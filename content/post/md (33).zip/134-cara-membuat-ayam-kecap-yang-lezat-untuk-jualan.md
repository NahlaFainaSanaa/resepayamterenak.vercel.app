---
description: "Cara membuat Ayam kecap yang lezat Untuk Jualan"
title: "Cara membuat Ayam kecap yang lezat Untuk Jualan"
slug: 134-cara-membuat-ayam-kecap-yang-lezat-untuk-jualan
date: 2021-02-18T23:30:04.461Z
image: https://img-global.cpcdn.com/recipes/311fd94368876bd2/680x482cq70/ayam-kecap-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/311fd94368876bd2/680x482cq70/ayam-kecap-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/311fd94368876bd2/680x482cq70/ayam-kecap-foto-resep-utama.jpg
author: Jessie Anderson
ratingvalue: 3.5
reviewcount: 5
recipeingredient:
- "1/2 ekor ayam potong 6"
- " bawang bombai 12 siung aku gapake lagi Gaada stock"
- "4 siung bawang putih"
- "7 siung bawang merah"
- "2 cm jahe"
- "2 batang Sereh"
- "4 butir Kemiri"
- "2 lembar Daun salam"
- " Kecap1 sdt garam12 sdt penyedapmerica dan ketumbar secukupny"
- "sesuai selera Gula merah"
recipeinstructions:
- "Cuci ayam lalu marinasi pakai perasan jeruk nipis,kasih garam diam km 15 menit lalu goreng setengah matang."
- "Ulek semua bumbu kecuali sereh dan daun salam."
- "Lalu tumis bumbu batang sereh daun salam sampai benar2 Tanak(matang)."
- "Tambah kan air jika sudah mendidih masukan garam,gula,penyedap."
- "Masukan ayam,kecap aduk2 dan tunggu sampai benar2 matang,jika sudah matang angkat sajikan dengan taburan bawang goreng👍"
categories:
- Resep
tags:
- ayam
- kecap

katakunci: ayam kecap 
nutrition: 282 calories
recipecuisine: Indonesian
preptime: "PT31M"
cooktime: "PT50M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam kecap](https://img-global.cpcdn.com/recipes/311fd94368876bd2/680x482cq70/ayam-kecap-foto-resep-utama.jpg)

Andai anda seorang yang hobi masak, menyediakan olahan menggugah selera buat orang tercinta adalah hal yang sangat menyenangkan bagi kamu sendiri. Tugas seorang ibu Tidak cuma mengatur rumah saja, namun kamu juga harus memastikan kebutuhan nutrisi tercukupi dan juga olahan yang dimakan orang tercinta harus nikmat.

Di era  sekarang, kamu memang mampu memesan olahan praktis tidak harus susah mengolahnya dahulu. Tapi ada juga orang yang memang mau menyajikan yang terenak bagi orang tercintanya. Pasalnya, menyajikan masakan sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan makanan tersebut sesuai masakan kesukaan orang tercinta. 



Apakah anda adalah salah satu penikmat ayam kecap?. Asal kamu tahu, ayam kecap merupakan hidangan khas di Nusantara yang sekarang disenangi oleh banyak orang dari berbagai tempat di Nusantara. Kalian bisa menghidangkan ayam kecap sendiri di rumahmu dan boleh jadi makanan kegemaranmu di hari liburmu.

Kita tidak usah bingung jika kamu ingin memakan ayam kecap, lantaran ayam kecap mudah untuk didapatkan dan juga kalian pun bisa menghidangkannya sendiri di tempatmu. ayam kecap boleh dimasak dengan beraneka cara. Kini sudah banyak banget resep kekinian yang membuat ayam kecap lebih lezat.

Resep ayam kecap juga gampang untuk dibikin, lho. Anda tidak perlu ribet-ribet untuk memesan ayam kecap, sebab Kalian bisa menghidangkan di rumah sendiri. Bagi Kalian yang ingin mencobanya, di bawah ini adalah resep untuk menyajikan ayam kecap yang nikamat yang bisa Kalian hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Ayam kecap:

1. Siapkan 1/2 ekor ayam potong 6
1. Gunakan  bawang bombai 1/2 siung (aku gapake lagi Gaada stock)
1. Sediakan 4 siung bawang putih
1. Ambil 7 siung bawang merah
1. Siapkan 2 cm jahe
1. Ambil 2 batang Sereh
1. Gunakan 4 butir Kemiri
1. Siapkan 2 lembar Daun salam
1. Siapkan  Kecap,1 sdt garam,1/2 sdt penyedap,merica dan ketumbar secukupny
1. Sediakan sesuai selera Gula merah




<!--inarticleads2-->

##### Cara menyiapkan Ayam kecap:

1. Cuci ayam lalu marinasi pakai perasan jeruk nipis,kasih garam diam km 15 menit lalu goreng setengah matang.
1. Ulek semua bumbu kecuali sereh dan daun salam.
1. Lalu tumis bumbu batang sereh daun salam sampai benar2 Tanak(matang).
1. Tambah kan air jika sudah mendidih masukan garam,gula,penyedap.
1. Masukan ayam,kecap aduk2 dan tunggu sampai benar2 matang,jika sudah matang angkat sajikan dengan taburan bawang goreng👍




Wah ternyata cara membuat ayam kecap yang lezat simple ini enteng sekali ya! Anda Semua mampu menghidangkannya. Cara buat ayam kecap Sangat cocok sekali buat anda yang baru belajar memasak maupun juga bagi kamu yang telah hebat memasak.

Apakah kamu mau mulai mencoba bikin resep ayam kecap nikmat tidak ribet ini? Kalau kamu ingin, ayo kalian segera siapkan alat dan bahan-bahannya, kemudian buat deh Resep ayam kecap yang mantab dan tidak rumit ini. Betul-betul taidak sulit kan. 

Maka, daripada kalian berfikir lama-lama, hayo langsung aja bikin resep ayam kecap ini. Pasti kamu tak akan nyesel bikin resep ayam kecap nikmat sederhana ini! Selamat mencoba dengan resep ayam kecap enak sederhana ini di rumah masing-masing,oke!.

