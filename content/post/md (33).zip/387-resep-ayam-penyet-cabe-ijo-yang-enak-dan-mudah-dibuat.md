---
description: "Resep Ayam Penyet Cabe Ijo yang enak dan Mudah Dibuat"
title: "Resep Ayam Penyet Cabe Ijo yang enak dan Mudah Dibuat"
slug: 387-resep-ayam-penyet-cabe-ijo-yang-enak-dan-mudah-dibuat
date: 2021-02-16T14:52:46.939Z
image: https://img-global.cpcdn.com/recipes/1b0af39c8a9f7dc3/680x482cq70/ayam-penyet-cabe-ijo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1b0af39c8a9f7dc3/680x482cq70/ayam-penyet-cabe-ijo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1b0af39c8a9f7dc3/680x482cq70/ayam-penyet-cabe-ijo-foto-resep-utama.jpg
author: Owen Collier
ratingvalue: 3.8
reviewcount: 6
recipeingredient:
- "1/2 kg daging ayam"
- "1 batang serai"
- "2 lembar daun jeruk"
- " Bumbu ukep ayam"
- "4 siung bawang merah"
- "3 siung bawang putih"
- "1 ruas jahe"
- "1 ruas kunyit"
- "1 sdt ketumbar"
- "Secukupnya garam"
- "Secukupnya kaldu jamur"
- "Secukupnya air untuk merebus ayam"
- " Bahan sambal ijo"
- "5 cabe hijau besar"
- "20 cabe rawit hijau"
- "2 tomat hijau kecil"
- "3 siung bawang putih"
- "4 siung bawang merah"
- "Secukupnya gula dan garam"
- "Secukupnya minyak goreng"
recipeinstructions:
- "Potong ayam kemudian cuci bersih ditiriskan. Rebus air hingga mendidih lalu masukkan ayam"
- "Siapkan bahan bumbu ukep, masukkan bumbu kedalam rebusan ayam tambahkan daun jeruk, serai garam dan kaldu jamur biarkan mendidih lalu koreksi rasa, masak hingga ayam empuk dan bumbu meresap"
- "Jika ayam sudah matang dan bumbu meresap, angkat dan tiriskan ayam lalu goreng dalam minyak panas hingga kecoklatan kemudian sisihkan"
- "Siapkan bahan untuk sambal ijo, goreng bumbu yg sudah dipotong-potong hingga bumbu matang dan layu"
- "Letakan bumbu di atas cobek tambahkan sedikit gula dan garam kemudian ulek dan koreksi rasa."
- "Letakkan ayam yg sudah digoreng tadi di atas cobek lalu penyet, ayam penyet siap disajikan"
- "Sajikan dengan nasi hangat, selamat sarapan 😅😉"
categories:
- Resep
tags:
- ayam
- penyet
- cabe

katakunci: ayam penyet cabe 
nutrition: 237 calories
recipecuisine: Indonesian
preptime: "PT19M"
cooktime: "PT30M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam Penyet Cabe Ijo](https://img-global.cpcdn.com/recipes/1b0af39c8a9f7dc3/680x482cq70/ayam-penyet-cabe-ijo-foto-resep-utama.jpg)

Sebagai seorang wanita, menyediakan panganan menggugah selera pada orang tercinta adalah suatu hal yang memuaskan bagi anda sendiri. Tanggung jawab seorang ibu Tidak saja mengurus rumah saja, tapi kamu pun wajib menyediakan keperluan gizi tercukupi dan olahan yang dimakan keluarga tercinta mesti enak.

Di masa  sekarang, kita memang bisa memesan panganan praktis walaupun tidak harus capek mengolahnya lebih dulu. Tetapi ada juga lho mereka yang selalu mau memberikan makanan yang terlezat untuk orang tercintanya. Pasalnya, memasak yang diolah sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan masakan tersebut sesuai selera famili. 



Mungkinkah anda seorang penikmat ayam penyet cabe ijo?. Tahukah kamu, ayam penyet cabe ijo adalah makanan khas di Nusantara yang saat ini disukai oleh kebanyakan orang dari hampir setiap wilayah di Nusantara. Kalian dapat memasak ayam penyet cabe ijo olahan sendiri di rumah dan pasti jadi santapan favoritmu di hari liburmu.

Kalian tak perlu bingung jika kamu ingin menyantap ayam penyet cabe ijo, sebab ayam penyet cabe ijo sangat mudah untuk ditemukan dan kalian pun dapat mengolahnya sendiri di rumah. ayam penyet cabe ijo boleh diolah lewat beragam cara. Saat ini sudah banyak banget resep modern yang menjadikan ayam penyet cabe ijo lebih lezat.

Resep ayam penyet cabe ijo pun mudah dihidangkan, lho. Kita jangan repot-repot untuk memesan ayam penyet cabe ijo, tetapi Kita mampu menghidangkan di rumah sendiri. Bagi Kita yang ingin membuatnya, berikut cara untuk menyajikan ayam penyet cabe ijo yang lezat yang mampu Kita coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Ayam Penyet Cabe Ijo:

1. Sediakan 1/2 kg daging ayam
1. Ambil 1 batang serai
1. Siapkan 2 lembar daun jeruk
1. Ambil  Bumbu ukep ayam
1. Ambil 4 siung bawang merah
1. Gunakan 3 siung bawang putih
1. Siapkan 1 ruas jahe
1. Sediakan 1 ruas kunyit
1. Siapkan 1 sdt ketumbar
1. Gunakan Secukupnya garam
1. Siapkan Secukupnya kaldu jamur
1. Siapkan Secukupnya air untuk merebus ayam
1. Ambil  Bahan sambal ijo
1. Siapkan 5 cabe hijau besar
1. Siapkan 20 cabe rawit hijau
1. Gunakan 2 tomat hijau kecil
1. Sediakan 3 siung bawang putih
1. Ambil 4 siung bawang merah
1. Sediakan Secukupnya gula dan garam
1. Gunakan Secukupnya minyak goreng




<!--inarticleads2-->

##### Cara menyiapkan Ayam Penyet Cabe Ijo:

1. Potong ayam kemudian cuci bersih ditiriskan. Rebus air hingga mendidih lalu masukkan ayam
1. Siapkan bahan bumbu ukep, masukkan bumbu kedalam rebusan ayam tambahkan daun jeruk, serai garam dan kaldu jamur biarkan mendidih lalu koreksi rasa, masak hingga ayam empuk dan bumbu meresap
1. Jika ayam sudah matang dan bumbu meresap, angkat dan tiriskan ayam lalu goreng dalam minyak panas hingga kecoklatan kemudian sisihkan
1. Siapkan bahan untuk sambal ijo, goreng bumbu yg sudah dipotong-potong hingga bumbu matang dan layu
1. Letakan bumbu di atas cobek tambahkan sedikit gula dan garam kemudian ulek dan koreksi rasa.
1. Letakkan ayam yg sudah digoreng tadi di atas cobek lalu penyet, ayam penyet siap disajikan
1. Sajikan dengan nasi hangat, selamat sarapan 😅😉




Wah ternyata cara buat ayam penyet cabe ijo yang nikamt tidak rumit ini enteng sekali ya! Anda Semua bisa memasaknya. Cara buat ayam penyet cabe ijo Cocok banget untuk anda yang baru belajar memasak maupun juga untuk kamu yang sudah jago dalam memasak.

Tertarik untuk mulai mencoba membikin resep ayam penyet cabe ijo lezat simple ini? Kalau anda tertarik, yuk kita segera buruan menyiapkan peralatan dan bahan-bahannya, lalu buat deh Resep ayam penyet cabe ijo yang nikmat dan tidak ribet ini. Sungguh taidak sulit kan. 

Maka dari itu, ketimbang kalian berfikir lama-lama, hayo kita langsung buat resep ayam penyet cabe ijo ini. Dijamin kamu tak akan nyesel sudah buat resep ayam penyet cabe ijo nikmat tidak rumit ini! Selamat mencoba dengan resep ayam penyet cabe ijo nikmat tidak ribet ini di tempat tinggal masing-masing,oke!.

