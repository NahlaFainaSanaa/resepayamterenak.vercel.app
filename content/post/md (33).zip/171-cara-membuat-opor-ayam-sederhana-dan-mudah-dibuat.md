---
description: "Cara membuat Opor Ayam Sederhana dan Mudah Dibuat"
title: "Cara membuat Opor Ayam Sederhana dan Mudah Dibuat"
slug: 171-cara-membuat-opor-ayam-sederhana-dan-mudah-dibuat
date: 2021-05-19T20:36:31.226Z
image: https://img-global.cpcdn.com/recipes/56098ae1491a47de/680x482cq70/opor-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/56098ae1491a47de/680x482cq70/opor-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/56098ae1491a47de/680x482cq70/opor-ayam-foto-resep-utama.jpg
author: Floyd Hubbard
ratingvalue: 3.6
reviewcount: 11
recipeingredient:
- "500 gr ayam"
- "1 butir Santan kelapa dari  kelapa"
- " Bumbu halus"
- "6 siung Bawang putih"
- "1 butir Kemiri"
- "1/2 sdt Merica"
- "1 ruas kunyit digoreng dulu biar ndak bau kunyit mentah"
- "Secuil jahe"
- "1 ruas jahe di geprek"
- "1 lembar daun salam"
- "1 lembar daun jeruk"
- "1 buah serai buang daunnya lalu di geprek"
- "sesuai selera Gula jawa garam kaldu jamur"
- "secukupnya Air"
- " Taburan bawang merah goreng sama seledri"
recipeinstructions:
- "Cuci bersih ayam, lalu rebus dulu sebentar.. setelah itu buang air rebusan dan tiriskan"
- "Haluskan bumbu, bawang putih, kemiri, merica,kunyit goreng dan secuil jahe,,"
- "Panaskan minyak, tumis bumbu halus sampai harum lalu tambahkan daun salam, daun jeruk, serai geprek dan jahe yang sudah digeprek, tumis hingga bumbu matang, lalu masukkan daging ayam, tambahkan sedikit air, tambahkan juga gula dan garam"
- "Peras santan dari 1 butir kelapa tadi, perasan pertama di sisihkan buat di masukkan ketika mau asat, perasan kedua di pake untuk ungkep ayamnya"
- "Setelah itu tambahkan santan cair (perasan kedua) pada ayam yg telah dimasak..setelah agak asat masukkan santan kental (perasan pertama) kaldu jamur dan koreksi rasa, tunggu agak menyusut santanya sambil di aduk"
- "Setelah matang, taburi bawang merah goreng dan seledri..selamat mencoba"
categories:
- Resep
tags:
- opor
- ayam

katakunci: opor ayam 
nutrition: 231 calories
recipecuisine: Indonesian
preptime: "PT25M"
cooktime: "PT43M"
recipeyield: "2"
recipecategory: Dinner

---


![Opor Ayam](https://img-global.cpcdn.com/recipes/56098ae1491a47de/680x482cq70/opor-ayam-foto-resep-utama.jpg)

Sebagai seorang yang hobi masak, menyajikan masakan nikmat pada famili adalah hal yang mengasyikan untuk anda sendiri. Kewajiban seorang  wanita Tidak sekadar mengatur rumah saja, namun kamu juga harus memastikan kebutuhan gizi tercukupi dan panganan yang dikonsumsi anak-anak wajib menggugah selera.

Di era  saat ini, anda sebenarnya mampu mengorder masakan siap saji meski tanpa harus ribet mengolahnya dahulu. Tetapi banyak juga lho orang yang selalu ingin menyajikan yang terenak untuk orang yang dicintainya. Karena, menghidangkan masakan sendiri jauh lebih higienis dan bisa menyesuaikan makanan tersebut sesuai makanan kesukaan orang tercinta. 



Apakah anda adalah seorang penikmat opor ayam?. Tahukah kamu, opor ayam merupakan makanan khas di Indonesia yang kini digemari oleh kebanyakan orang di berbagai wilayah di Indonesia. Anda bisa menghidangkan opor ayam sendiri di rumahmu dan pasti jadi hidangan kesenanganmu di akhir pekanmu.

Anda tidak perlu bingung jika kamu ingin menyantap opor ayam, sebab opor ayam mudah untuk didapatkan dan kalian pun dapat menghidangkannya sendiri di tempatmu. opor ayam dapat diolah memalui berbagai cara. Saat ini telah banyak resep kekinian yang membuat opor ayam lebih mantap.

Resep opor ayam juga gampang sekali dibikin, lho. Kamu tidak usah ribet-ribet untuk memesan opor ayam, karena Kalian mampu menyajikan di rumah sendiri. Bagi Kalian yang mau menghidangkannya, di bawah ini adalah resep menyajikan opor ayam yang nikamat yang mampu Kamu coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Opor Ayam:

1. Sediakan 500 gr ayam
1. Ambil 1 butir Santan kelapa dari  kelapa
1. Ambil  Bumbu halus
1. Sediakan 6 siung Bawang putih
1. Sediakan 1 butir Kemiri
1. Gunakan 1/2 sdt Merica
1. Gunakan 1 ruas kunyit digoreng dulu biar ndak bau kunyit mentah
1. Gunakan Secuil jahe
1. Sediakan 1 ruas jahe di geprek
1. Gunakan 1 lembar daun salam
1. Ambil 1 lembar daun jeruk
1. Gunakan 1 buah serai buang daunnya lalu di geprek
1. Gunakan sesuai selera Gula jawa, garam, kaldu jamur
1. Ambil secukupnya Air
1. Ambil  Taburan bawang merah goreng sama seledri




<!--inarticleads2-->

##### Langkah-langkah membuat Opor Ayam:

1. Cuci bersih ayam, lalu rebus dulu sebentar.. setelah itu buang air rebusan dan tiriskan
1. Haluskan bumbu, bawang putih, kemiri, merica,kunyit goreng dan secuil jahe,,
1. Panaskan minyak, tumis bumbu halus sampai harum lalu tambahkan daun salam, daun jeruk, serai geprek dan jahe yang sudah digeprek, tumis hingga bumbu matang, lalu masukkan daging ayam, tambahkan sedikit air, tambahkan juga gula dan garam
1. Peras santan dari 1 butir kelapa tadi, perasan pertama di sisihkan buat di masukkan ketika mau asat, perasan kedua di pake untuk ungkep ayamnya
1. Setelah itu tambahkan santan cair (perasan kedua) pada ayam yg telah dimasak..setelah agak asat masukkan santan kental (perasan pertama) kaldu jamur dan koreksi rasa, tunggu agak menyusut santanya sambil di aduk
1. Setelah matang, taburi bawang merah goreng dan seledri..selamat mencoba




Wah ternyata resep opor ayam yang enak tidak rumit ini enteng sekali ya! Kamu semua dapat membuatnya. Cara Membuat opor ayam Sesuai banget buat kalian yang sedang belajar memasak maupun juga bagi anda yang telah pandai memasak.

Apakah kamu ingin mulai mencoba membikin resep opor ayam mantab tidak rumit ini? Kalau kalian ingin, mending kamu segera buruan siapkan alat-alat dan bahannya, lantas bikin deh Resep opor ayam yang enak dan tidak rumit ini. Betul-betul gampang kan. 

Oleh karena itu, ketimbang anda berlama-lama, yuk kita langsung hidangkan resep opor ayam ini. Pasti kalian gak akan nyesel membuat resep opor ayam mantab simple ini! Selamat mencoba dengan resep opor ayam nikmat tidak rumit ini di rumah sendiri,oke!.

