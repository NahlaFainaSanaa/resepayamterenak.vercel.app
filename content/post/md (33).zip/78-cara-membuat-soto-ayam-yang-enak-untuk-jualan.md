---
description: "Cara membuat Soto Ayam yang enak Untuk Jualan"
title: "Cara membuat Soto Ayam yang enak Untuk Jualan"
slug: 78-cara-membuat-soto-ayam-yang-enak-untuk-jualan
date: 2021-05-16T21:20:18.738Z
image: https://img-global.cpcdn.com/recipes/a17fae7401ff89c3/680x482cq70/soto-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a17fae7401ff89c3/680x482cq70/soto-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a17fae7401ff89c3/680x482cq70/soto-ayam-foto-resep-utama.jpg
author: Peter Allen
ratingvalue: 3.7
reviewcount: 3
recipeingredient:
- "1 ekor Ayam belah jadi 4"
- "1500 ml Air"
- "2 batang Serai memarkan"
- "4 lembar Daun Jeruk"
- "2 cm Lengkuas memarkan"
- "1/4 sdt Lada bubuk"
- "Secukupnya Gula garam dan kaldu bubuk"
- " Bumbu Halus"
- "10 siung Bawang putih"
- "5 siung Bawang merah"
- "2 cm Jahe"
- "2 cm Kunyit"
- "4 butir Kemiri"
- " Pelengkap"
- "3 butir Telur rebu potong  potong"
- "4 lembar Kol iris halus"
- "100 gr Tauge"
- "2 bh Tomat potongpotong"
- "Beberapa lembar daun seledri rajang halus"
- "Secukupnya Bawang Merah goreng untuk taburan"
- "Secukupnya jeruk nipis untuk kecuran"
- " Sambal rebus cabai rawit haluskan dan beri tambahan gula dan garam secukupnya"
recipeinstructions:
- "Bersihkan ayam lalu rebus ayam sampai keluar kaldu dan ayam agak empuk. Haluskan bumbu dan tumis sampai harum, masukkan serai, daun jeruk, lengkuas dan lada bubuk, aduk-aduk sebentar. Masukkan bumbu tumis ke dalam rebusan ayam. Tambahkan gula, garam dan kaldu bubuk. Kecilkan api masak kira-kira 15 menit sampai bumbu meresap. Cicipi dan koreksi rasa."
- "Setelah ayam empuk, angkat dan goreng sebentar dengan sedikit minyak sampai ayam agak kecoklatan lalu suwir-suwir atau iris tipi sesuai selera. Siapkan pelengkap soto."
- "Hidangkan soto ayam dengan taburan kol rebus, irisan tomat, tauge, bawang goreng, telur rebus dan terakhir beri perasan jeruk nipis."
categories:
- Resep
tags:
- soto
- ayam

katakunci: soto ayam 
nutrition: 102 calories
recipecuisine: Indonesian
preptime: "PT30M"
cooktime: "PT51M"
recipeyield: "4"
recipecategory: Lunch

---


![Soto Ayam](https://img-global.cpcdn.com/recipes/a17fae7401ff89c3/680x482cq70/soto-ayam-foto-resep-utama.jpg)

Selaku seorang wanita, menyediakan hidangan lezat bagi famili adalah suatu hal yang mengasyikan untuk kita sendiri. Peran seorang ibu bukan sekedar menjaga rumah saja, namun anda pun harus memastikan keperluan gizi tercukupi dan juga santapan yang dikonsumsi anak-anak mesti mantab.

Di waktu  saat ini, kamu memang dapat memesan panganan instan tanpa harus susah memasaknya dulu. Tetapi ada juga lho mereka yang selalu mau memberikan makanan yang terlezat bagi orang yang dicintainya. Lantaran, menyajikan masakan yang diolah sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan hidangan tersebut berdasarkan makanan kesukaan keluarga. 



Mungkinkah anda merupakan salah satu penyuka soto ayam?. Tahukah kamu, soto ayam merupakan hidangan khas di Indonesia yang sekarang digemari oleh orang-orang dari berbagai daerah di Nusantara. Anda dapat membuat soto ayam sendiri di rumah dan dapat dijadikan makanan kesenanganmu di hari libur.

Kita jangan bingung untuk memakan soto ayam, sebab soto ayam mudah untuk ditemukan dan juga kalian pun bisa membuatnya sendiri di tempatmu. soto ayam dapat dibuat dengan beragam cara. Kini pun telah banyak sekali resep kekinian yang menjadikan soto ayam semakin mantap.

Resep soto ayam pun gampang dihidangkan, lho. Kalian tidak perlu ribet-ribet untuk memesan soto ayam, lantaran Kita mampu menghidangkan sendiri di rumah. Untuk Kamu yang hendak mencobanya, berikut resep untuk menyajikan soto ayam yang mantab yang dapat Kita coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Soto Ayam:

1. Ambil 1 ekor Ayam belah jadi 4
1. Gunakan 1500 ml Air
1. Gunakan 2 batang Serai, memarkan
1. Ambil 4 lembar Daun Jeruk
1. Ambil 2 cm Lengkuas, memarkan
1. Siapkan 1/4 sdt Lada bubuk
1. Siapkan Secukupnya Gula, garam dan kaldu bubuk
1. Ambil  Bumbu Halus:
1. Sediakan 10 siung Bawang putih
1. Siapkan 5 siung Bawang merah
1. Gunakan 2 cm Jahe
1. Sediakan 2 cm Kunyit
1. Sediakan 4 butir Kemiri
1. Siapkan  Pelengkap:
1. Siapkan 3 butir Telur rebu, potong - potong
1. Gunakan 4 lembar Kol, iris halus
1. Sediakan 100 gr Tauge
1. Ambil 2 bh Tomat, potong-potong
1. Sediakan Beberapa lembar daun seledri, rajang halus
1. Siapkan Secukupnya Bawang Merah goreng untuk taburan
1. Sediakan Secukupnya jeruk nipis untuk kecuran
1. Ambil  Sambal: (rebus cabai rawit, haluskan dan beri tambahan gula dan garam secukupnya)




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Soto Ayam:

1. Bersihkan ayam lalu rebus ayam sampai keluar kaldu dan ayam agak empuk. Haluskan bumbu dan tumis sampai harum, masukkan serai, daun jeruk, lengkuas dan lada bubuk, aduk-aduk sebentar. Masukkan bumbu tumis ke dalam rebusan ayam. Tambahkan gula, garam dan kaldu bubuk. Kecilkan api masak kira-kira 15 menit sampai bumbu meresap. Cicipi dan koreksi rasa.
1. Setelah ayam empuk, angkat dan goreng sebentar dengan sedikit minyak sampai ayam agak kecoklatan lalu suwir-suwir atau iris tipi sesuai selera. Siapkan pelengkap soto.
1. Hidangkan soto ayam dengan taburan kol rebus, irisan tomat, tauge, bawang goreng, telur rebus dan terakhir beri perasan jeruk nipis.




Wah ternyata resep soto ayam yang enak simple ini gampang banget ya! Kalian semua dapat mencobanya. Cara Membuat soto ayam Sangat sesuai banget buat kalian yang baru belajar memasak atau juga bagi kamu yang sudah jago memasak.

Apakah kamu tertarik mencoba buat resep soto ayam lezat sederhana ini? Kalau tertarik, mending kamu segera menyiapkan alat-alat dan bahan-bahannya, lalu buat deh Resep soto ayam yang mantab dan tidak rumit ini. Betul-betul mudah kan. 

Maka, daripada anda berlama-lama, maka kita langsung bikin resep soto ayam ini. Pasti kalian tak akan nyesel bikin resep soto ayam enak simple ini! Selamat berkreasi dengan resep soto ayam mantab sederhana ini di tempat tinggal kalian masing-masing,ya!.

