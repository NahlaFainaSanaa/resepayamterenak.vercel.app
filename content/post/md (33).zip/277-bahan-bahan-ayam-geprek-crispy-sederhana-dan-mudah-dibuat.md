---
description: "Bahan-bahan Ayam Geprek / Crispy Sederhana dan Mudah Dibuat"
title: "Bahan-bahan Ayam Geprek / Crispy Sederhana dan Mudah Dibuat"
slug: 277-bahan-bahan-ayam-geprek-crispy-sederhana-dan-mudah-dibuat
date: 2021-04-19T00:32:13.755Z
image: https://img-global.cpcdn.com/recipes/147156d34a533ef0/680x482cq70/ayam-geprek-crispy-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/147156d34a533ef0/680x482cq70/ayam-geprek-crispy-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/147156d34a533ef0/680x482cq70/ayam-geprek-crispy-foto-resep-utama.jpg
author: Katherine Baldwin
ratingvalue: 4.1
reviewcount: 8
recipeingredient:
- "Secukupnya ayam fillet garam jeniper"
- " Bumbu marinasi "
- "5 Bawang putih yg sudah dihaluskan"
- "1 sdt Lada bubuk"
- "1 sdm Kaldu bubuk"
- "1 sdm Garam"
- "1 sdm Cabe bubuk optional"
- "1 sdm Ketumbar"
- " Bumbu Baluran Tepung "
- " Tepung terigu agak banyakan"
- "1 sdm garam"
- "1 sdm kaldu bubuk"
- "1 sdm lada bubuk"
- "1 sdm ketumbar bubuk"
- "1 sdt baking powder  kalo gk ada boleh pake baking soda"
- " Bahan celupan air "
- " Air dingin  es"
- "1 sdt baking powder  baking soda"
- "1 sdt kaldu bubuk"
- "1 sdt garam"
recipeinstructions:
- "Bersihkan ayam, baluri jeniper dan garam, biarkan sebentar"
- "Siapkan bumbu marinasi, tambahkan ke ayam, aduk rata, biarkan selama semalaman di kulkas."
- "Siapkan bahan tepung balur, aduk rata. Sisihkan."
- "Siapkan bahan celupan air, aduk hingga merata semua."
- "Balurkan ayam yg sudah di marinasi ke dalam tepung, aduk dengan dibalik2 spt di gulung2, jangan di tekan2, lakukan selama 1-2 mnit"
- "Celupkan ke dalam campuran air es, angkat, lalu tiriskan airnya, usahakan air nya benar2 tertiriskan, supaya tepung nya tidak bergumpal2"
- "Lalu baluri lagi dg tepung tadi, guling2kan ayam nya sampai tepung nya terbentuk kriwil2 dn banyak"
- "Jika di rasa tepung kurang tebal, bisa di celupkan lagi ke air es, lalu baluri lg dg tepung"
- "Sambil masih di aduk ayamnya, panas kan minyak, stelah selesai proses baluran tepung, goreng ayam dengan posisi ayam bener2 tenggelam ke dlm minyak, minyak nya harus banyak dan bener2 udah panas pas di celupin ayam nya ke minyak"
- "Kalo sudah keemasan, balik ayamnya. Cukup 1 x balik saja. Stelah matang keemasan, angkat dn tiriskan"
- "Geprek ayam nya sedikit, baluri sambal di atasnya"
- "Siap di nikmati dengan nasi hangat :)"
categories:
- Resep
tags:
- ayam
- geprek
- 

katakunci: ayam geprek  
nutrition: 235 calories
recipecuisine: Indonesian
preptime: "PT36M"
cooktime: "PT53M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Geprek / Crispy](https://img-global.cpcdn.com/recipes/147156d34a533ef0/680x482cq70/ayam-geprek-crispy-foto-resep-utama.jpg)

Andai kamu seorang orang tua, menyediakan hidangan enak pada famili adalah suatu hal yang membahagiakan bagi anda sendiri. Kewajiban seorang  wanita Tidak sekedar menangani rumah saja, tapi anda juga harus menyediakan kebutuhan gizi tercukupi dan panganan yang dikonsumsi anak-anak mesti enak.

Di waktu  saat ini, kalian memang dapat memesan masakan instan tanpa harus ribet membuatnya dulu. Tapi banyak juga orang yang selalu ingin memberikan makanan yang terenak untuk orang tercintanya. Sebab, menyajikan masakan yang dibuat sendiri jauh lebih higienis dan bisa menyesuaikan makanan tersebut sesuai dengan selera famili. 



Apakah anda merupakan salah satu penggemar ayam geprek / crispy?. Asal kamu tahu, ayam geprek / crispy adalah makanan khas di Indonesia yang saat ini disenangi oleh banyak orang dari hampir setiap wilayah di Nusantara. Kamu bisa membuat ayam geprek / crispy sendiri di rumah dan boleh jadi hidangan kesenanganmu di hari libur.

Kita tidak perlu bingung untuk mendapatkan ayam geprek / crispy, sebab ayam geprek / crispy tidak sulit untuk dicari dan kalian pun dapat memasaknya sendiri di tempatmu. ayam geprek / crispy bisa dibuat memalui bermacam cara. Kini ada banyak cara modern yang membuat ayam geprek / crispy semakin mantap.

Resep ayam geprek / crispy pun gampang sekali untuk dibikin, lho. Anda jangan repot-repot untuk memesan ayam geprek / crispy, lantaran Anda dapat menghidangkan sendiri di rumah. Bagi Kamu yang hendak mencobanya, berikut cara menyajikan ayam geprek / crispy yang lezat yang mampu Kita buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Ayam Geprek / Crispy:

1. Gunakan Secukupnya ayam fillet, garam, jeniper
1. Gunakan  Bumbu marinasi :
1. Ambil 5 Bawang putih yg sudah dihaluskan
1. Ambil 1 sdt Lada bubuk
1. Gunakan 1 sdm Kaldu bubuk
1. Ambil 1 sdm Garam
1. Gunakan 1 sdm Cabe bubuk (optional)
1. Ambil 1 sdm Ketumbar
1. Ambil  Bumbu Baluran Tepung :
1. Sediakan  Tepung terigu (agak banyakan)
1. Sediakan 1 sdm garam
1. Siapkan 1 sdm kaldu bubuk
1. Siapkan 1 sdm lada bubuk
1. Sediakan 1 sdm ketumbar bubuk
1. Gunakan 1 sdt baking powder / kalo gk ada boleh pake baking soda
1. Siapkan  Bahan celupan air :
1. Sediakan  Air dingin + es
1. Ambil 1 sdt baking powder / baking soda
1. Sediakan 1 sdt kaldu bubuk
1. Siapkan 1 sdt garam




<!--inarticleads2-->

##### Cara membuat Ayam Geprek / Crispy:

1. Bersihkan ayam, baluri jeniper dan garam, biarkan sebentar
1. Siapkan bumbu marinasi, tambahkan ke ayam, aduk rata, biarkan selama semalaman di kulkas.
1. Siapkan bahan tepung balur, aduk rata. Sisihkan.
1. Siapkan bahan celupan air, aduk hingga merata semua.
1. Balurkan ayam yg sudah di marinasi ke dalam tepung, aduk dengan dibalik2 spt di gulung2, jangan di tekan2, lakukan selama 1-2 mnit
1. Celupkan ke dalam campuran air es, angkat, lalu tiriskan airnya, usahakan air nya benar2 tertiriskan, supaya tepung nya tidak bergumpal2
1. Lalu baluri lagi dg tepung tadi, guling2kan ayam nya sampai tepung nya terbentuk kriwil2 dn banyak
1. Jika di rasa tepung kurang tebal, bisa di celupkan lagi ke air es, lalu baluri lg dg tepung
1. Sambil masih di aduk ayamnya, panas kan minyak, stelah selesai proses baluran tepung, goreng ayam dengan posisi ayam bener2 tenggelam ke dlm minyak, minyak nya harus banyak dan bener2 udah panas pas di celupin ayam nya ke minyak
1. Kalo sudah keemasan, balik ayamnya. Cukup 1 x balik saja. - Stelah matang keemasan, angkat dn tiriskan
1. Geprek ayam nya sedikit, baluri sambal di atasnya
1. Siap di nikmati dengan nasi hangat :)




Wah ternyata cara buat ayam geprek / crispy yang nikamt sederhana ini enteng banget ya! Kamu semua mampu mencobanya. Cara buat ayam geprek / crispy Cocok sekali buat kalian yang baru belajar memasak maupun untuk kamu yang sudah lihai memasak.

Tertarik untuk mulai mencoba membikin resep ayam geprek / crispy lezat tidak ribet ini? Kalau tertarik, yuk kita segera buruan menyiapkan alat dan bahan-bahannya, kemudian buat deh Resep ayam geprek / crispy yang enak dan simple ini. Benar-benar mudah kan. 

Maka, ketimbang kita diam saja, maka kita langsung saja bikin resep ayam geprek / crispy ini. Dijamin kalian gak akan nyesel bikin resep ayam geprek / crispy nikmat simple ini! Selamat mencoba dengan resep ayam geprek / crispy nikmat tidak rumit ini di rumah masing-masing,oke!.

