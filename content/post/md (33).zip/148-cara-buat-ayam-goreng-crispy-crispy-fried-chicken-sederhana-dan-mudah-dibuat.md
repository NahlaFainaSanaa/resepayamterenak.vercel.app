---
description: "Cara buat Ayam Goreng Crispy / Crispy Fried Chicken Sederhana dan Mudah Dibuat"
title: "Cara buat Ayam Goreng Crispy / Crispy Fried Chicken Sederhana dan Mudah Dibuat"
slug: 148-cara-buat-ayam-goreng-crispy-crispy-fried-chicken-sederhana-dan-mudah-dibuat
date: 2021-03-08T22:51:46.038Z
image: https://img-global.cpcdn.com/recipes/0977d0a3a97ad075/680x482cq70/ayam-goreng-crispy-crispy-fried-chicken-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0977d0a3a97ad075/680x482cq70/ayam-goreng-crispy-crispy-fried-chicken-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0977d0a3a97ad075/680x482cq70/ayam-goreng-crispy-crispy-fried-chicken-foto-resep-utama.jpg
author: Tyler Sharp
ratingvalue: 3.3
reviewcount: 15
recipeingredient:
- "1 kg Ayam potong sesuai selera"
- "2 sdt Lada Bubuk"
- "2 sdt Garam"
- "2 sdt Curry Powder"
- "2 sdt Chilli Powder"
- "2 sdt Kaldu Bubuk Non MSG"
- "250 ml Air Es"
- "1 btr Telur kocok lepas"
- "250 g Terigu Protein Rendah"
- "125 g Maizena"
- "1 sdt Lada Bubuk Ekstra"
- "2 sdt Garam Ekstra"
- "1 sdt Baking Soda"
- "2 sdt Kaldu Bubuk Non MSG Ekstra"
- "secukupnya Minyak Goreng"
recipeinstructions:
- "Tusuk - tusuk daging ayam dengan garpu supaya bumbu marinasi dapat meresap"
- "Tambahkan lada bubuk + garam + Curry powder + chilli powder + kaldu bubuk non MSG, aduk rata. Simpan dalam lemari pendingin minimal 1 jam. Sisihkan"
- "Campur terigu + maizena + lada bubuk ekstra + garam ekstra + baking soda + kaldu bubuk ekstra, aduk rata. Sisihkan"
- "Campur air es + telur + 5 sdm campuran tepung, aduk rata. Sisihkan"
- "Masukkan ayam dalam campuran terigu, ratakan tepung sambil sedikit ditekan"
- "Celupkan dalam larutan air es, tiriskan"
- "Masukkan ayam dalam campuran terigu, ratakan tepung sambil dicubit - cubit. Kibaskan"
- "Goreng hingga matang 12 menit dalam minyak panas sedang yang volumenya merendam seluruh bagian ayam"
categories:
- Resep
tags:
- ayam
- goreng
- crispy

katakunci: ayam goreng crispy 
nutrition: 152 calories
recipecuisine: Indonesian
preptime: "PT14M"
cooktime: "PT36M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam Goreng Crispy / Crispy Fried Chicken](https://img-global.cpcdn.com/recipes/0977d0a3a97ad075/680x482cq70/ayam-goreng-crispy-crispy-fried-chicken-foto-resep-utama.jpg)

Selaku seorang istri, menyediakan santapan menggugah selera pada orang tercinta adalah suatu hal yang memuaskan bagi kita sendiri. Kewajiban seorang  wanita Tidak cuma menjaga rumah saja, namun kamu pun harus memastikan keperluan nutrisi terpenuhi dan juga olahan yang dikonsumsi keluarga tercinta mesti lezat.

Di era  sekarang, kita memang dapat mengorder olahan praktis tidak harus susah memasaknya dulu. Tetapi banyak juga lho mereka yang memang mau menyajikan yang terlezat bagi orang tercintanya. Lantaran, menghidangkan masakan sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan makanan tersebut sesuai dengan selera famili. 



Mungkinkah anda adalah salah satu penggemar ayam goreng crispy / crispy fried chicken?. Asal kamu tahu, ayam goreng crispy / crispy fried chicken adalah sajian khas di Nusantara yang sekarang digemari oleh setiap orang dari berbagai wilayah di Indonesia. Kalian dapat menghidangkan ayam goreng crispy / crispy fried chicken sendiri di rumah dan pasti jadi hidangan kesukaanmu di akhir pekan.

Kita jangan bingung untuk memakan ayam goreng crispy / crispy fried chicken, lantaran ayam goreng crispy / crispy fried chicken sangat mudah untuk didapatkan dan juga anda pun boleh mengolahnya sendiri di rumah. ayam goreng crispy / crispy fried chicken boleh diolah lewat beragam cara. Sekarang sudah banyak banget resep modern yang menjadikan ayam goreng crispy / crispy fried chicken semakin nikmat.

Resep ayam goreng crispy / crispy fried chicken pun mudah dihidangkan, lho. Kita tidak usah repot-repot untuk membeli ayam goreng crispy / crispy fried chicken, karena Kamu mampu menyiapkan di rumah sendiri. Untuk Kita yang akan menghidangkannya, di bawah ini adalah cara untuk membuat ayam goreng crispy / crispy fried chicken yang enak yang bisa Anda buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Ayam Goreng Crispy / Crispy Fried Chicken:

1. Ambil 1 kg Ayam, potong sesuai selera
1. Ambil 2 sdt Lada Bubuk
1. Ambil 2 sdt Garam
1. Sediakan 2 sdt Curry Powder
1. Gunakan 2 sdt Chilli Powder
1. Gunakan 2 sdt Kaldu Bubuk Non MSG
1. Gunakan 250 ml Air Es
1. Siapkan 1 btr Telur, kocok lepas
1. Gunakan 250 g Terigu Protein Rendah
1. Sediakan 125 g Maizena
1. Ambil 1 sdt Lada Bubuk Ekstra
1. Ambil 2 sdt Garam Ekstra
1. Ambil 1 sdt Baking Soda
1. Ambil 2 sdt Kaldu Bubuk Non MSG Ekstra
1. Sediakan secukupnya Minyak Goreng




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Goreng Crispy / Crispy Fried Chicken:

1. Tusuk - tusuk daging ayam dengan garpu supaya bumbu marinasi dapat meresap
1. Tambahkan lada bubuk + garam + Curry powder + chilli powder + kaldu bubuk non MSG, aduk rata. Simpan dalam lemari pendingin minimal 1 jam. Sisihkan
1. Campur terigu + maizena + lada bubuk ekstra + garam ekstra + baking soda + kaldu bubuk ekstra, aduk rata. Sisihkan
1. Campur air es + telur + 5 sdm campuran tepung, aduk rata. Sisihkan
1. Masukkan ayam dalam campuran terigu, ratakan tepung sambil sedikit ditekan
1. Celupkan dalam larutan air es, tiriskan
1. Masukkan ayam dalam campuran terigu, ratakan tepung sambil dicubit - cubit. Kibaskan
1. Goreng hingga matang 12 menit dalam minyak panas sedang yang volumenya merendam seluruh bagian ayam




Ternyata cara membuat ayam goreng crispy / crispy fried chicken yang enak tidak rumit ini enteng sekali ya! Kamu semua mampu memasaknya. Cara Membuat ayam goreng crispy / crispy fried chicken Cocok banget untuk kamu yang baru belajar memasak maupun bagi kalian yang telah lihai dalam memasak.

Tertarik untuk mencoba membikin resep ayam goreng crispy / crispy fried chicken nikmat tidak ribet ini? Kalau anda ingin, ayo kamu segera buruan menyiapkan alat dan bahan-bahannya, lalu bikin deh Resep ayam goreng crispy / crispy fried chicken yang lezat dan tidak ribet ini. Sangat mudah kan. 

Oleh karena itu, daripada anda diam saja, maka kita langsung saja sajikan resep ayam goreng crispy / crispy fried chicken ini. Dijamin kamu tiidak akan menyesal sudah buat resep ayam goreng crispy / crispy fried chicken mantab tidak rumit ini! Selamat berkreasi dengan resep ayam goreng crispy / crispy fried chicken nikmat tidak rumit ini di rumah kalian masing-masing,ya!.

