---
description: "Bahan-bahan Opor Ayam yang enak Untuk Jualan"
title: "Bahan-bahan Opor Ayam yang enak Untuk Jualan"
slug: 206-bahan-bahan-opor-ayam-yang-enak-untuk-jualan
date: 2021-04-27T05:42:01.497Z
image: https://img-global.cpcdn.com/recipes/496faf8753efd000/680x482cq70/opor-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/496faf8753efd000/680x482cq70/opor-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/496faf8753efd000/680x482cq70/opor-ayam-foto-resep-utama.jpg
author: Elizabeth George
ratingvalue: 3
reviewcount: 13
recipeingredient:
- "1 ekor ayam potong2 bisa ayam kampung atau negeri disini saya pake ayam negeri"
- "2 batang sereh digeprek"
- "3 lembar daun salam"
- "Sejempol lengkuas digeprek"
- "1300 ml santan encer 1 butir kelapa"
- "300 ml santan kental"
- "secukupnya Garam"
- "secukupnya Gula"
- " Penyedap rasa optional"
- " Bumbu yang dihaluskan"
- "10 siung bawang merah"
- "4 siung bawang putih"
- "2 butir kemiri sangrai"
- "1 sdm ketumbar sangrai"
- "3 cm jahe"
- "1/4 sdt jinten"
- "1 sdt lada  merica"
recipeinstructions:
- "Lumuri ayam dg jeruk nipis (agar hilang amisnya, kurleb 5 menit diamkan) lalu cuci bersih ayam."
- "Goreng sebentar ayam hingga kulit sedikit kecoklatan. Angkat dan sisihkan"
- "Tuang santan dalam wajan, masukkan bumbu halus, daun salam, sereh, lengkuas. Godog sekitar 10 menit sambil di aduk pelan2 agar santan tidak pecah."
- "Masukkan ayam. Beri garam, gula, penyedap rasa (optional). Biarkan mendidih. Lalu kecilkan api dan tiangs antal kental sambim diaduk pelan2."
- "Masak hingga ayam empuk, bumbu meresap dan kuah berminyak. Koreksi rasa. Sajikan."
categories:
- Resep
tags:
- opor
- ayam

katakunci: opor ayam 
nutrition: 203 calories
recipecuisine: Indonesian
preptime: "PT25M"
cooktime: "PT39M"
recipeyield: "2"
recipecategory: Lunch

---


![Opor Ayam](https://img-global.cpcdn.com/recipes/496faf8753efd000/680x482cq70/opor-ayam-foto-resep-utama.jpg)

Sebagai seorang wanita, menyajikan masakan nikmat untuk orang tercinta adalah hal yang memuaskan bagi kamu sendiri. Peran seorang  wanita bukan hanya mengerjakan pekerjaan rumah saja, tapi anda pun wajib memastikan keperluan gizi terpenuhi dan juga panganan yang dikonsumsi keluarga tercinta wajib sedap.

Di era  saat ini, kamu memang dapat memesan masakan instan walaupun tanpa harus ribet membuatnya terlebih dahulu. Tapi banyak juga lho orang yang memang ingin menyajikan yang terbaik untuk orang tercintanya. Pasalnya, menghidangkan masakan yang diolah sendiri jauh lebih higienis dan kita pun bisa menyesuaikan makanan tersebut sesuai dengan makanan kesukaan keluarga tercinta. 



Apakah anda salah satu penikmat opor ayam?. Tahukah kamu, opor ayam merupakan sajian khas di Indonesia yang sekarang disukai oleh kebanyakan orang dari berbagai wilayah di Indonesia. Kita dapat menyajikan opor ayam hasil sendiri di rumah dan boleh dijadikan hidangan kesukaanmu di hari liburmu.

Kalian tidak usah bingung untuk menyantap opor ayam, lantaran opor ayam sangat mudah untuk didapatkan dan kalian pun boleh mengolahnya sendiri di tempatmu. opor ayam bisa diolah lewat bermacam cara. Saat ini telah banyak cara kekinian yang menjadikan opor ayam semakin lebih mantap.

Resep opor ayam juga sangat mudah untuk dibikin, lho. Kita jangan ribet-ribet untuk memesan opor ayam, tetapi Kamu mampu menyiapkan di rumah sendiri. Untuk Kita yang ingin menyajikannya, inilah cara untuk membuat opor ayam yang lezat yang mampu Kamu coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Opor Ayam:

1. Gunakan 1 ekor ayam, potong2 (bisa ayam kampung atau negeri, disini saya pake ayam negeri)
1. Siapkan 2 batang sereh, digeprek
1. Ambil 3 lembar daun salam
1. Sediakan Sejempol lengkuas, digeprek
1. Ambil 1300 ml santan encer (1 butir kelapa)
1. Gunakan 300 ml santan kental
1. Ambil secukupnya Garam
1. Ambil secukupnya Gula
1. Siapkan  Penyedap rasa (optional)
1. Ambil  Bumbu yang dihaluskan
1. Siapkan 10 siung bawang merah
1. Ambil 4 siung bawang putih
1. Sediakan 2 butir kemiri, sangrai
1. Sediakan 1 sdm ketumbar, sangrai
1. Sediakan 3 cm jahe
1. Sediakan 1/4 sdt jinten
1. Sediakan 1 sdt lada / merica




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Opor Ayam:

1. Lumuri ayam dg jeruk nipis (agar hilang amisnya, kurleb 5 menit diamkan) lalu cuci bersih ayam.
1. Goreng sebentar ayam hingga kulit sedikit kecoklatan. Angkat dan sisihkan
1. Tuang santan dalam wajan, masukkan bumbu halus, daun salam, sereh, lengkuas. Godog sekitar 10 menit sambil di aduk pelan2 agar santan tidak pecah.
1. Masukkan ayam. Beri garam, gula, penyedap rasa (optional). Biarkan mendidih. Lalu kecilkan api dan tiangs antal kental sambim diaduk pelan2.
1. Masak hingga ayam empuk, bumbu meresap dan kuah berminyak. Koreksi rasa. Sajikan.




Wah ternyata cara buat opor ayam yang nikamt tidak rumit ini mudah sekali ya! Semua orang dapat mencobanya. Resep opor ayam Sesuai banget buat anda yang baru belajar memasak ataupun bagi kamu yang telah ahli dalam memasak.

Apakah kamu mau mencoba membuat resep opor ayam enak tidak rumit ini? Kalau tertarik, ayo kamu segera siapkan alat-alat dan bahannya, lalu bikin deh Resep opor ayam yang enak dan tidak ribet ini. Benar-benar taidak sulit kan. 

Oleh karena itu, ketimbang kamu berfikir lama-lama, hayo kita langsung saja bikin resep opor ayam ini. Dijamin kamu tak akan nyesel bikin resep opor ayam mantab tidak ribet ini! Selamat mencoba dengan resep opor ayam lezat sederhana ini di tempat tinggal kalian masing-masing,ya!.

