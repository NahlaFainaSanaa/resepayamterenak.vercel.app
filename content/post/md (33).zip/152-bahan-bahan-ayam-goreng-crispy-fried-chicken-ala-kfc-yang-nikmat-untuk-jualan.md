---
description: "Bahan-bahan Ayam Goreng Crispy (fried chicken ala KFC) yang nikmat Untuk Jualan"
title: "Bahan-bahan Ayam Goreng Crispy (fried chicken ala KFC) yang nikmat Untuk Jualan"
slug: 152-bahan-bahan-ayam-goreng-crispy-fried-chicken-ala-kfc-yang-nikmat-untuk-jualan
date: 2021-07-02T14:10:29.734Z
image: https://img-global.cpcdn.com/recipes/4c834e16a8e162a8/680x482cq70/ayam-goreng-crispy-fried-chicken-ala-kfc-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4c834e16a8e162a8/680x482cq70/ayam-goreng-crispy-fried-chicken-ala-kfc-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4c834e16a8e162a8/680x482cq70/ayam-goreng-crispy-fried-chicken-ala-kfc-foto-resep-utama.jpg
author: Roxie Nguyen
ratingvalue: 4.9
reviewcount: 4
recipeingredient:
- "5 paha atas ayam 12 kg ayam"
- "1/2 buah Jeruk nipis"
- " Bahan celup"
- "7 sdm plain flour tepung segitiga biru ya kalo di indo"
- "2 sdm corn flour maizena"
- " Air es"
- "5 siung bawang putih"
- "1/2 sdt merica bubuk"
- "1 sdm garam"
- "1/4 sdm gula"
- "1/2 cube maggi kaldu ayam bisa pake kaldu ayam lainnya"
- " Bahan kering"
- "7 sdm plain flour terigu serbaguna segitiga biru"
- "2 sdm corn flour maizena"
- "1/2 sdm garam"
- "1/2 sdt merica"
- "1/2 sdt bubuk cabe pedas"
- "1/2 sdt baking powder"
recipeinstructions:
- "Rendam ayam dengan jeruk nipis selama 10 menit/ sampai lemak2 keluar"
- "Cuci bersih dan rebus dengan air mendidih 15 menit (step ini bisa di skip, krna kompor disini tdk bs panas kecil jadi takutnya ketika di goreng ga mateng dalemnya jd saya rebus dulu)"
- "Haluskan : bawang putih, merica, garam dan kaldu ayam yg nanti akan digunakan untuk bahan pencelup"
- "Campurkan dengan maizena dan tepung terigu, tambahkan air es secukupnya"
- "Rendam ayam kedalam bahan pencelup dan masukkan ke kulkas sekitar 30 menit atau lebih"
- "Masukkan ayam dr pencelup ke bahan kering sambil di cubit2"
- "Goreng dalam minyak banyak dan panas"
- "Ayam goreng crispy siap disajikan!"
categories:
- Resep
tags:
- ayam
- goreng
- crispy

katakunci: ayam goreng crispy 
nutrition: 130 calories
recipecuisine: Indonesian
preptime: "PT30M"
cooktime: "PT38M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam Goreng Crispy (fried chicken ala KFC)](https://img-global.cpcdn.com/recipes/4c834e16a8e162a8/680x482cq70/ayam-goreng-crispy-fried-chicken-ala-kfc-foto-resep-utama.jpg)

Jika kita seorang istri, menyediakan panganan sedap kepada keluarga merupakan suatu hal yang menyenangkan bagi kita sendiri. Tugas seorang istri bukan hanya mengatur rumah saja, tetapi anda pun harus menyediakan keperluan gizi tercukupi dan juga olahan yang dimakan anak-anak harus lezat.

Di waktu  saat ini, anda sebenarnya dapat memesan hidangan praktis meski tidak harus repot memasaknya dulu. Tetapi banyak juga orang yang memang mau menghidangkan yang terbaik untuk keluarganya. Sebab, memasak yang diolah sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan sesuai makanan kesukaan keluarga tercinta. 



Mungkinkah anda adalah salah satu penikmat ayam goreng crispy (fried chicken ala kfc)?. Asal kamu tahu, ayam goreng crispy (fried chicken ala kfc) adalah sajian khas di Indonesia yang sekarang disenangi oleh orang-orang di hampir setiap tempat di Nusantara. Kalian bisa menghidangkan ayam goreng crispy (fried chicken ala kfc) sendiri di rumahmu dan pasti jadi camilan favoritmu di akhir pekan.

Kalian tak perlu bingung untuk mendapatkan ayam goreng crispy (fried chicken ala kfc), karena ayam goreng crispy (fried chicken ala kfc) mudah untuk ditemukan dan kamu pun dapat membuatnya sendiri di rumah. ayam goreng crispy (fried chicken ala kfc) boleh diolah lewat bermacam cara. Kini sudah banyak resep kekinian yang menjadikan ayam goreng crispy (fried chicken ala kfc) lebih enak.

Resep ayam goreng crispy (fried chicken ala kfc) pun mudah sekali dihidangkan, lho. Anda jangan repot-repot untuk memesan ayam goreng crispy (fried chicken ala kfc), tetapi Kalian bisa menghidangkan ditempatmu. Untuk Kalian yang hendak menghidangkannya, berikut cara untuk menyajikan ayam goreng crispy (fried chicken ala kfc) yang lezat yang bisa Kamu coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Ayam Goreng Crispy (fried chicken ala KFC):

1. Sediakan 5 paha atas ayam (1/2 kg ayam)
1. Sediakan 1/2 buah Jeruk nipis
1. Gunakan  Bahan celup
1. Siapkan 7 sdm plain flour (tepung segitiga biru ya kalo di indo)
1. Sediakan 2 sdm corn flour (maizena)
1. Gunakan  Air es
1. Siapkan 5 siung bawang putih
1. Sediakan 1/2 sdt merica bubuk
1. Gunakan 1 sdm garam
1. Ambil 1/4 sdm gula
1. Ambil 1/2 cube maggi kaldu ayam (bisa pake kaldu ayam lainnya)
1. Sediakan  Bahan kering
1. Gunakan 7 sdm plain flour (terigu serbaguna/ segitiga biru)
1. Ambil 2 sdm corn flour (maizena)
1. Siapkan 1/2 sdm garam
1. Siapkan 1/2 sdt merica
1. Ambil 1/2 sdt bubuk cabe pedas
1. Sediakan 1/2 sdt baking powder




<!--inarticleads2-->

##### Cara membuat Ayam Goreng Crispy (fried chicken ala KFC):

1. Rendam ayam dengan jeruk nipis selama 10 menit/ sampai lemak2 keluar
1. Cuci bersih dan rebus dengan air mendidih 15 menit (step ini bisa di skip, krna kompor disini tdk bs panas kecil jadi takutnya ketika di goreng ga mateng dalemnya jd saya rebus dulu)
1. Haluskan : bawang putih, merica, garam dan kaldu ayam yg nanti akan digunakan untuk bahan pencelup
1. Campurkan dengan maizena dan tepung terigu, tambahkan air es secukupnya
1. Rendam ayam kedalam bahan pencelup dan masukkan ke kulkas sekitar 30 menit atau lebih
1. Masukkan ayam dr pencelup ke bahan kering sambil di cubit2
1. Goreng dalam minyak banyak dan panas
1. Ayam goreng crispy siap disajikan!




Ternyata cara buat ayam goreng crispy (fried chicken ala kfc) yang mantab simple ini gampang banget ya! Kita semua bisa membuatnya. Cara Membuat ayam goreng crispy (fried chicken ala kfc) Sangat sesuai sekali untuk kamu yang baru belajar memasak atau juga bagi kamu yang telah lihai memasak.

Apakah kamu tertarik mencoba membuat resep ayam goreng crispy (fried chicken ala kfc) enak tidak rumit ini? Kalau ingin, mending kamu segera menyiapkan alat-alat dan bahannya, maka bikin deh Resep ayam goreng crispy (fried chicken ala kfc) yang enak dan tidak ribet ini. Benar-benar taidak sulit kan. 

Maka, daripada kamu berlama-lama, yuk kita langsung saja bikin resep ayam goreng crispy (fried chicken ala kfc) ini. Dijamin anda gak akan menyesal sudah bikin resep ayam goreng crispy (fried chicken ala kfc) enak tidak rumit ini! Selamat mencoba dengan resep ayam goreng crispy (fried chicken ala kfc) lezat tidak ribet ini di rumah kalian sendiri,oke!.

