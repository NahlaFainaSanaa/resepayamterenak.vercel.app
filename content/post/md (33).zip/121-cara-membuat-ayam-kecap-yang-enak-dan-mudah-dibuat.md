---
description: "Cara membuat Ayam Kecap yang enak dan Mudah Dibuat"
title: "Cara membuat Ayam Kecap yang enak dan Mudah Dibuat"
slug: 121-cara-membuat-ayam-kecap-yang-enak-dan-mudah-dibuat
date: 2021-03-27T15:57:37.362Z
image: https://img-global.cpcdn.com/recipes/57e557a88a489d85/680x482cq70/ayam-kecap-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/57e557a88a489d85/680x482cq70/ayam-kecap-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/57e557a88a489d85/680x482cq70/ayam-kecap-foto-resep-utama.jpg
author: Leila Salazar
ratingvalue: 3.3
reviewcount: 6
recipeingredient:
- "1 ekor ayam kampung kecil potong 4 bagian"
- "3 siung bawang putih"
- "1 siung bawang bombay kecil"
- "1 ruas jahe geprek"
- "3 batang daun bawang"
- "1 sdm saua tiram"
- "1/2 sdt saus rajarasa"
- "1/2 sdt minyak wijen"
- "1/2 sdt kecap inggris"
- "3 sdm kecap manis"
- "1/2 sdt kecap asin"
- "Secukupnya lada"
- "Secukupnya garam"
- "Secukupnya kaldu jamur"
- "1 buah jeruk nipis untuk mencuci ayam"
- "Secukupnya margarine"
- "Secukupnya minyak goreng"
- "100 ml air"
recipeinstructions:
- "Cuci bersih ayam lalu beri perasan jeruk nipis dan bilas"
- "Presto ayam ± 10 menit, setelah itu angkat."
- "Masukkan 2 sdm margarine dan 10 sdm minyak goreng, goreng ayam sebentar, lalu angkat dan sisihkan."
- "Panaskan 3 sdm margarine tumis bawang putih dan jahe hingga harum"
- "Tambahkan 100ml air lalu masukkan saus tiram, kecap inggris, kecap asin, saus rajarasa, minyak wijen, kecap manis, lada, garam, kaldu jamur lalh aduk rata."
- "Tunggu hingga air mendidih lalu masukkan ayam dan aduk rata, tambahkan bawang bombay dan daun bawang aduk dan cicipi rasa, jika sudah pas angkat dan sajikan"
categories:
- Resep
tags:
- ayam
- kecap

katakunci: ayam kecap 
nutrition: 245 calories
recipecuisine: Indonesian
preptime: "PT29M"
cooktime: "PT42M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam Kecap](https://img-global.cpcdn.com/recipes/57e557a88a489d85/680x482cq70/ayam-kecap-foto-resep-utama.jpg)

Selaku seorang yang hobi memasak, menyediakan hidangan lezat kepada keluarga tercinta merupakan suatu hal yang memuaskan untuk kita sendiri. Tanggung jawab seorang  wanita bukan hanya menjaga rumah saja, tetapi kamu pun wajib menyediakan keperluan nutrisi terpenuhi dan santapan yang disantap orang tercinta mesti lezat.

Di waktu  saat ini, kamu memang dapat memesan santapan yang sudah jadi walaupun tanpa harus capek membuatnya dahulu. Tetapi banyak juga orang yang selalu ingin memberikan makanan yang terenak bagi orang yang dicintainya. Pasalnya, memasak sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan sesuai dengan kesukaan keluarga. 



Apakah anda merupakan salah satu penikmat ayam kecap?. Asal kamu tahu, ayam kecap adalah sajian khas di Nusantara yang sekarang disenangi oleh orang-orang di berbagai daerah di Nusantara. Kalian dapat menghidangkan ayam kecap sendiri di rumah dan dapat dijadikan hidangan favorit di akhir pekanmu.

Anda tidak perlu bingung jika kamu ingin menyantap ayam kecap, karena ayam kecap mudah untuk dicari dan juga kalian pun boleh menghidangkannya sendiri di tempatmu. ayam kecap bisa dimasak dengan berbagai cara. Kini pun sudah banyak cara modern yang membuat ayam kecap semakin lebih enak.

Resep ayam kecap pun mudah sekali untuk dibikin, lho. Kalian jangan capek-capek untuk membeli ayam kecap, sebab Kalian dapat membuatnya di rumah sendiri. Bagi Kita yang mau mencobanya, inilah resep untuk menyajikan ayam kecap yang enak yang bisa Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Ayam Kecap:

1. Sediakan 1 ekor ayam kampung kecil (potong 4 bagian)
1. Gunakan 3 siung bawang putih
1. Gunakan 1 siung bawang bombay kecil
1. Sediakan 1 ruas jahe (geprek)
1. Sediakan 3 batang daun bawang
1. Ambil 1 sdm saua tiram
1. Ambil 1/2 sdt saus rajarasa
1. Sediakan 1/2 sdt minyak wijen
1. Siapkan 1/2 sdt kecap inggris
1. Sediakan 3 sdm kecap manis
1. Gunakan 1/2 sdt kecap asin
1. Siapkan Secukupnya lada
1. Sediakan Secukupnya garam
1. Ambil Secukupnya kaldu jamur
1. Ambil 1 buah jeruk nipis (untuk mencuci ayam)
1. Ambil Secukupnya margarine
1. Siapkan Secukupnya minyak goreng
1. Ambil 100 ml air




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Kecap:

1. Cuci bersih ayam lalu beri perasan jeruk nipis dan bilas
1. Presto ayam ± 10 menit, setelah itu angkat.
1. Masukkan 2 sdm margarine dan 10 sdm minyak goreng, goreng ayam sebentar, lalu angkat dan sisihkan.
1. Panaskan 3 sdm margarine tumis bawang putih dan jahe hingga harum
1. Tambahkan 100ml air lalu masukkan saus tiram, kecap inggris, kecap asin, saus rajarasa, minyak wijen, kecap manis, lada, garam, kaldu jamur lalh aduk rata.
1. Tunggu hingga air mendidih lalu masukkan ayam dan aduk rata, tambahkan bawang bombay dan daun bawang aduk dan cicipi rasa, jika sudah pas angkat dan sajikan




Ternyata cara buat ayam kecap yang mantab simple ini gampang sekali ya! Kita semua bisa menghidangkannya. Resep ayam kecap Cocok sekali buat kalian yang baru mau belajar memasak ataupun juga untuk kalian yang sudah ahli memasak.

Apakah kamu mau mulai mencoba buat resep ayam kecap nikmat tidak rumit ini? Kalau kalian tertarik, yuk kita segera menyiapkan alat dan bahannya, maka buat deh Resep ayam kecap yang lezat dan sederhana ini. Sungguh gampang kan. 

Maka dari itu, daripada anda diam saja, maka kita langsung saja bikin resep ayam kecap ini. Dijamin anda gak akan menyesal membuat resep ayam kecap nikmat tidak ribet ini! Selamat mencoba dengan resep ayam kecap mantab tidak rumit ini di tempat tinggal kalian sendiri,oke!.

