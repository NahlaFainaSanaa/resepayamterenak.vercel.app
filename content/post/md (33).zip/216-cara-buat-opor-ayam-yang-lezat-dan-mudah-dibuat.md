---
description: "Cara buat Opor Ayam yang lezat dan Mudah Dibuat"
title: "Cara buat Opor Ayam yang lezat dan Mudah Dibuat"
slug: 216-cara-buat-opor-ayam-yang-lezat-dan-mudah-dibuat
date: 2021-05-08T13:59:03.335Z
image: https://img-global.cpcdn.com/recipes/527f44033ed1c854/680x482cq70/opor-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/527f44033ed1c854/680x482cq70/opor-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/527f44033ed1c854/680x482cq70/opor-ayam-foto-resep-utama.jpg
author: Raymond Pittman
ratingvalue: 4.2
reviewcount: 14
recipeingredient:
- " Bahan"
- "1 ekor ayam kampung potong sesuai selera"
- "1 liter santan  2 bks santan instan ukuran 65 gr"
- "secukupnya Garam gula kaldu bubuk"
- " Minyak untuk menumis"
- "secukupnya Air"
- " Bahan dihaluskan"
- "8 siung bawang merah"
- "5 siung bawang putih"
- "4 butir kemiri"
- "1/2 sdm ketumbar"
- "1/2 sdr lada bubuk"
- "1 ruas kunyit"
- "1 ruas jahe"
- " Pelengkap"
- "3 lembar daun salam"
- "3 lembar daun jeruk"
- "2 batang serai dipeprek"
- "2 ruas lengkuas dipeprek"
- " Bawang goreng"
recipeinstructions:
- "Cuci bersih ayam yang sudah dipotong (boleh diberi perasan air jeruk nipis supaya tidak terlalu bau amis)"
- "Tumis bumbu yang sudah dihaluskan sampai harum. Tambahkan bumbu pelengkap. Aduk rata. Tambahkan air."
- "Masukkan ayam. Tambahkan garam, gula dan kaldu bubuk. Aduk rata. Masak sampai ayam agak empuk."
- "Masukkan santan. Aduk rata. Tunggu sampai ayam matang. Koreksi rasa."
- "Sajikan dengan bawang goreng"
categories:
- Resep
tags:
- opor
- ayam

katakunci: opor ayam 
nutrition: 264 calories
recipecuisine: Indonesian
preptime: "PT24M"
cooktime: "PT48M"
recipeyield: "3"
recipecategory: Dinner

---


![Opor Ayam](https://img-global.cpcdn.com/recipes/527f44033ed1c854/680x482cq70/opor-ayam-foto-resep-utama.jpg)

Sebagai seorang orang tua, menyediakan hidangan enak buat orang tercinta merupakan suatu hal yang memuaskan untuk kita sendiri. Tanggung jawab seorang istri bukan sekadar mengatur rumah saja, tetapi kamu pun wajib memastikan kebutuhan gizi tercukupi dan juga panganan yang dimakan anak-anak mesti mantab.

Di era  sekarang, kamu memang mampu membeli olahan instan meski tidak harus susah membuatnya lebih dulu. Namun banyak juga lho mereka yang memang mau memberikan makanan yang terlezat bagi keluarganya. Lantaran, menyajikan masakan sendiri akan jauh lebih higienis dan bisa menyesuaikan berdasarkan makanan kesukaan orang tercinta. 



Apakah anda salah satu penikmat opor ayam?. Asal kamu tahu, opor ayam merupakan hidangan khas di Indonesia yang kini disenangi oleh orang-orang dari berbagai tempat di Nusantara. Kamu bisa memasak opor ayam sendiri di rumah dan pasti jadi camilan kesukaanmu di hari liburmu.

Kita tak perlu bingung untuk menyantap opor ayam, karena opor ayam gampang untuk dicari dan anda pun dapat mengolahnya sendiri di rumah. opor ayam boleh dimasak memalui bermacam cara. Sekarang sudah banyak sekali cara kekinian yang membuat opor ayam semakin nikmat.

Resep opor ayam pun gampang untuk dibuat, lho. Kamu jangan capek-capek untuk memesan opor ayam, karena Kamu bisa menyiapkan ditempatmu. Untuk Kita yang akan mencobanya, berikut ini cara untuk menyajikan opor ayam yang enak yang dapat Kamu coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Opor Ayam:

1. Siapkan  Bahan:
1. Gunakan 1 ekor ayam kampung, potong sesuai selera
1. Gunakan 1 liter santan / 2 bks santan instan ukuran 65 gr
1. Sediakan secukupnya Garam, gula, kaldu bubuk
1. Gunakan  Minyak untuk menumis
1. Gunakan secukupnya Air
1. Sediakan  Bahan dihaluskan:
1. Sediakan 8 siung bawang merah
1. Ambil 5 siung bawang putih
1. Sediakan 4 butir kemiri
1. Gunakan 1/2 sdm ketumbar
1. Sediakan 1/2 sdr lada bubuk
1. Gunakan 1 ruas kunyit
1. Ambil 1 ruas jahe
1. Ambil  Pelengkap:
1. Gunakan 3 lembar daun salam
1. Sediakan 3 lembar daun jeruk
1. Gunakan 2 batang serai, dipeprek
1. Gunakan 2 ruas lengkuas, dipeprek
1. Ambil  Bawang goreng




<!--inarticleads2-->

##### Cara menyiapkan Opor Ayam:

1. Cuci bersih ayam yang sudah dipotong (boleh diberi perasan air jeruk nipis supaya tidak terlalu bau amis)
1. Tumis bumbu yang sudah dihaluskan sampai harum. Tambahkan bumbu pelengkap. Aduk rata. Tambahkan air.
1. Masukkan ayam. Tambahkan garam, gula dan kaldu bubuk. Aduk rata. Masak sampai ayam agak empuk.
1. Masukkan santan. Aduk rata. Tunggu sampai ayam matang. Koreksi rasa.
1. Sajikan dengan bawang goreng




Ternyata cara membuat opor ayam yang nikamt sederhana ini gampang banget ya! Kalian semua bisa mencobanya. Resep opor ayam Sangat cocok sekali buat anda yang baru belajar memasak ataupun juga untuk kamu yang sudah hebat memasak.

Tertarik untuk mulai mencoba membuat resep opor ayam mantab sederhana ini? Kalau kalian mau, ayo kalian segera buruan menyiapkan peralatan dan bahan-bahannya, kemudian buat deh Resep opor ayam yang nikmat dan sederhana ini. Benar-benar gampang kan. 

Maka, ketimbang kalian diam saja, yuk kita langsung saja bikin resep opor ayam ini. Dijamin kalian tiidak akan menyesal sudah bikin resep opor ayam nikmat tidak rumit ini! Selamat berkreasi dengan resep opor ayam enak tidak rumit ini di tempat tinggal masing-masing,oke!.

