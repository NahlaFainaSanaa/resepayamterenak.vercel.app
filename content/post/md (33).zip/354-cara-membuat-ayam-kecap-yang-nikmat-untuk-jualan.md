---
description: "Cara membuat Ayam kecap yang nikmat Untuk Jualan"
title: "Cara membuat Ayam kecap yang nikmat Untuk Jualan"
slug: 354-cara-membuat-ayam-kecap-yang-nikmat-untuk-jualan
date: 2021-02-20T12:34:11.142Z
image: https://img-global.cpcdn.com/recipes/25178e463c05eff3/680x482cq70/ayam-kecap-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/25178e463c05eff3/680x482cq70/ayam-kecap-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/25178e463c05eff3/680x482cq70/ayam-kecap-foto-resep-utama.jpg
author: Justin Harrington
ratingvalue: 4.4
reviewcount: 11
recipeingredient:
- "1/2 kg ayam potong 6"
- "4 siung Bawang merah"
- "2 siung Bawang putih"
- "1 buah Bawang bombai kecil"
- "3 buah biji cengkeh"
- "3-5 buah kapolaga"
- "1 potong kecil kayu manis"
- "2 lembar daun salam"
- "1/2 sdt garam"
- "1/2 sdt penyedap rasasaya pakai masako"
- "10 SDM Kecap manis"
- "100 ml air"
- "5 SDM minyak goreng utk menumis"
recipeinstructions:
- "Cuci bersih ayam, tiriskan Bubuhi garam dan jeruk nipis bila ada dan suka (saya skip)"
- "Goreng ayam setengah matang"
- "Iris bawang merah dan putih, kemudian tumis hingga harum, masukkan cengkeh, kapolaga, kayu manis dan daun salam"
- "Masukkan ayam, kecap kemudian aduk rata sampai wangi kecap"
- "Tambahkan air putih, masukkan irisan bawang bombai, kecilkan api, tambahkan garam dan penyedap kemudian biarkan bumbu"
- "Matikan api, koreksi rasa dan ayam kecap siap dihidangkan"
categories:
- Resep
tags:
- ayam
- kecap

katakunci: ayam kecap 
nutrition: 124 calories
recipecuisine: Indonesian
preptime: "PT26M"
cooktime: "PT54M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam kecap](https://img-global.cpcdn.com/recipes/25178e463c05eff3/680x482cq70/ayam-kecap-foto-resep-utama.jpg)

Jika kalian seorang orang tua, mempersiapkan hidangan enak untuk famili merupakan hal yang menyenangkan untuk anda sendiri. Peran seorang ibu bukan hanya menangani rumah saja, tapi anda pun wajib menyediakan keperluan gizi tercukupi dan panganan yang dimakan keluarga tercinta wajib nikmat.

Di zaman  sekarang, kamu memang mampu memesan santapan siap saji meski tanpa harus capek membuatnya lebih dulu. Tapi banyak juga lho orang yang memang ingin menghidangkan yang terlezat bagi keluarganya. Lantaran, menghidangkan masakan yang diolah sendiri jauh lebih bersih dan bisa menyesuaikan hidangan tersebut sesuai dengan kesukaan keluarga. 

Menu ayam kecap jadi andalan kesukaan keluarga Indonesia. Resep Ayam Kecap - Sekarang ini ayam dapat diolah menjadi berbagai makanan yang lezat. Dari mulai digoreng, dipanggang, dan sebagainya.

Apakah anda adalah seorang penggemar ayam kecap?. Asal kamu tahu, ayam kecap adalah hidangan khas di Nusantara yang saat ini disenangi oleh banyak orang di hampir setiap wilayah di Indonesia. Kamu bisa menghidangkan ayam kecap sendiri di rumah dan dapat dijadikan camilan kesukaanmu di akhir pekanmu.

Kalian tak perlu bingung jika kamu ingin mendapatkan ayam kecap, karena ayam kecap gampang untuk didapatkan dan kita pun bisa memasaknya sendiri di tempatmu. ayam kecap dapat dimasak dengan berbagai cara. Kini telah banyak banget cara modern yang membuat ayam kecap semakin mantap.

Resep ayam kecap pun gampang sekali dibikin, lho. Kita tidak usah capek-capek untuk membeli ayam kecap, lantaran Anda dapat menghidangkan ditempatmu. Bagi Kalian yang hendak menyajikannya, berikut ini resep membuat ayam kecap yang lezat yang bisa Kamu coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Ayam kecap:

1. Gunakan 1/2 kg ayam potong 6
1. Ambil 4 siung Bawang merah
1. Sediakan 2 siung Bawang putih
1. Ambil 1 buah Bawang bombai kecil
1. Gunakan 3 buah biji cengkeh
1. Gunakan 3-5 buah kapolaga
1. Ambil 1 potong kecil kayu manis
1. Sediakan 2 lembar daun salam
1. Ambil 1/2 sdt garam
1. Siapkan 1/2 sdt penyedap rasa(saya pakai masako)
1. Sediakan 10 SDM Kecap manis
1. Gunakan 100 ml air
1. Gunakan 5 SDM minyak goreng utk menumis


Daripada beli diluaran terus, Anda bisa membuatnya sendiri dirumah. Jadikan resep ayam kecap spesial ini sebagai solusi cepat dan lezat untuk segala suasana. Resep ayam kecap spesial ini istimewa karena menggunakan mentega atau margarin untuk menumis. Resep ayam kecap yang dimasak pakai bawang bombay ini dapat dipraktikkan di rumah. 

<!--inarticleads2-->

##### Langkah-langkah membuat Ayam kecap:

1. Cuci bersih ayam, tiriskan - Bubuhi garam dan jeruk nipis bila ada dan suka (saya skip)
1. Goreng ayam setengah matang
1. Iris bawang merah dan putih, kemudian tumis hingga harum, masukkan cengkeh, kapolaga, kayu manis dan daun salam
1. Masukkan ayam, kecap kemudian aduk rata sampai wangi kecap
1. Tambahkan air putih, masukkan irisan bawang bombai, kecilkan api, tambahkan garam dan penyedap kemudian biarkan bumbu
1. Matikan api, koreksi rasa dan ayam kecap siap dihidangkan


KOMPAS.com - Ayam kecap manis termasuk masakan yang gampang dibuat di rumah. Resep ayam kecap seperti apa yang jadi favoritmu? Menu olahan ayam sering kali jadi alternatif masakan yang mudah dan bergizi di rumah. Cara masak ayam kecap kuah: Goreng ayam hingga setengah matang, kemudian tiriskan minyaknya. Tumis bawang merah dan bawang putih yang sudah diiris halus, jahe yang sudah dimemarkan, dan. 

Wah ternyata cara buat ayam kecap yang lezat tidak rumit ini enteng banget ya! Semua orang dapat memasaknya. Resep ayam kecap Sangat cocok banget buat kalian yang sedang belajar memasak maupun untuk anda yang telah ahli memasak.

Apakah kamu ingin mulai mencoba membikin resep ayam kecap mantab tidak rumit ini? Kalau kamu mau, ayo kamu segera buruan siapin alat-alat dan bahannya, lantas buat deh Resep ayam kecap yang mantab dan tidak rumit ini. Sangat gampang kan. 

Maka dari itu, daripada anda berfikir lama-lama, ayo kita langsung bikin resep ayam kecap ini. Pasti kamu tak akan nyesel sudah buat resep ayam kecap mantab sederhana ini! Selamat mencoba dengan resep ayam kecap enak tidak rumit ini di rumah masing-masing,oke!.

