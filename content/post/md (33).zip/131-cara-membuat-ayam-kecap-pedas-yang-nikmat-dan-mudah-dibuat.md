---
description: "Cara membuat Ayam kecap pedas yang nikmat dan Mudah Dibuat"
title: "Cara membuat Ayam kecap pedas yang nikmat dan Mudah Dibuat"
slug: 131-cara-membuat-ayam-kecap-pedas-yang-nikmat-dan-mudah-dibuat
date: 2021-02-05T20:20:35.411Z
image: https://img-global.cpcdn.com/recipes/bcbd048f2e235e96/680x482cq70/ayam-kecap-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/bcbd048f2e235e96/680x482cq70/ayam-kecap-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/bcbd048f2e235e96/680x482cq70/ayam-kecap-pedas-foto-resep-utama.jpg
author: Lulu Roy
ratingvalue: 4.1
reviewcount: 9
recipeingredient:
- "1/2 kg ayam"
- "200 ml air putih"
- "5 lembar daun salam"
- "1 ruas jari lengkuas geprek"
- "1 ruas jari jahe geprek"
- "1 batang sereh geprek"
- "Secukupnya kecap manis"
- "6 siung bawang putih"
- "3 siung bawang merah"
- "Sedikit kunyit"
- "2 buah cabe merah keriting"
- "5 buah cabe rawit klo ga suka pedas bisa di kurangi"
- " Gula"
- " Garam"
- " Penyedap sya pke masako ayam"
- "Secukupnya minyak"
recipeinstructions:
- "Rebus ayam selama 15 menit dengan 3 bawang putih (geprek) + 3 lembar daun salam, sisihkan"
- "Ulek bawang putih + bawang merah + kunyit + cabe merah kriting dan cabe rawit, lalu tumis smpe harum"
- "Msukan daun salam + jahe + lengkuas + sereh tumis lagi"
- "Masukan ayam yg sudah di rebus tadi dan lanjut tumis"
- "Masukan garam + gula + penyedap, lanjut tumis (takaran bisa di sesuaikan)"
- "Tambahkan air putih, setelah air mendidih masukan kecap (sesuai selera)"
- "Cek rasa, klo udh pas aduk sekali2 smpe air kecap menyusut dan meresap ke ayam"
- "Angkat dan siap di hidangkan"
categories:
- Resep
tags:
- ayam
- kecap
- pedas

katakunci: ayam kecap pedas 
nutrition: 100 calories
recipecuisine: Indonesian
preptime: "PT32M"
cooktime: "PT34M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam kecap pedas](https://img-global.cpcdn.com/recipes/bcbd048f2e235e96/680x482cq70/ayam-kecap-pedas-foto-resep-utama.jpg)

Sebagai seorang ibu, menyediakan santapan nikmat buat famili adalah suatu hal yang menyenangkan untuk kamu sendiri. Tanggung jawab seorang ibu bukan cuman mengatur rumah saja, namun kamu pun wajib menyediakan keperluan nutrisi tercukupi dan santapan yang dikonsumsi anak-anak mesti nikmat.

Di era  sekarang, kamu sebenarnya dapat membeli panganan praktis tanpa harus repot memasaknya dahulu. Tapi ada juga orang yang memang mau memberikan yang terbaik untuk keluarganya. Karena, menghidangkan masakan yang diolah sendiri jauh lebih bersih dan kita pun bisa menyesuaikan hidangan tersebut sesuai masakan kesukaan famili. 



Mungkinkah anda merupakan seorang penggemar ayam kecap pedas?. Asal kamu tahu, ayam kecap pedas merupakan hidangan khas di Nusantara yang saat ini digemari oleh banyak orang dari berbagai daerah di Nusantara. Kita bisa menghidangkan ayam kecap pedas sendiri di rumahmu dan pasti jadi camilan favorit di akhir pekanmu.

Kita tidak usah bingung jika kamu ingin menyantap ayam kecap pedas, lantaran ayam kecap pedas tidak sukar untuk didapatkan dan kamu pun boleh menghidangkannya sendiri di tempatmu. ayam kecap pedas dapat dibuat lewat bermacam cara. Saat ini ada banyak sekali cara modern yang membuat ayam kecap pedas semakin enak.

Resep ayam kecap pedas juga mudah untuk dibuat, lho. Kamu jangan ribet-ribet untuk membeli ayam kecap pedas, karena Anda dapat menyajikan di rumahmu. Untuk Kalian yang ingin menyajikannya, berikut resep membuat ayam kecap pedas yang nikamat yang mampu Kamu buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Ayam kecap pedas:

1. Ambil 1/2 kg ayam
1. Siapkan 200 ml air putih
1. Gunakan 5 lembar daun salam
1. Gunakan 1 ruas jari lengkuas (geprek)
1. Gunakan 1 ruas jari jahe (geprek)
1. Siapkan 1 batang sereh (geprek)
1. Gunakan Secukupnya kecap manis
1. Siapkan 6 siung bawang putih
1. Sediakan 3 siung bawang merah
1. Sediakan Sedikit kunyit
1. Sediakan 2 buah cabe merah keriting
1. Ambil 5 buah cabe rawit (klo ga suka pedas bisa di kurangi)
1. Gunakan  Gula
1. Siapkan  Garam
1. Ambil  Penyedap (sya pke masako ayam)
1. Ambil Secukupnya minyak




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam kecap pedas:

1. Rebus ayam selama 15 menit dengan 3 bawang putih (geprek) + 3 lembar daun salam, sisihkan
1. Ulek bawang putih + bawang merah + kunyit + cabe merah kriting dan cabe rawit, lalu tumis smpe harum
1. Msukan daun salam + jahe + lengkuas + sereh tumis lagi
1. Masukan ayam yg sudah di rebus tadi dan lanjut tumis
1. Masukan garam + gula + penyedap, lanjut tumis (takaran bisa di sesuaikan)
1. Tambahkan air putih, setelah air mendidih masukan kecap (sesuai selera)
1. Cek rasa, klo udh pas aduk sekali2 smpe air kecap menyusut dan meresap ke ayam
1. Angkat dan siap di hidangkan




Ternyata resep ayam kecap pedas yang mantab tidak ribet ini mudah banget ya! Kamu semua mampu menghidangkannya. Cara Membuat ayam kecap pedas Sangat sesuai sekali buat kita yang baru mau belajar memasak ataupun juga untuk kalian yang telah pandai memasak.

Tertarik untuk mencoba bikin resep ayam kecap pedas mantab tidak rumit ini? Kalau anda mau, ayo kamu segera buruan menyiapkan alat dan bahan-bahannya, setelah itu bikin deh Resep ayam kecap pedas yang mantab dan tidak ribet ini. Sangat taidak sulit kan. 

Oleh karena itu, ketimbang kamu diam saja, yuk langsung aja bikin resep ayam kecap pedas ini. Dijamin anda tak akan menyesal bikin resep ayam kecap pedas enak simple ini! Selamat mencoba dengan resep ayam kecap pedas mantab tidak rumit ini di tempat tinggal sendiri,ya!.

