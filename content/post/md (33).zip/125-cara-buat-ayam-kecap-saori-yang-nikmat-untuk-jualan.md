---
description: "Cara buat Ayam Kecap Saori yang nikmat Untuk Jualan"
title: "Cara buat Ayam Kecap Saori yang nikmat Untuk Jualan"
slug: 125-cara-buat-ayam-kecap-saori-yang-nikmat-untuk-jualan
date: 2021-04-25T19:29:56.504Z
image: https://img-global.cpcdn.com/recipes/6d1e28b241350a0c/680x482cq70/ayam-kecap-saori-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6d1e28b241350a0c/680x482cq70/ayam-kecap-saori-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6d1e28b241350a0c/680x482cq70/ayam-kecap-saori-foto-resep-utama.jpg
author: Ray Banks
ratingvalue: 3
reviewcount: 7
recipeingredient:
- "5-6 potong ayam ukuran sedang"
- " Bumbu ungkep "
- "2 sdt kunyit bubuk"
- "2,5 sdt ketumbar bubuk"
- "1 sdt merica bubuk"
- "1/2 sdt garam"
- "1 sdt kaldu jamur"
- "1 sdt saori saos tiram"
- "1 batang sereh sayat2 menjadi 3 bagian"
- "secukupnya Air"
- " Bahan saos kecap"
- "2 sdm kecap manis"
- "1 sdt saori"
- "1 bawang merah ukuran besar kl sedang 2 bwng merah iris halus"
- "1 bawang putih iris halus"
- "3 buah cabe keriting iris serong"
- "1/2 buah tomat"
- " Minyak secukupnya utk menggoreng"
recipeinstructions:
- "Bersihkan ayam, lalu masukkan ke kuali, kemudian campur dengan secukupnya air dan seluruh bumbu ungkep. Ungkep (rebus) hingga air susut."
- "Goreng ayam ungkep di api sedang, tingkat kekeringan saat menggoreng sedang. Angkat tiriskan."
- "Tumis bawang merah dan putih hingga wangi. Masukkan irisan cabe, aduk lagi, masukkan kecap manis+saori. Masukkan tomat. Aduk sebentar. Tes rasa saos, jika kurang pas bisa ditambahkan sedikit garam (saya tdk pakai). Masukkan ayam yg telah digoreng td, aduk rata. Ayam kecap saori siap disajikan. 😍"
categories:
- Resep
tags:
- ayam
- kecap
- saori

katakunci: ayam kecap saori 
nutrition: 271 calories
recipecuisine: Indonesian
preptime: "PT28M"
cooktime: "PT53M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Kecap Saori](https://img-global.cpcdn.com/recipes/6d1e28b241350a0c/680x482cq70/ayam-kecap-saori-foto-resep-utama.jpg)

Selaku seorang ibu, menyediakan olahan lezat bagi orang tercinta adalah suatu hal yang menyenangkan bagi kamu sendiri. Tugas seorang ibu Tidak sekadar menangani rumah saja, namun kamu pun harus memastikan kebutuhan gizi terpenuhi dan panganan yang dimakan anak-anak harus sedap.

Di masa  saat ini, anda memang dapat membeli olahan siap saji tidak harus ribet membuatnya dahulu. Tapi ada juga mereka yang selalu ingin menghidangkan yang terlezat untuk keluarganya. Karena, menyajikan masakan yang dibuat sendiri akan jauh lebih higienis dan bisa menyesuaikan masakan tersebut berdasarkan masakan kesukaan keluarga. 



Apakah anda salah satu penyuka ayam kecap saori?. Asal kamu tahu, ayam kecap saori merupakan sajian khas di Nusantara yang sekarang disenangi oleh setiap orang dari berbagai daerah di Nusantara. Kita dapat memasak ayam kecap saori olahan sendiri di rumahmu dan boleh dijadikan camilan favoritmu di hari libur.

Kita jangan bingung jika kamu ingin menyantap ayam kecap saori, lantaran ayam kecap saori mudah untuk ditemukan dan kalian pun bisa membuatnya sendiri di tempatmu. ayam kecap saori boleh diolah memalui bermacam cara. Kini pun sudah banyak resep modern yang menjadikan ayam kecap saori lebih enak.

Resep ayam kecap saori pun sangat gampang dibuat, lho. Anda tidak usah capek-capek untuk memesan ayam kecap saori, sebab Kalian dapat menyajikan sendiri di rumah. Bagi Kamu yang mau menyajikannya, berikut cara untuk menyajikan ayam kecap saori yang nikamat yang dapat Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Ayam Kecap Saori:

1. Siapkan 5-6 potong ayam ukuran sedang
1. Gunakan  Bumbu ungkep :
1. Gunakan 2 sdt kunyit bubuk
1. Gunakan 2,5 sdt ketumbar bubuk
1. Siapkan 1 sdt merica bubuk
1. Gunakan 1/2 sdt garam
1. Ambil 1 sdt kaldu jamur
1. Siapkan 1 sdt saori saos tiram
1. Gunakan 1 batang sereh, sayat2 menjadi 3 bagian
1. Siapkan secukupnya Air
1. Ambil  Bahan saos kecap
1. Gunakan 2 sdm kecap manis
1. Gunakan 1 sdt saori
1. Gunakan 1 bawang merah ukuran besar (kl sedang 2 bwng merah) iris halus
1. Gunakan 1 bawang putih iris halus
1. Sediakan 3 buah cabe keriting, iris serong
1. Gunakan 1/2 buah tomat
1. Ambil  Minyak secukupnya utk menggoreng




<!--inarticleads2-->

##### Cara menyiapkan Ayam Kecap Saori:

1. Bersihkan ayam, lalu masukkan ke kuali, kemudian campur dengan secukupnya air dan seluruh bumbu ungkep. Ungkep (rebus) hingga air susut.
1. Goreng ayam ungkep di api sedang, tingkat kekeringan saat menggoreng sedang. Angkat tiriskan.
1. Tumis bawang merah dan putih hingga wangi. Masukkan irisan cabe, aduk lagi, masukkan kecap manis+saori. Masukkan tomat. Aduk sebentar. Tes rasa saos, jika kurang pas bisa ditambahkan sedikit garam (saya tdk pakai). Masukkan ayam yg telah digoreng td, aduk rata. Ayam kecap saori siap disajikan. 😍




Ternyata cara membuat ayam kecap saori yang lezat simple ini mudah banget ya! Kita semua mampu menghidangkannya. Cara buat ayam kecap saori Sesuai sekali buat anda yang baru belajar memasak maupun untuk kamu yang telah lihai dalam memasak.

Tertarik untuk mulai mencoba membuat resep ayam kecap saori mantab sederhana ini? Kalau kalian ingin, ayo kamu segera menyiapkan peralatan dan bahan-bahannya, kemudian bikin deh Resep ayam kecap saori yang mantab dan simple ini. Sangat taidak sulit kan. 

Oleh karena itu, ketimbang kamu diam saja, hayo langsung aja sajikan resep ayam kecap saori ini. Pasti kamu tak akan nyesel sudah bikin resep ayam kecap saori enak tidak ribet ini! Selamat mencoba dengan resep ayam kecap saori mantab simple ini di rumah sendiri,oke!.

