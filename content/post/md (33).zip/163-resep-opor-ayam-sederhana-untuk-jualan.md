---
description: "Resep Opor Ayam Sederhana Untuk Jualan"
title: "Resep Opor Ayam Sederhana Untuk Jualan"
slug: 163-resep-opor-ayam-sederhana-untuk-jualan
date: 2021-01-12T13:17:05.229Z
image: https://img-global.cpcdn.com/recipes/907306f98c237ad6/680x482cq70/opor-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/907306f98c237ad6/680x482cq70/opor-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/907306f98c237ad6/680x482cq70/opor-ayam-foto-resep-utama.jpg
author: Dorothy Ryan
ratingvalue: 4.3
reviewcount: 6
recipeingredient:
- "1 ekor ayam sedang potong2 cuci bersih"
- "50 ml santan kara campur air hingga 100ml"
- "3 bh cabe keriting iris serong"
- "1 btg serai geprek"
- "3 daun salam"
- "3 daun jeruk buang tulang"
- "1 ruas jahe"
- "1 ruas lengkuas"
- "1/8 bj pala"
- "1/4 sdt jintan"
- "1/2 sdt ketumbar bubuk"
- "600 ml air minum"
- " Minyak unt menumis"
- "1 sdt garam batu himalayan"
- "secukupnya Lada"
- " Bawang goreng  telur rebus sbg pelengkap"
- " Bahan halus "
- "12 siung bawang merah"
- "6 siung bawang putih"
- "5 bh kemiri"
- "1 ruas kunyit"
recipeinstructions:
- "Tumis semua bahan kecuali santan."
- "Masukkan ayam, aduk rata. Tutup sbntr wajan. Biarkan bumbu meresap."
- "Beri air, didihkan dan masak hingga ayam empuk."
- "Beri garam. Koreksi rasa, matikan api. Masukkan santan &amp; aduk rata."
- "Angkat ayam, saring kuah agar ampas bumbu tdk ikt. Sajikan dgn bawang goreng &amp; telur rebus."
categories:
- Resep
tags:
- opor
- ayam

katakunci: opor ayam 
nutrition: 270 calories
recipecuisine: Indonesian
preptime: "PT19M"
cooktime: "PT34M"
recipeyield: "2"
recipecategory: Dessert

---


![Opor Ayam](https://img-global.cpcdn.com/recipes/907306f98c237ad6/680x482cq70/opor-ayam-foto-resep-utama.jpg)

Jika kamu seorang ibu, menyajikan panganan mantab untuk keluarga merupakan hal yang sangat menyenangkan bagi kita sendiri. Tanggung jawab seorang  wanita bukan cuman mengerjakan pekerjaan rumah saja, tapi anda juga wajib memastikan keperluan nutrisi terpenuhi dan juga panganan yang dimakan orang tercinta harus sedap.

Di zaman  sekarang, kalian memang bisa membeli masakan jadi tidak harus repot mengolahnya terlebih dahulu. Tapi banyak juga lho orang yang selalu mau menyajikan yang terbaik untuk orang tercintanya. Lantaran, menyajikan masakan sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan berdasarkan masakan kesukaan famili. 



Mungkinkah kamu seorang penyuka opor ayam?. Asal kamu tahu, opor ayam merupakan makanan khas di Nusantara yang saat ini digemari oleh orang-orang di berbagai daerah di Nusantara. Anda bisa membuat opor ayam sendiri di rumah dan boleh dijadikan makanan favorit di hari libur.

Anda tidak usah bingung jika kamu ingin mendapatkan opor ayam, sebab opor ayam mudah untuk didapatkan dan kalian pun dapat menghidangkannya sendiri di tempatmu. opor ayam dapat dibuat lewat beragam cara. Kini ada banyak sekali cara kekinian yang membuat opor ayam lebih enak.

Resep opor ayam juga mudah untuk dibuat, lho. Anda tidak usah ribet-ribet untuk memesan opor ayam, karena Kita mampu membuatnya sendiri di rumah. Bagi Kita yang mau menyajikannya, inilah resep untuk membuat opor ayam yang lezat yang dapat Kamu coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Opor Ayam:

1. Sediakan 1 ekor ayam sedang, potong2, cuci bersih
1. Gunakan 50 ml santan kara, campur air hingga 100ml
1. Sediakan 3 bh cabe keriting, iris serong
1. Ambil 1 btg serai, geprek
1. Sediakan 3 daun salam
1. Siapkan 3 daun jeruk, buang tulang
1. Siapkan 1 ruas jahe
1. Ambil 1 ruas lengkuas
1. Gunakan 1/8 bj pala
1. Ambil 1/4 sdt jintan
1. Gunakan 1/2 sdt ketumbar bubuk
1. Gunakan 600 ml air minum
1. Gunakan  Minyak unt menumis
1. Gunakan 1 sdt garam batu himalayan
1. Sediakan secukupnya Lada
1. Gunakan  Bawang goreng &amp; telur rebus sbg pelengkap
1. Ambil  Bahan halus :
1. Ambil 12 siung bawang merah
1. Sediakan 6 siung bawang putih
1. Ambil 5 bh kemiri
1. Ambil 1 ruas kunyit




<!--inarticleads2-->

##### Langkah-langkah membuat Opor Ayam:

1. Tumis semua bahan kecuali santan.
1. Masukkan ayam, aduk rata. Tutup sbntr wajan. Biarkan bumbu meresap.
1. Beri air, didihkan dan masak hingga ayam empuk.
1. Beri garam. Koreksi rasa, matikan api. Masukkan santan &amp; aduk rata.
1. Angkat ayam, saring kuah agar ampas bumbu tdk ikt. Sajikan dgn bawang goreng &amp; telur rebus.




Ternyata cara membuat opor ayam yang enak sederhana ini mudah sekali ya! Kamu semua mampu membuatnya. Cara Membuat opor ayam Sangat sesuai sekali untuk anda yang baru belajar memasak atau juga untuk kalian yang sudah jago dalam memasak.

Tertarik untuk mencoba membikin resep opor ayam lezat tidak ribet ini? Kalau mau, mending kamu segera buruan siapin alat-alat dan bahannya, setelah itu bikin deh Resep opor ayam yang nikmat dan sederhana ini. Benar-benar mudah kan. 

Maka dari itu, ketimbang anda berlama-lama, yuk kita langsung saja buat resep opor ayam ini. Pasti kalian gak akan nyesel sudah membuat resep opor ayam enak simple ini! Selamat mencoba dengan resep opor ayam mantab tidak rumit ini di tempat tinggal kalian masing-masing,ya!.

