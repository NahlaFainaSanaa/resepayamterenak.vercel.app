---
description: "Cara membuat Opor Ayam yang nikmat dan Mudah Dibuat"
title: "Cara membuat Opor Ayam yang nikmat dan Mudah Dibuat"
slug: 161-cara-membuat-opor-ayam-yang-nikmat-dan-mudah-dibuat
date: 2021-03-06T06:07:29.424Z
image: https://img-global.cpcdn.com/recipes/41d87ad880587ce7/680x482cq70/opor-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/41d87ad880587ce7/680x482cq70/opor-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/41d87ad880587ce7/680x482cq70/opor-ayam-foto-resep-utama.jpg
author: Scott Fisher
ratingvalue: 4.5
reviewcount: 9
recipeingredient:
- "1/2 ekor ayam potong cuci bersih"
- "2 lembar Daun salam"
- "1 batang Serai geprek"
- "1 ruas lengkuah geprek"
- "2 cm Kayu manis"
- " Garam"
- " Gula"
- " Kaldu bubuk"
- "1 bks santan instan 65 ml meKara"
- "Sedikit minyak untuk menumis"
- "secukupnya Air"
- " Bumbu halus"
- "5 buah bawang merah"
- "3 siung bawang putih"
- "2 butir kemiri"
- "1 sdm ketumbar"
- "1 sdt merica"
- "1 ruas jahe"
recipeinstructions:
- "Siapkan semua bahan. Tumis bumbu halus, serai, lengkuas dan daun salam hingga harum. Lalu masukkan ayam. Tumis sebentar hingga ayam berwarna pucat. Lalu tuang air hingga ayam terendam. Masak hingga mendidih"
- "Stelah mendidih, masukkan garam gula n kaldu. Terakhir msukkan santan. Masak hingga keluar minyak dan ayam matang. Koreksi rasa dan sajikan 😊"
categories:
- Resep
tags:
- opor
- ayam

katakunci: opor ayam 
nutrition: 215 calories
recipecuisine: Indonesian
preptime: "PT34M"
cooktime: "PT59M"
recipeyield: "1"
recipecategory: Dinner

---


![Opor Ayam](https://img-global.cpcdn.com/recipes/41d87ad880587ce7/680x482cq70/opor-ayam-foto-resep-utama.jpg)

Sebagai seorang wanita, menyediakan masakan menggugah selera untuk keluarga adalah suatu hal yang menggembirakan untuk anda sendiri. Kewajiban seorang ibu Tidak hanya mengurus rumah saja, namun kamu pun harus memastikan kebutuhan gizi tercukupi dan panganan yang disantap anak-anak harus sedap.

Di era  sekarang, kalian sebenarnya mampu mengorder santapan praktis meski tanpa harus repot mengolahnya lebih dulu. Tetapi ada juga mereka yang memang ingin memberikan yang terlezat bagi orang tercintanya. Karena, menyajikan masakan sendiri jauh lebih higienis dan bisa menyesuaikan berdasarkan masakan kesukaan keluarga tercinta. 



Mungkinkah anda seorang penyuka opor ayam?. Asal kamu tahu, opor ayam merupakan makanan khas di Nusantara yang kini digemari oleh orang-orang di berbagai tempat di Indonesia. Kamu bisa membuat opor ayam buatan sendiri di rumah dan pasti jadi makanan favorit di akhir pekanmu.

Kalian tak perlu bingung jika kamu ingin memakan opor ayam, karena opor ayam gampang untuk dicari dan anda pun dapat mengolahnya sendiri di tempatmu. opor ayam dapat dimasak dengan beragam cara. Kini pun telah banyak resep kekinian yang membuat opor ayam semakin lebih lezat.

Resep opor ayam juga mudah untuk dibikin, lho. Kalian tidak perlu repot-repot untuk memesan opor ayam, sebab Kamu dapat menyiapkan ditempatmu. Bagi Kalian yang mau menghidangkannya, berikut ini resep membuat opor ayam yang nikamat yang bisa Kalian hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Opor Ayam:

1. Sediakan 1/2 ekor ayam, potong cuci bersih
1. Siapkan 2 lembar Daun salam
1. Siapkan 1 batang Serai, geprek
1. Gunakan 1 ruas lengkuah, geprek
1. Sediakan 2 cm Kayu manis
1. Ambil  Garam
1. Gunakan  Gula
1. Sediakan  Kaldu bubuk
1. Ambil 1 bks santan instan 65 ml (me:Kara)
1. Siapkan Sedikit minyak untuk menumis
1. Ambil secukupnya Air
1. Sediakan  Bumbu halus:
1. Gunakan 5 buah bawang merah
1. Siapkan 3 siung bawang putih
1. Gunakan 2 butir kemiri
1. Sediakan 1 sdm ketumbar
1. Siapkan 1 sdt merica
1. Ambil 1 ruas jahe




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Opor Ayam:

1. Siapkan semua bahan. - Tumis bumbu halus, serai, lengkuas dan daun salam hingga harum. Lalu masukkan ayam. Tumis sebentar hingga ayam berwarna pucat. Lalu tuang air hingga ayam terendam. Masak hingga mendidih
1. Stelah mendidih, masukkan garam gula n kaldu. Terakhir msukkan santan. Masak hingga keluar minyak dan ayam matang. Koreksi rasa dan sajikan 😊




Wah ternyata resep opor ayam yang enak tidak ribet ini gampang banget ya! Kamu semua bisa membuatnya. Resep opor ayam Sesuai banget buat kalian yang baru mau belajar memasak maupun juga bagi kamu yang telah hebat dalam memasak.

Apakah kamu tertarik mencoba membuat resep opor ayam nikmat simple ini? Kalau kalian tertarik, yuk kita segera buruan siapin alat-alat dan bahannya, kemudian bikin deh Resep opor ayam yang mantab dan tidak ribet ini. Sangat mudah kan. 

Oleh karena itu, daripada anda berlama-lama, yuk kita langsung bikin resep opor ayam ini. Dijamin kalian tak akan menyesal membuat resep opor ayam nikmat tidak ribet ini! Selamat berkreasi dengan resep opor ayam enak tidak rumit ini di tempat tinggal kalian sendiri,oke!.

