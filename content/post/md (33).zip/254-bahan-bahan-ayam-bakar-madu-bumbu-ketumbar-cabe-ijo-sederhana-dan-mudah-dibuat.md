---
description: "Bahan-bahan Ayam Bakar Madu Bumbu Ketumbar Cabe Ijo Sederhana dan Mudah Dibuat"
title: "Bahan-bahan Ayam Bakar Madu Bumbu Ketumbar Cabe Ijo Sederhana dan Mudah Dibuat"
slug: 254-bahan-bahan-ayam-bakar-madu-bumbu-ketumbar-cabe-ijo-sederhana-dan-mudah-dibuat
date: 2021-01-14T16:01:20.792Z
image: https://img-global.cpcdn.com/recipes/ddda4f040a5c565e/680x482cq70/ayam-bakar-madu-bumbu-ketumbar-cabe-ijo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ddda4f040a5c565e/680x482cq70/ayam-bakar-madu-bumbu-ketumbar-cabe-ijo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ddda4f040a5c565e/680x482cq70/ayam-bakar-madu-bumbu-ketumbar-cabe-ijo-foto-resep-utama.jpg
author: Bessie Bridges
ratingvalue: 3
reviewcount: 6
recipeingredient:
- "1 ekor ayam"
- "1 buah jeruk nipis peras airnya"
- "1 ruas lengkuas digeprek"
- "1 batang serai digeprek"
- "2 lembar daun jeruk"
- "3 lembar daun salam"
- "secukupnya Penyedap Rasa  Kaldu Jamur"
- "secukupnya Garam"
- "secukupnya Gula merah"
- "1 sdm kecap manis"
- "3 sdm Madu"
- "1 sdm ketumbar bubuk"
- "2 sdm minyak goreng saya pakai minyak VCO 3 semprot"
- "secukupnya Air"
- " Bumbu Halus"
- "15 buah cabai keriting"
- "10 buah cabai ijo lupa difoto"
- "5 siung bawang merah"
- "5 siung bawang putih"
- "1 batang serai"
- "1 ruas lengkuas"
- "2 butir kemiri"
recipeinstructions:
- "Potong ayam beberapa bagian sesuai selera lalu cuci bersih dan tiriskan (lupa difoto)"
- "Marinasi dengan perasan air jeruk dan diamkan selama 15 menit. Lalu cuci bersih dan tiriskan kembali"
- "Panaskan wajan, masukkan minyak lalu masukkan bumbu halus"
- "Masukkan serai, lengkuas, daun jeruk, ketumbar bubuk, tumis sampai harum. Tambahkan air sedikit lalu masukkan gula merah, kecap manis dan kaldu jamur"
- "Masukkan madu lalu aduk sampai bumbu menyatu. Koreksi rasa"
- "Masukkan ayam lalu aduk sampai bumbu meresap. Tambahkan air jika bumbu kering."
- "Setelah ayam empuk matikan kompor, diamkan selama 15 menit"
- "Panaskan pembakaran lalu bakar ayam tadi, oleskan bumbu tumisan ayam saat membakar ayam"
- "Setelah ayam dibakar sajikan bersama lalapan dan nasi merah (maklum lagi diet 😁), jika masih ada sisa bumbu bisa siram diatas ayam yang telah dibakar tadi."
categories:
- Resep
tags:
- ayam
- bakar
- madu

katakunci: ayam bakar madu 
nutrition: 257 calories
recipecuisine: Indonesian
preptime: "PT26M"
cooktime: "PT50M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Bakar Madu Bumbu Ketumbar Cabe Ijo](https://img-global.cpcdn.com/recipes/ddda4f040a5c565e/680x482cq70/ayam-bakar-madu-bumbu-ketumbar-cabe-ijo-foto-resep-utama.jpg)

Sebagai seorang yang hobi masak, mempersiapkan santapan nikmat buat orang tercinta merupakan hal yang membahagiakan bagi anda sendiri. Kewajiban seorang  wanita Tidak cuman mengurus rumah saja, tapi kamu pun harus memastikan kebutuhan gizi tercukupi dan juga hidangan yang dikonsumsi orang tercinta mesti sedap.

Di zaman  saat ini, anda sebenarnya dapat memesan masakan siap saji meski tanpa harus ribet mengolahnya dahulu. Tetapi banyak juga lho orang yang memang mau memberikan yang terenak untuk keluarganya. Pasalnya, menghidangkan masakan yang dibuat sendiri jauh lebih bersih dan kita pun bisa menyesuaikan hidangan tersebut sesuai masakan kesukaan famili. 



Apakah anda seorang penyuka ayam bakar madu bumbu ketumbar cabe ijo?. Tahukah kamu, ayam bakar madu bumbu ketumbar cabe ijo merupakan sajian khas di Nusantara yang saat ini digemari oleh banyak orang dari hampir setiap wilayah di Indonesia. Kamu dapat menghidangkan ayam bakar madu bumbu ketumbar cabe ijo olahan sendiri di rumahmu dan dapat dijadikan hidangan favoritmu di akhir pekan.

Kalian tidak perlu bingung jika kamu ingin menyantap ayam bakar madu bumbu ketumbar cabe ijo, karena ayam bakar madu bumbu ketumbar cabe ijo gampang untuk ditemukan dan juga kita pun bisa membuatnya sendiri di tempatmu. ayam bakar madu bumbu ketumbar cabe ijo boleh diolah lewat beragam cara. Saat ini ada banyak sekali resep kekinian yang membuat ayam bakar madu bumbu ketumbar cabe ijo lebih mantap.

Resep ayam bakar madu bumbu ketumbar cabe ijo pun sangat gampang untuk dibikin, lho. Kamu jangan capek-capek untuk membeli ayam bakar madu bumbu ketumbar cabe ijo, lantaran Anda bisa menyiapkan di rumahmu. Untuk Anda yang ingin membuatnya, dibawah ini merupakan resep membuat ayam bakar madu bumbu ketumbar cabe ijo yang mantab yang mampu Anda hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Ayam Bakar Madu Bumbu Ketumbar Cabe Ijo:

1. Siapkan 1 ekor ayam
1. Sediakan 1 buah jeruk nipis (peras airnya)
1. Sediakan 1 ruas lengkuas digeprek
1. Siapkan 1 batang serai digeprek
1. Ambil 2 lembar daun jeruk
1. Ambil 3 lembar daun salam
1. Gunakan secukupnya Penyedap Rasa / Kaldu Jamur
1. Siapkan secukupnya Garam
1. Sediakan secukupnya Gula merah
1. Siapkan 1 sdm kecap manis
1. Ambil 3 sdm Madu
1. Siapkan 1 sdm ketumbar bubuk
1. Ambil 2 sdm minyak goreng (saya pakai minyak VCO 3 semprot)
1. Ambil secukupnya Air
1. Ambil  Bumbu Halus
1. Sediakan 15 buah cabai keriting
1. Ambil 10 buah cabai ijo (lupa difoto)
1. Ambil 5 siung bawang merah
1. Gunakan 5 siung bawang putih
1. Sediakan 1 batang serai
1. Gunakan 1 ruas lengkuas
1. Siapkan 2 butir kemiri




<!--inarticleads2-->

##### Cara menyiapkan Ayam Bakar Madu Bumbu Ketumbar Cabe Ijo:

1. Potong ayam beberapa bagian sesuai selera lalu cuci bersih dan tiriskan (lupa difoto)
1. Marinasi dengan perasan air jeruk dan diamkan selama 15 menit. Lalu cuci bersih dan tiriskan kembali
1. Panaskan wajan, masukkan minyak lalu masukkan bumbu halus
1. Masukkan serai, lengkuas, daun jeruk, ketumbar bubuk, tumis sampai harum. Tambahkan air sedikit lalu masukkan gula merah, kecap manis dan kaldu jamur
1. Masukkan madu lalu aduk sampai bumbu menyatu. Koreksi rasa
1. Masukkan ayam lalu aduk sampai bumbu meresap. Tambahkan air jika bumbu kering.
1. Setelah ayam empuk matikan kompor, diamkan selama 15 menit
1. Panaskan pembakaran lalu bakar ayam tadi, oleskan bumbu tumisan ayam saat membakar ayam
1. Setelah ayam dibakar sajikan bersama lalapan dan nasi merah (maklum lagi diet 😁), jika masih ada sisa bumbu bisa siram diatas ayam yang telah dibakar tadi.




Wah ternyata cara membuat ayam bakar madu bumbu ketumbar cabe ijo yang mantab simple ini mudah banget ya! Kita semua dapat membuatnya. Cara Membuat ayam bakar madu bumbu ketumbar cabe ijo Sangat sesuai sekali buat kita yang baru belajar memasak maupun juga bagi anda yang telah pandai memasak.

Apakah kamu mau mencoba bikin resep ayam bakar madu bumbu ketumbar cabe ijo enak tidak ribet ini? Kalau ingin, ayo kamu segera siapin peralatan dan bahannya, lantas bikin deh Resep ayam bakar madu bumbu ketumbar cabe ijo yang enak dan sederhana ini. Betul-betul mudah kan. 

Maka, daripada kita berfikir lama-lama, hayo kita langsung hidangkan resep ayam bakar madu bumbu ketumbar cabe ijo ini. Dijamin kalian tiidak akan menyesal sudah buat resep ayam bakar madu bumbu ketumbar cabe ijo mantab tidak rumit ini! Selamat berkreasi dengan resep ayam bakar madu bumbu ketumbar cabe ijo nikmat simple ini di rumah kalian masing-masing,oke!.

