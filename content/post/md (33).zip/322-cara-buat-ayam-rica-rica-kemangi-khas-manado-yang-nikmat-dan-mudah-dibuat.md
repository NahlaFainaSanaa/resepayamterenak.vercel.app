---
description: "Cara buat Ayam rica-rica kemangi khas manado yang nikmat dan Mudah Dibuat"
title: "Cara buat Ayam rica-rica kemangi khas manado yang nikmat dan Mudah Dibuat"
slug: 322-cara-buat-ayam-rica-rica-kemangi-khas-manado-yang-nikmat-dan-mudah-dibuat
date: 2021-05-01T04:26:25.472Z
image: https://img-global.cpcdn.com/recipes/4f74f6f296c2dcfc/680x482cq70/ayam-rica-rica-kemangi-khas-manado-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4f74f6f296c2dcfc/680x482cq70/ayam-rica-rica-kemangi-khas-manado-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4f74f6f296c2dcfc/680x482cq70/ayam-rica-rica-kemangi-khas-manado-foto-resep-utama.jpg
author: George Morgan
ratingvalue: 3.1
reviewcount: 13
recipeingredient:
- "1 1/2 ekor ayam"
- "6 cabai merah"
- "20 cabai rawit"
- "10 siung bawang merah"
- "4 siung bawang putih"
- "1 ikat kemangi"
- "1 biji kunyit"
- "1 biji jahe"
- "4 butir kemiri"
- "1/2 sdm garam"
- "1 sdm gula"
- "3 biji serai"
- "5 lembar daun jeruk"
- "3 lembar daun salam"
- "2 biji jeruk nipis asli"
- "1/2 sdm lada putih dan hitam sesuai selera"
recipeinstructions:
- "Bersihkan daging ayamnya, lalu taburkan garam dan jeruk nipis ke dalam rendaman ayam yang telah dibersihkan diamkan selama kurang lebih 15 menit supaya garam dan jeruk nipisnya menyerap ke daging ayam."
- "Haluskan bawang merah, bawang putih, jahe, kunyit, cabai merah, cabai rawit, kemiri, lada hitam dan putih lalu berikan sedikit air supaya bumbu dapat di blender dengan halus."
- "Goreng daging ayam sampai warna nya coklat dan jangan terlalu kering sekali gorengnya."
- "Tumis bumbu yang sudah dihaluskan tadi sampai benar-benar tanang dan harum, setelah bumbu tanak atau masak masukkan daging ayam yang sudah digoreng tadi sampai benar-benar bumbunya meresap ke dalam daging ayam yang sudah di goreng."
- "Siap disajikan."
categories:
- Resep
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 127 calories
recipecuisine: Indonesian
preptime: "PT30M"
cooktime: "PT55M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam rica-rica kemangi khas manado](https://img-global.cpcdn.com/recipes/4f74f6f296c2dcfc/680x482cq70/ayam-rica-rica-kemangi-khas-manado-foto-resep-utama.jpg)

Apabila kalian seorang orang tua, menyajikan panganan mantab buat orang tercinta merupakan suatu hal yang menyenangkan untuk anda sendiri. Tanggung jawab seorang ibu bukan sekedar menangani rumah saja, tapi anda pun harus memastikan keperluan gizi tercukupi dan hidangan yang dimakan anak-anak wajib lezat.

Di masa  sekarang, kalian sebenarnya mampu mengorder hidangan instan walaupun tanpa harus ribet memasaknya dahulu. Namun banyak juga orang yang memang ingin memberikan makanan yang terenak bagi orang tercintanya. Sebab, menyajikan masakan yang diolah sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan hidangan tersebut sesuai kesukaan orang tercinta. 

Rica-rica dalam bahasa Manado (Sulawesi Utara) berarti pedas atau cabe. dalam proses masaknya beraneka ragam. Masakan kali ini dengan menambah daun kemangi. Inilah rahasia resep masakan ayam rica rica dan petunjuk cara bikin hidangan rica rica ayam.

Apakah anda salah satu penyuka ayam rica-rica kemangi khas manado?. Asal kamu tahu, ayam rica-rica kemangi khas manado adalah sajian khas di Nusantara yang sekarang disukai oleh setiap orang di hampir setiap wilayah di Indonesia. Kalian bisa memasak ayam rica-rica kemangi khas manado sendiri di rumahmu dan boleh jadi santapan kesukaanmu di hari libur.

Anda jangan bingung untuk memakan ayam rica-rica kemangi khas manado, karena ayam rica-rica kemangi khas manado tidak sulit untuk ditemukan dan juga kita pun boleh menghidangkannya sendiri di rumah. ayam rica-rica kemangi khas manado bisa diolah memalui beraneka cara. Saat ini sudah banyak sekali cara kekinian yang menjadikan ayam rica-rica kemangi khas manado semakin enak.

Resep ayam rica-rica kemangi khas manado juga mudah sekali untuk dibuat, lho. Anda tidak perlu repot-repot untuk memesan ayam rica-rica kemangi khas manado, sebab Kamu dapat membuatnya sendiri di rumah. Untuk Anda yang akan menyajikannya, di bawah ini adalah resep menyajikan ayam rica-rica kemangi khas manado yang lezat yang mampu Kamu coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Ayam rica-rica kemangi khas manado:

1. Sediakan 1 1/2 ekor ayam
1. Sediakan 6 cabai merah
1. Siapkan 20 cabai rawit
1. Gunakan 10 siung bawang merah
1. Ambil 4 siung bawang putih
1. Siapkan 1 ikat kemangi
1. Gunakan 1 biji kunyit
1. Ambil 1 biji jahe
1. Siapkan 4 butir kemiri
1. Gunakan 1/2 sdm garam
1. Gunakan 1 sdm gula
1. Siapkan 3 biji serai
1. Siapkan 5 lembar daun jeruk
1. Sediakan 3 lembar daun salam
1. Ambil 2 biji jeruk nipis asli
1. Gunakan 1/2 sdm lada putih dan hitam sesuai selera


Ayam rica-rica yang merupakan salah satu panganan khas daerah Manado, Sulawesi Utara. Dimana &#34;rica&#34; ini yang berarti &#34;cabai&#34; atau &#34;pedas&#34; dalam bahasa Manadonya. Resep Ayam Rica Rica - Siapa yang tidak mengenal kuliner yang telah menjamur ditengah masyarakat ini. Ayam rica-rica adalah salah satu kuliner kebanggaan masyarakat Indonesia khas dari Manado, Sulawesi Utara. 

<!--inarticleads2-->

##### Cara menyiapkan Ayam rica-rica kemangi khas manado:

1. Bersihkan daging ayamnya, lalu taburkan garam dan jeruk nipis ke dalam rendaman ayam yang telah dibersihkan diamkan selama kurang lebih 15 menit supaya garam dan jeruk nipisnya menyerap ke daging ayam.
1. Haluskan bawang merah, bawang putih, jahe, kunyit, cabai merah, cabai rawit, kemiri, lada hitam dan putih lalu berikan sedikit air supaya bumbu dapat di blender dengan halus.
1. Goreng daging ayam sampai warna nya coklat dan jangan terlalu kering sekali gorengnya.
1. Tumis bumbu yang sudah dihaluskan tadi sampai benar-benar tanang dan harum, setelah bumbu tanak atau masak masukkan daging ayam yang sudah digoreng tadi sampai benar-benar bumbunya meresap ke dalam daging ayam yang sudah di goreng.
1. Siap disajikan.


Dengan aroma yang menggoda dibumbui dengan. Resepnya sederhana dan mudah, khas Manado asli pakai daun kemangi. Wajib coba bagi pecinta makanan pedas. Resep cara membuat ayam rica rica, jika ditambah daun kemangi pasti lebih enak. Ini merupakan resep makanan pedas asli khas Manado yang populer. 

Wah ternyata cara membuat ayam rica-rica kemangi khas manado yang nikamt tidak rumit ini mudah banget ya! Semua orang bisa menghidangkannya. Resep ayam rica-rica kemangi khas manado Sangat sesuai banget buat kita yang baru akan belajar memasak maupun bagi kalian yang telah jago dalam memasak.

Tertarik untuk mulai mencoba bikin resep ayam rica-rica kemangi khas manado nikmat tidak ribet ini? Kalau kalian mau, yuk kita segera siapin alat dan bahan-bahannya, lantas buat deh Resep ayam rica-rica kemangi khas manado yang enak dan sederhana ini. Sangat taidak sulit kan. 

Maka, daripada kamu berlama-lama, yuk kita langsung saja buat resep ayam rica-rica kemangi khas manado ini. Pasti kalian gak akan nyesel sudah bikin resep ayam rica-rica kemangi khas manado mantab sederhana ini! Selamat mencoba dengan resep ayam rica-rica kemangi khas manado enak tidak rumit ini di tempat tinggal sendiri,oke!.

