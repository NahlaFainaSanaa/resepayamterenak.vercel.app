---
description: "Cara membuat Soto Ayam Bumbu Iris yang nikmat dan Mudah Dibuat"
title: "Cara membuat Soto Ayam Bumbu Iris yang nikmat dan Mudah Dibuat"
slug: 235-cara-membuat-soto-ayam-bumbu-iris-yang-nikmat-dan-mudah-dibuat
date: 2021-03-18T21:01:27.768Z
image: https://img-global.cpcdn.com/recipes/f1b1b3dce49a5b3a/680x482cq70/soto-ayam-bumbu-iris-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f1b1b3dce49a5b3a/680x482cq70/soto-ayam-bumbu-iris-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f1b1b3dce49a5b3a/680x482cq70/soto-ayam-bumbu-iris-foto-resep-utama.jpg
author: Julian Craig
ratingvalue: 4.4
reviewcount: 9
recipeingredient:
- "500 gr ayam"
- "1 lt air"
- "5 sdm minyak untuk menumis"
- " Bumbu Iris"
- "2 sg bawang putih"
- "4 sg bawang merah"
- "1 btg daun bawang"
- " Bumbu Cemplung"
- "2 lbr daun salam"
- "2 lbr daun jeruk"
- "1 btg sere"
- "1 bh tomat Iris"
- "1 ruas jahe geprek"
- " Bumbu Penyedap"
- "1 sdt kunyit bubuk"
- "1 sdt ketumbar bubuk"
- "1/2 sdt merica bubuk"
- "1/2 sdt garam"
- "1/2 sdt kaldu bubuk"
- "1/2 sdt gula"
- " Pelengkap"
- " Sambal kecap"
- " Toge lalap"
- " Bawang goreng"
recipeinstructions:
- "Potong dan cuci bersih ayam. Didihkan air, rebus ayam. Buang air rebusan, dan rebus lg hingga empuk. Tiriskan ayam. Air rebusan yg ke 2 jg dibuang ya bund."
- "Siapkan semua bumbu. Tumis bumbu cemplung, kecuali tomat dan bumbu iris hingga harum"
- "Masukkan ayam dan tumis lg. Masukkan bumbu penyedap, aduk rata."
- "Masukkan air rebusan ayam. Aduk rata. Masak 15 menit/ hingga bumbu meresap dlm ayam. Masukkan tomat. Cek rasa. Angkat."
- "Sajikan taburi bawang goreng, nikmati dg sambal kecap dan toge lalap."
categories:
- Resep
tags:
- soto
- ayam
- bumbu

katakunci: soto ayam bumbu 
nutrition: 110 calories
recipecuisine: Indonesian
preptime: "PT29M"
cooktime: "PT42M"
recipeyield: "4"
recipecategory: Dinner

---


![Soto Ayam Bumbu Iris](https://img-global.cpcdn.com/recipes/f1b1b3dce49a5b3a/680x482cq70/soto-ayam-bumbu-iris-foto-resep-utama.jpg)

Apabila anda seorang ibu, menyuguhkan panganan nikmat untuk keluarga merupakan suatu hal yang menyenangkan untuk kamu sendiri. Tugas seorang istri bukan cuman mengatur rumah saja, namun anda pun harus menyediakan kebutuhan gizi tercukupi dan panganan yang disantap anak-anak mesti mantab.

Di masa  sekarang, kalian sebenarnya dapat memesan santapan instan walaupun tidak harus capek memasaknya dahulu. Namun ada juga orang yang selalu mau memberikan yang terbaik untuk orang yang dicintainya. Sebab, memasak sendiri akan jauh lebih bersih dan bisa menyesuaikan makanan tersebut berdasarkan masakan kesukaan orang tercinta. 



Mungkinkah anda adalah seorang penikmat soto ayam bumbu iris?. Tahukah kamu, soto ayam bumbu iris adalah sajian khas di Indonesia yang saat ini disukai oleh kebanyakan orang dari berbagai daerah di Nusantara. Kamu bisa membuat soto ayam bumbu iris kreasi sendiri di rumahmu dan dapat dijadikan camilan kesenanganmu di akhir pekan.

Kalian tidak usah bingung jika kamu ingin mendapatkan soto ayam bumbu iris, sebab soto ayam bumbu iris gampang untuk ditemukan dan juga kamu pun bisa menghidangkannya sendiri di tempatmu. soto ayam bumbu iris dapat dimasak lewat bermacam cara. Saat ini ada banyak banget cara modern yang membuat soto ayam bumbu iris semakin mantap.

Resep soto ayam bumbu iris pun mudah sekali untuk dibuat, lho. Kalian tidak perlu ribet-ribet untuk membeli soto ayam bumbu iris, tetapi Kalian bisa membuatnya di rumahmu. Untuk Kalian yang mau menghidangkannya, berikut ini cara untuk membuat soto ayam bumbu iris yang enak yang dapat Anda coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Soto Ayam Bumbu Iris:

1. Sediakan 500 gr ayam
1. Ambil 1 lt air
1. Sediakan 5 sdm minyak untuk menumis
1. Gunakan  Bumbu Iris:
1. Sediakan 2 sg bawang putih
1. Siapkan 4 sg bawang merah
1. Ambil 1 btg daun bawang
1. Sediakan  Bumbu Cemplung:
1. Sediakan 2 lbr daun salam
1. Siapkan 2 lbr daun jeruk
1. Sediakan 1 btg sere
1. Siapkan 1 bh tomat (Iris)
1. Ambil 1 ruas jahe (geprek)
1. Siapkan  Bumbu Penyedap:
1. Siapkan 1 sdt kunyit bubuk
1. Ambil 1 sdt ketumbar bubuk
1. Gunakan 1/2 sdt merica bubuk
1. Sediakan 1/2 sdt garam
1. Gunakan 1/2 sdt kaldu bubuk
1. Sediakan 1/2 sdt gula
1. Gunakan  Pelengkap:
1. Ambil  Sambal kecap
1. Siapkan  Toge lalap
1. Siapkan  Bawang goreng




<!--inarticleads2-->

##### Cara membuat Soto Ayam Bumbu Iris:

1. Potong dan cuci bersih ayam. Didihkan air, rebus ayam. Buang air rebusan, dan rebus lg hingga empuk. Tiriskan ayam. Air rebusan yg ke 2 jg dibuang ya bund.
1. Siapkan semua bumbu. Tumis bumbu cemplung, kecuali tomat dan bumbu iris hingga harum
1. Masukkan ayam dan tumis lg. Masukkan bumbu penyedap, aduk rata.
1. Masukkan air rebusan ayam. Aduk rata. Masak 15 menit/ hingga bumbu meresap dlm ayam. Masukkan tomat. Cek rasa. Angkat.
1. Sajikan taburi bawang goreng, nikmati dg sambal kecap dan toge lalap.




Wah ternyata resep soto ayam bumbu iris yang enak simple ini mudah sekali ya! Semua orang mampu memasaknya. Cara Membuat soto ayam bumbu iris Sangat sesuai sekali untuk anda yang sedang belajar memasak ataupun untuk kamu yang sudah jago memasak.

Apakah kamu mau mencoba membuat resep soto ayam bumbu iris lezat tidak ribet ini? Kalau kalian mau, ayo kalian segera siapin alat-alat dan bahannya, maka bikin deh Resep soto ayam bumbu iris yang mantab dan tidak ribet ini. Sungguh mudah kan. 

Maka dari itu, daripada kalian berfikir lama-lama, maka kita langsung saja buat resep soto ayam bumbu iris ini. Dijamin kamu tiidak akan nyesel sudah membuat resep soto ayam bumbu iris lezat tidak ribet ini! Selamat berkreasi dengan resep soto ayam bumbu iris mantab sederhana ini di rumah sendiri,ya!.

