---
description: "Cara membuat Ayam rica - rica yang nikmat Untuk Jualan"
title: "Cara membuat Ayam rica - rica yang nikmat Untuk Jualan"
slug: 315-cara-membuat-ayam-rica-rica-yang-nikmat-untuk-jualan
date: 2021-03-06T01:07:12.382Z
image: https://img-global.cpcdn.com/recipes/6291f1652a362f7b/680x482cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6291f1652a362f7b/680x482cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6291f1652a362f7b/680x482cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Mattie Moore
ratingvalue: 3
reviewcount: 7
recipeingredient:
- "1/2 ayam yg sudah d potong  potong"
- "3 ikat daun kemangi"
- "3 bawang merah"
- "2 bawang putih"
- "7 cabai setan"
- "3 cabe merah"
- "1 ruas kunyit"
- "1/2 jahe"
- "1/2 lengkuas"
- "secukupnya Daun salam"
- "1 serai"
- "secukupnya Ladaku"
- "secukupnya Garam"
- "secukupnya Sasa"
- "secukupnya gula"
recipeinstructions:
- "Masukan ayam kedalam panci yg airnya sudah mendidih tunggu sekitar 10 menit"
- "Tumis bumbu yg sudah halus masukan air secukupnya lalu masukan ayam tunggu sampai air sudah mengering angkat dan sanjikan"
categories:
- Resep
tags:
- ayam
- rica
- 

katakunci: ayam rica  
nutrition: 262 calories
recipecuisine: Indonesian
preptime: "PT21M"
cooktime: "PT39M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam rica - rica](https://img-global.cpcdn.com/recipes/6291f1652a362f7b/680x482cq70/ayam-rica-rica-foto-resep-utama.jpg)

Selaku seorang yang hobi memasak, menyuguhkan masakan lezat pada orang tercinta merupakan hal yang menyenangkan untuk kamu sendiri. Kewajiban seorang  wanita bukan saja menangani rumah saja, tetapi anda juga wajib menyediakan keperluan nutrisi tercukupi dan juga santapan yang dimakan anak-anak mesti enak.

Di masa  saat ini, kita memang bisa mengorder santapan jadi tanpa harus capek mengolahnya dahulu. Tapi banyak juga lho orang yang memang mau menyajikan yang terlezat untuk orang tercintanya. Pasalnya, menyajikan masakan yang dibuat sendiri akan jauh lebih higienis dan bisa menyesuaikan makanan tersebut sesuai dengan selera famili. 

Ayam rica-rica (Indonesian for chicken rica-rica) is an Indonesian hot and spicy chicken dish. It is made up of chicken that cooked in spicy red and green chili pepper. The origin of this dish is from Minahasan cuisine of North Sulawesi.

Mungkinkah anda merupakan salah satu penyuka ayam rica - rica?. Asal kamu tahu, ayam rica - rica merupakan makanan khas di Indonesia yang sekarang disenangi oleh setiap orang di berbagai daerah di Indonesia. Anda dapat membuat ayam rica - rica sendiri di rumahmu dan boleh jadi camilan kesukaanmu di akhir pekanmu.

Anda tidak usah bingung jika kamu ingin memakan ayam rica - rica, karena ayam rica - rica mudah untuk dicari dan juga anda pun boleh membuatnya sendiri di rumah. ayam rica - rica bisa dimasak dengan berbagai cara. Kini telah banyak resep modern yang membuat ayam rica - rica semakin lebih nikmat.

Resep ayam rica - rica pun sangat gampang untuk dibikin, lho. Anda jangan capek-capek untuk membeli ayam rica - rica, tetapi Kita mampu menyiapkan ditempatmu. Untuk Kalian yang ingin menghidangkannya, di bawah ini adalah resep untuk menyajikan ayam rica - rica yang nikamat yang dapat Kita coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Ayam rica - rica:

1. Ambil 1/2 ayam yg sudah d potong - potong
1. Ambil 3 ikat daun kemangi
1. Siapkan 3 bawang merah
1. Gunakan 2 bawang putih
1. Gunakan 7 cabai setan
1. Gunakan 3 cabe merah
1. Gunakan 1 ruas kunyit
1. Ambil 1/2 jahe
1. Sediakan 1/2 lengkuas
1. Siapkan secukupnya Daun salam
1. Ambil 1 serai
1. Siapkan secukupnya Ladaku
1. Gunakan secukupnya Garam
1. Siapkan secukupnya Sasa
1. Sediakan secukupnya gula


Cara pembuatan ayam rica rica sebenarnya tidaklah terlalu sulit. Seperti olahan ayam yang lainnya, bumbu ayam rica rica ini menggunakan bumbu rempah asli Indonesia, seperti kunyit, jahe. Ayam rica-rica is specialty chicken dish from the city of Manado in Indonesia North Sulawesi. Rica means chili in North Sulawesi language, so ayam rica-rica translates to chicken with chili sauce. 

<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam rica - rica:

1. Masukan ayam kedalam panci yg airnya sudah mendidih tunggu sekitar 10 menit
1. Tumis bumbu yg sudah halus masukan air secukupnya lalu masukan ayam tunggu sampai air sudah mengering angkat dan sanjikan


Cara pembuatan ayam rica-rica tidaklah sulit. Dibutuhkan bahan-bahan seperti daun jeruk, serai, dan daun pandan agar aromanya menjadi kuat dan khas. Ayam rica-rica is specialty chicken dish from the city of Manado in Indonesia North Sulawesi. Rica means chili in North Sulawesi language, so ayam rica-rica translates to chicken with chili sauce. Learn how to make tasty ayam rica rica with a pressure cooker or on the stove. 

Ternyata resep ayam rica - rica yang enak simple ini mudah banget ya! Kalian semua mampu memasaknya. Cara buat ayam rica - rica Sangat sesuai sekali untuk anda yang baru mau belajar memasak maupun untuk kalian yang telah jago dalam memasak.

Tertarik untuk mencoba bikin resep ayam rica - rica mantab tidak ribet ini? Kalau kalian ingin, mending kamu segera menyiapkan alat dan bahan-bahannya, lantas buat deh Resep ayam rica - rica yang nikmat dan sederhana ini. Betul-betul gampang kan. 

Jadi, ketimbang kamu diam saja, yuk kita langsung hidangkan resep ayam rica - rica ini. Pasti anda tak akan nyesel sudah membuat resep ayam rica - rica mantab tidak rumit ini! Selamat berkreasi dengan resep ayam rica - rica lezat tidak rumit ini di tempat tinggal kalian sendiri,ya!.

