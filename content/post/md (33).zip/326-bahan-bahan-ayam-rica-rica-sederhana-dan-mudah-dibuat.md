---
description: "Bahan-bahan Ayam Rica Rica Sederhana dan Mudah Dibuat"
title: "Bahan-bahan Ayam Rica Rica Sederhana dan Mudah Dibuat"
slug: 326-bahan-bahan-ayam-rica-rica-sederhana-dan-mudah-dibuat
date: 2021-01-22T10:41:27.463Z
image: https://img-global.cpcdn.com/recipes/0a80fe9a6475e42c/680x482cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0a80fe9a6475e42c/680x482cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0a80fe9a6475e42c/680x482cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Adeline McCormick
ratingvalue: 4.8
reviewcount: 6
recipeingredient:
- "500 gr daging ayam"
- "1 bh jeruk nipis"
- "1 ikat daun kemangisy skip ganti cabe ijo"
- "300 ml air"
- " Bumbu aromatik"
- "2 btg seraigeprek"
- "3 cm lengkuas geprek"
- "3 lmbr daun jeruk"
- " Bumbu halus "
- "7 siung bawang merah"
- "4 siung bawang putih"
- "5 bh cabe merah"
- "6 bh cabe rawit merah"
- "1 bh tomat ukr sedang"
- "2 ruas jahe"
- "20 gr gula aren"
- "1 sdt kaldu jamur"
- "1/2 sdt garam"
- "1 sdt kunyit bubuk"
recipeinstructions:
- "Sebelumnya lumurin lebih dahulu ayam dengan jeruk nipis dan garam, diamkan sebentar, lalu cuci lagi sebentar saja.sisihkan dulu  Siapkan bumbu dan haluskan, tumis bumbu halus dan bumbu aromatik sampai matang dan harum."
- "Masukkan potongan daging ayam, masak hingga daging ayam berubah warna, tambahkan air, masak hingga air nya sat, dan ayamnya matang, sambil dicek rasanya."
- "Masukkan potongan cabe hijau, aduk sebentar hinga cabe sedikit layu.  Matikan kompor"
- "Hidangkan 👌👍😍"
categories:
- Resep
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 205 calories
recipecuisine: Indonesian
preptime: "PT19M"
cooktime: "PT49M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam Rica Rica](https://img-global.cpcdn.com/recipes/0a80fe9a6475e42c/680x482cq70/ayam-rica-rica-foto-resep-utama.jpg)

Selaku seorang orang tua, mempersiapkan olahan menggugah selera bagi orang tercinta adalah hal yang menyenangkan bagi kita sendiri. Tugas seorang istri bukan saja mengurus rumah saja, tetapi kamu pun harus menyediakan keperluan gizi terpenuhi dan juga hidangan yang disantap anak-anak wajib enak.

Di waktu  saat ini, kamu sebenarnya dapat mengorder hidangan praktis meski tanpa harus capek membuatnya terlebih dahulu. Tetapi banyak juga mereka yang memang mau menghidangkan yang terbaik untuk orang tercintanya. Pasalnya, memasak yang dibuat sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan makanan tersebut sesuai selera keluarga tercinta. 



Apakah anda merupakan salah satu penikmat ayam rica rica?. Asal kamu tahu, ayam rica rica merupakan sajian khas di Nusantara yang sekarang disukai oleh kebanyakan orang di berbagai tempat di Nusantara. Kita dapat membuat ayam rica rica sendiri di rumahmu dan boleh jadi camilan kesukaanmu di hari libur.

Anda jangan bingung untuk memakan ayam rica rica, karena ayam rica rica tidak sukar untuk dicari dan kalian pun dapat membuatnya sendiri di tempatmu. ayam rica rica boleh diolah lewat beraneka cara. Kini telah banyak banget cara kekinian yang menjadikan ayam rica rica lebih mantap.

Resep ayam rica rica juga sangat gampang dibikin, lho. Anda tidak perlu repot-repot untuk membeli ayam rica rica, tetapi Kalian mampu menghidangkan sendiri di rumah. Untuk Anda yang hendak membuatnya, dibawah ini merupakan resep untuk membuat ayam rica rica yang lezat yang dapat Anda coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Ayam Rica Rica:

1. Sediakan 500 gr daging ayam
1. Siapkan 1 bh jeruk nipis
1. Gunakan 1 ikat daun kemangi(sy skip ganti cabe ijo)
1. Siapkan 300 ml air
1. Gunakan  Bumbu aromatik
1. Siapkan 2 btg serai,geprek
1. Gunakan 3 cm lengkuas, geprek
1. Ambil 3 lmbr daun jeruk
1. Ambil  Bumbu halus :
1. Gunakan 7 siung bawang merah
1. Siapkan 4 siung bawang putih
1. Gunakan 5 bh cabe merah
1. Siapkan 6 bh cabe rawit merah
1. Sediakan 1 bh tomat ukr sedang
1. Sediakan 2 ruas jahe
1. Ambil 20 gr gula aren
1. Siapkan 1 sdt kaldu jamur
1. Siapkan 1/2 sdt garam
1. Ambil 1 sdt kunyit bubuk




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Rica Rica:

1. Sebelumnya lumurin lebih dahulu ayam dengan jeruk nipis dan garam, diamkan sebentar, lalu cuci lagi sebentar saja.sisihkan dulu -  - Siapkan bumbu dan haluskan, tumis bumbu halus dan bumbu aromatik sampai matang dan harum.
1. Masukkan potongan daging ayam, masak hingga daging ayam berubah warna, tambahkan air, masak hingga air nya sat, dan ayamnya matang, sambil dicek rasanya.
1. Masukkan potongan cabe hijau, aduk sebentar hinga cabe sedikit layu.  - Matikan kompor
1. Hidangkan 👌👍😍




Ternyata cara buat ayam rica rica yang lezat tidak rumit ini enteng sekali ya! Kamu semua dapat memasaknya. Cara Membuat ayam rica rica Cocok sekali buat kita yang baru belajar memasak ataupun juga bagi kamu yang sudah pandai dalam memasak.

Tertarik untuk mulai mencoba bikin resep ayam rica rica nikmat simple ini? Kalau kalian mau, ayo kamu segera buruan siapkan alat-alat dan bahannya, kemudian buat deh Resep ayam rica rica yang mantab dan sederhana ini. Betul-betul gampang kan. 

Maka dari itu, ketimbang kamu berlama-lama, ayo langsung aja sajikan resep ayam rica rica ini. Pasti kalian tak akan menyesal sudah buat resep ayam rica rica nikmat tidak ribet ini! Selamat mencoba dengan resep ayam rica rica enak simple ini di rumah sendiri,ya!.

