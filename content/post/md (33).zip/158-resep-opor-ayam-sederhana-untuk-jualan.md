---
description: "Resep Opor ayam Sederhana Untuk Jualan"
title: "Resep Opor ayam Sederhana Untuk Jualan"
slug: 158-resep-opor-ayam-sederhana-untuk-jualan
date: 2021-06-23T09:27:04.262Z
image: https://img-global.cpcdn.com/recipes/90dfa3dcc1185146/680x482cq70/opor-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/90dfa3dcc1185146/680x482cq70/opor-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/90dfa3dcc1185146/680x482cq70/opor-ayam-foto-resep-utama.jpg
author: Abbie Jacobs
ratingvalue: 4.6
reviewcount: 7
recipeingredient:
- "1 ekor ayam"
- "1 liter air putih campur dgn 2 bungkus santan kara"
- "3 buah kentang potong dadu"
- "3 buah wortel potong dadu"
- "3 helai daun bawang ptong2"
- " Gula garam penyedap"
- "Secukupnya minyak"
- " Bumbu halus"
- "6 siung bawang putih"
- "6 siung bawang merah"
- "3 buah cabe rawit  4 buah cabe merah kriting"
- "1-2 ruas jari kunyit"
- "3 buah kemiri"
- " Bumbu kasar"
- "2 ruas jari jahe geprek"
- "2 ruas jari lengkuas geprek"
- "1 batang sereh geprek"
- "2 lembar daun salam"
recipeinstructions:
- "Tumis bumbu halus smpe harum, lalu masukan bumbu kasar nya dan lanjut tumis"
- "Masukan ayam, aduk2"
- "Masukan air santan, aduk2 jgn smpe santan pecah (kompor pke api sedang aja)"
- "Setelah air santan mendidih masukan kentang + wortel"
- "Masukan gula, garam, penyedap (takaran bisa di sesuaikan)"
- "Aduk2 dan tes rasa, jika rasa udh pas aduk skali2 smpe kentang dan wortel empuk"
- "Jika smua udah empuk taburkan daun bawang, aduk dan angkat. (bisa taburkan bawang merah goreng jg klo suka tpi dsini ak skip)"
categories:
- Resep
tags:
- opor
- ayam

katakunci: opor ayam 
nutrition: 261 calories
recipecuisine: Indonesian
preptime: "PT40M"
cooktime: "PT44M"
recipeyield: "1"
recipecategory: Dinner

---


![Opor ayam](https://img-global.cpcdn.com/recipes/90dfa3dcc1185146/680x482cq70/opor-ayam-foto-resep-utama.jpg)

Selaku seorang yang hobi masak, mempersiapkan hidangan lezat bagi famili adalah hal yang menggembirakan bagi kita sendiri. Peran seorang ibu Tidak saja mengurus rumah saja, namun kamu pun harus memastikan kebutuhan gizi tercukupi dan juga santapan yang dimakan orang tercinta mesti enak.

Di masa  sekarang, anda sebenarnya dapat membeli olahan siap saji tidak harus susah memasaknya terlebih dahulu. Namun banyak juga lho orang yang memang ingin memberikan hidangan yang terlezat bagi keluarganya. Pasalnya, memasak yang dibuat sendiri jauh lebih bersih dan bisa menyesuaikan hidangan tersebut sesuai makanan kesukaan famili. 



Apakah anda adalah salah satu penyuka opor ayam?. Asal kamu tahu, opor ayam adalah hidangan khas di Indonesia yang saat ini disukai oleh kebanyakan orang di berbagai wilayah di Nusantara. Kamu dapat membuat opor ayam olahan sendiri di rumahmu dan dapat dijadikan hidangan kesenanganmu di akhir pekanmu.

Kita tidak usah bingung untuk mendapatkan opor ayam, lantaran opor ayam mudah untuk dicari dan kita pun dapat menghidangkannya sendiri di tempatmu. opor ayam boleh diolah dengan bermacam cara. Kini sudah banyak cara modern yang membuat opor ayam semakin nikmat.

Resep opor ayam juga gampang dihidangkan, lho. Kalian tidak perlu capek-capek untuk membeli opor ayam, karena Anda dapat menyajikan di rumah sendiri. Untuk Anda yang akan menyajikannya, berikut cara untuk menyajikan opor ayam yang lezat yang dapat Kita hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Opor ayam:

1. Siapkan 1 ekor ayam
1. Siapkan 1 liter air putih campur dgn 2 bungkus santan kara
1. Ambil 3 buah kentang (potong dadu)
1. Sediakan 3 buah wortel (potong dadu)
1. Sediakan 3 helai daun bawang (ptong2)
1. Ambil  Gula, garam, penyedap
1. Siapkan Secukupnya minyak
1. Siapkan  Bumbu halus:
1. Ambil 6 siung bawang putih
1. Ambil 6 siung bawang merah
1. Sediakan 3 buah cabe rawit + 4 buah cabe merah kriting
1. Siapkan 1-2 ruas jari kunyit
1. Ambil 3 buah kemiri
1. Gunakan  Bumbu kasar:
1. Gunakan 2 ruas jari jahe (geprek)
1. Ambil 2 ruas jari lengkuas (geprek)
1. Sediakan 1 batang sereh (geprek)
1. Siapkan 2 lembar daun salam




<!--inarticleads2-->

##### Langkah-langkah membuat Opor ayam:

1. Tumis bumbu halus smpe harum, lalu masukan bumbu kasar nya dan lanjut tumis
1. Masukan ayam, aduk2
1. Masukan air santan, aduk2 jgn smpe santan pecah (kompor pke api sedang aja)
1. Setelah air santan mendidih masukan kentang + wortel
1. Masukan gula, garam, penyedap (takaran bisa di sesuaikan)
1. Aduk2 dan tes rasa, jika rasa udh pas aduk skali2 smpe kentang dan wortel empuk
1. Jika smua udah empuk taburkan daun bawang, aduk dan angkat. (bisa taburkan bawang merah goreng jg klo suka tpi dsini ak skip)




Wah ternyata cara buat opor ayam yang lezat tidak rumit ini mudah sekali ya! Kita semua mampu memasaknya. Cara buat opor ayam Sangat sesuai banget buat kita yang baru belajar memasak ataupun juga untuk kalian yang sudah pandai dalam memasak.

Apakah kamu ingin mencoba membikin resep opor ayam lezat tidak ribet ini? Kalau kamu tertarik, mending kamu segera siapin alat dan bahan-bahannya, lalu bikin deh Resep opor ayam yang mantab dan sederhana ini. Sungguh taidak sulit kan. 

Jadi, ketimbang kita berfikir lama-lama, ayo kita langsung hidangkan resep opor ayam ini. Dijamin anda gak akan nyesel membuat resep opor ayam mantab tidak ribet ini! Selamat berkreasi dengan resep opor ayam enak tidak rumit ini di rumah kalian sendiri,ya!.

