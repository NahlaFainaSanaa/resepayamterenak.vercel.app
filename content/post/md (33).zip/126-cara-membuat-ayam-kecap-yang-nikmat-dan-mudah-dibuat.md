---
description: "Cara membuat Ayam kecap yang nikmat dan Mudah Dibuat"
title: "Cara membuat Ayam kecap yang nikmat dan Mudah Dibuat"
slug: 126-cara-membuat-ayam-kecap-yang-nikmat-dan-mudah-dibuat
date: 2021-03-08T03:13:17.184Z
image: https://img-global.cpcdn.com/recipes/89677615a7fede3c/680x482cq70/ayam-kecap-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/89677615a7fede3c/680x482cq70/ayam-kecap-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/89677615a7fede3c/680x482cq70/ayam-kecap-foto-resep-utama.jpg
author: Joshua Glover
ratingvalue: 3.7
reviewcount: 14
recipeingredient:
- "10 potong ayam"
- " jeruk nipis"
- " garam"
- " bawang merah"
- " bawang putih"
- " bawang bombay"
- " lada bubuk"
- " pala bubuk"
- " cabe merah"
- " jahe"
- " saos tomat"
- " kecap"
- " gula"
- " sereh"
- " daun salam"
- " daun jeruk"
- " lengkuas laja"
- " garam"
- " penyedapsy pake pecin"
recipeinstructions:
- "Ayam potong cuci bersih,tambah perasan jeruk nipis,garam..tunggu beberapa menit"
- "Goreng ayam (kalau saya suka yg kering)"
- "Iris semua bahan..bawang merah bawang putih jahe laja bombay sereh cabe"
- "Tumis bahan yg td di iris tambah gula,saos tomat, kecap, lada,pala(sedikit)"
- "Koreksi rasa + sedikit air+garam+penyedap..masukan ayam tunggu hingga meresap,koreksi rasa kembali.."
categories:
- Resep
tags:
- ayam
- kecap

katakunci: ayam kecap 
nutrition: 285 calories
recipecuisine: Indonesian
preptime: "PT36M"
cooktime: "PT43M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam kecap](https://img-global.cpcdn.com/recipes/89677615a7fede3c/680x482cq70/ayam-kecap-foto-resep-utama.jpg)

Sebagai seorang wanita, menyediakan hidangan enak pada orang tercinta adalah suatu hal yang membahagiakan bagi kamu sendiri. Kewajiban seorang  wanita Tidak saja mengatur rumah saja, tapi anda pun harus menyediakan kebutuhan nutrisi tercukupi dan juga hidangan yang disantap orang tercinta harus sedap.

Di zaman  saat ini, kamu sebenarnya dapat memesan olahan instan tidak harus capek membuatnya terlebih dahulu. Namun banyak juga orang yang selalu mau memberikan makanan yang terenak bagi keluarganya. Lantaran, memasak yang diolah sendiri jauh lebih higienis dan kita pun bisa menyesuaikan masakan tersebut berdasarkan makanan kesukaan keluarga. 



Apakah kamu seorang penikmat ayam kecap?. Tahukah kamu, ayam kecap adalah makanan khas di Nusantara yang kini disukai oleh setiap orang di berbagai daerah di Nusantara. Kamu bisa menyajikan ayam kecap sendiri di rumahmu dan dapat dijadikan hidangan kesukaanmu di akhir pekan.

Anda tak perlu bingung untuk mendapatkan ayam kecap, sebab ayam kecap mudah untuk ditemukan dan kalian pun dapat membuatnya sendiri di rumah. ayam kecap dapat dibuat lewat beragam cara. Sekarang ada banyak sekali cara kekinian yang menjadikan ayam kecap semakin mantap.

Resep ayam kecap pun gampang sekali dibuat, lho. Kita tidak usah repot-repot untuk memesan ayam kecap, lantaran Kita bisa menyajikan di rumahmu. Bagi Anda yang akan membuatnya, di bawah ini adalah resep untuk membuat ayam kecap yang mantab yang mampu Kita buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Ayam kecap:

1. Siapkan 10 potong ayam
1. Sediakan  jeruk nipis
1. Ambil  garam
1. Gunakan  bawang merah
1. Sediakan  bawang putih
1. Siapkan  bawang bombay
1. Ambil  lada bubuk
1. Ambil  pala bubuk
1. Ambil  cabe merah
1. Gunakan  jahe
1. Gunakan  saos tomat
1. Sediakan  kecap
1. Ambil  gula
1. Sediakan  sereh
1. Ambil  daun salam
1. Sediakan  daun jeruk
1. Sediakan  lengkuas (laja)
1. Siapkan  garam
1. Ambil  penyedap(sy pake pecin)




<!--inarticleads2-->

##### Cara menyiapkan Ayam kecap:

1. Ayam potong cuci bersih,tambah perasan jeruk nipis,garam..tunggu beberapa menit
1. Goreng ayam (kalau saya suka yg kering)
1. Iris semua bahan..bawang merah bawang putih jahe laja bombay sereh cabe
1. Tumis bahan yg td di iris tambah gula,saos tomat, kecap, lada,pala(sedikit)
1. Koreksi rasa + sedikit air+garam+penyedap..masukan ayam tunggu hingga meresap,koreksi rasa kembali..




Wah ternyata cara membuat ayam kecap yang lezat tidak rumit ini enteng banget ya! Semua orang mampu menghidangkannya. Cara Membuat ayam kecap Sesuai banget buat anda yang sedang belajar memasak ataupun bagi kalian yang telah ahli memasak.

Apakah kamu ingin mulai mencoba bikin resep ayam kecap nikmat tidak rumit ini? Kalau kamu mau, ayo kalian segera siapkan alat-alat dan bahan-bahannya, lalu buat deh Resep ayam kecap yang nikmat dan tidak rumit ini. Betul-betul mudah kan. 

Maka, daripada kalian berlama-lama, yuk kita langsung bikin resep ayam kecap ini. Dijamin kalian gak akan menyesal sudah membuat resep ayam kecap enak tidak ribet ini! Selamat berkreasi dengan resep ayam kecap lezat sederhana ini di tempat tinggal masing-masing,ya!.

