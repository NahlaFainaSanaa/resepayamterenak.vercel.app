---
description: "Cara buat Fried Chicken // Ayam Goreng Tepung Krispy yang enak dan Mudah Dibuat"
title: "Cara buat Fried Chicken // Ayam Goreng Tepung Krispy yang enak dan Mudah Dibuat"
slug: 146-cara-buat-fried-chicken-ayam-goreng-tepung-krispy-yang-enak-dan-mudah-dibuat
date: 2021-05-07T11:42:03.532Z
image: https://img-global.cpcdn.com/recipes/64b3e185ca12d8e1/680x482cq70/fried-chicken-ayam-goreng-tepung-krispy-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/64b3e185ca12d8e1/680x482cq70/fried-chicken-ayam-goreng-tepung-krispy-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/64b3e185ca12d8e1/680x482cq70/fried-chicken-ayam-goreng-tepung-krispy-foto-resep-utama.jpg
author: Samuel Rios
ratingvalue: 4.3
reviewcount: 11
recipeingredient:
- "500 gr Ayam"
- " Bumbu marinase"
- "1 sdt lada bubuk"
- "1 sdt garlic bubuk"
- "1 sdt kaldu ayam bubuk"
- "1/2 sdm garam"
- " Bahan celupan keringtepung bumbu"
- "150 terigu "
- "50 gr meizena"
- "1/2 sdm garam sesuai selera"
- "1 sdt lada bubuk"
- "1 sdt ketumbar bubuk"
- "1 sdt garlic bubuk"
- "1 sdt cabe bubuk"
- "1 sdt kaldu ayam bubuk"
- "1/2 sdt baking powder"
- " Bahan celupan basah"
- "1 butir telor"
- "100 ml air me sprite"
recipeinstructions:
- "Cuci ayam kemudian campur dengan bahan marinase, aduk sampai rata lalu masukkan kulkas selama minimal 30 menit"
- "Campur semua bahan tepung bumbu. Aduk rata. Lalu buat bahan pencelup, kocok lepas telor, lalu tambahkan air/sprite, kocok lagi sampai tercampur rata."
- "Keluarkan ayam dari dalam kulkas lalu masukkan kedalam tepung bumbu, aduk rata sampai seluruh permukaan ayam terbalut tepung. Lalu masukkan kedalam campuran telor, sampai seluruh permukaan ayam terbalut telor kemudian angkat dan masukkan lagi ke dalam campuran tepung lagi, gulingkan sampai seluruh permukaan ayam terbalut tepung."
- "Panaskan minyak. Ketuk² ayam sebelum masuk kedalam minyak. Lalu goreng dalam minyak yg banyak sampai kecoklatan. Saya pakai sauce pan. Kemudian angkat dan tiriskan."
- "Sajikan dengan nasi hangat dan saos sambal atau bisa digeprek dengan sambal favorit 🍗🍚👍😋"
categories:
- Resep
tags:
- fried
- chicken
- 

katakunci: fried chicken  
nutrition: 232 calories
recipecuisine: Indonesian
preptime: "PT12M"
cooktime: "PT36M"
recipeyield: "2"
recipecategory: Dessert

---


![Fried Chicken // Ayam Goreng Tepung Krispy](https://img-global.cpcdn.com/recipes/64b3e185ca12d8e1/680x482cq70/fried-chicken-ayam-goreng-tepung-krispy-foto-resep-utama.jpg)

Sebagai seorang wanita, menyajikan olahan lezat buat keluarga tercinta adalah hal yang menggembirakan untuk anda sendiri. Tanggung jawab seorang ibu Tidak sekadar menangani rumah saja, namun anda pun harus menyediakan keperluan nutrisi tercukupi dan panganan yang dikonsumsi keluarga tercinta mesti mantab.

Di waktu  saat ini, kamu memang mampu memesan hidangan instan walaupun tidak harus capek mengolahnya dahulu. Tetapi banyak juga orang yang selalu ingin menyajikan yang terlezat untuk orang tercintanya. Lantaran, menyajikan masakan sendiri jauh lebih higienis dan bisa menyesuaikan makanan tersebut sesuai dengan makanan kesukaan keluarga. 



Apakah kamu seorang penggemar fried chicken // ayam goreng tepung krispy?. Tahukah kamu, fried chicken // ayam goreng tepung krispy merupakan sajian khas di Nusantara yang saat ini disenangi oleh orang-orang dari hampir setiap daerah di Nusantara. Kita bisa membuat fried chicken // ayam goreng tepung krispy sendiri di rumahmu dan boleh dijadikan makanan kesukaanmu di akhir pekan.

Kita jangan bingung jika kamu ingin mendapatkan fried chicken // ayam goreng tepung krispy, karena fried chicken // ayam goreng tepung krispy tidak sulit untuk ditemukan dan kamu pun bisa menghidangkannya sendiri di rumah. fried chicken // ayam goreng tepung krispy bisa dimasak memalui beragam cara. Kini pun sudah banyak banget resep modern yang membuat fried chicken // ayam goreng tepung krispy semakin mantap.

Resep fried chicken // ayam goreng tepung krispy juga sangat gampang dibikin, lho. Kita tidak perlu repot-repot untuk memesan fried chicken // ayam goreng tepung krispy, lantaran Anda dapat menyiapkan sendiri di rumah. Bagi Kamu yang ingin mencobanya, di bawah ini adalah resep untuk menyajikan fried chicken // ayam goreng tepung krispy yang enak yang mampu Kalian coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Fried Chicken // Ayam Goreng Tepung Krispy:

1. Siapkan 500 gr Ayam
1. Ambil  Bumbu marinase:
1. Gunakan 1 sdt lada bubuk
1. Sediakan 1 sdt garlic bubuk
1. Siapkan 1 sdt kaldu ayam bubuk
1. Siapkan 1/2 sdm garam
1. Ambil  Bahan celupan kering/tepung bumbu:
1. Siapkan 150 terigu Δ
1. Gunakan 50 gr meizena
1. Sediakan 1/2 sdm garam (sesuai selera)
1. Gunakan 1 sdt lada bubuk
1. Sediakan 1 sdt ketumbar bubuk
1. Siapkan 1 sdt garlic bubuk
1. Sediakan 1 sdt cabe bubuk
1. Sediakan 1 sdt kaldu ayam bubuk
1. Siapkan 1/2 sdt baking powder
1. Sediakan  Bahan celupan basah:
1. Sediakan 1 butir telor
1. Ambil 100 ml air (me: sprite)




<!--inarticleads2-->

##### Langkah-langkah membuat Fried Chicken // Ayam Goreng Tepung Krispy:

1. Cuci ayam kemudian campur dengan bahan marinase, aduk sampai rata lalu masukkan kulkas selama minimal 30 menit
1. Campur semua bahan tepung bumbu. Aduk rata. Lalu buat bahan pencelup, kocok lepas telor, lalu tambahkan air/sprite, kocok lagi sampai tercampur rata.
1. Keluarkan ayam dari dalam kulkas lalu masukkan kedalam tepung bumbu, aduk rata sampai seluruh permukaan ayam terbalut tepung. Lalu masukkan kedalam campuran telor, sampai seluruh permukaan ayam terbalut telor kemudian angkat dan masukkan lagi ke dalam campuran tepung lagi, gulingkan sampai seluruh permukaan ayam terbalut tepung.
1. Panaskan minyak. Ketuk² ayam sebelum masuk kedalam minyak. Lalu goreng dalam minyak yg banyak sampai kecoklatan. Saya pakai sauce pan. Kemudian angkat dan tiriskan.
1. Sajikan dengan nasi hangat dan saos sambal atau bisa digeprek dengan sambal favorit 🍗🍚👍😋




Wah ternyata cara buat fried chicken // ayam goreng tepung krispy yang enak tidak ribet ini gampang banget ya! Kita semua mampu membuatnya. Resep fried chicken // ayam goreng tepung krispy Sangat cocok sekali untuk kamu yang baru belajar memasak ataupun juga untuk anda yang sudah jago dalam memasak.

Apakah kamu mau mencoba membikin resep fried chicken // ayam goreng tepung krispy enak tidak ribet ini? Kalau kalian tertarik, mending kamu segera buruan siapkan alat-alat dan bahan-bahannya, lalu bikin deh Resep fried chicken // ayam goreng tepung krispy yang mantab dan sederhana ini. Sungguh gampang kan. 

Maka, ketimbang kita berlama-lama, yuk langsung aja bikin resep fried chicken // ayam goreng tepung krispy ini. Dijamin kamu gak akan menyesal sudah bikin resep fried chicken // ayam goreng tepung krispy mantab simple ini! Selamat mencoba dengan resep fried chicken // ayam goreng tepung krispy enak tidak ribet ini di tempat tinggal kalian masing-masing,oke!.

