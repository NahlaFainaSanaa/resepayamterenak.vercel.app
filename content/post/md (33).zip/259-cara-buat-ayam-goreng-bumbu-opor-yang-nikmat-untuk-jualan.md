---
description: "Cara buat Ayam goreng bumbu opor yang nikmat Untuk Jualan"
title: "Cara buat Ayam goreng bumbu opor yang nikmat Untuk Jualan"
slug: 259-cara-buat-ayam-goreng-bumbu-opor-yang-nikmat-untuk-jualan
date: 2021-07-07T05:30:47.099Z
image: https://img-global.cpcdn.com/recipes/a5764413ea49fc22/680x482cq70/ayam-goreng-bumbu-opor-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a5764413ea49fc22/680x482cq70/ayam-goreng-bumbu-opor-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a5764413ea49fc22/680x482cq70/ayam-goreng-bumbu-opor-foto-resep-utama.jpg
author: George Hogan
ratingvalue: 4.1
reviewcount: 3
recipeingredient:
- "700 gr ayam potong 4 bagian"
- "2 buah jeruk nipis"
- "1 sdt jinten"
- "1 sdt merica"
- "1 sdt ketumbar"
- "1 cm kayu manis"
- "1 butir kapulaga"
- "4 helai daun jeruk"
- "8 siung bawang merah"
- "2 sdm bawang putih goreng"
- "3 sdt garam"
- "3 sdt gula"
- "1/4 sdt kunyit bubuk"
- "1/2 sdt temulawak"
- "2 sdm minyak untuk menumis bumbu"
- "1 shc santan instan"
- "500 ml air"
recipeinstructions:
- "Lumuri ayam dg perasan jeruk nipis. Diamkan 15 menit, lalu bilas dan cuci hingga bersih."
- "Rebus ayam dalam air mendidih 5 menit sambil dibolak-balik agar matang merata."
- "Lalu matikan kompor dan biarkan panci tertutup 20 menit. Kemudian tiriskan ayam dan buang air bekas rebusannya."
- "Tumis seluruh bumbu yg telah dihaluskan, lalu masukkan air dan bumbu pelengkap nya"
- "Masukkan ayam yg sudah direbus tadi, lalu masak hingga kuah menyusut kurang lebih 10 menit sambil dibolak-balik agar bumbu meresap."
- "Matikan kompor, diamkan dalam keadaan tertutup selama 20 menit. Lalu tiriskan dan sisihkan diwadah untuk disimpan dalam kulkas, atau langsung digoreng dan disajikan dg nasi hangat dan lalapan."
categories:
- Resep
tags:
- ayam
- goreng
- bumbu

katakunci: ayam goreng bumbu 
nutrition: 142 calories
recipecuisine: Indonesian
preptime: "PT37M"
cooktime: "PT60M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam goreng bumbu opor](https://img-global.cpcdn.com/recipes/a5764413ea49fc22/680x482cq70/ayam-goreng-bumbu-opor-foto-resep-utama.jpg)

Selaku seorang wanita, menyuguhkan masakan menggugah selera kepada keluarga tercinta merupakan hal yang mengasyikan bagi anda sendiri. Peran seorang ibu bukan sekedar menjaga rumah saja, tapi kamu pun harus memastikan kebutuhan gizi terpenuhi dan panganan yang dimakan keluarga tercinta harus mantab.

Di era  saat ini, kita sebenarnya bisa memesan santapan instan meski tidak harus susah membuatnya dulu. Namun ada juga lho mereka yang memang mau memberikan hidangan yang terlezat untuk keluarganya. Sebab, menyajikan masakan yang diolah sendiri akan jauh lebih higienis dan bisa menyesuaikan masakan tersebut berdasarkan kesukaan orang tercinta. 



Apakah anda adalah seorang penyuka ayam goreng bumbu opor?. Asal kamu tahu, ayam goreng bumbu opor adalah hidangan khas di Nusantara yang sekarang disukai oleh orang-orang di berbagai tempat di Indonesia. Kamu dapat memasak ayam goreng bumbu opor kreasi sendiri di rumah dan dapat dijadikan camilan favoritmu di akhir pekan.

Anda jangan bingung jika kamu ingin menyantap ayam goreng bumbu opor, lantaran ayam goreng bumbu opor sangat mudah untuk dicari dan kamu pun dapat mengolahnya sendiri di tempatmu. ayam goreng bumbu opor dapat dimasak lewat beragam cara. Sekarang sudah banyak cara modern yang menjadikan ayam goreng bumbu opor semakin mantap.

Resep ayam goreng bumbu opor pun mudah sekali untuk dibikin, lho. Kamu jangan ribet-ribet untuk memesan ayam goreng bumbu opor, sebab Anda dapat menghidangkan di rumah sendiri. Bagi Kamu yang ingin mencobanya, di bawah ini adalah resep untuk membuat ayam goreng bumbu opor yang enak yang mampu Kita hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Ayam goreng bumbu opor:

1. Siapkan 700 gr ayam potong 4 bagian
1. Sediakan 2 buah jeruk nipis
1. Siapkan 1 sdt jinten
1. Gunakan 1 sdt merica
1. Gunakan 1 sdt ketumbar
1. Sediakan 1 cm kayu manis
1. Gunakan 1 butir kapulaga
1. Ambil 4 helai daun jeruk
1. Gunakan 8 siung bawang merah
1. Gunakan 2 sdm bawang putih goreng
1. Ambil 3 sdt garam
1. Siapkan 3 sdt gula
1. Ambil 1/4 sdt kunyit bubuk
1. Siapkan 1/2 sdt temulawak
1. Sediakan 2 sdm minyak untuk menumis bumbu
1. Ambil 1 shc santan instan
1. Siapkan 500 ml air




<!--inarticleads2-->

##### Cara menyiapkan Ayam goreng bumbu opor:

1. Lumuri ayam dg perasan jeruk nipis. Diamkan 15 menit, lalu bilas dan cuci hingga bersih.
1. Rebus ayam dalam air mendidih 5 menit sambil dibolak-balik agar matang merata.
1. Lalu matikan kompor dan biarkan panci tertutup 20 menit. Kemudian tiriskan ayam dan buang air bekas rebusannya.
1. Tumis seluruh bumbu yg telah dihaluskan, lalu masukkan air dan bumbu pelengkap nya
1. Masukkan ayam yg sudah direbus tadi, lalu masak hingga kuah menyusut kurang lebih 10 menit sambil dibolak-balik agar bumbu meresap.
1. Matikan kompor, diamkan dalam keadaan tertutup selama 20 menit. Lalu tiriskan dan sisihkan diwadah untuk disimpan dalam kulkas, atau langsung digoreng dan disajikan dg nasi hangat dan lalapan.




Ternyata cara membuat ayam goreng bumbu opor yang nikamt tidak ribet ini mudah banget ya! Anda Semua mampu mencobanya. Cara buat ayam goreng bumbu opor Sangat sesuai banget untuk anda yang baru akan belajar memasak ataupun juga untuk anda yang sudah hebat dalam memasak.

Apakah kamu tertarik mulai mencoba membuat resep ayam goreng bumbu opor lezat simple ini? Kalau kalian ingin, yuk kita segera buruan menyiapkan alat-alat dan bahannya, kemudian bikin deh Resep ayam goreng bumbu opor yang enak dan tidak rumit ini. Sungguh taidak sulit kan. 

Oleh karena itu, ketimbang kita berfikir lama-lama, hayo kita langsung saja sajikan resep ayam goreng bumbu opor ini. Dijamin anda gak akan menyesal sudah buat resep ayam goreng bumbu opor mantab tidak ribet ini! Selamat mencoba dengan resep ayam goreng bumbu opor mantab tidak ribet ini di rumah kalian masing-masing,ya!.

