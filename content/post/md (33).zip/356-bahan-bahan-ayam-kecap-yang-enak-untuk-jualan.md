---
description: "Bahan-bahan Ayam Kecap yang enak Untuk Jualan"
title: "Bahan-bahan Ayam Kecap yang enak Untuk Jualan"
slug: 356-bahan-bahan-ayam-kecap-yang-enak-untuk-jualan
date: 2021-05-18T01:25:34.691Z
image: https://img-global.cpcdn.com/recipes/57e557a88a489d85/680x482cq70/ayam-kecap-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/57e557a88a489d85/680x482cq70/ayam-kecap-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/57e557a88a489d85/680x482cq70/ayam-kecap-foto-resep-utama.jpg
author: Nell Beck
ratingvalue: 4.3
reviewcount: 15
recipeingredient:
- "1 ekor ayam kampung kecil potong 4 bagian"
- "3 siung bawang putih"
- "1 siung bawang bombay kecil"
- "1 ruas jahe geprek"
- "3 batang daun bawang"
- "1 sdm saua tiram"
- "1/2 sdt saus rajarasa"
- "1/2 sdt minyak wijen"
- "1/2 sdt kecap inggris"
- "3 sdm kecap manis"
- "1/2 sdt kecap asin"
- "Secukupnya lada"
- "Secukupnya garam"
- "Secukupnya kaldu jamur"
- "1 buah jeruk nipis untuk mencuci ayam"
- "Secukupnya margarine"
- "Secukupnya minyak goreng"
- "100 ml air"
recipeinstructions:
- "Cuci bersih ayam lalu beri perasan jeruk nipis dan bilas"
- "Presto ayam ± 10 menit, setelah itu angkat."
- "Masukkan 2 sdm margarine dan 10 sdm minyak goreng, goreng ayam sebentar, lalu angkat dan sisihkan."
- "Panaskan 3 sdm margarine tumis bawang putih dan jahe hingga harum"
- "Tambahkan 100ml air lalu masukkan saus tiram, kecap inggris, kecap asin, saus rajarasa, minyak wijen, kecap manis, lada, garam, kaldu jamur lalh aduk rata."
- "Tunggu hingga air mendidih lalu masukkan ayam dan aduk rata, tambahkan bawang bombay dan daun bawang aduk dan cicipi rasa, jika sudah pas angkat dan sajikan"
categories:
- Resep
tags:
- ayam
- kecap

katakunci: ayam kecap 
nutrition: 118 calories
recipecuisine: Indonesian
preptime: "PT35M"
cooktime: "PT59M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Kecap](https://img-global.cpcdn.com/recipes/57e557a88a489d85/680x482cq70/ayam-kecap-foto-resep-utama.jpg)

Sebagai seorang yang hobi masak, menyediakan olahan mantab pada keluarga merupakan hal yang mengasyikan untuk kita sendiri. Peran seorang  wanita bukan sekadar menangani rumah saja, namun kamu juga wajib menyediakan keperluan gizi tercukupi dan hidangan yang disantap anak-anak mesti lezat.

Di waktu  saat ini, kita sebenarnya bisa memesan hidangan siap saji tanpa harus ribet mengolahnya lebih dulu. Namun ada juga mereka yang selalu mau memberikan yang terenak bagi keluarganya. Pasalnya, memasak yang diolah sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan berdasarkan kesukaan famili. 



Mungkinkah kamu salah satu penikmat ayam kecap?. Tahukah kamu, ayam kecap merupakan makanan khas di Nusantara yang sekarang disenangi oleh orang-orang di berbagai wilayah di Nusantara. Kalian bisa membuat ayam kecap hasil sendiri di rumahmu dan dapat dijadikan hidangan kesenanganmu di hari libur.

Kalian tidak perlu bingung jika kamu ingin memakan ayam kecap, lantaran ayam kecap sangat mudah untuk ditemukan dan juga kamu pun bisa membuatnya sendiri di rumah. ayam kecap dapat dimasak memalui beragam cara. Kini pun sudah banyak cara modern yang menjadikan ayam kecap semakin mantap.

Resep ayam kecap pun mudah dibuat, lho. Kalian jangan repot-repot untuk memesan ayam kecap, tetapi Kalian bisa menghidangkan di rumahmu. Bagi Kamu yang hendak mencobanya, di bawah ini adalah resep untuk membuat ayam kecap yang mantab yang mampu Kalian coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Ayam Kecap:

1. Siapkan 1 ekor ayam kampung kecil (potong 4 bagian)
1. Sediakan 3 siung bawang putih
1. Sediakan 1 siung bawang bombay kecil
1. Gunakan 1 ruas jahe (geprek)
1. Gunakan 3 batang daun bawang
1. Ambil 1 sdm saua tiram
1. Siapkan 1/2 sdt saus rajarasa
1. Gunakan 1/2 sdt minyak wijen
1. Ambil 1/2 sdt kecap inggris
1. Sediakan 3 sdm kecap manis
1. Sediakan 1/2 sdt kecap asin
1. Siapkan Secukupnya lada
1. Sediakan Secukupnya garam
1. Ambil Secukupnya kaldu jamur
1. Gunakan 1 buah jeruk nipis (untuk mencuci ayam)
1. Ambil Secukupnya margarine
1. Sediakan Secukupnya minyak goreng
1. Ambil 100 ml air




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam Kecap:

1. Cuci bersih ayam lalu beri perasan jeruk nipis dan bilas
1. Presto ayam ± 10 menit, setelah itu angkat.
1. Masukkan 2 sdm margarine dan 10 sdm minyak goreng, goreng ayam sebentar, lalu angkat dan sisihkan.
1. Panaskan 3 sdm margarine tumis bawang putih dan jahe hingga harum
1. Tambahkan 100ml air lalu masukkan saus tiram, kecap inggris, kecap asin, saus rajarasa, minyak wijen, kecap manis, lada, garam, kaldu jamur lalh aduk rata.
1. Tunggu hingga air mendidih lalu masukkan ayam dan aduk rata, tambahkan bawang bombay dan daun bawang aduk dan cicipi rasa, jika sudah pas angkat dan sajikan




Ternyata resep ayam kecap yang lezat tidak ribet ini mudah sekali ya! Kita semua bisa menghidangkannya. Cara buat ayam kecap Sangat sesuai sekali buat kita yang baru belajar memasak ataupun untuk anda yang sudah jago memasak.

Apakah kamu tertarik mencoba buat resep ayam kecap enak tidak ribet ini? Kalau mau, mending kamu segera buruan siapin peralatan dan bahan-bahannya, setelah itu bikin deh Resep ayam kecap yang mantab dan tidak rumit ini. Sangat taidak sulit kan. 

Oleh karena itu, daripada kamu diam saja, yuk kita langsung saja buat resep ayam kecap ini. Dijamin anda gak akan menyesal membuat resep ayam kecap lezat tidak rumit ini! Selamat mencoba dengan resep ayam kecap lezat tidak ribet ini di rumah sendiri,oke!.

