---
description: "Cara buat Opor ayam yang nikmat Untuk Jualan"
title: "Cara buat Opor ayam yang nikmat Untuk Jualan"
slug: 214-cara-buat-opor-ayam-yang-nikmat-untuk-jualan
date: 2021-04-20T20:24:48.978Z
image: https://img-global.cpcdn.com/recipes/e858518107323b0d/680x482cq70/opor-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e858518107323b0d/680x482cq70/opor-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e858518107323b0d/680x482cq70/opor-ayam-foto-resep-utama.jpg
author: Marion Vargas
ratingvalue: 4.5
reviewcount: 14
recipeingredient:
- "1 Kg ayam"
- "1/2 kg kentang"
- "5 siung bawang merah"
- "4 siung bawang putih"
- "1 santan kara 65 ml"
- "4 butir kemiri"
- "1 sdt ketumbar bubuk"
- "1 sdm garam"
- "1/2 sdt penyedap rasa"
- "secukupnya Daun salam"
- "1 batang Serai"
- "2 lembar daun jeruk"
- "1 ruas lengkuas geprek"
- "1 sdt kunyit bubuk"
- " Minyak goreng untuk menumis"
- " Bawang goreng"
recipeinstructions:
- "Potong ayam sesuai selera, kemudian cuci besih"
- "Haluskan bawang merah, bawang putih, dan kemiri. Lalu tumis bumbi halus tambahkan ketumbar bubuk, kunyit bubuk, daun salam, daun jeruk, serai dan lengkuas. Tumis semua bumbu hingga harum."
- "Setelah bumbu matang, tuang 1sachet santan kara dan tambahkan 1 liter air. Masukkan ayam dan kentang yang dipotong sesuai selera rebus hingga empuk."
- "Uji rasa dengan menambahkan garam dan penyedap rasa secukupnya. Setelah matang angkat dan beri taburan bawang goreng."
categories:
- Resep
tags:
- opor
- ayam

katakunci: opor ayam 
nutrition: 152 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT60M"
recipeyield: "3"
recipecategory: Dinner

---


![Opor ayam](https://img-global.cpcdn.com/recipes/e858518107323b0d/680x482cq70/opor-ayam-foto-resep-utama.jpg)

Sebagai seorang istri, menyajikan panganan enak untuk keluarga merupakan suatu hal yang membahagiakan bagi anda sendiri. Tanggung jawab seorang  wanita bukan cuman mengurus rumah saja, tapi kamu juga wajib menyediakan keperluan gizi tercukupi dan olahan yang disantap orang tercinta wajib lezat.

Di waktu  sekarang, anda sebenarnya bisa membeli masakan instan walaupun tidak harus capek membuatnya terlebih dahulu. Tapi ada juga mereka yang memang mau memberikan makanan yang terenak untuk orang yang dicintainya. Karena, menghidangkan masakan sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan masakan tersebut sesuai makanan kesukaan keluarga. 



Mungkinkah kamu salah satu penikmat opor ayam?. Tahukah kamu, opor ayam merupakan sajian khas di Indonesia yang saat ini disukai oleh orang-orang di hampir setiap wilayah di Indonesia. Kita dapat memasak opor ayam sendiri di rumah dan boleh jadi camilan kegemaranmu di hari libur.

Kita tidak usah bingung untuk memakan opor ayam, karena opor ayam tidak sulit untuk ditemukan dan kamu pun dapat membuatnya sendiri di rumah. opor ayam bisa dibuat memalui beragam cara. Kini pun telah banyak cara modern yang membuat opor ayam semakin lebih mantap.

Resep opor ayam pun mudah dihidangkan, lho. Kalian tidak usah ribet-ribet untuk memesan opor ayam, karena Kita bisa menyiapkan sendiri di rumah. Bagi Anda yang hendak menghidangkannya, berikut ini resep untuk membuat opor ayam yang enak yang mampu Kalian hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Opor ayam:

1. Ambil 1 Kg ayam
1. Gunakan 1/2 kg kentang
1. Ambil 5 siung bawang merah
1. Sediakan 4 siung bawang putih
1. Gunakan 1 santan kara 65 ml
1. Ambil 4 butir kemiri
1. Sediakan 1 sdt ketumbar bubuk
1. Gunakan 1 sdm garam
1. Sediakan 1/2 sdt penyedap rasa
1. Ambil secukupnya Daun salam
1. Sediakan 1 batang Serai
1. Gunakan 2 lembar daun jeruk
1. Ambil 1 ruas lengkuas geprek
1. Ambil 1 sdt kunyit bubuk
1. Gunakan  Minyak goreng untuk menumis
1. Gunakan  Bawang goreng




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Opor ayam:

1. Potong ayam sesuai selera, kemudian cuci besih
1. Haluskan bawang merah, bawang putih, dan kemiri. Lalu tumis bumbi halus tambahkan ketumbar bubuk, kunyit bubuk, daun salam, daun jeruk, serai dan lengkuas. Tumis semua bumbu hingga harum.
1. Setelah bumbu matang, tuang 1sachet santan kara dan tambahkan 1 liter air. Masukkan ayam dan kentang yang dipotong sesuai selera rebus hingga empuk.
1. Uji rasa dengan menambahkan garam dan penyedap rasa secukupnya. Setelah matang angkat dan beri taburan bawang goreng.




Wah ternyata cara membuat opor ayam yang enak sederhana ini mudah banget ya! Anda Semua bisa memasaknya. Cara Membuat opor ayam Sesuai sekali buat kalian yang baru belajar memasak atau juga untuk kalian yang sudah ahli memasak.

Tertarik untuk mulai mencoba bikin resep opor ayam nikmat tidak ribet ini? Kalau kalian mau, ayo kamu segera buruan siapkan alat-alat dan bahan-bahannya, setelah itu bikin deh Resep opor ayam yang mantab dan tidak ribet ini. Benar-benar mudah kan. 

Oleh karena itu, ketimbang kamu diam saja, maka kita langsung buat resep opor ayam ini. Dijamin kalian tak akan menyesal sudah buat resep opor ayam lezat tidak rumit ini! Selamat berkreasi dengan resep opor ayam nikmat sederhana ini di rumah masing-masing,oke!.

