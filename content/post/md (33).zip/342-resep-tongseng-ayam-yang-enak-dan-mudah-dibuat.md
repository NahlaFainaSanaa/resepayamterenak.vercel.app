---
description: "Resep Tongseng Ayam yang enak dan Mudah Dibuat"
title: "Resep Tongseng Ayam yang enak dan Mudah Dibuat"
slug: 342-resep-tongseng-ayam-yang-enak-dan-mudah-dibuat
date: 2021-04-16T00:37:20.455Z
image: https://img-global.cpcdn.com/recipes/61bd62d98cd7dba1/680x482cq70/tongseng-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/61bd62d98cd7dba1/680x482cq70/tongseng-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/61bd62d98cd7dba1/680x482cq70/tongseng-ayam-foto-resep-utama.jpg
author: Martin Boyd
ratingvalue: 3.3
reviewcount: 8
recipeingredient:
- "1/2 kg ayam aku campur sama fillet dada"
- "750 ml air matang"
- "200 gr kol"
- "1 buah tomat ukuran sedang"
- "1 batang daun bawang"
- "10 cabai rawit"
- " Bumbu halus"
- "10 butir bawang merah iris 2 butir"
- "4 bawang putih"
- "1 ruas jahe"
- "1 ruas kunyit"
- "3 butir kemiri"
- "1 sdm ketumbar bubuk"
- " Bahan cemplung"
- "4 lembar daun salam"
- "4 lembar daun jeruk"
- "2 batang serai"
- "2 ruas lengkuas"
- "750 ml air"
- "1 1/2 sdt garam"
- "1 sdt penyedap"
- "Secukupnya kecap"
- "1 sdt gula pasir"
- "25 ml santan"
recipeinstructions:
- "Persiapkan semua bahan"
- "Tumis irisan bawang merah hingga harum"
- "Masukan bumbu halus, beserta bumbu cemplung, tumis hingga matang, berwarna kecoklatan. Kemudian masukan ayam aduk hingga rata"
- "Tuangkan air matang, tunggu higga mendidih kemudian masukan kecap, garam, gula, penyedap aduk rata"
- "Masukan santan dan tunggu air hingga menyusut"
- "Apabil air sudah menyusut, masukan cabai rawit, kol, tomat dan daun bawang. Tunggu hingga sayur agak layu. Tes rasa dan siap di santap"
categories:
- Resep
tags:
- tongseng
- ayam

katakunci: tongseng ayam 
nutrition: 191 calories
recipecuisine: Indonesian
preptime: "PT16M"
cooktime: "PT51M"
recipeyield: "4"
recipecategory: Lunch

---


![Tongseng Ayam](https://img-global.cpcdn.com/recipes/61bd62d98cd7dba1/680x482cq70/tongseng-ayam-foto-resep-utama.jpg)

Andai kalian seorang yang hobi memasak, mempersiapkan masakan mantab buat famili merupakan hal yang memuaskan untuk anda sendiri. Tugas seorang  wanita bukan hanya mengatur rumah saja, tapi kamu pun harus menyediakan kebutuhan gizi tercukupi dan santapan yang dikonsumsi anak-anak mesti enak.

Di waktu  saat ini, kalian memang mampu membeli santapan instan walaupun tidak harus repot mengolahnya lebih dulu. Tapi ada juga mereka yang memang mau menghidangkan yang terlezat bagi orang tercintanya. Sebab, menghidangkan masakan sendiri akan jauh lebih bersih dan bisa menyesuaikan berdasarkan kesukaan famili. 



Mungkinkah anda seorang penggemar tongseng ayam?. Tahukah kamu, tongseng ayam adalah sajian khas di Indonesia yang sekarang digemari oleh orang-orang di hampir setiap wilayah di Nusantara. Anda bisa membuat tongseng ayam kreasi sendiri di rumah dan boleh jadi santapan kegemaranmu di akhir pekanmu.

Anda jangan bingung jika kamu ingin menyantap tongseng ayam, lantaran tongseng ayam tidak sukar untuk dicari dan kalian pun bisa mengolahnya sendiri di tempatmu. tongseng ayam boleh dibuat memalui beragam cara. Saat ini telah banyak sekali cara modern yang menjadikan tongseng ayam lebih enak.

Resep tongseng ayam juga gampang sekali dibikin, lho. Kita tidak usah capek-capek untuk memesan tongseng ayam, karena Kalian bisa menyajikan di rumahmu. Untuk Kita yang hendak menyajikannya, berikut ini cara membuat tongseng ayam yang lezat yang mampu Kalian coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Tongseng Ayam:

1. Siapkan 1/2 kg ayam, aku campur sama fillet dada
1. Siapkan 750 ml air matang
1. Sediakan 200 gr kol
1. Siapkan 1 buah tomat ukuran sedang
1. Siapkan 1 batang daun bawang
1. Siapkan 10 cabai rawit
1. Siapkan  Bumbu halus
1. Siapkan 10 butir bawang merah, iris 2 butir
1. Ambil 4 bawang putih
1. Siapkan 1 ruas jahe
1. Siapkan 1 ruas kunyit
1. Sediakan 3 butir kemiri
1. Sediakan 1 sdm ketumbar bubuk
1. Siapkan  Bahan cemplung
1. Gunakan 4 lembar daun salam
1. Gunakan 4 lembar daun jeruk
1. Ambil 2 batang serai
1. Sediakan 2 ruas lengkuas
1. Ambil 750 ml air
1. Sediakan 1 1/2 sdt garam
1. Ambil 1 sdt penyedap
1. Gunakan Secukupnya kecap
1. Siapkan 1 sdt gula pasir
1. Sediakan 25 ml santan




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Tongseng Ayam:

1. Persiapkan semua bahan
1. Tumis irisan bawang merah hingga harum
1. Masukan bumbu halus, beserta bumbu cemplung, tumis hingga matang, berwarna kecoklatan. Kemudian masukan ayam aduk hingga rata
1. Tuangkan air matang, tunggu higga mendidih kemudian masukan kecap, garam, gula, penyedap aduk rata
1. Masukan santan dan tunggu air hingga menyusut
1. Apabil air sudah menyusut, masukan cabai rawit, kol, tomat dan daun bawang. Tunggu hingga sayur agak layu. Tes rasa dan siap di santap




Wah ternyata cara membuat tongseng ayam yang nikamt tidak rumit ini mudah sekali ya! Semua orang mampu memasaknya. Cara Membuat tongseng ayam Sesuai sekali buat kalian yang sedang belajar memasak ataupun juga bagi kalian yang telah lihai dalam memasak.

Tertarik untuk mencoba bikin resep tongseng ayam enak tidak rumit ini? Kalau kamu tertarik, ayo kalian segera buruan siapkan peralatan dan bahannya, setelah itu buat deh Resep tongseng ayam yang enak dan sederhana ini. Benar-benar gampang kan. 

Maka dari itu, daripada anda berlama-lama, maka langsung aja hidangkan resep tongseng ayam ini. Dijamin kalian tak akan nyesel bikin resep tongseng ayam lezat simple ini! Selamat berkreasi dengan resep tongseng ayam nikmat simple ini di rumah kalian masing-masing,ya!.

