---
description: "Cara membuat Ayam rica-rica kecap Sederhana Untuk Jualan"
title: "Cara membuat Ayam rica-rica kecap Sederhana Untuk Jualan"
slug: 319-cara-membuat-ayam-rica-rica-kecap-sederhana-untuk-jualan
date: 2021-03-15T00:32:18.472Z
image: https://img-global.cpcdn.com/recipes/933c1a988f8afca9/680x482cq70/ayam-rica-rica-kecap-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/933c1a988f8afca9/680x482cq70/ayam-rica-rica-kecap-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/933c1a988f8afca9/680x482cq70/ayam-rica-rica-kecap-foto-resep-utama.jpg
author: Rena Wise
ratingvalue: 3
reviewcount: 9
recipeingredient:
- "1 kg ayam"
- " Jeruk nipis"
- " Kecap"
- "1 sdm Gula jawa"
- "3 batang Daun bawang iris 2 cm"
- "7 lembar Daun jeruk"
- " Kayu manis opsional"
- "1 batang sereh di geprek"
- " Penyedap"
- " Minyak goreng"
- " Bumbu halus"
- "8 siung Bawang merah"
- "6 siung Bawang putih"
- "2/3 sdm Ketumbar"
- "1 1/2 biji Kemiri"
- "1/2 sdt Merica"
- "1 ruas jahe"
- "1 ruas kunyit"
- "1 ruas lengkuas"
- "3 biji Kapulaga"
- "7 buah cabe keriting"
- "7 buah cabe rawit ini blm pedes bisa ditambah kl mau pedes"
recipeinstructions:
- "Siapkan bahan. Peras jeruk nipis diatas ayam untuk menghilangkan amis, lalu cuci ayamnya."
- "Bumbu halus semua diuleg sampe halus"
- "Tumis bumbu halus sampai agak matang. Lalu masukkan ayam aduk aduk sampe tercampur merata."
- "Masukan air, daun bawang, kayu manis, daun jeruk, gula jawa, kecap, penyedap. Aduk rata. Sesuaikan kecap dan penyedap agar rasanya passs. Bisa ditambahkan cabe rawit iris kalo kurang pedas yaa.  (difoto sebenernya aku kebanyakan air, kayanya lebih dari 100ml. Nah pas masukin air dikit demi dikit aja yaa, jgn kebanyakan, lama menguapnya. Kalo ayam lehor dia cepet empuk ayamnya, jadi diaduk2 aja. Kl ayam kampung agak lama, sesuai kan aja airnya)"
- "Tips biar bumbu meresap yaitu dimasak di api kecil ya guys. Aduk sesekali. Masak sampai tidak ada air tersisa. Selamat mencoba."
categories:
- Resep
tags:
- ayam
- ricarica
- kecap

katakunci: ayam ricarica kecap 
nutrition: 216 calories
recipecuisine: Indonesian
preptime: "PT14M"
cooktime: "PT48M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam rica-rica kecap](https://img-global.cpcdn.com/recipes/933c1a988f8afca9/680x482cq70/ayam-rica-rica-kecap-foto-resep-utama.jpg)

Apabila anda seorang istri, menyuguhkan hidangan enak bagi famili merupakan hal yang memuaskan untuk kita sendiri. Tanggung jawab seorang istri bukan cuman mengurus rumah saja, tetapi anda juga harus memastikan keperluan gizi terpenuhi dan masakan yang dikonsumsi keluarga tercinta wajib enak.

Di waktu  saat ini, kalian sebenarnya dapat mengorder masakan yang sudah jadi tidak harus capek memasaknya lebih dulu. Tetapi ada juga lho mereka yang selalu mau memberikan makanan yang terbaik untuk orang yang dicintainya. Pasalnya, memasak yang dibuat sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan sesuai dengan masakan kesukaan orang tercinta. 



Mungkinkah anda salah satu penggemar ayam rica-rica kecap?. Tahukah kamu, ayam rica-rica kecap adalah hidangan khas di Nusantara yang saat ini disukai oleh orang-orang dari berbagai daerah di Nusantara. Kamu bisa memasak ayam rica-rica kecap sendiri di rumah dan dapat dijadikan santapan kesenanganmu di akhir pekan.

Kita tidak perlu bingung untuk mendapatkan ayam rica-rica kecap, karena ayam rica-rica kecap sangat mudah untuk ditemukan dan kita pun boleh menghidangkannya sendiri di tempatmu. ayam rica-rica kecap boleh diolah dengan berbagai cara. Kini ada banyak banget cara kekinian yang menjadikan ayam rica-rica kecap semakin lezat.

Resep ayam rica-rica kecap juga sangat mudah untuk dibuat, lho. Anda tidak usah repot-repot untuk memesan ayam rica-rica kecap, tetapi Kalian dapat membuatnya sendiri di rumah. Untuk Kalian yang mau membuatnya, inilah resep membuat ayam rica-rica kecap yang enak yang dapat Kalian buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Ayam rica-rica kecap:

1. Sediakan 1 kg ayam
1. Gunakan  Jeruk nipis
1. Siapkan  Kecap
1. Ambil 1 sdm Gula jawa
1. Sediakan 3 batang Daun bawang iris 2 cm
1. Siapkan 7 lembar Daun jeruk
1. Siapkan  Kayu manis (opsional)
1. Ambil 1 batang sereh di geprek
1. Siapkan  Penyedap
1. Sediakan  Minyak goreng
1. Sediakan  Bumbu halus
1. Siapkan 8 siung Bawang merah
1. Gunakan 6 siung Bawang putih
1. Ambil 2/3 sdm Ketumbar
1. Ambil 1 1/2 biji Kemiri
1. Siapkan 1/2 sdt Merica
1. Siapkan 1 ruas jahe
1. Ambil 1 ruas kunyit
1. Sediakan 1 ruas lengkuas
1. Sediakan 3 biji Kapulaga
1. Ambil 7 buah cabe keriting
1. Gunakan 7 buah cabe rawit (ini blm pedes, bisa ditambah kl mau pedes)




<!--inarticleads2-->

##### Cara membuat Ayam rica-rica kecap:

1. Siapkan bahan. Peras jeruk nipis diatas ayam untuk menghilangkan amis, lalu cuci ayamnya.
1. Bumbu halus semua diuleg sampe halus
1. Tumis bumbu halus sampai agak matang. Lalu masukkan ayam aduk aduk sampe tercampur merata.
1. Masukan air, daun bawang, kayu manis, daun jeruk, gula jawa, kecap, penyedap. Aduk rata. Sesuaikan kecap dan penyedap agar rasanya passs. Bisa ditambahkan cabe rawit iris kalo kurang pedas yaa. -  (difoto sebenernya aku kebanyakan air, kayanya lebih dari 100ml. Nah pas masukin air dikit demi dikit aja yaa, jgn kebanyakan, lama menguapnya. Kalo ayam lehor dia cepet empuk ayamnya, jadi diaduk2 aja. Kl ayam kampung agak lama, sesuai kan aja airnya)
1. Tips biar bumbu meresap yaitu dimasak di api kecil ya guys. Aduk sesekali. Masak sampai tidak ada air tersisa. Selamat mencoba.




Wah ternyata resep ayam rica-rica kecap yang nikamt simple ini mudah banget ya! Anda Semua bisa membuatnya. Resep ayam rica-rica kecap Cocok banget untuk kalian yang baru mau belajar memasak ataupun untuk kamu yang telah ahli dalam memasak.

Tertarik untuk mulai mencoba bikin resep ayam rica-rica kecap lezat tidak rumit ini? Kalau anda mau, ayo kalian segera buruan menyiapkan alat dan bahannya, lantas buat deh Resep ayam rica-rica kecap yang lezat dan tidak rumit ini. Benar-benar mudah kan. 

Maka, ketimbang anda berlama-lama, hayo kita langsung saja hidangkan resep ayam rica-rica kecap ini. Dijamin kamu tiidak akan nyesel bikin resep ayam rica-rica kecap lezat simple ini! Selamat berkreasi dengan resep ayam rica-rica kecap mantab tidak rumit ini di rumah masing-masing,ya!.

