---
description: "Cara buat Soto Ayam yang enak Untuk Jualan"
title: "Cara buat Soto Ayam yang enak Untuk Jualan"
slug: 43-cara-buat-soto-ayam-yang-enak-untuk-jualan
date: 2021-03-02T15:14:19.740Z
image: https://img-global.cpcdn.com/recipes/f72d50f2556d9875/680x482cq70/soto-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f72d50f2556d9875/680x482cq70/soto-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f72d50f2556d9875/680x482cq70/soto-ayam-foto-resep-utama.jpg
author: Chad Haynes
ratingvalue: 4
reviewcount: 8
recipeingredient:
- "1 ekor ayam potong 8 bagian"
- "1 sdt ketumbar"
- "2 cm jahe"
- "2 cm lengkuas"
- "2 cm kunyit"
- "15 bawang merah"
- "10 bawang putih"
- "1 sdt merica"
- "5 butir kemiri"
- "100 gr toge"
- "2 bungkus kecil soun"
- "2 batang daun bawang"
- "5 batang seledri"
- "3 daun jeruk 3 daun salam 3 batang sereh"
- " Sambal  15 cabe rawit  2 bawang putih"
- "2 lt air 5 sdm minyak untuk menumis"
- " Garam dan penyedap rasa opsional"
- " Jeruk nipis dipotong kecil2"
recipeinstructions:
- "Haluskan / blender : ketumbar, merica, bawang merah, bawang putih, jahe, lengkuas, kunyit, kemiri."
- "Panaskan minyak, tumis bumbu yang sudah di haluskan di dalam panci, tambahkan daun jeruk, sereh dan daun salam hingga harum aromanya.  Kemudian tambahkan air 1lt.  Tutup panci"
- "Setelah mendidih, masukkan ayam. Tambahkan garam dan penyedap rasa. Rebus hingga 30 menit."
- "Setelah bumbu meresap, keluarkan ayam dari panci.  Kemudian tambahkan air 1Lt lagi di panci, aduk sekali2."
- "Goreng ayam di minyak panas, tiriskan.  Lalu potong kecil2 / suwir.  Setelah itu masukkan lagi ke dalam panci rebusan kuah soto.  Kecilkan api dan tes rasa, bila diperlukan tambahkan garam dan penyedap rasa."
- "Bahan pelengkap : Potong/iris tipis kol.  Cuci kol dan toge. Lalu di panci lain, rebus air hingga mendidih.  Matikan api, celupkan kol, toge dan soun lalu segera tiriskan. Siapkan di mangkok."
- "Bahan tabur : Potong/iris daun bawang, seledri. Siapkan di piring kecil"
- "Sambal soto : Rebus cabe dan bawang putih. Setelah itu, uleg kasar saja.  Taruh di mangkuk kecil, lalu tuangkan 1 sendok sup kuah soto ke sambal."
- "Penyajian : taruh bahan tabur, soun, kol dan toge di mangkok. Siram dengan kuah soto. Tambahkan sambal dan jeruk nipis. Nikmati selagi hangat. Silahkan mencoba"
categories:
- Resep
tags:
- soto
- ayam

katakunci: soto ayam 
nutrition: 295 calories
recipecuisine: Indonesian
preptime: "PT29M"
cooktime: "PT37M"
recipeyield: "3"
recipecategory: Dessert

---


![Soto Ayam](https://img-global.cpcdn.com/recipes/f72d50f2556d9875/680x482cq70/soto-ayam-foto-resep-utama.jpg)

Selaku seorang yang hobi masak, menyajikan hidangan enak kepada orang tercinta merupakan hal yang mengasyikan bagi kita sendiri. Peran seorang istri bukan cuma menangani rumah saja, namun anda juga wajib memastikan kebutuhan gizi terpenuhi dan panganan yang dimakan anak-anak harus sedap.

Di waktu  saat ini, kita memang mampu membeli hidangan yang sudah jadi meski tidak harus ribet membuatnya dulu. Namun banyak juga mereka yang memang mau memberikan hidangan yang terbaik bagi keluarganya. Sebab, menyajikan masakan yang diolah sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan hidangan tersebut sesuai dengan makanan kesukaan keluarga. 



Mungkinkah anda seorang penyuka soto ayam?. Asal kamu tahu, soto ayam merupakan makanan khas di Indonesia yang saat ini disenangi oleh orang-orang di berbagai wilayah di Nusantara. Kamu dapat menyajikan soto ayam hasil sendiri di rumah dan dapat dijadikan camilan kesukaanmu di hari libur.

Kamu tidak perlu bingung untuk memakan soto ayam, lantaran soto ayam tidak sukar untuk didapatkan dan anda pun boleh menghidangkannya sendiri di rumah. soto ayam dapat diolah memalui beraneka cara. Kini telah banyak resep kekinian yang membuat soto ayam semakin lezat.

Resep soto ayam juga mudah dihidangkan, lho. Kamu tidak usah repot-repot untuk membeli soto ayam, sebab Kita dapat membuatnya ditempatmu. Untuk Kita yang hendak mencobanya, berikut ini cara untuk membuat soto ayam yang nikamat yang mampu Anda hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Soto Ayam:

1. Siapkan 1 ekor ayam potong 8 bagian
1. Siapkan 1 sdt ketumbar
1. Sediakan 2 cm jahe
1. Sediakan 2 cm lengkuas
1. Siapkan 2 cm kunyit
1. Siapkan 15 bawang merah
1. Gunakan 10 bawang putih
1. Gunakan 1 sdt merica
1. Ambil 5 butir kemiri
1. Siapkan 100 gr toge
1. Siapkan 2 bungkus kecil soun
1. Sediakan 2 batang daun bawang
1. Siapkan 5 batang seledri
1. Gunakan 3 daun jeruk, 3 daun salam, 3 batang sereh
1. Siapkan  Sambal : 15 cabe rawit + 2 bawang putih
1. Gunakan 2 lt air, 5 sdm minyak untuk menumis
1. Ambil  Garam dan penyedap rasa (opsional)
1. Siapkan  Jeruk nipis dipotong kecil2




<!--inarticleads2-->

##### Cara menyiapkan Soto Ayam:

1. Haluskan / blender : ketumbar, merica, bawang merah, bawang putih, jahe, lengkuas, kunyit, kemiri.
1. Panaskan minyak, tumis bumbu yang sudah di haluskan di dalam panci, tambahkan daun jeruk, sereh dan daun salam hingga harum aromanya.  - Kemudian tambahkan air 1lt.  - Tutup panci
1. Setelah mendidih, masukkan ayam. Tambahkan garam dan penyedap rasa. Rebus hingga 30 menit.
1. Setelah bumbu meresap, keluarkan ayam dari panci.  - Kemudian tambahkan air 1Lt lagi di panci, aduk sekali2.
1. Goreng ayam di minyak panas, tiriskan.  - Lalu potong kecil2 / suwir.  - Setelah itu masukkan lagi ke dalam panci rebusan kuah soto.  - Kecilkan api dan tes rasa, bila diperlukan tambahkan garam dan penyedap rasa.
1. Bahan pelengkap : - Potong/iris tipis kol.  - Cuci kol dan toge. - Lalu di panci lain, rebus air hingga mendidih.  - Matikan api, celupkan kol, toge dan soun lalu segera tiriskan. - Siapkan di mangkok.
1. Bahan tabur : - Potong/iris daun bawang, seledri. Siapkan di piring kecil
1. Sambal soto : - Rebus cabe dan bawang putih. Setelah itu, uleg kasar saja.  - Taruh di mangkuk kecil, lalu tuangkan 1 sendok sup kuah soto ke sambal.
1. Penyajian : taruh bahan tabur, soun, kol dan toge di mangkok. Siram dengan kuah soto. Tambahkan sambal dan jeruk nipis. Nikmati selagi hangat. - Silahkan mencoba




Ternyata cara membuat soto ayam yang lezat sederhana ini mudah banget ya! Kita semua mampu membuatnya. Cara Membuat soto ayam Sesuai banget untuk kita yang baru mau belajar memasak maupun juga bagi kamu yang telah lihai dalam memasak.

Apakah kamu tertarik mulai mencoba membuat resep soto ayam enak sederhana ini? Kalau mau, yuk kita segera siapin peralatan dan bahan-bahannya, setelah itu buat deh Resep soto ayam yang mantab dan sederhana ini. Sangat mudah kan. 

Maka, daripada anda berlama-lama, hayo langsung aja buat resep soto ayam ini. Pasti kamu tiidak akan nyesel membuat resep soto ayam enak tidak rumit ini! Selamat mencoba dengan resep soto ayam mantab tidak rumit ini di rumah masing-masing,ya!.

