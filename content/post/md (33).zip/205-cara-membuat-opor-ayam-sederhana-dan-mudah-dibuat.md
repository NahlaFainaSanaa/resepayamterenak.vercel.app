---
description: "Cara membuat Opor Ayam Sederhana dan Mudah Dibuat"
title: "Cara membuat Opor Ayam Sederhana dan Mudah Dibuat"
slug: 205-cara-membuat-opor-ayam-sederhana-dan-mudah-dibuat
date: 2021-03-24T17:17:41.787Z
image: https://img-global.cpcdn.com/recipes/444849acba08907d/680x482cq70/opor-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/444849acba08907d/680x482cq70/opor-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/444849acba08907d/680x482cq70/opor-ayam-foto-resep-utama.jpg
author: Eugenia Drake
ratingvalue: 4
reviewcount: 7
recipeingredient:
- "1 kg Daging Ayam"
- "1 liter Air"
- "1 ruas Jahe"
- "1 sdt Garam"
- "1 batang Serai"
- "1 sdt Gula Merah"
- "1 ruas Lengkuas"
- "1 sdt Merica Bubuk"
- "1 saset Santan Kara"
- "1 sdt Ketumbar Bubuk"
- "2 lembar Daun Salam"
- "3 lembar Daun Jeruk"
- "3 siung Bawang Putih"
- "5 buah Cabai Merah"
- "5 butir Bawang Merah"
- "1/2 sdt Kunyit Bubuk"
recipeinstructions:
- "Haluskan bawang merah bawang putih.  Tumis bumbu tersebut hingga harum baunya."
- "Tuang air,  Tambahkan bumbu-bumbu yang lainnya seperti, gula, kaldu bubuk, daun salam, daun jeruk, serai, jahe dan lengkuas yang telah dimemarkan.  Masukkan daging ayam. Aduk-aduk hingga tercampur rata. Tunggu sampai mendidih."
- "Tambahkan santan kara. Aduk-aduk kembali dan lanjutkan proses memasak hingga matang serta santannya menyusut dan daging ayamnya menjadi semakin lunak."
categories:
- Resep
tags:
- opor
- ayam

katakunci: opor ayam 
nutrition: 212 calories
recipecuisine: Indonesian
preptime: "PT14M"
cooktime: "PT40M"
recipeyield: "1"
recipecategory: Dessert

---


![Opor Ayam](https://img-global.cpcdn.com/recipes/444849acba08907d/680x482cq70/opor-ayam-foto-resep-utama.jpg)

Jika anda seorang orang tua, menyediakan masakan enak bagi famili adalah suatu hal yang mengasyikan untuk kita sendiri. Tugas seorang ibu bukan hanya mengerjakan pekerjaan rumah saja, tapi anda juga wajib menyediakan kebutuhan nutrisi terpenuhi dan masakan yang dimakan anak-anak mesti nikmat.

Di era  sekarang, kalian sebenarnya dapat membeli olahan praktis walaupun tidak harus susah mengolahnya terlebih dahulu. Tapi ada juga mereka yang selalu ingin memberikan makanan yang terenak untuk orang tercintanya. Pasalnya, menghidangkan masakan yang dibuat sendiri akan jauh lebih higienis dan bisa menyesuaikan hidangan tersebut sesuai dengan masakan kesukaan keluarga. 



Mungkinkah anda merupakan seorang penyuka opor ayam?. Tahukah kamu, opor ayam adalah sajian khas di Nusantara yang kini disenangi oleh kebanyakan orang dari hampir setiap daerah di Indonesia. Kamu dapat membuat opor ayam sendiri di rumahmu dan boleh jadi hidangan favorit di hari libur.

Anda jangan bingung untuk menyantap opor ayam, lantaran opor ayam gampang untuk didapatkan dan kalian pun dapat memasaknya sendiri di tempatmu. opor ayam bisa diolah memalui berbagai cara. Kini pun sudah banyak cara kekinian yang membuat opor ayam semakin lebih enak.

Resep opor ayam juga mudah sekali untuk dibikin, lho. Kita jangan repot-repot untuk membeli opor ayam, tetapi Kita mampu menyajikan ditempatmu. Bagi Kita yang ingin membuatnya, di bawah ini adalah cara membuat opor ayam yang enak yang bisa Kita buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Opor Ayam:

1. Sediakan 1 kg Daging Ayam
1. Siapkan 1 liter Air
1. Sediakan 1 ruas Jahe
1. Sediakan 1 sdt Garam
1. Ambil 1 batang Serai
1. Ambil 1 sdt Gula Merah
1. Ambil 1 ruas Lengkuas
1. Gunakan 1 sdt Merica Bubuk
1. Gunakan 1 saset Santan Kara
1. Sediakan 1 sdt Ketumbar Bubuk
1. Gunakan 2 lembar Daun Salam
1. Gunakan 3 lembar Daun Jeruk
1. Gunakan 3 siung Bawang Putih
1. Sediakan 5 buah Cabai Merah
1. Siapkan 5 butir Bawang Merah
1. Ambil 1/2 sdt Kunyit Bubuk




<!--inarticleads2-->

##### Cara membuat Opor Ayam:

1. Haluskan bawang merah bawang putih.  - Tumis bumbu tersebut hingga harum baunya.
1. Tuang air,  - Tambahkan bumbu-bumbu yang lainnya seperti, gula, kaldu bubuk, daun salam, daun jeruk, serai, jahe dan lengkuas yang telah dimemarkan.  - Masukkan daging ayam. - Aduk-aduk hingga tercampur rata. - Tunggu sampai mendidih.
1. Tambahkan santan kara. - Aduk-aduk kembali dan lanjutkan proses memasak hingga matang serta santannya menyusut dan daging ayamnya menjadi semakin lunak.




Ternyata cara buat opor ayam yang lezat tidak rumit ini enteng sekali ya! Kamu semua bisa memasaknya. Cara Membuat opor ayam Sangat sesuai banget untuk kamu yang sedang belajar memasak ataupun juga bagi kamu yang telah ahli dalam memasak.

Apakah kamu ingin mencoba membikin resep opor ayam mantab simple ini? Kalau anda mau, ayo kalian segera buruan siapkan alat-alat dan bahan-bahannya, lalu buat deh Resep opor ayam yang enak dan sederhana ini. Sungguh mudah kan. 

Maka dari itu, daripada kamu berfikir lama-lama, ayo kita langsung saja buat resep opor ayam ini. Dijamin kalian gak akan menyesal sudah bikin resep opor ayam nikmat tidak rumit ini! Selamat mencoba dengan resep opor ayam mantab tidak ribet ini di rumah sendiri,oke!.

