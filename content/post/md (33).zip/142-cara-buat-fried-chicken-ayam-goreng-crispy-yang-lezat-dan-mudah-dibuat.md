---
description: "Cara buat Fried Chicken / Ayam Goreng Crispy yang lezat dan Mudah Dibuat"
title: "Cara buat Fried Chicken / Ayam Goreng Crispy yang lezat dan Mudah Dibuat"
slug: 142-cara-buat-fried-chicken-ayam-goreng-crispy-yang-lezat-dan-mudah-dibuat
date: 2021-03-23T14:58:40.401Z
image: https://img-global.cpcdn.com/recipes/68bcc818c78fef60/680x482cq70/fried-chicken-ayam-goreng-crispy-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/68bcc818c78fef60/680x482cq70/fried-chicken-ayam-goreng-crispy-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/68bcc818c78fef60/680x482cq70/fried-chicken-ayam-goreng-crispy-foto-resep-utama.jpg
author: Rosa Cunningham
ratingvalue: 3.5
reviewcount: 5
recipeingredient:
- "1 Kg Ayam"
- "3 Bungkus tepung bumbu ss"
- "125 gram tepung terigu"
- " Merica"
- " Garam"
- " Bawang putih ulek"
- " Air es"
recipeinstructions:
- "Cuci bersih ayam,lalu beri garam,merica dan bawang putih ulek remas remas"
- "Bagi adonan menjadi 2 bagian"
- "Pertama adonan basah(tepung sasa campur dengan tepung terigu beri air es secukupnya),dan kedua adonan kering"
- "Celupkan ayam kedalam adonan basah,lalu masukkan ke adonan kering remas perlahan lalu masak kedalam minyak panas*api kecil supaya matang merata*"
- "Goreng hingga keemasan,lalu angkat dan tiriskan"
categories:
- Resep
tags:
- fried
- chicken
- 

katakunci: fried chicken  
nutrition: 113 calories
recipecuisine: Indonesian
preptime: "PT14M"
cooktime: "PT49M"
recipeyield: "2"
recipecategory: Lunch

---


![Fried Chicken / Ayam Goreng Crispy](https://img-global.cpcdn.com/recipes/68bcc818c78fef60/680x482cq70/fried-chicken-ayam-goreng-crispy-foto-resep-utama.jpg)

Andai kita seorang yang hobi masak, menyuguhkan panganan menggugah selera untuk keluarga tercinta merupakan suatu hal yang memuaskan bagi kamu sendiri. Peran seorang ibu Tidak cuma menjaga rumah saja, tetapi kamu juga harus menyediakan kebutuhan nutrisi tercukupi dan panganan yang dimakan orang tercinta wajib lezat.

Di era  sekarang, kalian sebenarnya bisa mengorder masakan praktis walaupun tidak harus susah memasaknya dahulu. Tapi ada juga lho mereka yang selalu mau menghidangkan yang terbaik untuk orang tercintanya. Karena, memasak sendiri jauh lebih bersih dan bisa menyesuaikan masakan tersebut sesuai dengan masakan kesukaan keluarga tercinta. 



Mungkinkah anda salah satu penikmat fried chicken / ayam goreng crispy?. Tahukah kamu, fried chicken / ayam goreng crispy merupakan hidangan khas di Indonesia yang saat ini disenangi oleh banyak orang di berbagai wilayah di Indonesia. Kamu bisa menyajikan fried chicken / ayam goreng crispy hasil sendiri di rumah dan pasti jadi camilan kegemaranmu di akhir pekan.

Kalian tidak perlu bingung jika kamu ingin menyantap fried chicken / ayam goreng crispy, karena fried chicken / ayam goreng crispy mudah untuk didapatkan dan kita pun bisa memasaknya sendiri di tempatmu. fried chicken / ayam goreng crispy dapat diolah memalui bermacam cara. Kini telah banyak resep modern yang membuat fried chicken / ayam goreng crispy semakin lezat.

Resep fried chicken / ayam goreng crispy pun gampang untuk dibuat, lho. Kita tidak usah capek-capek untuk membeli fried chicken / ayam goreng crispy, karena Kita mampu membuatnya sendiri di rumah. Untuk Anda yang akan mencobanya, di bawah ini adalah resep untuk menyajikan fried chicken / ayam goreng crispy yang nikamat yang mampu Kamu coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Fried Chicken / Ayam Goreng Crispy:

1. Gunakan 1 Kg Ayam
1. Sediakan 3 Bungkus tepung bumbu s*s*
1. Ambil 125 gram tepung terigu
1. Siapkan  Merica
1. Gunakan  Garam
1. Ambil  Bawang putih ulek
1. Gunakan  Air es




<!--inarticleads2-->

##### Cara membuat Fried Chicken / Ayam Goreng Crispy:

1. Cuci bersih ayam,lalu beri garam,merica dan bawang putih ulek remas remas
1. Bagi adonan menjadi 2 bagian
1. Pertama adonan basah(tepung sasa campur dengan tepung terigu beri air es secukupnya),dan kedua adonan kering
1. Celupkan ayam kedalam adonan basah,lalu masukkan ke adonan kering remas perlahan lalu masak kedalam minyak panas*api kecil supaya matang merata*
1. Goreng hingga keemasan,lalu angkat dan tiriskan




Ternyata cara membuat fried chicken / ayam goreng crispy yang enak sederhana ini mudah banget ya! Kita semua mampu membuatnya. Resep fried chicken / ayam goreng crispy Sangat sesuai banget buat anda yang baru akan belajar memasak ataupun untuk anda yang telah lihai memasak.

Tertarik untuk mulai mencoba membuat resep fried chicken / ayam goreng crispy mantab tidak ribet ini? Kalau anda mau, mending kamu segera siapkan alat dan bahannya, kemudian buat deh Resep fried chicken / ayam goreng crispy yang nikmat dan tidak ribet ini. Betul-betul gampang kan. 

Maka dari itu, ketimbang anda berfikir lama-lama, maka kita langsung bikin resep fried chicken / ayam goreng crispy ini. Pasti kalian tak akan menyesal bikin resep fried chicken / ayam goreng crispy nikmat sederhana ini! Selamat berkreasi dengan resep fried chicken / ayam goreng crispy enak tidak ribet ini di tempat tinggal kalian masing-masing,ya!.

