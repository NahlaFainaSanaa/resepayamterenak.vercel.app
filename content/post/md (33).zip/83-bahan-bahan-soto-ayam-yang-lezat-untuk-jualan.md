---
description: "Bahan-bahan Soto Ayam yang lezat Untuk Jualan"
title: "Bahan-bahan Soto Ayam yang lezat Untuk Jualan"
slug: 83-bahan-bahan-soto-ayam-yang-lezat-untuk-jualan
date: 2021-04-09T22:26:49.942Z
image: https://img-global.cpcdn.com/recipes/f72d50f2556d9875/680x482cq70/soto-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f72d50f2556d9875/680x482cq70/soto-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f72d50f2556d9875/680x482cq70/soto-ayam-foto-resep-utama.jpg
author: Amelia Harmon
ratingvalue: 3
reviewcount: 7
recipeingredient:
- "1 ekor ayam potong 8 bagian"
- "1 sdt ketumbar"
- "2 cm jahe"
- "2 cm lengkuas"
- "2 cm kunyit"
- "15 bawang merah"
- "10 bawang putih"
- "1 sdt merica"
- "5 butir kemiri"
- "100 gr toge"
- "2 bungkus kecil soun"
- "2 batang daun bawang"
- "5 batang seledri"
- "3 daun jeruk 3 daun salam 3 batang sereh"
- " Sambal  15 cabe rawit  2 bawang putih"
- "2 lt air 5 sdm minyak untuk menumis"
- " Garam dan penyedap rasa opsional"
- " Jeruk nipis dipotong kecil2"
recipeinstructions:
- "Haluskan / blender : ketumbar, merica, bawang merah, bawang putih, jahe, lengkuas, kunyit, kemiri."
- "Panaskan minyak, tumis bumbu yang sudah di haluskan di dalam panci, tambahkan daun jeruk, sereh dan daun salam hingga harum aromanya.  Kemudian tambahkan air 1lt.  Tutup panci"
- "Setelah mendidih, masukkan ayam. Tambahkan garam dan penyedap rasa. Rebus hingga 30 menit."
- "Setelah bumbu meresap, keluarkan ayam dari panci.  Kemudian tambahkan air 1Lt lagi di panci, aduk sekali2."
- "Goreng ayam di minyak panas, tiriskan.  Lalu potong kecil2 / suwir.  Setelah itu masukkan lagi ke dalam panci rebusan kuah soto.  Kecilkan api dan tes rasa, bila diperlukan tambahkan garam dan penyedap rasa."
- "Bahan pelengkap : Potong/iris tipis kol.  Cuci kol dan toge. Lalu di panci lain, rebus air hingga mendidih.  Matikan api, celupkan kol, toge dan soun lalu segera tiriskan. Siapkan di mangkok."
- "Bahan tabur : Potong/iris daun bawang, seledri. Siapkan di piring kecil"
- "Sambal soto : Rebus cabe dan bawang putih. Setelah itu, uleg kasar saja.  Taruh di mangkuk kecil, lalu tuangkan 1 sendok sup kuah soto ke sambal."
- "Penyajian : taruh bahan tabur, soun, kol dan toge di mangkok. Siram dengan kuah soto. Tambahkan sambal dan jeruk nipis. Nikmati selagi hangat. Silahkan mencoba"
categories:
- Resep
tags:
- soto
- ayam

katakunci: soto ayam 
nutrition: 231 calories
recipecuisine: Indonesian
preptime: "PT40M"
cooktime: "PT35M"
recipeyield: "4"
recipecategory: Lunch

---


![Soto Ayam](https://img-global.cpcdn.com/recipes/f72d50f2556d9875/680x482cq70/soto-ayam-foto-resep-utama.jpg)

Sebagai seorang yang hobi memasak, menyajikan olahan enak kepada keluarga tercinta merupakan suatu hal yang membahagiakan bagi kamu sendiri. Tanggung jawab seorang istri bukan sekedar menangani rumah saja, namun kamu pun harus menyediakan kebutuhan gizi tercukupi dan santapan yang dimakan anak-anak wajib enak.

Di zaman  sekarang, kita sebenarnya bisa mengorder santapan instan meski tidak harus repot memasaknya dulu. Tapi banyak juga lho mereka yang memang mau memberikan makanan yang terlezat bagi orang yang dicintainya. Sebab, menghidangkan masakan yang diolah sendiri jauh lebih higienis dan bisa menyesuaikan sesuai makanan kesukaan famili. 



Apakah anda salah satu penyuka soto ayam?. Asal kamu tahu, soto ayam adalah makanan khas di Indonesia yang kini disukai oleh orang-orang di berbagai tempat di Nusantara. Anda dapat membuat soto ayam sendiri di rumah dan pasti jadi camilan favoritmu di hari liburmu.

Kita tak perlu bingung untuk memakan soto ayam, sebab soto ayam mudah untuk ditemukan dan kita pun bisa menghidangkannya sendiri di tempatmu. soto ayam dapat dibuat memalui berbagai cara. Sekarang sudah banyak banget resep modern yang membuat soto ayam semakin lebih lezat.

Resep soto ayam pun sangat gampang dibikin, lho. Kalian jangan repot-repot untuk memesan soto ayam, tetapi Kamu bisa menyajikan ditempatmu. Untuk Kamu yang hendak menghidangkannya, dibawah ini merupakan resep untuk menyajikan soto ayam yang mantab yang bisa Anda buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Soto Ayam:

1. Siapkan 1 ekor ayam potong 8 bagian
1. Siapkan 1 sdt ketumbar
1. Siapkan 2 cm jahe
1. Ambil 2 cm lengkuas
1. Sediakan 2 cm kunyit
1. Gunakan 15 bawang merah
1. Gunakan 10 bawang putih
1. Sediakan 1 sdt merica
1. Siapkan 5 butir kemiri
1. Gunakan 100 gr toge
1. Siapkan 2 bungkus kecil soun
1. Gunakan 2 batang daun bawang
1. Gunakan 5 batang seledri
1. Sediakan 3 daun jeruk, 3 daun salam, 3 batang sereh
1. Sediakan  Sambal : 15 cabe rawit + 2 bawang putih
1. Siapkan 2 lt air, 5 sdm minyak untuk menumis
1. Siapkan  Garam dan penyedap rasa (opsional)
1. Siapkan  Jeruk nipis dipotong kecil2




<!--inarticleads2-->

##### Cara menyiapkan Soto Ayam:

1. Haluskan / blender : ketumbar, merica, bawang merah, bawang putih, jahe, lengkuas, kunyit, kemiri.
1. Panaskan minyak, tumis bumbu yang sudah di haluskan di dalam panci, tambahkan daun jeruk, sereh dan daun salam hingga harum aromanya.  - Kemudian tambahkan air 1lt.  - Tutup panci
1. Setelah mendidih, masukkan ayam. Tambahkan garam dan penyedap rasa. Rebus hingga 30 menit.
1. Setelah bumbu meresap, keluarkan ayam dari panci.  - Kemudian tambahkan air 1Lt lagi di panci, aduk sekali2.
1. Goreng ayam di minyak panas, tiriskan.  - Lalu potong kecil2 / suwir.  - Setelah itu masukkan lagi ke dalam panci rebusan kuah soto.  - Kecilkan api dan tes rasa, bila diperlukan tambahkan garam dan penyedap rasa.
1. Bahan pelengkap : - Potong/iris tipis kol.  - Cuci kol dan toge. - Lalu di panci lain, rebus air hingga mendidih.  - Matikan api, celupkan kol, toge dan soun lalu segera tiriskan. - Siapkan di mangkok.
1. Bahan tabur : - Potong/iris daun bawang, seledri. Siapkan di piring kecil
1. Sambal soto : - Rebus cabe dan bawang putih. Setelah itu, uleg kasar saja.  - Taruh di mangkuk kecil, lalu tuangkan 1 sendok sup kuah soto ke sambal.
1. Penyajian : taruh bahan tabur, soun, kol dan toge di mangkok. Siram dengan kuah soto. Tambahkan sambal dan jeruk nipis. Nikmati selagi hangat. - Silahkan mencoba




Ternyata cara buat soto ayam yang lezat tidak ribet ini gampang sekali ya! Kita semua dapat membuatnya. Cara buat soto ayam Sangat sesuai sekali untuk kalian yang baru mau belajar memasak maupun juga untuk kamu yang telah hebat dalam memasak.

Tertarik untuk mulai mencoba buat resep soto ayam lezat simple ini? Kalau kalian tertarik, mending kamu segera menyiapkan alat-alat dan bahan-bahannya, lalu bikin deh Resep soto ayam yang nikmat dan simple ini. Sungguh mudah kan. 

Maka, ketimbang kalian berfikir lama-lama, ayo kita langsung saja buat resep soto ayam ini. Dijamin kalian tiidak akan nyesel sudah bikin resep soto ayam enak simple ini! Selamat mencoba dengan resep soto ayam enak tidak rumit ini di tempat tinggal kalian masing-masing,ya!.

