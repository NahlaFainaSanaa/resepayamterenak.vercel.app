---
description: "Resep Ayam Panggang bumbu ayam bakar klaten yang lezat Untuk Jualan"
title: "Resep Ayam Panggang bumbu ayam bakar klaten yang lezat Untuk Jualan"
slug: 247-resep-ayam-panggang-bumbu-ayam-bakar-klaten-yang-lezat-untuk-jualan
date: 2021-06-24T08:42:43.267Z
image: https://img-global.cpcdn.com/recipes/fb90504ed07c49a0/680x482cq70/ayam-panggang-bumbu-ayam-bakar-klaten-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/fb90504ed07c49a0/680x482cq70/ayam-panggang-bumbu-ayam-bakar-klaten-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/fb90504ed07c49a0/680x482cq70/ayam-panggang-bumbu-ayam-bakar-klaten-foto-resep-utama.jpg
author: Peter Salazar
ratingvalue: 3
reviewcount: 14
recipeingredient:
- "1 ekor 600700 gram ayam negri"
- "1 buah jeruk nipis"
- "1 sendok makan air asam jawa"
- "2 lembar daun salam"
- "2 cm lengkuas memarkan"
- "2 batang serai memarkan"
- "1/2 sendok makan garam"
- "1 sendok teh gula merah"
- "400 ml santan dari 1 bks santan kemasan 65 ml"
- "3 sendok makan minyak untuk menumis"
- " Bumbu halus"
- "15 butir bawang merah"
- "6 siung bawang putih"
- "1 buah cabe merah besar"
- "8 butir kemiri sangrai"
- "2 sendok teh ketumba"
- "2 cm kencur"
- "2 cm jahe"
recipeinstructions:
- "Ayam dibelah melebar utuh atau bisa dipotong2.  Lumuri ayam dengan air jeruk nipis. Diamkan 30 menit."
- "Tumis bumbu halus, daun salam, lengkuas, dan serai sampai harum."
- "Masukkan ayam. Aduk sampai berubah warna. Tambahkan garam, air asam jawa dan gula merah. Aduk rata. Tuang santan secara bertahap sambil diaduk perlahan. Masak sampai matang dan meresap."
- "Panggang ayam dalam oven di suhu 165C selama 30menit lalu balik dan panggang lagi selama 50 menit. Selama proses pemanggangan, oles ayam dg sisa bumbu yang dicampur dengan sedikit margarin"
- "Sajikan ayam dengan sambal dan lalapan. Matangnya sampai ke bagian dalam yaa..."
categories:
- Resep
tags:
- ayam
- panggang
- bumbu

katakunci: ayam panggang bumbu 
nutrition: 296 calories
recipecuisine: Indonesian
preptime: "PT10M"
cooktime: "PT58M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Panggang bumbu ayam bakar klaten](https://img-global.cpcdn.com/recipes/fb90504ed07c49a0/680x482cq70/ayam-panggang-bumbu-ayam-bakar-klaten-foto-resep-utama.jpg)

Apabila kalian seorang yang hobi memasak, menyajikan panganan enak pada famili merupakan hal yang menggembirakan bagi anda sendiri. Peran seorang  wanita Tidak sekadar mengerjakan pekerjaan rumah saja, tetapi kamu pun harus menyediakan kebutuhan gizi terpenuhi dan olahan yang dikonsumsi orang tercinta harus sedap.

Di waktu  saat ini, kita memang bisa mengorder panganan jadi tidak harus capek mengolahnya dulu. Tetapi banyak juga lho orang yang memang ingin memberikan hidangan yang terlezat untuk orang tercintanya. Lantaran, memasak yang dibuat sendiri jauh lebih bersih dan kita pun bisa menyesuaikan makanan tersebut sesuai dengan selera keluarga. 



Mungkinkah anda adalah salah satu penyuka ayam panggang bumbu ayam bakar klaten?. Tahukah kamu, ayam panggang bumbu ayam bakar klaten adalah sajian khas di Nusantara yang sekarang disukai oleh kebanyakan orang di berbagai daerah di Nusantara. Anda dapat menghidangkan ayam panggang bumbu ayam bakar klaten buatan sendiri di rumah dan boleh dijadikan hidangan kesenanganmu di hari liburmu.

Kamu tidak usah bingung untuk memakan ayam panggang bumbu ayam bakar klaten, sebab ayam panggang bumbu ayam bakar klaten tidak sukar untuk dicari dan kita pun dapat memasaknya sendiri di rumah. ayam panggang bumbu ayam bakar klaten dapat dimasak memalui beragam cara. Sekarang telah banyak sekali cara kekinian yang membuat ayam panggang bumbu ayam bakar klaten semakin enak.

Resep ayam panggang bumbu ayam bakar klaten juga sangat mudah dihidangkan, lho. Kalian tidak perlu capek-capek untuk membeli ayam panggang bumbu ayam bakar klaten, sebab Kamu mampu menyajikan sendiri di rumah. Untuk Kamu yang akan mencobanya, dibawah ini merupakan cara untuk menyajikan ayam panggang bumbu ayam bakar klaten yang mantab yang mampu Kalian coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Ayam Panggang bumbu ayam bakar klaten:

1. Gunakan 1 ekor (600-700 gram) ayam negri
1. Sediakan 1 buah jeruk nipis
1. Gunakan 1 sendok makan air asam jawa
1. Gunakan 2 lembar daun salam
1. Ambil 2 cm lengkuas, memarkan
1. Siapkan 2 batang serai, memarkan
1. Sediakan 1/2 sendok makan garam
1. Sediakan 1 sendok teh gula merah
1. Ambil 400 ml santan, dari 1 bks santan kemasan 65 ml
1. Ambil 3 sendok makan minyak untuk menumis
1. Ambil  Bumbu halus:
1. Siapkan 15 butir bawang merah
1. Siapkan 6 siung bawang putih
1. Gunakan 1 buah cabe merah besar
1. Gunakan 8 butir kemiri, sangrai
1. Sediakan 2 sendok teh ketumba
1. Siapkan 2 cm kencur
1. Siapkan 2 cm jahe




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Panggang bumbu ayam bakar klaten:

1. Ayam dibelah melebar utuh atau bisa dipotong2.  - Lumuri ayam dengan air jeruk nipis. Diamkan 30 menit.
1. Tumis bumbu halus, daun salam, lengkuas, dan serai sampai harum.
1. Masukkan ayam. Aduk sampai berubah warna. Tambahkan garam, air asam jawa dan gula merah. Aduk rata. Tuang santan secara bertahap sambil diaduk perlahan. Masak sampai matang dan meresap.
1. Panggang ayam dalam oven di suhu 165C selama 30menit lalu balik dan panggang lagi selama 50 menit. Selama proses pemanggangan, oles ayam dg sisa bumbu yang dicampur dengan sedikit margarin
1. Sajikan ayam dengan sambal dan lalapan. Matangnya sampai ke bagian dalam yaa...




Wah ternyata cara membuat ayam panggang bumbu ayam bakar klaten yang mantab simple ini mudah banget ya! Anda Semua bisa membuatnya. Resep ayam panggang bumbu ayam bakar klaten Cocok sekali buat kalian yang baru mau belajar memasak maupun untuk kamu yang telah jago dalam memasak.

Apakah kamu tertarik mulai mencoba bikin resep ayam panggang bumbu ayam bakar klaten enak tidak ribet ini? Kalau anda mau, yuk kita segera buruan menyiapkan alat dan bahan-bahannya, kemudian buat deh Resep ayam panggang bumbu ayam bakar klaten yang nikmat dan tidak rumit ini. Sungguh gampang kan. 

Jadi, ketimbang anda berfikir lama-lama, maka kita langsung buat resep ayam panggang bumbu ayam bakar klaten ini. Pasti kamu gak akan menyesal sudah buat resep ayam panggang bumbu ayam bakar klaten mantab tidak ribet ini! Selamat mencoba dengan resep ayam panggang bumbu ayam bakar klaten lezat sederhana ini di tempat tinggal masing-masing,ya!.

