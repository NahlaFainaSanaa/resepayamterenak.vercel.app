---
description: "Cara membuat Ayam rica-rica pedas Sederhana Untuk Jualan"
title: "Cara membuat Ayam rica-rica pedas Sederhana Untuk Jualan"
slug: 320-cara-membuat-ayam-rica-rica-pedas-sederhana-untuk-jualan
date: 2021-06-23T00:15:55.005Z
image: https://img-global.cpcdn.com/recipes/ffc710da4f3ad51f/680x482cq70/ayam-rica-rica-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ffc710da4f3ad51f/680x482cq70/ayam-rica-rica-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ffc710da4f3ad51f/680x482cq70/ayam-rica-rica-pedas-foto-resep-utama.jpg
author: Augusta Barrett
ratingvalue: 4.7
reviewcount: 9
recipeingredient:
- "2 ekor ayam"
- " Bumbu halus diblenderdiulek"
- "2 buah Tomat"
- "1 ruas Jahe"
- "2 ruas Kunyit"
- "6 butir Kemiri"
- "9 siung Bawang merah"
- "2 siung bawang putih"
- "1,5 ons cabe merah"
- "15 biji cabe rawit merah"
- " Bahan pelengkap"
- "15 biji Cabe rawit hijau"
- "1 batang daun bawang"
- "2 lembar daun salam"
- "1 lembar daun kunyit"
- "10 lembar daun jeruk"
- "1 batang sere"
- "1 ruas lengkuas"
- "1 ikat daun kemangi dimasukan saat ayam matang"
recipeinstructions:
- "Ayam yg sudah dipotong di marinasi dengan perasan jeruk selama 20menit. Sambilan buat bumbu halus ssesuai keterangan resep."
- "Langkah awal masukan minyak goreng secukupnya (sesuai byknya bumbu halus yg akan ditumis).. *Masukan cabe rawit dan daun bawang yg sudah di iris sedang (tdk tebal tdk tipis).  *Jika cabe sudah sedikit layu masukan bumbu halus yg sudah diblender/diulek. *setelah wangi masukan seluruh bahan2 pelengkap (dedaunan) kecuali kemangi dan masukan bumbu seperti garam 2 sdt-gula 1sdt-kaldu jamur 1/2sdt. Dirasa2, jika kurang bs tambahkan sesuai selera."
- "Aduk sebentar...  masukan ayam yg sudah dimarinasi. Tambahkan air 350-450ml. Disarankan 450ml jk menggunakan ayam kampung, dan 350ml jk menggunakan ayam negeri biasa.   Ungkep ayam selama 40menit-1 jam. Smpe kuah mengental dan ayam lembut. Masukan daun kemangi yg sdh dipetik daunnya. Ayam rica2 siap dihidangkan..."
categories:
- Resep
tags:
- ayam
- ricarica
- pedas

katakunci: ayam ricarica pedas 
nutrition: 208 calories
recipecuisine: Indonesian
preptime: "PT33M"
cooktime: "PT60M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam rica-rica pedas](https://img-global.cpcdn.com/recipes/ffc710da4f3ad51f/680x482cq70/ayam-rica-rica-pedas-foto-resep-utama.jpg)

Jika anda seorang orang tua, menyediakan masakan mantab kepada keluarga tercinta adalah hal yang menggembirakan untuk anda sendiri. Tanggung jawab seorang ibu Tidak sekadar mengatur rumah saja, namun anda pun wajib memastikan kebutuhan gizi terpenuhi dan masakan yang disantap orang tercinta wajib menggugah selera.

Di zaman  saat ini, kita memang mampu mengorder masakan jadi tanpa harus ribet membuatnya dulu. Namun banyak juga lho mereka yang memang mau memberikan makanan yang terbaik untuk orang yang dicintainya. Karena, memasak yang diolah sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan hidangan tersebut berdasarkan selera orang tercinta. 



Mungkinkah anda adalah seorang penyuka ayam rica-rica pedas?. Tahukah kamu, ayam rica-rica pedas adalah makanan khas di Nusantara yang saat ini disukai oleh setiap orang dari hampir setiap daerah di Indonesia. Kalian bisa menyajikan ayam rica-rica pedas sendiri di rumah dan boleh dijadikan makanan favoritmu di hari libur.

Kamu tidak perlu bingung jika kamu ingin memakan ayam rica-rica pedas, sebab ayam rica-rica pedas gampang untuk ditemukan dan juga kalian pun dapat memasaknya sendiri di rumah. ayam rica-rica pedas boleh dibuat dengan beragam cara. Kini ada banyak sekali cara kekinian yang menjadikan ayam rica-rica pedas semakin enak.

Resep ayam rica-rica pedas juga mudah sekali dibikin, lho. Anda jangan ribet-ribet untuk memesan ayam rica-rica pedas, tetapi Kalian dapat menghidangkan di rumahmu. Bagi Kalian yang akan menghidangkannya, dibawah ini merupakan cara menyajikan ayam rica-rica pedas yang mantab yang mampu Kamu hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Ayam rica-rica pedas:

1. Siapkan 2 ekor ayam
1. Ambil  Bumbu halus diblender/diulek
1. Gunakan 2 buah Tomat
1. Ambil 1 ruas Jahe
1. Siapkan 2 ruas Kunyit
1. Gunakan 6 butir Kemiri
1. Ambil 9 siung Bawang merah
1. Ambil 2 siung bawang putih
1. Sediakan 1,5 ons cabe merah
1. Gunakan 15 biji cabe rawit merah
1. Gunakan  Bahan pelengkap
1. Siapkan 15 biji Cabe rawit hijau
1. Gunakan 1 batang daun bawang
1. Gunakan 2 lembar daun salam
1. Sediakan 1 lembar daun kunyit
1. Gunakan 10 lembar daun jeruk
1. Gunakan 1 batang sere
1. Gunakan 1 ruas lengkuas
1. Sediakan 1 ikat daun kemangi (dimasukan saat ayam matang)




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam rica-rica pedas:

1. Ayam yg sudah dipotong di marinasi dengan perasan jeruk selama 20menit. Sambilan buat bumbu halus ssesuai keterangan resep.
1. Langkah awal masukan minyak goreng secukupnya (sesuai byknya bumbu halus yg akan ditumis).. - *Masukan cabe rawit dan daun bawang yg sudah di iris sedang (tdk tebal tdk tipis).  - *Jika cabe sudah sedikit layu masukan bumbu halus yg sudah diblender/diulek. - *setelah wangi masukan seluruh bahan2 pelengkap (dedaunan) kecuali kemangi dan masukan bumbu seperti garam 2 sdt-gula 1sdt-kaldu jamur 1/2sdt. Dirasa2, jika kurang bs tambahkan sesuai selera.
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Ayam rica-rica pedas">1. Aduk sebentar...  - masukan ayam yg sudah dimarinasi. Tambahkan air 350-450ml. Disarankan 450ml jk menggunakan ayam kampung, dan 350ml jk menggunakan ayam negeri biasa.  -  - Ungkep ayam selama 40menit-1 jam. Smpe kuah mengental dan ayam lembut. Masukan daun kemangi yg sdh dipetik daunnya. Ayam rica2 siap dihidangkan...




Ternyata cara membuat ayam rica-rica pedas yang lezat simple ini enteng sekali ya! Semua orang dapat mencobanya. Cara buat ayam rica-rica pedas Sangat sesuai banget untuk kamu yang baru mau belajar memasak atau juga untuk kalian yang telah pandai memasak.

Tertarik untuk mencoba membuat resep ayam rica-rica pedas enak sederhana ini? Kalau anda ingin, yuk kita segera buruan menyiapkan peralatan dan bahannya, lantas buat deh Resep ayam rica-rica pedas yang enak dan simple ini. Sangat taidak sulit kan. 

Maka, daripada kalian berlama-lama, maka langsung aja hidangkan resep ayam rica-rica pedas ini. Dijamin anda tak akan menyesal bikin resep ayam rica-rica pedas mantab tidak ribet ini! Selamat mencoba dengan resep ayam rica-rica pedas enak tidak rumit ini di rumah masing-masing,oke!.

