---
description: "Cara buat Ayam Rica Rica Manado yang nikmat dan Mudah Dibuat"
title: "Cara buat Ayam Rica Rica Manado yang nikmat dan Mudah Dibuat"
slug: 316-cara-buat-ayam-rica-rica-manado-yang-nikmat-dan-mudah-dibuat
date: 2021-03-19T14:11:27.768Z
image: https://img-global.cpcdn.com/recipes/ee55b01017b3a2f8/680x482cq70/ayam-rica-rica-manado-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ee55b01017b3a2f8/680x482cq70/ayam-rica-rica-manado-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ee55b01017b3a2f8/680x482cq70/ayam-rica-rica-manado-foto-resep-utama.jpg
author: Olivia Pena
ratingvalue: 4.6
reviewcount: 11
recipeingredient:
- "1 Ekor Ayam Potong Menjadi Bagian KecilKecil"
- " Jahe"
- " Lengkuas"
- " Kemiri"
- "sesuai selera Cabe rawit"
- "sesuai selera Cabe Merah"
- "4 lembar Daun salam"
- "2 Batang Serai"
- " Daun kemangi"
- "6 Siung Bawang Merah"
- "2 Siung Bawang putih"
- " Daun jeruk 3 lembar iris"
recipeinstructions:
- "Potong Ayam menjadi beberapa Bagian, dan goreng sebentar saja"
- "Blender bumbu halus (Cabe merah, cabe rawit, jahe, lengkuas, bawang merah, bawang putih, kemiri)"
- "Tumis bumbu yang sudah dihaluskan sampai harum, setelah nya masukan serai yang sudah digeprek, daun Salam dan daun jeruk yang sudah diris iris"
- "Masukan ayam yang sudah digoreng tadi, aduk hingga rata sampai tercampur dengan bumbu nya"
- "Tambahkan sedikir air, beri penyedap/kaldu bubuk, gula, garam. Aduk hingga rata (tes rasa). Biarkan airnya sampai sedikit menyusut"
- "Terakhir, tambahkan daun kemangi lalu aduk kembali. Angkat dan sajikan"
categories:
- Resep
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 158 calories
recipecuisine: Indonesian
preptime: "PT25M"
cooktime: "PT58M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Rica Rica Manado](https://img-global.cpcdn.com/recipes/ee55b01017b3a2f8/680x482cq70/ayam-rica-rica-manado-foto-resep-utama.jpg)

Selaku seorang yang hobi memasak, menyuguhkan olahan sedap kepada keluarga tercinta merupakan hal yang sangat menyenangkan untuk kamu sendiri. Tugas seorang ibu bukan cuma mengurus rumah saja, tapi kamu pun wajib menyediakan keperluan gizi tercukupi dan hidangan yang dimakan keluarga tercinta harus enak.

Di zaman  sekarang, kalian sebenarnya mampu mengorder panganan yang sudah jadi tidak harus ribet membuatnya dulu. Tapi banyak juga orang yang selalu mau memberikan makanan yang terlezat bagi orang yang dicintainya. Sebab, menghidangkan masakan yang diolah sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan sesuai selera keluarga. 



Apakah anda adalah seorang penggemar ayam rica rica manado?. Tahukah kamu, ayam rica rica manado merupakan hidangan khas di Indonesia yang saat ini disenangi oleh setiap orang dari berbagai daerah di Nusantara. Kamu bisa menyajikan ayam rica rica manado buatan sendiri di rumahmu dan dapat dijadikan camilan kesenanganmu di akhir pekanmu.

Kita jangan bingung jika kamu ingin mendapatkan ayam rica rica manado, sebab ayam rica rica manado tidak sukar untuk dicari dan kamu pun dapat memasaknya sendiri di rumah. ayam rica rica manado dapat dimasak memalui beragam cara. Kini ada banyak sekali cara kekinian yang membuat ayam rica rica manado semakin lebih enak.

Resep ayam rica rica manado pun mudah sekali untuk dibuat, lho. Kalian tidak usah ribet-ribet untuk memesan ayam rica rica manado, sebab Anda dapat menghidangkan di rumahmu. Untuk Kita yang hendak membuatnya, berikut cara membuat ayam rica rica manado yang enak yang mampu Kita coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Ayam Rica Rica Manado:

1. Siapkan 1 Ekor Ayam (Potong Menjadi Bagian Kecil-Kecil)
1. Sediakan  Jahe
1. Sediakan  Lengkuas
1. Sediakan  Kemiri
1. Ambil sesuai selera Cabe rawit
1. Gunakan sesuai selera Cabe Merah
1. Ambil 4 lembar Daun salam
1. Siapkan 2 Batang Serai
1. Siapkan  Daun kemangi
1. Siapkan 6 Siung Bawang Merah
1. Siapkan 2 Siung Bawang putih
1. Siapkan  Daun jeruk 3 lembar (iris)




<!--inarticleads2-->

##### Cara membuat Ayam Rica Rica Manado:

1. Potong Ayam menjadi beberapa Bagian, dan goreng sebentar saja
1. Blender bumbu halus (Cabe merah, cabe rawit, jahe, lengkuas, bawang merah, bawang putih, kemiri)
1. Tumis bumbu yang sudah dihaluskan sampai harum, setelah nya masukan serai yang sudah digeprek, daun Salam dan daun jeruk yang sudah diris iris
1. Masukan ayam yang sudah digoreng tadi, aduk hingga rata sampai tercampur dengan bumbu nya
1. Tambahkan sedikir air, beri penyedap/kaldu bubuk, gula, garam. Aduk hingga rata (tes rasa). Biarkan airnya sampai sedikit menyusut
1. Terakhir, tambahkan daun kemangi lalu aduk kembali. Angkat dan sajikan




Wah ternyata cara membuat ayam rica rica manado yang enak tidak rumit ini enteng sekali ya! Kalian semua bisa membuatnya. Cara Membuat ayam rica rica manado Sangat sesuai banget buat kita yang baru belajar memasak ataupun untuk anda yang telah pandai memasak.

Tertarik untuk mencoba membikin resep ayam rica rica manado mantab tidak rumit ini? Kalau anda tertarik, mending kamu segera buruan siapkan alat-alat dan bahan-bahannya, setelah itu buat deh Resep ayam rica rica manado yang nikmat dan tidak rumit ini. Sungguh taidak sulit kan. 

Oleh karena itu, ketimbang kalian berlama-lama, yuk langsung aja bikin resep ayam rica rica manado ini. Pasti kamu tak akan nyesel membuat resep ayam rica rica manado enak tidak rumit ini! Selamat berkreasi dengan resep ayam rica rica manado lezat sederhana ini di rumah masing-masing,oke!.

