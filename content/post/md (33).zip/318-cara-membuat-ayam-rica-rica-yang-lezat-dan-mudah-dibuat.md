---
description: "Cara membuat Ayam Rica-Rica yang lezat dan Mudah Dibuat"
title: "Cara membuat Ayam Rica-Rica yang lezat dan Mudah Dibuat"
slug: 318-cara-membuat-ayam-rica-rica-yang-lezat-dan-mudah-dibuat
date: 2021-03-12T18:06:49.600Z
image: https://img-global.cpcdn.com/recipes/2e8b4f17f5c9bfcd/680x482cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2e8b4f17f5c9bfcd/680x482cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2e8b4f17f5c9bfcd/680x482cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Lena Cross
ratingvalue: 5
reviewcount: 14
recipeingredient:
- "1/2 ekor ayam"
- "1 buah Jeruk nipis  peras"
- "secukupnya Daun kemangi"
- "1 buah Tomat  iris opsi"
- "3 batang Serai  geprek"
- "3 lembar Daun jeruk"
- "3 lembar Daun salam"
- "1 cm Jahe  geprek"
- "1 cm Lengkuas  geprek"
- "secukupnya Gula  Garam"
- "secukupnya Penyedap rasa"
- " Bumbu Halus "
- "6 butir Bawang merah"
- "3 siung Bawang putih"
- "sesuai selera Cabe rawit"
- "1 cm Kunyit"
- "3 butir Kemiri"
- "secukupnya Ketumbar"
recipeinstructions:
- "Potong ayam agak kecil, cuci bersih lalu lumuri perasan jeruk nipis,diamkan 10 menit, bilas hingga bersih kemudian goreng setengah matang."
- "Panaskan 2 sdm minyak goreng, masukkan bumbu halus,tambahkan serai, daun jeruk, daun salam, lengkuas, jahe, gula,garam dan penyedap. Tumis hingga harum."
- "Masukkan ayam dan tomat,, tambahkan sedikit air, biarkan hingga bumbu meresap dan matang sempurna. Matikan api, lalu masukkan daun kemangi, aduk rata.Ayam rica siap dihidangkan bersama nasi hangat."
categories:
- Resep
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 180 calories
recipecuisine: Indonesian
preptime: "PT31M"
cooktime: "PT47M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Rica-Rica](https://img-global.cpcdn.com/recipes/2e8b4f17f5c9bfcd/680x482cq70/ayam-rica-rica-foto-resep-utama.jpg)

Selaku seorang istri, menyuguhkan masakan mantab pada famili merupakan hal yang menyenangkan untuk kita sendiri. Tugas seorang ibu bukan saja mengatur rumah saja, tetapi kamu juga wajib menyediakan keperluan nutrisi terpenuhi dan juga santapan yang dimakan keluarga tercinta harus sedap.

Di masa  sekarang, anda memang bisa mengorder panganan yang sudah jadi tidak harus ribet mengolahnya terlebih dahulu. Tetapi banyak juga mereka yang selalu mau memberikan hidangan yang terenak bagi keluarganya. Pasalnya, menghidangkan masakan sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan sesuai dengan kesukaan keluarga. 



Apakah kamu seorang penikmat ayam rica-rica?. Asal kamu tahu, ayam rica-rica merupakan sajian khas di Nusantara yang saat ini digemari oleh orang-orang di berbagai wilayah di Indonesia. Anda bisa menghidangkan ayam rica-rica sendiri di rumahmu dan dapat dijadikan makanan kegemaranmu di hari liburmu.

Kita jangan bingung jika kamu ingin menyantap ayam rica-rica, sebab ayam rica-rica sangat mudah untuk dicari dan kita pun boleh membuatnya sendiri di tempatmu. ayam rica-rica bisa dimasak lewat berbagai cara. Kini sudah banyak cara kekinian yang membuat ayam rica-rica lebih nikmat.

Resep ayam rica-rica pun mudah untuk dibuat, lho. Kamu tidak usah ribet-ribet untuk memesan ayam rica-rica, sebab Kalian mampu membuatnya ditempatmu. Bagi Kalian yang hendak mencobanya, dibawah ini merupakan resep membuat ayam rica-rica yang nikamat yang bisa Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Ayam Rica-Rica:

1. Siapkan 1/2 ekor ayam
1. Gunakan 1 buah Jeruk nipis , peras
1. Gunakan secukupnya Daun kemangi
1. Siapkan 1 buah Tomat , iris (opsi)
1. Ambil 3 batang Serai , geprek
1. Siapkan 3 lembar Daun jeruk
1. Siapkan 3 lembar Daun salam
1. Ambil 1 cm Jahe , geprek
1. Gunakan 1 cm Lengkuas , geprek
1. Ambil secukupnya Gula &amp; Garam
1. Gunakan secukupnya Penyedap rasa
1. Siapkan  Bumbu Halus :
1. Ambil 6 butir Bawang merah
1. Gunakan 3 siung Bawang putih
1. Gunakan sesuai selera Cabe rawit
1. Siapkan 1 cm Kunyit
1. Ambil 3 butir Kemiri
1. Siapkan secukupnya Ketumbar




<!--inarticleads2-->

##### Cara menyiapkan Ayam Rica-Rica:

1. Potong ayam agak kecil, cuci bersih lalu lumuri perasan jeruk nipis,diamkan 10 menit, bilas hingga bersih kemudian goreng setengah matang.
1. Panaskan 2 sdm minyak goreng, masukkan bumbu halus,tambahkan serai, daun jeruk, daun salam, lengkuas, jahe, gula,garam dan penyedap. Tumis hingga harum.
1. Masukkan ayam dan tomat,, tambahkan sedikit air, biarkan hingga bumbu meresap dan matang sempurna. Matikan api, lalu masukkan daun kemangi, aduk rata.Ayam rica siap dihidangkan bersama nasi hangat.




Ternyata cara membuat ayam rica-rica yang enak simple ini gampang banget ya! Kita semua mampu memasaknya. Cara buat ayam rica-rica Sangat cocok banget untuk kamu yang baru akan belajar memasak maupun juga untuk kalian yang sudah lihai dalam memasak.

Tertarik untuk mulai mencoba membikin resep ayam rica-rica mantab tidak ribet ini? Kalau kalian tertarik, ayo kamu segera buruan siapkan alat-alat dan bahannya, maka buat deh Resep ayam rica-rica yang enak dan sederhana ini. Benar-benar taidak sulit kan. 

Jadi, ketimbang kita berfikir lama-lama, yuk kita langsung saja hidangkan resep ayam rica-rica ini. Dijamin kamu tiidak akan nyesel sudah bikin resep ayam rica-rica mantab tidak ribet ini! Selamat mencoba dengan resep ayam rica-rica mantab tidak ribet ini di tempat tinggal sendiri,ya!.

