---
description: "Cara buat Ayam Rica Rica Kemangi yang enak dan Mudah Dibuat"
title: "Cara buat Ayam Rica Rica Kemangi yang enak dan Mudah Dibuat"
slug: 324-cara-buat-ayam-rica-rica-kemangi-yang-enak-dan-mudah-dibuat
date: 2021-07-03T18:43:03.081Z
image: https://img-global.cpcdn.com/recipes/1c40514f2ad2143f/680x482cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1c40514f2ad2143f/680x482cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1c40514f2ad2143f/680x482cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Micheal Lyons
ratingvalue: 5
reviewcount: 15
recipeingredient:
- "1/2 ekor ayam ayam nya aku potong kecil2 supaya lbh ter caramelized bumbubiar lbh nyerep bumbu"
- "3 ikat kemangi"
- "8 daun jeruk"
- "1 btg seraimemarkan"
- "1 btg daun bawangpotong kasar"
- "1 ruas lengkuas memarkan"
- "1 jeruk nipisoptional"
- "1/2 sdm garam"
- "1 sdt kaldu jamur totole"
- " Bahan dihaluskan"
- "6 siung bawang merah"
- "2 siung bawang putih"
- "3 btr kemiri"
- "7 cabai keriting"
- "7 cabe rawit klo mau pedes bs di banyakin"
- "1/2 keping kecil gula merah"
- "1 ruas kunyit"
- "1 ruas jahe"
recipeinstructions:
- "Siapkan bahan dan cuci bersih"
- "Potong ayam jd kecil2 (cth:paha bs jd 8 bagian) biar nyerep bumbu,lbh sedep. Cuci ayam dan beri perasan jeruk nipis"
- "Tumis bumbu yg sudah di haluskan,begitu harum masukin lengkuas,daun jeruk dan serai"
- "Lalu masukan ayam,masak sampe stengah matang/ayam berubah warna. Lalu tambahkan air secukupnya (saya pake 300ml) Beri garam dan kaldu (saya pakai totole) untuk bumbu bs menyesuaikan ya,tgl d icip2 aja. Masak sampai bumbu mulai mengental"
- "Begitu bumbu sdh mengental dan ayam matang Masukan daun bawang dan kemangi aduk sebentar dan matikan api"
categories:
- Resep
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 299 calories
recipecuisine: Indonesian
preptime: "PT25M"
cooktime: "PT46M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Rica Rica Kemangi](https://img-global.cpcdn.com/recipes/1c40514f2ad2143f/680x482cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Sebagai seorang orang tua, menyajikan panganan nikmat buat keluarga tercinta adalah suatu hal yang mengasyikan untuk anda sendiri. Kewajiban seorang ibu Tidak sekadar menangani rumah saja, namun kamu juga harus menyediakan kebutuhan nutrisi tercukupi dan juga hidangan yang disantap orang tercinta harus menggugah selera.

Di waktu  sekarang, kita memang mampu membeli masakan instan walaupun tidak harus susah mengolahnya lebih dulu. Tapi banyak juga lho orang yang selalu ingin menghidangkan yang terlezat untuk keluarganya. Lantaran, menyajikan masakan sendiri jauh lebih bersih dan kita juga bisa menyesuaikan sesuai kesukaan keluarga tercinta. 



Mungkinkah anda adalah salah satu penggemar ayam rica rica kemangi?. Asal kamu tahu, ayam rica rica kemangi merupakan sajian khas di Nusantara yang sekarang disukai oleh orang-orang di hampir setiap tempat di Nusantara. Kalian dapat menghidangkan ayam rica rica kemangi sendiri di rumahmu dan dapat dijadikan camilan kegemaranmu di hari libur.

Kita tidak perlu bingung jika kamu ingin memakan ayam rica rica kemangi, karena ayam rica rica kemangi gampang untuk dicari dan kita pun bisa memasaknya sendiri di tempatmu. ayam rica rica kemangi bisa dibuat memalui bermacam cara. Kini pun ada banyak resep modern yang membuat ayam rica rica kemangi semakin lezat.

Resep ayam rica rica kemangi pun mudah sekali dibuat, lho. Kamu jangan ribet-ribet untuk memesan ayam rica rica kemangi, lantaran Kalian bisa menghidangkan di rumahmu. Bagi Kamu yang ingin menghidangkannya, inilah resep untuk menyajikan ayam rica rica kemangi yang enak yang dapat Kamu coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Ayam Rica Rica Kemangi:

1. Siapkan 1/2 ekor ayam (ayam nya aku potong kecil2 supaya lbh ter caramelized bumbu,biar lbh nyerep bumbu)
1. Gunakan 3 ikat kemangi
1. Ambil 8 daun jeruk
1. Siapkan 1 btg serai(memarkan)
1. Siapkan 1 btg daun bawang(potong kasar)
1. Sediakan 1 ruas lengkuas (memarkan)
1. Sediakan 1 jeruk nipis(optional)
1. Sediakan 1/2 sdm garam
1. Gunakan 1 sdt kaldu jamur totole
1. Siapkan  Bahan dihaluskan
1. Siapkan 6 siung bawang merah
1. Sediakan 2 siung bawang putih
1. Ambil 3 btr kemiri
1. Gunakan 7 cabai keriting
1. Siapkan 7 cabe rawit (klo mau pedes bs di banyakin)
1. Ambil 1/2 keping kecil gula merah
1. Siapkan 1 ruas kunyit
1. Siapkan 1 ruas jahe




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Rica Rica Kemangi:

1. Siapkan bahan dan cuci bersih
1. Potong ayam jd kecil2 (cth:paha bs jd 8 bagian) biar nyerep bumbu,lbh sedep. - Cuci ayam dan beri perasan jeruk nipis
1. Tumis bumbu yg sudah di haluskan,begitu harum masukin lengkuas,daun jeruk dan serai
1. Lalu masukan ayam,masak sampe stengah matang/ayam berubah warna. - Lalu tambahkan air secukupnya (saya pake 300ml) - Beri garam dan kaldu (saya pakai totole) untuk bumbu bs menyesuaikan ya,tgl d icip2 aja. - Masak sampai bumbu mulai mengental
1. Begitu bumbu sdh mengental dan ayam matang - Masukan daun bawang dan kemangi aduk sebentar dan matikan api




Ternyata cara buat ayam rica rica kemangi yang mantab sederhana ini gampang banget ya! Semua orang bisa menghidangkannya. Resep ayam rica rica kemangi Sesuai sekali buat kalian yang sedang belajar memasak maupun untuk anda yang sudah hebat memasak.

Apakah kamu ingin mulai mencoba membikin resep ayam rica rica kemangi enak tidak ribet ini? Kalau anda mau, yuk kita segera buruan menyiapkan alat-alat dan bahan-bahannya, lantas bikin deh Resep ayam rica rica kemangi yang enak dan tidak rumit ini. Sangat taidak sulit kan. 

Jadi, ketimbang kalian berlama-lama, hayo kita langsung saja buat resep ayam rica rica kemangi ini. Dijamin anda tak akan nyesel membuat resep ayam rica rica kemangi lezat tidak rumit ini! Selamat berkreasi dengan resep ayam rica rica kemangi nikmat simple ini di rumah masing-masing,ya!.

