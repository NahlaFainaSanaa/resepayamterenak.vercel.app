---
description: "Cara buat Ayam Bakar Kecap Mudah (Grilled Chicken) yang enak dan Mudah Dibuat"
title: "Cara buat Ayam Bakar Kecap Mudah (Grilled Chicken) yang enak dan Mudah Dibuat"
slug: 98-cara-buat-ayam-bakar-kecap-mudah-grilled-chicken-yang-enak-dan-mudah-dibuat
date: 2021-06-13T22:40:13.984Z
image: https://img-global.cpcdn.com/recipes/ebba67b76f1684da/680x482cq70/ayam-bakar-kecap-mudah-grilled-chicken-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ebba67b76f1684da/680x482cq70/ayam-bakar-kecap-mudah-grilled-chicken-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ebba67b76f1684da/680x482cq70/ayam-bakar-kecap-mudah-grilled-chicken-foto-resep-utama.jpg
author: Ronnie Reed
ratingvalue: 4.3
reviewcount: 5
recipeingredient:
- "1/2 ekor Ayam saya suka bagian paha"
- " Bumbu Ungkep"
- "1 batang Serai"
- "2 lembar Daun Salam"
- "1 ruas Lengkuas"
- "Secukupnya Garam Gula Merica Bubuk dan Kecap Manis"
- "2 bongkah kecil Gula Merah Sekitar 23 sendok makan bila di potongpotong"
- " Bumbu Halus BlenderUlek"
- "4 siung Bawang Putih"
- "7 siung Bawang Merah"
- "5 buah Cabai Merah Keriting"
- "2 buah Cabai Merah Besar"
- "2 butir Kemiri"
- "1 ruas Jahe"
- "1 sdm Kunyit Bubuk"
- "1 sdm Ketumbar Bubuk"
recipeinstructions:
- "Masukkan bumbu yang sudah dihaluskan kedalam wajan atau panci, lalu tambahkan ayam, serai, lengkuas, daun salam serta air (tambahkan air hingga semua bagian ayam tenggelam). Jangan lupa tambahkan garam, gula dan merica bubuk. Sisihkan gula merah dan kecap untuk nanti."
- "Ungkep ayam dengan api sedang atau kecil, biarkan hingga matang. Setelah ayam matang dan bumbu meresap tambahkan gula merah dan kecap. Lalu aduk rata dan biarkan hingga air ungkepan hampir kering (sambil dites rasa)."
- "Jika suka ayam bakar yang manis bisa tambahkan gula agak banyak dan kecap. Tapi harus sambil dites rasa, agar rasa gula dan kecap tidak terlalu berlebihan."
- "Setelah itu matikan kompor dan bakar ayam yang sudah diungkep dengan teflon (kalau saya, teflon saya lapisi sedikit minyak goreng, diusapkan merata menggunakan tissue). Bakar dengan api kecil."
- "Setelah matang bisa langsung disantap dengan nasi hangat. Selamat Mencoba 😊"
categories:
- Resep
tags:
- ayam
- bakar
- kecap

katakunci: ayam bakar kecap 
nutrition: 163 calories
recipecuisine: Indonesian
preptime: "PT27M"
cooktime: "PT45M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam Bakar Kecap Mudah (Grilled Chicken)](https://img-global.cpcdn.com/recipes/ebba67b76f1684da/680x482cq70/ayam-bakar-kecap-mudah-grilled-chicken-foto-resep-utama.jpg)

Apabila kamu seorang wanita, mempersiapkan olahan menggugah selera pada keluarga adalah suatu hal yang membahagiakan bagi anda sendiri. Tugas seorang istri Tidak cuman mengatur rumah saja, tetapi kamu pun harus memastikan keperluan nutrisi terpenuhi dan juga santapan yang dimakan orang tercinta wajib nikmat.

Di zaman  sekarang, kita memang dapat memesan olahan siap saji walaupun tanpa harus capek memasaknya dahulu. Tapi banyak juga lho orang yang selalu ingin menghidangkan yang terlezat untuk orang tercintanya. Karena, menyajikan masakan yang dibuat sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan hidangan tersebut berdasarkan selera famili. 



Apakah kamu salah satu penggemar ayam bakar kecap mudah (grilled chicken)?. Tahukah kamu, ayam bakar kecap mudah (grilled chicken) merupakan hidangan khas di Indonesia yang kini digemari oleh setiap orang di berbagai wilayah di Nusantara. Kita dapat membuat ayam bakar kecap mudah (grilled chicken) sendiri di rumah dan pasti jadi makanan kegemaranmu di akhir pekan.

Kalian tak perlu bingung jika kamu ingin memakan ayam bakar kecap mudah (grilled chicken), karena ayam bakar kecap mudah (grilled chicken) mudah untuk dicari dan anda pun dapat menghidangkannya sendiri di tempatmu. ayam bakar kecap mudah (grilled chicken) dapat diolah dengan beragam cara. Sekarang sudah banyak sekali cara modern yang menjadikan ayam bakar kecap mudah (grilled chicken) semakin mantap.

Resep ayam bakar kecap mudah (grilled chicken) pun gampang dibikin, lho. Kita tidak usah ribet-ribet untuk memesan ayam bakar kecap mudah (grilled chicken), lantaran Kamu mampu menghidangkan di rumah sendiri. Bagi Kamu yang hendak membuatnya, inilah resep membuat ayam bakar kecap mudah (grilled chicken) yang lezat yang dapat Anda hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Ayam Bakar Kecap Mudah (Grilled Chicken):

1. Gunakan 1/2 ekor Ayam (saya suka bagian paha)
1. Ambil  Bumbu Ungkep
1. Gunakan 1 batang Serai
1. Gunakan 2 lembar Daun Salam
1. Siapkan 1 ruas Lengkuas
1. Sediakan Secukupnya Garam, Gula, Merica Bubuk dan Kecap Manis
1. Gunakan 2 bongkah kecil Gula Merah (Sekitar 2-3 sendok makan bila di potong-potong)
1. Siapkan  Bumbu Halus (Blender/Ulek)
1. Siapkan 4 siung Bawang Putih
1. Sediakan 7 siung Bawang Merah
1. Gunakan 5 buah Cabai Merah Keriting
1. Sediakan 2 buah Cabai Merah Besar
1. Ambil 2 butir Kemiri
1. Sediakan 1 ruas Jahe
1. Gunakan 1 sdm Kunyit Bubuk
1. Sediakan 1 sdm Ketumbar Bubuk




<!--inarticleads2-->

##### Cara menyiapkan Ayam Bakar Kecap Mudah (Grilled Chicken):

1. Masukkan bumbu yang sudah dihaluskan kedalam wajan atau panci, lalu tambahkan ayam, serai, lengkuas, daun salam serta air (tambahkan air hingga semua bagian ayam tenggelam). Jangan lupa tambahkan garam, gula dan merica bubuk. Sisihkan gula merah dan kecap untuk nanti.
1. Ungkep ayam dengan api sedang atau kecil, biarkan hingga matang. Setelah ayam matang dan bumbu meresap tambahkan gula merah dan kecap. Lalu aduk rata dan biarkan hingga air ungkepan hampir kering (sambil dites rasa).
1. Jika suka ayam bakar yang manis bisa tambahkan gula agak banyak dan kecap. Tapi harus sambil dites rasa, agar rasa gula dan kecap tidak terlalu berlebihan.
1. Setelah itu matikan kompor dan bakar ayam yang sudah diungkep dengan teflon (kalau saya, teflon saya lapisi sedikit minyak goreng, diusapkan merata menggunakan tissue). Bakar dengan api kecil.
1. Setelah matang bisa langsung disantap dengan nasi hangat. Selamat Mencoba 😊




Ternyata cara buat ayam bakar kecap mudah (grilled chicken) yang lezat tidak rumit ini gampang sekali ya! Anda Semua dapat memasaknya. Cara Membuat ayam bakar kecap mudah (grilled chicken) Sesuai sekali buat anda yang baru akan belajar memasak atau juga untuk kalian yang telah hebat memasak.

Apakah kamu mau mencoba membikin resep ayam bakar kecap mudah (grilled chicken) lezat tidak rumit ini? Kalau kamu tertarik, ayo kamu segera buruan menyiapkan alat dan bahannya, maka bikin deh Resep ayam bakar kecap mudah (grilled chicken) yang lezat dan sederhana ini. Sungguh taidak sulit kan. 

Maka dari itu, daripada kita berfikir lama-lama, yuk langsung aja hidangkan resep ayam bakar kecap mudah (grilled chicken) ini. Pasti kamu gak akan nyesel sudah membuat resep ayam bakar kecap mudah (grilled chicken) lezat tidak rumit ini! Selamat berkreasi dengan resep ayam bakar kecap mudah (grilled chicken) nikmat tidak ribet ini di rumah kalian sendiri,ya!.

