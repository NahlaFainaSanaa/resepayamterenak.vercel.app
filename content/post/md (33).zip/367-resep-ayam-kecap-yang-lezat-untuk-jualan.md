---
description: "Resep Ayam kecap yang lezat Untuk Jualan"
title: "Resep Ayam kecap yang lezat Untuk Jualan"
slug: 367-resep-ayam-kecap-yang-lezat-untuk-jualan
date: 2021-05-25T06:20:36.040Z
image: https://img-global.cpcdn.com/recipes/311fd94368876bd2/680x482cq70/ayam-kecap-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/311fd94368876bd2/680x482cq70/ayam-kecap-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/311fd94368876bd2/680x482cq70/ayam-kecap-foto-resep-utama.jpg
author: Wesley Massey
ratingvalue: 4.8
reviewcount: 14
recipeingredient:
- "1/2 ekor ayam potong 6"
- " bawang bombai 12 siung aku gapake lagi Gaada stock"
- "4 siung bawang putih"
- "7 siung bawang merah"
- "2 cm jahe"
- "2 batang Sereh"
- "4 butir Kemiri"
- "2 lembar Daun salam"
- " Kecap1 sdt garam12 sdt penyedapmerica dan ketumbar secukupny"
- "sesuai selera Gula merah"
recipeinstructions:
- "Cuci ayam lalu marinasi pakai perasan jeruk nipis,kasih garam diam km 15 menit lalu goreng setengah matang."
- "Ulek semua bumbu kecuali sereh dan daun salam."
- "Lalu tumis bumbu batang sereh daun salam sampai benar2 Tanak(matang)."
- "Tambah kan air jika sudah mendidih masukan garam,gula,penyedap."
- "Masukan ayam,kecap aduk2 dan tunggu sampai benar2 matang,jika sudah matang angkat sajikan dengan taburan bawang goreng👍"
categories:
- Resep
tags:
- ayam
- kecap

katakunci: ayam kecap 
nutrition: 240 calories
recipecuisine: Indonesian
preptime: "PT37M"
cooktime: "PT60M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam kecap](https://img-global.cpcdn.com/recipes/311fd94368876bd2/680x482cq70/ayam-kecap-foto-resep-utama.jpg)

Andai kamu seorang wanita, menyuguhkan santapan nikmat untuk keluarga adalah suatu hal yang menggembirakan bagi anda sendiri. Tugas seorang ibu Tidak hanya mengurus rumah saja, tapi kamu juga harus memastikan keperluan gizi tercukupi dan juga santapan yang disantap orang tercinta wajib mantab.

Di masa  saat ini, anda memang dapat mengorder olahan jadi meski tidak harus capek mengolahnya terlebih dahulu. Tapi banyak juga lho orang yang selalu ingin menghidangkan yang terbaik bagi orang yang dicintainya. Sebab, menyajikan masakan sendiri jauh lebih higienis dan kita juga bisa menyesuaikan hidangan tersebut berdasarkan makanan kesukaan keluarga tercinta. 



Mungkinkah anda adalah seorang penggemar ayam kecap?. Tahukah kamu, ayam kecap merupakan sajian khas di Indonesia yang sekarang disenangi oleh kebanyakan orang di berbagai daerah di Nusantara. Kamu bisa memasak ayam kecap buatan sendiri di rumahmu dan dapat dijadikan camilan kesenanganmu di hari liburmu.

Anda tak perlu bingung jika kamu ingin memakan ayam kecap, karena ayam kecap gampang untuk ditemukan dan juga anda pun bisa menghidangkannya sendiri di rumah. ayam kecap bisa diolah memalui beraneka cara. Kini sudah banyak sekali resep kekinian yang menjadikan ayam kecap semakin lebih mantap.

Resep ayam kecap juga mudah sekali dibuat, lho. Anda tidak perlu repot-repot untuk membeli ayam kecap, karena Kamu bisa menyiapkan di rumah sendiri. Untuk Kamu yang mau membuatnya, dibawah ini merupakan cara membuat ayam kecap yang mantab yang bisa Anda coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Ayam kecap:

1. Sediakan 1/2 ekor ayam potong 6
1. Ambil  bawang bombai 1/2 siung (aku gapake lagi Gaada stock)
1. Sediakan 4 siung bawang putih
1. Sediakan 7 siung bawang merah
1. Sediakan 2 cm jahe
1. Siapkan 2 batang Sereh
1. Sediakan 4 butir Kemiri
1. Ambil 2 lembar Daun salam
1. Ambil  Kecap,1 sdt garam,1/2 sdt penyedap,merica dan ketumbar secukupny
1. Gunakan sesuai selera Gula merah




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam kecap:

1. Cuci ayam lalu marinasi pakai perasan jeruk nipis,kasih garam diam km 15 menit lalu goreng setengah matang.
1. Ulek semua bumbu kecuali sereh dan daun salam.
1. Lalu tumis bumbu batang sereh daun salam sampai benar2 Tanak(matang).
1. Tambah kan air jika sudah mendidih masukan garam,gula,penyedap.
1. Masukan ayam,kecap aduk2 dan tunggu sampai benar2 matang,jika sudah matang angkat sajikan dengan taburan bawang goreng👍




Wah ternyata cara membuat ayam kecap yang enak simple ini mudah banget ya! Kamu semua bisa mencobanya. Cara buat ayam kecap Sangat cocok banget untuk kamu yang baru belajar memasak ataupun bagi kamu yang sudah lihai memasak.

Apakah kamu tertarik mulai mencoba buat resep ayam kecap enak simple ini? Kalau anda mau, ayo kamu segera siapin alat-alat dan bahannya, maka buat deh Resep ayam kecap yang lezat dan sederhana ini. Betul-betul taidak sulit kan. 

Maka, daripada kita diam saja, yuk langsung aja sajikan resep ayam kecap ini. Pasti kamu gak akan menyesal bikin resep ayam kecap enak tidak ribet ini! Selamat berkreasi dengan resep ayam kecap enak sederhana ini di tempat tinggal kalian masing-masing,ya!.

