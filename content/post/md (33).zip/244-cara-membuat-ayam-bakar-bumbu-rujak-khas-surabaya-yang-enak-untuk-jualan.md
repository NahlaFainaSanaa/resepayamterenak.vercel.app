---
description: "Cara membuat Ayam bakar bumbu rujak khas surabaya yang enak Untuk Jualan"
title: "Cara membuat Ayam bakar bumbu rujak khas surabaya yang enak Untuk Jualan"
slug: 244-cara-membuat-ayam-bakar-bumbu-rujak-khas-surabaya-yang-enak-untuk-jualan
date: 2021-03-19T08:36:28.376Z
image: https://img-global.cpcdn.com/recipes/9147a2c416d0d4e7/680x482cq70/ayam-bakar-bumbu-rujak-khas-surabaya-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9147a2c416d0d4e7/680x482cq70/ayam-bakar-bumbu-rujak-khas-surabaya-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9147a2c416d0d4e7/680x482cq70/ayam-bakar-bumbu-rujak-khas-surabaya-foto-resep-utama.jpg
author: Blake Underwood
ratingvalue: 4.1
reviewcount: 8
recipeingredient:
- "500 gr ayam potong kecil"
- "20 ml santan kara"
- "2 sdm gula merah"
- "1 sdt asam jawa diseduh air panas 3 sdm"
- "Secukupnya minyak"
- "Secukupnya garam totole"
- " Bumbu halus"
- "10 siung bawang merah"
- "5 siung bawang putih"
- "10 buah cabe keriting atau cabe kering juga bisa kalo kering warna jadi lebih merah bagus"
- "10 buah cabe rawit"
- "4 buah kemiri"
- "3 cm jahe"
- "3 cm kunyit"
- "1 sdt ketumbar"
- "1/2 sdt jinten"
- "1 sdm terasi"
- " Bumbu cemplung"
- "4 lembar daun jeruk"
- "2 lembar daun salam"
- "1 buah sereh digeprek"
- "3 cm lengkuas digeprek"
recipeinstructions:
- "Tumis minyak sedikit dengan bumbu yang sudah dihaluskan dan bumbu cemplung hingga airnya menguap dan bumbu mengeluarkan minyak tidak bau mentah. Masukkan ayam, aduk hingga merata dengan bumbu."
- "Masukkan air, rebus hingga mendidih. Beri santan, gula merah, santan, dan aduk terus agar santan tidak pecah. Beri garam dan totole sesuai selera."
- "Satkan airnya hingga berkurang setengahnya dan bumbu menjadi kental. Tambahkan air asam sesuai selera sampai dirasa pas (jangan langsung banyak nanti terlalu kecut). Siapkan teflon untuk membakar ayamnya. Ayam dibakar dengan sesekali diolesi bumbunya. Jika sudah terbakar semua, campur lagi ayam bakar dengan bumbu. Ayam bakar siap dihidangkan, selesai."
categories:
- Resep
tags:
- ayam
- bakar
- bumbu

katakunci: ayam bakar bumbu 
nutrition: 128 calories
recipecuisine: Indonesian
preptime: "PT23M"
cooktime: "PT40M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam bakar bumbu rujak khas surabaya](https://img-global.cpcdn.com/recipes/9147a2c416d0d4e7/680x482cq70/ayam-bakar-bumbu-rujak-khas-surabaya-foto-resep-utama.jpg)

Sebagai seorang istri, menyediakan hidangan sedap pada keluarga tercinta adalah suatu hal yang menyenangkan bagi kamu sendiri. Kewajiban seorang istri Tidak cuma mengurus rumah saja, namun kamu juga harus memastikan kebutuhan gizi terpenuhi dan olahan yang dikonsumsi orang tercinta harus lezat.

Di masa  sekarang, kamu sebenarnya dapat membeli hidangan jadi walaupun tidak harus repot membuatnya dulu. Tapi ada juga mereka yang memang mau menyajikan yang terbaik untuk orang tercintanya. Lantaran, menghidangkan masakan yang dibuat sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan makanan tersebut sesuai selera famili. 



Apakah kamu salah satu penyuka ayam bakar bumbu rujak khas surabaya?. Asal kamu tahu, ayam bakar bumbu rujak khas surabaya adalah makanan khas di Indonesia yang saat ini disenangi oleh kebanyakan orang di berbagai tempat di Nusantara. Anda bisa membuat ayam bakar bumbu rujak khas surabaya buatan sendiri di rumahmu dan dapat dijadikan santapan kegemaranmu di akhir pekan.

Anda tidak perlu bingung untuk mendapatkan ayam bakar bumbu rujak khas surabaya, lantaran ayam bakar bumbu rujak khas surabaya mudah untuk didapatkan dan kamu pun bisa membuatnya sendiri di rumah. ayam bakar bumbu rujak khas surabaya boleh dibuat lewat berbagai cara. Saat ini sudah banyak sekali resep kekinian yang membuat ayam bakar bumbu rujak khas surabaya semakin enak.

Resep ayam bakar bumbu rujak khas surabaya juga mudah sekali dibikin, lho. Kalian tidak usah capek-capek untuk memesan ayam bakar bumbu rujak khas surabaya, tetapi Kita mampu menghidangkan sendiri di rumah. Untuk Kamu yang hendak membuatnya, berikut cara untuk menyajikan ayam bakar bumbu rujak khas surabaya yang nikamat yang dapat Kamu buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Ayam bakar bumbu rujak khas surabaya:

1. Siapkan 500 gr ayam, potong kecil
1. Siapkan 20 ml santan kara
1. Ambil 2 sdm gula merah
1. Gunakan 1 sdt asam jawa diseduh air panas 3 sdm
1. Siapkan Secukupnya minyak
1. Ambil Secukupnya garam, totole
1. Gunakan  Bumbu halus
1. Ambil 10 siung bawang merah
1. Ambil 5 siung bawang putih
1. Gunakan 10 buah cabe keriting (atau cabe kering juga bisa, kalo kering warna jadi lebih merah bagus)
1. Sediakan 10 buah cabe rawit
1. Gunakan 4 buah kemiri
1. Ambil 3 cm jahe
1. Sediakan 3 cm kunyit
1. Gunakan 1 sdt ketumbar
1. Sediakan 1/2 sdt jinten
1. Gunakan 1 sdm terasi
1. Gunakan  Bumbu cemplung
1. Sediakan 4 lembar daun jeruk
1. Ambil 2 lembar daun salam
1. Gunakan 1 buah sereh digeprek
1. Gunakan 3 cm lengkuas digeprek




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam bakar bumbu rujak khas surabaya:

1. Tumis minyak sedikit dengan bumbu yang sudah dihaluskan dan bumbu cemplung hingga airnya menguap dan bumbu mengeluarkan minyak tidak bau mentah. Masukkan ayam, aduk hingga merata dengan bumbu.
1. Masukkan air, rebus hingga mendidih. Beri santan, gula merah, santan, dan aduk terus agar santan tidak pecah. Beri garam dan totole sesuai selera.
1. Satkan airnya hingga berkurang setengahnya dan bumbu menjadi kental. Tambahkan air asam sesuai selera sampai dirasa pas (jangan langsung banyak nanti terlalu kecut). Siapkan teflon untuk membakar ayamnya. Ayam dibakar dengan sesekali diolesi bumbunya. Jika sudah terbakar semua, campur lagi ayam bakar dengan bumbu. Ayam bakar siap dihidangkan, selesai.




Ternyata cara buat ayam bakar bumbu rujak khas surabaya yang mantab simple ini enteng sekali ya! Semua orang dapat mencobanya. Cara buat ayam bakar bumbu rujak khas surabaya Cocok sekali untuk kamu yang sedang belajar memasak maupun juga untuk kalian yang telah pandai dalam memasak.

Apakah kamu tertarik mulai mencoba membuat resep ayam bakar bumbu rujak khas surabaya lezat tidak ribet ini? Kalau kamu ingin, yuk kita segera menyiapkan alat-alat dan bahannya, lalu bikin deh Resep ayam bakar bumbu rujak khas surabaya yang nikmat dan tidak rumit ini. Sangat gampang kan. 

Oleh karena itu, ketimbang anda berfikir lama-lama, yuk kita langsung saja sajikan resep ayam bakar bumbu rujak khas surabaya ini. Pasti kamu tiidak akan menyesal membuat resep ayam bakar bumbu rujak khas surabaya mantab sederhana ini! Selamat berkreasi dengan resep ayam bakar bumbu rujak khas surabaya enak simple ini di rumah sendiri,oke!.

