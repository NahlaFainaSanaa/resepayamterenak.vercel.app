---
description: "Resep Soto Ayam yang enak Untuk Jualan"
title: "Resep Soto Ayam yang enak Untuk Jualan"
slug: 38-resep-soto-ayam-yang-enak-untuk-jualan
date: 2021-05-15T01:24:28.707Z
image: https://img-global.cpcdn.com/recipes/a17fae7401ff89c3/680x482cq70/soto-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a17fae7401ff89c3/680x482cq70/soto-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a17fae7401ff89c3/680x482cq70/soto-ayam-foto-resep-utama.jpg
author: Erik Holloway
ratingvalue: 4.8
reviewcount: 5
recipeingredient:
- "1 ekor Ayam belah jadi 4"
- "1500 ml Air"
- "2 batang Serai memarkan"
- "4 lembar Daun Jeruk"
- "2 cm Lengkuas memarkan"
- "1/4 sdt Lada bubuk"
- "Secukupnya Gula garam dan kaldu bubuk"
- " Bumbu Halus"
- "10 siung Bawang putih"
- "5 siung Bawang merah"
- "2 cm Jahe"
- "2 cm Kunyit"
- "4 butir Kemiri"
- " Pelengkap"
- "3 butir Telur rebu potong  potong"
- "4 lembar Kol iris halus"
- "100 gr Tauge"
- "2 bh Tomat potongpotong"
- "Beberapa lembar daun seledri rajang halus"
- "Secukupnya Bawang Merah goreng untuk taburan"
- "Secukupnya jeruk nipis untuk kecuran"
- " Sambal rebus cabai rawit haluskan dan beri tambahan gula dan garam secukupnya"
recipeinstructions:
- "Bersihkan ayam lalu rebus ayam sampai keluar kaldu dan ayam agak empuk. Haluskan bumbu dan tumis sampai harum, masukkan serai, daun jeruk, lengkuas dan lada bubuk, aduk-aduk sebentar. Masukkan bumbu tumis ke dalam rebusan ayam. Tambahkan gula, garam dan kaldu bubuk. Kecilkan api masak kira-kira 15 menit sampai bumbu meresap. Cicipi dan koreksi rasa."
- "Setelah ayam empuk, angkat dan goreng sebentar dengan sedikit minyak sampai ayam agak kecoklatan lalu suwir-suwir atau iris tipi sesuai selera. Siapkan pelengkap soto."
- "Hidangkan soto ayam dengan taburan kol rebus, irisan tomat, tauge, bawang goreng, telur rebus dan terakhir beri perasan jeruk nipis."
categories:
- Resep
tags:
- soto
- ayam

katakunci: soto ayam 
nutrition: 290 calories
recipecuisine: Indonesian
preptime: "PT40M"
cooktime: "PT47M"
recipeyield: "2"
recipecategory: Dinner

---


![Soto Ayam](https://img-global.cpcdn.com/recipes/a17fae7401ff89c3/680x482cq70/soto-ayam-foto-resep-utama.jpg)

Sebagai seorang ibu, menyediakan olahan nikmat pada keluarga tercinta adalah hal yang menggembirakan untuk kita sendiri. Peran seorang ibu bukan sekedar mengerjakan pekerjaan rumah saja, namun kamu pun harus memastikan keperluan nutrisi tercukupi dan juga masakan yang disantap keluarga tercinta wajib sedap.

Di era  saat ini, kamu sebenarnya bisa mengorder panganan siap saji tidak harus capek memasaknya dahulu. Tapi banyak juga lho orang yang memang mau menghidangkan yang terlezat untuk keluarganya. Pasalnya, memasak yang diolah sendiri akan jauh lebih higienis dan bisa menyesuaikan sesuai masakan kesukaan orang tercinta. 



Mungkinkah anda merupakan salah satu penyuka soto ayam?. Asal kamu tahu, soto ayam merupakan makanan khas di Nusantara yang saat ini digemari oleh setiap orang dari berbagai wilayah di Indonesia. Kalian dapat menghidangkan soto ayam sendiri di rumah dan dapat dijadikan santapan favorit di hari liburmu.

Anda tak perlu bingung untuk mendapatkan soto ayam, lantaran soto ayam tidak sukar untuk ditemukan dan kalian pun bisa membuatnya sendiri di tempatmu. soto ayam boleh dibuat dengan beraneka cara. Saat ini sudah banyak sekali resep modern yang membuat soto ayam semakin lebih enak.

Resep soto ayam pun gampang untuk dibikin, lho. Kamu jangan ribet-ribet untuk membeli soto ayam, tetapi Anda bisa menyajikan ditempatmu. Untuk Anda yang hendak membuatnya, inilah cara untuk menyajikan soto ayam yang mantab yang mampu Kamu hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Soto Ayam:

1. Ambil 1 ekor Ayam belah jadi 4
1. Ambil 1500 ml Air
1. Gunakan 2 batang Serai, memarkan
1. Sediakan 4 lembar Daun Jeruk
1. Ambil 2 cm Lengkuas, memarkan
1. Sediakan 1/4 sdt Lada bubuk
1. Ambil Secukupnya Gula, garam dan kaldu bubuk
1. Sediakan  Bumbu Halus:
1. Siapkan 10 siung Bawang putih
1. Siapkan 5 siung Bawang merah
1. Gunakan 2 cm Jahe
1. Siapkan 2 cm Kunyit
1. Siapkan 4 butir Kemiri
1. Sediakan  Pelengkap:
1. Gunakan 3 butir Telur rebu, potong - potong
1. Sediakan 4 lembar Kol, iris halus
1. Gunakan 100 gr Tauge
1. Siapkan 2 bh Tomat, potong-potong
1. Ambil Beberapa lembar daun seledri, rajang halus
1. Siapkan Secukupnya Bawang Merah goreng untuk taburan
1. Sediakan Secukupnya jeruk nipis untuk kecuran
1. Siapkan  Sambal: (rebus cabai rawit, haluskan dan beri tambahan gula dan garam secukupnya)




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Soto Ayam:

1. Bersihkan ayam lalu rebus ayam sampai keluar kaldu dan ayam agak empuk. Haluskan bumbu dan tumis sampai harum, masukkan serai, daun jeruk, lengkuas dan lada bubuk, aduk-aduk sebentar. Masukkan bumbu tumis ke dalam rebusan ayam. Tambahkan gula, garam dan kaldu bubuk. Kecilkan api masak kira-kira 15 menit sampai bumbu meresap. Cicipi dan koreksi rasa.
1. Setelah ayam empuk, angkat dan goreng sebentar dengan sedikit minyak sampai ayam agak kecoklatan lalu suwir-suwir atau iris tipi sesuai selera. Siapkan pelengkap soto.
1. Hidangkan soto ayam dengan taburan kol rebus, irisan tomat, tauge, bawang goreng, telur rebus dan terakhir beri perasan jeruk nipis.




Ternyata cara membuat soto ayam yang nikamt simple ini enteng sekali ya! Kalian semua dapat memasaknya. Cara Membuat soto ayam Cocok banget buat anda yang baru belajar memasak maupun juga untuk kalian yang sudah pandai dalam memasak.

Apakah kamu ingin mencoba membikin resep soto ayam lezat tidak ribet ini? Kalau mau, ayo kalian segera buruan menyiapkan alat-alat dan bahan-bahannya, maka buat deh Resep soto ayam yang nikmat dan tidak rumit ini. Sungguh taidak sulit kan. 

Jadi, daripada kamu berfikir lama-lama, yuk kita langsung saja bikin resep soto ayam ini. Dijamin kamu tiidak akan menyesal sudah membuat resep soto ayam mantab simple ini! Selamat mencoba dengan resep soto ayam nikmat sederhana ini di rumah kalian sendiri,oke!.

