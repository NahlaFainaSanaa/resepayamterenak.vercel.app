---
description: "Cara membuat Ayam kecap pedas Sederhana dan Mudah Dibuat"
title: "Cara membuat Ayam kecap pedas Sederhana dan Mudah Dibuat"
slug: 365-cara-membuat-ayam-kecap-pedas-sederhana-dan-mudah-dibuat
date: 2021-03-14T21:41:25.917Z
image: https://img-global.cpcdn.com/recipes/bcbd048f2e235e96/680x482cq70/ayam-kecap-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/bcbd048f2e235e96/680x482cq70/ayam-kecap-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/bcbd048f2e235e96/680x482cq70/ayam-kecap-pedas-foto-resep-utama.jpg
author: Raymond Mathis
ratingvalue: 4.9
reviewcount: 14
recipeingredient:
- "1/2 kg ayam"
- "200 ml air putih"
- "5 lembar daun salam"
- "1 ruas jari lengkuas geprek"
- "1 ruas jari jahe geprek"
- "1 batang sereh geprek"
- "Secukupnya kecap manis"
- "6 siung bawang putih"
- "3 siung bawang merah"
- "Sedikit kunyit"
- "2 buah cabe merah keriting"
- "5 buah cabe rawit klo ga suka pedas bisa di kurangi"
- " Gula"
- " Garam"
- " Penyedap sya pke masako ayam"
- "Secukupnya minyak"
recipeinstructions:
- "Rebus ayam selama 15 menit dengan 3 bawang putih (geprek) + 3 lembar daun salam, sisihkan"
- "Ulek bawang putih + bawang merah + kunyit + cabe merah kriting dan cabe rawit, lalu tumis smpe harum"
- "Msukan daun salam + jahe + lengkuas + sereh tumis lagi"
- "Masukan ayam yg sudah di rebus tadi dan lanjut tumis"
- "Masukan garam + gula + penyedap, lanjut tumis (takaran bisa di sesuaikan)"
- "Tambahkan air putih, setelah air mendidih masukan kecap (sesuai selera)"
- "Cek rasa, klo udh pas aduk sekali2 smpe air kecap menyusut dan meresap ke ayam"
- "Angkat dan siap di hidangkan"
categories:
- Resep
tags:
- ayam
- kecap
- pedas

katakunci: ayam kecap pedas 
nutrition: 238 calories
recipecuisine: Indonesian
preptime: "PT32M"
cooktime: "PT41M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam kecap pedas](https://img-global.cpcdn.com/recipes/bcbd048f2e235e96/680x482cq70/ayam-kecap-pedas-foto-resep-utama.jpg)

Sebagai seorang yang hobi masak, menyajikan hidangan nikmat bagi orang tercinta adalah hal yang membahagiakan bagi anda sendiri. Kewajiban seorang  wanita Tidak sekedar menangani rumah saja, tetapi anda juga harus menyediakan kebutuhan nutrisi tercukupi dan juga hidangan yang dimakan keluarga tercinta harus mantab.

Di waktu  saat ini, kalian memang mampu memesan olahan siap saji tanpa harus capek mengolahnya lebih dulu. Tetapi ada juga lho orang yang memang mau memberikan makanan yang terlezat bagi orang yang dicintainya. Karena, memasak yang dibuat sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan hidangan tersebut berdasarkan selera famili. 

Resep Ayam Kecap - Sekarang ini ayam dapat diolah menjadi berbagai makanan yang lezat. Lihat juga resep Ayam kecap manis pedas enak lainnya. Perpaduan kecap manis dan bumbu pedas bikin kreasi ayam jadi semakin nikmat.

Apakah anda adalah salah satu penikmat ayam kecap pedas?. Asal kamu tahu, ayam kecap pedas merupakan makanan khas di Nusantara yang kini disenangi oleh banyak orang di hampir setiap daerah di Indonesia. Kita bisa memasak ayam kecap pedas hasil sendiri di rumah dan boleh dijadikan hidangan favorit di akhir pekanmu.

Anda tidak usah bingung untuk mendapatkan ayam kecap pedas, sebab ayam kecap pedas sangat mudah untuk dicari dan juga kalian pun bisa mengolahnya sendiri di tempatmu. ayam kecap pedas bisa dimasak dengan berbagai cara. Kini telah banyak cara kekinian yang menjadikan ayam kecap pedas semakin lebih nikmat.

Resep ayam kecap pedas pun mudah sekali dibikin, lho. Kalian tidak usah capek-capek untuk memesan ayam kecap pedas, tetapi Kamu bisa menghidangkan di rumah sendiri. Bagi Kita yang mau mencobanya, di bawah ini adalah cara membuat ayam kecap pedas yang nikamat yang dapat Kamu coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Ayam kecap pedas:

1. Siapkan 1/2 kg ayam
1. Sediakan 200 ml air putih
1. Ambil 5 lembar daun salam
1. Sediakan 1 ruas jari lengkuas (geprek)
1. Ambil 1 ruas jari jahe (geprek)
1. Ambil 1 batang sereh (geprek)
1. Sediakan Secukupnya kecap manis
1. Siapkan 6 siung bawang putih
1. Ambil 3 siung bawang merah
1. Ambil Sedikit kunyit
1. Siapkan 2 buah cabe merah keriting
1. Gunakan 5 buah cabe rawit (klo ga suka pedas bisa di kurangi)
1. Gunakan  Gula
1. Sediakan  Garam
1. Gunakan  Penyedap (sya pke masako ayam)
1. Gunakan Secukupnya minyak


Silakan Klik Cara Memasak Ayam Kecap Pedas Manis Mudah dan Praktis Untuk Melihat Artikel Selengkapnya. Campur ayam dengan bumbu halus I, serai, daun salam, dan Resep Ayam Taliwang, Ayam Bakar Pedas dari Nusa Tenggara Barat. Resep Ayam Kecap - Ayam dengan balutan bumbu kecap menjadi salah satu menu olahan daging Setelah matang dan menyusut angkat masakan ayam kecap pedas dan tiriskan ke dalam mangkuk. Resep ayam kecap enak dan empuk macam macam masakan yang lezat dan nikmat biasanya tidak lepas dari bahan selengkapnya silahkan dilihat dalam Aplikasi resep ayam kecap pedas berikut ini. 

<!--inarticleads2-->

##### Cara membuat Ayam kecap pedas:

1. Rebus ayam selama 15 menit dengan 3 bawang putih (geprek) + 3 lembar daun salam, sisihkan
1. Ulek bawang putih + bawang merah + kunyit + cabe merah kriting dan cabe rawit, lalu tumis smpe harum
1. Msukan daun salam + jahe + lengkuas + sereh tumis lagi
1. Masukan ayam yg sudah di rebus tadi dan lanjut tumis
1. Masukan garam + gula + penyedap, lanjut tumis (takaran bisa di sesuaikan)
1. Tambahkan air putih, setelah air mendidih masukan kecap (sesuai selera)
1. Cek rasa, klo udh pas aduk sekali2 smpe air kecap menyusut dan meresap ke ayam
1. Angkat dan siap di hidangkan


Menu favorit buat makan siang kalian lebih mantaap. Ayam kecap or ayam masak kicap is an Indonesian chicken dish poached or simmered in sweet soy sauce (kecap manis) commonly found in Indonesia and Malaysia. Resep Ayam Kecap Pedas Manis Istimewa Dan MudahПодробнее. Resep ayam kecap manis pedas ala restoran padang !!! Resep Ayam Kecap - Selain mudah untuk didapatkan, daging ayam juga sangat mudah untuk Meskipun memiliki rasa yang manis, kamu juga bisa menggunakan resep ayam kecap pedas agar. 

Wah ternyata cara membuat ayam kecap pedas yang lezat simple ini mudah sekali ya! Kalian semua bisa menghidangkannya. Cara Membuat ayam kecap pedas Sangat cocok banget buat kamu yang sedang belajar memasak ataupun untuk kalian yang sudah ahli dalam memasak.

Apakah kamu tertarik mulai mencoba bikin resep ayam kecap pedas nikmat tidak ribet ini? Kalau kalian tertarik, mending kamu segera buruan siapin peralatan dan bahan-bahannya, lalu bikin deh Resep ayam kecap pedas yang enak dan simple ini. Benar-benar mudah kan. 

Maka dari itu, daripada kita berlama-lama, ayo langsung aja bikin resep ayam kecap pedas ini. Pasti anda tiidak akan menyesal sudah membuat resep ayam kecap pedas mantab simple ini! Selamat berkreasi dengan resep ayam kecap pedas mantab simple ini di tempat tinggal kalian masing-masing,oke!.

