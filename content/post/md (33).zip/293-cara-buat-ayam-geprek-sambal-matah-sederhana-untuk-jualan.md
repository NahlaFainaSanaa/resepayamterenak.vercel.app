---
description: "Cara buat Ayam Geprek Sambal Matah Sederhana Untuk Jualan"
title: "Cara buat Ayam Geprek Sambal Matah Sederhana Untuk Jualan"
slug: 293-cara-buat-ayam-geprek-sambal-matah-sederhana-untuk-jualan
date: 2021-04-26T08:55:55.480Z
image: https://img-global.cpcdn.com/recipes/962f2cdd6e5e5901/680x482cq70/ayam-geprek-sambal-matah-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/962f2cdd6e5e5901/680x482cq70/ayam-geprek-sambal-matah-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/962f2cdd6e5e5901/680x482cq70/ayam-geprek-sambal-matah-foto-resep-utama.jpg
author: Gilbert Roberts
ratingvalue: 4.2
reviewcount: 11
recipeingredient:
- " Bahan Ayam Krispi"
- "8 potong ayam bagian paha 4 paha atas  4 paha bawah"
- "1/2-1 sdt garam"
- "1/4 sdt lada"
- "1/2 sdt bawang putih bubuk  1 siung bawang putih cincang"
- "1 butir telur kocok lepas"
- " Minyak untuk menggoreng"
- " Bahan baluran kering ayam"
- "20 sdm tepung terigu"
- "4 sdm maizena  pati jagung"
- " Bahan Sambal Matah"
- "16 butir bawang merah iris halus"
- "5 bh cabai rawit buang biji iris"
- "4 lembar daun jeruk buang batang daun iris halus"
- "1 batang serai bagian putihnya iris"
- "2 sdm air jeruk nipis"
- "1/2 sdt garam kurang lebih"
- "1 sdt gula kurang lebih"
- "1/4 sdt kaldu jamur"
- "5 sdm minyak panas"
recipeinstructions:
- "Siapkan semua bahan"
- "Marinasi ayam potong dengan bawang putih, garam, lada minimal 30 menit"
- "Campurkan bahan baluran kering ayam secara merata"
- "Tambahkan kocokan telur ke ayam yang sudah dimarinasi, lalu balurkan campuran tepung. Goreng di minyak yang cukup banyak dan panas. Selama menggoreng apinya sedang aja. Goreng selama kurang lebih 8 menit di satu sisi, balik, goreng lagi 3 menit (sesuaikan besar potongan ayam juga ya)"
- "Campur bahan sambal matah KECUALI garam, gula, kaldu jamur, minyak panas, dan air jeruk nipis"
- "Siramkan minyak panas secara merata ke campuran sambal, tambahkan garam, gula, kaldu jamur, aduk hingga rata. Terakhir tambah air jeruk nipis lalu aduk rata lagi"
- "Geprek ayam krispi, tambahkan sambal matah, geprek lagi perlahan. Sajikan dengan nasi 😋"
categories:
- Resep
tags:
- ayam
- geprek
- sambal

katakunci: ayam geprek sambal 
nutrition: 141 calories
recipecuisine: Indonesian
preptime: "PT27M"
cooktime: "PT60M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Geprek Sambal Matah](https://img-global.cpcdn.com/recipes/962f2cdd6e5e5901/680x482cq70/ayam-geprek-sambal-matah-foto-resep-utama.jpg)

Sebagai seorang orang tua, mempersiapkan santapan menggugah selera bagi keluarga tercinta merupakan suatu hal yang sangat menyenangkan untuk kamu sendiri. Peran seorang ibu bukan sekadar mengerjakan pekerjaan rumah saja, tetapi anda juga wajib menyediakan kebutuhan gizi terpenuhi dan masakan yang dimakan keluarga tercinta harus menggugah selera.

Di masa  sekarang, kalian sebenarnya bisa memesan olahan praktis walaupun tanpa harus capek membuatnya terlebih dahulu. Namun ada juga lho mereka yang selalu ingin memberikan makanan yang terlezat untuk orang tercintanya. Sebab, memasak yang diolah sendiri akan jauh lebih higienis dan bisa menyesuaikan makanan tersebut sesuai selera orang tercinta. 



Apakah anda salah satu penikmat ayam geprek sambal matah?. Tahukah kamu, ayam geprek sambal matah adalah hidangan khas di Indonesia yang saat ini disukai oleh banyak orang di hampir setiap wilayah di Nusantara. Kita dapat menghidangkan ayam geprek sambal matah olahan sendiri di rumah dan pasti jadi makanan favorit di hari libur.

Kamu tidak perlu bingung untuk menyantap ayam geprek sambal matah, lantaran ayam geprek sambal matah mudah untuk ditemukan dan anda pun dapat menghidangkannya sendiri di tempatmu. ayam geprek sambal matah dapat dimasak dengan beragam cara. Saat ini ada banyak resep kekinian yang menjadikan ayam geprek sambal matah semakin lebih lezat.

Resep ayam geprek sambal matah juga sangat mudah untuk dibikin, lho. Kamu tidak perlu capek-capek untuk membeli ayam geprek sambal matah, lantaran Kita bisa menyajikan ditempatmu. Bagi Kamu yang hendak menghidangkannya, berikut resep menyajikan ayam geprek sambal matah yang enak yang dapat Kamu coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Ayam Geprek Sambal Matah:

1. Ambil  Bahan Ayam Krispi
1. Ambil 8 potong ayam bagian paha (4 paha atas + 4 paha bawah)
1. Sediakan 1/2-1 sdt garam
1. Sediakan 1/4 sdt lada
1. Ambil 1/2 sdt bawang putih bubuk / 1 siung bawang putih cincang
1. Sediakan 1 butir telur, kocok lepas
1. Ambil  Minyak untuk menggoreng
1. Sediakan  Bahan baluran kering ayam
1. Sediakan 20 sdm tepung terigu
1. Siapkan 4 sdm maizena / pati jagung
1. Gunakan  Bahan Sambal Matah
1. Gunakan 16 butir bawang merah, iris halus
1. Gunakan 5 bh cabai rawit, buang biji, iris
1. Gunakan 4 lembar daun jeruk, buang batang daun, iris halus
1. Ambil 1 batang serai bagian putihnya, iris
1. Gunakan 2 sdm air jeruk nipis
1. Sediakan 1/2 sdt garam (kurang lebih)
1. Ambil 1 sdt gula (kurang lebih)
1. Ambil 1/4 sdt kaldu jamur
1. Sediakan 5 sdm minyak panas




<!--inarticleads2-->

##### Cara menyiapkan Ayam Geprek Sambal Matah:

1. Siapkan semua bahan
1. Marinasi ayam potong dengan bawang putih, garam, lada minimal 30 menit
1. Campurkan bahan baluran kering ayam secara merata
1. Tambahkan kocokan telur ke ayam yang sudah dimarinasi, lalu balurkan campuran tepung. Goreng di minyak yang cukup banyak dan panas. Selama menggoreng apinya sedang aja. Goreng selama kurang lebih 8 menit di satu sisi, balik, goreng lagi 3 menit (sesuaikan besar potongan ayam juga ya)
1. Campur bahan sambal matah KECUALI garam, gula, kaldu jamur, minyak panas, dan air jeruk nipis
1. Siramkan minyak panas secara merata ke campuran sambal, tambahkan garam, gula, kaldu jamur, aduk hingga rata. Terakhir tambah air jeruk nipis lalu aduk rata lagi
1. Geprek ayam krispi, tambahkan sambal matah, geprek lagi perlahan. Sajikan dengan nasi 😋




Wah ternyata cara buat ayam geprek sambal matah yang nikamt sederhana ini enteng banget ya! Kita semua mampu membuatnya. Cara Membuat ayam geprek sambal matah Sangat cocok banget buat anda yang baru belajar memasak ataupun juga untuk kamu yang sudah pandai dalam memasak.

Apakah kamu tertarik mulai mencoba membuat resep ayam geprek sambal matah mantab sederhana ini? Kalau kalian ingin, ayo kalian segera siapkan alat-alat dan bahannya, setelah itu buat deh Resep ayam geprek sambal matah yang enak dan simple ini. Sungguh mudah kan. 

Maka, ketimbang kita berfikir lama-lama, ayo langsung aja bikin resep ayam geprek sambal matah ini. Dijamin anda gak akan menyesal membuat resep ayam geprek sambal matah mantab tidak rumit ini! Selamat berkreasi dengan resep ayam geprek sambal matah nikmat sederhana ini di tempat tinggal kalian sendiri,oke!.

