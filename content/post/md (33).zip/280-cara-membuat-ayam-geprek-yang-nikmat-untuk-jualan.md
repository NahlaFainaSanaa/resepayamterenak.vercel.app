---
description: "Cara membuat Ayam Geprek yang nikmat Untuk Jualan"
title: "Cara membuat Ayam Geprek yang nikmat Untuk Jualan"
slug: 280-cara-membuat-ayam-geprek-yang-nikmat-untuk-jualan
date: 2021-03-31T02:48:39.652Z
image: https://img-global.cpcdn.com/recipes/db0f91ee0635e942/680x482cq70/ayam-geprek-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/db0f91ee0635e942/680x482cq70/ayam-geprek-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/db0f91ee0635e942/680x482cq70/ayam-geprek-foto-resep-utama.jpg
author: Russell Goodman
ratingvalue: 4.1
reviewcount: 5
recipeingredient:
- "1/2 kg Ayam Segar"
- "1 buah Jeruk Nipis"
- "1 sdt ketumbar"
- "1 sdt merica"
- "5 siung bawang putih"
- "10 buah cabai segar"
- "2 sdt kaldu jamur"
- "2 bungkus tepung Bumbu Sajiku"
- "secukupnya Air"
recipeinstructions:
- "Cuci ayam hingga bersih. Lalu masukkan perasan jeruk nipis. Aduk2 hingga bau amisnya hilang, lalu cuci kembali"
- "Haluskan 4 siung bawang putih &amp; ketumbar, lalu lumuri ke ayam yg sdh dibersihkan. Tambahkan merica &amp; kaldu jamur. Diamkan selama 1 jam hingga bumbunya meresap"
- "Siapkan 2 mangkuk untuk tepung bumbu Sajiku. Mangkuk pertama adonan kental, dan mangkuk kedua adonan kering (tanpa air)"
- "Setelah bumbu ayam meresap, celupkan ayam ke dalam adonan kental, lalu angkat dan masukkan ke dalam adonan kering (tepung terigu). Bolak balik hingga semua ayam terselimuti oleh tepung terigu"
- "Masukkan ayam ke dlm minyak yg sudah sedikit panas, masak dengan menggunakan api kecil agar matang sampai dalam"
- "Selanjutnya kita buat sambal geprek andalan"
- "Siapkan cabai dan 1 siung bawang putih, tambahkan Penyedap Rasa (sesuai selera) lalu ulek kasar. Setelah itu siram dengan minyak panas"
- "Angkat ayam, lalu tiriskan. Setelah itu geprek ayam tsb dan langsung baluri dengan sambal diatasnya"
- "Ayam geprek siap dihidangkan"
categories:
- Resep
tags:
- ayam
- geprek

katakunci: ayam geprek 
nutrition: 164 calories
recipecuisine: Indonesian
preptime: "PT19M"
cooktime: "PT32M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Geprek](https://img-global.cpcdn.com/recipes/db0f91ee0635e942/680x482cq70/ayam-geprek-foto-resep-utama.jpg)

Sebagai seorang orang tua, mempersiapkan panganan nikmat pada orang tercinta merupakan suatu hal yang menggembirakan untuk kita sendiri. Tugas seorang ibu Tidak hanya menjaga rumah saja, tapi kamu pun wajib memastikan kebutuhan nutrisi terpenuhi dan juga hidangan yang dimakan orang tercinta mesti nikmat.

Di zaman  sekarang, kalian sebenarnya bisa mengorder olahan yang sudah jadi meski tidak harus repot mengolahnya lebih dulu. Tetapi banyak juga mereka yang selalu mau memberikan hidangan yang terlezat bagi orang tercintanya. Lantaran, menghidangkan masakan yang dibuat sendiri jauh lebih higienis dan kita juga bisa menyesuaikan hidangan tersebut sesuai dengan makanan kesukaan keluarga tercinta. 



Mungkinkah anda salah satu penggemar ayam geprek?. Tahukah kamu, ayam geprek merupakan sajian khas di Nusantara yang saat ini digemari oleh banyak orang di hampir setiap daerah di Nusantara. Kita dapat menghidangkan ayam geprek olahan sendiri di rumahmu dan boleh jadi hidangan favorit di hari liburmu.

Kamu tidak usah bingung jika kamu ingin menyantap ayam geprek, lantaran ayam geprek gampang untuk dicari dan kalian pun boleh mengolahnya sendiri di rumah. ayam geprek bisa dibuat dengan bermacam cara. Kini ada banyak sekali cara kekinian yang menjadikan ayam geprek semakin mantap.

Resep ayam geprek pun mudah dibuat, lho. Anda tidak usah capek-capek untuk membeli ayam geprek, tetapi Kita mampu menyiapkan di rumahmu. Bagi Kalian yang hendak menghidangkannya, dibawah ini merupakan cara menyajikan ayam geprek yang lezat yang mampu Kita coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Ayam Geprek:

1. Ambil 1/2 kg Ayam Segar
1. Ambil 1 buah Jeruk Nipis
1. Siapkan 1 sdt ketumbar
1. Gunakan 1 sdt merica
1. Sediakan 5 siung bawang putih
1. Gunakan 10 buah cabai segar
1. Gunakan 2 sdt kaldu jamur
1. Gunakan 2 bungkus tepung Bumbu Sajiku
1. Sediakan secukupnya Air




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam Geprek:

1. Cuci ayam hingga bersih. Lalu masukkan perasan jeruk nipis. Aduk2 hingga bau amisnya hilang, lalu cuci kembali
1. Haluskan 4 siung bawang putih &amp; ketumbar, lalu lumuri ke ayam yg sdh dibersihkan. Tambahkan merica &amp; kaldu jamur. Diamkan selama 1 jam hingga bumbunya meresap
1. Siapkan 2 mangkuk untuk tepung bumbu Sajiku. Mangkuk pertama adonan kental, dan mangkuk kedua adonan kering (tanpa air)
1. Setelah bumbu ayam meresap, celupkan ayam ke dalam adonan kental, lalu angkat dan masukkan ke dalam adonan kering (tepung terigu). Bolak balik hingga semua ayam terselimuti oleh tepung terigu
1. Masukkan ayam ke dlm minyak yg sudah sedikit panas, masak dengan menggunakan api kecil agar matang sampai dalam
1. Selanjutnya kita buat sambal geprek andalan
1. Siapkan cabai dan 1 siung bawang putih, tambahkan Penyedap Rasa (sesuai selera) lalu ulek kasar. Setelah itu siram dengan minyak panas
1. Angkat ayam, lalu tiriskan. Setelah itu geprek ayam tsb dan langsung baluri dengan sambal diatasnya
1. Ayam geprek siap dihidangkan




Wah ternyata cara membuat ayam geprek yang mantab simple ini mudah banget ya! Anda Semua dapat menghidangkannya. Cara Membuat ayam geprek Sesuai banget buat kamu yang baru mau belajar memasak maupun juga bagi anda yang sudah ahli memasak.

Tertarik untuk mulai mencoba bikin resep ayam geprek nikmat sederhana ini? Kalau ingin, ayo kalian segera menyiapkan alat dan bahan-bahannya, setelah itu bikin deh Resep ayam geprek yang lezat dan tidak rumit ini. Benar-benar gampang kan. 

Jadi, ketimbang kamu berlama-lama, hayo langsung aja sajikan resep ayam geprek ini. Dijamin kamu tiidak akan menyesal sudah membuat resep ayam geprek lezat tidak ribet ini! Selamat mencoba dengan resep ayam geprek lezat tidak ribet ini di tempat tinggal masing-masing,ya!.

