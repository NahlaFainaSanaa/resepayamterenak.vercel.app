---
description: "Bahan-bahan Ayam Rica-rica yang lezat Untuk Jualan"
title: "Bahan-bahan Ayam Rica-rica yang lezat Untuk Jualan"
slug: 317-bahan-bahan-ayam-rica-rica-yang-lezat-untuk-jualan
date: 2021-02-08T06:12:54.713Z
image: https://img-global.cpcdn.com/recipes/032c14f700e6f94f/680x482cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/032c14f700e6f94f/680x482cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/032c14f700e6f94f/680x482cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Susan Scott
ratingvalue: 3.3
reviewcount: 8
recipeingredient:
- "1/2 kg ayampotong sesuai selera"
- "1 ikat kemangipetik daunnya saja"
- "1 btg serai geprek"
- "2 lembar daun jeruk"
- "2 siung bawang putih cincang"
- "1/2 biji jeruk nipis"
- "1/2 sdt merica bubuk"
- "secukupnya Kaldu jamurgaram dan gula pasir"
- "secukupnya Air"
- " Minyak makan buat menumis nanti"
- " Bumbu halus"
- "5 siung bawang merah"
- "2 siung bawang putih"
- "5-10 bh cabe merah"
- "10 bj cabe rawit"
- "3 cm jahe"
- "2 bj kemiri"
- "2 ruas kelingking kunyit"
recipeinstructions:
- "Cuci bersih ayam yang sudah dipotong-potong tadi, kemudian marinasi dengan melumuri jeruk nipis, bawang putih cincang, garam dan merica bubuk. Diamkan sekitar 15 menit, kemudian digoreng 3/4 matang. Jadi jangan sampai kecoklatan,sisihkan"
- "Tumis bumbu halus, masukkan serai,daun jeruk sampai matang lalu masukkan garam, kaldu jamur dan gula pasir aduk rata dan masukkan air secukupnya, cek rasa"
- "Masukkan ayam, aduk-aduk dan biarkn hingga airnya berkurang agar bumbu lebih meresap,"
- "Setelah airnya sudah mulai berkurang dan setengah kering,masukkan daun kemangi dan daun bawang, aduk-aduk hingga kemangi agak layu, kemudian angkat"
- "Sajikan dengan nasi hangat Selamat menikmati 😘"
categories:
- Resep
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 185 calories
recipecuisine: Indonesian
preptime: "PT40M"
cooktime: "PT59M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam Rica-rica](https://img-global.cpcdn.com/recipes/032c14f700e6f94f/680x482cq70/ayam-rica-rica-foto-resep-utama.jpg)

Selaku seorang istri, mempersiapkan olahan menggugah selera untuk keluarga tercinta merupakan hal yang menggembirakan untuk kamu sendiri. Kewajiban seorang ibu bukan sekedar mengerjakan pekerjaan rumah saja, tapi kamu juga harus menyediakan kebutuhan gizi tercukupi dan hidangan yang disantap keluarga tercinta harus lezat.

Di era  sekarang, kita sebenarnya mampu mengorder hidangan yang sudah jadi tidak harus ribet mengolahnya terlebih dahulu. Tetapi banyak juga orang yang memang mau memberikan makanan yang terbaik bagi orang yang dicintainya. Sebab, menyajikan masakan yang diolah sendiri akan jauh lebih bersih dan bisa menyesuaikan masakan tersebut sesuai masakan kesukaan orang tercinta. 



Mungkinkah anda merupakan salah satu penyuka ayam rica-rica?. Tahukah kamu, ayam rica-rica adalah sajian khas di Nusantara yang saat ini disukai oleh banyak orang di hampir setiap wilayah di Nusantara. Kita bisa menghidangkan ayam rica-rica sendiri di rumah dan boleh dijadikan hidangan kegemaranmu di akhir pekan.

Anda tidak usah bingung untuk mendapatkan ayam rica-rica, karena ayam rica-rica sangat mudah untuk didapatkan dan juga kalian pun bisa membuatnya sendiri di rumah. ayam rica-rica dapat diolah lewat beraneka cara. Kini telah banyak resep modern yang menjadikan ayam rica-rica semakin nikmat.

Resep ayam rica-rica juga mudah dibuat, lho. Kita tidak perlu repot-repot untuk membeli ayam rica-rica, karena Kamu mampu menghidangkan di rumah sendiri. Untuk Kamu yang hendak mencobanya, berikut ini cara untuk menyajikan ayam rica-rica yang nikamat yang dapat Kita coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Ayam Rica-rica:

1. Sediakan 1/2 kg ayam,potong sesuai selera
1. Siapkan 1 ikat kemangi,petik daunnya saja
1. Ambil 1 btg serai geprek
1. Gunakan 2 lembar daun jeruk
1. Siapkan 2 siung bawang putih cincang
1. Ambil 1/2 biji jeruk nipis
1. Gunakan 1/2 sdt merica bubuk
1. Sediakan secukupnya Kaldu jamur,garam dan gula pasir
1. Siapkan secukupnya Air
1. Sediakan  Minyak makan buat menumis nanti
1. Sediakan  Bumbu halus
1. Gunakan 5 siung bawang merah
1. Siapkan 2 siung bawang putih
1. Siapkan 5-10 bh cabe merah
1. Siapkan 10 bj cabe rawit
1. Ambil 3 cm jahe
1. Ambil 2 bj kemiri
1. Sediakan 2 ruas kelingking kunyit




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Rica-rica:

1. Cuci bersih ayam yang sudah dipotong-potong tadi, kemudian marinasi dengan melumuri jeruk nipis, bawang putih cincang, garam dan merica bubuk. Diamkan sekitar 15 menit, kemudian digoreng 3/4 matang. Jadi jangan sampai kecoklatan,sisihkan
1. Tumis bumbu halus, masukkan serai,daun jeruk sampai matang lalu masukkan garam, kaldu jamur dan gula pasir aduk rata dan masukkan air secukupnya, cek rasa
1. Masukkan ayam, aduk-aduk dan biarkn hingga airnya berkurang agar bumbu lebih meresap,
1. Setelah airnya sudah mulai berkurang dan setengah kering,masukkan daun kemangi dan daun bawang, aduk-aduk hingga kemangi agak layu, kemudian angkat
1. Sajikan dengan nasi hangat - Selamat menikmati 😘




Wah ternyata cara membuat ayam rica-rica yang mantab simple ini enteng sekali ya! Kamu semua mampu membuatnya. Cara buat ayam rica-rica Sangat cocok banget buat anda yang baru belajar memasak ataupun bagi kamu yang sudah ahli memasak.

Tertarik untuk mencoba buat resep ayam rica-rica mantab sederhana ini? Kalau ingin, ayo kamu segera buruan siapkan alat-alat dan bahannya, setelah itu buat deh Resep ayam rica-rica yang lezat dan simple ini. Sangat gampang kan. 

Jadi, ketimbang kita berlama-lama, hayo langsung aja bikin resep ayam rica-rica ini. Dijamin anda tiidak akan menyesal sudah membuat resep ayam rica-rica mantab simple ini! Selamat mencoba dengan resep ayam rica-rica mantab tidak rumit ini di rumah kalian masing-masing,oke!.

