---
description: "Bahan-bahan Ayam Kecap Kemangi yang nikmat dan Mudah Dibuat"
title: "Bahan-bahan Ayam Kecap Kemangi yang nikmat dan Mudah Dibuat"
slug: 133-bahan-bahan-ayam-kecap-kemangi-yang-nikmat-dan-mudah-dibuat
date: 2021-04-05T14:29:26.199Z
image: https://img-global.cpcdn.com/recipes/47da0e706c5d671d/680x482cq70/ayam-kecap-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/47da0e706c5d671d/680x482cq70/ayam-kecap-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/47da0e706c5d671d/680x482cq70/ayam-kecap-kemangi-foto-resep-utama.jpg
author: Dominic Phillips
ratingvalue: 3.6
reviewcount: 4
recipeingredient:
- "1  ekor ayam aga besar"
- "4 bawang merah"
- "2 bawang putih"
- "1  bombay"
- "1 cabe besar merah"
- "1 cabe besar hijau"
- "2 ikat kecil daun kemangi"
- " daun bawang"
- "3 sdm kecap asin premium"
- "2 sdm minyak wijen"
- "1 sdm saus tiram"
- " lada"
- " garam"
- " gula"
- " kaldu jamur"
- " gula merah 1 bongkah kecil"
- " minyak goreng"
recipeinstructions:
- "Potong ayam setelah dibersihkan"
- "Tumis dengan mengunakan minyak goreng dan minyak wijen : bawang merah, baput n bombay, masukan cabe merah n hijau besar. Ak angkat dl sebagian tumisan bawang2an taruh di mangkok spy ga lembek nanti bumbunya pas di masak."
- "Masukan ayam dan masak smp ayam berubah warna, bumbui kecap asin n saus tiram.."
- "Beri air secukupnya. Bumbui gula, garam, lada, kaldu jamur,sdkt gula merah kecil sj (1 sdt) dan beri bbrp pcs cabe rawit utuh bila suka. Masak smp ayam matang n kuah aga berkurang tp jgn smp habis ya kuahnya."
- "Sebelum diangkat, masukan daun bawang, bumbu2 tumisan yg tadi di angkat, daun kemangi dan masak sebentar saja, aduk2 n cicipi rasaya sdh pas atau blm. Angkat dan sajikan"
categories:
- Resep
tags:
- ayam
- kecap
- kemangi

katakunci: ayam kecap kemangi 
nutrition: 225 calories
recipecuisine: Indonesian
preptime: "PT11M"
cooktime: "PT31M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Kecap Kemangi](https://img-global.cpcdn.com/recipes/47da0e706c5d671d/680x482cq70/ayam-kecap-kemangi-foto-resep-utama.jpg)

Andai kita seorang ibu, mempersiapkan santapan nikmat kepada keluarga merupakan suatu hal yang menyenangkan untuk kita sendiri. Tugas seorang istri bukan hanya menangani rumah saja, namun kamu pun harus menyediakan kebutuhan gizi terpenuhi dan masakan yang disantap keluarga tercinta mesti sedap.

Di waktu  sekarang, kita memang mampu membeli hidangan jadi meski tidak harus susah membuatnya terlebih dahulu. Tetapi banyak juga lho mereka yang selalu ingin menghidangkan yang terenak untuk orang yang dicintainya. Sebab, menyajikan masakan yang diolah sendiri jauh lebih higienis dan bisa menyesuaikan sesuai dengan masakan kesukaan keluarga tercinta. 



Mungkinkah anda adalah seorang penikmat ayam kecap kemangi?. Asal kamu tahu, ayam kecap kemangi adalah sajian khas di Indonesia yang saat ini disukai oleh orang-orang dari hampir setiap wilayah di Nusantara. Kalian dapat memasak ayam kecap kemangi kreasi sendiri di rumah dan dapat dijadikan makanan kegemaranmu di hari libur.

Kita tidak perlu bingung jika kamu ingin menyantap ayam kecap kemangi, sebab ayam kecap kemangi mudah untuk ditemukan dan kita pun bisa memasaknya sendiri di tempatmu. ayam kecap kemangi dapat diolah lewat beragam cara. Kini pun sudah banyak sekali resep kekinian yang menjadikan ayam kecap kemangi lebih mantap.

Resep ayam kecap kemangi pun sangat gampang dibuat, lho. Anda tidak perlu ribet-ribet untuk membeli ayam kecap kemangi, sebab Kita mampu membuatnya sendiri di rumah. Untuk Kalian yang akan menghidangkannya, berikut ini resep untuk membuat ayam kecap kemangi yang nikamat yang mampu Anda buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Ayam Kecap Kemangi:

1. Ambil 1 /² ekor ayam aga besar
1. Gunakan 4 bawang merah
1. Ambil 2 bawang putih
1. Sediakan 1 /² bombay
1. Ambil 1 cabe besar merah
1. Gunakan 1 cabe besar hijau
1. Gunakan 2 ikat kecil daun kemangi
1. Ambil  daun bawang
1. Gunakan 3 sdm kecap asin premium
1. Ambil 2 sdm minyak wijen
1. Siapkan 1 sdm saus tiram
1. Ambil  lada
1. Sediakan  garam
1. Ambil  gula
1. Sediakan  kaldu jamur
1. Sediakan  gula merah 1 bongkah kecil
1. Gunakan  minyak goreng




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam Kecap Kemangi:

1. Potong ayam setelah dibersihkan
1. Tumis dengan mengunakan minyak goreng dan minyak wijen : bawang merah, baput n bombay, masukan cabe merah n hijau besar. Ak angkat dl sebagian tumisan bawang2an taruh di mangkok spy ga lembek nanti bumbunya pas di masak.
1. Masukan ayam dan masak smp ayam berubah warna, bumbui kecap asin n saus tiram..
1. Beri air secukupnya. Bumbui gula, garam, lada, kaldu jamur,sdkt gula merah kecil sj (1 sdt) dan beri bbrp pcs cabe rawit utuh bila suka. Masak smp ayam matang n kuah aga berkurang tp jgn smp habis ya kuahnya.
1. Sebelum diangkat, masukan daun bawang, bumbu2 tumisan yg tadi di angkat, daun kemangi dan masak sebentar saja, aduk2 n cicipi rasaya sdh pas atau blm. - Angkat dan sajikan




Ternyata cara membuat ayam kecap kemangi yang mantab tidak ribet ini mudah banget ya! Kita semua bisa mencobanya. Cara buat ayam kecap kemangi Sangat sesuai sekali buat anda yang baru mau belajar memasak maupun juga bagi anda yang telah jago memasak.

Apakah kamu ingin mencoba bikin resep ayam kecap kemangi enak tidak ribet ini? Kalau kalian tertarik, yuk kita segera siapin peralatan dan bahan-bahannya, kemudian bikin deh Resep ayam kecap kemangi yang enak dan tidak rumit ini. Sungguh gampang kan. 

Maka, ketimbang anda diam saja, yuk kita langsung buat resep ayam kecap kemangi ini. Dijamin anda tak akan nyesel sudah bikin resep ayam kecap kemangi mantab tidak rumit ini! Selamat mencoba dengan resep ayam kecap kemangi lezat simple ini di rumah sendiri,oke!.

