---
description: "Cara buat Opor Ayam Pok Pok (Bumbu Opor Jawa Timuran) yang enak dan Mudah Dibuat"
title: "Cara buat Opor Ayam Pok Pok (Bumbu Opor Jawa Timuran) yang enak dan Mudah Dibuat"
slug: 257-cara-buat-opor-ayam-pok-pok-bumbu-opor-jawa-timuran-yang-enak-dan-mudah-dibuat
date: 2021-04-07T01:15:01.930Z
image: https://img-global.cpcdn.com/recipes/9ff038dd2936f1f9/680x482cq70/opor-ayam-pok-pok-bumbu-opor-jawa-timuran-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9ff038dd2936f1f9/680x482cq70/opor-ayam-pok-pok-bumbu-opor-jawa-timuran-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9ff038dd2936f1f9/680x482cq70/opor-ayam-pok-pok-bumbu-opor-jawa-timuran-foto-resep-utama.jpg
author: Harriet Wood
ratingvalue: 4.3
reviewcount: 10
recipeingredient:
- " Bahan Kuah Opor  Bumbu Cemplung"
- "1-2 liter air bersih"
- "30 gram santan kental"
- "2 batang sereh memarkan"
- "2 lembar daun salam"
- "1 ruas jari lengkuas memarkan"
- "1 butir kapulaga"
- "1 sdt garam"
- "1 sdm gula pasir atau bisa pakai gula aren"
- "1/2 sdt kaldu bubuk"
- " Bumbu Halus"
- "8 butir bawang merah"
- "4 siung bawang putih"
- "2 cm kunyit bakar"
- "2 butir kemiri sangrai"
- "1 ruas jari jahe"
- "1 lembar daun jeruk"
- "1/2 sdt ketumbar bubuk"
- " Bahan Ayam Pok Pok"
- "300 gram dada ayam potong dadu"
- "1 sdm air jeruk nipis"
- "1/2 sachet bumbu ayam goreng untuk marinasi"
- "2 butir telur kocok lepas"
- "250 gram tepung terigu"
- "3 sdm tepung beras"
- "secukupnya kaldu bubuk"
- "secukupnya minyak goreng"
- " Bahan Lainnya"
- "2 buah kentang potong panjang"
- "1 buah cabai merah besar iris serong"
- "secukupnya bawang goreng"
- "secukupnya daun bawang iris"
recipeinstructions:
- "Membuat Kuah Opor: Blender bumbu hingga halus. Lalu panaskan minyak goreng, masukkan bumbu halus beserta bumbu cemplungnya. Tumis hingga harum dan matang."
- "Selanjutnya tambahkan air, santan, gula, garam dan kaldu bubuk. Aduk rata masak hingga mendidih. Sesekali diaduk agar santan tidak pecah dan jangan lupa tes rasa. Jika sudah matang matikan apinya, sisihkan."
- "Untuk Kentangnya: kupas, potong panjang, lalu cuci bersih. Rendam sebentar dengan air garam ± 10 menit, lalu goreng hingga goldenbrown. Jika sudah tiriskan."
- "Untuk Ayam Pok2nya: Cuci bersih ayam yang sudah dipotong-potong lalu lumuri dengan air perasan jeruk nipis. Remas-remas agar jeruk nipis tercampur rata, kemudian bilas lagi dengan air bersih."
- "Selanjutnya masukkan bumbu marinasi, aduk rata dan diamkan selama satu jam, simpan dalam kulkas."
- "Sambil menunggu bumbu marinasi meresap, siapkan tepung pelapisnya. Campur jadi satu tepung terigu, tepung beras, garam, dan kaldu bubuk, aduk rata. Jika sudah 1 jan keluarkan ayam lalu lumuri tepung hingga merata."
- "Kemudian celupkan kedalam telur kocok, aduk rata dan pindahkan lagi ke tepung pelapisnya (2x tahapan)."
- "Selanjutnya goreng pada minyak panas yang cukup banyak agar matang merata dan krispi. Biarkan dulu jangan dibolak balik, tunggu sampai tepung agak kokoh supaya tepung tidak rontok."
- "Jika warna sudah matang kecoklatan, angkat dan tiriskan."
- "Penyajian 1: Panaskan kuah... Ambil beberapa ayam pok pok dan kentang goreng. Letakkan dan tata pada wadah saji kemudian siram kuah opornya. Beri taburan daun bawang dan cabai iris, sajikan."
- "Penyajian 2: Ambil secukupnya ayam pok pok dan letakkan di mangkuk saji. Siram kuah opornya, untuk kentang diletakkan terpisah, sajikan."
- "Penyajian 3: Campur jadi satu ayam pok pok, kentang goreng dan kuah opor. Beri taburan bawang goreng dan irisan cabai merah, sajikan."
- "Bisa juga kunjungi link resep asli https://cookpad.com/id/resep/13882229-opor-ayam-jawa-timur?invite_token=LVhMFkXahxJiA79iJExidLfQ&amp;shared_at=1620511106."
categories:
- Resep
tags:
- opor
- ayam
- pok

katakunci: opor ayam pok 
nutrition: 258 calories
recipecuisine: Indonesian
preptime: "PT32M"
cooktime: "PT39M"
recipeyield: "4"
recipecategory: Lunch

---


![Opor Ayam Pok Pok (Bumbu Opor Jawa Timuran)](https://img-global.cpcdn.com/recipes/9ff038dd2936f1f9/680x482cq70/opor-ayam-pok-pok-bumbu-opor-jawa-timuran-foto-resep-utama.jpg)

Sebagai seorang wanita, menyediakan masakan sedap pada famili merupakan suatu hal yang membahagiakan bagi kita sendiri. Kewajiban seorang istri Tidak hanya mengatur rumah saja, tapi kamu pun wajib menyediakan keperluan nutrisi terpenuhi dan panganan yang dikonsumsi keluarga tercinta mesti mantab.

Di era  sekarang, kita sebenarnya mampu memesan hidangan praktis meski tanpa harus susah mengolahnya dulu. Tapi ada juga lho mereka yang memang ingin memberikan makanan yang terenak untuk orang tercintanya. Pasalnya, menghidangkan masakan yang diolah sendiri akan jauh lebih bersih dan bisa menyesuaikan masakan tersebut sesuai dengan kesukaan keluarga. 



Apakah anda salah satu penikmat opor ayam pok pok (bumbu opor jawa timuran)?. Asal kamu tahu, opor ayam pok pok (bumbu opor jawa timuran) adalah hidangan khas di Nusantara yang saat ini digemari oleh banyak orang dari hampir setiap daerah di Nusantara. Kalian dapat menyajikan opor ayam pok pok (bumbu opor jawa timuran) hasil sendiri di rumah dan boleh jadi camilan kesukaanmu di hari libur.

Kalian jangan bingung untuk mendapatkan opor ayam pok pok (bumbu opor jawa timuran), karena opor ayam pok pok (bumbu opor jawa timuran) tidak sukar untuk didapatkan dan juga kita pun bisa membuatnya sendiri di rumah. opor ayam pok pok (bumbu opor jawa timuran) bisa dibuat lewat beragam cara. Kini ada banyak sekali resep modern yang membuat opor ayam pok pok (bumbu opor jawa timuran) semakin lebih enak.

Resep opor ayam pok pok (bumbu opor jawa timuran) pun sangat mudah dibuat, lho. Anda jangan ribet-ribet untuk membeli opor ayam pok pok (bumbu opor jawa timuran), karena Kalian mampu menyiapkan di rumahmu. Bagi Kita yang ingin menyajikannya, inilah cara menyajikan opor ayam pok pok (bumbu opor jawa timuran) yang nikamat yang dapat Anda hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Opor Ayam Pok Pok (Bumbu Opor Jawa Timuran):

1. Sediakan  Bahan Kuah Opor + Bumbu Cemplung:
1. Siapkan 1-2 liter air bersih
1. Ambil 30 gram santan kental
1. Ambil 2 batang sereh, memarkan
1. Sediakan 2 lembar daun salam
1. Siapkan 1 ruas jari lengkuas, memarkan
1. Gunakan 1 butir kapulaga
1. Gunakan 1 sdt garam
1. Ambil 1 sdm gula pasir, atau bisa pakai gula aren
1. Siapkan 1/2 sdt kaldu bubuk
1. Ambil  Bumbu Halus:
1. Gunakan 8 butir bawang merah
1. Ambil 4 siung bawang putih
1. Gunakan 2 cm kunyit bakar
1. Ambil 2 butir kemiri sangrai
1. Sediakan 1 ruas jari jahe
1. Gunakan 1 lembar daun jeruk
1. Ambil 1/2 sdt ketumbar bubuk
1. Ambil  Bahan Ayam Pok Pok:
1. Ambil 300 gram dada ayam, potong dadu
1. Gunakan 1 sdm air jeruk nipis
1. Sediakan 1/2 sachet bumbu ayam goreng, untuk marinasi
1. Siapkan 2 butir telur, kocok lepas
1. Sediakan 250 gram tepung terigu
1. Siapkan 3 sdm tepung beras
1. Ambil secukupnya kaldu bubuk
1. Gunakan secukupnya minyak goreng
1. Ambil  Bahan Lainnya:
1. Ambil 2 buah kentang, potong panjang
1. Siapkan 1 buah cabai merah besar, iris serong
1. Ambil secukupnya bawang goreng
1. Ambil secukupnya daun bawang, iris




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Opor Ayam Pok Pok (Bumbu Opor Jawa Timuran):

1. Membuat Kuah Opor: Blender bumbu hingga halus. Lalu panaskan minyak goreng, masukkan bumbu halus beserta bumbu cemplungnya. Tumis hingga harum dan matang.
1. Selanjutnya tambahkan air, santan, gula, garam dan kaldu bubuk. Aduk rata masak hingga mendidih. Sesekali diaduk agar santan tidak pecah dan jangan lupa tes rasa. Jika sudah matang matikan apinya, sisihkan.
1. Untuk Kentangnya: kupas, potong panjang, lalu cuci bersih. Rendam sebentar dengan air garam ± 10 menit, lalu goreng hingga goldenbrown. Jika sudah tiriskan.
1. Untuk Ayam Pok2nya: Cuci bersih ayam yang sudah dipotong-potong lalu lumuri dengan air perasan jeruk nipis. Remas-remas agar jeruk nipis tercampur rata, kemudian bilas lagi dengan air bersih.
1. Selanjutnya masukkan bumbu marinasi, aduk rata dan diamkan selama satu jam, simpan dalam kulkas.
1. Sambil menunggu bumbu marinasi meresap, siapkan tepung pelapisnya. Campur jadi satu tepung terigu, tepung beras, garam, dan kaldu bubuk, aduk rata. Jika sudah 1 jan keluarkan ayam lalu lumuri tepung hingga merata.
1. Kemudian celupkan kedalam telur kocok, aduk rata dan pindahkan lagi ke tepung pelapisnya (2x tahapan).
1. Selanjutnya goreng pada minyak panas yang cukup banyak agar matang merata dan krispi. Biarkan dulu jangan dibolak balik, tunggu sampai tepung agak kokoh supaya tepung tidak rontok.
1. Jika warna sudah matang kecoklatan, angkat dan tiriskan.
1. Penyajian 1: Panaskan kuah... Ambil beberapa ayam pok pok dan kentang goreng. Letakkan dan tata pada wadah saji kemudian siram kuah opornya. Beri taburan daun bawang dan cabai iris, sajikan.
1. Penyajian 2: Ambil secukupnya ayam pok pok dan letakkan di mangkuk saji. Siram kuah opornya, untuk kentang diletakkan terpisah, sajikan.
1. Penyajian 3: Campur jadi satu ayam pok pok, kentang goreng dan kuah opor. Beri taburan bawang goreng dan irisan cabai merah, sajikan.
1. Bisa juga kunjungi link resep asli https://cookpad.com/id/resep/13882229-opor-ayam-jawa-timur?invite_token=LVhMFkXahxJiA79iJExidLfQ&amp;shared_at=1620511106.




Wah ternyata cara membuat opor ayam pok pok (bumbu opor jawa timuran) yang mantab tidak ribet ini enteng sekali ya! Kamu semua bisa mencobanya. Cara Membuat opor ayam pok pok (bumbu opor jawa timuran) Sesuai banget buat kita yang baru mau belajar memasak maupun juga bagi anda yang sudah pandai dalam memasak.

Tertarik untuk mencoba membikin resep opor ayam pok pok (bumbu opor jawa timuran) mantab tidak ribet ini? Kalau anda tertarik, ayo kalian segera buruan siapin peralatan dan bahan-bahannya, lantas buat deh Resep opor ayam pok pok (bumbu opor jawa timuran) yang lezat dan tidak rumit ini. Benar-benar mudah kan. 

Maka, daripada kita berfikir lama-lama, maka langsung aja bikin resep opor ayam pok pok (bumbu opor jawa timuran) ini. Pasti kalian tak akan menyesal sudah buat resep opor ayam pok pok (bumbu opor jawa timuran) lezat tidak ribet ini! Selamat berkreasi dengan resep opor ayam pok pok (bumbu opor jawa timuran) mantab tidak rumit ini di tempat tinggal kalian sendiri,oke!.

