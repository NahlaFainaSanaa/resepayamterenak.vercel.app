---
description: "Bahan-bahan Ayam rica rica yang enak dan Mudah Dibuat"
title: "Bahan-bahan Ayam rica rica yang enak dan Mudah Dibuat"
slug: 325-bahan-bahan-ayam-rica-rica-yang-enak-dan-mudah-dibuat
date: 2021-06-15T23:17:57.573Z
image: https://img-global.cpcdn.com/recipes/7d23bcae5dab834c/680x482cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7d23bcae5dab834c/680x482cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7d23bcae5dab834c/680x482cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Lina Mendoza
ratingvalue: 3.4
reviewcount: 8
recipeingredient:
- "1/2 kg ayam"
- " bumbu halus bisa diblender atau di tumbuk"
- "8 siung bawang merah"
- "4 siung bawang putih"
- "7 bh cabe merah keriting"
- "5 bh cabe rawit kecil"
- "1 ruas jahe"
- "1 ruas kunyit"
- "3 butir kemiri di sangrai dulu"
- " bumbu lainnya"
- "1 ruas lengkuas geprek"
- "1 btg serai geprek"
- "1 bh tomat iris"
- "2 lembar daun jeruk"
- "secukupnya garam bumbu penyedap"
- "1 sdm gula merah"
- "1 bh jeruk nipis"
recipeinstructions:
- "Potongan ayamnya di marinasi dg jeruk nipis kurang lebih 15 menit kemudian goreng ayamnya setengah mateng atau bisa sampai warna agak kecoklatan"
- "Tumis bumbu halus sampai wangi kemudian masukkan lengkuas, serai, tomat dan daun jeruk yg di sobek2. aduk sebentar"
- "Masukkan potongan ayam, tambahkan air, aduk rata.. tambahkan garam, bumbu penyedap dan gula merah.. aduk rata"
- "Test rasa jika sudah pas tunggu sbntr sampai air agak menyusut sekitar 15 menit atau lebih.. jika sudah, langsung angkat dan sajikan"
categories:
- Resep
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 291 calories
recipecuisine: Indonesian
preptime: "PT40M"
cooktime: "PT49M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam rica rica](https://img-global.cpcdn.com/recipes/7d23bcae5dab834c/680x482cq70/ayam-rica-rica-foto-resep-utama.jpg)

Selaku seorang wanita, menyajikan olahan enak bagi famili merupakan suatu hal yang membahagiakan untuk anda sendiri. Peran seorang ibu bukan saja menjaga rumah saja, tetapi anda juga wajib memastikan keperluan gizi tercukupi dan juga masakan yang disantap keluarga tercinta harus nikmat.

Di masa  sekarang, kamu memang bisa mengorder hidangan instan walaupun tidak harus repot memasaknya terlebih dahulu. Namun ada juga mereka yang selalu ingin menghidangkan yang terlezat bagi orang yang dicintainya. Pasalnya, memasak yang diolah sendiri jauh lebih higienis dan kita pun bisa menyesuaikan makanan tersebut sesuai dengan kesukaan keluarga tercinta. 



Apakah anda merupakan seorang penggemar ayam rica rica?. Tahukah kamu, ayam rica rica adalah hidangan khas di Indonesia yang saat ini disukai oleh banyak orang dari berbagai daerah di Nusantara. Kalian bisa membuat ayam rica rica olahan sendiri di rumah dan dapat dijadikan santapan kegemaranmu di hari liburmu.

Kalian tidak perlu bingung jika kamu ingin menyantap ayam rica rica, lantaran ayam rica rica tidak sulit untuk ditemukan dan juga anda pun boleh mengolahnya sendiri di rumah. ayam rica rica bisa dibuat memalui beragam cara. Kini pun ada banyak sekali resep kekinian yang menjadikan ayam rica rica lebih mantap.

Resep ayam rica rica pun gampang sekali dihidangkan, lho. Kita tidak usah repot-repot untuk memesan ayam rica rica, tetapi Kamu mampu menyiapkan ditempatmu. Bagi Kamu yang hendak menyajikannya, berikut ini cara untuk menyajikan ayam rica rica yang mantab yang mampu Anda hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Ayam rica rica:

1. Siapkan 1/2 kg ayam
1. Ambil  bumbu halus (bisa diblender atau di tumbuk)
1. Siapkan 8 siung bawang merah
1. Siapkan 4 siung bawang putih
1. Ambil 7 bh cabe merah keriting
1. Siapkan 5 bh cabe rawit kecil
1. Ambil 1 ruas jahe
1. Siapkan 1 ruas kunyit
1. Gunakan 3 butir kemiri (di sangrai dulu)
1. Gunakan  bumbu lainnya
1. Siapkan 1 ruas lengkuas geprek
1. Sediakan 1 btg serai geprek
1. Ambil 1 bh tomat iris
1. Ambil 2 lembar daun jeruk
1. Ambil secukupnya garam, bumbu penyedap
1. Siapkan 1 sdm gula merah
1. Sediakan 1 bh jeruk nipis




<!--inarticleads2-->

##### Cara menyiapkan Ayam rica rica:

1. Potongan ayamnya di marinasi dg jeruk nipis kurang lebih 15 menit kemudian goreng ayamnya setengah mateng atau bisa sampai warna agak kecoklatan
1. Tumis bumbu halus sampai wangi kemudian masukkan lengkuas, serai, tomat dan daun jeruk yg di sobek2. aduk sebentar
1. Masukkan potongan ayam, tambahkan air, aduk rata.. - tambahkan garam, bumbu penyedap dan gula merah.. aduk rata
1. Test rasa jika sudah pas tunggu sbntr sampai air agak menyusut sekitar 15 menit atau lebih.. jika sudah, langsung angkat dan sajikan




Wah ternyata resep ayam rica rica yang lezat tidak rumit ini mudah banget ya! Kamu semua dapat menghidangkannya. Cara Membuat ayam rica rica Sesuai sekali untuk kamu yang baru belajar memasak maupun juga bagi kamu yang sudah ahli memasak.

Tertarik untuk mencoba bikin resep ayam rica rica mantab sederhana ini? Kalau tertarik, ayo kamu segera buruan siapkan peralatan dan bahannya, kemudian bikin deh Resep ayam rica rica yang mantab dan sederhana ini. Benar-benar taidak sulit kan. 

Maka, daripada kita diam saja, ayo langsung aja hidangkan resep ayam rica rica ini. Pasti kalian gak akan nyesel sudah bikin resep ayam rica rica enak simple ini! Selamat mencoba dengan resep ayam rica rica mantab simple ini di rumah kalian masing-masing,oke!.

