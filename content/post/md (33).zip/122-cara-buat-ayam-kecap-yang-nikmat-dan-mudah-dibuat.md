---
description: "Cara buat Ayam kecap yang nikmat dan Mudah Dibuat"
title: "Cara buat Ayam kecap yang nikmat dan Mudah Dibuat"
slug: 122-cara-buat-ayam-kecap-yang-nikmat-dan-mudah-dibuat
date: 2021-04-02T16:10:10.192Z
image: https://img-global.cpcdn.com/recipes/80a267c989457670/680x482cq70/ayam-kecap-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/80a267c989457670/680x482cq70/ayam-kecap-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/80a267c989457670/680x482cq70/ayam-kecap-foto-resep-utama.jpg
author: Derrick Terry
ratingvalue: 4.3
reviewcount: 7
recipeingredient:
- "1/2 kg ayam potong"
- " Bumbu "
- "1 buah bawang bombay"
- "1 siung bawang putih"
- "3 buah cabai rawit sesuai selera"
- "2 lembar daun salam"
- "1 lembar daun jeruk"
- "1 ruas jahe"
- "1 bungkus penyedap me  royco"
- "3 sdm minyak buat menumis"
- "3 tangkai daun kemangi optional"
- "secukupnya Air"
- " Saus marinasi "
- "4 sdm kecap manis"
- "4 sdm saus tiram"
- "3 sdm saus cabai"
- "1/2 buah jeruk nipis"
recipeinstructions:
- "Cuci bersih ayam,lumuri dg air jeruk nipis tambahkan saus marinasi. Diamkan minimal 1/2 jam biar merasuk. Atau kalau masih malas masak bisa taruh di wadah kedap udara &amp; di simpan dulu di freezer."
- "Iris semua bumbu, kecuali daun salam, daun jeruk."
- "Panaskan minyak sayur, tumis bawang bombay n bawang putih hingga harum."
- "Masukkan sisa bumbu, oseng sampai harum, masukkan ayam marinasi aduk rata."
- "Tambahkan air secukupnya, tunggu sampai ayam empuk.matikan api, Masukkan kemangi. Angkat, siap di hidangkan dg nasi anget..... Mantap......"
categories:
- Resep
tags:
- ayam
- kecap

katakunci: ayam kecap 
nutrition: 160 calories
recipecuisine: Indonesian
preptime: "PT26M"
cooktime: "PT54M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam kecap](https://img-global.cpcdn.com/recipes/80a267c989457670/680x482cq70/ayam-kecap-foto-resep-utama.jpg)

Andai kita seorang orang tua, menyuguhkan santapan lezat kepada keluarga adalah hal yang membahagiakan untuk kamu sendiri. Tugas seorang istri Tidak cuman menjaga rumah saja, namun kamu pun wajib memastikan keperluan nutrisi terpenuhi dan panganan yang disantap keluarga tercinta harus sedap.

Di waktu  sekarang, kita sebenarnya bisa membeli panganan praktis tidak harus susah mengolahnya dahulu. Tetapi ada juga mereka yang memang mau menghidangkan yang terlezat untuk orang tercintanya. Pasalnya, menyajikan masakan yang dibuat sendiri jauh lebih bersih dan kita juga bisa menyesuaikan berdasarkan masakan kesukaan keluarga. 



Mungkinkah anda salah satu penyuka ayam kecap?. Tahukah kamu, ayam kecap adalah sajian khas di Indonesia yang kini disukai oleh setiap orang dari hampir setiap tempat di Indonesia. Kalian bisa menghidangkan ayam kecap sendiri di rumahmu dan dapat dijadikan hidangan favoritmu di akhir pekan.

Kalian tak perlu bingung jika kamu ingin menyantap ayam kecap, lantaran ayam kecap sangat mudah untuk ditemukan dan kalian pun boleh memasaknya sendiri di rumah. ayam kecap bisa dibuat dengan beraneka cara. Saat ini sudah banyak cara modern yang menjadikan ayam kecap lebih lezat.

Resep ayam kecap juga gampang sekali dibikin, lho. Kalian tidak usah repot-repot untuk membeli ayam kecap, lantaran Kamu bisa menyajikan di rumah sendiri. Untuk Kita yang akan menyajikannya, berikut cara untuk membuat ayam kecap yang lezat yang bisa Kita hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Ayam kecap:

1. Gunakan 1/2 kg ayam (potong)
1. Ambil  Bumbu :
1. Ambil 1 buah bawang bombay
1. Sediakan 1 siung bawang putih
1. Gunakan 3 buah cabai rawit (sesuai selera)
1. Gunakan 2 lembar daun salam
1. Gunakan 1 lembar daun jeruk
1. Gunakan 1 ruas jahe
1. Ambil 1 bungkus penyedap (me : royco)
1. Ambil 3 sdm minyak buat menumis
1. Siapkan 3 tangkai daun kemangi (optional)
1. Siapkan secukupnya Air
1. Siapkan  Saus marinasi :
1. Sediakan 4 sdm kecap manis
1. Sediakan 4 sdm saus tiram
1. Ambil 3 sdm saus cabai
1. Gunakan 1/2 buah jeruk nipis




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam kecap:

1. Cuci bersih ayam,lumuri dg air jeruk nipis tambahkan saus marinasi. Diamkan minimal 1/2 jam biar merasuk. Atau kalau masih malas masak bisa taruh di wadah kedap udara &amp; di simpan dulu di freezer.
1. Iris semua bumbu, kecuali daun salam, daun jeruk.
1. Panaskan minyak sayur, tumis bawang bombay n bawang putih hingga harum.
1. Masukkan sisa bumbu, oseng sampai harum, masukkan ayam marinasi aduk rata.
1. Tambahkan air secukupnya, tunggu sampai ayam empuk.matikan api, Masukkan kemangi. Angkat, siap di hidangkan dg nasi anget..... Mantap......




Ternyata cara membuat ayam kecap yang nikamt tidak ribet ini gampang banget ya! Kamu semua dapat membuatnya. Resep ayam kecap Sesuai sekali buat kita yang sedang belajar memasak maupun bagi anda yang telah ahli memasak.

Apakah kamu mau mencoba bikin resep ayam kecap nikmat sederhana ini? Kalau ingin, ayo kamu segera buruan siapkan alat-alat dan bahan-bahannya, lalu buat deh Resep ayam kecap yang nikmat dan tidak ribet ini. Sungguh mudah kan. 

Maka, ketimbang kamu diam saja, yuk kita langsung bikin resep ayam kecap ini. Pasti kamu gak akan menyesal sudah bikin resep ayam kecap nikmat sederhana ini! Selamat mencoba dengan resep ayam kecap enak simple ini di rumah masing-masing,ya!.

