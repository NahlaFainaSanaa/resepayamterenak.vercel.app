---
description: "Bahan-bahan Ayam Kecap yang nikmat dan Mudah Dibuat"
title: "Bahan-bahan Ayam Kecap yang nikmat dan Mudah Dibuat"
slug: 366-bahan-bahan-ayam-kecap-yang-nikmat-dan-mudah-dibuat
date: 2021-01-11T05:24:22.279Z
image: https://img-global.cpcdn.com/recipes/f4b5a5af8fdb7453/680x482cq70/ayam-kecap-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f4b5a5af8fdb7453/680x482cq70/ayam-kecap-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f4b5a5af8fdb7453/680x482cq70/ayam-kecap-foto-resep-utama.jpg
author: Marcus Brown
ratingvalue: 3.8
reviewcount: 7
recipeingredient:
- "250 gr ayam"
- "300 ml air"
- "7 sdm kecap manis"
- "1 sdm gula jawa"
- " Bumbu "
- "4 siung bawang putih"
- "5 siung bawang merah"
- "2 cabe merah besar"
- "2 cabe rawit sesuaikan selera"
- "1 ruas lengkuas"
- "1 Bawang bombay ukuran kecil"
- "1 lembar daun salam"
- "1 lembar daun jeruk"
- "1/2 sdt merica bubuk"
- "1/2 sdt kaldu jamur"
recipeinstructions:
- "Potong ayam menjadi beberapa bagian, bersihkan"
- "Iris tipis bawang merah, bawang putih, cabe merah, cabe rawit. Iris memanjang bawang bombay. Geprek lengkuas."
- "Goreng ayam hingga sedikit kecoklatan. Kemudian angkat dan sisihkan"
- "Tumis bawang merah, bawang bombay, bawang putih, daun salam, daun jeruk, lengkuas hingga harum"
- "Masukkan ayam, dan tambahkan 300 ml air, kecap, merica bubuk, kalsu jamur, cabe merah"
- "Masak hingga bumbu meresal ± 15 menit"
- "Sajikan"
categories:
- Resep
tags:
- ayam
- kecap

katakunci: ayam kecap 
nutrition: 113 calories
recipecuisine: Indonesian
preptime: "PT33M"
cooktime: "PT34M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam Kecap](https://img-global.cpcdn.com/recipes/f4b5a5af8fdb7453/680x482cq70/ayam-kecap-foto-resep-utama.jpg)

Andai anda seorang orang tua, menyuguhkan masakan nikmat buat orang tercinta merupakan suatu hal yang membahagiakan untuk kamu sendiri. Tugas seorang ibu bukan cuma menangani rumah saja, tapi kamu juga harus menyediakan kebutuhan nutrisi tercukupi dan juga masakan yang dimakan keluarga tercinta wajib menggugah selera.

Di waktu  sekarang, kamu sebenarnya mampu memesan masakan instan meski tidak harus ribet memasaknya terlebih dahulu. Tetapi ada juga orang yang memang mau menghidangkan yang terenak bagi orang tercintanya. Sebab, menghidangkan masakan yang dibuat sendiri jauh lebih higienis dan bisa menyesuaikan makanan tersebut sesuai masakan kesukaan keluarga tercinta. 



Mungkinkah anda salah satu penikmat ayam kecap?. Asal kamu tahu, ayam kecap merupakan sajian khas di Nusantara yang kini digemari oleh setiap orang dari hampir setiap wilayah di Nusantara. Kita bisa menyajikan ayam kecap hasil sendiri di rumah dan pasti jadi hidangan kegemaranmu di akhir pekan.

Kita tidak perlu bingung untuk mendapatkan ayam kecap, karena ayam kecap gampang untuk dicari dan kalian pun bisa memasaknya sendiri di rumah. ayam kecap boleh diolah lewat bermacam cara. Kini ada banyak cara kekinian yang membuat ayam kecap lebih mantap.

Resep ayam kecap juga gampang untuk dibikin, lho. Kalian tidak usah repot-repot untuk membeli ayam kecap, tetapi Kita bisa menghidangkan sendiri di rumah. Bagi Kita yang ingin menghidangkannya, berikut resep menyajikan ayam kecap yang nikamat yang bisa Anda hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Ayam Kecap:

1. Siapkan 250 gr ayam
1. Sediakan 300 ml air
1. Ambil 7 sdm kecap manis
1. Sediakan 1 sdm gula jawa
1. Siapkan  Bumbu :
1. Gunakan 4 siung bawang putih
1. Sediakan 5 siung bawang merah
1. Siapkan 2 cabe merah besar
1. Siapkan 2 cabe rawit (sesuaikan selera)
1. Ambil 1 ruas lengkuas
1. Gunakan 1 Bawang bombay ukuran kecil
1. Gunakan 1 lembar daun salam
1. Siapkan 1 lembar daun jeruk
1. Gunakan 1/2 sdt merica bubuk
1. Ambil 1/2 sdt kaldu jamur




<!--inarticleads2-->

##### Cara menyiapkan Ayam Kecap:

1. Potong ayam menjadi beberapa bagian, bersihkan
1. Iris tipis bawang merah, bawang putih, cabe merah, cabe rawit. - Iris memanjang bawang bombay. - Geprek lengkuas.
1. Goreng ayam hingga sedikit kecoklatan. Kemudian angkat dan sisihkan
1. Tumis bawang merah, bawang bombay, bawang putih, daun salam, daun jeruk, lengkuas hingga harum
1. Masukkan ayam, dan tambahkan 300 ml air, kecap, merica bubuk, kalsu jamur, cabe merah
1. Masak hingga bumbu meresal ± 15 menit
1. Sajikan




Ternyata cara membuat ayam kecap yang lezat simple ini mudah banget ya! Anda Semua dapat membuatnya. Resep ayam kecap Cocok sekali untuk kita yang baru belajar memasak ataupun juga bagi kamu yang telah pandai dalam memasak.

Apakah kamu mau mencoba buat resep ayam kecap nikmat tidak rumit ini? Kalau kalian mau, yuk kita segera menyiapkan alat-alat dan bahan-bahannya, kemudian buat deh Resep ayam kecap yang nikmat dan tidak ribet ini. Sungguh mudah kan. 

Maka, daripada kamu berlama-lama, maka kita langsung sajikan resep ayam kecap ini. Pasti kalian gak akan nyesel membuat resep ayam kecap lezat simple ini! Selamat berkreasi dengan resep ayam kecap mantab tidak rumit ini di tempat tinggal masing-masing,oke!.

