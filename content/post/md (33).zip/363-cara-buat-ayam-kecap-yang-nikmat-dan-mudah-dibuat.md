---
description: "Cara buat Ayam Kecap yang nikmat dan Mudah Dibuat"
title: "Cara buat Ayam Kecap yang nikmat dan Mudah Dibuat"
slug: 363-cara-buat-ayam-kecap-yang-nikmat-dan-mudah-dibuat
date: 2021-05-04T01:22:03.362Z
image: https://img-global.cpcdn.com/recipes/bd44e3289f836cba/680x482cq70/ayam-kecap-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/bd44e3289f836cba/680x482cq70/ayam-kecap-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/bd44e3289f836cba/680x482cq70/ayam-kecap-foto-resep-utama.jpg
author: Rachel Becker
ratingvalue: 4
reviewcount: 7
recipeingredient:
- "1 kg ayam potong sesuai selera lalu rebus sebentar"
- "5 butir bawang merah haluskan"
- "4 siung bawang putih haluskan"
- "5 lembar daun salam"
- "1 ruas lengkuas geprek"
- "Secukupnya kecap manis kecap asin dan saus tiram"
- "Secukupnya gula merahpasir garam kaldu ayam dan lada bubuk"
- "Secukupnya air"
- "Secukupnya minyakmargarin untuk menumis"
recipeinstructions:
- "Tumis duo bawang yang di haluskan hingga harum, lalu tambahkan air kemudian masukan daun salam dan lengkuas yang telah di geprek. Tunggu hingga air mendidih."
- "Lalu bumbui dengan gula, garam, kaldu ayam, lada bubuk, kecap manis, kecap asin, dan saus tiram. Aduk hingga semua bahan tercampur rata dan mengental. Koreksi rasa."
- "Kemudian masukan potongan ayam yang sudah di rebus sebentar. Aduk-aduk hingga air sedikit surut dan bumbu meresap pada ayam."
- "Kemudian taburi dengan bawang goreng. Sajikan."
categories:
- Resep
tags:
- ayam
- kecap

katakunci: ayam kecap 
nutrition: 200 calories
recipecuisine: Indonesian
preptime: "PT29M"
cooktime: "PT33M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Kecap](https://img-global.cpcdn.com/recipes/bd44e3289f836cba/680x482cq70/ayam-kecap-foto-resep-utama.jpg)

Jika anda seorang wanita, mempersiapkan santapan mantab bagi orang tercinta adalah suatu hal yang menyenangkan untuk kamu sendiri. Peran seorang istri Tidak hanya mengurus rumah saja, namun kamu pun harus memastikan keperluan gizi terpenuhi dan juga masakan yang dimakan anak-anak harus sedap.

Di era  sekarang, kamu sebenarnya bisa memesan hidangan siap saji meski tidak harus susah mengolahnya terlebih dahulu. Tetapi ada juga mereka yang selalu mau memberikan yang terlezat untuk orang yang dicintainya. Sebab, memasak sendiri jauh lebih higienis dan kita pun bisa menyesuaikan masakan tersebut berdasarkan masakan kesukaan orang tercinta. 



Mungkinkah kamu salah satu penggemar ayam kecap?. Tahukah kamu, ayam kecap merupakan sajian khas di Nusantara yang saat ini disenangi oleh orang-orang dari berbagai daerah di Nusantara. Kita bisa menghidangkan ayam kecap sendiri di rumahmu dan boleh jadi santapan favoritmu di hari liburmu.

Kamu tidak perlu bingung jika kamu ingin memakan ayam kecap, karena ayam kecap mudah untuk ditemukan dan kalian pun boleh memasaknya sendiri di rumah. ayam kecap dapat dibuat memalui beraneka cara. Kini ada banyak banget resep kekinian yang membuat ayam kecap semakin mantap.

Resep ayam kecap pun mudah sekali untuk dibikin, lho. Kita tidak perlu ribet-ribet untuk membeli ayam kecap, tetapi Kalian dapat menyiapkan sendiri di rumah. Bagi Anda yang akan mencobanya, inilah cara menyajikan ayam kecap yang nikamat yang mampu Kalian coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Ayam Kecap:

1. Gunakan 1 kg ayam (potong sesuai selera lalu rebus sebentar)
1. Gunakan 5 butir bawang merah (haluskan)
1. Siapkan 4 siung bawang putih (haluskan)
1. Siapkan 5 lembar daun salam
1. Sediakan 1 ruas lengkuas (geprek)
1. Siapkan Secukupnya kecap manis, kecap asin, dan saus tiram
1. Gunakan Secukupnya gula merah+pasir, garam, kaldu ayam, dan lada bubuk
1. Ambil Secukupnya air
1. Siapkan Secukupnya minyak+margarin (untuk menumis)




<!--inarticleads2-->

##### Cara menyiapkan Ayam Kecap:

1. Tumis duo bawang yang di haluskan hingga harum, lalu tambahkan air kemudian masukan daun salam dan lengkuas yang telah di geprek. Tunggu hingga air mendidih.
1. Lalu bumbui dengan gula, garam, kaldu ayam, lada bubuk, kecap manis, kecap asin, dan saus tiram. Aduk hingga semua bahan tercampur rata dan mengental. Koreksi rasa.
1. Kemudian masukan potongan ayam yang sudah di rebus sebentar. Aduk-aduk hingga air sedikit surut dan bumbu meresap pada ayam.
1. Kemudian taburi dengan bawang goreng. Sajikan.




Ternyata cara membuat ayam kecap yang nikamt sederhana ini mudah banget ya! Semua orang mampu mencobanya. Cara Membuat ayam kecap Sangat cocok sekali untuk kalian yang baru akan belajar memasak atau juga untuk kalian yang telah lihai memasak.

Tertarik untuk mulai mencoba membikin resep ayam kecap mantab sederhana ini? Kalau ingin, yuk kita segera buruan siapin alat-alat dan bahannya, lalu bikin deh Resep ayam kecap yang enak dan tidak ribet ini. Sangat gampang kan. 

Maka dari itu, ketimbang kamu berfikir lama-lama, yuk kita langsung saja buat resep ayam kecap ini. Pasti kamu tiidak akan menyesal sudah buat resep ayam kecap lezat simple ini! Selamat mencoba dengan resep ayam kecap mantab simple ini di tempat tinggal masing-masing,oke!.

