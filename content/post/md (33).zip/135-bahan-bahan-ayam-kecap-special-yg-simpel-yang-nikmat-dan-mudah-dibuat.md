---
description: "Bahan-bahan Ayam kecap special yg simpel yang nikmat dan Mudah Dibuat"
title: "Bahan-bahan Ayam kecap special yg simpel yang nikmat dan Mudah Dibuat"
slug: 135-bahan-bahan-ayam-kecap-special-yg-simpel-yang-nikmat-dan-mudah-dibuat
date: 2021-05-10T04:58:19.393Z
image: https://img-global.cpcdn.com/recipes/cfcac53a14431270/680x482cq70/ayam-kecap-special-yg-simpel-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/cfcac53a14431270/680x482cq70/ayam-kecap-special-yg-simpel-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/cfcac53a14431270/680x482cq70/ayam-kecap-special-yg-simpel-foto-resep-utama.jpg
author: Floyd Schultz
ratingvalue: 3.9
reviewcount: 7
recipeingredient:
- "5 sayap ayam me  blansir"
- "7 butir bawang merah"
- "4 butir bawang putih"
- "2 bh cabe merah hijau tambahkan jk suka pedas"
- "2 btg sereh"
- "1 ruas lengkuas"
- "2 lbr daun salam"
- "1 lbr daun jeruk"
- " Kecap manis me bango"
- " Garam merica penyedap"
- " Minyak untuk menumis"
- "Sedikit air kr2 75ml"
recipeinstructions:
- "Potong2 sayap ayam jadi 2 atau sesuai selera. Iris bawang merah, bawang putih dan cabe. Geprek sereh dan lengkuas."
- "Tumis bawang merah, bawang putih dan cabe, tambahkan sereh, lengkuas, daun salam dan daun jeruk, sampai harum."
- "Masukkan ayam, aduk2 sebentar, tambahkan air, kecap (sampai warna kecoklatan) aduk2. Masukkan garam, merica dan penyedap (jika suka). Masak dg api kecil."
- "Tutup wajan supaya air tidak cepat habis, dan bumbu meresap. Sebentar2 dibuka dan bolak-balik ayamnya agar kecap merata."
- "Masak sampai ayam matang betul, dan kuah mengental. Koreksi rasa."
- "Ayam kecap special siap dinikmati 😋"
categories:
- Resep
tags:
- ayam
- kecap
- special

katakunci: ayam kecap special 
nutrition: 254 calories
recipecuisine: Indonesian
preptime: "PT13M"
cooktime: "PT58M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam kecap special yg simpel](https://img-global.cpcdn.com/recipes/cfcac53a14431270/680x482cq70/ayam-kecap-special-yg-simpel-foto-resep-utama.jpg)

Selaku seorang yang hobi memasak, mempersiapkan panganan nikmat pada orang tercinta merupakan suatu hal yang menyenangkan untuk kamu sendiri. Peran seorang ibu Tidak sekedar mengatur rumah saja, namun anda pun wajib memastikan kebutuhan nutrisi terpenuhi dan santapan yang dikonsumsi orang tercinta mesti lezat.

Di era  sekarang, kamu memang dapat mengorder santapan siap saji tidak harus susah memasaknya dulu. Namun banyak juga lho mereka yang selalu mau memberikan hidangan yang terlezat untuk orang tercintanya. Lantaran, menghidangkan masakan yang diolah sendiri jauh lebih higienis dan bisa menyesuaikan hidangan tersebut sesuai dengan kesukaan famili. 



Apakah anda adalah salah satu penyuka ayam kecap special yg simpel?. Asal kamu tahu, ayam kecap special yg simpel merupakan hidangan khas di Nusantara yang saat ini digemari oleh setiap orang di hampir setiap daerah di Indonesia. Kalian bisa memasak ayam kecap special yg simpel buatan sendiri di rumah dan dapat dijadikan camilan favorit di akhir pekan.

Kita jangan bingung untuk menyantap ayam kecap special yg simpel, sebab ayam kecap special yg simpel gampang untuk didapatkan dan kita pun dapat membuatnya sendiri di rumah. ayam kecap special yg simpel boleh diolah lewat bermacam cara. Kini telah banyak cara kekinian yang membuat ayam kecap special yg simpel semakin mantap.

Resep ayam kecap special yg simpel pun mudah untuk dibikin, lho. Kamu tidak usah repot-repot untuk membeli ayam kecap special yg simpel, karena Kamu bisa menyiapkan ditempatmu. Untuk Kita yang ingin menyajikannya, dibawah ini merupakan cara untuk menyajikan ayam kecap special yg simpel yang nikamat yang dapat Anda buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Ayam kecap special yg simpel:

1. Gunakan 5 sayap ayam (me : blansir)
1. Ambil 7 butir bawang merah
1. Sediakan 4 butir bawang putih
1. Siapkan 2 bh cabe merah, hijau (tambahkan jk suka pedas)
1. Ambil 2 btg sereh
1. Sediakan 1 ruas lengkuas
1. Siapkan 2 lbr daun salam
1. Siapkan 1 lbr daun jeruk
1. Gunakan  Kecap manis (me: bango)
1. Gunakan  Garam, merica, penyedap
1. Ambil  Minyak untuk menumis
1. Gunakan Sedikit air (kr2 75ml)




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam kecap special yg simpel:

1. Potong2 sayap ayam jadi 2 atau sesuai selera. Iris bawang merah, bawang putih dan cabe. Geprek sereh dan lengkuas.
1. Tumis bawang merah, bawang putih dan cabe, tambahkan sereh, lengkuas, daun salam dan daun jeruk, sampai harum.
1. Masukkan ayam, aduk2 sebentar, tambahkan air, kecap (sampai warna kecoklatan) aduk2. Masukkan garam, merica dan penyedap (jika suka). Masak dg api kecil.
1. Tutup wajan supaya air tidak cepat habis, dan bumbu meresap. Sebentar2 dibuka dan bolak-balik ayamnya agar kecap merata.
1. Masak sampai ayam matang betul, dan kuah mengental. Koreksi rasa.
1. Ayam kecap special siap dinikmati 😋




Wah ternyata cara membuat ayam kecap special yg simpel yang lezat tidak ribet ini enteng banget ya! Anda Semua dapat mencobanya. Cara buat ayam kecap special yg simpel Cocok banget untuk kita yang sedang belajar memasak maupun juga untuk kamu yang telah ahli memasak.

Apakah kamu tertarik mencoba membikin resep ayam kecap special yg simpel enak tidak rumit ini? Kalau anda ingin, yuk kita segera siapin alat-alat dan bahan-bahannya, setelah itu buat deh Resep ayam kecap special yg simpel yang enak dan sederhana ini. Betul-betul taidak sulit kan. 

Jadi, ketimbang kita berlama-lama, maka langsung aja sajikan resep ayam kecap special yg simpel ini. Pasti kamu tiidak akan menyesal membuat resep ayam kecap special yg simpel nikmat tidak rumit ini! Selamat mencoba dengan resep ayam kecap special yg simpel mantab sederhana ini di rumah sendiri,oke!.

