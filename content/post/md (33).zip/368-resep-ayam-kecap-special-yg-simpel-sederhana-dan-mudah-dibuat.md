---
description: "Resep Ayam kecap special yg simpel Sederhana dan Mudah Dibuat"
title: "Resep Ayam kecap special yg simpel Sederhana dan Mudah Dibuat"
slug: 368-resep-ayam-kecap-special-yg-simpel-sederhana-dan-mudah-dibuat
date: 2021-07-06T07:29:26.879Z
image: https://img-global.cpcdn.com/recipes/cfcac53a14431270/680x482cq70/ayam-kecap-special-yg-simpel-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/cfcac53a14431270/680x482cq70/ayam-kecap-special-yg-simpel-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/cfcac53a14431270/680x482cq70/ayam-kecap-special-yg-simpel-foto-resep-utama.jpg
author: Pauline Young
ratingvalue: 3.3
reviewcount: 5
recipeingredient:
- "5 sayap ayam me  blansir"
- "7 butir bawang merah"
- "4 butir bawang putih"
- "2 bh cabe merah hijau tambahkan jk suka pedas"
- "2 btg sereh"
- "1 ruas lengkuas"
- "2 lbr daun salam"
- "1 lbr daun jeruk"
- " Kecap manis me bango"
- " Garam merica penyedap"
- " Minyak untuk menumis"
- "Sedikit air kr2 75ml"
recipeinstructions:
- "Potong2 sayap ayam jadi 2 atau sesuai selera. Iris bawang merah, bawang putih dan cabe. Geprek sereh dan lengkuas."
- "Tumis bawang merah, bawang putih dan cabe, tambahkan sereh, lengkuas, daun salam dan daun jeruk, sampai harum."
- "Masukkan ayam, aduk2 sebentar, tambahkan air, kecap (sampai warna kecoklatan) aduk2. Masukkan garam, merica dan penyedap (jika suka). Masak dg api kecil."
- "Tutup wajan supaya air tidak cepat habis, dan bumbu meresap. Sebentar2 dibuka dan bolak-balik ayamnya agar kecap merata."
- "Masak sampai ayam matang betul, dan kuah mengental. Koreksi rasa."
- "Ayam kecap special siap dinikmati 😋"
categories:
- Resep
tags:
- ayam
- kecap
- special

katakunci: ayam kecap special 
nutrition: 157 calories
recipecuisine: Indonesian
preptime: "PT39M"
cooktime: "PT52M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam kecap special yg simpel](https://img-global.cpcdn.com/recipes/cfcac53a14431270/680x482cq70/ayam-kecap-special-yg-simpel-foto-resep-utama.jpg)

Sebagai seorang orang tua, menyediakan masakan sedap bagi famili adalah hal yang memuaskan bagi anda sendiri. Kewajiban seorang istri Tidak cuma mengerjakan pekerjaan rumah saja, namun anda juga wajib memastikan keperluan nutrisi terpenuhi dan juga hidangan yang disantap orang tercinta harus menggugah selera.

Di era  saat ini, anda sebenarnya dapat mengorder santapan yang sudah jadi meski tidak harus capek membuatnya terlebih dahulu. Tapi banyak juga mereka yang memang mau menyajikan yang terenak untuk keluarganya. Karena, menghidangkan masakan yang dibuat sendiri jauh lebih bersih dan bisa menyesuaikan masakan tersebut berdasarkan selera orang tercinta. 



Mungkinkah anda merupakan salah satu penggemar ayam kecap special yg simpel?. Asal kamu tahu, ayam kecap special yg simpel adalah sajian khas di Nusantara yang saat ini disenangi oleh kebanyakan orang di hampir setiap wilayah di Nusantara. Kamu dapat memasak ayam kecap special yg simpel sendiri di rumah dan pasti jadi hidangan favorit di akhir pekanmu.

Anda tidak perlu bingung jika kamu ingin memakan ayam kecap special yg simpel, sebab ayam kecap special yg simpel gampang untuk didapatkan dan juga kalian pun boleh membuatnya sendiri di rumah. ayam kecap special yg simpel bisa dimasak memalui berbagai cara. Kini pun sudah banyak banget cara kekinian yang menjadikan ayam kecap special yg simpel semakin nikmat.

Resep ayam kecap special yg simpel pun mudah sekali untuk dibikin, lho. Anda tidak usah capek-capek untuk memesan ayam kecap special yg simpel, lantaran Kamu dapat menyiapkan di rumah sendiri. Bagi Kita yang mau mencobanya, berikut resep membuat ayam kecap special yg simpel yang mantab yang dapat Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Ayam kecap special yg simpel:

1. Ambil 5 sayap ayam (me : blansir)
1. Sediakan 7 butir bawang merah
1. Gunakan 4 butir bawang putih
1. Siapkan 2 bh cabe merah, hijau (tambahkan jk suka pedas)
1. Sediakan 2 btg sereh
1. Ambil 1 ruas lengkuas
1. Siapkan 2 lbr daun salam
1. Ambil 1 lbr daun jeruk
1. Siapkan  Kecap manis (me: bango)
1. Sediakan  Garam, merica, penyedap
1. Sediakan  Minyak untuk menumis
1. Gunakan Sedikit air (kr2 75ml)




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam kecap special yg simpel:

1. Potong2 sayap ayam jadi 2 atau sesuai selera. Iris bawang merah, bawang putih dan cabe. Geprek sereh dan lengkuas.
1. Tumis bawang merah, bawang putih dan cabe, tambahkan sereh, lengkuas, daun salam dan daun jeruk, sampai harum.
1. Masukkan ayam, aduk2 sebentar, tambahkan air, kecap (sampai warna kecoklatan) aduk2. Masukkan garam, merica dan penyedap (jika suka). Masak dg api kecil.
1. Tutup wajan supaya air tidak cepat habis, dan bumbu meresap. Sebentar2 dibuka dan bolak-balik ayamnya agar kecap merata.
1. Masak sampai ayam matang betul, dan kuah mengental. Koreksi rasa.
1. Ayam kecap special siap dinikmati 😋




Wah ternyata cara buat ayam kecap special yg simpel yang mantab sederhana ini enteng sekali ya! Kita semua dapat membuatnya. Cara Membuat ayam kecap special yg simpel Cocok sekali buat kamu yang baru mau belajar memasak atau juga bagi anda yang telah lihai memasak.

Tertarik untuk mulai mencoba membuat resep ayam kecap special yg simpel lezat tidak rumit ini? Kalau kamu tertarik, ayo kamu segera siapin peralatan dan bahan-bahannya, setelah itu bikin deh Resep ayam kecap special yg simpel yang nikmat dan simple ini. Betul-betul taidak sulit kan. 

Maka, daripada kalian diam saja, yuk kita langsung hidangkan resep ayam kecap special yg simpel ini. Pasti kamu gak akan menyesal sudah buat resep ayam kecap special yg simpel mantab sederhana ini! Selamat mencoba dengan resep ayam kecap special yg simpel enak sederhana ini di tempat tinggal masing-masing,oke!.

