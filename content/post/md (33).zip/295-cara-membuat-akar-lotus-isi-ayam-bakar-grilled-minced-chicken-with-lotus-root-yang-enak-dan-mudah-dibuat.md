---
description: "Cara membuat Akar Lotus Isi Ayam Bakar 鶏ひき肉の蓮根はさみ焼き Grilled minced chicken with lotus root yang enak dan Mudah Dibuat"
title: "Cara membuat Akar Lotus Isi Ayam Bakar 鶏ひき肉の蓮根はさみ焼き Grilled minced chicken with lotus root yang enak dan Mudah Dibuat"
slug: 295-cara-membuat-akar-lotus-isi-ayam-bakar-grilled-minced-chicken-with-lotus-root-yang-enak-dan-mudah-dibuat
date: 2021-03-15T09:27:35.099Z
image: https://img-global.cpcdn.com/recipes/491dcf189f479a87/680x482cq70/akar-lotus-isi-ayam-bakar-鶏ひき肉の蓮根はさみ焼き-grilled-minced-chicken-with-lotus-root-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/491dcf189f479a87/680x482cq70/akar-lotus-isi-ayam-bakar-鶏ひき肉の蓮根はさみ焼き-grilled-minced-chicken-with-lotus-root-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/491dcf189f479a87/680x482cq70/akar-lotus-isi-ayam-bakar-鶏ひき肉の蓮根はさみ焼き-grilled-minced-chicken-with-lotus-root-foto-resep-utama.jpg
author: Frank Lawrence
ratingvalue: 4.3
reviewcount: 10
recipeingredient:
- "200 g Ayam cincang    Minced chicken"
- "1 pc Akar lotus    Lotus root"
- "1 atau 2 pcs telur    egg "
- "10 g Tepung Maizena    Cornstarch "
- "Secukupnya garam dan lada    Salt  pepper "
- "15 g Sake   "
- "20 g Daun bawang iris    Chopped Green Onion "
- " Sake bisa diganti dengan air15g"
- " 15g"
- " If Sake is not used replace it with 15g water"
- " Saus    sauce"
- " 1  1 sesame"
- " Buat saus dari kecap shoyu dan cuka dengan perbandingan 11"
- " Make sauce with shoyu soy sauce and vinegar with ratio 11"
recipeinstructions:
- "Potong akar lotus dengan ketebalan -/+ 1 cm Cut the lotus root width -/+ 1 cm"
- "Taruh semua bahan dalam mangkuk (kecuali lotus dan bahan saus). Aduk bahan hingga kental/tercampur rata 全ての材料をボウルに入れて、粘りが出るまで練る。 Put all ingredients in a bowl and knead until sticky"
- "Rendam akar lotus dalam air cuka selama 15 menit 3㎜位にスライスした蓮根を酢水につける（15分） Soak lotus root sliced ​​in 3 mm in vinegar water (15 minutes)"
- "Lap akar lotus hingga kering dari air cuka, kemudian tumpuk dengan adonan ayam kemudian tumpuk lagi dengan lotus (buat seperti hamburger) kemudian bubuhkan dengan tepung maizena 水分をふき取ったレンコンを並べてコーンスターチを振りかけ、鶏ミンチを 載せる lotus roots that have been wiped off the water, sprinkler with cornstarch, and minced chicken."
- "Taruh minyak di wajan dengan api rendah, kemudian goreng lotus ayam yang sudah dibubuhi dengan tepung maizena 弱火で温めたフライパンに油を入れ、周りをコーンスターチでコーティング した蓮根を並べる。 Put oil in a frying pan warmed on low heat and lotus roots coat with cornstarch."
- "Apabila lotus bagian bawah sudah matang, balik ke sisi satunya kemudian tutup panci dan masak dengan api rendah 片面が焼けたらレンコンをひっくり返してフライパンに蓋をする（弱火） When one side is cooked, turn the lotus root over and cover the frying pan (low heat)."
- "Apabila kedua sisi sudah matang, tuangkan bahan saus. Apabila sudah tidak berair berarti lotus ayam siap dihidangkan 両面が良く焼けたらポン酢を入れて水分が無くなったら出来上がり。 When both sides are well baked, add ponzu vinegar and when the water is gone, it&#39;s done."
categories:
- Resep
tags:
- akar
- lotus
- isi

katakunci: akar lotus isi 
nutrition: 114 calories
recipecuisine: Indonesian
preptime: "PT11M"
cooktime: "PT52M"
recipeyield: "1"
recipecategory: Lunch

---


![Akar Lotus Isi Ayam Bakar 鶏ひき肉の蓮根はさみ焼き
Grilled minced chicken with lotus root](https://img-global.cpcdn.com/recipes/491dcf189f479a87/680x482cq70/akar-lotus-isi-ayam-bakar-鶏ひき肉の蓮根はさみ焼き-grilled-minced-chicken-with-lotus-root-foto-resep-utama.jpg)

Selaku seorang istri, menyajikan masakan lezat untuk famili merupakan hal yang sangat menyenangkan bagi anda sendiri. Tugas seorang  wanita bukan sekadar mengerjakan pekerjaan rumah saja, tetapi kamu juga harus menyediakan keperluan nutrisi tercukupi dan panganan yang disantap anak-anak harus lezat.

Di era  saat ini, kita sebenarnya mampu mengorder santapan yang sudah jadi walaupun tidak harus repot memasaknya dahulu. Tetapi ada juga mereka yang selalu ingin menyajikan yang terenak untuk orang tercintanya. Lantaran, menyajikan masakan yang diolah sendiri jauh lebih bersih dan kita juga bisa menyesuaikan makanan tersebut sesuai dengan makanan kesukaan keluarga. 



Apakah anda seorang penikmat akar lotus isi ayam bakar 鶏ひき肉の蓮根はさみ焼き
grilled minced chicken with lotus root?. Asal kamu tahu, akar lotus isi ayam bakar 鶏ひき肉の蓮根はさみ焼き
grilled minced chicken with lotus root adalah makanan khas di Nusantara yang sekarang digemari oleh orang-orang di hampir setiap daerah di Indonesia. Kamu dapat menghidangkan akar lotus isi ayam bakar 鶏ひき肉の蓮根はさみ焼き
grilled minced chicken with lotus root sendiri di rumah dan dapat dijadikan hidangan kesenanganmu di akhir pekanmu.

Anda tidak perlu bingung untuk mendapatkan akar lotus isi ayam bakar 鶏ひき肉の蓮根はさみ焼き
grilled minced chicken with lotus root, sebab akar lotus isi ayam bakar 鶏ひき肉の蓮根はさみ焼き
grilled minced chicken with lotus root sangat mudah untuk didapatkan dan kamu pun boleh membuatnya sendiri di rumah. akar lotus isi ayam bakar 鶏ひき肉の蓮根はさみ焼き
grilled minced chicken with lotus root dapat dimasak memalui berbagai cara. Saat ini ada banyak banget cara kekinian yang membuat akar lotus isi ayam bakar 鶏ひき肉の蓮根はさみ焼き
grilled minced chicken with lotus root semakin mantap.

Resep akar lotus isi ayam bakar 鶏ひき肉の蓮根はさみ焼き
grilled minced chicken with lotus root juga gampang sekali dihidangkan, lho. Kita jangan ribet-ribet untuk membeli akar lotus isi ayam bakar 鶏ひき肉の蓮根はさみ焼き
grilled minced chicken with lotus root, lantaran Kalian mampu menyajikan ditempatmu. Bagi Anda yang akan mencobanya, berikut ini cara membuat akar lotus isi ayam bakar 鶏ひき肉の蓮根はさみ焼き
grilled minced chicken with lotus root yang enak yang bisa Kita coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Akar Lotus Isi Ayam Bakar 鶏ひき肉の蓮根はさみ焼き
Grilled minced chicken with lotus root:

1. Sediakan 200 g Ayam cincang / 鶏ひき肉 / Minced chicken
1. Siapkan 1 pc Akar lotus / 蓮根 / Lotus root
1. Sediakan 1 atau 2 pcs telur / 卵 / egg ☆
1. Siapkan 10 g Tepung Maizena / コーンスターチ / Cornstarch ☆
1. Sediakan Secukupnya garam dan lada / 塩コショウ / Salt &amp; pepper ☆
1. Sediakan 15 g Sake / 酒 ☆
1. Sediakan 20 g Daun bawang iris / 青ネギみじん切り / Chopped Green Onion ☆
1. Sediakan  Sake bisa diganti dengan air15g
1. Sediakan  酒を使用しない場合、水15gと置き換えてください。
1. Siapkan  If Sake is not used, replace it with 15g water
1. Ambil  Saus / ソース / sauce
1. Ambil  醤油1 : 酢1 白ごま/sesame
1. Siapkan  Buat saus dari kecap shoyu dan cuka dengan perbandingan 1:1
1. Siapkan  Make sauce with shoyu soy sauce and vinegar with ratio 1:1




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Akar Lotus Isi Ayam Bakar 鶏ひき肉の蓮根はさみ焼き
Grilled minced chicken with lotus root:

1. Potong akar lotus dengan ketebalan -/+ 1 cm - Cut the lotus root width -/+ 1 cm
1. Taruh semua bahan dalam mangkuk (kecuali lotus dan bahan saus). Aduk bahan hingga kental/tercampur rata - 全ての材料をボウルに入れて、粘りが出るまで練る。 - Put all ingredients in a bowl and knead until sticky
1. Rendam akar lotus dalam air cuka selama 15 menit - 3㎜位にスライスした蓮根を酢水につける（15分） - Soak lotus root sliced ​​in 3 mm in vinegar water (15 minutes)
1. Lap akar lotus hingga kering dari air cuka, kemudian tumpuk dengan adonan ayam kemudian tumpuk lagi dengan lotus (buat seperti hamburger) kemudian bubuhkan dengan tepung maizena - 水分をふき取ったレンコンを並べてコーンスターチを振りかけ、鶏ミンチを - 載せる - lotus roots that have been wiped off the water, sprinkler with cornstarch, and minced chicken.
1. Taruh minyak di wajan dengan api rendah, kemudian goreng lotus ayam yang sudah dibubuhi dengan tepung maizena - 弱火で温めたフライパンに油を入れ、周りをコーンスターチでコーティング - した蓮根を並べる。 - Put oil in a frying pan warmed on low heat and lotus roots coat with cornstarch.
1. Apabila lotus bagian bawah sudah matang, balik ke sisi satunya kemudian tutup panci dan masak dengan api rendah - 片面が焼けたらレンコンをひっくり返してフライパンに蓋をする（弱火） - When one side is cooked, turn the lotus root over and cover the frying pan (low heat).
1. Apabila kedua sisi sudah matang, tuangkan bahan saus. Apabila sudah tidak berair berarti lotus ayam siap dihidangkan - 両面が良く焼けたらポン酢を入れて水分が無くなったら出来上がり。 - When both sides are well baked, add ponzu vinegar and when the water is gone, it&#39;s done.




Ternyata cara buat akar lotus isi ayam bakar 鶏ひき肉の蓮根はさみ焼き
grilled minced chicken with lotus root yang mantab tidak rumit ini gampang sekali ya! Anda Semua bisa membuatnya. Resep akar lotus isi ayam bakar 鶏ひき肉の蓮根はさみ焼き
grilled minced chicken with lotus root Sangat sesuai sekali buat kita yang baru mau belajar memasak maupun untuk kalian yang telah hebat dalam memasak.

Apakah kamu ingin mulai mencoba buat resep akar lotus isi ayam bakar 鶏ひき肉の蓮根はさみ焼き
grilled minced chicken with lotus root enak simple ini? Kalau ingin, ayo kalian segera siapin peralatan dan bahan-bahannya, maka buat deh Resep akar lotus isi ayam bakar 鶏ひき肉の蓮根はさみ焼き
grilled minced chicken with lotus root yang lezat dan sederhana ini. Benar-benar mudah kan. 

Jadi, daripada kita diam saja, yuk kita langsung saja bikin resep akar lotus isi ayam bakar 鶏ひき肉の蓮根はさみ焼き
grilled minced chicken with lotus root ini. Dijamin kamu tak akan menyesal sudah bikin resep akar lotus isi ayam bakar 鶏ひき肉の蓮根はさみ焼き
grilled minced chicken with lotus root nikmat tidak rumit ini! Selamat berkreasi dengan resep akar lotus isi ayam bakar 鶏ひき肉の蓮根はさみ焼き
grilled minced chicken with lotus root mantab sederhana ini di tempat tinggal kalian sendiri,oke!.

