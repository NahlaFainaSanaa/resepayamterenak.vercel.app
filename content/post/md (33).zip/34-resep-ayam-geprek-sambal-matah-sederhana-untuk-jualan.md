---
description: "Resep Ayam Geprek Sambal Matah Sederhana Untuk Jualan"
title: "Resep Ayam Geprek Sambal Matah Sederhana Untuk Jualan"
slug: 34-resep-ayam-geprek-sambal-matah-sederhana-untuk-jualan
date: 2021-06-29T17:51:20.565Z
image: https://img-global.cpcdn.com/recipes/962f2cdd6e5e5901/680x482cq70/ayam-geprek-sambal-matah-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/962f2cdd6e5e5901/680x482cq70/ayam-geprek-sambal-matah-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/962f2cdd6e5e5901/680x482cq70/ayam-geprek-sambal-matah-foto-resep-utama.jpg
author: Adam Moran
ratingvalue: 3.5
reviewcount: 7
recipeingredient:
- " Bahan Ayam Krispi"
- "8 potong ayam bagian paha 4 paha atas  4 paha bawah"
- "1/2-1 sdt garam"
- "1/4 sdt lada"
- "1/2 sdt bawang putih bubuk  1 siung bawang putih cincang"
- "1 butir telur kocok lepas"
- " Minyak untuk menggoreng"
- " Bahan baluran kering ayam"
- "20 sdm tepung terigu"
- "4 sdm maizena  pati jagung"
- " Bahan Sambal Matah"
- "16 butir bawang merah iris halus"
- "5 bh cabai rawit buang biji iris"
- "4 lembar daun jeruk buang batang daun iris halus"
- "1 batang serai bagian putihnya iris"
- "2 sdm air jeruk nipis"
- "1/2 sdt garam kurang lebih"
- "1 sdt gula kurang lebih"
- "1/4 sdt kaldu jamur"
- "5 sdm minyak panas"
recipeinstructions:
- "Siapkan semua bahan"
- "Marinasi ayam potong dengan bawang putih, garam, lada minimal 30 menit"
- "Campurkan bahan baluran kering ayam secara merata"
- "Tambahkan kocokan telur ke ayam yang sudah dimarinasi, lalu balurkan campuran tepung. Goreng di minyak yang cukup banyak dan panas. Selama menggoreng apinya sedang aja. Goreng selama kurang lebih 8 menit di satu sisi, balik, goreng lagi 3 menit (sesuaikan besar potongan ayam juga ya)"
- "Campur bahan sambal matah KECUALI garam, gula, kaldu jamur, minyak panas, dan air jeruk nipis"
- "Siramkan minyak panas secara merata ke campuran sambal, tambahkan garam, gula, kaldu jamur, aduk hingga rata. Terakhir tambah air jeruk nipis lalu aduk rata lagi"
- "Geprek ayam krispi, tambahkan sambal matah, geprek lagi perlahan. Sajikan dengan nasi 😋"
categories:
- Resep
tags:
- ayam
- geprek
- sambal

katakunci: ayam geprek sambal 
nutrition: 204 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT59M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam Geprek Sambal Matah](https://img-global.cpcdn.com/recipes/962f2cdd6e5e5901/680x482cq70/ayam-geprek-sambal-matah-foto-resep-utama.jpg)

Sebagai seorang ibu, menyuguhkan panganan enak bagi keluarga merupakan hal yang sangat menyenangkan untuk kita sendiri. Tugas seorang  wanita bukan cuma mengerjakan pekerjaan rumah saja, tapi kamu juga wajib menyediakan kebutuhan nutrisi tercukupi dan santapan yang dimakan keluarga tercinta mesti menggugah selera.

Di waktu  sekarang, kamu sebenarnya bisa memesan hidangan instan walaupun tanpa harus susah mengolahnya terlebih dahulu. Tapi banyak juga lho mereka yang memang mau menghidangkan yang terbaik bagi keluarganya. Karena, menyajikan masakan yang dibuat sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan masakan tersebut sesuai makanan kesukaan famili. 



Apakah anda salah satu penyuka ayam geprek sambal matah?. Tahukah kamu, ayam geprek sambal matah adalah hidangan khas di Nusantara yang sekarang disukai oleh kebanyakan orang di hampir setiap wilayah di Nusantara. Kita bisa menyajikan ayam geprek sambal matah sendiri di rumah dan pasti jadi hidangan favorit di akhir pekan.

Kalian jangan bingung jika kamu ingin memakan ayam geprek sambal matah, sebab ayam geprek sambal matah tidak sulit untuk didapatkan dan juga kamu pun boleh menghidangkannya sendiri di rumah. ayam geprek sambal matah boleh diolah lewat beragam cara. Kini ada banyak banget cara modern yang menjadikan ayam geprek sambal matah lebih nikmat.

Resep ayam geprek sambal matah juga gampang sekali untuk dibuat, lho. Anda jangan repot-repot untuk membeli ayam geprek sambal matah, karena Kita dapat membuatnya sendiri di rumah. Bagi Kita yang mau menghidangkannya, berikut ini resep untuk membuat ayam geprek sambal matah yang lezat yang bisa Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Ayam Geprek Sambal Matah:

1. Siapkan  Bahan Ayam Krispi
1. Sediakan 8 potong ayam bagian paha (4 paha atas + 4 paha bawah)
1. Ambil 1/2-1 sdt garam
1. Ambil 1/4 sdt lada
1. Sediakan 1/2 sdt bawang putih bubuk / 1 siung bawang putih cincang
1. Siapkan 1 butir telur, kocok lepas
1. Siapkan  Minyak untuk menggoreng
1. Siapkan  Bahan baluran kering ayam
1. Sediakan 20 sdm tepung terigu
1. Gunakan 4 sdm maizena / pati jagung
1. Ambil  Bahan Sambal Matah
1. Gunakan 16 butir bawang merah, iris halus
1. Ambil 5 bh cabai rawit, buang biji, iris
1. Siapkan 4 lembar daun jeruk, buang batang daun, iris halus
1. Siapkan 1 batang serai bagian putihnya, iris
1. Sediakan 2 sdm air jeruk nipis
1. Ambil 1/2 sdt garam (kurang lebih)
1. Ambil 1 sdt gula (kurang lebih)
1. Ambil 1/4 sdt kaldu jamur
1. Siapkan 5 sdm minyak panas




<!--inarticleads2-->

##### Cara menyiapkan Ayam Geprek Sambal Matah:

1. Siapkan semua bahan
1. Marinasi ayam potong dengan bawang putih, garam, lada minimal 30 menit
1. Campurkan bahan baluran kering ayam secara merata
1. Tambahkan kocokan telur ke ayam yang sudah dimarinasi, lalu balurkan campuran tepung. Goreng di minyak yang cukup banyak dan panas. Selama menggoreng apinya sedang aja. Goreng selama kurang lebih 8 menit di satu sisi, balik, goreng lagi 3 menit (sesuaikan besar potongan ayam juga ya)
1. Campur bahan sambal matah KECUALI garam, gula, kaldu jamur, minyak panas, dan air jeruk nipis
1. Siramkan minyak panas secara merata ke campuran sambal, tambahkan garam, gula, kaldu jamur, aduk hingga rata. Terakhir tambah air jeruk nipis lalu aduk rata lagi
1. Geprek ayam krispi, tambahkan sambal matah, geprek lagi perlahan. Sajikan dengan nasi 😋




Wah ternyata cara membuat ayam geprek sambal matah yang nikamt simple ini gampang sekali ya! Kalian semua mampu membuatnya. Resep ayam geprek sambal matah Cocok banget untuk kamu yang baru mau belajar memasak ataupun bagi kalian yang telah jago memasak.

Apakah kamu tertarik mencoba membuat resep ayam geprek sambal matah mantab tidak rumit ini? Kalau tertarik, ayo kamu segera siapin alat dan bahannya, kemudian bikin deh Resep ayam geprek sambal matah yang lezat dan tidak rumit ini. Sungguh gampang kan. 

Maka, daripada kalian diam saja, ayo kita langsung sajikan resep ayam geprek sambal matah ini. Pasti kamu gak akan menyesal membuat resep ayam geprek sambal matah mantab tidak ribet ini! Selamat mencoba dengan resep ayam geprek sambal matah nikmat tidak rumit ini di tempat tinggal masing-masing,oke!.

