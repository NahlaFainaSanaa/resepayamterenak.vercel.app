---
description: "Bahan-bahan Opor ayam yang enak dan Mudah Dibuat"
title: "Bahan-bahan Opor ayam yang enak dan Mudah Dibuat"
slug: 174-bahan-bahan-opor-ayam-yang-enak-dan-mudah-dibuat
date: 2021-02-27T01:07:12.720Z
image: https://img-global.cpcdn.com/recipes/e858518107323b0d/680x482cq70/opor-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e858518107323b0d/680x482cq70/opor-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e858518107323b0d/680x482cq70/opor-ayam-foto-resep-utama.jpg
author: Nellie Castillo
ratingvalue: 3.3
reviewcount: 14
recipeingredient:
- "1 Kg ayam"
- "1/2 kg kentang"
- "5 siung bawang merah"
- "4 siung bawang putih"
- "1 santan kara 65 ml"
- "4 butir kemiri"
- "1 sdt ketumbar bubuk"
- "1 sdm garam"
- "1/2 sdt penyedap rasa"
- "secukupnya Daun salam"
- "1 batang Serai"
- "2 lembar daun jeruk"
- "1 ruas lengkuas geprek"
- "1 sdt kunyit bubuk"
- " Minyak goreng untuk menumis"
- " Bawang goreng"
recipeinstructions:
- "Potong ayam sesuai selera, kemudian cuci besih"
- "Haluskan bawang merah, bawang putih, dan kemiri. Lalu tumis bumbi halus tambahkan ketumbar bubuk, kunyit bubuk, daun salam, daun jeruk, serai dan lengkuas. Tumis semua bumbu hingga harum."
- "Setelah bumbu matang, tuang 1sachet santan kara dan tambahkan 1 liter air. Masukkan ayam dan kentang yang dipotong sesuai selera rebus hingga empuk."
- "Uji rasa dengan menambahkan garam dan penyedap rasa secukupnya. Setelah matang angkat dan beri taburan bawang goreng."
categories:
- Resep
tags:
- opor
- ayam

katakunci: opor ayam 
nutrition: 107 calories
recipecuisine: Indonesian
preptime: "PT18M"
cooktime: "PT32M"
recipeyield: "3"
recipecategory: Dessert

---


![Opor ayam](https://img-global.cpcdn.com/recipes/e858518107323b0d/680x482cq70/opor-ayam-foto-resep-utama.jpg)

Selaku seorang istri, menyajikan santapan enak buat keluarga merupakan hal yang memuaskan untuk anda sendiri. Peran seorang  wanita bukan sekadar mengerjakan pekerjaan rumah saja, tapi kamu pun wajib memastikan kebutuhan gizi terpenuhi dan olahan yang dimakan orang tercinta wajib nikmat.

Di era  saat ini, kita memang dapat mengorder hidangan siap saji tanpa harus ribet mengolahnya dulu. Tetapi ada juga mereka yang selalu ingin memberikan yang terenak untuk keluarganya. Sebab, menghidangkan masakan yang diolah sendiri jauh lebih higienis dan bisa menyesuaikan makanan tersebut berdasarkan makanan kesukaan famili. 



Apakah kamu salah satu penikmat opor ayam?. Tahukah kamu, opor ayam adalah makanan khas di Nusantara yang saat ini disukai oleh kebanyakan orang dari berbagai daerah di Indonesia. Kita bisa menghidangkan opor ayam sendiri di rumahmu dan pasti jadi camilan kesenanganmu di hari libur.

Kita tak perlu bingung untuk mendapatkan opor ayam, lantaran opor ayam tidak sulit untuk didapatkan dan kita pun dapat memasaknya sendiri di rumah. opor ayam bisa diolah lewat berbagai cara. Kini pun telah banyak cara modern yang menjadikan opor ayam lebih nikmat.

Resep opor ayam juga sangat mudah dibuat, lho. Anda jangan repot-repot untuk memesan opor ayam, karena Kalian mampu membuatnya ditempatmu. Bagi Kalian yang ingin menghidangkannya, di bawah ini adalah resep menyajikan opor ayam yang nikamat yang mampu Kamu coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Opor ayam:

1. Ambil 1 Kg ayam
1. Ambil 1/2 kg kentang
1. Ambil 5 siung bawang merah
1. Gunakan 4 siung bawang putih
1. Gunakan 1 santan kara 65 ml
1. Ambil 4 butir kemiri
1. Gunakan 1 sdt ketumbar bubuk
1. Siapkan 1 sdm garam
1. Ambil 1/2 sdt penyedap rasa
1. Siapkan secukupnya Daun salam
1. Gunakan 1 batang Serai
1. Siapkan 2 lembar daun jeruk
1. Sediakan 1 ruas lengkuas geprek
1. Siapkan 1 sdt kunyit bubuk
1. Ambil  Minyak goreng untuk menumis
1. Gunakan  Bawang goreng




<!--inarticleads2-->

##### Cara membuat Opor ayam:

1. Potong ayam sesuai selera, kemudian cuci besih
1. Haluskan bawang merah, bawang putih, dan kemiri. Lalu tumis bumbi halus tambahkan ketumbar bubuk, kunyit bubuk, daun salam, daun jeruk, serai dan lengkuas. Tumis semua bumbu hingga harum.
1. Setelah bumbu matang, tuang 1sachet santan kara dan tambahkan 1 liter air. Masukkan ayam dan kentang yang dipotong sesuai selera rebus hingga empuk.
1. Uji rasa dengan menambahkan garam dan penyedap rasa secukupnya. Setelah matang angkat dan beri taburan bawang goreng.




Ternyata resep opor ayam yang mantab sederhana ini mudah sekali ya! Semua orang bisa mencobanya. Cara Membuat opor ayam Sangat sesuai banget buat kalian yang baru akan belajar memasak ataupun juga untuk kamu yang telah jago dalam memasak.

Tertarik untuk mulai mencoba buat resep opor ayam enak sederhana ini? Kalau kamu ingin, ayo kamu segera buruan menyiapkan alat-alat dan bahan-bahannya, setelah itu buat deh Resep opor ayam yang lezat dan sederhana ini. Sungguh mudah kan. 

Oleh karena itu, daripada kita berlama-lama, hayo kita langsung buat resep opor ayam ini. Dijamin kamu tiidak akan nyesel sudah buat resep opor ayam lezat tidak ribet ini! Selamat berkreasi dengan resep opor ayam nikmat simple ini di tempat tinggal masing-masing,oke!.

