---
description: "Cara membuat Soto ayam yang lezat Untuk Jualan"
title: "Cara membuat Soto ayam yang lezat Untuk Jualan"
slug: 81-cara-membuat-soto-ayam-yang-lezat-untuk-jualan
date: 2021-01-10T04:42:43.443Z
image: https://img-global.cpcdn.com/recipes/d7ef7e15648dcbb0/680x482cq70/soto-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d7ef7e15648dcbb0/680x482cq70/soto-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d7ef7e15648dcbb0/680x482cq70/soto-ayam-foto-resep-utama.jpg
author: Johanna Mann
ratingvalue: 4.1
reviewcount: 7
recipeingredient:
- "1/2 kg ayam"
- " Bumbu halus "
- "5 siung bawang putih"
- "8 siung bawang merah"
- "4 buah kemiri"
- "2 ruas kunyit"
- " Tambahan "
- "2 batang sereh geprek"
- "3 lembar daun salam"
- "6 lembar daun jeruk"
- "1 ruas lengkuas geprek"
- "2 batang daun bawang iris"
- "1 batang seledri iris"
- "1 buah tomat iris sesuai selera"
- "1/2 jeruk nipis"
- "2 sdt Garam"
- "1/2 sdt Gula"
- "1 sdt Lada bubuk"
recipeinstructions:
- "Rebus ayam tidak usah lama2, lalu buang airnya. Rebus kembali."
- "Tumis bumbu halus di atas api sedang, jika sudah harum masukan daun salam, daun jeruk, sereh, lengkuas. Tambahkan 1 gelas belimbing air. Aduk sampai air mendidih. Matikan."
- "Jika rebusan ayam sudah mendidih, masukan bumbu yg sudah di tumis tadi. Aduk."
- "Tambahkan garam, lada, gula. Cek rasa. Matikan kompor."
- "Hidangkan soto di mangkuk, jangan lupa di beri irisan daun bawang, daun seledri, tomat dan perasan jeruk agar tambah segar."
categories:
- Resep
tags:
- soto
- ayam

katakunci: soto ayam 
nutrition: 107 calories
recipecuisine: Indonesian
preptime: "PT13M"
cooktime: "PT58M"
recipeyield: "2"
recipecategory: Dinner

---


![Soto ayam](https://img-global.cpcdn.com/recipes/d7ef7e15648dcbb0/680x482cq70/soto-ayam-foto-resep-utama.jpg)

Jika anda seorang orang tua, menyajikan masakan menggugah selera kepada keluarga tercinta merupakan hal yang menyenangkan bagi kita sendiri. Kewajiban seorang ibu bukan saja mengerjakan pekerjaan rumah saja, tetapi anda juga harus memastikan kebutuhan nutrisi terpenuhi dan masakan yang dikonsumsi keluarga tercinta mesti lezat.

Di era  sekarang, kalian memang bisa mengorder hidangan yang sudah jadi tanpa harus ribet membuatnya terlebih dahulu. Tapi ada juga lho mereka yang selalu mau memberikan makanan yang terenak untuk keluarganya. Lantaran, memasak yang dibuat sendiri jauh lebih higienis dan kita pun bisa menyesuaikan makanan tersebut sesuai makanan kesukaan orang tercinta. 



Apakah kamu seorang penyuka soto ayam?. Tahukah kamu, soto ayam adalah makanan khas di Nusantara yang kini disenangi oleh kebanyakan orang dari berbagai wilayah di Indonesia. Kalian dapat memasak soto ayam sendiri di rumahmu dan pasti jadi santapan kesukaanmu di akhir pekan.

Kalian tak perlu bingung jika kamu ingin menyantap soto ayam, karena soto ayam gampang untuk ditemukan dan anda pun boleh memasaknya sendiri di tempatmu. soto ayam dapat dibuat dengan beragam cara. Kini pun telah banyak banget cara kekinian yang menjadikan soto ayam lebih mantap.

Resep soto ayam juga gampang sekali dibikin, lho. Kita tidak usah capek-capek untuk memesan soto ayam, karena Anda dapat menghidangkan ditempatmu. Untuk Kalian yang ingin menghidangkannya, inilah resep membuat soto ayam yang mantab yang mampu Kita hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Soto ayam:

1. Siapkan 1/2 kg ayam
1. Siapkan  Bumbu halus :
1. Siapkan 5 siung bawang putih
1. Ambil 8 siung bawang merah
1. Sediakan 4 buah kemiri
1. Siapkan 2 ruas kunyit
1. Gunakan  Tambahan :
1. Gunakan 2 batang sereh (geprek)
1. Siapkan 3 lembar daun salam
1. Ambil 6 lembar daun jeruk
1. Sediakan 1 ruas lengkuas (geprek)
1. Gunakan 2 batang daun bawang (iris)
1. Ambil 1 batang seledri (iris)
1. Gunakan 1 buah tomat (iris sesuai selera)
1. Siapkan 1/2 jeruk nipis
1. Sediakan 2 sdt Garam
1. Gunakan 1/2 sdt Gula
1. Ambil 1 sdt Lada bubuk




<!--inarticleads2-->

##### Cara membuat Soto ayam:

1. Rebus ayam tidak usah lama2, lalu buang airnya. Rebus kembali.
1. Tumis bumbu halus di atas api sedang, jika sudah harum masukan daun salam, daun jeruk, sereh, lengkuas. Tambahkan 1 gelas belimbing air. Aduk sampai air mendidih. Matikan.
1. Jika rebusan ayam sudah mendidih, masukan bumbu yg sudah di tumis tadi. Aduk.
1. Tambahkan garam, lada, gula. Cek rasa. Matikan kompor.
1. Hidangkan soto di mangkuk, jangan lupa di beri irisan daun bawang, daun seledri, tomat dan perasan jeruk agar tambah segar.




Wah ternyata resep soto ayam yang enak tidak rumit ini gampang sekali ya! Semua orang mampu membuatnya. Cara Membuat soto ayam Cocok banget buat kalian yang baru belajar memasak maupun bagi kamu yang telah lihai memasak.

Tertarik untuk mencoba membuat resep soto ayam mantab simple ini? Kalau tertarik, yuk kita segera buruan menyiapkan alat-alat dan bahannya, setelah itu bikin deh Resep soto ayam yang nikmat dan simple ini. Sungguh gampang kan. 

Oleh karena itu, daripada kita berfikir lama-lama, ayo langsung aja sajikan resep soto ayam ini. Dijamin kalian tak akan nyesel sudah membuat resep soto ayam lezat simple ini! Selamat mencoba dengan resep soto ayam lezat tidak ribet ini di tempat tinggal kalian masing-masing,oke!.

