---
description: "Cara membuat Tongseng Ayam Sederhana Untuk Jualan"
title: "Cara membuat Tongseng Ayam Sederhana Untuk Jualan"
slug: 397-cara-membuat-tongseng-ayam-sederhana-untuk-jualan
date: 2021-05-06T04:20:47.257Z
image: https://img-global.cpcdn.com/recipes/61bd62d98cd7dba1/680x482cq70/tongseng-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/61bd62d98cd7dba1/680x482cq70/tongseng-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/61bd62d98cd7dba1/680x482cq70/tongseng-ayam-foto-resep-utama.jpg
author: Etta Price
ratingvalue: 4
reviewcount: 14
recipeingredient:
- "1/2 kg ayam aku campur sama fillet dada"
- "750 ml air matang"
- "200 gr kol"
- "1 buah tomat ukuran sedang"
- "1 batang daun bawang"
- "10 cabai rawit"
- " Bumbu halus"
- "10 butir bawang merah iris 2 butir"
- "4 bawang putih"
- "1 ruas jahe"
- "1 ruas kunyit"
- "3 butir kemiri"
- "1 sdm ketumbar bubuk"
- " Bahan cemplung"
- "4 lembar daun salam"
- "4 lembar daun jeruk"
- "2 batang serai"
- "2 ruas lengkuas"
- "750 ml air"
- "1 1/2 sdt garam"
- "1 sdt penyedap"
- "Secukupnya kecap"
- "1 sdt gula pasir"
- "25 ml santan"
recipeinstructions:
- "Persiapkan semua bahan"
- "Tumis irisan bawang merah hingga harum"
- "Masukan bumbu halus, beserta bumbu cemplung, tumis hingga matang, berwarna kecoklatan. Kemudian masukan ayam aduk hingga rata"
- "Tuangkan air matang, tunggu higga mendidih kemudian masukan kecap, garam, gula, penyedap aduk rata"
- "Masukan santan dan tunggu air hingga menyusut"
- "Apabil air sudah menyusut, masukan cabai rawit, kol, tomat dan daun bawang. Tunggu hingga sayur agak layu. Tes rasa dan siap di santap"
categories:
- Resep
tags:
- tongseng
- ayam

katakunci: tongseng ayam 
nutrition: 101 calories
recipecuisine: Indonesian
preptime: "PT24M"
cooktime: "PT54M"
recipeyield: "2"
recipecategory: Dinner

---


![Tongseng Ayam](https://img-global.cpcdn.com/recipes/61bd62d98cd7dba1/680x482cq70/tongseng-ayam-foto-resep-utama.jpg)

Andai kamu seorang yang hobi masak, mempersiapkan masakan nikmat bagi famili adalah hal yang menyenangkan untuk anda sendiri. Tugas seorang ibu Tidak cuman mengatur rumah saja, tetapi kamu pun wajib menyediakan kebutuhan gizi tercukupi dan juga panganan yang dimakan keluarga tercinta mesti lezat.

Di era  sekarang, anda sebenarnya bisa membeli masakan instan meski tanpa harus ribet membuatnya dahulu. Tapi banyak juga lho mereka yang memang ingin memberikan makanan yang terenak untuk orang yang dicintainya. Lantaran, menghidangkan masakan sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan sesuai dengan masakan kesukaan keluarga. 



Mungkinkah anda salah satu penikmat tongseng ayam?. Tahukah kamu, tongseng ayam adalah hidangan khas di Nusantara yang sekarang digemari oleh orang-orang di hampir setiap daerah di Nusantara. Kamu dapat menyajikan tongseng ayam olahan sendiri di rumahmu dan boleh jadi hidangan kegemaranmu di hari liburmu.

Kita tidak usah bingung jika kamu ingin mendapatkan tongseng ayam, lantaran tongseng ayam tidak sulit untuk ditemukan dan kamu pun bisa membuatnya sendiri di rumah. tongseng ayam bisa dimasak memalui beragam cara. Saat ini sudah banyak sekali resep kekinian yang menjadikan tongseng ayam lebih enak.

Resep tongseng ayam pun gampang dihidangkan, lho. Kamu jangan ribet-ribet untuk memesan tongseng ayam, sebab Kita mampu menghidangkan sendiri di rumah. Bagi Kamu yang ingin menghidangkannya, dibawah ini merupakan cara untuk membuat tongseng ayam yang lezat yang dapat Kamu buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Tongseng Ayam:

1. Siapkan 1/2 kg ayam, aku campur sama fillet dada
1. Sediakan 750 ml air matang
1. Ambil 200 gr kol
1. Siapkan 1 buah tomat ukuran sedang
1. Siapkan 1 batang daun bawang
1. Siapkan 10 cabai rawit
1. Siapkan  Bumbu halus
1. Gunakan 10 butir bawang merah, iris 2 butir
1. Ambil 4 bawang putih
1. Sediakan 1 ruas jahe
1. Sediakan 1 ruas kunyit
1. Gunakan 3 butir kemiri
1. Gunakan 1 sdm ketumbar bubuk
1. Gunakan  Bahan cemplung
1. Siapkan 4 lembar daun salam
1. Siapkan 4 lembar daun jeruk
1. Siapkan 2 batang serai
1. Siapkan 2 ruas lengkuas
1. Sediakan 750 ml air
1. Gunakan 1 1/2 sdt garam
1. Siapkan 1 sdt penyedap
1. Siapkan Secukupnya kecap
1. Siapkan 1 sdt gula pasir
1. Sediakan 25 ml santan




<!--inarticleads2-->

##### Cara menyiapkan Tongseng Ayam:

1. Persiapkan semua bahan
1. Tumis irisan bawang merah hingga harum
1. Masukan bumbu halus, beserta bumbu cemplung, tumis hingga matang, berwarna kecoklatan. Kemudian masukan ayam aduk hingga rata
1. Tuangkan air matang, tunggu higga mendidih kemudian masukan kecap, garam, gula, penyedap aduk rata
1. Masukan santan dan tunggu air hingga menyusut
1. Apabil air sudah menyusut, masukan cabai rawit, kol, tomat dan daun bawang. Tunggu hingga sayur agak layu. Tes rasa dan siap di santap




Ternyata cara membuat tongseng ayam yang lezat sederhana ini enteng banget ya! Kalian semua bisa membuatnya. Resep tongseng ayam Sangat sesuai banget untuk anda yang baru mau belajar memasak maupun juga untuk kalian yang sudah hebat memasak.

Apakah kamu ingin mencoba membikin resep tongseng ayam nikmat sederhana ini? Kalau kamu tertarik, yuk kita segera buruan menyiapkan alat-alat dan bahannya, maka bikin deh Resep tongseng ayam yang enak dan tidak rumit ini. Betul-betul taidak sulit kan. 

Maka, daripada anda berlama-lama, hayo langsung aja sajikan resep tongseng ayam ini. Dijamin kalian tak akan menyesal sudah membuat resep tongseng ayam mantab tidak rumit ini! Selamat mencoba dengan resep tongseng ayam enak simple ini di tempat tinggal kalian masing-masing,ya!.

