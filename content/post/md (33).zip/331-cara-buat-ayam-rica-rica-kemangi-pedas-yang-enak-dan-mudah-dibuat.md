---
description: "Cara buat Ayam Rica-Rica Kemangi Pedas yang enak dan Mudah Dibuat"
title: "Cara buat Ayam Rica-Rica Kemangi Pedas yang enak dan Mudah Dibuat"
slug: 331-cara-buat-ayam-rica-rica-kemangi-pedas-yang-enak-dan-mudah-dibuat
date: 2021-04-23T19:32:15.583Z
image: https://img-global.cpcdn.com/recipes/b5be1f485bd8bf63/680x482cq70/ayam-rica-rica-kemangi-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b5be1f485bd8bf63/680x482cq70/ayam-rica-rica-kemangi-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b5be1f485bd8bf63/680x482cq70/ayam-rica-rica-kemangi-pedas-foto-resep-utama.jpg
author: Esther Walton
ratingvalue: 5
reviewcount: 5
recipeingredient:
- "8 potong Ayam"
- "1/2 sdt Kunyit bahan marinasi ayam"
- "1 sdt Garam bahan marinasi ayam"
- "secukupnya Minyak Goreng"
- "3 lembar Daun Salam"
- "2 lembar Daun Jeruk"
- "1 ruas Lengkuas geprek"
- "1 batang Sereh geprek"
- "2 ikat Kemangi"
- "secukupnya Air"
- "secukupnya Garam"
- "secukupnya Masako"
- " Bumbu Halus "
- "15 buah Cabe Merah Keriting"
- "25 buah Cabe Rawit kalo suka lebih pedas bisa ditambahin ya"
- "3 butir Kemiri"
- "10 siung Bawang Merah"
- "6 siung Bawang Putih"
- "1 ruas Jahe"
- "1 sdt Kunyit Bubuk  sekelingking"
recipeinstructions:
- "Cuci bersih ayam. Marinasi dengan garam &amp; kunyit bubuk. Diamkan selama 1 jam."
- "Panaskan minyak goreng &amp; sedikit tepung (Bertujuan agar tidak meletup). Goreng ayam sebentar sampai berkulit saja. Angkat &amp; sisihkan."
- "Siapkan bahan bumbu halus. Kemudian blender."
- "Panaskan minyak. Masukkan bumbu halus, tumis sampai matang harum. Masukkan sereh, lengkuas, daun salam &amp; daun jeruk, tumis lagi sampai matang."
- "Masukkan air, aduk rata. Masak sampai mulai matang mendidih. Masukkan masako &amp; garam, aduk merata."
- "Masukkan ayam goreng, aduk rata. Masak dengan api kecil sampai bumbu meresap."
- "Masukkan daun kemangi, aduk rata. Matikan kompor, angkat &amp; sajikan."
- "Taraaa... Sudah matang, silahkan mencobaa~~ 😙😍"
categories:
- Resep
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 209 calories
recipecuisine: Indonesian
preptime: "PT32M"
cooktime: "PT55M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam Rica-Rica Kemangi Pedas](https://img-global.cpcdn.com/recipes/b5be1f485bd8bf63/680x482cq70/ayam-rica-rica-kemangi-pedas-foto-resep-utama.jpg)

Jika kamu seorang orang tua, menyuguhkan panganan sedap pada keluarga tercinta merupakan suatu hal yang menggembirakan untuk anda sendiri. Kewajiban seorang  wanita Tidak cuman menjaga rumah saja, tetapi kamu juga harus memastikan kebutuhan nutrisi tercukupi dan juga olahan yang dimakan orang tercinta wajib sedap.

Di era  saat ini, kamu sebenarnya bisa membeli panganan praktis tanpa harus capek membuatnya lebih dulu. Namun ada juga mereka yang memang ingin memberikan yang terbaik bagi keluarganya. Lantaran, menghidangkan masakan yang diolah sendiri akan jauh lebih higienis dan bisa menyesuaikan makanan tersebut sesuai dengan makanan kesukaan famili. 



Mungkinkah kamu seorang penikmat ayam rica-rica kemangi pedas?. Asal kamu tahu, ayam rica-rica kemangi pedas merupakan sajian khas di Nusantara yang saat ini disukai oleh banyak orang dari berbagai wilayah di Indonesia. Kalian dapat membuat ayam rica-rica kemangi pedas sendiri di rumahmu dan boleh jadi santapan favorit di akhir pekan.

Kita tidak perlu bingung untuk menyantap ayam rica-rica kemangi pedas, karena ayam rica-rica kemangi pedas gampang untuk dicari dan kamu pun boleh menghidangkannya sendiri di tempatmu. ayam rica-rica kemangi pedas bisa dimasak lewat beragam cara. Kini telah banyak sekali cara kekinian yang menjadikan ayam rica-rica kemangi pedas semakin lebih mantap.

Resep ayam rica-rica kemangi pedas pun mudah sekali dibuat, lho. Anda jangan ribet-ribet untuk membeli ayam rica-rica kemangi pedas, tetapi Kita mampu menghidangkan di rumah sendiri. Untuk Anda yang mau menghidangkannya, berikut ini resep untuk membuat ayam rica-rica kemangi pedas yang lezat yang dapat Kita coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Ayam Rica-Rica Kemangi Pedas:

1. Siapkan 8 potong Ayam
1. Gunakan 1/2 sdt Kunyit, bahan marinasi ayam
1. Sediakan 1 sdt Garam, bahan marinasi ayam
1. Ambil secukupnya Minyak Goreng
1. Sediakan 3 lembar Daun Salam
1. Gunakan 2 lembar Daun Jeruk
1. Siapkan 1 ruas Lengkuas, geprek
1. Sediakan 1 batang Sereh, geprek
1. Ambil 2 ikat Kemangi
1. Gunakan secukupnya Air
1. Siapkan secukupnya Garam
1. Ambil secukupnya Masako
1. Sediakan  Bumbu Halus :
1. Ambil 15 buah Cabe Merah Keriting
1. Ambil 25 buah Cabe Rawit, kalo suka lebih pedas, bisa ditambahin ya
1. Gunakan 3 butir Kemiri
1. Ambil 10 siung Bawang Merah
1. Siapkan 6 siung Bawang Putih
1. Sediakan 1 ruas Jahe
1. Siapkan 1 sdt Kunyit Bubuk / sekelingking




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Rica-Rica Kemangi Pedas:

1. Cuci bersih ayam. Marinasi dengan garam &amp; kunyit bubuk. Diamkan selama 1 jam.
1. Panaskan minyak goreng &amp; sedikit tepung (Bertujuan agar tidak meletup). Goreng ayam sebentar sampai berkulit saja. Angkat &amp; sisihkan.
1. Siapkan bahan bumbu halus. Kemudian blender.
1. Panaskan minyak. Masukkan bumbu halus, tumis sampai matang harum. Masukkan sereh, lengkuas, daun salam &amp; daun jeruk, tumis lagi sampai matang.
1. Masukkan air, aduk rata. Masak sampai mulai matang mendidih. Masukkan masako &amp; garam, aduk merata.
1. Masukkan ayam goreng, aduk rata. Masak dengan api kecil sampai bumbu meresap.
1. Masukkan daun kemangi, aduk rata. Matikan kompor, angkat &amp; sajikan.
1. Taraaa... Sudah matang, silahkan mencobaa~~ 😙😍




Wah ternyata resep ayam rica-rica kemangi pedas yang enak simple ini enteng banget ya! Semua orang mampu mencobanya. Cara Membuat ayam rica-rica kemangi pedas Cocok sekali buat kamu yang baru akan belajar memasak atau juga untuk anda yang sudah jago dalam memasak.

Tertarik untuk mulai mencoba bikin resep ayam rica-rica kemangi pedas nikmat tidak rumit ini? Kalau anda mau, yuk kita segera buruan menyiapkan peralatan dan bahan-bahannya, lalu buat deh Resep ayam rica-rica kemangi pedas yang enak dan simple ini. Benar-benar mudah kan. 

Jadi, daripada kalian berlama-lama, yuk langsung aja hidangkan resep ayam rica-rica kemangi pedas ini. Pasti kamu gak akan nyesel membuat resep ayam rica-rica kemangi pedas lezat simple ini! Selamat mencoba dengan resep ayam rica-rica kemangi pedas nikmat tidak rumit ini di rumah kalian masing-masing,oke!.

