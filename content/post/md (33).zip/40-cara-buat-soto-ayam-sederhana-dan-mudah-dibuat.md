---
description: "Cara buat Soto Ayam Sederhana dan Mudah Dibuat"
title: "Cara buat Soto Ayam Sederhana dan Mudah Dibuat"
slug: 40-cara-buat-soto-ayam-sederhana-dan-mudah-dibuat
date: 2021-04-19T20:38:49.120Z
image: https://img-global.cpcdn.com/recipes/0e103bcecb130943/680x482cq70/soto-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0e103bcecb130943/680x482cq70/soto-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0e103bcecb130943/680x482cq70/soto-ayam-foto-resep-utama.jpg
author: Barbara Carson
ratingvalue: 3.5
reviewcount: 8
recipeingredient:
- "1/2 ekor ayam"
- " Kol"
- " Toge Panjang"
- " Bihun Jagung"
- " Daun Bawang"
- "5 siung Bawang Merah"
- "3 siung Bawang Putih"
- "1 ruas Jahe"
- "1 ruas Kunyit"
- "2 lbr Daun Salam"
- "2 lbr Daun Jeruk"
- "1 Serai"
- "1 Lengkuas Geprek"
- "1 sdm Lada Bubuk"
- "secukupnya Gula"
- "secukupnya Garam"
- "secukupnya Penyedap rasa"
recipeinstructions:
- "Sangrai Bawang Merah, Bawang Putih, Jahe, Kunyit Setelah itu Lalu dihaluskan"
- "Tumis Bumbu yg sudah dihaluskan, daun salam, daun jeruk, serai, Lengkuas"
- "Didihkan Air, Lalu Masukkan ayam.. setelah mendidih baru masukkan bumbu yg sudah ditumis"
- "Masukkan gula, garam, lada, dan Penyedap rasa"
- "Setelah semua rasa telah pas, masukkan potongan Daun Bawang"
- "Didihkan Air.. rebus toge panjang, bihun, dan kol"
- "Masukkan bihun, toge panjang, kol, ayam suwir, daun bawang, dan tomat ke dalam mangkok"
- "Soto Ayam siap disajikan"
categories:
- Resep
tags:
- soto
- ayam

katakunci: soto ayam 
nutrition: 169 calories
recipecuisine: Indonesian
preptime: "PT25M"
cooktime: "PT47M"
recipeyield: "2"
recipecategory: Dinner

---


![Soto Ayam](https://img-global.cpcdn.com/recipes/0e103bcecb130943/680x482cq70/soto-ayam-foto-resep-utama.jpg)

Sebagai seorang orang tua, menyuguhkan santapan mantab untuk keluarga tercinta adalah suatu hal yang mengasyikan bagi anda sendiri. Tanggung jawab seorang istri bukan saja mengatur rumah saja, namun kamu pun wajib memastikan kebutuhan nutrisi terpenuhi dan juga santapan yang disantap keluarga tercinta harus lezat.

Di waktu  sekarang, anda sebenarnya bisa memesan panganan yang sudah jadi tidak harus ribet membuatnya dahulu. Tapi banyak juga lho orang yang memang mau menyajikan yang terenak bagi keluarganya. Pasalnya, menghidangkan masakan sendiri akan jauh lebih bersih dan bisa menyesuaikan masakan tersebut sesuai makanan kesukaan keluarga. 



Apakah anda adalah seorang penikmat soto ayam?. Asal kamu tahu, soto ayam merupakan hidangan khas di Nusantara yang kini disenangi oleh orang-orang di hampir setiap tempat di Indonesia. Anda bisa menyajikan soto ayam olahan sendiri di rumahmu dan boleh jadi hidangan kegemaranmu di akhir pekan.

Anda jangan bingung untuk memakan soto ayam, sebab soto ayam mudah untuk ditemukan dan juga kamu pun bisa membuatnya sendiri di tempatmu. soto ayam bisa dibuat lewat bermacam cara. Sekarang sudah banyak sekali cara kekinian yang membuat soto ayam semakin lebih nikmat.

Resep soto ayam pun sangat mudah dihidangkan, lho. Anda tidak perlu capek-capek untuk memesan soto ayam, karena Kamu dapat menyajikan sendiri di rumah. Untuk Kalian yang hendak menyajikannya, inilah cara untuk menyajikan soto ayam yang mantab yang dapat Kita buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Soto Ayam:

1. Ambil 1/2 ekor ayam
1. Ambil  Kol
1. Sediakan  Toge Panjang
1. Ambil  Bihun Jagung
1. Gunakan  Daun Bawang
1. Siapkan 5 siung Bawang Merah
1. Siapkan 3 siung Bawang Putih
1. Sediakan 1 ruas Jahe
1. Siapkan 1 ruas Kunyit
1. Siapkan 2 lbr Daun Salam
1. Sediakan 2 lbr Daun Jeruk
1. Gunakan 1 Serai
1. Siapkan 1 Lengkuas (Geprek)
1. Sediakan 1 sdm Lada Bubuk
1. Siapkan secukupnya Gula
1. Siapkan secukupnya Garam
1. Gunakan secukupnya Penyedap rasa




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Soto Ayam:

1. Sangrai Bawang Merah, Bawang Putih, Jahe, Kunyit - Setelah itu Lalu dihaluskan
1. Tumis Bumbu yg sudah dihaluskan, daun salam, daun jeruk, serai, Lengkuas
1. Didihkan Air, Lalu Masukkan ayam.. setelah mendidih baru masukkan bumbu yg sudah ditumis
1. Masukkan gula, garam, lada, dan Penyedap rasa
1. Setelah semua rasa telah pas, masukkan potongan Daun Bawang
1. Didihkan Air.. rebus toge panjang, bihun, dan kol
1. Masukkan bihun, toge panjang, kol, ayam suwir, daun bawang, dan tomat ke dalam mangkok
1. Soto Ayam siap disajikan




Ternyata cara buat soto ayam yang mantab tidak ribet ini enteng sekali ya! Semua orang dapat mencobanya. Cara buat soto ayam Sesuai banget untuk anda yang baru mau belajar memasak maupun untuk anda yang sudah ahli memasak.

Tertarik untuk mencoba membikin resep soto ayam mantab simple ini? Kalau kalian tertarik, yuk kita segera siapin peralatan dan bahannya, kemudian buat deh Resep soto ayam yang enak dan tidak rumit ini. Benar-benar mudah kan. 

Maka, daripada kalian berfikir lama-lama, ayo langsung aja bikin resep soto ayam ini. Dijamin kalian tak akan menyesal bikin resep soto ayam enak simple ini! Selamat berkreasi dengan resep soto ayam nikmat tidak rumit ini di tempat tinggal sendiri,ya!.

