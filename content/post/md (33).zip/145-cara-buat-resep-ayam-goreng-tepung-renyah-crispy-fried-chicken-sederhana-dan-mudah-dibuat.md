---
description: "Cara buat Resep Ayam Goreng Tepung Renyah / Crispy Fried Chicken Sederhana dan Mudah Dibuat"
title: "Cara buat Resep Ayam Goreng Tepung Renyah / Crispy Fried Chicken Sederhana dan Mudah Dibuat"
slug: 145-cara-buat-resep-ayam-goreng-tepung-renyah-crispy-fried-chicken-sederhana-dan-mudah-dibuat
date: 2021-01-08T14:21:17.106Z
image: https://img-global.cpcdn.com/recipes/65ad9e807f0b06fc/680x482cq70/resep-ayam-goreng-tepung-renyah-crispy-fried-chicken-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/65ad9e807f0b06fc/680x482cq70/resep-ayam-goreng-tepung-renyah-crispy-fried-chicken-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/65ad9e807f0b06fc/680x482cq70/resep-ayam-goreng-tepung-renyah-crispy-fried-chicken-foto-resep-utama.jpg
author: Mitchell Collier
ratingvalue: 3.8
reviewcount: 13
recipeingredient:
- "1/2 kg dada ayam saya beli tanpa tulang di tksayur"
- "1 bh jeruk nipis"
- " Bumbu Rendaman haluskan"
- "5 siung bawang putih"
- "1/2 sdt lada putih bubuk"
- "1/2 sdt lada hitam bubuk"
- "1 sdt garam"
- "1/2 sdt kaldu bubuk"
- "Secukupnya air"
- " Adonan Tepung Basah"
- "1 sdm munjung tepung ayam goreng instant saya pake merk Sasa"
- "1 sdm munjung tepung beras"
- "3 sdm munjung tepung terigu sesuaikan"
- " Adonan Tepung Kering"
- "250 gram tepung terigu"
- "2 sdm munjung tepung beras"
- "1 sdm munjung tepung ayam goreng instant merk Sasa"
- "1/2 sdt lada putih bubuk"
- "1/2 sdt garam"
- " Bahan Lain"
- " Minyak goreng untuk menggoreng"
recipeinstructions:
- "Cuci bersih ayam, lumuri dengan air jeruk nipis, diamkan -+ 10 menit. Kemudian bilas. Potong sesuai selera. Saya sengaja potong tipis supaya hasilnya banyak &amp; memang ingin krispi tepungnya saja. Bilas kembali lalu tiriskan."
- "Haluskan bumbu. Setelah halus, rendam ayam dalam bumbu. Beri air sampai ayam-nya tenggelam. Aduk rata. Diamkan -+ 15menit dalam lemari es."
- "Siapkan tepung untuk adonan basah. Setelah bumbu meresap, masukan tepung untuk adonan basah dalam rendaman ayam, aduk sampai adonan menjadi semi kental."
- "Siapkan adonan tepung kering. Gunakan wadah yang cukup besar untuk menampung adonan tepung kering."
- "Siapkan wajan, isi dengan minyak goreng baru. Gunakan api sedang. Sambil menunggu minyak panas, uleni adonan. Caranya; ambil potongan ayam dalam adonan basah, gulingkan dalam adonan tepung kering, pijat-pijat/remas-remas daging ayam supaya muncul efek &#39;gimbal&#39;. Ketuk di tepi wadah sampai yang tersisa hanya tepung yang mau menempel saja pada daging ayam. Ulangi meremas sampai ketebalan yang diinginkan."
- "Saya sisihkan dulu di sebuah wadah. Setelah minyak panas, masukkan dalam minyak sampai seluruh bagian ayam terendam minyak panas, jangan terlalu banyak menggorengnya dan jangan sering-sering diaduk/dibalik. Diamkan sebentar satu sisi, baru kemudian balik ke sisi lainnya. Goreng sampai tingkat kematangan yang diinginkan. Tiriskan lalu sajikan."
categories:
- Resep
tags:
- resep
- ayam
- goreng

katakunci: resep ayam goreng 
nutrition: 232 calories
recipecuisine: Indonesian
preptime: "PT18M"
cooktime: "PT56M"
recipeyield: "3"
recipecategory: Dessert

---


![Resep Ayam Goreng Tepung Renyah / Crispy Fried Chicken](https://img-global.cpcdn.com/recipes/65ad9e807f0b06fc/680x482cq70/resep-ayam-goreng-tepung-renyah-crispy-fried-chicken-foto-resep-utama.jpg)

Sebagai seorang yang hobi masak, menyediakan masakan menggugah selera kepada keluarga tercinta merupakan suatu hal yang mengasyikan bagi kamu sendiri. Tugas seorang  wanita Tidak cuma mengurus rumah saja, namun anda pun harus memastikan kebutuhan nutrisi terpenuhi dan olahan yang dikonsumsi keluarga tercinta wajib sedap.

Di waktu  saat ini, kamu sebenarnya mampu memesan masakan jadi meski tidak harus susah membuatnya lebih dulu. Tetapi ada juga lho mereka yang selalu ingin memberikan yang terbaik untuk orang tercintanya. Pasalnya, menyajikan masakan sendiri jauh lebih higienis dan bisa menyesuaikan makanan tersebut berdasarkan makanan kesukaan keluarga tercinta. 



Apakah anda merupakan seorang penyuka resep ayam goreng tepung renyah / crispy fried chicken?. Tahukah kamu, resep ayam goreng tepung renyah / crispy fried chicken adalah hidangan khas di Nusantara yang saat ini disenangi oleh banyak orang di hampir setiap wilayah di Indonesia. Anda bisa menyajikan resep ayam goreng tepung renyah / crispy fried chicken sendiri di rumahmu dan dapat dijadikan camilan kesenanganmu di akhir pekan.

Kamu tidak perlu bingung untuk memakan resep ayam goreng tepung renyah / crispy fried chicken, karena resep ayam goreng tepung renyah / crispy fried chicken gampang untuk didapatkan dan kita pun dapat membuatnya sendiri di rumah. resep ayam goreng tepung renyah / crispy fried chicken bisa dimasak dengan beraneka cara. Sekarang telah banyak sekali resep modern yang menjadikan resep ayam goreng tepung renyah / crispy fried chicken semakin lebih lezat.

Resep resep ayam goreng tepung renyah / crispy fried chicken juga gampang sekali dibikin, lho. Kalian tidak perlu capek-capek untuk memesan resep ayam goreng tepung renyah / crispy fried chicken, karena Kamu mampu menyajikan sendiri di rumah. Bagi Kamu yang mau menghidangkannya, di bawah ini adalah resep membuat resep ayam goreng tepung renyah / crispy fried chicken yang lezat yang mampu Kamu coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Resep Ayam Goreng Tepung Renyah / Crispy Fried Chicken:

1. Sediakan 1/2 kg dada ayam (saya beli tanpa tulang di tk.sayur)
1. Gunakan 1 bh jeruk nipis
1. Siapkan  Bumbu Rendaman (haluskan)
1. Siapkan 5 siung bawang putih
1. Ambil 1/2 sdt lada putih bubuk
1. Sediakan 1/2 sdt lada hitam bubuk
1. Sediakan 1 sdt garam
1. Ambil 1/2 sdt kaldu bubuk
1. Sediakan Secukupnya air
1. Sediakan  Adonan Tepung Basah
1. Ambil 1 sdm munjung tepung ayam goreng instant (saya pake merk Sasa)
1. Sediakan 1 sdm munjung tepung beras
1. Gunakan 3 sdm munjung tepung terigu (sesuaikan)
1. Ambil  Adonan Tepung Kering
1. Sediakan 250 gram tepung terigu
1. Gunakan 2 sdm munjung tepung beras
1. Siapkan 1 sdm munjung tepung ayam goreng instant merk Sasa
1. Ambil 1/2 sdt lada putih bubuk
1. Gunakan 1/2 sdt garam
1. Sediakan  Bahan Lain
1. Siapkan  Minyak goreng untuk menggoreng




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Resep Ayam Goreng Tepung Renyah / Crispy Fried Chicken:

1. Cuci bersih ayam, lumuri dengan air jeruk nipis, diamkan -+ 10 menit. Kemudian bilas. Potong sesuai selera. Saya sengaja potong tipis supaya hasilnya banyak &amp; memang ingin krispi tepungnya saja. Bilas kembali lalu tiriskan.
1. Haluskan bumbu. Setelah halus, rendam ayam dalam bumbu. Beri air sampai ayam-nya tenggelam. Aduk rata. Diamkan -+ 15menit dalam lemari es.
1. Siapkan tepung untuk adonan basah. Setelah bumbu meresap, masukan tepung untuk adonan basah dalam rendaman ayam, aduk sampai adonan menjadi semi kental.
1. Siapkan adonan tepung kering. Gunakan wadah yang cukup besar untuk menampung adonan tepung kering.
1. Siapkan wajan, isi dengan minyak goreng baru. Gunakan api sedang. Sambil menunggu minyak panas, uleni adonan. Caranya; ambil potongan ayam dalam adonan basah, gulingkan dalam adonan tepung kering, pijat-pijat/remas-remas daging ayam supaya muncul efek &#39;gimbal&#39;. Ketuk di tepi wadah sampai yang tersisa hanya tepung yang mau menempel saja pada daging ayam. Ulangi meremas sampai ketebalan yang diinginkan.
1. Saya sisihkan dulu di sebuah wadah. Setelah minyak panas, masukkan dalam minyak sampai seluruh bagian ayam terendam minyak panas, jangan terlalu banyak menggorengnya dan jangan sering-sering diaduk/dibalik. Diamkan sebentar satu sisi, baru kemudian balik ke sisi lainnya. Goreng sampai tingkat kematangan yang diinginkan. Tiriskan lalu sajikan.




Wah ternyata cara buat resep ayam goreng tepung renyah / crispy fried chicken yang mantab simple ini mudah sekali ya! Kamu semua mampu menghidangkannya. Resep resep ayam goreng tepung renyah / crispy fried chicken Sangat cocok sekali buat kalian yang baru belajar memasak atau juga bagi kamu yang telah lihai dalam memasak.

Tertarik untuk mencoba membuat resep resep ayam goreng tepung renyah / crispy fried chicken enak simple ini? Kalau kamu mau, mending kamu segera menyiapkan peralatan dan bahan-bahannya, lalu buat deh Resep resep ayam goreng tepung renyah / crispy fried chicken yang enak dan tidak rumit ini. Sungguh gampang kan. 

Maka, daripada kamu diam saja, hayo kita langsung bikin resep resep ayam goreng tepung renyah / crispy fried chicken ini. Pasti kamu tiidak akan nyesel sudah bikin resep resep ayam goreng tepung renyah / crispy fried chicken nikmat tidak ribet ini! Selamat berkreasi dengan resep resep ayam goreng tepung renyah / crispy fried chicken enak tidak rumit ini di tempat tinggal kalian masing-masing,ya!.

