---
description: "Bahan-bahan Opor ayam yang enak dan Mudah Dibuat"
title: "Bahan-bahan Opor ayam yang enak dan Mudah Dibuat"
slug: 204-bahan-bahan-opor-ayam-yang-enak-dan-mudah-dibuat
date: 2021-06-06T18:53:59.434Z
image: https://img-global.cpcdn.com/recipes/465ee2873e7fc5b9/680x482cq70/opor-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/465ee2873e7fc5b9/680x482cq70/opor-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/465ee2873e7fc5b9/680x482cq70/opor-ayam-foto-resep-utama.jpg
author: Amanda Norris
ratingvalue: 4.3
reviewcount: 14
recipeingredient:
- "1/2 ekor ayam"
- "2 Tahu putih"
- " Santan kara"
- " Daun salam"
- " Gula"
- " Garam"
- " Merica"
- " Bumbu penyedap"
- " Lengkuas geprek"
- " Serai geprek"
- " Bumbu halus"
- "5 siung bawang merah"
- "3 siung bawang putih"
- "2 buah kemiri"
- "1 ruas jahe"
- " Ketumbar"
- " Kunyit"
recipeinstructions:
- "Potong ayam jd beberapa baguan lalu cuci bersih ayam"
- "Didihkan air rebus ayam campur daun jeruk sebentar sampai empuk setelah masak jangan buang air rebusan ayamnya"
- "Tumis bumbu halus sama daun salam dan serai sampai harum lalu masukkan tahu dan ayam aduk” sebentar kemudian tuang air kaldu ayam tadi dan diamkan sampai mendidih"
- "Setelah mendidih masukkan gula,garam,merica,penyedap aduk” sebentar lalu masukkan santan kara"
- "Setelah semua bumbu sudah masuk aduk masak sebentar jangan lupa dicicipi biar pas rasanya, setelah masak angkat lalu sajikan taburi bawang goreng diatasnya agar rasanya semakin gurih"
- "Nb : Jika ingin masakan yg pedas bisa tinggal tambahin aja cabe dibumbu halusnya, sengaja gak pakai cabe biar anak bisa makan jug 😊😊"
categories:
- Resep
tags:
- opor
- ayam

katakunci: opor ayam 
nutrition: 164 calories
recipecuisine: Indonesian
preptime: "PT18M"
cooktime: "PT54M"
recipeyield: "2"
recipecategory: Dinner

---


![Opor ayam](https://img-global.cpcdn.com/recipes/465ee2873e7fc5b9/680x482cq70/opor-ayam-foto-resep-utama.jpg)

Sebagai seorang orang tua, menyuguhkan olahan nikmat kepada famili merupakan hal yang mengasyikan bagi anda sendiri. Tugas seorang ibu bukan saja mengerjakan pekerjaan rumah saja, tapi anda pun wajib memastikan keperluan gizi terpenuhi dan juga santapan yang dimakan keluarga tercinta harus enak.

Di masa  sekarang, kita sebenarnya bisa memesan hidangan jadi walaupun tanpa harus ribet memasaknya terlebih dahulu. Tapi banyak juga orang yang selalu mau memberikan yang terenak bagi orang yang dicintainya. Pasalnya, menghidangkan masakan sendiri jauh lebih higienis dan kita juga bisa menyesuaikan makanan tersebut sesuai masakan kesukaan famili. 



Apakah kamu seorang penyuka opor ayam?. Asal kamu tahu, opor ayam adalah sajian khas di Nusantara yang saat ini disukai oleh orang-orang dari berbagai wilayah di Nusantara. Kita dapat menyajikan opor ayam sendiri di rumah dan boleh dijadikan hidangan favoritmu di hari libur.

Anda jangan bingung jika kamu ingin menyantap opor ayam, lantaran opor ayam sangat mudah untuk didapatkan dan kita pun bisa memasaknya sendiri di tempatmu. opor ayam dapat dimasak dengan beragam cara. Sekarang telah banyak sekali resep kekinian yang menjadikan opor ayam semakin nikmat.

Resep opor ayam pun sangat gampang untuk dibikin, lho. Anda tidak usah repot-repot untuk memesan opor ayam, sebab Kamu mampu menyajikan ditempatmu. Untuk Kamu yang mau menyajikannya, di bawah ini adalah resep untuk menyajikan opor ayam yang enak yang bisa Kalian coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Opor ayam:

1. Sediakan 1/2 ekor ayam
1. Sediakan 2 Tahu putih
1. Ambil  Santan kara
1. Gunakan  Daun salam
1. Ambil  Gula
1. Ambil  Garam
1. Sediakan  Merica
1. Sediakan  Bumbu penyedap
1. Siapkan  Lengkuas geprek
1. Ambil  Serai geprek
1. Sediakan  Bumbu halus
1. Ambil 5 siung bawang merah
1. Siapkan 3 siung bawang putih
1. Sediakan 2 buah kemiri
1. Sediakan 1 ruas jahe
1. Sediakan  Ketumbar
1. Gunakan  Kunyit




<!--inarticleads2-->

##### Cara menyiapkan Opor ayam:

1. Potong ayam jd beberapa baguan lalu cuci bersih ayam
1. Didihkan air rebus ayam campur daun jeruk sebentar sampai empuk setelah masak jangan buang air rebusan ayamnya
1. Tumis bumbu halus sama daun salam dan serai sampai harum lalu masukkan tahu dan ayam aduk” sebentar kemudian tuang air kaldu ayam tadi dan diamkan sampai mendidih
1. Setelah mendidih masukkan gula,garam,merica,penyedap aduk” sebentar lalu masukkan santan kara
1. Setelah semua bumbu sudah masuk aduk masak sebentar jangan lupa dicicipi biar pas rasanya, setelah masak angkat lalu sajikan taburi bawang goreng diatasnya agar rasanya semakin gurih
1. Nb : Jika ingin masakan yg pedas bisa tinggal tambahin aja cabe dibumbu halusnya, sengaja gak pakai cabe biar anak bisa makan jug 😊😊




Wah ternyata resep opor ayam yang enak tidak ribet ini enteng sekali ya! Anda Semua dapat mencobanya. Cara buat opor ayam Sesuai banget buat kita yang baru belajar memasak maupun juga bagi kalian yang sudah hebat dalam memasak.

Apakah kamu ingin mencoba membuat resep opor ayam nikmat simple ini? Kalau kamu mau, yuk kita segera siapkan peralatan dan bahan-bahannya, kemudian buat deh Resep opor ayam yang enak dan simple ini. Sangat gampang kan. 

Maka dari itu, ketimbang kalian diam saja, hayo kita langsung saja buat resep opor ayam ini. Pasti kalian tiidak akan menyesal sudah membuat resep opor ayam enak tidak rumit ini! Selamat mencoba dengan resep opor ayam nikmat tidak rumit ini di rumah kalian sendiri,oke!.

