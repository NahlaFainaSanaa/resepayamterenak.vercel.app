---
description: "Resep Ayam Bakar Kecap Mudah (Grilled Chicken) yang enak Untuk Jualan"
title: "Resep Ayam Bakar Kecap Mudah (Grilled Chicken) yang enak Untuk Jualan"
slug: 296-resep-ayam-bakar-kecap-mudah-grilled-chicken-yang-enak-untuk-jualan
date: 2021-05-08T11:41:58.583Z
image: https://img-global.cpcdn.com/recipes/ebba67b76f1684da/680x482cq70/ayam-bakar-kecap-mudah-grilled-chicken-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ebba67b76f1684da/680x482cq70/ayam-bakar-kecap-mudah-grilled-chicken-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ebba67b76f1684da/680x482cq70/ayam-bakar-kecap-mudah-grilled-chicken-foto-resep-utama.jpg
author: Jacob Moody
ratingvalue: 4.7
reviewcount: 13
recipeingredient:
- "1/2 ekor Ayam saya suka bagian paha"
- " Bumbu Ungkep"
- "1 batang Serai"
- "2 lembar Daun Salam"
- "1 ruas Lengkuas"
- "Secukupnya Garam Gula Merica Bubuk dan Kecap Manis"
- "2 bongkah kecil Gula Merah Sekitar 23 sendok makan bila di potongpotong"
- " Bumbu Halus BlenderUlek"
- "4 siung Bawang Putih"
- "7 siung Bawang Merah"
- "5 buah Cabai Merah Keriting"
- "2 buah Cabai Merah Besar"
- "2 butir Kemiri"
- "1 ruas Jahe"
- "1 sdm Kunyit Bubuk"
- "1 sdm Ketumbar Bubuk"
recipeinstructions:
- "Masukkan bumbu yang sudah dihaluskan kedalam wajan atau panci, lalu tambahkan ayam, serai, lengkuas, daun salam serta air (tambahkan air hingga semua bagian ayam tenggelam). Jangan lupa tambahkan garam, gula dan merica bubuk. Sisihkan gula merah dan kecap untuk nanti."
- "Ungkep ayam dengan api sedang atau kecil, biarkan hingga matang. Setelah ayam matang dan bumbu meresap tambahkan gula merah dan kecap. Lalu aduk rata dan biarkan hingga air ungkepan hampir kering (sambil dites rasa)."
- "Jika suka ayam bakar yang manis bisa tambahkan gula agak banyak dan kecap. Tapi harus sambil dites rasa, agar rasa gula dan kecap tidak terlalu berlebihan."
- "Setelah itu matikan kompor dan bakar ayam yang sudah diungkep dengan teflon (kalau saya, teflon saya lapisi sedikit minyak goreng, diusapkan merata menggunakan tissue). Bakar dengan api kecil."
- "Setelah matang bisa langsung disantap dengan nasi hangat. Selamat Mencoba 😊"
categories:
- Resep
tags:
- ayam
- bakar
- kecap

katakunci: ayam bakar kecap 
nutrition: 197 calories
recipecuisine: Indonesian
preptime: "PT14M"
cooktime: "PT50M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam Bakar Kecap Mudah (Grilled Chicken)](https://img-global.cpcdn.com/recipes/ebba67b76f1684da/680x482cq70/ayam-bakar-kecap-mudah-grilled-chicken-foto-resep-utama.jpg)

Sebagai seorang yang hobi masak, mempersiapkan olahan mantab bagi famili merupakan suatu hal yang memuaskan bagi kamu sendiri. Tugas seorang istri bukan hanya menangani rumah saja, namun kamu pun harus memastikan kebutuhan nutrisi tercukupi dan juga panganan yang disantap orang tercinta wajib nikmat.

Di zaman  sekarang, kamu memang mampu membeli panganan siap saji meski tanpa harus susah membuatnya lebih dulu. Tetapi ada juga lho mereka yang selalu ingin menghidangkan yang terbaik bagi orang yang dicintainya. Pasalnya, memasak sendiri jauh lebih bersih dan kita juga bisa menyesuaikan makanan tersebut sesuai masakan kesukaan keluarga. 



Mungkinkah anda salah satu penyuka ayam bakar kecap mudah (grilled chicken)?. Tahukah kamu, ayam bakar kecap mudah (grilled chicken) merupakan makanan khas di Nusantara yang kini digemari oleh setiap orang dari hampir setiap wilayah di Nusantara. Kita dapat memasak ayam bakar kecap mudah (grilled chicken) buatan sendiri di rumah dan pasti jadi camilan kesukaanmu di akhir pekanmu.

Anda tak perlu bingung jika kamu ingin memakan ayam bakar kecap mudah (grilled chicken), karena ayam bakar kecap mudah (grilled chicken) gampang untuk ditemukan dan juga kita pun bisa mengolahnya sendiri di rumah. ayam bakar kecap mudah (grilled chicken) bisa diolah lewat bermacam cara. Sekarang sudah banyak sekali cara kekinian yang menjadikan ayam bakar kecap mudah (grilled chicken) lebih nikmat.

Resep ayam bakar kecap mudah (grilled chicken) pun mudah sekali untuk dibuat, lho. Kalian tidak usah capek-capek untuk memesan ayam bakar kecap mudah (grilled chicken), karena Kalian dapat menyiapkan di rumah sendiri. Untuk Kalian yang hendak menyajikannya, inilah cara membuat ayam bakar kecap mudah (grilled chicken) yang lezat yang bisa Kita coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Ayam Bakar Kecap Mudah (Grilled Chicken):

1. Siapkan 1/2 ekor Ayam (saya suka bagian paha)
1. Sediakan  Bumbu Ungkep
1. Gunakan 1 batang Serai
1. Ambil 2 lembar Daun Salam
1. Gunakan 1 ruas Lengkuas
1. Siapkan Secukupnya Garam, Gula, Merica Bubuk dan Kecap Manis
1. Siapkan 2 bongkah kecil Gula Merah (Sekitar 2-3 sendok makan bila di potong-potong)
1. Siapkan  Bumbu Halus (Blender/Ulek)
1. Gunakan 4 siung Bawang Putih
1. Gunakan 7 siung Bawang Merah
1. Ambil 5 buah Cabai Merah Keriting
1. Gunakan 2 buah Cabai Merah Besar
1. Gunakan 2 butir Kemiri
1. Sediakan 1 ruas Jahe
1. Sediakan 1 sdm Kunyit Bubuk
1. Siapkan 1 sdm Ketumbar Bubuk




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Bakar Kecap Mudah (Grilled Chicken):

1. Masukkan bumbu yang sudah dihaluskan kedalam wajan atau panci, lalu tambahkan ayam, serai, lengkuas, daun salam serta air (tambahkan air hingga semua bagian ayam tenggelam). Jangan lupa tambahkan garam, gula dan merica bubuk. Sisihkan gula merah dan kecap untuk nanti.
1. Ungkep ayam dengan api sedang atau kecil, biarkan hingga matang. Setelah ayam matang dan bumbu meresap tambahkan gula merah dan kecap. Lalu aduk rata dan biarkan hingga air ungkepan hampir kering (sambil dites rasa).
1. Jika suka ayam bakar yang manis bisa tambahkan gula agak banyak dan kecap. Tapi harus sambil dites rasa, agar rasa gula dan kecap tidak terlalu berlebihan.
1. Setelah itu matikan kompor dan bakar ayam yang sudah diungkep dengan teflon (kalau saya, teflon saya lapisi sedikit minyak goreng, diusapkan merata menggunakan tissue). Bakar dengan api kecil.
1. Setelah matang bisa langsung disantap dengan nasi hangat. Selamat Mencoba 😊




Ternyata cara membuat ayam bakar kecap mudah (grilled chicken) yang nikamt tidak ribet ini enteng sekali ya! Anda Semua mampu menghidangkannya. Cara buat ayam bakar kecap mudah (grilled chicken) Sangat cocok banget buat anda yang baru belajar memasak maupun juga untuk kamu yang sudah lihai memasak.

Tertarik untuk mencoba membikin resep ayam bakar kecap mudah (grilled chicken) lezat simple ini? Kalau kalian ingin, mending kamu segera siapin alat-alat dan bahan-bahannya, maka buat deh Resep ayam bakar kecap mudah (grilled chicken) yang enak dan tidak rumit ini. Sungguh taidak sulit kan. 

Oleh karena itu, ketimbang kamu diam saja, ayo kita langsung saja bikin resep ayam bakar kecap mudah (grilled chicken) ini. Dijamin kalian tiidak akan nyesel bikin resep ayam bakar kecap mudah (grilled chicken) lezat tidak ribet ini! Selamat mencoba dengan resep ayam bakar kecap mudah (grilled chicken) nikmat simple ini di tempat tinggal kalian sendiri,oke!.

