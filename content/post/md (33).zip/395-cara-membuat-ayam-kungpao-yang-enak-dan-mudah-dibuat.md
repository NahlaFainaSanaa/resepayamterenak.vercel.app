---
description: "Cara membuat Ayam kungpao yang enak dan Mudah Dibuat"
title: "Cara membuat Ayam kungpao yang enak dan Mudah Dibuat"
slug: 395-cara-membuat-ayam-kungpao-yang-enak-dan-mudah-dibuat
date: 2021-04-27T02:56:42.691Z
image: https://img-global.cpcdn.com/recipes/20ba0cbab4826774/680x482cq70/ayam-kungpao-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/20ba0cbab4826774/680x482cq70/ayam-kungpao-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/20ba0cbab4826774/680x482cq70/ayam-kungpao-foto-resep-utama.jpg
author: Samuel Holt
ratingvalue: 4.6
reviewcount: 8
recipeingredient:
- "3 fillet paha ayam potong kotak"
- "1 bawang bombay"
- "1 paprika merah"
- "3 butir bawang putih"
- "1 sdm saos tomat"
- "1 sdm saos tiram"
- "2 sdm kecap manis"
- "1 sdt gula"
- "1 batang daun bawang"
- "1 sdt minyak wijen"
- "Secukupnya garam lada kaldu jamur"
- "Sedikit air"
recipeinstructions:
- "Goreng ayam yang sudah dipotong hingga matang lalu angkat dan tiriskan"
- "Tumis bawang putih dan bawang bombay.. setelah harum masukkan paprika.. aduk2 sebentar"
- "Masukkan ayam yang telah digoreng, lalu masukkan saos tomat, kecap, saos tiram, gula, garam, lada, kaldu dan air."
- "Koreksi rasa.. masukkan daun bawang dan minyak wijen.. Angkat, dan sajikan."
categories:
- Resep
tags:
- ayam
- kungpao

katakunci: ayam kungpao 
nutrition: 196 calories
recipecuisine: Indonesian
preptime: "PT27M"
cooktime: "PT49M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam kungpao](https://img-global.cpcdn.com/recipes/20ba0cbab4826774/680x482cq70/ayam-kungpao-foto-resep-utama.jpg)

Sebagai seorang istri, menyajikan hidangan lezat buat keluarga tercinta adalah suatu hal yang membahagiakan bagi kita sendiri. Kewajiban seorang ibu Tidak hanya mengerjakan pekerjaan rumah saja, tetapi kamu pun harus menyediakan keperluan nutrisi tercukupi dan juga santapan yang disantap keluarga tercinta harus lezat.

Di era  sekarang, anda memang dapat mengorder hidangan yang sudah jadi meski tidak harus repot mengolahnya dulu. Tetapi ada juga lho orang yang selalu ingin menghidangkan yang terbaik untuk orang tercintanya. Lantaran, menyajikan masakan yang diolah sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan makanan tersebut sesuai selera keluarga. 



Mungkinkah anda adalah seorang penggemar ayam kungpao?. Asal kamu tahu, ayam kungpao adalah hidangan khas di Indonesia yang kini disukai oleh setiap orang di hampir setiap tempat di Indonesia. Kamu dapat menyajikan ayam kungpao sendiri di rumahmu dan boleh jadi makanan kesenanganmu di akhir pekanmu.

Kalian tidak perlu bingung jika kamu ingin menyantap ayam kungpao, karena ayam kungpao sangat mudah untuk ditemukan dan juga anda pun bisa membuatnya sendiri di rumah. ayam kungpao boleh dimasak lewat beragam cara. Saat ini telah banyak banget cara kekinian yang membuat ayam kungpao lebih enak.

Resep ayam kungpao juga sangat mudah untuk dibikin, lho. Anda tidak usah repot-repot untuk membeli ayam kungpao, lantaran Anda dapat menyajikan sendiri di rumah. Bagi Anda yang akan menyajikannya, inilah cara untuk membuat ayam kungpao yang lezat yang dapat Kalian coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Ayam kungpao:

1. Ambil 3 fillet paha ayam potong kotak
1. Gunakan 1 bawang bombay
1. Gunakan 1 paprika merah
1. Ambil 3 butir bawang putih
1. Gunakan 1 sdm saos tomat
1. Sediakan 1 sdm saos tiram
1. Gunakan 2 sdm kecap manis
1. Sediakan 1 sdt gula
1. Gunakan 1 batang daun bawang
1. Siapkan 1 sdt minyak wijen
1. Sediakan Secukupnya garam, lada, kaldu jamur
1. Sediakan Sedikit air




<!--inarticleads2-->

##### Cara membuat Ayam kungpao:

1. Goreng ayam yang sudah dipotong hingga matang lalu angkat dan tiriskan
1. Tumis bawang putih dan bawang bombay.. setelah harum masukkan paprika.. aduk2 sebentar
1. Masukkan ayam yang telah digoreng, lalu masukkan saos tomat, kecap, saos tiram, gula, garam, lada, kaldu dan air.
1. Koreksi rasa.. masukkan daun bawang dan minyak wijen.. Angkat, dan sajikan.




Wah ternyata resep ayam kungpao yang mantab simple ini mudah sekali ya! Kita semua dapat mencobanya. Cara buat ayam kungpao Sangat cocok sekali untuk kamu yang baru mau belajar memasak ataupun juga untuk kalian yang sudah pandai memasak.

Tertarik untuk mencoba buat resep ayam kungpao lezat tidak rumit ini? Kalau anda ingin, mending kamu segera siapin peralatan dan bahannya, lalu buat deh Resep ayam kungpao yang mantab dan tidak rumit ini. Betul-betul gampang kan. 

Jadi, daripada anda diam saja, hayo kita langsung saja buat resep ayam kungpao ini. Dijamin anda gak akan menyesal membuat resep ayam kungpao enak simple ini! Selamat mencoba dengan resep ayam kungpao lezat simple ini di rumah masing-masing,ya!.

