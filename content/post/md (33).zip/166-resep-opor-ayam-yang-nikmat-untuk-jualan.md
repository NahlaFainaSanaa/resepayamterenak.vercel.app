---
description: "Resep Opor Ayam yang nikmat Untuk Jualan"
title: "Resep Opor Ayam yang nikmat Untuk Jualan"
slug: 166-resep-opor-ayam-yang-nikmat-untuk-jualan
date: 2021-03-08T15:14:10.258Z
image: https://img-global.cpcdn.com/recipes/496faf8753efd000/680x482cq70/opor-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/496faf8753efd000/680x482cq70/opor-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/496faf8753efd000/680x482cq70/opor-ayam-foto-resep-utama.jpg
author: Barry Nelson
ratingvalue: 4
reviewcount: 5
recipeingredient:
- "1 ekor ayam potong2 bisa ayam kampung atau negeri disini saya pake ayam negeri"
- "2 batang sereh digeprek"
- "3 lembar daun salam"
- "Sejempol lengkuas digeprek"
- "1300 ml santan encer 1 butir kelapa"
- "300 ml santan kental"
- "secukupnya Garam"
- "secukupnya Gula"
- " Penyedap rasa optional"
- " Bumbu yang dihaluskan"
- "10 siung bawang merah"
- "4 siung bawang putih"
- "2 butir kemiri sangrai"
- "1 sdm ketumbar sangrai"
- "3 cm jahe"
- "1/4 sdt jinten"
- "1 sdt lada  merica"
recipeinstructions:
- "Lumuri ayam dg jeruk nipis (agar hilang amisnya, kurleb 5 menit diamkan) lalu cuci bersih ayam."
- "Goreng sebentar ayam hingga kulit sedikit kecoklatan. Angkat dan sisihkan"
- "Tuang santan dalam wajan, masukkan bumbu halus, daun salam, sereh, lengkuas. Godog sekitar 10 menit sambil di aduk pelan2 agar santan tidak pecah."
- "Masukkan ayam. Beri garam, gula, penyedap rasa (optional). Biarkan mendidih. Lalu kecilkan api dan tiangs antal kental sambim diaduk pelan2."
- "Masak hingga ayam empuk, bumbu meresap dan kuah berminyak. Koreksi rasa. Sajikan."
categories:
- Resep
tags:
- opor
- ayam

katakunci: opor ayam 
nutrition: 175 calories
recipecuisine: Indonesian
preptime: "PT27M"
cooktime: "PT40M"
recipeyield: "2"
recipecategory: Dinner

---


![Opor Ayam](https://img-global.cpcdn.com/recipes/496faf8753efd000/680x482cq70/opor-ayam-foto-resep-utama.jpg)

Sebagai seorang yang hobi memasak, menyajikan santapan lezat kepada keluarga adalah suatu hal yang mengasyikan bagi kamu sendiri. Tanggung jawab seorang  wanita bukan sekadar mengatur rumah saja, namun kamu juga harus menyediakan keperluan gizi tercukupi dan juga panganan yang dimakan orang tercinta wajib lezat.

Di zaman  sekarang, anda memang dapat mengorder hidangan yang sudah jadi tidak harus susah memasaknya terlebih dahulu. Namun ada juga mereka yang selalu mau memberikan yang terenak bagi orang tercintanya. Karena, memasak yang dibuat sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan hidangan tersebut sesuai dengan makanan kesukaan keluarga. 



Apakah anda salah satu penggemar opor ayam?. Asal kamu tahu, opor ayam merupakan makanan khas di Indonesia yang saat ini disenangi oleh setiap orang di berbagai daerah di Nusantara. Kita bisa memasak opor ayam olahan sendiri di rumahmu dan dapat dijadikan makanan favoritmu di hari libur.

Anda jangan bingung jika kamu ingin menyantap opor ayam, karena opor ayam mudah untuk dicari dan kalian pun dapat membuatnya sendiri di rumah. opor ayam bisa dibuat memalui bermacam cara. Kini pun telah banyak sekali resep kekinian yang membuat opor ayam semakin nikmat.

Resep opor ayam pun mudah sekali untuk dibikin, lho. Kalian tidak perlu ribet-ribet untuk memesan opor ayam, karena Anda dapat menyajikan di rumah sendiri. Untuk Anda yang hendak mencobanya, di bawah ini adalah cara untuk menyajikan opor ayam yang enak yang mampu Kalian coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Opor Ayam:

1. Siapkan 1 ekor ayam, potong2 (bisa ayam kampung atau negeri, disini saya pake ayam negeri)
1. Ambil 2 batang sereh, digeprek
1. Siapkan 3 lembar daun salam
1. Ambil Sejempol lengkuas, digeprek
1. Gunakan 1300 ml santan encer (1 butir kelapa)
1. Ambil 300 ml santan kental
1. Ambil secukupnya Garam
1. Siapkan secukupnya Gula
1. Ambil  Penyedap rasa (optional)
1. Sediakan  Bumbu yang dihaluskan
1. Gunakan 10 siung bawang merah
1. Gunakan 4 siung bawang putih
1. Sediakan 2 butir kemiri, sangrai
1. Siapkan 1 sdm ketumbar, sangrai
1. Gunakan 3 cm jahe
1. Sediakan 1/4 sdt jinten
1. Sediakan 1 sdt lada / merica




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Opor Ayam:

1. Lumuri ayam dg jeruk nipis (agar hilang amisnya, kurleb 5 menit diamkan) lalu cuci bersih ayam.
1. Goreng sebentar ayam hingga kulit sedikit kecoklatan. Angkat dan sisihkan
1. Tuang santan dalam wajan, masukkan bumbu halus, daun salam, sereh, lengkuas. Godog sekitar 10 menit sambil di aduk pelan2 agar santan tidak pecah.
1. Masukkan ayam. Beri garam, gula, penyedap rasa (optional). Biarkan mendidih. Lalu kecilkan api dan tiangs antal kental sambim diaduk pelan2.
1. Masak hingga ayam empuk, bumbu meresap dan kuah berminyak. Koreksi rasa. Sajikan.




Ternyata cara buat opor ayam yang lezat tidak ribet ini gampang sekali ya! Kalian semua bisa membuatnya. Cara buat opor ayam Cocok sekali buat anda yang baru mau belajar memasak ataupun juga bagi kalian yang sudah pandai memasak.

Apakah kamu mau mencoba bikin resep opor ayam nikmat sederhana ini? Kalau anda mau, ayo kalian segera buruan siapin peralatan dan bahan-bahannya, kemudian buat deh Resep opor ayam yang lezat dan tidak rumit ini. Sungguh mudah kan. 

Oleh karena itu, ketimbang anda berfikir lama-lama, maka kita langsung hidangkan resep opor ayam ini. Dijamin kalian tiidak akan nyesel sudah buat resep opor ayam lezat simple ini! Selamat berkreasi dengan resep opor ayam enak sederhana ini di tempat tinggal kalian sendiri,ya!.

