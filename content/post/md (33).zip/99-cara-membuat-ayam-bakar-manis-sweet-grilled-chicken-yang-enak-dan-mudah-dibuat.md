---
description: "Cara membuat Ayam Bakar Manis (Sweet Grilled Chicken) yang enak dan Mudah Dibuat"
title: "Cara membuat Ayam Bakar Manis (Sweet Grilled Chicken) yang enak dan Mudah Dibuat"
slug: 99-cara-membuat-ayam-bakar-manis-sweet-grilled-chicken-yang-enak-dan-mudah-dibuat
date: 2021-06-22T16:50:57.598Z
image: https://img-global.cpcdn.com/recipes/660f1d267a2d3cf6/680x482cq70/ayam-bakar-manis-sweet-grilled-chicken-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/660f1d267a2d3cf6/680x482cq70/ayam-bakar-manis-sweet-grilled-chicken-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/660f1d267a2d3cf6/680x482cq70/ayam-bakar-manis-sweet-grilled-chicken-foto-resep-utama.jpg
author: Katie Conner
ratingvalue: 4.7
reviewcount: 7
recipeingredient:
- "2 ekor ayam probiotik negeri organik atau 3 ekor ayam kampung kecil total sekitar 2 kg"
- "500 ml santan kental dicairkan dengan 250 ml air ayam kampung airnya 500 ml"
- " bisa diganti dengan 2 santan instant kecil dicairkan dengan 600 ml air ayam negeri atau 850 ml ayam kampung"
- " atau"
- "750 ml total cairan untuk ayam negeri"
- "1 liter total cairan untuk ayam kampung"
- "7 lembar daun salam saya suka agak banyak"
- "7 sdm air asam jawa encertidak terlalu kental"
- " Bumbu Halus saya pakai food processor"
- "15 butir bawang merah"
- "13 siung bawang putih"
- "5 cm jahe  potong kecil"
- "5 cm laoslengkuas  potong kecil"
- "1 keping50 gram gula merah sesuai selera"
- "5 butir kemiri"
- " Bumbu Pelengkap"
- "1 sdt ketumbar bubuk sesuai selera"
- "1 sdt lada bubuk sesuai selera"
- "secukupnya garlic salt sesuai selera"
- "sesuai selera kecap manis"
recipeinstructions:
- "Tumis bumbu halus sampai harum dan agak kering"
- "Di panci lain, rebus ayam dengan santan, air asam jawa, dan daun salam"
- "Tuang bumbu tumis ke dalam rebusan ayam"
- "Aduk rata perlahan. Tambahkan ketumbar bubuk, lada bubuk, garlic salt, dan kecap manis. Koreksi rasa."
- "Masak sampai air santan asat/berkurang."
- "Siapkan panggangan (saya pakai Happy Call supaya mudah dibalik-balik). Bakar dengan tingkat kematangan sesuai selera. Selagi dipanggang, oles2 ayam dengan sisa bumbu dari wajan."
- "Sajikan selagi hangat dengan sambal dan lalapan."
categories:
- Resep
tags:
- ayam
- bakar
- manis

katakunci: ayam bakar manis 
nutrition: 178 calories
recipecuisine: Indonesian
preptime: "PT14M"
cooktime: "PT52M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Bakar Manis (Sweet Grilled Chicken)](https://img-global.cpcdn.com/recipes/660f1d267a2d3cf6/680x482cq70/ayam-bakar-manis-sweet-grilled-chicken-foto-resep-utama.jpg)

Selaku seorang orang tua, menyediakan masakan sedap buat famili adalah hal yang sangat menyenangkan untuk kamu sendiri. Tugas seorang ibu Tidak hanya menangani rumah saja, tapi kamu pun harus menyediakan kebutuhan gizi tercukupi dan juga panganan yang dikonsumsi anak-anak wajib lezat.

Di waktu  sekarang, kalian sebenarnya mampu mengorder masakan jadi tidak harus ribet memasaknya lebih dulu. Namun ada juga orang yang memang ingin memberikan hidangan yang terlezat bagi keluarganya. Karena, menghidangkan masakan yang dibuat sendiri jauh lebih bersih dan kita pun bisa menyesuaikan makanan tersebut berdasarkan masakan kesukaan keluarga tercinta. 



Apakah anda adalah salah satu penikmat ayam bakar manis (sweet grilled chicken)?. Asal kamu tahu, ayam bakar manis (sweet grilled chicken) adalah makanan khas di Indonesia yang sekarang digemari oleh setiap orang di hampir setiap tempat di Indonesia. Kamu bisa membuat ayam bakar manis (sweet grilled chicken) sendiri di rumah dan dapat dijadikan camilan favoritmu di hari libur.

Anda jangan bingung jika kamu ingin mendapatkan ayam bakar manis (sweet grilled chicken), karena ayam bakar manis (sweet grilled chicken) mudah untuk dicari dan juga kalian pun boleh mengolahnya sendiri di tempatmu. ayam bakar manis (sweet grilled chicken) dapat dibuat lewat beraneka cara. Kini sudah banyak resep modern yang menjadikan ayam bakar manis (sweet grilled chicken) semakin mantap.

Resep ayam bakar manis (sweet grilled chicken) pun gampang sekali untuk dibuat, lho. Kamu tidak perlu capek-capek untuk memesan ayam bakar manis (sweet grilled chicken), karena Kita mampu menghidangkan sendiri di rumah. Untuk Kalian yang mau membuatnya, berikut resep untuk menyajikan ayam bakar manis (sweet grilled chicken) yang nikamat yang mampu Kalian buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Ayam Bakar Manis (Sweet Grilled Chicken):

1. Ambil 2 ekor ayam probiotik (negeri organik) atau 3 ekor ayam kampung kecil (total sekitar 2 kg)
1. Siapkan 500 ml santan kental dicairkan dengan 250 ml air (ayam kampung airnya 500 ml)
1. Sediakan  bisa diganti dengan 2 santan instant kecil dicairkan dengan 600 ml air (ayam negeri) atau 850 ml (ayam kampung)
1. Gunakan  atau
1. Siapkan 750 ml total cairan untuk ayam negeri
1. Gunakan 1 liter total cairan untuk ayam kampung
1. Gunakan 7 lembar daun salam (saya suka agak banyak)
1. Gunakan 7 sdm air asam jawa (encer/tidak terlalu kental)
1. Gunakan  Bumbu Halus (saya pakai food processor)
1. Ambil 15 butir bawang merah
1. Siapkan 13 siung bawang putih
1. Sediakan 5 cm jahe - potong kecil
1. Siapkan 5 cm laos/lengkuas - potong kecil
1. Gunakan 1 keping/50 gram gula merah (sesuai selera)
1. Ambil 5 butir kemiri
1. Siapkan  Bumbu Pelengkap
1. Ambil 1 sdt ketumbar bubuk (sesuai selera)
1. Sediakan 1 sdt lada bubuk (sesuai selera)
1. Ambil secukupnya garlic salt (sesuai selera)
1. Siapkan sesuai selera kecap manis




<!--inarticleads2-->

##### Cara menyiapkan Ayam Bakar Manis (Sweet Grilled Chicken):

1. Tumis bumbu halus sampai harum dan agak kering
1. Di panci lain, rebus ayam dengan santan, air asam jawa, dan daun salam
1. Tuang bumbu tumis ke dalam rebusan ayam
1. Aduk rata perlahan. Tambahkan ketumbar bubuk, lada bubuk, garlic salt, dan kecap manis. Koreksi rasa.
1. Masak sampai air santan asat/berkurang.
1. Siapkan panggangan (saya pakai Happy Call supaya mudah dibalik-balik). Bakar dengan tingkat kematangan sesuai selera. Selagi dipanggang, oles2 ayam dengan sisa bumbu dari wajan.
1. Sajikan selagi hangat dengan sambal dan lalapan.




Wah ternyata resep ayam bakar manis (sweet grilled chicken) yang enak sederhana ini enteng sekali ya! Kamu semua bisa membuatnya. Resep ayam bakar manis (sweet grilled chicken) Sangat sesuai sekali buat anda yang sedang belajar memasak ataupun juga untuk kalian yang telah jago dalam memasak.

Tertarik untuk mulai mencoba membikin resep ayam bakar manis (sweet grilled chicken) lezat sederhana ini? Kalau kalian tertarik, yuk kita segera buruan menyiapkan peralatan dan bahan-bahannya, maka bikin deh Resep ayam bakar manis (sweet grilled chicken) yang mantab dan tidak rumit ini. Sangat mudah kan. 

Oleh karena itu, daripada kita diam saja, yuk langsung aja hidangkan resep ayam bakar manis (sweet grilled chicken) ini. Pasti anda tak akan menyesal sudah membuat resep ayam bakar manis (sweet grilled chicken) enak tidak ribet ini! Selamat mencoba dengan resep ayam bakar manis (sweet grilled chicken) lezat tidak ribet ini di tempat tinggal kalian sendiri,ya!.

