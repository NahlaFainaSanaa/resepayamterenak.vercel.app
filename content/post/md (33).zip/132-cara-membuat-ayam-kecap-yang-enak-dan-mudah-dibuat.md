---
description: "Cara membuat Ayam Kecap yang enak dan Mudah Dibuat"
title: "Cara membuat Ayam Kecap yang enak dan Mudah Dibuat"
slug: 132-cara-membuat-ayam-kecap-yang-enak-dan-mudah-dibuat
date: 2021-01-24T23:01:00.236Z
image: https://img-global.cpcdn.com/recipes/f4b5a5af8fdb7453/680x482cq70/ayam-kecap-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f4b5a5af8fdb7453/680x482cq70/ayam-kecap-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f4b5a5af8fdb7453/680x482cq70/ayam-kecap-foto-resep-utama.jpg
author: Bessie Harris
ratingvalue: 4.8
reviewcount: 6
recipeingredient:
- "250 gr ayam"
- "300 ml air"
- "7 sdm kecap manis"
- "1 sdm gula jawa"
- " Bumbu "
- "4 siung bawang putih"
- "5 siung bawang merah"
- "2 cabe merah besar"
- "2 cabe rawit sesuaikan selera"
- "1 ruas lengkuas"
- "1 Bawang bombay ukuran kecil"
- "1 lembar daun salam"
- "1 lembar daun jeruk"
- "1/2 sdt merica bubuk"
- "1/2 sdt kaldu jamur"
recipeinstructions:
- "Potong ayam menjadi beberapa bagian, bersihkan"
- "Iris tipis bawang merah, bawang putih, cabe merah, cabe rawit. Iris memanjang bawang bombay. Geprek lengkuas."
- "Goreng ayam hingga sedikit kecoklatan. Kemudian angkat dan sisihkan"
- "Tumis bawang merah, bawang bombay, bawang putih, daun salam, daun jeruk, lengkuas hingga harum"
- "Masukkan ayam, dan tambahkan 300 ml air, kecap, merica bubuk, kalsu jamur, cabe merah"
- "Masak hingga bumbu meresal ± 15 menit"
- "Sajikan"
categories:
- Resep
tags:
- ayam
- kecap

katakunci: ayam kecap 
nutrition: 259 calories
recipecuisine: Indonesian
preptime: "PT18M"
cooktime: "PT32M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Kecap](https://img-global.cpcdn.com/recipes/f4b5a5af8fdb7453/680x482cq70/ayam-kecap-foto-resep-utama.jpg)

Apabila anda seorang yang hobi masak, mempersiapkan panganan lezat pada keluarga tercinta adalah suatu hal yang menyenangkan untuk kamu sendiri. Tanggung jawab seorang ibu Tidak sekedar mengatur rumah saja, tetapi kamu pun wajib menyediakan kebutuhan gizi terpenuhi dan juga panganan yang dimakan orang tercinta wajib lezat.

Di waktu  sekarang, anda memang mampu memesan masakan jadi tanpa harus capek membuatnya dahulu. Tapi ada juga lho orang yang selalu ingin memberikan hidangan yang terlezat bagi orang tercintanya. Pasalnya, menyajikan masakan yang dibuat sendiri jauh lebih bersih dan kita pun bisa menyesuaikan sesuai dengan kesukaan keluarga. 



Mungkinkah anda seorang penyuka ayam kecap?. Asal kamu tahu, ayam kecap adalah sajian khas di Nusantara yang kini digemari oleh kebanyakan orang dari berbagai tempat di Indonesia. Anda dapat menghidangkan ayam kecap sendiri di rumahmu dan boleh jadi santapan favoritmu di hari libur.

Kita tak perlu bingung jika kamu ingin mendapatkan ayam kecap, karena ayam kecap tidak sulit untuk ditemukan dan kamu pun bisa membuatnya sendiri di tempatmu. ayam kecap bisa dimasak dengan berbagai cara. Sekarang telah banyak resep modern yang membuat ayam kecap lebih mantap.

Resep ayam kecap pun gampang sekali dibikin, lho. Kita tidak perlu capek-capek untuk memesan ayam kecap, sebab Anda mampu menghidangkan ditempatmu. Untuk Kita yang akan menghidangkannya, inilah cara untuk menyajikan ayam kecap yang lezat yang mampu Kalian coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Ayam Kecap:

1. Siapkan 250 gr ayam
1. Gunakan 300 ml air
1. Ambil 7 sdm kecap manis
1. Siapkan 1 sdm gula jawa
1. Sediakan  Bumbu :
1. Sediakan 4 siung bawang putih
1. Siapkan 5 siung bawang merah
1. Siapkan 2 cabe merah besar
1. Siapkan 2 cabe rawit (sesuaikan selera)
1. Sediakan 1 ruas lengkuas
1. Gunakan 1 Bawang bombay ukuran kecil
1. Siapkan 1 lembar daun salam
1. Siapkan 1 lembar daun jeruk
1. Sediakan 1/2 sdt merica bubuk
1. Gunakan 1/2 sdt kaldu jamur




<!--inarticleads2-->

##### Cara membuat Ayam Kecap:

1. Potong ayam menjadi beberapa bagian, bersihkan
1. Iris tipis bawang merah, bawang putih, cabe merah, cabe rawit. - Iris memanjang bawang bombay. - Geprek lengkuas.
1. Goreng ayam hingga sedikit kecoklatan. Kemudian angkat dan sisihkan
1. Tumis bawang merah, bawang bombay, bawang putih, daun salam, daun jeruk, lengkuas hingga harum
1. Masukkan ayam, dan tambahkan 300 ml air, kecap, merica bubuk, kalsu jamur, cabe merah
1. Masak hingga bumbu meresal ± 15 menit
1. Sajikan




Ternyata cara membuat ayam kecap yang lezat tidak rumit ini gampang sekali ya! Kamu semua mampu mencobanya. Cara Membuat ayam kecap Cocok banget buat kamu yang sedang belajar memasak ataupun untuk anda yang sudah pandai dalam memasak.

Apakah kamu mau mencoba membuat resep ayam kecap mantab tidak rumit ini? Kalau anda ingin, mending kamu segera buruan siapkan peralatan dan bahan-bahannya, lantas buat deh Resep ayam kecap yang enak dan tidak rumit ini. Benar-benar taidak sulit kan. 

Maka, ketimbang kita diam saja, yuk kita langsung saja buat resep ayam kecap ini. Pasti anda tak akan nyesel sudah bikin resep ayam kecap enak tidak rumit ini! Selamat berkreasi dengan resep ayam kecap enak tidak ribet ini di rumah kalian sendiri,oke!.

