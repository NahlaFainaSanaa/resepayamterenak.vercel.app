---
description: "Resep *Ayam Penyet Sambel Ijo* yang nikmat Untuk Jualan"
title: "Resep *Ayam Penyet Sambel Ijo* yang nikmat Untuk Jualan"
slug: 382-resep-ayam-penyet-sambel-ijo-yang-nikmat-untuk-jualan
date: 2021-06-07T17:26:04.492Z
image: https://img-global.cpcdn.com/recipes/4993dab0ad5c2e06/680x482cq70/ayam-penyet-sambel-ijo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4993dab0ad5c2e06/680x482cq70/ayam-penyet-sambel-ijo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4993dab0ad5c2e06/680x482cq70/ayam-penyet-sambel-ijo-foto-resep-utama.jpg
author: Oscar Harris
ratingvalue: 3.3
reviewcount: 14
recipeingredient:
- "1/2 ekor ayam"
- "1 btg sereh"
- "2 lbr daun jeruk"
- " Bumbu ungkep ayam "
- "4 siung bwg merah Sy skip"
- "3 siung bwg putih"
- "1 ruas jahe"
- "1 ruas kunyit"
- "1 sdt ketumbar"
- "Secukupnya garam"
- "Secukupnya gula"
- "Secukupnya kaldu jamur sy skip"
- "Secukupnya air"
- " Bumbu sambel ijo "
- "8 cabe ijo keriting"
- "2 cabe ijo besar"
- "10 cabe rawit ijo"
- "1 buah tomat ijo"
- "3 siung bwg merah"
- "3 siung bwg putih"
- "2 sdm bumbu dasar cabe ijo tambahan sy           lihat resep"
recipeinstructions:
- "Cuci bersih ayam rebus hingga mendidih, angkat lalu rebus lagi bersama bumbu lainnya hingga bumbu meyerap dan airnya mengering. Lalu goreng hingga matang (sy, tidak terlalu kering), angkat sisihkan."
- "Cuci bahan sambal, potong2 lalu goreng hingga matang. Kemudian ulek kasar saja"
- "Tambahkan bumbu dasar cabe ijo, beri garam dan gula. Ulek hingga tercampur rata"
- "Taruh ayam goreng diatas.sambal lalu penyet dengan ulekan dan pindahkan dalam wadah saji"
- "Daan ayam penyet sambal ijo siap disajikan, ditambah perasan air jeruk nipis lebih enak"
categories:
- Resep
tags:
- ayam
- penyet
- sambel

katakunci: ayam penyet sambel 
nutrition: 190 calories
recipecuisine: Indonesian
preptime: "PT25M"
cooktime: "PT56M"
recipeyield: "1"
recipecategory: Lunch

---


![*Ayam Penyet Sambel Ijo*](https://img-global.cpcdn.com/recipes/4993dab0ad5c2e06/680x482cq70/ayam-penyet-sambel-ijo-foto-resep-utama.jpg)

Andai kamu seorang orang tua, menyajikan olahan lezat pada keluarga adalah suatu hal yang menggembirakan untuk kita sendiri. Tanggung jawab seorang istri Tidak cuma mengerjakan pekerjaan rumah saja, tetapi anda juga wajib memastikan keperluan nutrisi tercukupi dan panganan yang dikonsumsi orang tercinta wajib menggugah selera.

Di zaman  saat ini, kalian memang bisa memesan santapan siap saji tidak harus capek mengolahnya lebih dulu. Tapi banyak juga lho mereka yang selalu mau menyajikan yang terbaik untuk orang tercintanya. Lantaran, menyajikan masakan yang dibuat sendiri jauh lebih bersih dan kita pun bisa menyesuaikan sesuai dengan makanan kesukaan orang tercinta. 



Apakah anda adalah salah satu penyuka *ayam penyet sambel ijo*?. Asal kamu tahu, *ayam penyet sambel ijo* adalah makanan khas di Indonesia yang saat ini disenangi oleh setiap orang di hampir setiap wilayah di Indonesia. Kita bisa menghidangkan *ayam penyet sambel ijo* olahan sendiri di rumahmu dan pasti jadi camilan kegemaranmu di akhir pekan.

Kamu tak perlu bingung jika kamu ingin mendapatkan *ayam penyet sambel ijo*, lantaran *ayam penyet sambel ijo* tidak sulit untuk ditemukan dan kalian pun boleh membuatnya sendiri di tempatmu. *ayam penyet sambel ijo* boleh dimasak lewat beragam cara. Kini ada banyak banget cara kekinian yang menjadikan *ayam penyet sambel ijo* semakin lebih nikmat.

Resep *ayam penyet sambel ijo* juga sangat gampang untuk dibuat, lho. Kalian tidak perlu repot-repot untuk membeli *ayam penyet sambel ijo*, sebab Kita mampu membuatnya sendiri di rumah. Bagi Kamu yang akan mencobanya, di bawah ini adalah cara menyajikan *ayam penyet sambel ijo* yang nikamat yang bisa Kalian hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan *Ayam Penyet Sambel Ijo*:

1. Ambil 1/2 ekor ayam
1. Ambil 1 btg sereh
1. Ambil 2 lbr daun jeruk
1. Gunakan  Bumbu ungkep ayam :
1. Siapkan 4 siung bwg merah (Sy, skip)
1. Sediakan 3 siung bwg putih
1. Ambil 1 ruas jahe
1. Sediakan 1 ruas kunyit
1. Gunakan 1 sdt ketumbar
1. Siapkan Secukupnya garam
1. Siapkan Secukupnya gula
1. Gunakan Secukupnya kaldu jamur (sy, skip)
1. Ambil Secukupnya air
1. Gunakan  Bumbu sambel ijo :
1. Gunakan 8 cabe ijo keriting
1. Ambil 2 cabe ijo besar
1. Ambil 10 cabe rawit ijo
1. Siapkan 1 buah tomat ijo
1. Siapkan 3 siung bwg merah
1. Ambil 3 siung bwg putih
1. Ambil 2 sdm bumbu dasar cabe ijo (tambahan sy)           (lihat resep)




<!--inarticleads2-->

##### Cara menyiapkan *Ayam Penyet Sambel Ijo*:

1. Cuci bersih ayam rebus hingga mendidih, angkat lalu rebus lagi bersama bumbu lainnya hingga bumbu meyerap dan airnya mengering. Lalu goreng hingga matang (sy, tidak terlalu kering), angkat sisihkan.
1. Cuci bahan sambal, potong2 lalu goreng hingga matang. Kemudian ulek kasar saja
1. Tambahkan bumbu dasar cabe ijo, beri garam dan gula. Ulek hingga tercampur rata
1. Taruh ayam goreng diatas.sambal lalu penyet dengan ulekan dan pindahkan dalam wadah saji
1. Daan ayam penyet sambal ijo siap disajikan, ditambah perasan air jeruk nipis lebih enak




Wah ternyata resep *ayam penyet sambel ijo* yang mantab simple ini enteng banget ya! Semua orang dapat membuatnya. Cara Membuat *ayam penyet sambel ijo* Sangat sesuai sekali untuk kita yang sedang belajar memasak maupun untuk kamu yang sudah hebat dalam memasak.

Apakah kamu mau mencoba bikin resep *ayam penyet sambel ijo* nikmat tidak rumit ini? Kalau kamu tertarik, ayo kalian segera buruan siapin alat-alat dan bahannya, lantas buat deh Resep *ayam penyet sambel ijo* yang nikmat dan tidak rumit ini. Benar-benar mudah kan. 

Oleh karena itu, ketimbang anda berlama-lama, maka langsung aja bikin resep *ayam penyet sambel ijo* ini. Pasti anda tak akan menyesal sudah bikin resep *ayam penyet sambel ijo* enak tidak rumit ini! Selamat mencoba dengan resep *ayam penyet sambel ijo* enak tidak ribet ini di rumah sendiri,ya!.

