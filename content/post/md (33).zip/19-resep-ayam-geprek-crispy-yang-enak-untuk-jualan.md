---
description: "Resep Ayam Geprek / Crispy yang enak Untuk Jualan"
title: "Resep Ayam Geprek / Crispy yang enak Untuk Jualan"
slug: 19-resep-ayam-geprek-crispy-yang-enak-untuk-jualan
date: 2021-04-14T03:47:10.219Z
image: https://img-global.cpcdn.com/recipes/147156d34a533ef0/680x482cq70/ayam-geprek-crispy-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/147156d34a533ef0/680x482cq70/ayam-geprek-crispy-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/147156d34a533ef0/680x482cq70/ayam-geprek-crispy-foto-resep-utama.jpg
author: Theresa Collier
ratingvalue: 3.2
reviewcount: 14
recipeingredient:
- "Secukupnya ayam fillet garam jeniper"
- " Bumbu marinasi "
- "5 Bawang putih yg sudah dihaluskan"
- "1 sdt Lada bubuk"
- "1 sdm Kaldu bubuk"
- "1 sdm Garam"
- "1 sdm Cabe bubuk optional"
- "1 sdm Ketumbar"
- " Bumbu Baluran Tepung "
- " Tepung terigu agak banyakan"
- "1 sdm garam"
- "1 sdm kaldu bubuk"
- "1 sdm lada bubuk"
- "1 sdm ketumbar bubuk"
- "1 sdt baking powder  kalo gk ada boleh pake baking soda"
- " Bahan celupan air "
- " Air dingin  es"
- "1 sdt baking powder  baking soda"
- "1 sdt kaldu bubuk"
- "1 sdt garam"
recipeinstructions:
- "Bersihkan ayam, baluri jeniper dan garam, biarkan sebentar"
- "Siapkan bumbu marinasi, tambahkan ke ayam, aduk rata, biarkan selama semalaman di kulkas."
- "Siapkan bahan tepung balur, aduk rata. Sisihkan."
- "Siapkan bahan celupan air, aduk hingga merata semua."
- "Balurkan ayam yg sudah di marinasi ke dalam tepung, aduk dengan dibalik2 spt di gulung2, jangan di tekan2, lakukan selama 1-2 mnit"
- "Celupkan ke dalam campuran air es, angkat, lalu tiriskan airnya, usahakan air nya benar2 tertiriskan, supaya tepung nya tidak bergumpal2"
- "Lalu baluri lagi dg tepung tadi, guling2kan ayam nya sampai tepung nya terbentuk kriwil2 dn banyak"
- "Jika di rasa tepung kurang tebal, bisa di celupkan lagi ke air es, lalu baluri lg dg tepung"
- "Sambil masih di aduk ayamnya, panas kan minyak, stelah selesai proses baluran tepung, goreng ayam dengan posisi ayam bener2 tenggelam ke dlm minyak, minyak nya harus banyak dan bener2 udah panas pas di celupin ayam nya ke minyak"
- "Kalo sudah keemasan, balik ayamnya. Cukup 1 x balik saja. Stelah matang keemasan, angkat dn tiriskan"
- "Geprek ayam nya sedikit, baluri sambal di atasnya"
- "Siap di nikmati dengan nasi hangat :)"
categories:
- Resep
tags:
- ayam
- geprek
- 

katakunci: ayam geprek  
nutrition: 230 calories
recipecuisine: Indonesian
preptime: "PT14M"
cooktime: "PT50M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam Geprek / Crispy](https://img-global.cpcdn.com/recipes/147156d34a533ef0/680x482cq70/ayam-geprek-crispy-foto-resep-utama.jpg)

Selaku seorang wanita, menyuguhkan masakan menggugah selera buat keluarga merupakan suatu hal yang menggembirakan bagi kita sendiri. Tugas seorang ibu Tidak cuman menjaga rumah saja, tapi kamu pun wajib menyediakan kebutuhan gizi terpenuhi dan panganan yang disantap anak-anak mesti mantab.

Di masa  sekarang, kita memang mampu mengorder olahan yang sudah jadi walaupun tidak harus ribet mengolahnya dahulu. Tapi ada juga mereka yang selalu mau menyajikan yang terenak bagi orang tercintanya. Karena, menghidangkan masakan sendiri akan jauh lebih bersih dan bisa menyesuaikan masakan tersebut berdasarkan kesukaan famili. 



Apakah anda adalah seorang penggemar ayam geprek / crispy?. Asal kamu tahu, ayam geprek / crispy adalah hidangan khas di Indonesia yang kini disukai oleh orang-orang dari hampir setiap tempat di Indonesia. Kalian bisa membuat ayam geprek / crispy sendiri di rumahmu dan dapat dijadikan santapan kegemaranmu di akhir pekan.

Kita tidak perlu bingung jika kamu ingin menyantap ayam geprek / crispy, sebab ayam geprek / crispy gampang untuk dicari dan juga anda pun dapat mengolahnya sendiri di tempatmu. ayam geprek / crispy dapat dimasak lewat beraneka cara. Sekarang telah banyak sekali cara modern yang menjadikan ayam geprek / crispy semakin enak.

Resep ayam geprek / crispy juga sangat mudah dibuat, lho. Kamu jangan ribet-ribet untuk memesan ayam geprek / crispy, karena Anda mampu menghidangkan sendiri di rumah. Untuk Kamu yang akan menghidangkannya, berikut ini cara menyajikan ayam geprek / crispy yang mantab yang bisa Kalian buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Ayam Geprek / Crispy:

1. Siapkan Secukupnya ayam fillet, garam, jeniper
1. Sediakan  Bumbu marinasi :
1. Gunakan 5 Bawang putih yg sudah dihaluskan
1. Sediakan 1 sdt Lada bubuk
1. Sediakan 1 sdm Kaldu bubuk
1. Sediakan 1 sdm Garam
1. Ambil 1 sdm Cabe bubuk (optional)
1. Siapkan 1 sdm Ketumbar
1. Sediakan  Bumbu Baluran Tepung :
1. Gunakan  Tepung terigu (agak banyakan)
1. Ambil 1 sdm garam
1. Ambil 1 sdm kaldu bubuk
1. Sediakan 1 sdm lada bubuk
1. Sediakan 1 sdm ketumbar bubuk
1. Siapkan 1 sdt baking powder / kalo gk ada boleh pake baking soda
1. Sediakan  Bahan celupan air :
1. Ambil  Air dingin + es
1. Gunakan 1 sdt baking powder / baking soda
1. Sediakan 1 sdt kaldu bubuk
1. Gunakan 1 sdt garam




<!--inarticleads2-->

##### Cara menyiapkan Ayam Geprek / Crispy:

1. Bersihkan ayam, baluri jeniper dan garam, biarkan sebentar
1. Siapkan bumbu marinasi, tambahkan ke ayam, aduk rata, biarkan selama semalaman di kulkas.
1. Siapkan bahan tepung balur, aduk rata. Sisihkan.
1. Siapkan bahan celupan air, aduk hingga merata semua.
1. Balurkan ayam yg sudah di marinasi ke dalam tepung, aduk dengan dibalik2 spt di gulung2, jangan di tekan2, lakukan selama 1-2 mnit
1. Celupkan ke dalam campuran air es, angkat, lalu tiriskan airnya, usahakan air nya benar2 tertiriskan, supaya tepung nya tidak bergumpal2
1. Lalu baluri lagi dg tepung tadi, guling2kan ayam nya sampai tepung nya terbentuk kriwil2 dn banyak
1. Jika di rasa tepung kurang tebal, bisa di celupkan lagi ke air es, lalu baluri lg dg tepung
1. Sambil masih di aduk ayamnya, panas kan minyak, stelah selesai proses baluran tepung, goreng ayam dengan posisi ayam bener2 tenggelam ke dlm minyak, minyak nya harus banyak dan bener2 udah panas pas di celupin ayam nya ke minyak
1. Kalo sudah keemasan, balik ayamnya. Cukup 1 x balik saja. - Stelah matang keemasan, angkat dn tiriskan
1. Geprek ayam nya sedikit, baluri sambal di atasnya
1. Siap di nikmati dengan nasi hangat :)




Wah ternyata cara membuat ayam geprek / crispy yang mantab tidak ribet ini gampang sekali ya! Kita semua dapat memasaknya. Cara buat ayam geprek / crispy Sangat sesuai sekali buat kalian yang baru belajar memasak atau juga bagi kalian yang telah ahli dalam memasak.

Tertarik untuk mencoba bikin resep ayam geprek / crispy mantab simple ini? Kalau kamu ingin, ayo kalian segera siapkan alat dan bahannya, kemudian buat deh Resep ayam geprek / crispy yang nikmat dan tidak rumit ini. Benar-benar gampang kan. 

Maka, daripada kalian berfikir lama-lama, maka kita langsung hidangkan resep ayam geprek / crispy ini. Dijamin kamu tiidak akan nyesel sudah membuat resep ayam geprek / crispy lezat sederhana ini! Selamat berkreasi dengan resep ayam geprek / crispy nikmat tidak ribet ini di rumah masing-masing,ya!.

