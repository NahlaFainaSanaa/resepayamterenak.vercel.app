---
description: "Cara membuat Fried Chicken/Ayam Goreng Crispy/KFC KW yang lezat dan Mudah Dibuat"
title: "Cara membuat Fried Chicken/Ayam Goreng Crispy/KFC KW yang lezat dan Mudah Dibuat"
slug: 151-cara-membuat-fried-chicken-ayam-goreng-crispy-kfc-kw-yang-lezat-dan-mudah-dibuat
date: 2021-01-30T07:47:50.498Z
image: https://img-global.cpcdn.com/recipes/db5121e070378f16/680x482cq70/fried-chickenayam-goreng-crispykfc-kw-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/db5121e070378f16/680x482cq70/fried-chickenayam-goreng-crispykfc-kw-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/db5121e070378f16/680x482cq70/fried-chickenayam-goreng-crispykfc-kw-foto-resep-utama.jpg
author: Ruby Bass
ratingvalue: 4.5
reviewcount: 7
recipeingredient:
- "500 gr ayam broiler"
- " Bumbu halus utk marinasi "
- "3 bh bawang putih"
- "1/2 sdt ketumbar bubuk"
- "1/2 sdt lada bubuk"
- "1/2 sdt kunyit bubuk optional"
- "1 ruas jahe geprek"
- "1 sdt garam"
- "secukupnya Kaldu bubuk"
- " Bahan pencelup "
- "1 btr putih telur kocok lepas"
- "60 ml air es"
- "Sejumput garam"
- "1/2 sdt baking soda"
- " Bahan pelapis "
- "130 gr terigu protein tinggi"
- "40 gr maizena"
- "1/4 sdt lada bubuk"
- "1/2 sdt paprika powder optional"
- "1/4 sdt basil boleh skip"
- "1/4 sdt oregano boleh skip"
- "1/4 sdt thyme boleh skip"
- "1/2 sdt garam"
- "secukupnya Kaldu bubuk"
recipeinstructions:
- "Cuci bersih ayam, potong2 lalu marinasi dgn bumbu halus. Simpan di dlm chiller (sy 1malam) agar bumbu meresap sempurna sampai ke tulang2."
- "Campur semua bahan pelapis. Aduk rata."
- "Siapkan bahan pencelup : campur air es, putih telur, garam, dan 3sdm campuran tepung pelapis, Aduk rata. Tambahkan baking soda. Masukkan5menit ke dlm kulkas agar tetap dingin."
- "Siapkan minyak banyak dan panas. Masukkan ayam ke tepung pelapis -pencelup-pelapis sambil dicubit2. Langsung goreng dgn tehnik deepfry. Pastikan timing menggorengnya pas ya.. agar hasilnya tetap keriting dan renyah."
categories:
- Resep
tags:
- fried
- chickenayam
- goreng

katakunci: fried chickenayam goreng 
nutrition: 208 calories
recipecuisine: Indonesian
preptime: "PT10M"
cooktime: "PT60M"
recipeyield: "3"
recipecategory: Dinner

---


![Fried Chicken/Ayam Goreng Crispy/KFC KW](https://img-global.cpcdn.com/recipes/db5121e070378f16/680x482cq70/fried-chickenayam-goreng-crispykfc-kw-foto-resep-utama.jpg)

Selaku seorang orang tua, menyediakan hidangan sedap buat keluarga merupakan hal yang sangat menyenangkan untuk kita sendiri. Peran seorang  wanita Tidak cuman mengurus rumah saja, tapi kamu juga wajib menyediakan kebutuhan gizi tercukupi dan santapan yang disantap keluarga tercinta wajib nikmat.

Di era  saat ini, anda memang mampu memesan panganan praktis meski tanpa harus susah membuatnya lebih dulu. Namun banyak juga lho mereka yang memang mau memberikan makanan yang terbaik untuk orang yang dicintainya. Sebab, memasak yang dibuat sendiri akan jauh lebih bersih dan bisa menyesuaikan masakan tersebut sesuai makanan kesukaan orang tercinta. 



Apakah kamu salah satu penggemar fried chicken/ayam goreng crispy/kfc kw?. Tahukah kamu, fried chicken/ayam goreng crispy/kfc kw adalah hidangan khas di Indonesia yang saat ini digemari oleh setiap orang di berbagai wilayah di Nusantara. Kita bisa memasak fried chicken/ayam goreng crispy/kfc kw sendiri di rumah dan boleh dijadikan camilan kesenanganmu di akhir pekanmu.

Kalian tak perlu bingung jika kamu ingin menyantap fried chicken/ayam goreng crispy/kfc kw, karena fried chicken/ayam goreng crispy/kfc kw tidak sukar untuk didapatkan dan juga kamu pun dapat menghidangkannya sendiri di rumah. fried chicken/ayam goreng crispy/kfc kw boleh dimasak dengan beraneka cara. Saat ini sudah banyak banget cara modern yang menjadikan fried chicken/ayam goreng crispy/kfc kw lebih mantap.

Resep fried chicken/ayam goreng crispy/kfc kw juga mudah untuk dibuat, lho. Kamu tidak perlu capek-capek untuk membeli fried chicken/ayam goreng crispy/kfc kw, tetapi Kita bisa menyiapkan ditempatmu. Untuk Anda yang akan menyajikannya, di bawah ini adalah cara membuat fried chicken/ayam goreng crispy/kfc kw yang lezat yang dapat Anda coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Fried Chicken/Ayam Goreng Crispy/KFC KW:

1. Siapkan 500 gr ayam broiler
1. Siapkan  Bumbu halus utk marinasi :
1. Ambil 3 bh bawang putih
1. Siapkan 1/2 sdt ketumbar bubuk
1. Siapkan 1/2 sdt lada bubuk
1. Ambil 1/2 sdt kunyit bubuk (optional)
1. Ambil 1 ruas jahe, geprek
1. Gunakan 1 sdt garam
1. Sediakan secukupnya Kaldu bubuk
1. Sediakan  Bahan pencelup :
1. Siapkan 1 btr putih telur, kocok lepas
1. Gunakan 60 ml air es
1. Ambil Sejumput garam
1. Gunakan 1/2 sdt baking soda
1. Gunakan  Bahan pelapis :
1. Ambil 130 gr terigu protein tinggi
1. Sediakan 40 gr maizena
1. Sediakan 1/4 sdt lada bubuk
1. Ambil 1/2 sdt paprika powder (optional)
1. Sediakan 1/4 sdt basil (boleh skip)
1. Sediakan 1/4 sdt oregano (boleh skip)
1. Siapkan 1/4 sdt thyme (boleh skip)
1. Gunakan 1/2 sdt garam
1. Sediakan secukupnya Kaldu bubuk




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Fried Chicken/Ayam Goreng Crispy/KFC KW:

1. Cuci bersih ayam, potong2 lalu marinasi dgn bumbu halus. Simpan di dlm chiller (sy 1malam) agar bumbu meresap sempurna sampai ke tulang2.
1. Campur semua bahan pelapis. Aduk rata.
1. Siapkan bahan pencelup : campur air es, putih telur, garam, dan 3sdm campuran tepung pelapis, Aduk rata. Tambahkan baking soda. Masukkan5menit ke dlm kulkas agar tetap dingin.
1. Siapkan minyak banyak dan panas. Masukkan ayam ke tepung pelapis -pencelup-pelapis sambil dicubit2. Langsung goreng dgn tehnik deepfry. Pastikan timing menggorengnya pas ya.. agar hasilnya tetap keriting dan renyah.




Ternyata resep fried chicken/ayam goreng crispy/kfc kw yang nikamt simple ini gampang banget ya! Kamu semua bisa menghidangkannya. Cara buat fried chicken/ayam goreng crispy/kfc kw Sangat sesuai sekali untuk kita yang baru belajar memasak ataupun bagi kamu yang sudah hebat memasak.

Apakah kamu mau mencoba membuat resep fried chicken/ayam goreng crispy/kfc kw enak sederhana ini? Kalau ingin, mending kamu segera buruan siapin alat dan bahan-bahannya, lantas bikin deh Resep fried chicken/ayam goreng crispy/kfc kw yang nikmat dan tidak rumit ini. Benar-benar gampang kan. 

Maka, daripada anda berfikir lama-lama, ayo kita langsung buat resep fried chicken/ayam goreng crispy/kfc kw ini. Dijamin kamu tak akan nyesel sudah bikin resep fried chicken/ayam goreng crispy/kfc kw mantab tidak ribet ini! Selamat mencoba dengan resep fried chicken/ayam goreng crispy/kfc kw nikmat sederhana ini di rumah kalian masing-masing,ya!.

