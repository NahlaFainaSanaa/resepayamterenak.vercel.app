---
description: "Cara membuat Ayam Bakar Manis (Sweet Grilled Chicken) Sederhana dan Mudah Dibuat"
title: "Cara membuat Ayam Bakar Manis (Sweet Grilled Chicken) Sederhana dan Mudah Dibuat"
slug: 297-cara-membuat-ayam-bakar-manis-sweet-grilled-chicken-sederhana-dan-mudah-dibuat
date: 2021-03-04T09:29:00.923Z
image: https://img-global.cpcdn.com/recipes/660f1d267a2d3cf6/680x482cq70/ayam-bakar-manis-sweet-grilled-chicken-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/660f1d267a2d3cf6/680x482cq70/ayam-bakar-manis-sweet-grilled-chicken-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/660f1d267a2d3cf6/680x482cq70/ayam-bakar-manis-sweet-grilled-chicken-foto-resep-utama.jpg
author: Phoebe Wheeler
ratingvalue: 4.6
reviewcount: 13
recipeingredient:
- "2 ekor ayam probiotik negeri organik atau 3 ekor ayam kampung kecil total sekitar 2 kg"
- "500 ml santan kental dicairkan dengan 250 ml air ayam kampung airnya 500 ml"
- " bisa diganti dengan 2 santan instant kecil dicairkan dengan 600 ml air ayam negeri atau 850 ml ayam kampung"
- " atau"
- "750 ml total cairan untuk ayam negeri"
- "1 liter total cairan untuk ayam kampung"
- "7 lembar daun salam saya suka agak banyak"
- "7 sdm air asam jawa encertidak terlalu kental"
- " Bumbu Halus saya pakai food processor"
- "15 butir bawang merah"
- "13 siung bawang putih"
- "5 cm jahe  potong kecil"
- "5 cm laoslengkuas  potong kecil"
- "1 keping50 gram gula merah sesuai selera"
- "5 butir kemiri"
- " Bumbu Pelengkap"
- "1 sdt ketumbar bubuk sesuai selera"
- "1 sdt lada bubuk sesuai selera"
- "secukupnya garlic salt sesuai selera"
- "sesuai selera kecap manis"
recipeinstructions:
- "Tumis bumbu halus sampai harum dan agak kering"
- "Di panci lain, rebus ayam dengan santan, air asam jawa, dan daun salam"
- "Tuang bumbu tumis ke dalam rebusan ayam"
- "Aduk rata perlahan. Tambahkan ketumbar bubuk, lada bubuk, garlic salt, dan kecap manis. Koreksi rasa."
- "Masak sampai air santan asat/berkurang."
- "Siapkan panggangan (saya pakai Happy Call supaya mudah dibalik-balik). Bakar dengan tingkat kematangan sesuai selera. Selagi dipanggang, oles2 ayam dengan sisa bumbu dari wajan."
- "Sajikan selagi hangat dengan sambal dan lalapan."
categories:
- Resep
tags:
- ayam
- bakar
- manis

katakunci: ayam bakar manis 
nutrition: 219 calories
recipecuisine: Indonesian
preptime: "PT40M"
cooktime: "PT49M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Bakar Manis (Sweet Grilled Chicken)](https://img-global.cpcdn.com/recipes/660f1d267a2d3cf6/680x482cq70/ayam-bakar-manis-sweet-grilled-chicken-foto-resep-utama.jpg)

Jika kamu seorang istri, menyediakan panganan sedap pada keluarga tercinta merupakan hal yang sangat menyenangkan untuk kita sendiri. Peran seorang ibu bukan sekedar mengerjakan pekerjaan rumah saja, namun kamu juga wajib menyediakan kebutuhan gizi tercukupi dan masakan yang dimakan anak-anak wajib mantab.

Di zaman  saat ini, kalian memang bisa membeli masakan yang sudah jadi meski tidak harus repot membuatnya dahulu. Tetapi banyak juga mereka yang memang ingin menghidangkan yang terlezat untuk keluarganya. Karena, memasak yang dibuat sendiri jauh lebih higienis dan kita pun bisa menyesuaikan berdasarkan kesukaan famili. 



Apakah anda adalah salah satu penggemar ayam bakar manis (sweet grilled chicken)?. Asal kamu tahu, ayam bakar manis (sweet grilled chicken) merupakan makanan khas di Nusantara yang sekarang digemari oleh setiap orang di berbagai daerah di Indonesia. Kalian dapat memasak ayam bakar manis (sweet grilled chicken) olahan sendiri di rumah dan pasti jadi santapan kesukaanmu di hari liburmu.

Kalian tidak usah bingung jika kamu ingin memakan ayam bakar manis (sweet grilled chicken), sebab ayam bakar manis (sweet grilled chicken) mudah untuk dicari dan kamu pun bisa memasaknya sendiri di tempatmu. ayam bakar manis (sweet grilled chicken) boleh diolah lewat beraneka cara. Kini ada banyak resep modern yang menjadikan ayam bakar manis (sweet grilled chicken) semakin enak.

Resep ayam bakar manis (sweet grilled chicken) juga sangat gampang untuk dibuat, lho. Kalian jangan ribet-ribet untuk membeli ayam bakar manis (sweet grilled chicken), lantaran Kalian dapat menghidangkan di rumahmu. Bagi Kamu yang mau mencobanya, berikut cara membuat ayam bakar manis (sweet grilled chicken) yang nikamat yang mampu Anda coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Ayam Bakar Manis (Sweet Grilled Chicken):

1. Gunakan 2 ekor ayam probiotik (negeri organik) atau 3 ekor ayam kampung kecil (total sekitar 2 kg)
1. Siapkan 500 ml santan kental dicairkan dengan 250 ml air (ayam kampung airnya 500 ml)
1. Siapkan  bisa diganti dengan 2 santan instant kecil dicairkan dengan 600 ml air (ayam negeri) atau 850 ml (ayam kampung)
1. Siapkan  atau
1. Gunakan 750 ml total cairan untuk ayam negeri
1. Gunakan 1 liter total cairan untuk ayam kampung
1. Gunakan 7 lembar daun salam (saya suka agak banyak)
1. Sediakan 7 sdm air asam jawa (encer/tidak terlalu kental)
1. Ambil  Bumbu Halus (saya pakai food processor)
1. Ambil 15 butir bawang merah
1. Siapkan 13 siung bawang putih
1. Ambil 5 cm jahe - potong kecil
1. Sediakan 5 cm laos/lengkuas - potong kecil
1. Siapkan 1 keping/50 gram gula merah (sesuai selera)
1. Gunakan 5 butir kemiri
1. Gunakan  Bumbu Pelengkap
1. Siapkan 1 sdt ketumbar bubuk (sesuai selera)
1. Gunakan 1 sdt lada bubuk (sesuai selera)
1. Ambil secukupnya garlic salt (sesuai selera)
1. Gunakan sesuai selera kecap manis




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Bakar Manis (Sweet Grilled Chicken):

1. Tumis bumbu halus sampai harum dan agak kering
1. Di panci lain, rebus ayam dengan santan, air asam jawa, dan daun salam
1. Tuang bumbu tumis ke dalam rebusan ayam
1. Aduk rata perlahan. Tambahkan ketumbar bubuk, lada bubuk, garlic salt, dan kecap manis. Koreksi rasa.
1. Masak sampai air santan asat/berkurang.
1. Siapkan panggangan (saya pakai Happy Call supaya mudah dibalik-balik). Bakar dengan tingkat kematangan sesuai selera. Selagi dipanggang, oles2 ayam dengan sisa bumbu dari wajan.
1. Sajikan selagi hangat dengan sambal dan lalapan.




Ternyata cara buat ayam bakar manis (sweet grilled chicken) yang lezat sederhana ini enteng sekali ya! Kita semua dapat mencobanya. Cara Membuat ayam bakar manis (sweet grilled chicken) Sangat cocok sekali untuk kalian yang sedang belajar memasak ataupun juga bagi kalian yang sudah hebat memasak.

Tertarik untuk mencoba buat resep ayam bakar manis (sweet grilled chicken) enak tidak rumit ini? Kalau kamu mau, yuk kita segera buruan siapin alat dan bahan-bahannya, lantas buat deh Resep ayam bakar manis (sweet grilled chicken) yang lezat dan simple ini. Sangat gampang kan. 

Jadi, ketimbang anda berfikir lama-lama, hayo kita langsung saja bikin resep ayam bakar manis (sweet grilled chicken) ini. Pasti anda tiidak akan nyesel sudah membuat resep ayam bakar manis (sweet grilled chicken) lezat tidak ribet ini! Selamat mencoba dengan resep ayam bakar manis (sweet grilled chicken) mantab tidak rumit ini di tempat tinggal masing-masing,ya!.

