---
description: "Cara buat Ayam Rica- Rica Daun Kemangi yang enak dan Mudah Dibuat"
title: "Cara buat Ayam Rica- Rica Daun Kemangi yang enak dan Mudah Dibuat"
slug: 330-cara-buat-ayam-rica-rica-daun-kemangi-yang-enak-dan-mudah-dibuat
date: 2021-04-16T10:20:50.674Z
image: https://img-global.cpcdn.com/recipes/d8d82fb574cc0b67/680x482cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d8d82fb574cc0b67/680x482cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d8d82fb574cc0b67/680x482cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
author: Corey Herrera
ratingvalue: 4.9
reviewcount: 8
recipeingredient:
- "1 ekor ayam potong 812"
- " Daun kemangi"
- " Bumbu halus"
- "1 ruas Kunyit"
- "7 siung bawang merah"
- "4 siung bawang putih"
- "sesuai selera Cabai"
- "1 sendok teh Ketumbar"
- "1 sendok teh Lada"
- " Bumbu tambahan untuk tumis"
- "1 ruas Lengkoas  geprek"
- "1 ruas Jahe  geprek"
- "4 batang sereh geprek"
- "1 buah tomat besar potong dadu"
- "3 daun salam"
- "4 daun jeruk"
- " Kaldu ayam"
- " Garam"
- " Gula"
recipeinstructions:
- ""
- "Tumis bumbu halus hingga wangi"
- "Masukan bahan tambahan tumisan"
- "Jika bumbu sudah matang, masukan ayam dan tambah air secukup nya"
- "Tambahkan garam secukup nya"
- "Masak hingga matang, masukan daun kemangi"
categories:
- Resep
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 288 calories
recipecuisine: Indonesian
preptime: "PT17M"
cooktime: "PT37M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam Rica- Rica Daun Kemangi](https://img-global.cpcdn.com/recipes/d8d82fb574cc0b67/680x482cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg)

Andai kita seorang orang tua, menyediakan hidangan lezat kepada keluarga tercinta merupakan suatu hal yang memuaskan untuk anda sendiri. Tugas seorang istri bukan cuma menjaga rumah saja, tetapi kamu pun wajib memastikan keperluan nutrisi terpenuhi dan juga olahan yang disantap anak-anak mesti lezat.

Di waktu  sekarang, kalian sebenarnya dapat memesan hidangan instan tidak harus susah memasaknya terlebih dahulu. Tapi ada juga lho orang yang selalu mau memberikan yang terbaik bagi keluarganya. Pasalnya, menghidangkan masakan yang dibuat sendiri jauh lebih higienis dan kita pun bisa menyesuaikan sesuai selera famili. 



Mungkinkah anda seorang penggemar ayam rica- rica daun kemangi?. Asal kamu tahu, ayam rica- rica daun kemangi merupakan hidangan khas di Indonesia yang sekarang digemari oleh kebanyakan orang di hampir setiap daerah di Nusantara. Anda dapat menghidangkan ayam rica- rica daun kemangi sendiri di rumahmu dan boleh jadi camilan kesukaanmu di akhir pekan.

Kita tak perlu bingung jika kamu ingin menyantap ayam rica- rica daun kemangi, sebab ayam rica- rica daun kemangi gampang untuk ditemukan dan juga anda pun boleh membuatnya sendiri di tempatmu. ayam rica- rica daun kemangi boleh dimasak lewat beraneka cara. Kini pun telah banyak resep modern yang membuat ayam rica- rica daun kemangi semakin lezat.

Resep ayam rica- rica daun kemangi juga sangat mudah untuk dibuat, lho. Kalian tidak usah capek-capek untuk memesan ayam rica- rica daun kemangi, tetapi Kamu bisa membuatnya di rumah sendiri. Bagi Kalian yang akan mencobanya, inilah resep membuat ayam rica- rica daun kemangi yang lezat yang bisa Kita coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Ayam Rica- Rica Daun Kemangi:

1. Sediakan 1 ekor ayam potong 8-12
1. Gunakan  Daun kemangi
1. Sediakan  Bumbu halus:
1. Siapkan 1 ruas Kunyit
1. Gunakan 7 siung bawang merah
1. Sediakan 4 siung bawang putih
1. Siapkan sesuai selera Cabai
1. Gunakan 1 sendok teh Ketumbar
1. Ambil 1 sendok teh Lada
1. Sediakan  Bumbu tambahan untuk tumis:
1. Sediakan 1 ruas Lengkoas  (geprek)
1. Siapkan 1 ruas Jahe  (geprek)
1. Gunakan 4 batang sereh (geprek)
1. Ambil 1 buah tomat besar (potong dadu)
1. Gunakan 3 daun salam
1. Sediakan 4 daun jeruk
1. Sediakan  Kaldu ayam
1. Sediakan  Garam
1. Ambil  Gula




<!--inarticleads2-->

##### Cara menyiapkan Ayam Rica- Rica Daun Kemangi:

1. 
1. Tumis bumbu halus hingga wangi
1. Masukan bahan tambahan tumisan
1. Jika bumbu sudah matang, masukan ayam dan tambah air secukup nya
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Ayam Rica- Rica Daun Kemangi">1. Tambahkan garam secukup nya
1. Masak hingga matang, masukan daun kemangi




Ternyata cara membuat ayam rica- rica daun kemangi yang lezat simple ini enteng sekali ya! Semua orang dapat mencobanya. Cara buat ayam rica- rica daun kemangi Sangat sesuai sekali untuk anda yang sedang belajar memasak ataupun juga bagi kalian yang telah lihai dalam memasak.

Tertarik untuk mulai mencoba membikin resep ayam rica- rica daun kemangi mantab simple ini? Kalau anda tertarik, ayo kamu segera buruan siapin peralatan dan bahannya, kemudian buat deh Resep ayam rica- rica daun kemangi yang enak dan tidak ribet ini. Sungguh mudah kan. 

Maka dari itu, daripada anda berlama-lama, ayo kita langsung bikin resep ayam rica- rica daun kemangi ini. Pasti anda gak akan menyesal sudah membuat resep ayam rica- rica daun kemangi mantab tidak ribet ini! Selamat berkreasi dengan resep ayam rica- rica daun kemangi lezat sederhana ini di rumah sendiri,ya!.

