---
description: "Cara membuat Opor Ayam Sederhana Untuk Jualan"
title: "Cara membuat Opor Ayam Sederhana Untuk Jualan"
slug: 398-cara-membuat-opor-ayam-sederhana-untuk-jualan
date: 2021-02-02T11:11:49.915Z
image: https://img-global.cpcdn.com/recipes/907306f98c237ad6/680x482cq70/opor-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/907306f98c237ad6/680x482cq70/opor-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/907306f98c237ad6/680x482cq70/opor-ayam-foto-resep-utama.jpg
author: Emily Newman
ratingvalue: 3.6
reviewcount: 4
recipeingredient:
- "1 ekor ayam sedang potong2 cuci bersih"
- "50 ml santan kara campur air hingga 100ml"
- "3 bh cabe keriting iris serong"
- "1 btg serai geprek"
- "3 daun salam"
- "3 daun jeruk buang tulang"
- "1 ruas jahe"
- "1 ruas lengkuas"
- "1/8 bj pala"
- "1/4 sdt jintan"
- "1/2 sdt ketumbar bubuk"
- "600 ml air minum"
- " Minyak unt menumis"
- "1 sdt garam batu himalayan"
- "secukupnya Lada"
- " Bawang goreng  telur rebus sbg pelengkap"
- " Bahan halus "
- "12 siung bawang merah"
- "6 siung bawang putih"
- "5 bh kemiri"
- "1 ruas kunyit"
recipeinstructions:
- "Tumis semua bahan kecuali santan."
- "Masukkan ayam, aduk rata. Tutup sbntr wajan. Biarkan bumbu meresap."
- "Beri air, didihkan dan masak hingga ayam empuk."
- "Beri garam. Koreksi rasa, matikan api. Masukkan santan &amp; aduk rata."
- "Angkat ayam, saring kuah agar ampas bumbu tdk ikt. Sajikan dgn bawang goreng &amp; telur rebus."
categories:
- Resep
tags:
- opor
- ayam

katakunci: opor ayam 
nutrition: 227 calories
recipecuisine: Indonesian
preptime: "PT31M"
cooktime: "PT54M"
recipeyield: "2"
recipecategory: Dinner

---


![Opor Ayam](https://img-global.cpcdn.com/recipes/907306f98c237ad6/680x482cq70/opor-ayam-foto-resep-utama.jpg)

Apabila kita seorang istri, mempersiapkan masakan enak buat orang tercinta merupakan suatu hal yang mengasyikan untuk kita sendiri. Peran seorang istri Tidak cuman mengurus rumah saja, tapi anda pun harus menyediakan keperluan gizi tercukupi dan juga olahan yang dimakan orang tercinta mesti menggugah selera.

Di masa  sekarang, kalian memang bisa membeli santapan siap saji meski tidak harus repot membuatnya terlebih dahulu. Tapi ada juga lho mereka yang memang ingin memberikan makanan yang terlezat untuk keluarganya. Lantaran, memasak yang dibuat sendiri jauh lebih higienis dan bisa menyesuaikan sesuai dengan kesukaan famili. 



Mungkinkah anda salah satu penikmat opor ayam?. Asal kamu tahu, opor ayam adalah sajian khas di Nusantara yang sekarang digemari oleh kebanyakan orang dari berbagai wilayah di Nusantara. Kamu bisa menyajikan opor ayam kreasi sendiri di rumahmu dan pasti jadi santapan favorit di hari libur.

Kita tidak perlu bingung untuk menyantap opor ayam, sebab opor ayam mudah untuk didapatkan dan juga kita pun bisa mengolahnya sendiri di rumah. opor ayam boleh dimasak dengan bermacam cara. Kini pun ada banyak banget cara modern yang membuat opor ayam semakin lezat.

Resep opor ayam juga sangat gampang dibikin, lho. Anda tidak perlu ribet-ribet untuk membeli opor ayam, tetapi Kamu dapat menghidangkan di rumah sendiri. Bagi Kita yang ingin membuatnya, dibawah ini merupakan resep menyajikan opor ayam yang enak yang bisa Kamu coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Opor Ayam:

1. Sediakan 1 ekor ayam sedang, potong2, cuci bersih
1. Siapkan 50 ml santan kara, campur air hingga 100ml
1. Siapkan 3 bh cabe keriting, iris serong
1. Gunakan 1 btg serai, geprek
1. Siapkan 3 daun salam
1. Ambil 3 daun jeruk, buang tulang
1. Siapkan 1 ruas jahe
1. Ambil 1 ruas lengkuas
1. Siapkan 1/8 bj pala
1. Ambil 1/4 sdt jintan
1. Sediakan 1/2 sdt ketumbar bubuk
1. Siapkan 600 ml air minum
1. Ambil  Minyak unt menumis
1. Sediakan 1 sdt garam batu himalayan
1. Gunakan secukupnya Lada
1. Ambil  Bawang goreng &amp; telur rebus sbg pelengkap
1. Ambil  Bahan halus :
1. Sediakan 12 siung bawang merah
1. Gunakan 6 siung bawang putih
1. Siapkan 5 bh kemiri
1. Gunakan 1 ruas kunyit




<!--inarticleads2-->

##### Langkah-langkah membuat Opor Ayam:

1. Tumis semua bahan kecuali santan.
1. Masukkan ayam, aduk rata. Tutup sbntr wajan. Biarkan bumbu meresap.
1. Beri air, didihkan dan masak hingga ayam empuk.
1. Beri garam. Koreksi rasa, matikan api. Masukkan santan &amp; aduk rata.
1. Angkat ayam, saring kuah agar ampas bumbu tdk ikt. Sajikan dgn bawang goreng &amp; telur rebus.




Ternyata resep opor ayam yang nikamt sederhana ini gampang sekali ya! Anda Semua mampu membuatnya. Resep opor ayam Sesuai sekali untuk kamu yang baru mau belajar memasak maupun bagi kamu yang telah lihai dalam memasak.

Tertarik untuk mulai mencoba buat resep opor ayam lezat sederhana ini? Kalau kalian tertarik, mending kamu segera siapin peralatan dan bahannya, maka buat deh Resep opor ayam yang nikmat dan tidak rumit ini. Sangat taidak sulit kan. 

Jadi, daripada kamu diam saja, yuk langsung aja bikin resep opor ayam ini. Pasti anda tiidak akan menyesal sudah bikin resep opor ayam mantab simple ini! Selamat mencoba dengan resep opor ayam enak tidak ribet ini di tempat tinggal masing-masing,oke!.

