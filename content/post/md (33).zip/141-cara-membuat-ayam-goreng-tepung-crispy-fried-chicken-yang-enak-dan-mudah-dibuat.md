---
description: "Cara membuat Ayam Goreng Tepung/crispy Fried Chicken yang enak dan Mudah Dibuat"
title: "Cara membuat Ayam Goreng Tepung/crispy Fried Chicken yang enak dan Mudah Dibuat"
slug: 141-cara-membuat-ayam-goreng-tepung-crispy-fried-chicken-yang-enak-dan-mudah-dibuat
date: 2021-03-22T08:45:50.760Z
image: https://img-global.cpcdn.com/recipes/16f6bcbaf5e08219/680x482cq70/ayam-goreng-tepungcrispy-fried-chicken-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/16f6bcbaf5e08219/680x482cq70/ayam-goreng-tepungcrispy-fried-chicken-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/16f6bcbaf5e08219/680x482cq70/ayam-goreng-tepungcrispy-fried-chicken-foto-resep-utama.jpg
author: Mabel Tyler
ratingvalue: 3.1
reviewcount: 4
recipeingredient:
- "1 ekor Ayam boiler potongpotong"
- "7 siung Bawang putih"
- "1/2 sdt Merica bubuk"
- " me 1sdt"
- "1 bks Kaldu bubuk"
- " me 1sdt kaldu jamur"
- "Secukupnya Garam me 1 sdt"
- "1 btr telur"
- " Bahan pelapis "
- "5 sdk sayur Tepung terigu"
- "  250gr"
- "1 sdk sayur Tepung maizena"
- "  50gr"
recipeinstructions:
- "Siapkan bahan ayam marinase (kecuali telur). Haluskan bawang putih."
- "Aduk rata ayam, bawang putih, merica, kaldu bubuk dan garam (me sambil di remas2 biar bumbu meresap). Simpan dalam kulkas beberapa jam (semalaman). (me: semalaman)"
- "Dalam wadah terpisah. Campur tepung terigu dan maizena aduk rata (tidak perlu dikasih garam). Karenan nanti tepung tetap berasa asin saat dimakan"
- "Keluarkan ayam dari kulkas. Masukkan 1 butir telur ayam, aduk rata"
- "Gulingkan potongan ayam dalam tepung, sambil diremas-remas dan dicubit-cubit agar nanti keriting"
- "Pukul-pukulkan ayam yang sudah dibalur tepung pada dinding wadah tepung, untuk mendapatkan hasil lebih keriting. Lakukan langkah 5 dan 6 pada semua potongan ayam. Ayam siap digoreng"
- "Goreng ayam dalam minyak panas hingga kuning kecoklatan (me dengan api sedang cenderung kecil agar matang bagian dalamnya)"
- "Ayam goreng krispi siap disantap 😍"
categories:
- Resep
tags:
- ayam
- goreng
- tepungcrispy

katakunci: ayam goreng tepungcrispy 
nutrition: 148 calories
recipecuisine: Indonesian
preptime: "PT39M"
cooktime: "PT31M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Goreng Tepung/crispy Fried Chicken](https://img-global.cpcdn.com/recipes/16f6bcbaf5e08219/680x482cq70/ayam-goreng-tepungcrispy-fried-chicken-foto-resep-utama.jpg)

Andai anda seorang ibu, menyediakan hidangan nikmat bagi keluarga tercinta merupakan suatu hal yang mengasyikan untuk kamu sendiri. Kewajiban seorang istri Tidak cuma menjaga rumah saja, tetapi kamu pun wajib memastikan kebutuhan gizi tercukupi dan juga masakan yang dimakan anak-anak harus mantab.

Di era  sekarang, kalian sebenarnya dapat membeli masakan instan meski tanpa harus susah membuatnya lebih dulu. Tetapi banyak juga lho orang yang selalu mau menyajikan yang terlezat untuk keluarganya. Pasalnya, memasak sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan makanan tersebut sesuai kesukaan keluarga tercinta. 



Mungkinkah kamu seorang penggemar ayam goreng tepung/crispy fried chicken?. Asal kamu tahu, ayam goreng tepung/crispy fried chicken merupakan hidangan khas di Indonesia yang sekarang digemari oleh banyak orang di hampir setiap daerah di Nusantara. Kita bisa memasak ayam goreng tepung/crispy fried chicken hasil sendiri di rumahmu dan boleh dijadikan camilan favoritmu di akhir pekan.

Kamu tak perlu bingung untuk menyantap ayam goreng tepung/crispy fried chicken, lantaran ayam goreng tepung/crispy fried chicken sangat mudah untuk dicari dan juga anda pun boleh memasaknya sendiri di rumah. ayam goreng tepung/crispy fried chicken boleh dibuat lewat berbagai cara. Kini pun sudah banyak banget resep kekinian yang menjadikan ayam goreng tepung/crispy fried chicken semakin lebih mantap.

Resep ayam goreng tepung/crispy fried chicken juga mudah dibuat, lho. Kamu tidak usah repot-repot untuk memesan ayam goreng tepung/crispy fried chicken, karena Anda mampu membuatnya di rumah sendiri. Bagi Kita yang akan menghidangkannya, berikut ini cara untuk menyajikan ayam goreng tepung/crispy fried chicken yang nikamat yang mampu Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Ayam Goreng Tepung/crispy Fried Chicken:

1. Sediakan 1 ekor Ayam boiler, potong-potong
1. Siapkan 7 siung Bawang putih
1. Gunakan 1/2 sdt Merica bubuk
1. Siapkan  (me 1sdt)
1. Gunakan 1 bks Kaldu bubuk
1. Gunakan  (me, 1sdt kaldu jamur)
1. Gunakan Secukupnya Garam (me 1 sdt)
1. Gunakan 1 btr telur
1. Siapkan  Bahan pelapis :
1. Gunakan 5 sdk sayur Tepung terigu
1. Sediakan  (+/- 250gr)
1. Ambil 1 sdk sayur Tepung maizena
1. Sediakan  (+/- 50gr)




<!--inarticleads2-->

##### Cara menyiapkan Ayam Goreng Tepung/crispy Fried Chicken:

1. Siapkan bahan ayam marinase (kecuali telur). Haluskan bawang putih.
1. Aduk rata ayam, bawang putih, merica, kaldu bubuk dan garam (me sambil di remas2 biar bumbu meresap). Simpan dalam kulkas beberapa jam (semalaman). (me: semalaman)
1. Dalam wadah terpisah. Campur tepung terigu dan maizena aduk rata (tidak perlu dikasih garam). Karenan nanti tepung tetap berasa asin saat dimakan
1. Keluarkan ayam dari kulkas. Masukkan 1 butir telur ayam, aduk rata
1. Gulingkan potongan ayam dalam tepung, sambil diremas-remas dan dicubit-cubit agar nanti keriting
1. Pukul-pukulkan ayam yang sudah dibalur tepung pada dinding wadah tepung, untuk mendapatkan hasil lebih keriting. Lakukan langkah 5 dan 6 pada semua potongan ayam. Ayam siap digoreng
1. Goreng ayam dalam minyak panas hingga kuning kecoklatan (me dengan api sedang cenderung kecil agar matang bagian dalamnya)
1. Ayam goreng krispi siap disantap 😍




Ternyata resep ayam goreng tepung/crispy fried chicken yang enak sederhana ini mudah banget ya! Kalian semua dapat menghidangkannya. Cara Membuat ayam goreng tepung/crispy fried chicken Sangat cocok sekali buat kita yang baru akan belajar memasak maupun untuk kalian yang sudah hebat memasak.

Apakah kamu mau mencoba membuat resep ayam goreng tepung/crispy fried chicken lezat simple ini? Kalau anda tertarik, ayo kalian segera siapin alat-alat dan bahan-bahannya, maka bikin deh Resep ayam goreng tepung/crispy fried chicken yang enak dan sederhana ini. Sangat gampang kan. 

Jadi, daripada kalian berfikir lama-lama, yuk kita langsung buat resep ayam goreng tepung/crispy fried chicken ini. Pasti kalian tak akan nyesel membuat resep ayam goreng tepung/crispy fried chicken nikmat tidak rumit ini! Selamat berkreasi dengan resep ayam goreng tepung/crispy fried chicken mantab simple ini di tempat tinggal sendiri,ya!.

