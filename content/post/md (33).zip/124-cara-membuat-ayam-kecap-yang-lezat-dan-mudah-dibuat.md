---
description: "Cara membuat Ayam Kecap yang lezat dan Mudah Dibuat"
title: "Cara membuat Ayam Kecap yang lezat dan Mudah Dibuat"
slug: 124-cara-membuat-ayam-kecap-yang-lezat-dan-mudah-dibuat
date: 2021-03-25T03:32:38.869Z
image: https://img-global.cpcdn.com/recipes/a98ab22873117a0d/680x482cq70/ayam-kecap-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a98ab22873117a0d/680x482cq70/ayam-kecap-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a98ab22873117a0d/680x482cq70/ayam-kecap-foto-resep-utama.jpg
author: Randy Murphy
ratingvalue: 3.8
reviewcount: 15
recipeingredient:
- "350 gr ayam paha atas dipotong sesuai selera"
- "1 buah bawang bombay dipotong melingkar"
- " Bumbu Marinasi"
- "1 sdm saus tiram"
- "1 sdm saus tomat"
- "Secukupnya garam"
- "Secukupnya kecap manis"
- "Secukupnya lada"
- "Secukupnya jahe bubuk"
- "5 buah bawang putih dicincang"
recipeinstructions:
- "Marinasi ayam yang sudah dipotong dengan bumbu marinasi selama minimal 30 menit. Kalau saya, saya marinasi semalaman didalam kulkas."
- "Panaskan teflon dan masukkan ayam tanpa minyak ya moms, karena nanti ayamnya akan keluar minyaknya sendiri."
- "Untuk awal jangan diaduk dulu ya moms. Ayamnya dibolak balik saja sampai ada yang tampak dibakar."
- "Jika sudah benar2 berwarna coklat, masukkan bawang bombay. Aduk sebentar."
- "Angkat dan sajikan. Enak lho moms, ini pantas dicoba 👍"
categories:
- Resep
tags:
- ayam
- kecap

katakunci: ayam kecap 
nutrition: 264 calories
recipecuisine: Indonesian
preptime: "PT30M"
cooktime: "PT46M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Kecap](https://img-global.cpcdn.com/recipes/a98ab22873117a0d/680x482cq70/ayam-kecap-foto-resep-utama.jpg)

Selaku seorang orang tua, menyuguhkan hidangan enak untuk keluarga adalah hal yang menyenangkan untuk kamu sendiri. Tugas seorang ibu bukan sekedar mengatur rumah saja, tapi anda juga harus menyediakan kebutuhan gizi tercukupi dan juga masakan yang dimakan anak-anak harus lezat.

Di zaman  sekarang, kalian sebenarnya mampu membeli olahan yang sudah jadi walaupun tidak harus repot memasaknya dahulu. Tetapi banyak juga orang yang memang mau menyajikan yang terlezat bagi orang yang dicintainya. Karena, menyajikan masakan yang diolah sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan makanan tersebut berdasarkan kesukaan keluarga tercinta. 



Apakah anda adalah seorang penikmat ayam kecap?. Tahukah kamu, ayam kecap adalah makanan khas di Indonesia yang saat ini disukai oleh banyak orang di berbagai tempat di Nusantara. Kamu dapat menyajikan ayam kecap sendiri di rumah dan dapat dijadikan makanan kesenanganmu di hari libur.

Anda tak perlu bingung untuk memakan ayam kecap, karena ayam kecap sangat mudah untuk ditemukan dan kita pun bisa membuatnya sendiri di rumah. ayam kecap boleh dibuat memalui berbagai cara. Sekarang telah banyak banget cara kekinian yang membuat ayam kecap semakin lezat.

Resep ayam kecap juga mudah dibuat, lho. Kita jangan repot-repot untuk memesan ayam kecap, lantaran Kita dapat menyajikan sendiri di rumah. Bagi Kita yang akan mencobanya, di bawah ini adalah cara menyajikan ayam kecap yang nikamat yang dapat Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Ayam Kecap:

1. Siapkan 350 gr ayam paha atas dipotong sesuai selera
1. Siapkan 1 buah bawang bombay dipotong melingkar
1. Siapkan  Bumbu Marinasi
1. Siapkan 1 sdm saus tiram
1. Siapkan 1 sdm saus tomat
1. Ambil Secukupnya garam
1. Gunakan Secukupnya kecap manis
1. Ambil Secukupnya lada
1. Gunakan Secukupnya jahe bubuk
1. Ambil 5 buah bawang putih dicincang




<!--inarticleads2-->

##### Cara membuat Ayam Kecap:

1. Marinasi ayam yang sudah dipotong dengan bumbu marinasi selama minimal 30 menit. Kalau saya, saya marinasi semalaman didalam kulkas.
1. Panaskan teflon dan masukkan ayam tanpa minyak ya moms, karena nanti ayamnya akan keluar minyaknya sendiri.
1. Untuk awal jangan diaduk dulu ya moms. Ayamnya dibolak balik saja sampai ada yang tampak dibakar.
1. Jika sudah benar2 berwarna coklat, masukkan bawang bombay. Aduk sebentar.
1. Angkat dan sajikan. Enak lho moms, ini pantas dicoba 👍




Wah ternyata cara buat ayam kecap yang nikamt tidak ribet ini gampang banget ya! Anda Semua dapat memasaknya. Resep ayam kecap Sangat cocok banget untuk kalian yang sedang belajar memasak maupun untuk kamu yang sudah lihai dalam memasak.

Tertarik untuk mulai mencoba bikin resep ayam kecap nikmat simple ini? Kalau kamu mau, yuk kita segera siapin alat dan bahan-bahannya, kemudian buat deh Resep ayam kecap yang enak dan sederhana ini. Sungguh gampang kan. 

Jadi, ketimbang anda berfikir lama-lama, maka langsung aja bikin resep ayam kecap ini. Pasti kamu tak akan nyesel sudah membuat resep ayam kecap enak sederhana ini! Selamat mencoba dengan resep ayam kecap lezat sederhana ini di tempat tinggal kalian sendiri,oke!.

