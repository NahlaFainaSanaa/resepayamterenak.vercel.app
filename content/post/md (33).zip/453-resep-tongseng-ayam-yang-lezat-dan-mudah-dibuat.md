---
description: "Resep Tongseng Ayam yang lezat dan Mudah Dibuat"
title: "Resep Tongseng Ayam yang lezat dan Mudah Dibuat"
slug: 453-resep-tongseng-ayam-yang-lezat-dan-mudah-dibuat
date: 2021-02-06T20:48:31.405Z
image: https://img-global.cpcdn.com/recipes/ceff6e9e10295a7c/680x482cq70/tongseng-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ceff6e9e10295a7c/680x482cq70/tongseng-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ceff6e9e10295a7c/680x482cq70/tongseng-ayam-foto-resep-utama.jpg
author: Lottie Dean
ratingvalue: 3.4
reviewcount: 15
recipeingredient:
- "potong dadu Dada ayam"
- "potong dadu Tomat"
- " Kol potong kecil atau sesuai selera"
- "secukupnya Air"
- " Garam"
- " Gula"
- " Merica"
- "2 lembar daun salam"
- "1 buah sereh geprek"
- "2 buah Cengkeh"
- " Kayu manis"
- "1 sdt Pala bubuk"
- "2 sdm santansusu cair"
- " Rawit"
- " Bumbu halus"
- "6 siung bawang merah"
- "3 siung bawang putih"
- "1 sdt ketumbar"
- "1 sdt jinten"
- "3 buah kemiri"
- "2 cm jahe"
recipeinstructions:
- "Tumis cengkeh pala bubuk dan kayu manis sebentar lalu masukan bumbu halus dan salam sereh masak sampai matang dan tidak ada airnya"
- "Lalu setelah bumbu matang dan berubah warna menjadi coklat masukan ayam yang telah dipotong dadu.  Tumis sampai stgh matang sampai bumbu melumuri ayamnya."
- "Setelah ayam stgh matang dan bumbu sudah melumuri dagingnya beri kecap, garam, gula, merica, penyedap rasa ayam, kaldu jamur. (Optional sesuai selera)   Saya beri sedikit bubuk kari biar lebih sedap sekitar 1/4 sdt  Kemudian aduk sampai matang."
- "Setelah ayam matang beri air secukupnya dan juga santan. Krn santan saya habis saya beri susu.  Beri sekitar 2 sdm"
- "Terakhir beri potongan tomat dan potongan kol lalu matikan api.   Saya tambahkn rawit krn biar bisa ada rasa pedas jika suka pedas"
- "Tongseng ayam siap dihidangkan"
categories:
- Resep
tags:
- tongseng
- ayam

katakunci: tongseng ayam 
nutrition: 163 calories
recipecuisine: Indonesian
preptime: "PT32M"
cooktime: "PT44M"
recipeyield: "4"
recipecategory: Dessert

---


![Tongseng Ayam](https://img-global.cpcdn.com/recipes/ceff6e9e10295a7c/680x482cq70/tongseng-ayam-foto-resep-utama.jpg)

Andai kalian seorang wanita, menyediakan olahan nikmat pada keluarga tercinta merupakan hal yang menyenangkan bagi anda sendiri. Tanggung jawab seorang  wanita bukan hanya mengatur rumah saja, namun anda juga wajib menyediakan kebutuhan gizi tercukupi dan olahan yang disantap keluarga tercinta harus sedap.

Di masa  sekarang, kalian memang dapat membeli santapan yang sudah jadi walaupun tanpa harus ribet mengolahnya dulu. Namun banyak juga mereka yang memang ingin menyajikan yang terlezat untuk orang tercintanya. Pasalnya, memasak yang diolah sendiri akan jauh lebih higienis dan bisa menyesuaikan hidangan tersebut sesuai selera famili. 



Mungkinkah anda adalah seorang penyuka tongseng ayam?. Tahukah kamu, tongseng ayam merupakan hidangan khas di Nusantara yang sekarang digemari oleh kebanyakan orang dari berbagai wilayah di Indonesia. Anda dapat membuat tongseng ayam kreasi sendiri di rumahmu dan boleh dijadikan hidangan kesukaanmu di akhir pekan.

Kamu tidak perlu bingung jika kamu ingin menyantap tongseng ayam, karena tongseng ayam tidak sukar untuk ditemukan dan anda pun bisa menghidangkannya sendiri di tempatmu. tongseng ayam boleh diolah lewat beraneka cara. Saat ini ada banyak resep modern yang menjadikan tongseng ayam lebih mantap.

Resep tongseng ayam pun sangat gampang dibikin, lho. Anda tidak usah repot-repot untuk memesan tongseng ayam, tetapi Kalian dapat menyajikan ditempatmu. Bagi Kita yang mau membuatnya, berikut cara untuk membuat tongseng ayam yang enak yang bisa Kalian hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Tongseng Ayam:

1. Sediakan potong dadu Dada ayam
1. Ambil potong dadu Tomat
1. Ambil  Kol potong kecil atau sesuai selera
1. Siapkan secukupnya Air
1. Ambil  Garam
1. Ambil  Gula
1. Ambil  Merica
1. Siapkan 2 lembar daun salam
1. Sediakan 1 buah sereh geprek
1. Sediakan 2 buah Cengkeh
1. Siapkan  Kayu manis
1. Gunakan 1 sdt Pala bubuk
1. Ambil 2 sdm santan/susu cair
1. Ambil  Rawit
1. Gunakan  Bumbu halus
1. Gunakan 6 siung bawang merah
1. Ambil 3 siung bawang putih
1. Sediakan 1 sdt ketumbar
1. Sediakan 1 sdt jinten
1. Sediakan 3 buah kemiri
1. Siapkan 2 cm jahe




<!--inarticleads2-->

##### Cara membuat Tongseng Ayam:

1. Tumis cengkeh pala bubuk dan kayu manis sebentar lalu masukan bumbu halus dan salam sereh masak sampai matang dan tidak ada airnya
1. Lalu setelah bumbu matang dan berubah warna menjadi coklat masukan ayam yang telah dipotong dadu.  - Tumis sampai stgh matang sampai bumbu melumuri ayamnya.
1. Setelah ayam stgh matang dan bumbu sudah melumuri dagingnya beri kecap, garam, gula, merica, penyedap rasa ayam, kaldu jamur. (Optional sesuai selera)  -  - Saya beri sedikit bubuk kari biar lebih sedap sekitar 1/4 sdt -  - Kemudian aduk sampai matang.
1. Setelah ayam matang beri air secukupnya dan juga santan. Krn santan saya habis saya beri susu.  - Beri sekitar 2 sdm
1. Terakhir beri potongan tomat dan potongan kol lalu matikan api.  -  - Saya tambahkn rawit krn biar bisa ada rasa pedas jika suka pedas
1. Tongseng ayam siap dihidangkan




Ternyata resep tongseng ayam yang nikamt sederhana ini mudah banget ya! Kita semua mampu memasaknya. Cara buat tongseng ayam Sangat cocok sekali buat anda yang baru mau belajar memasak ataupun untuk kalian yang sudah jago memasak.

Tertarik untuk mulai mencoba buat resep tongseng ayam enak tidak rumit ini? Kalau anda tertarik, ayo kamu segera buruan siapin alat dan bahan-bahannya, kemudian buat deh Resep tongseng ayam yang enak dan tidak rumit ini. Sangat taidak sulit kan. 

Maka dari itu, daripada kamu berfikir lama-lama, ayo langsung aja sajikan resep tongseng ayam ini. Dijamin kalian tak akan menyesal sudah membuat resep tongseng ayam enak tidak rumit ini! Selamat mencoba dengan resep tongseng ayam lezat sederhana ini di rumah sendiri,oke!.

