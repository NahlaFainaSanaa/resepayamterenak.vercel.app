---
description: "Bahan-bahan Ayam kungpao yang enak dan Mudah Dibuat"
title: "Bahan-bahan Ayam kungpao yang enak dan Mudah Dibuat"
slug: 340-bahan-bahan-ayam-kungpao-yang-enak-dan-mudah-dibuat
date: 2021-04-30T03:00:13.833Z
image: https://img-global.cpcdn.com/recipes/20ba0cbab4826774/680x482cq70/ayam-kungpao-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/20ba0cbab4826774/680x482cq70/ayam-kungpao-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/20ba0cbab4826774/680x482cq70/ayam-kungpao-foto-resep-utama.jpg
author: Albert Davis
ratingvalue: 4.2
reviewcount: 14
recipeingredient:
- "3 fillet paha ayam potong kotak"
- "1 bawang bombay"
- "1 paprika merah"
- "3 butir bawang putih"
- "1 sdm saos tomat"
- "1 sdm saos tiram"
- "2 sdm kecap manis"
- "1 sdt gula"
- "1 batang daun bawang"
- "1 sdt minyak wijen"
- "Secukupnya garam lada kaldu jamur"
- "Sedikit air"
recipeinstructions:
- "Goreng ayam yang sudah dipotong hingga matang lalu angkat dan tiriskan"
- "Tumis bawang putih dan bawang bombay.. setelah harum masukkan paprika.. aduk2 sebentar"
- "Masukkan ayam yang telah digoreng, lalu masukkan saos tomat, kecap, saos tiram, gula, garam, lada, kaldu dan air."
- "Koreksi rasa.. masukkan daun bawang dan minyak wijen.. Angkat, dan sajikan."
categories:
- Resep
tags:
- ayam
- kungpao

katakunci: ayam kungpao 
nutrition: 203 calories
recipecuisine: Indonesian
preptime: "PT36M"
cooktime: "PT33M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam kungpao](https://img-global.cpcdn.com/recipes/20ba0cbab4826774/680x482cq70/ayam-kungpao-foto-resep-utama.jpg)

Jika kamu seorang yang hobi masak, menyajikan olahan mantab untuk keluarga tercinta adalah hal yang memuaskan bagi anda sendiri. Kewajiban seorang ibu Tidak saja mengatur rumah saja, namun anda pun harus memastikan keperluan gizi tercukupi dan juga olahan yang dimakan anak-anak mesti menggugah selera.

Di waktu  sekarang, kalian memang dapat mengorder olahan instan walaupun tanpa harus susah mengolahnya terlebih dahulu. Tapi banyak juga lho orang yang memang ingin menghidangkan yang terenak bagi orang tercintanya. Pasalnya, menyajikan masakan yang dibuat sendiri jauh lebih higienis dan kita juga bisa menyesuaikan makanan tersebut berdasarkan kesukaan keluarga. 



Apakah anda salah satu penikmat ayam kungpao?. Asal kamu tahu, ayam kungpao adalah hidangan khas di Indonesia yang kini disukai oleh kebanyakan orang di hampir setiap daerah di Nusantara. Kalian bisa menghidangkan ayam kungpao sendiri di rumah dan pasti jadi makanan favorit di hari libur.

Kalian tidak perlu bingung jika kamu ingin menyantap ayam kungpao, karena ayam kungpao gampang untuk didapatkan dan juga kita pun dapat membuatnya sendiri di tempatmu. ayam kungpao bisa dibuat dengan berbagai cara. Kini pun sudah banyak sekali cara kekinian yang membuat ayam kungpao semakin lebih enak.

Resep ayam kungpao juga gampang dibuat, lho. Kamu tidak perlu capek-capek untuk memesan ayam kungpao, sebab Kita dapat menyiapkan ditempatmu. Untuk Anda yang ingin mencobanya, di bawah ini adalah cara membuat ayam kungpao yang nikamat yang bisa Kalian hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Ayam kungpao:

1. Ambil 3 fillet paha ayam potong kotak
1. Ambil 1 bawang bombay
1. Ambil 1 paprika merah
1. Gunakan 3 butir bawang putih
1. Sediakan 1 sdm saos tomat
1. Sediakan 1 sdm saos tiram
1. Siapkan 2 sdm kecap manis
1. Ambil 1 sdt gula
1. Gunakan 1 batang daun bawang
1. Sediakan 1 sdt minyak wijen
1. Ambil Secukupnya garam, lada, kaldu jamur
1. Siapkan Sedikit air




<!--inarticleads2-->

##### Cara membuat Ayam kungpao:

1. Goreng ayam yang sudah dipotong hingga matang lalu angkat dan tiriskan
1. Tumis bawang putih dan bawang bombay.. setelah harum masukkan paprika.. aduk2 sebentar
1. Masukkan ayam yang telah digoreng, lalu masukkan saos tomat, kecap, saos tiram, gula, garam, lada, kaldu dan air.
1. Koreksi rasa.. masukkan daun bawang dan minyak wijen.. Angkat, dan sajikan.




Ternyata cara buat ayam kungpao yang lezat tidak rumit ini mudah sekali ya! Kita semua dapat membuatnya. Resep ayam kungpao Cocok sekali untuk anda yang baru belajar memasak maupun bagi kamu yang sudah ahli dalam memasak.

Apakah kamu mau mulai mencoba membuat resep ayam kungpao enak tidak rumit ini? Kalau anda ingin, yuk kita segera siapin alat dan bahan-bahannya, maka bikin deh Resep ayam kungpao yang nikmat dan sederhana ini. Sangat taidak sulit kan. 

Maka dari itu, daripada kalian berlama-lama, maka kita langsung hidangkan resep ayam kungpao ini. Pasti anda tiidak akan menyesal sudah membuat resep ayam kungpao enak tidak ribet ini! Selamat mencoba dengan resep ayam kungpao mantab tidak rumit ini di tempat tinggal kalian sendiri,oke!.

