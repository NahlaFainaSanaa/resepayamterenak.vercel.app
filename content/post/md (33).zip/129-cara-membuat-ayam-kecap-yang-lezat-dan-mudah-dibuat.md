---
description: "Cara membuat Ayam Kecap yang lezat dan Mudah Dibuat"
title: "Cara membuat Ayam Kecap yang lezat dan Mudah Dibuat"
slug: 129-cara-membuat-ayam-kecap-yang-lezat-dan-mudah-dibuat
date: 2021-05-25T09:00:27.531Z
image: https://img-global.cpcdn.com/recipes/bd44e3289f836cba/680x482cq70/ayam-kecap-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/bd44e3289f836cba/680x482cq70/ayam-kecap-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/bd44e3289f836cba/680x482cq70/ayam-kecap-foto-resep-utama.jpg
author: Cecilia Webb
ratingvalue: 4.2
reviewcount: 3
recipeingredient:
- "1 kg ayam potong sesuai selera lalu rebus sebentar"
- "5 butir bawang merah haluskan"
- "4 siung bawang putih haluskan"
- "5 lembar daun salam"
- "1 ruas lengkuas geprek"
- "Secukupnya kecap manis kecap asin dan saus tiram"
- "Secukupnya gula merahpasir garam kaldu ayam dan lada bubuk"
- "Secukupnya air"
- "Secukupnya minyakmargarin untuk menumis"
recipeinstructions:
- "Tumis duo bawang yang di haluskan hingga harum, lalu tambahkan air kemudian masukan daun salam dan lengkuas yang telah di geprek. Tunggu hingga air mendidih."
- "Lalu bumbui dengan gula, garam, kaldu ayam, lada bubuk, kecap manis, kecap asin, dan saus tiram. Aduk hingga semua bahan tercampur rata dan mengental. Koreksi rasa."
- "Kemudian masukan potongan ayam yang sudah di rebus sebentar. Aduk-aduk hingga air sedikit surut dan bumbu meresap pada ayam."
- "Kemudian taburi dengan bawang goreng. Sajikan."
categories:
- Resep
tags:
- ayam
- kecap

katakunci: ayam kecap 
nutrition: 203 calories
recipecuisine: Indonesian
preptime: "PT16M"
cooktime: "PT41M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam Kecap](https://img-global.cpcdn.com/recipes/bd44e3289f836cba/680x482cq70/ayam-kecap-foto-resep-utama.jpg)

Jika anda seorang ibu, mempersiapkan masakan menggugah selera pada keluarga merupakan suatu hal yang sangat menyenangkan bagi kamu sendiri. Tugas seorang istri bukan sekadar menangani rumah saja, tetapi anda juga harus menyediakan keperluan nutrisi terpenuhi dan panganan yang disantap anak-anak wajib enak.

Di zaman  sekarang, kamu sebenarnya dapat memesan santapan jadi walaupun tidak harus ribet memasaknya dahulu. Namun banyak juga mereka yang selalu ingin memberikan yang terbaik untuk keluarganya. Lantaran, menghidangkan masakan sendiri akan jauh lebih higienis dan bisa menyesuaikan sesuai dengan masakan kesukaan keluarga tercinta. 



Mungkinkah anda salah satu penyuka ayam kecap?. Tahukah kamu, ayam kecap merupakan sajian khas di Nusantara yang kini disukai oleh kebanyakan orang dari hampir setiap daerah di Indonesia. Kamu bisa menghidangkan ayam kecap sendiri di rumah dan boleh jadi hidangan favorit di akhir pekan.

Anda tidak usah bingung jika kamu ingin memakan ayam kecap, lantaran ayam kecap sangat mudah untuk didapatkan dan juga anda pun boleh menghidangkannya sendiri di rumah. ayam kecap dapat diolah dengan berbagai cara. Saat ini telah banyak banget cara modern yang membuat ayam kecap semakin lebih lezat.

Resep ayam kecap pun sangat gampang dibuat, lho. Kalian jangan repot-repot untuk memesan ayam kecap, sebab Kamu dapat menyajikan di rumah sendiri. Untuk Kamu yang hendak membuatnya, berikut ini resep untuk menyajikan ayam kecap yang enak yang mampu Kalian coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Ayam Kecap:

1. Ambil 1 kg ayam (potong sesuai selera lalu rebus sebentar)
1. Siapkan 5 butir bawang merah (haluskan)
1. Gunakan 4 siung bawang putih (haluskan)
1. Gunakan 5 lembar daun salam
1. Sediakan 1 ruas lengkuas (geprek)
1. Ambil Secukupnya kecap manis, kecap asin, dan saus tiram
1. Siapkan Secukupnya gula merah+pasir, garam, kaldu ayam, dan lada bubuk
1. Gunakan Secukupnya air
1. Sediakan Secukupnya minyak+margarin (untuk menumis)




<!--inarticleads2-->

##### Cara membuat Ayam Kecap:

1. Tumis duo bawang yang di haluskan hingga harum, lalu tambahkan air kemudian masukan daun salam dan lengkuas yang telah di geprek. Tunggu hingga air mendidih.
1. Lalu bumbui dengan gula, garam, kaldu ayam, lada bubuk, kecap manis, kecap asin, dan saus tiram. Aduk hingga semua bahan tercampur rata dan mengental. Koreksi rasa.
1. Kemudian masukan potongan ayam yang sudah di rebus sebentar. Aduk-aduk hingga air sedikit surut dan bumbu meresap pada ayam.
1. Kemudian taburi dengan bawang goreng. Sajikan.




Ternyata cara membuat ayam kecap yang lezat tidak ribet ini mudah banget ya! Kita semua bisa memasaknya. Resep ayam kecap Sesuai banget buat kita yang baru akan belajar memasak maupun untuk kamu yang sudah ahli dalam memasak.

Apakah kamu mau mulai mencoba membuat resep ayam kecap mantab tidak rumit ini? Kalau kamu ingin, ayo kamu segera buruan menyiapkan peralatan dan bahannya, maka bikin deh Resep ayam kecap yang nikmat dan tidak rumit ini. Sangat taidak sulit kan. 

Jadi, ketimbang kalian berfikir lama-lama, hayo kita langsung saja buat resep ayam kecap ini. Dijamin anda tak akan nyesel bikin resep ayam kecap lezat simple ini! Selamat mencoba dengan resep ayam kecap nikmat tidak rumit ini di rumah sendiri,ya!.

