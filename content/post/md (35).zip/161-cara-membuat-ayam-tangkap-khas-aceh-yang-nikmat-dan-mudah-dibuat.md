---
description: "Cara membuat Ayam Tangkap Khas Aceh yang nikmat dan Mudah Dibuat"
title: "Cara membuat Ayam Tangkap Khas Aceh yang nikmat dan Mudah Dibuat"
slug: 161-cara-membuat-ayam-tangkap-khas-aceh-yang-nikmat-dan-mudah-dibuat
date: 2021-05-15T23:21:24.035Z
image: https://img-global.cpcdn.com/recipes/f29ad02fbc0b21e8/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f29ad02fbc0b21e8/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f29ad02fbc0b21e8/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg
author: Randy Graham
ratingvalue: 4.3
reviewcount: 13
recipeingredient:
- "1 ekor ayam pejantan"
- "500 ml air kelapa"
- "1 tangkai daun kari"
- "1 daun pandan simpulkan"
- "1 ruas lengkuas"
- "2 sdt garam"
- " BUMBU HALUS "
- "1 sdm ketumbar"
- "1 ruas kunyit"
- "3 bawang putih"
- "1 sdt lada"
- " BAHAN GORENG "
- "5 cabe hijau belah"
- "1 lembar daun pandan iris"
- "2 lembar daun salam iris"
- "2 tangkai daun kari"
- "4 lembar daun jeruk sobek"
- "2 tangkai daun kari"
recipeinstructions:
- "Potong- potong ayam lalu lumuri dengan bumbu, daun pandan, lengkuas, lalu diamkan 30 menit."
- "Tuang air kelapa di wajan, tambahkan ayam, lalu garam dan ungkep sampai asat."
- "Jika sudah asat, angkat dan tiriskan."
- "Goreng ayam sampai setengah matang."
- "Masukan dedaunan lalu goreng sampai kering. Ini wangi banget loh 🥰"
- "Kalau sudah seperti ini angkat dan tiriskan yah."
- "Ayam Tangkap siap untuk disajikan."
categories:
- Resep
tags:
- ayam
- tangkap
- khas

katakunci: ayam tangkap khas 
nutrition: 294 calories
recipecuisine: Indonesian
preptime: "PT39M"
cooktime: "PT46M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Tangkap Khas Aceh](https://img-global.cpcdn.com/recipes/f29ad02fbc0b21e8/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg)

Selaku seorang orang tua, menyuguhkan olahan mantab buat orang tercinta merupakan suatu hal yang sangat menyenangkan bagi anda sendiri. Peran seorang ibu Tidak cuman menjaga rumah saja, tapi anda juga harus memastikan kebutuhan nutrisi terpenuhi dan juga santapan yang disantap anak-anak wajib enak.

Di zaman  sekarang, anda sebenarnya bisa memesan masakan siap saji tanpa harus repot mengolahnya lebih dulu. Tapi banyak juga lho orang yang selalu mau memberikan hidangan yang terlezat bagi orang yang dicintainya. Sebab, menyajikan masakan yang dibuat sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan hidangan tersebut sesuai dengan makanan kesukaan keluarga. 



Mungkinkah anda salah satu penikmat ayam tangkap khas aceh?. Asal kamu tahu, ayam tangkap khas aceh merupakan makanan khas di Nusantara yang saat ini disenangi oleh orang-orang di berbagai daerah di Indonesia. Anda bisa menghidangkan ayam tangkap khas aceh hasil sendiri di rumah dan dapat dijadikan camilan kesukaanmu di hari liburmu.

Kamu tidak perlu bingung jika kamu ingin menyantap ayam tangkap khas aceh, sebab ayam tangkap khas aceh gampang untuk ditemukan dan kita pun bisa memasaknya sendiri di rumah. ayam tangkap khas aceh dapat dimasak memalui bermacam cara. Saat ini ada banyak resep kekinian yang menjadikan ayam tangkap khas aceh semakin lebih nikmat.

Resep ayam tangkap khas aceh pun gampang sekali untuk dibikin, lho. Anda jangan capek-capek untuk memesan ayam tangkap khas aceh, karena Kita bisa menghidangkan sendiri di rumah. Bagi Anda yang mau menyajikannya, berikut resep membuat ayam tangkap khas aceh yang nikamat yang bisa Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Ayam Tangkap Khas Aceh:

1. Sediakan 1 ekor ayam pejantan
1. Ambil 500 ml air kelapa
1. Sediakan 1 tangkai daun kari
1. Siapkan 1 daun pandan simpulkan
1. Sediakan 1 ruas lengkuas
1. Ambil 2 sdt garam
1. Siapkan  BUMBU HALUS :
1. Gunakan 1 sdm ketumbar
1. Siapkan 1 ruas kunyit
1. Siapkan 3 bawang putih
1. Ambil 1 sdt lada
1. Sediakan  BAHAN GORENG :
1. Sediakan 5 cabe hijau belah
1. Sediakan 1 lembar daun pandan iris
1. Ambil 2 lembar daun salam iris
1. Gunakan 2 tangkai daun kari
1. Gunakan 4 lembar daun jeruk sobek
1. Siapkan 2 tangkai daun kari




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam Tangkap Khas Aceh:

1. Potong- potong ayam lalu lumuri dengan bumbu, daun pandan, lengkuas, lalu diamkan 30 menit.
1. Tuang air kelapa di wajan, tambahkan ayam, lalu garam dan ungkep sampai asat.
1. Jika sudah asat, angkat dan tiriskan.
1. Goreng ayam sampai setengah matang.
1. Masukan dedaunan lalu goreng sampai kering. Ini wangi banget loh 🥰
1. Kalau sudah seperti ini angkat dan tiriskan yah.
1. Ayam Tangkap siap untuk disajikan.




Ternyata cara membuat ayam tangkap khas aceh yang nikamt tidak rumit ini mudah sekali ya! Semua orang bisa memasaknya. Cara Membuat ayam tangkap khas aceh Sesuai banget untuk kalian yang sedang belajar memasak atau juga untuk anda yang sudah jago dalam memasak.

Apakah kamu mau mencoba membikin resep ayam tangkap khas aceh mantab tidak rumit ini? Kalau kalian ingin, ayo kamu segera siapkan alat dan bahannya, maka buat deh Resep ayam tangkap khas aceh yang enak dan tidak ribet ini. Benar-benar taidak sulit kan. 

Jadi, daripada kita diam saja, maka kita langsung hidangkan resep ayam tangkap khas aceh ini. Dijamin kalian tak akan menyesal bikin resep ayam tangkap khas aceh mantab sederhana ini! Selamat mencoba dengan resep ayam tangkap khas aceh enak sederhana ini di tempat tinggal masing-masing,ya!.

