---
description: "Resep Kari Ayam Khas Aceh Sederhana dan Mudah Dibuat"
title: "Resep Kari Ayam Khas Aceh Sederhana dan Mudah Dibuat"
slug: 178-resep-kari-ayam-khas-aceh-sederhana-dan-mudah-dibuat
date: 2021-06-29T23:22:16.556Z
image: https://img-global.cpcdn.com/recipes/7271e6bf0ff6869f/680x482cq70/kari-ayam-khas-aceh-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7271e6bf0ff6869f/680x482cq70/kari-ayam-khas-aceh-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7271e6bf0ff6869f/680x482cq70/kari-ayam-khas-aceh-foto-resep-utama.jpg
author: Rhoda Warner
ratingvalue: 3.2
reviewcount: 14
recipeingredient:
- "800 gr ayamme 500 gr"
- "Secukupnya minyak goreng"
- "500 ml airskip"
- "1 bks santan kara uk kecilme santan kental 500 ml"
- "1/2 sdt garam"
- "1 sdt gula pasir"
- "1/4 sdt kaldu jamur"
- " Bumbu halus"
- "3 siung bawang putih"
- "4 butir bawang merah"
- "7 buah cabe merah"
- "1 sdt ketumbar"
- "1/2 sdt lada"
- "1/2 buah pala"
- "1/4 sdt jinten halus"
- "1/4 sdt jinten kasar"
- "4 sdm kelapa sangrai yg dihaluskan"
- " Bumbu rempah tumisan"
- "1 butir bawang merah iris"
- "1 buah cengkehbunga lawang"
- "1 buah kapulaga"
- "1 lembar daun pandan"
- "1 batang daun kari"
recipeinstructions:
- "Cuci bersih ayam ungkep dgn api sedang hingga setengah matang (ungkep bersama garam perasan air jeruk nipis lada bubuk kunyit dan ketumbar bubuk angkat sisihkan)"
- "Siapkan bumbu halus dan ayam ungkep, lumuri ayam ungkep dgn bumbu halus dan santan aduk hingga tercampur rata, diamkan sebentar agar bumbu meresap"
- "Tumis bumbu rempah hingga harum masukan ayam aduk rata masak sebentar tambahkan air"
- "Masak terus hingga bumbu meresap dan kuah menyusut dan mengeluarkan minyak nya matikan api angkat dan tata di piring saji"
categories:
- Resep
tags:
- kari
- ayam
- khas

katakunci: kari ayam khas 
nutrition: 152 calories
recipecuisine: Indonesian
preptime: "PT20M"
cooktime: "PT32M"
recipeyield: "3"
recipecategory: Dinner

---


![Kari Ayam Khas Aceh](https://img-global.cpcdn.com/recipes/7271e6bf0ff6869f/680x482cq70/kari-ayam-khas-aceh-foto-resep-utama.jpg)

Sebagai seorang istri, menyuguhkan santapan lezat buat famili merupakan hal yang membahagiakan bagi anda sendiri. Tugas seorang  wanita bukan sekedar menjaga rumah saja, tetapi kamu pun harus memastikan keperluan nutrisi terpenuhi dan santapan yang dimakan keluarga tercinta harus menggugah selera.

Di masa  saat ini, anda sebenarnya mampu memesan masakan instan tanpa harus capek memasaknya terlebih dahulu. Namun ada juga lho mereka yang selalu ingin memberikan makanan yang terenak bagi orang tercintanya. Karena, menghidangkan masakan yang diolah sendiri jauh lebih bersih dan kita juga bisa menyesuaikan sesuai dengan masakan kesukaan keluarga. 



Apakah anda seorang penggemar kari ayam khas aceh?. Tahukah kamu, kari ayam khas aceh merupakan hidangan khas di Indonesia yang kini disukai oleh orang-orang di berbagai tempat di Nusantara. Kalian dapat memasak kari ayam khas aceh kreasi sendiri di rumahmu dan pasti jadi santapan kesenanganmu di akhir pekan.

Kalian tak perlu bingung untuk mendapatkan kari ayam khas aceh, sebab kari ayam khas aceh tidak sukar untuk dicari dan kalian pun boleh mengolahnya sendiri di rumah. kari ayam khas aceh bisa diolah lewat beraneka cara. Kini sudah banyak banget cara modern yang menjadikan kari ayam khas aceh lebih enak.

Resep kari ayam khas aceh juga sangat mudah untuk dibuat, lho. Kalian jangan ribet-ribet untuk memesan kari ayam khas aceh, karena Kita dapat menyajikan sendiri di rumah. Untuk Kalian yang mau menyajikannya, dibawah ini merupakan cara untuk membuat kari ayam khas aceh yang lezat yang mampu Kamu hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Kari Ayam Khas Aceh:

1. Siapkan 800 gr ayam(me 500 gr)
1. Sediakan Secukupnya minyak goreng
1. Siapkan 500 ml air(skip)
1. Gunakan 1 bks santan kara uk kecil(me santan kental 500 ml)
1. Sediakan 1/2 sdt garam
1. Ambil 1 sdt gula pasir
1. Siapkan 1/4 sdt kaldu jamur
1. Sediakan  Bumbu halus:
1. Sediakan 3 siung bawang putih
1. Gunakan 4 butir bawang merah
1. Sediakan 7 buah cabe merah
1. Ambil 1 sdt ketumbar
1. Ambil 1/2 sdt lada
1. Sediakan 1/2 buah pala
1. Ambil 1/4 sdt jinten halus
1. Siapkan 1/4 sdt jinten kasar
1. Ambil 4 sdm kelapa sangrai yg dihaluskan
1. Sediakan  Bumbu rempah tumisan
1. Ambil 1 butir bawang merah iris
1. Siapkan 1 buah cengkeh/bunga lawang
1. Siapkan 1 buah kapulaga
1. Sediakan 1 lembar daun pandan
1. Ambil 1 batang daun kari




<!--inarticleads2-->

##### Langkah-langkah membuat Kari Ayam Khas Aceh:

1. Cuci bersih ayam ungkep dgn api sedang hingga setengah matang (ungkep bersama garam perasan air jeruk nipis lada bubuk kunyit dan ketumbar bubuk angkat sisihkan)
1. Siapkan bumbu halus dan ayam ungkep, lumuri ayam ungkep dgn bumbu halus dan santan aduk hingga tercampur rata, diamkan sebentar agar bumbu meresap
1. Tumis bumbu rempah hingga harum masukan ayam aduk rata masak sebentar tambahkan air
1. Masak terus hingga bumbu meresap dan kuah menyusut dan mengeluarkan minyak nya matikan api angkat dan tata di piring saji




Ternyata cara buat kari ayam khas aceh yang nikamt simple ini enteng banget ya! Kita semua bisa memasaknya. Cara buat kari ayam khas aceh Sesuai sekali buat kamu yang sedang belajar memasak atau juga untuk anda yang telah ahli memasak.

Apakah kamu ingin mencoba bikin resep kari ayam khas aceh nikmat tidak rumit ini? Kalau anda tertarik, yuk kita segera siapin alat-alat dan bahan-bahannya, lantas buat deh Resep kari ayam khas aceh yang lezat dan sederhana ini. Sungguh gampang kan. 

Jadi, daripada kamu berlama-lama, ayo kita langsung saja buat resep kari ayam khas aceh ini. Pasti kamu gak akan nyesel membuat resep kari ayam khas aceh enak sederhana ini! Selamat berkreasi dengan resep kari ayam khas aceh nikmat simple ini di rumah kalian masing-masing,ya!.

