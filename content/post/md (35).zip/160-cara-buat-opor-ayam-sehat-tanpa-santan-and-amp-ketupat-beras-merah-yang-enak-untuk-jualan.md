---
description: "Cara buat Opor Ayam Sehat (tanpa santan) &amp;amp; Ketupat Beras Merah yang enak Untuk Jualan"
title: "Cara buat Opor Ayam Sehat (tanpa santan) &amp;amp; Ketupat Beras Merah yang enak Untuk Jualan"
slug: 160-cara-buat-opor-ayam-sehat-tanpa-santan-and-amp-ketupat-beras-merah-yang-enak-untuk-jualan
date: 2021-06-08T17:35:29.610Z
image: https://img-global.cpcdn.com/recipes/ac34a530013f9279/680x482cq70/opor-ayam-sehat-tanpa-santan-ketupat-beras-merah-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ac34a530013f9279/680x482cq70/opor-ayam-sehat-tanpa-santan-ketupat-beras-merah-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ac34a530013f9279/680x482cq70/opor-ayam-sehat-tanpa-santan-ketupat-beras-merah-foto-resep-utama.jpg
author: Rosie Bowers
ratingvalue: 4.2
reviewcount: 3
recipeingredient:
- "1 kg ayam potong direbus 12 jam dicampur daun salam 3 lembar buang airnya  demiiii lemak jahatnya berkurang"
- " Bumbu Halus"
- "7 bawang merah"
- "5 bawang putih"
- "3 kemiri disangrai"
- "1 sdt ketumbar disangrai"
- "1 sdt jinten disangrai"
- "1 buah kunyit 5 cm an"
- " Bahan Tambahan"
- "3 lembar daun jeruk purut"
- "3 lembar daun salam"
- "1 ruas lengkuas geprak"
- "2 serai diikat lalu digeprak"
- " Fiber creme sebagai pengganti santan sesuaikan selera aja Suka kental ya banyakin"
- " Campuran lain"
- " Totole"
- "dikit Gula aren"
- " Gula tropicana"
- " Garam himayala"
- " Kecap manis"
- " Ketupat Beras Merah"
- "10 selongsong ketupat"
- " Beras merah saya pake sekitar 4 gelas direndam semalaman buang air lalu dicuci bersih Masukkan ke selongsong dan rebus 12 jam kondisi tenggelam"
recipeinstructions:
- "Opor - tumis bumbu halus sampe wangi. Masukkan lengkuas salam daunjeruk sere dan gula aren dikit. Tunggu bumbu matang. Sambil diaduk. Jangan ditinggal nonton drakor ya"
- "Masukkan ayam rebus. Aduk bersama bumbu sampai ayam terselimuti bumbu dan berubah warnanya (saya lebih suka ayam direbus dulu dan buang airnya agar lemak unggasnya yg jahat itu berkurang drastis tak masuk ke badan saya)"
- "Kalau sudah berubah warna, masukkan air sampai ayam agak tenggelam. Biarkan mendidih."
- "Setelah mendidih, masukkan gula, garam, totole, dan sedikit kecap manis. Aduk. Koreksi rasa dulu. Udah pas, masukkan fiber creme sesuai kebutuhan. Semakin banyak akan bikin kental (tapi boros woyyyy... mahal)"
- "Biarkan sampai kuah agak menyusut dan mengental. Terus koreksi rasa karena keadaan air bisa mempengaruhi rasa. Kita tahu air di tiap tempat beda2 keadaannya. Jangan bosan incip terus ya"
- "Sajikan bersama ketupat beras merah. Kalau suka bisa ditaburi bawang goreng. Saya : mete goreng. Semoga sehat selalu 🙏"
categories:
- Resep
tags:
- opor
- ayam
- sehat

katakunci: opor ayam sehat 
nutrition: 271 calories
recipecuisine: Indonesian
preptime: "PT14M"
cooktime: "PT31M"
recipeyield: "3"
recipecategory: Lunch

---


![Opor Ayam Sehat (tanpa santan) &amp; Ketupat Beras Merah](https://img-global.cpcdn.com/recipes/ac34a530013f9279/680x482cq70/opor-ayam-sehat-tanpa-santan-ketupat-beras-merah-foto-resep-utama.jpg)

Andai kalian seorang wanita, menyajikan panganan lezat buat famili adalah hal yang memuaskan untuk anda sendiri. Kewajiban seorang  wanita bukan saja menjaga rumah saja, tapi anda pun wajib memastikan keperluan gizi tercukupi dan juga olahan yang dikonsumsi keluarga tercinta harus menggugah selera.

Di era  sekarang, kalian sebenarnya dapat memesan santapan instan meski tidak harus repot mengolahnya dulu. Tapi banyak juga orang yang memang mau memberikan hidangan yang terenak bagi orang yang dicintainya. Karena, menghidangkan masakan sendiri jauh lebih bersih dan bisa menyesuaikan masakan tersebut berdasarkan makanan kesukaan orang tercinta. 



Mungkinkah anda salah satu penggemar opor ayam sehat (tanpa santan) &amp; ketupat beras merah?. Asal kamu tahu, opor ayam sehat (tanpa santan) &amp; ketupat beras merah adalah sajian khas di Indonesia yang saat ini disenangi oleh setiap orang di berbagai wilayah di Nusantara. Kita bisa memasak opor ayam sehat (tanpa santan) &amp; ketupat beras merah buatan sendiri di rumah dan boleh jadi santapan favoritmu di akhir pekan.

Kita tidak usah bingung jika kamu ingin menyantap opor ayam sehat (tanpa santan) &amp; ketupat beras merah, karena opor ayam sehat (tanpa santan) &amp; ketupat beras merah sangat mudah untuk didapatkan dan anda pun dapat membuatnya sendiri di tempatmu. opor ayam sehat (tanpa santan) &amp; ketupat beras merah dapat dibuat memalui beraneka cara. Kini pun telah banyak cara modern yang menjadikan opor ayam sehat (tanpa santan) &amp; ketupat beras merah lebih lezat.

Resep opor ayam sehat (tanpa santan) &amp; ketupat beras merah juga gampang dibikin, lho. Kalian tidak usah repot-repot untuk membeli opor ayam sehat (tanpa santan) &amp; ketupat beras merah, lantaran Kalian mampu menyiapkan sendiri di rumah. Untuk Kamu yang akan mencobanya, inilah resep menyajikan opor ayam sehat (tanpa santan) &amp; ketupat beras merah yang lezat yang bisa Kamu coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Opor Ayam Sehat (tanpa santan) &amp; Ketupat Beras Merah:

1. Ambil 1 kg ayam potong (direbus 1/2 jam dicampur daun salam 3 lembar, buang airnya) —- demiiii lemak jahatnya berkurang
1. Siapkan  Bumbu Halus
1. Ambil 7 bawang merah
1. Siapkan 5 bawang putih
1. Gunakan 3 kemiri (disangrai)
1. Sediakan 1 sdt ketumbar (disangrai)
1. Gunakan 1 sdt jinten (disangrai)
1. Ambil 1 buah kunyit 5 cm an
1. Gunakan  Bahan Tambahan
1. Gunakan 3 lembar daun jeruk purut
1. Sediakan 3 lembar daun salam
1. Sediakan 1 ruas lengkuas geprak
1. Sediakan 2 serai diikat lalu digeprak
1. Sediakan  Fiber creme (sebagai pengganti santan, sesuaikan selera aja. Suka kental ya banyakin)
1. Ambil  Campuran lain
1. Ambil  Totole
1. Gunakan dikit Gula aren
1. Gunakan  Gula tropicana
1. Sediakan  Garam himayala
1. Sediakan  Kecap manis
1. Sediakan  Ketupat Beras Merah
1. Sediakan 10 selongsong ketupat
1. Ambil  Beras merah saya pake sekitar 4 gelas, direndam semalaman, buang air lalu dicuci bersih. Masukkan ke selongsong dan rebus 1-2 jam kondisi tenggelam




<!--inarticleads2-->

##### Cara menyiapkan Opor Ayam Sehat (tanpa santan) &amp; Ketupat Beras Merah:

1. Opor - tumis bumbu halus sampe wangi. Masukkan lengkuas salam daunjeruk sere dan gula aren dikit. Tunggu bumbu matang. Sambil diaduk. Jangan ditinggal nonton drakor ya
1. Masukkan ayam rebus. Aduk bersama bumbu sampai ayam terselimuti bumbu dan berubah warnanya (saya lebih suka ayam direbus dulu dan buang airnya agar lemak unggasnya yg jahat itu berkurang drastis tak masuk ke badan saya)
1. Kalau sudah berubah warna, masukkan air sampai ayam agak tenggelam. Biarkan mendidih.
1. Setelah mendidih, masukkan gula, garam, totole, dan sedikit kecap manis. Aduk. Koreksi rasa dulu. Udah pas, masukkan fiber creme sesuai kebutuhan. Semakin banyak akan bikin kental (tapi boros woyyyy... mahal)
1. Biarkan sampai kuah agak menyusut dan mengental. Terus koreksi rasa karena keadaan air bisa mempengaruhi rasa. Kita tahu air di tiap tempat beda2 keadaannya. Jangan bosan incip terus ya
1. Sajikan bersama ketupat beras merah. Kalau suka bisa ditaburi bawang goreng. Saya : mete goreng. Semoga sehat selalu 🙏




Ternyata cara membuat opor ayam sehat (tanpa santan) &amp; ketupat beras merah yang nikamt tidak rumit ini mudah sekali ya! Anda Semua dapat mencobanya. Resep opor ayam sehat (tanpa santan) &amp; ketupat beras merah Sangat sesuai banget untuk kamu yang baru mau belajar memasak atau juga bagi kalian yang telah lihai dalam memasak.

Apakah kamu ingin mencoba buat resep opor ayam sehat (tanpa santan) &amp; ketupat beras merah mantab sederhana ini? Kalau anda ingin, mending kamu segera buruan siapkan alat dan bahan-bahannya, setelah itu buat deh Resep opor ayam sehat (tanpa santan) &amp; ketupat beras merah yang enak dan tidak ribet ini. Sungguh taidak sulit kan. 

Maka, ketimbang kamu diam saja, hayo langsung aja sajikan resep opor ayam sehat (tanpa santan) &amp; ketupat beras merah ini. Pasti kamu tiidak akan nyesel bikin resep opor ayam sehat (tanpa santan) &amp; ketupat beras merah enak tidak rumit ini! Selamat berkreasi dengan resep opor ayam sehat (tanpa santan) &amp; ketupat beras merah lezat sederhana ini di rumah masing-masing,oke!.

