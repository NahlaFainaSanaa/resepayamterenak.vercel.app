---
description: "Cara buat Ayam kfc/ kentuky simple,kriting dan kriuk nya tahan lama, yang enak dan Mudah Dibuat"
title: "Cara buat Ayam kfc/ kentuky simple,kriting dan kriuk nya tahan lama, yang enak dan Mudah Dibuat"
slug: 382-cara-buat-ayam-kfc-kentuky-simple-kriting-dan-kriuk-nya-tahan-lama-yang-enak-dan-mudah-dibuat
date: 2021-04-23T13:33:21.673Z
image: https://img-global.cpcdn.com/recipes/803ecb3a54cbb7cf/680x482cq70/ayam-kfc-kentuky-simplekriting-dan-kriuk-nya-tahan-lama-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/803ecb3a54cbb7cf/680x482cq70/ayam-kfc-kentuky-simplekriting-dan-kriuk-nya-tahan-lama-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/803ecb3a54cbb7cf/680x482cq70/ayam-kfc-kentuky-simplekriting-dan-kriuk-nya-tahan-lama-foto-resep-utama.jpg
author: Georgia Wade
ratingvalue: 4.2
reviewcount: 4
recipeingredient:
- "1/2 kg daging ayam"
- "1/2 kg gandum segi3"
- "1/2 bks tepung maizena"
- "1 bks es batu2rban"
- "1 btr telur"
- "4 bks royco ayam"
- " Bumbu"
- "4 siung BP"
- "1 siung BM"
- "secukupnya Garam"
- "secukupnya Mrica"
- "secukupnya Tumbar"
- "1ruas jari Jahe"
- "1ruas jari Kunyit"
- " Bahan lumuran tambahkn Baking soda"
recipeinstructions:
- "Langkah 1, haluskan semua bumbu tambahkn 1bks royco(aq pkk blender olhnya lg bwaan bayi tangnya semutan)"
- "Mariminasi ayam, masukan setngh es batu kdlm bumbu yg sdh dituang ke wadah ayam yg sdh dibersihkn,ksih royco 1 ½bks( biarkan dlu sembri kita siapkn bahan lumuran dan bahan Kering,"
- "Bumbu kring, campurkn tepung segitiga dan maizena tmbhkn 1bks royco, aduk2 sampai rata"
- "Bahan celupan, masukn sisa es batu kdlm baskom bri secukupy air,(jngn terllu bnyak nnti gk dingin) tmbhkn royco 1bks tambah sedikit bahan kering dan beking soda tambahkn telur yg sdh di ceplok(aduk hingga rata)"
- "Selnjutnya, ambil ayam 1 persatu yg sdh di mariminasi msukan kebhan kering(bolak balik smbil di cubit2,, (sembri panaskn minyak)"
- "Angkat lalu msukn ke adonan celupan es tunggu kurleb 1mnit, lalu angkat gulingkn ke adonan kering sambil di cubit2 biar ngbntuk kriting2,"
- "Lalu angkat goreng menggunkn minyak panas, kmudian kcilkn api(jngn terllu besar) tkut daging ngk mateng, tunggu hingga kcoklatan (jngn di bolak balik terus y, bisa rontok kriting2nya, balik ayam jika sdh kring."
- "Lalu tiriskn"
- "Selmat mencoba"
categories:
- Resep
tags:
- ayam
- kfc
- kentuky

katakunci: ayam kfc kentuky 
nutrition: 282 calories
recipecuisine: Indonesian
preptime: "PT18M"
cooktime: "PT35M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam kfc/ kentuky simple,kriting dan kriuk nya tahan lama,](https://img-global.cpcdn.com/recipes/803ecb3a54cbb7cf/680x482cq70/ayam-kfc-kentuky-simplekriting-dan-kriuk-nya-tahan-lama-foto-resep-utama.jpg)

Sebagai seorang orang tua, menyuguhkan olahan lezat kepada keluarga merupakan suatu hal yang menggembirakan bagi kita sendiri. Tugas seorang ibu Tidak sekedar menjaga rumah saja, tapi anda juga harus menyediakan kebutuhan nutrisi tercukupi dan juga hidangan yang disantap keluarga tercinta mesti menggugah selera.

Di zaman  saat ini, kamu memang mampu membeli hidangan praktis tidak harus capek memasaknya dahulu. Tetapi banyak juga mereka yang memang mau memberikan makanan yang terlezat bagi orang yang dicintainya. Pasalnya, memasak sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan masakan tersebut sesuai makanan kesukaan keluarga tercinta. 



Apakah anda adalah salah satu penggemar ayam kfc/ kentuky simple,kriting dan kriuk nya tahan lama,?. Tahukah kamu, ayam kfc/ kentuky simple,kriting dan kriuk nya tahan lama, adalah makanan khas di Nusantara yang sekarang disenangi oleh kebanyakan orang di hampir setiap daerah di Indonesia. Kalian dapat menghidangkan ayam kfc/ kentuky simple,kriting dan kriuk nya tahan lama, buatan sendiri di rumah dan pasti jadi makanan kegemaranmu di akhir pekanmu.

Kamu tidak usah bingung jika kamu ingin mendapatkan ayam kfc/ kentuky simple,kriting dan kriuk nya tahan lama,, lantaran ayam kfc/ kentuky simple,kriting dan kriuk nya tahan lama, sangat mudah untuk dicari dan juga kamu pun boleh membuatnya sendiri di rumah. ayam kfc/ kentuky simple,kriting dan kriuk nya tahan lama, dapat dimasak dengan beraneka cara. Saat ini ada banyak sekali cara modern yang menjadikan ayam kfc/ kentuky simple,kriting dan kriuk nya tahan lama, semakin mantap.

Resep ayam kfc/ kentuky simple,kriting dan kriuk nya tahan lama, juga gampang untuk dibikin, lho. Kita tidak usah repot-repot untuk memesan ayam kfc/ kentuky simple,kriting dan kriuk nya tahan lama,, tetapi Kita dapat menyiapkan di rumahmu. Bagi Kalian yang ingin membuatnya, di bawah ini adalah cara menyajikan ayam kfc/ kentuky simple,kriting dan kriuk nya tahan lama, yang enak yang dapat Kamu buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Ayam kfc/ kentuky simple,kriting dan kriuk nya tahan lama,:

1. Siapkan 1/2 kg daging ayam
1. Ambil 1/2 kg gandum segi3
1. Gunakan 1/2 bks tepung maizena
1. Sediakan 1 bks es batu(2rban)
1. Ambil 1 btr telur
1. Siapkan 4 bks royco ayam
1. Siapkan  Bumbu
1. Ambil 4 siung BP
1. Gunakan 1 siung BM
1. Gunakan secukupnya Garam
1. Ambil secukupnya Mrica
1. Gunakan secukupnya Tumbar
1. Siapkan 1ruas jari Jahe
1. Siapkan 1ruas jari Kunyit
1. Siapkan  Bahan lumuran tambahkn Baking soda




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam kfc/ kentuky simple,kriting dan kriuk nya tahan lama,:

1. Langkah 1, haluskan semua bumbu tambahkn 1bks royco(aq pkk blender olhnya lg bwaan bayi tangnya semutan)
1. Mariminasi ayam, masukan setngh es batu kdlm bumbu yg sdh dituang ke wadah ayam yg sdh dibersihkn,ksih royco 1 ½bks( biarkan dlu sembri kita siapkn bahan lumuran dan bahan Kering,
1. Bumbu kring, campurkn tepung segitiga dan maizena tmbhkn 1bks royco, aduk2 sampai rata
1. Bahan celupan, masukn sisa es batu kdlm baskom bri secukupy air,(jngn terllu bnyak nnti gk dingin) tmbhkn royco 1bks tambah sedikit bahan kering dan beking soda tambahkn telur yg sdh di ceplok(aduk hingga rata)
1. Selnjutnya, ambil ayam 1 persatu yg sdh di mariminasi msukan kebhan kering(bolak balik smbil di cubit2,, (sembri panaskn minyak)
1. Angkat lalu msukn ke adonan celupan es tunggu kurleb 1mnit, lalu angkat gulingkn ke adonan kering sambil di cubit2 biar ngbntuk kriting2,
1. Lalu angkat goreng menggunkn minyak panas, kmudian kcilkn api(jngn terllu besar) tkut daging ngk mateng, tunggu hingga kcoklatan (jngn di bolak balik terus y, bisa rontok kriting2nya, balik ayam jika sdh kring.
1. Lalu tiriskn
1. Selmat mencoba




Wah ternyata cara membuat ayam kfc/ kentuky simple,kriting dan kriuk nya tahan lama, yang nikamt tidak ribet ini mudah sekali ya! Kalian semua mampu membuatnya. Resep ayam kfc/ kentuky simple,kriting dan kriuk nya tahan lama, Sangat sesuai banget buat anda yang sedang belajar memasak atau juga untuk kalian yang sudah lihai memasak.

Apakah kamu mau mulai mencoba membikin resep ayam kfc/ kentuky simple,kriting dan kriuk nya tahan lama, lezat tidak ribet ini? Kalau kalian ingin, yuk kita segera buruan siapin alat dan bahannya, maka bikin deh Resep ayam kfc/ kentuky simple,kriting dan kriuk nya tahan lama, yang mantab dan tidak rumit ini. Betul-betul taidak sulit kan. 

Maka, ketimbang kita berfikir lama-lama, maka kita langsung saja hidangkan resep ayam kfc/ kentuky simple,kriting dan kriuk nya tahan lama, ini. Pasti anda tak akan menyesal bikin resep ayam kfc/ kentuky simple,kriting dan kriuk nya tahan lama, nikmat sederhana ini! Selamat berkreasi dengan resep ayam kfc/ kentuky simple,kriting dan kriuk nya tahan lama, enak tidak ribet ini di rumah masing-masing,oke!.

