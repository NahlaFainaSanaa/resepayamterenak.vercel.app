---
description: "Cara membuat Ayam Woku Sederhana dan Mudah Dibuat"
title: "Cara membuat Ayam Woku Sederhana dan Mudah Dibuat"
slug: 407-cara-membuat-ayam-woku-sederhana-dan-mudah-dibuat
date: 2021-03-19T01:06:46.781Z
image: https://img-global.cpcdn.com/recipes/d574b4134770c6e7/680x482cq70/ayam-woku-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d574b4134770c6e7/680x482cq70/ayam-woku-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d574b4134770c6e7/680x482cq70/ayam-woku-foto-resep-utama.jpg
author: Viola Butler
ratingvalue: 3.6
reviewcount: 3
recipeingredient:
- "1/2 ekor ayam"
- "1 ikat daun kemangi"
- " Bumbu Halus"
- "8-10 siung bawang merah"
- "4 siung bawang putih"
- "4 cabe rawit"
- "6 cabe merah keriting"
- "1 butir kemiri"
- " Bumbu utuh"
- "2 lembar daun salam"
- "2 batang sereh"
- "2 ruas lengkuas"
- "2 lembar daun jeruk"
- " Bumbu Penyedap"
- " Gula"
- " Garam"
- " Kaldu jamur"
- " Gula merah"
recipeinstructions:
- "Cuci bersih ayam lalu lumuri dengan air perasan jeruk nipis"
- "Goreng ayam sebentar agar tidak hancur saat dimasak dan sisa kotorannya hilang lalu tiriskan"
- "Tumis bumbu halus dan bumbu utuh yg digeprek sampai harum, lalu masukan ayam yg sudah digoreng tambahkan 500ml air dan bumbui dgn gula,garam,kaldu jamur, dan diamkan hingga airnya menyusut"
- "Jika airnya sudah mulai kering koreksi lagi rasanya jika sudah pas masukan daun kemangi dan aduk&#34; hingga daunnya layu lalu matikan api dan sajikan"
categories:
- Resep
tags:
- ayam
- woku

katakunci: ayam woku 
nutrition: 263 calories
recipecuisine: Indonesian
preptime: "PT19M"
cooktime: "PT56M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam Woku](https://img-global.cpcdn.com/recipes/d574b4134770c6e7/680x482cq70/ayam-woku-foto-resep-utama.jpg)

Andai kita seorang ibu, menyediakan santapan lezat untuk keluarga tercinta adalah hal yang membahagiakan bagi kamu sendiri. Kewajiban seorang ibu Tidak hanya mengatur rumah saja, tetapi kamu pun wajib memastikan kebutuhan nutrisi terpenuhi dan juga santapan yang dimakan keluarga tercinta mesti nikmat.

Di waktu  saat ini, anda memang mampu membeli hidangan siap saji walaupun tanpa harus capek mengolahnya dulu. Tapi banyak juga orang yang selalu ingin memberikan yang terenak untuk keluarganya. Lantaran, menyajikan masakan yang diolah sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan sesuai dengan selera orang tercinta. 



Apakah anda salah satu penikmat ayam woku?. Tahukah kamu, ayam woku merupakan makanan khas di Nusantara yang kini disukai oleh banyak orang dari hampir setiap wilayah di Nusantara. Kalian dapat membuat ayam woku sendiri di rumahmu dan pasti jadi santapan favoritmu di akhir pekan.

Kalian tidak perlu bingung jika kamu ingin menyantap ayam woku, lantaran ayam woku tidak sulit untuk didapatkan dan kamu pun bisa menghidangkannya sendiri di tempatmu. ayam woku boleh dibuat dengan bermacam cara. Kini pun ada banyak sekali resep modern yang menjadikan ayam woku lebih lezat.

Resep ayam woku pun mudah dibikin, lho. Kalian tidak usah repot-repot untuk membeli ayam woku, tetapi Kamu bisa menghidangkan ditempatmu. Untuk Kita yang hendak menyajikannya, berikut ini cara membuat ayam woku yang mantab yang bisa Kamu hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Ayam Woku:

1. Gunakan 1/2 ekor ayam
1. Sediakan 1 ikat daun kemangi
1. Ambil  Bumbu Halus
1. Sediakan 8-10 siung bawang merah
1. Siapkan 4 siung bawang putih
1. Ambil 4 cabe rawit
1. Gunakan 6 cabe merah keriting
1. Gunakan 1 butir kemiri
1. Ambil  Bumbu utuh
1. Sediakan 2 lembar daun salam
1. Gunakan 2 batang sereh
1. Siapkan 2 ruas lengkuas
1. Siapkan 2 lembar daun jeruk
1. Gunakan  Bumbu Penyedap
1. Sediakan  Gula
1. Siapkan  Garam
1. Sediakan  Kaldu jamur
1. Gunakan  Gula merah




<!--inarticleads2-->

##### Cara membuat Ayam Woku:

1. Cuci bersih ayam lalu lumuri dengan air perasan jeruk nipis
1. Goreng ayam sebentar agar tidak hancur saat dimasak dan sisa kotorannya hilang lalu tiriskan
1. Tumis bumbu halus dan bumbu utuh yg digeprek sampai harum, lalu masukan ayam yg sudah digoreng tambahkan 500ml air dan bumbui dgn gula,garam,kaldu jamur, dan diamkan hingga airnya menyusut
1. Jika airnya sudah mulai kering koreksi lagi rasanya jika sudah pas masukan daun kemangi dan aduk&#34; hingga daunnya layu lalu matikan api dan sajikan




Ternyata cara membuat ayam woku yang nikamt tidak ribet ini mudah sekali ya! Kalian semua mampu memasaknya. Resep ayam woku Sangat sesuai banget buat kamu yang baru mau belajar memasak atau juga bagi kamu yang telah ahli memasak.

Tertarik untuk mulai mencoba membuat resep ayam woku nikmat simple ini? Kalau anda tertarik, mending kamu segera siapin peralatan dan bahannya, setelah itu bikin deh Resep ayam woku yang mantab dan tidak ribet ini. Benar-benar mudah kan. 

Maka, daripada kamu berfikir lama-lama, yuk kita langsung saja sajikan resep ayam woku ini. Pasti kalian gak akan menyesal sudah bikin resep ayam woku mantab tidak ribet ini! Selamat mencoba dengan resep ayam woku lezat tidak ribet ini di rumah sendiri,ya!.

