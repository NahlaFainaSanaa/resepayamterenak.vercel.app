---
description: "Cara membuat Soto Ayam Koya Lamongan yang nikmat Untuk Jualan"
title: "Cara membuat Soto Ayam Koya Lamongan yang nikmat Untuk Jualan"
slug: 233-cara-membuat-soto-ayam-koya-lamongan-yang-nikmat-untuk-jualan
date: 2021-02-04T12:38:23.738Z
image: https://img-global.cpcdn.com/recipes/24b8c446254da92e/680x482cq70/soto-ayam-koya-lamongan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/24b8c446254da92e/680x482cq70/soto-ayam-koya-lamongan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/24b8c446254da92e/680x482cq70/soto-ayam-koya-lamongan-foto-resep-utama.jpg
author: Fannie Davis
ratingvalue: 4.6
reviewcount: 3
recipeingredient:
- "500 gram dada ayam"
- "250 gram ceker ayam"
- "2 lembar daun jeruk"
- "1 Batang seraigeprek"
- "1 ruas lengkuas geprek"
- "2 Batang daun preiirisiris"
- " Gulagaramkaldu bubuk  lada"
- " Bumbu halus"
- "4 siung bawang putih"
- "7 siung bawang merah"
- "5 cm kunyit"
- "1 sdm ketumbar"
- "1 sdt jinten"
- "1 ruas jahe"
- "3 butir kemiri"
- " Bahan pelengkap"
- " Telur rebus"
- " Seledriiris halus"
- " Kol"
- " Soun RRT"
- " Koya           lihat resep"
- " Sambal           lihat resep"
- " Krupuk udang"
- " Jeruk nipis"
recipeinstructions:
- "Cuci bersih dada ayam &amp; ceker."
- "Rebus dada ayam &amp; ceker"
- "Tumis semua bumbu halus hingga harum,masukkan serai lengkuas daun jeruk. Tumis kembali."
- "Masukkan daun prei,tumis hingga layu.angkat"
- "Masukkan tumisan bumbu halus ke dalam rebusan ayam &amp; ceker.aduk rata"
- "Tambahkan garam,gula,lada &amp; kaldu bubuk.masak hingga dada ayam &amp; ceker empuk.cek rasa,matikan kompor"
- "Angkat dada ayam dari kuah soto,lalu goreng."
- "Sajikan soto ayam dengan bahan pelengkap"
categories:
- Resep
tags:
- soto
- ayam
- koya

katakunci: soto ayam koya 
nutrition: 268 calories
recipecuisine: Indonesian
preptime: "PT23M"
cooktime: "PT50M"
recipeyield: "3"
recipecategory: Lunch

---


![Soto Ayam Koya Lamongan](https://img-global.cpcdn.com/recipes/24b8c446254da92e/680x482cq70/soto-ayam-koya-lamongan-foto-resep-utama.jpg)

Selaku seorang yang hobi memasak, menyediakan olahan lezat pada keluarga tercinta merupakan hal yang memuaskan untuk kamu sendiri. Kewajiban seorang  wanita Tidak cuma mengurus rumah saja, tetapi anda juga harus menyediakan kebutuhan nutrisi terpenuhi dan juga masakan yang dimakan orang tercinta harus nikmat.

Di waktu  saat ini, kamu memang bisa membeli hidangan praktis meski tidak harus capek membuatnya dahulu. Tetapi ada juga lho orang yang selalu mau memberikan hidangan yang terlezat bagi orang yang dicintainya. Sebab, menyajikan masakan yang dibuat sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan berdasarkan masakan kesukaan keluarga. 



Apakah kamu seorang penyuka soto ayam koya lamongan?. Asal kamu tahu, soto ayam koya lamongan merupakan hidangan khas di Indonesia yang sekarang disukai oleh setiap orang dari hampir setiap daerah di Nusantara. Anda dapat menyajikan soto ayam koya lamongan buatan sendiri di rumah dan dapat dijadikan camilan kegemaranmu di hari liburmu.

Kita tidak perlu bingung jika kamu ingin menyantap soto ayam koya lamongan, sebab soto ayam koya lamongan tidak sulit untuk didapatkan dan anda pun boleh memasaknya sendiri di tempatmu. soto ayam koya lamongan boleh diolah dengan bermacam cara. Sekarang sudah banyak resep kekinian yang menjadikan soto ayam koya lamongan semakin lezat.

Resep soto ayam koya lamongan pun gampang sekali untuk dibikin, lho. Anda tidak usah repot-repot untuk memesan soto ayam koya lamongan, sebab Kita bisa menyiapkan di rumah sendiri. Bagi Kamu yang akan menghidangkannya, dibawah ini merupakan resep untuk menyajikan soto ayam koya lamongan yang mantab yang dapat Kita buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Soto Ayam Koya Lamongan:

1. Siapkan 500 gram dada ayam
1. Gunakan 250 gram ceker ayam
1. Sediakan 2 lembar daun jeruk
1. Ambil 1 Batang serai,geprek
1. Ambil 1 ruas lengkuas, geprek
1. Siapkan 2 Batang daun prei,iris-iris
1. Gunakan  Gula,garam,kaldu bubuk &amp; lada
1. Ambil  Bumbu halus:
1. Sediakan 4 siung bawang putih
1. Siapkan 7 siung bawang merah
1. Sediakan 5 cm kunyit
1. Ambil 1 sdm ketumbar
1. Gunakan 1 sdt jinten
1. Siapkan 1 ruas jahe
1. Siapkan 3 butir kemiri
1. Sediakan  Bahan pelengkap:
1. Siapkan  Telur rebus
1. Gunakan  Seledri,iris halus
1. Sediakan  Kol
1. Ambil  Soun RRT
1. Siapkan  Koya           (lihat resep)
1. Gunakan  Sambal           (lihat resep)
1. Siapkan  Krupuk udang
1. Gunakan  Jeruk nipis




<!--inarticleads2-->

##### Langkah-langkah membuat Soto Ayam Koya Lamongan:

1. Cuci bersih dada ayam &amp; ceker.
1. Rebus dada ayam &amp; ceker
1. Tumis semua bumbu halus hingga harum,masukkan serai lengkuas daun jeruk. Tumis kembali.
1. Masukkan daun prei,tumis hingga layu.angkat
1. Masukkan tumisan bumbu halus ke dalam rebusan ayam &amp; ceker.aduk rata
1. Tambahkan garam,gula,lada &amp; kaldu bubuk.masak hingga dada ayam &amp; ceker empuk.cek rasa,matikan kompor
1. Angkat dada ayam dari kuah soto,lalu goreng.
1. Sajikan soto ayam dengan bahan pelengkap




Ternyata cara buat soto ayam koya lamongan yang enak tidak rumit ini enteng banget ya! Kamu semua bisa memasaknya. Cara Membuat soto ayam koya lamongan Cocok banget buat kamu yang sedang belajar memasak ataupun bagi anda yang sudah jago memasak.

Tertarik untuk mencoba membikin resep soto ayam koya lamongan enak sederhana ini? Kalau kamu ingin, mending kamu segera menyiapkan alat-alat dan bahan-bahannya, setelah itu bikin deh Resep soto ayam koya lamongan yang lezat dan simple ini. Betul-betul mudah kan. 

Maka dari itu, ketimbang kita berfikir lama-lama, yuk kita langsung saja bikin resep soto ayam koya lamongan ini. Dijamin anda tak akan nyesel membuat resep soto ayam koya lamongan nikmat sederhana ini! Selamat berkreasi dengan resep soto ayam koya lamongan lezat tidak ribet ini di rumah masing-masing,ya!.

