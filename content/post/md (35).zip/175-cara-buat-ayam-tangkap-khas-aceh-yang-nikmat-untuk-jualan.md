---
description: "Cara buat Ayam Tangkap Khas Aceh yang nikmat Untuk Jualan"
title: "Cara buat Ayam Tangkap Khas Aceh yang nikmat Untuk Jualan"
slug: 175-cara-buat-ayam-tangkap-khas-aceh-yang-nikmat-untuk-jualan
date: 2021-03-29T14:42:20.319Z
image: https://img-global.cpcdn.com/recipes/3d5e992e6a1aacc5/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/3d5e992e6a1aacc5/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/3d5e992e6a1aacc5/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg
author: Julia Hansen
ratingvalue: 3.2
reviewcount: 15
recipeingredient:
- "1 ekor ayam kampungpotong sy ayam potong 13 kg"
- "1 buah jeruk nipis ambil airnya"
- "3 sdm air asam jawa dr 3 mata asam"
- "2 sdt garam sesuai selera"
- "300 ml air kelapa dr 1 butir kelapa"
- "Secukupnya minyak goreng"
- " Bumbu halus"
- "6 siung bawang merah"
- "3 siung bawang putih"
- "5-8 buah cabai rawit hijau opsional"
- "1 sdt kunyit bubuk"
- "1/2 sdt merica bubuk"
- "1 ruas jari jahe"
- " Bahan"
- "10 tangkai daun kari ambil daunnya"
- "7 lembar daun pandan potong kecil"
- "8 buah cabai hijau potong jadi 3 bagian"
- "8 siung bawang merah iris tipis"
recipeinstructions:
- "Potong kecil-kecil ayam, cuci bersih, tiriskan, beri air jeruk nipis (dari 1/2 buah), diamkan beberapa saat, kmdn bilas kembali, tiriskan. Masukkan ayam ke dlm wajan, balur ayam dengan garam dan campuran air jeruk nipis (dari 1/2 buah jeruk nipis) + 3 sdm air asam jawa. Siapkan juga bahan rempah daunnya."
- "Masukkan bumbu halus ke dalam ayam, ratakan. Tambahkan air kelapa, kmdn ungkep ayam sambil ditutup sampai air menyusut dan bumbu meresap. Note: jika menggunakan ayam kampung, banyaknya air kelapa bisa disesuaikan."
- "Panaskan minyak goreng (minyak banyak), goreng ayam dgn api sedang, kemudian balik ayam. Setelah ayam mulai berwarna kecoklatan, masukkan daun kari, daun pandan, cabai hijau dan bawang merah iris. Goreng sampai ayam berwarna kecoklatan dan rempah daunnya kering serta bawang merahnya kecoklatan. Note: Saya 2X goreng, jadi rempah daunnya dibagi 2."
- "Setelah ayam matang berwarna kuning kecoklatan dan rempah daun kering, angkat dan tiriskan."
- "Sajikan ayam bersama rempah daun kering, cabai hijau dan bawang goreng keringnya. Ayam ini enak disajikan saat panas-panas, sehingga rempah daunnya masih kriuk."
categories:
- Resep
tags:
- ayam
- tangkap
- khas

katakunci: ayam tangkap khas 
nutrition: 230 calories
recipecuisine: Indonesian
preptime: "PT37M"
cooktime: "PT56M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Tangkap Khas Aceh](https://img-global.cpcdn.com/recipes/3d5e992e6a1aacc5/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg)

Sebagai seorang orang tua, menyuguhkan panganan menggugah selera bagi keluarga tercinta merupakan suatu hal yang membahagiakan bagi kamu sendiri. Peran seorang istri Tidak sekadar mengerjakan pekerjaan rumah saja, tetapi kamu juga harus memastikan kebutuhan gizi terpenuhi dan juga santapan yang dikonsumsi orang tercinta wajib nikmat.

Di masa  sekarang, anda memang bisa membeli panganan instan tanpa harus susah mengolahnya dahulu. Tetapi banyak juga mereka yang memang ingin memberikan hidangan yang terenak untuk keluarganya. Karena, menghidangkan masakan yang diolah sendiri jauh lebih higienis dan bisa menyesuaikan masakan tersebut berdasarkan kesukaan keluarga tercinta. 



Apakah anda seorang penyuka ayam tangkap khas aceh?. Tahukah kamu, ayam tangkap khas aceh adalah sajian khas di Nusantara yang saat ini digemari oleh orang-orang di hampir setiap wilayah di Indonesia. Kita bisa membuat ayam tangkap khas aceh sendiri di rumahmu dan dapat dijadikan camilan kesukaanmu di akhir pekanmu.

Kamu jangan bingung untuk memakan ayam tangkap khas aceh, lantaran ayam tangkap khas aceh sangat mudah untuk ditemukan dan juga anda pun bisa menghidangkannya sendiri di rumah. ayam tangkap khas aceh bisa dimasak dengan berbagai cara. Kini pun ada banyak banget cara modern yang menjadikan ayam tangkap khas aceh lebih enak.

Resep ayam tangkap khas aceh juga sangat gampang dihidangkan, lho. Kalian tidak usah repot-repot untuk membeli ayam tangkap khas aceh, lantaran Kita mampu menyiapkan sendiri di rumah. Bagi Kita yang ingin menyajikannya, berikut ini resep membuat ayam tangkap khas aceh yang nikamat yang mampu Kita coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Ayam Tangkap Khas Aceh:

1. Siapkan 1 ekor ayam kampung/potong (sy: ayam potong 1,3 kg)
1. Gunakan 1 buah jeruk nipis, ambil airnya
1. Ambil 3 sdm air asam jawa (dr 3 mata asam)
1. Siapkan 2 sdt garam (sesuai selera)
1. Gunakan 300 ml air kelapa (dr 1 butir kelapa)
1. Gunakan Secukupnya minyak goreng
1. Siapkan  Bumbu halus:
1. Siapkan 6 siung bawang merah
1. Gunakan 3 siung bawang putih
1. Siapkan 5-8 buah cabai rawit hijau (opsional)
1. Sediakan 1 sdt kunyit bubuk
1. Siapkan 1/2 sdt merica bubuk
1. Siapkan 1 ruas jari jahe
1. Gunakan  Bahan
1. Sediakan 10 tangkai daun kari, ambil daunnya
1. Ambil 7 lembar daun pandan, potong kecil
1. Sediakan 8 buah cabai hijau, potong jadi 3 bagian
1. Ambil 8 siung bawang merah, iris tipis




<!--inarticleads2-->

##### Cara membuat Ayam Tangkap Khas Aceh:

1. Potong kecil-kecil ayam, cuci bersih, tiriskan, beri air jeruk nipis (dari 1/2 buah), diamkan beberapa saat, kmdn bilas kembali, tiriskan. Masukkan ayam ke dlm wajan, balur ayam dengan garam dan campuran air jeruk nipis (dari 1/2 buah jeruk nipis) + 3 sdm air asam jawa. Siapkan juga bahan rempah daunnya.
1. Masukkan bumbu halus ke dalam ayam, ratakan. Tambahkan air kelapa, kmdn ungkep ayam sambil ditutup sampai air menyusut dan bumbu meresap. Note: jika menggunakan ayam kampung, banyaknya air kelapa bisa disesuaikan.
1. Panaskan minyak goreng (minyak banyak), goreng ayam dgn api sedang, kemudian balik ayam. Setelah ayam mulai berwarna kecoklatan, masukkan daun kari, daun pandan, cabai hijau dan bawang merah iris. Goreng sampai ayam berwarna kecoklatan dan rempah daunnya kering serta bawang merahnya kecoklatan. Note: Saya 2X goreng, jadi rempah daunnya dibagi 2.
1. Setelah ayam matang berwarna kuning kecoklatan dan rempah daun kering, angkat dan tiriskan.
1. Sajikan ayam bersama rempah daun kering, cabai hijau dan bawang goreng keringnya. Ayam ini enak disajikan saat panas-panas, sehingga rempah daunnya masih kriuk.




Ternyata cara buat ayam tangkap khas aceh yang lezat tidak rumit ini enteng banget ya! Kamu semua mampu membuatnya. Resep ayam tangkap khas aceh Sangat sesuai banget untuk kalian yang baru mau belajar memasak ataupun untuk kamu yang sudah lihai memasak.

Tertarik untuk mencoba bikin resep ayam tangkap khas aceh nikmat sederhana ini? Kalau kamu ingin, mending kamu segera menyiapkan alat-alat dan bahannya, setelah itu buat deh Resep ayam tangkap khas aceh yang lezat dan tidak ribet ini. Sangat taidak sulit kan. 

Maka dari itu, ketimbang kalian berfikir lama-lama, hayo langsung aja bikin resep ayam tangkap khas aceh ini. Dijamin anda tak akan nyesel sudah bikin resep ayam tangkap khas aceh lezat simple ini! Selamat berkreasi dengan resep ayam tangkap khas aceh lezat sederhana ini di rumah kalian masing-masing,oke!.

