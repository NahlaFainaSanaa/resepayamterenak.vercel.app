---
description: "Cara membuat Marinasi Ayam santan yang enak dan Mudah Dibuat"
title: "Cara membuat Marinasi Ayam santan yang enak dan Mudah Dibuat"
slug: 478-cara-membuat-marinasi-ayam-santan-yang-enak-dan-mudah-dibuat
date: 2021-01-22T10:04:07.403Z
image: https://img-global.cpcdn.com/recipes/e7ca49783bcd126a/680x482cq70/marinasi-ayam-santan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e7ca49783bcd126a/680x482cq70/marinasi-ayam-santan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e7ca49783bcd126a/680x482cq70/marinasi-ayam-santan-foto-resep-utama.jpg
author: Susie Hanson
ratingvalue: 4.1
reviewcount: 11
recipeingredient:
- "500 gr ayam"
- "1 saset sun kara"
- "4 siung bawang putih"
- "1/2 sdt lada"
- "1/2 sdt ketumbar"
- "1/2 sdt Kunyit"
- "2 sdm garam halus"
- "1 sdt sasa"
- "4 cm lengkuas"
recipeinstructions:
- "Bersihkan ayam terlebih dahulu"
- "Siapkan bahan"
- "Cincang bawang putih dan lengkuas sampai halus"
- "Campurkan semua bumbu ke ayam."
- "Lalu aduk rata bumbu dengan ayam."
- "Setelah rata, masukkan ayam ke kulkas dan diamkan ayam 1 jam"
- "Selanjutnya goreng ayam dengan api kecil"
- "Selamat menikmati"
categories:
- Resep
tags:
- marinasi
- ayam
- santan

katakunci: marinasi ayam santan 
nutrition: 120 calories
recipecuisine: Indonesian
preptime: "PT35M"
cooktime: "PT59M"
recipeyield: "3"
recipecategory: Dinner

---


![Marinasi Ayam santan](https://img-global.cpcdn.com/recipes/e7ca49783bcd126a/680x482cq70/marinasi-ayam-santan-foto-resep-utama.jpg)

Selaku seorang ibu, menyuguhkan hidangan enak untuk famili merupakan suatu hal yang sangat menyenangkan untuk kamu sendiri. Kewajiban seorang  wanita Tidak hanya menangani rumah saja, tapi anda juga wajib memastikan kebutuhan gizi tercukupi dan olahan yang dimakan keluarga tercinta harus mantab.

Di waktu  sekarang, anda memang mampu membeli panganan praktis tanpa harus repot memasaknya terlebih dahulu. Namun ada juga orang yang selalu ingin memberikan makanan yang terlezat bagi orang yang dicintainya. Pasalnya, menghidangkan masakan sendiri jauh lebih bersih dan kita pun bisa menyesuaikan hidangan tersebut berdasarkan kesukaan keluarga. 



Mungkinkah anda adalah seorang penyuka marinasi ayam santan?. Asal kamu tahu, marinasi ayam santan adalah hidangan khas di Indonesia yang sekarang digemari oleh banyak orang di hampir setiap wilayah di Nusantara. Kamu dapat menghidangkan marinasi ayam santan hasil sendiri di rumah dan boleh dijadikan camilan kesukaanmu di akhir pekan.

Kamu jangan bingung untuk memakan marinasi ayam santan, sebab marinasi ayam santan sangat mudah untuk dicari dan juga kamu pun boleh mengolahnya sendiri di rumah. marinasi ayam santan boleh dimasak memalui beraneka cara. Saat ini telah banyak resep modern yang membuat marinasi ayam santan lebih enak.

Resep marinasi ayam santan juga sangat mudah untuk dibuat, lho. Kita tidak usah capek-capek untuk memesan marinasi ayam santan, karena Kita bisa membuatnya ditempatmu. Untuk Kamu yang ingin menghidangkannya, dibawah ini merupakan resep untuk menyajikan marinasi ayam santan yang mantab yang mampu Kalian buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Marinasi Ayam santan:

1. Siapkan 500 gr ayam
1. Siapkan 1 saset sun kara
1. Ambil 4 siung bawang putih
1. Sediakan 1/2 sdt lada
1. Gunakan 1/2 sdt ketumbar
1. Sediakan 1/2 sdt Kunyit
1. Siapkan 2 sdm garam halus
1. Sediakan 1 sdt sasa
1. Gunakan 4 cm lengkuas




<!--inarticleads2-->

##### Langkah-langkah membuat Marinasi Ayam santan:

1. Bersihkan ayam terlebih dahulu
<img src="https://img-global.cpcdn.com/steps/f6698922264c6775/160x128cq70/marinasi-ayam-santan-langkah-memasak-1-foto.jpg" alt="Marinasi Ayam santan">1. Siapkan bahan
<img src="https://img-global.cpcdn.com/steps/e6cd1c2e6ab0a092/160x128cq70/marinasi-ayam-santan-langkah-memasak-2-foto.jpg" alt="Marinasi Ayam santan">1. Cincang bawang putih dan lengkuas sampai halus
1. Campurkan semua bumbu ke ayam.
1. Lalu aduk rata bumbu dengan ayam.
1. Setelah rata, masukkan ayam ke kulkas dan diamkan ayam 1 jam
1. Selanjutnya goreng ayam dengan api kecil
1. Selamat menikmati




Wah ternyata cara buat marinasi ayam santan yang enak sederhana ini enteng sekali ya! Kamu semua dapat mencobanya. Cara Membuat marinasi ayam santan Sesuai sekali buat kita yang baru akan belajar memasak ataupun bagi kalian yang telah jago memasak.

Apakah kamu tertarik mulai mencoba membuat resep marinasi ayam santan mantab tidak rumit ini? Kalau ingin, mending kamu segera buruan siapin alat-alat dan bahannya, lalu buat deh Resep marinasi ayam santan yang lezat dan tidak rumit ini. Betul-betul mudah kan. 

Jadi, daripada anda diam saja, maka kita langsung buat resep marinasi ayam santan ini. Pasti kamu tiidak akan menyesal bikin resep marinasi ayam santan enak simple ini! Selamat berkreasi dengan resep marinasi ayam santan mantab simple ini di tempat tinggal sendiri,ya!.

