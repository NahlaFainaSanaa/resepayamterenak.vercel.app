---
description: "Resep 123. Ayam Tangkap khas Aceh yang nikmat Untuk Jualan"
title: "Resep 123. Ayam Tangkap khas Aceh yang nikmat Untuk Jualan"
slug: 168-resep-123-ayam-tangkap-khas-aceh-yang-nikmat-untuk-jualan
date: 2021-04-27T19:30:21.242Z
image: https://img-global.cpcdn.com/recipes/bda5c614a79824d4/680x482cq70/123-ayam-tangkap-khas-aceh-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/bda5c614a79824d4/680x482cq70/123-ayam-tangkap-khas-aceh-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/bda5c614a79824d4/680x482cq70/123-ayam-tangkap-khas-aceh-foto-resep-utama.jpg
author: Herman Floyd
ratingvalue: 3.8
reviewcount: 11
recipeingredient:
- "1 ekor  700 g ayam kampung"
- "2 batang serai memarkan"
- "6 lembar daun jeruk buang tulang daunnya"
- "500 ml air kelapa"
- "200 ml air"
- " minyak untuk menggoreng"
- " Bumbu Halus "
- "100 g bawang merah"
- "8 siung bawang putih"
- "4 cm jahe"
- "4 cm kunyit"
- "1/2-1 sdt merica"
- "1 1/2 sdt garam"
- "1 sdm air asam jawa"
- "1 sdm gula merah"
- " Bahan Kasar "
- "125 g bawang merah iris tipis"
- "8 siung bawang putih iris tipis"
- "2 lembar daun pandan iris ukuran 2 cm"
- "2 tangkai daun salam koja petik daunnya"
- "5 buah cabai hijau belah dua memanjang me cabe merah"
- "4 batang daun bawang iris ukuran 3 cm"
- "3 lembar daun kunyit iris  cm"
- "4 batang serai memarkan"
recipeinstructions:
- "Potong-potong kecil ayam beserta tulangnya ukuran 3 cm. Campur potongan ayam dengan bumbu halus, aduk rata, diamkan selama ± 30 menit agar bumbu meresap."
- "Taruh ayam berikut bumbunya dalam wajan, masukkan serai dan daun jeruk. Tuangi air kelapa dan air, jerang di atas api, masak hingga mendidih. Kecilkan apinya, tutup wajan, masak terus hingga airnya mengering dan ayam empuk."
- "Panaskan minyak goreng yang banyak dalam wajan di atas api sedang. Goreng masing-masing bumbu kasar secara terpisah, aduk-aduk hingga masing-masing bumbu matang dan kering, angkat. Campur jadi satu semua bumbu kasar yang sudah digoreng tadi, sisihkan."
- "Panaskan kembali bekas menggoreng bumbu, masukkan setengah bagian ayam ungkep. Goreng sambil diaduk-aduk hingga ayam kering, angkat, tiriskan. Lakukan hal yang sama untuk sisa ayam."
- "Taruh ayam goreng dan bumbu kasar goreng dalam wadah, aduk rata, hidangkan."
categories:
- Resep
tags:
- 123
- ayam
- tangkap

katakunci: 123 ayam tangkap 
nutrition: 181 calories
recipecuisine: Indonesian
preptime: "PT13M"
cooktime: "PT50M"
recipeyield: "2"
recipecategory: Lunch

---


![123. Ayam Tangkap khas Aceh](https://img-global.cpcdn.com/recipes/bda5c614a79824d4/680x482cq70/123-ayam-tangkap-khas-aceh-foto-resep-utama.jpg)

Sebagai seorang ibu, menyediakan panganan enak pada orang tercinta merupakan suatu hal yang memuaskan bagi kamu sendiri. Tanggung jawab seorang  wanita bukan cuma menjaga rumah saja, namun anda pun harus memastikan keperluan nutrisi tercukupi dan juga santapan yang disantap keluarga tercinta harus sedap.

Di zaman  saat ini, kita memang dapat membeli hidangan siap saji tanpa harus ribet mengolahnya dulu. Tetapi banyak juga lho mereka yang memang ingin menyajikan yang terenak untuk orang yang dicintainya. Lantaran, memasak sendiri akan jauh lebih higienis dan bisa menyesuaikan makanan tersebut sesuai masakan kesukaan famili. 



Apakah anda merupakan salah satu penyuka 123. ayam tangkap khas aceh?. Asal kamu tahu, 123. ayam tangkap khas aceh merupakan hidangan khas di Nusantara yang saat ini digemari oleh kebanyakan orang dari berbagai tempat di Nusantara. Anda bisa menyajikan 123. ayam tangkap khas aceh hasil sendiri di rumahmu dan boleh jadi makanan favorit di hari liburmu.

Kalian tak perlu bingung untuk menyantap 123. ayam tangkap khas aceh, lantaran 123. ayam tangkap khas aceh tidak sukar untuk ditemukan dan anda pun dapat mengolahnya sendiri di rumah. 123. ayam tangkap khas aceh bisa dibuat lewat bermacam cara. Saat ini sudah banyak cara modern yang membuat 123. ayam tangkap khas aceh semakin enak.

Resep 123. ayam tangkap khas aceh pun sangat mudah dihidangkan, lho. Kita tidak perlu repot-repot untuk membeli 123. ayam tangkap khas aceh, tetapi Anda dapat menyajikan ditempatmu. Untuk Kamu yang ingin menghidangkannya, di bawah ini adalah cara menyajikan 123. ayam tangkap khas aceh yang enak yang dapat Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan 123. Ayam Tangkap khas Aceh:

1. Gunakan 1 ekor (± 700 g) ayam kampung
1. Sediakan 2 batang serai, memarkan
1. Ambil 6 lembar daun jeruk, buang tulang daunnya
1. Siapkan 500 ml air kelapa
1. Siapkan 200 ml air
1. Sediakan  minyak untuk menggoreng
1. Sediakan  Bumbu Halus :
1. Sediakan 100 g bawang merah
1. Ambil 8 siung bawang putih
1. Ambil 4 cm jahe
1. Sediakan 4 cm kunyit
1. Siapkan 1/2-1 sdt merica
1. Sediakan 1 1/2 sdt garam
1. Gunakan 1 sdm air asam jawa
1. Gunakan 1 sdm gula merah
1. Gunakan  Bahan Kasar :
1. Ambil 125 g bawang merah, iris tipis
1. Sediakan 8 siung bawang putih, iris tipis
1. Ambil 2 lembar daun pandan, iris ukuran 2 cm
1. Gunakan 2 tangkai daun salam koja, petik daunnya
1. Ambil 5 buah cabai hijau, belah dua memanjang (me: cabe merah)
1. Gunakan 4 batang daun bawang, iris ukuran 3 cm
1. Ambil 3 lembar daun kunyit, iris ½ cm
1. Gunakan 4 batang serai, memarkan




<!--inarticleads2-->

##### Cara membuat 123. Ayam Tangkap khas Aceh:

1. Potong-potong kecil ayam beserta tulangnya ukuran 3 cm. Campur potongan ayam dengan bumbu halus, aduk rata, diamkan selama ± 30 menit agar bumbu meresap.
1. Taruh ayam berikut bumbunya dalam wajan, masukkan serai dan daun jeruk. Tuangi air kelapa dan air, jerang di atas api, masak hingga mendidih. Kecilkan apinya, tutup wajan, masak terus hingga airnya mengering dan ayam empuk.
1. Panaskan minyak goreng yang banyak dalam wajan di atas api sedang. Goreng masing-masing bumbu kasar secara terpisah, aduk-aduk hingga masing-masing bumbu matang dan kering, angkat. Campur jadi satu semua bumbu kasar yang sudah digoreng tadi, sisihkan.
1. Panaskan kembali bekas menggoreng bumbu, masukkan setengah bagian ayam ungkep. Goreng sambil diaduk-aduk hingga ayam kering, angkat, tiriskan. Lakukan hal yang sama untuk sisa ayam.
1. Taruh ayam goreng dan bumbu kasar goreng dalam wadah, aduk rata, hidangkan.




Wah ternyata cara membuat 123. ayam tangkap khas aceh yang enak simple ini gampang banget ya! Kalian semua dapat membuatnya. Cara buat 123. ayam tangkap khas aceh Cocok sekali buat kamu yang baru akan belajar memasak ataupun juga untuk kalian yang sudah hebat dalam memasak.

Apakah kamu ingin mencoba membuat resep 123. ayam tangkap khas aceh mantab sederhana ini? Kalau kamu tertarik, yuk kita segera buruan siapkan alat-alat dan bahan-bahannya, lalu bikin deh Resep 123. ayam tangkap khas aceh yang mantab dan tidak ribet ini. Benar-benar gampang kan. 

Jadi, daripada kita berfikir lama-lama, ayo langsung aja buat resep 123. ayam tangkap khas aceh ini. Pasti anda gak akan nyesel sudah membuat resep 123. ayam tangkap khas aceh nikmat simple ini! Selamat berkreasi dengan resep 123. ayam tangkap khas aceh enak tidak rumit ini di tempat tinggal kalian sendiri,oke!.

