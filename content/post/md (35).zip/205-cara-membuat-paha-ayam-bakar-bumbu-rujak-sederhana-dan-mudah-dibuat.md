---
description: "Cara membuat Paha Ayam Bakar Bumbu Rujak Sederhana dan Mudah Dibuat"
title: "Cara membuat Paha Ayam Bakar Bumbu Rujak Sederhana dan Mudah Dibuat"
slug: 205-cara-membuat-paha-ayam-bakar-bumbu-rujak-sederhana-dan-mudah-dibuat
date: 2021-06-11T17:02:56.590Z
image: https://img-global.cpcdn.com/recipes/537a98a5ce29531f/680x482cq70/paha-ayam-bakar-bumbu-rujak-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/537a98a5ce29531f/680x482cq70/paha-ayam-bakar-bumbu-rujak-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/537a98a5ce29531f/680x482cq70/paha-ayam-bakar-bumbu-rujak-foto-resep-utama.jpg
author: Irene Pena
ratingvalue: 3
reviewcount: 11
recipeingredient:
- "1 kg9 potong paha ayam bagian bawah cuci bersih"
- "1 batang besar serai potong 3 lalu geprek"
- "6 lembar daun jeruk purut"
- "2 sdm gula merah aren"
- "2 sdm air asam jawa sejempol asam  air"
- "300 ml air"
- "50 ml minyak goreng"
- " Bumbu halus "
- "12 buah cabe merah keriting"
- "6 buah cabe rawit merah besar"
- "10 butir bawang merah"
- "6 siung bawang putih"
- "5 butir kemiri"
- "1.5 sdt ketumbar"
- "5 gr1 bungkus terasi ABC"
- "1.5 sdt garam"
- " Bahan olesan  aduk rata"
- "Secukupnya kuah ungkepan ayam"
- "Secukupnya kecap manis"
recipeinstructions:
- "Tumis bumbu halus, serai dan daun jeruk hingga harum"
- "Tambahkan ayam sambil diaduk-aduk hingga ayam berubah warna"
- "Tuang air, air asam jawa dan santan lalu beri gula aren. Masak hingga kuahnya menyusut dan mengental. Koreksi rasa. Siapkan bahan olesan"
- "Bakar ayam hingga setengah kering. Beri bahan olesan sambil dibolak balik hingga kering (banyaknya olesan sesuaikan selera aja)"
categories:
- Resep
tags:
- paha
- ayam
- bakar

katakunci: paha ayam bakar 
nutrition: 172 calories
recipecuisine: Indonesian
preptime: "PT17M"
cooktime: "PT45M"
recipeyield: "4"
recipecategory: Dessert

---


![Paha Ayam Bakar Bumbu Rujak](https://img-global.cpcdn.com/recipes/537a98a5ce29531f/680x482cq70/paha-ayam-bakar-bumbu-rujak-foto-resep-utama.jpg)

Selaku seorang ibu, mempersiapkan masakan lezat buat famili adalah hal yang menyenangkan bagi anda sendiri. Kewajiban seorang  wanita bukan saja mengerjakan pekerjaan rumah saja, tetapi kamu juga wajib memastikan kebutuhan gizi terpenuhi dan juga hidangan yang dimakan anak-anak wajib sedap.

Di era  saat ini, kita memang bisa membeli panganan siap saji walaupun tanpa harus repot memasaknya lebih dulu. Tapi banyak juga lho mereka yang selalu mau menyajikan yang terbaik untuk orang tercintanya. Pasalnya, menyajikan masakan yang dibuat sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan hidangan tersebut sesuai dengan masakan kesukaan orang tercinta. 



Mungkinkah anda merupakan seorang penikmat paha ayam bakar bumbu rujak?. Tahukah kamu, paha ayam bakar bumbu rujak adalah hidangan khas di Indonesia yang sekarang disukai oleh setiap orang di hampir setiap tempat di Nusantara. Kita dapat menghidangkan paha ayam bakar bumbu rujak hasil sendiri di rumahmu dan boleh jadi santapan favorit di akhir pekan.

Kamu jangan bingung untuk mendapatkan paha ayam bakar bumbu rujak, lantaran paha ayam bakar bumbu rujak mudah untuk didapatkan dan kamu pun dapat menghidangkannya sendiri di tempatmu. paha ayam bakar bumbu rujak boleh diolah lewat beraneka cara. Saat ini telah banyak cara kekinian yang membuat paha ayam bakar bumbu rujak semakin lebih mantap.

Resep paha ayam bakar bumbu rujak juga mudah dibikin, lho. Kita tidak perlu repot-repot untuk memesan paha ayam bakar bumbu rujak, lantaran Kalian dapat membuatnya sendiri di rumah. Bagi Kamu yang mau mencobanya, berikut cara menyajikan paha ayam bakar bumbu rujak yang mantab yang mampu Kamu hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Paha Ayam Bakar Bumbu Rujak:

1. Siapkan 1 kg/9 potong paha ayam (bagian bawah), cuci bersih
1. Sediakan 1 batang besar serai, potong 3 lalu geprek
1. Sediakan 6 lembar daun jeruk purut
1. Siapkan 2 sdm gula merah aren
1. Sediakan 2 sdm air asam jawa (sejempol asam + air)
1. Siapkan 300 ml air
1. Sediakan 50 ml minyak goreng
1. Gunakan  Bumbu halus :
1. Ambil 12 buah cabe merah keriting
1. Ambil 6 buah cabe rawit merah besar
1. Gunakan 10 butir bawang merah
1. Gunakan 6 siung bawang putih
1. Gunakan 5 butir kemiri
1. Sediakan 1.5 sdt ketumbar
1. Ambil 5 gr/1 bungkus terasi ABC
1. Ambil 1.5 sdt garam
1. Gunakan  Bahan olesan : aduk rata
1. Gunakan Secukupnya kuah ungkepan ayam
1. Sediakan Secukupnya kecap manis




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Paha Ayam Bakar Bumbu Rujak:

1. Tumis bumbu halus, serai dan daun jeruk hingga harum
1. Tambahkan ayam sambil diaduk-aduk hingga ayam berubah warna
1. Tuang air, air asam jawa dan santan lalu beri gula aren. Masak hingga kuahnya menyusut dan mengental. Koreksi rasa. Siapkan bahan olesan
1. Bakar ayam hingga setengah kering. Beri bahan olesan sambil dibolak balik hingga kering (banyaknya olesan sesuaikan selera aja)




Wah ternyata cara buat paha ayam bakar bumbu rujak yang mantab tidak ribet ini enteng banget ya! Kamu semua dapat mencobanya. Cara buat paha ayam bakar bumbu rujak Sangat cocok banget untuk anda yang baru belajar memasak maupun untuk kalian yang sudah pandai dalam memasak.

Tertarik untuk mencoba buat resep paha ayam bakar bumbu rujak nikmat simple ini? Kalau kalian tertarik, mending kamu segera buruan menyiapkan peralatan dan bahannya, lantas bikin deh Resep paha ayam bakar bumbu rujak yang enak dan tidak ribet ini. Sangat mudah kan. 

Oleh karena itu, ketimbang kita berlama-lama, hayo kita langsung saja hidangkan resep paha ayam bakar bumbu rujak ini. Pasti kamu gak akan nyesel sudah membuat resep paha ayam bakar bumbu rujak nikmat sederhana ini! Selamat mencoba dengan resep paha ayam bakar bumbu rujak mantab tidak ribet ini di tempat tinggal masing-masing,oke!.

