---
description: "Cara membuat Woku Ayam Kampung Ala Rumah Kami yang nikmat Untuk Jualan"
title: "Cara membuat Woku Ayam Kampung Ala Rumah Kami yang nikmat Untuk Jualan"
slug: 392-cara-membuat-woku-ayam-kampung-ala-rumah-kami-yang-nikmat-untuk-jualan
date: 2021-04-18T17:00:18.246Z
image: https://img-global.cpcdn.com/recipes/ab9420fcb100bef0/680x482cq70/woku-ayam-kampung-ala-rumah-kami-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ab9420fcb100bef0/680x482cq70/woku-ayam-kampung-ala-rumah-kami-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ab9420fcb100bef0/680x482cq70/woku-ayam-kampung-ala-rumah-kami-foto-resep-utama.jpg
author: Eric McDaniel
ratingvalue: 4.8
reviewcount: 15
recipeingredient:
- "1 ekor ayam kampung agak muda"
- "23-25 buah cabe merah"
- "10-15 buah cabe rawit setan"
- "10-12 siung bawang merah"
- "7-8 siung bawang putih"
- "4 butir kemiri"
- "1 ruas sedang jahe"
- "3-4 batang serai"
- "1,5 ruas kunyit"
- "3-4 lembar daun pandan segar diikat"
- "1-2 lembar daun kunyit segar kalo besar cukup 1"
- "3-5 lembar daun salam segar"
- "3-5 lembar daun jeruk segar"
- "1 ikat daun kemangi segar"
- "2 buah tomat"
- "1 SDM garam halus"
- "1 SDM kaldu ayam bubuk"
- "1 SDM gula pasir"
- "1 SDT merica halus"
recipeinstructions:
- "Siapkan bahan"
- "Bersihkan ayam kampung, potong-potong lalu cuci. Kucuri dengan jeruk kunci lalu sisihkan."
- "Bersihkan dan kupas bumbu. Kemiri, jahe, kunyit dan serai disangrai dulu biar wangi."
- "Haluskan cabe, bawang merah, bawang putih, kemiri, jahe dan kunyit yang sudah disangrai tadi"
- "Cuci bersih daun pandan, daun kunyit, daun salam, daun jeruk dan daun kemangi. Serai digeprek. Tomat dipotong-potong"
- "Tumis bumbu halus sampai tertumis sempurna. Masukkan serai"
- "Masukkan daun pandan, daun kunyit, lalu daun salam dan daun jeruk. Aduk rata."
- "Aduk dan tumis sampai daun layu dan bumbu makin harum"
- "Masukkan potongan ayam dengan tangan sedikit demi sedikit, supaya air marinasi gak ikut"
- "Lanjut tumis sampai ayam mengkeret. Lalu beri air matang sekitar 2 gelas"
- "Aduk lalu tunggu mendidih. Kemudian tutup wajan dan masak dengan metode NCC (5 menit rebus, 30 menit biarkan dan 7 menit lanjut rebus)"
- "Setelah selesai matikan kompor dan buka wajan, ayam sudah empuk dan bumbu agak sat. Boleh tambah air matang lagi sekitar 1 gelas. Tunggu mendidih lagi lalu masukkan Garam halus, bubuk merica, kaldu bubuk, gula pasir. Aduk rata."
- "Aduk lalu masukkan potongan tomat dan koreksi rasa."
- "Matikan kompor. Masukkan daun kemangi. Aduk. Jadi deh"
- "Tinggal disajikan, makan dengan nasi hangat, muantap ini. Selamat mencoba."
categories:
- Resep
tags:
- woku
- ayam
- kampung

katakunci: woku ayam kampung 
nutrition: 245 calories
recipecuisine: Indonesian
preptime: "PT16M"
cooktime: "PT41M"
recipeyield: "4"
recipecategory: Lunch

---


![Woku Ayam Kampung Ala Rumah Kami](https://img-global.cpcdn.com/recipes/ab9420fcb100bef0/680x482cq70/woku-ayam-kampung-ala-rumah-kami-foto-resep-utama.jpg)

Apabila kamu seorang ibu, menyediakan masakan nikmat pada famili merupakan hal yang sangat menyenangkan bagi kamu sendiri. Tanggung jawab seorang ibu bukan sekedar mengerjakan pekerjaan rumah saja, tetapi anda pun wajib menyediakan keperluan gizi tercukupi dan juga hidangan yang dimakan anak-anak mesti enak.

Di zaman  sekarang, anda sebenarnya bisa membeli olahan yang sudah jadi meski tidak harus susah memasaknya lebih dulu. Tapi ada juga lho mereka yang selalu ingin menghidangkan yang terenak bagi orang tercintanya. Sebab, memasak yang diolah sendiri jauh lebih bersih dan kita pun bisa menyesuaikan makanan tersebut berdasarkan makanan kesukaan keluarga tercinta. 



Apakah anda adalah salah satu penikmat woku ayam kampung ala rumah kami?. Tahukah kamu, woku ayam kampung ala rumah kami merupakan hidangan khas di Nusantara yang sekarang disenangi oleh banyak orang dari berbagai daerah di Nusantara. Anda bisa menghidangkan woku ayam kampung ala rumah kami kreasi sendiri di rumahmu dan boleh jadi camilan kesukaanmu di hari liburmu.

Kamu tidak perlu bingung jika kamu ingin menyantap woku ayam kampung ala rumah kami, sebab woku ayam kampung ala rumah kami mudah untuk didapatkan dan kalian pun boleh memasaknya sendiri di rumah. woku ayam kampung ala rumah kami bisa dimasak memalui beragam cara. Kini pun ada banyak sekali resep modern yang menjadikan woku ayam kampung ala rumah kami lebih enak.

Resep woku ayam kampung ala rumah kami juga sangat mudah untuk dibikin, lho. Kamu tidak perlu repot-repot untuk memesan woku ayam kampung ala rumah kami, tetapi Kita dapat menyiapkan di rumahmu. Bagi Kalian yang akan menghidangkannya, di bawah ini adalah resep membuat woku ayam kampung ala rumah kami yang nikamat yang mampu Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Woku Ayam Kampung Ala Rumah Kami:

1. Gunakan 1 ekor ayam kampung agak muda
1. Ambil 23-25 buah cabe merah
1. Siapkan 10-15 buah cabe rawit setan
1. Siapkan 10-12 siung bawang merah
1. Sediakan 7-8 siung bawang putih
1. Sediakan 4 butir kemiri
1. Gunakan 1 ruas sedang jahe
1. Siapkan 3-4 batang serai
1. Gunakan 1,5 ruas kunyit
1. Gunakan 3-4 lembar daun pandan segar diikat
1. Siapkan 1-2 lembar daun kunyit segar, kalo besar cukup 1
1. Gunakan 3-5 lembar daun salam segar
1. Sediakan 3-5 lembar daun jeruk segar
1. Gunakan 1 ikat daun kemangi segar
1. Siapkan 2 buah tomat
1. Ambil 1 SDM garam halus
1. Siapkan 1 SDM kaldu ayam bubuk
1. Gunakan 1 SDM gula pasir
1. Gunakan 1 SDT merica halus




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Woku Ayam Kampung Ala Rumah Kami:

1. Siapkan bahan
1. Bersihkan ayam kampung, potong-potong lalu cuci. Kucuri dengan jeruk kunci lalu sisihkan.
1. Bersihkan dan kupas bumbu. Kemiri, jahe, kunyit dan serai disangrai dulu biar wangi.
1. Haluskan cabe, bawang merah, bawang putih, kemiri, jahe dan kunyit yang sudah disangrai tadi
1. Cuci bersih daun pandan, daun kunyit, daun salam, daun jeruk dan daun kemangi. Serai digeprek. Tomat dipotong-potong
1. Tumis bumbu halus sampai tertumis sempurna. Masukkan serai
1. Masukkan daun pandan, daun kunyit, lalu daun salam dan daun jeruk. Aduk rata.
1. Aduk dan tumis sampai daun layu dan bumbu makin harum
1. Masukkan potongan ayam dengan tangan sedikit demi sedikit, supaya air marinasi gak ikut
1. Lanjut tumis sampai ayam mengkeret. Lalu beri air matang sekitar 2 gelas
1. Aduk lalu tunggu mendidih. Kemudian tutup wajan dan masak dengan metode NCC (5 menit rebus, 30 menit biarkan dan 7 menit lanjut rebus)
1. Setelah selesai matikan kompor dan buka wajan, ayam sudah empuk dan bumbu agak sat. Boleh tambah air matang lagi sekitar 1 gelas. Tunggu mendidih lagi lalu masukkan Garam halus, bubuk merica, kaldu bubuk, gula pasir. Aduk rata.
1. Aduk lalu masukkan potongan tomat dan koreksi rasa.
1. Matikan kompor. Masukkan daun kemangi. Aduk. Jadi deh
1. Tinggal disajikan, makan dengan nasi hangat, muantap ini. Selamat mencoba.




Wah ternyata resep woku ayam kampung ala rumah kami yang nikamt sederhana ini gampang banget ya! Semua orang bisa membuatnya. Cara buat woku ayam kampung ala rumah kami Sangat sesuai sekali buat kita yang baru belajar memasak maupun untuk anda yang telah jago dalam memasak.

Apakah kamu tertarik mulai mencoba membikin resep woku ayam kampung ala rumah kami enak tidak rumit ini? Kalau kalian ingin, ayo kalian segera buruan siapin alat dan bahan-bahannya, setelah itu bikin deh Resep woku ayam kampung ala rumah kami yang lezat dan sederhana ini. Benar-benar taidak sulit kan. 

Maka dari itu, ketimbang kita diam saja, ayo kita langsung hidangkan resep woku ayam kampung ala rumah kami ini. Dijamin anda tak akan nyesel sudah bikin resep woku ayam kampung ala rumah kami enak sederhana ini! Selamat mencoba dengan resep woku ayam kampung ala rumah kami mantab simple ini di tempat tinggal sendiri,ya!.

