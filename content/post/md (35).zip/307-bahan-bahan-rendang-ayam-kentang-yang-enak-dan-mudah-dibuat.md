---
description: "Bahan-bahan Rendang Ayam Kentang yang enak dan Mudah Dibuat"
title: "Bahan-bahan Rendang Ayam Kentang yang enak dan Mudah Dibuat"
slug: 307-bahan-bahan-rendang-ayam-kentang-yang-enak-dan-mudah-dibuat
date: 2021-07-07T05:38:23.366Z
image: https://img-global.cpcdn.com/recipes/d231b723b170981e/680x482cq70/rendang-ayam-kentang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d231b723b170981e/680x482cq70/rendang-ayam-kentang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d231b723b170981e/680x482cq70/rendang-ayam-kentang-foto-resep-utama.jpg
author: Max Abbott
ratingvalue: 4.1
reviewcount: 5
recipeingredient:
- "1 ekor ayam 2kg"
- "1/2 kg kentang potong besar"
- "6 sdm bumbu dasar merah           lihat resep"
- "4 sdm bumbu dasar kuning           lihat resep"
- "2 sachet santan instant 65 ml"
- "1 sdt garam selera"
- "1 sdt gula pasir selera"
- "3 iris gula merah selera"
- "600 ml air"
- " Bumbu Cemplung"
- "5 lbr daun salam"
- "2 lbr daun jeruk"
- "1 batang sereh memarkan"
- "5 cm kayu manis"
- "3 bh bunga lawang"
- "7 bh cengkeh"
- "2 bh kapulaga"
- "3 iris pala dihaluskan"
- "1 sdm ketumbar bubuk"
- "1/2 sdt lada bubuk"
recipeinstructions:
- "Siapkan bahannya."
- "Cuci bersih ayam beri perasan jeruk dan garam, diaduk rata biarkan beberapa saat. Cuci dan bilas kembali."
- "Tumis bumbu dasar merah, dan bumbu dasar kuning. Masukkan bumbu Cemplung biarkan harum. Masukkan ayam dan biarkan hingga ayam 1/2 empuk."
- "Masukkan potongan kentang. Beri santan instan dan biarkan mendidih. Tambahkan garam, gula pasir dan gula merah."
- "Biarkan hingga kuahnya sedikit dan mengental, koreksi rasa. Angkat dan sajikan."
categories:
- Resep
tags:
- rendang
- ayam
- kentang

katakunci: rendang ayam kentang 
nutrition: 225 calories
recipecuisine: Indonesian
preptime: "PT31M"
cooktime: "PT39M"
recipeyield: "3"
recipecategory: Dessert

---


![Rendang Ayam Kentang](https://img-global.cpcdn.com/recipes/d231b723b170981e/680x482cq70/rendang-ayam-kentang-foto-resep-utama.jpg)

Sebagai seorang wanita, menyajikan olahan mantab bagi keluarga tercinta adalah hal yang sangat menyenangkan bagi kita sendiri. Tugas seorang ibu Tidak sekadar menangani rumah saja, namun kamu juga wajib memastikan keperluan gizi tercukupi dan juga olahan yang dikonsumsi keluarga tercinta wajib nikmat.

Di masa  sekarang, kamu memang dapat mengorder olahan instan tanpa harus ribet mengolahnya lebih dulu. Namun banyak juga orang yang memang mau menghidangkan yang terenak untuk orang tercintanya. Lantaran, menyajikan masakan sendiri jauh lebih higienis dan kita juga bisa menyesuaikan sesuai dengan selera orang tercinta. 



Mungkinkah anda adalah salah satu penyuka rendang ayam kentang?. Tahukah kamu, rendang ayam kentang adalah sajian khas di Indonesia yang kini disukai oleh kebanyakan orang dari berbagai wilayah di Nusantara. Anda dapat memasak rendang ayam kentang kreasi sendiri di rumah dan pasti jadi camilan kegemaranmu di hari libur.

Kamu tak perlu bingung untuk mendapatkan rendang ayam kentang, karena rendang ayam kentang gampang untuk ditemukan dan juga anda pun boleh memasaknya sendiri di tempatmu. rendang ayam kentang boleh dimasak lewat berbagai cara. Saat ini ada banyak sekali cara modern yang membuat rendang ayam kentang lebih enak.

Resep rendang ayam kentang juga gampang sekali dibikin, lho. Kamu tidak perlu ribet-ribet untuk membeli rendang ayam kentang, lantaran Kamu mampu menyajikan ditempatmu. Bagi Kamu yang hendak mencobanya, dibawah ini merupakan cara untuk menyajikan rendang ayam kentang yang enak yang bisa Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Rendang Ayam Kentang:

1. Gunakan 1 ekor ayam (2kg)
1. Ambil 1/2 kg kentang potong besar
1. Sediakan 6 sdm bumbu dasar merah           (lihat resep)
1. Ambil 4 sdm bumbu dasar kuning           (lihat resep)
1. Ambil 2 sachet santan instant @65 ml
1. Gunakan 1 sdt garam (selera)
1. Ambil 1 sdt gula pasir (selera)
1. Gunakan 3 iris gula merah (selera)
1. Sediakan 600 ml air
1. Siapkan  Bumbu Cemplung:
1. Sediakan 5 lbr daun salam
1. Ambil 2 lbr daun jeruk
1. Gunakan 1 batang sereh memarkan
1. Gunakan 5 cm kayu manis
1. Siapkan 3 bh bunga lawang
1. Gunakan 7 bh cengkeh
1. Siapkan 2 bh kapulaga
1. Siapkan 3 iris pala dihaluskan
1. Gunakan 1 sdm ketumbar bubuk
1. Siapkan 1/2 sdt lada bubuk




<!--inarticleads2-->

##### Langkah-langkah membuat Rendang Ayam Kentang:

1. Siapkan bahannya.
1. Cuci bersih ayam beri perasan jeruk dan garam, diaduk rata biarkan beberapa saat. Cuci dan bilas kembali.
1. Tumis bumbu dasar merah, dan bumbu dasar kuning. Masukkan bumbu Cemplung biarkan harum. Masukkan ayam dan biarkan hingga ayam 1/2 empuk.
1. Masukkan potongan kentang. Beri santan instan dan biarkan mendidih. Tambahkan garam, gula pasir dan gula merah.
1. Biarkan hingga kuahnya sedikit dan mengental, koreksi rasa. Angkat dan sajikan.




Ternyata resep rendang ayam kentang yang lezat tidak ribet ini mudah banget ya! Kalian semua bisa memasaknya. Cara buat rendang ayam kentang Cocok banget buat anda yang sedang belajar memasak maupun juga bagi kamu yang sudah hebat dalam memasak.

Apakah kamu mau mulai mencoba buat resep rendang ayam kentang enak tidak ribet ini? Kalau mau, ayo kalian segera siapkan alat dan bahan-bahannya, kemudian buat deh Resep rendang ayam kentang yang mantab dan tidak ribet ini. Betul-betul mudah kan. 

Maka dari itu, daripada anda berfikir lama-lama, hayo kita langsung saja buat resep rendang ayam kentang ini. Dijamin kamu gak akan menyesal sudah buat resep rendang ayam kentang nikmat sederhana ini! Selamat berkreasi dengan resep rendang ayam kentang enak simple ini di tempat tinggal sendiri,oke!.

