---
description: "Cara buat Ayam kfc simpel, kriuk yang enak Untuk Jualan"
title: "Cara buat Ayam kfc simpel, kriuk yang enak Untuk Jualan"
slug: 383-cara-buat-ayam-kfc-simpel-kriuk-yang-enak-untuk-jualan
date: 2021-03-30T02:27:40.673Z
image: https://img-global.cpcdn.com/recipes/a90a4693f716ee5b/680x482cq70/ayam-kfc-simpel-kriuk-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a90a4693f716ee5b/680x482cq70/ayam-kfc-simpel-kriuk-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a90a4693f716ee5b/680x482cq70/ayam-kfc-simpel-kriuk-foto-resep-utama.jpg
author: Jeffrey Casey
ratingvalue: 3.8
reviewcount: 3
recipeingredient:
- "1/2 kg ayam"
- " bumbu marinasi"
- "2 bawang putih dihaluskan"
- "1/2 sdt lada bubuk"
- "1/2 sdt jahe bubuk optional yaa"
- "1/4 sdt kunyit bubuk"
- "secukupnya boncabe kalo mau pedes2"
- "1 sdt garam"
- " bumbu tepung"
- "4 sdm tepung"
- "2 sdm tepung maisena"
- "1/2 bks royko"
- "1/2 sdt baking soda optional"
- " air dingin"
- " minyak utk menggoreng"
recipeinstructions:
- "Cuci ayam sampai bersih, beri sayatan didagingnya agar meresap lalu beri bumbu marinasinya aduk2 sampai rata lalu diamkan di kulkas semalaman, kalo mau langsung di goreng minimal 2 jam udh di marinasi"
- "Campur semua bahan tepung pisahkan sedikit adonan tepungnya utk bahan basah, (setelah adonan diaduk rata ambil 2 sdm utk di campur air dingin)"
- "Lalu setelah ayam di marinasi, campur dengan tepung kering lalu celup ke tepung basah, kemudian ke tepung kering kembali sambil di pijat2 yah agar meresap"
- "Lalu panaskan minyaknya, setelah panas kecilkan api masukan ayam lalu goreng sampai coklat keemasan atau sampai benar2 kering kedalam"
- "Setelah dirasa sudah matang, angkat dan sajikan selagi hangat 😋😋😋😋😋"
categories:
- Resep
tags:
- ayam
- kfc
- simpel

katakunci: ayam kfc simpel 
nutrition: 100 calories
recipecuisine: Indonesian
preptime: "PT30M"
cooktime: "PT54M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam kfc simpel, kriuk](https://img-global.cpcdn.com/recipes/a90a4693f716ee5b/680x482cq70/ayam-kfc-simpel-kriuk-foto-resep-utama.jpg)

Selaku seorang wanita, mempersiapkan olahan nikmat untuk keluarga tercinta merupakan hal yang menyenangkan untuk kamu sendiri. Tugas seorang istri Tidak cuma menangani rumah saja, namun anda juga harus memastikan kebutuhan nutrisi terpenuhi dan santapan yang disantap anak-anak wajib enak.

Di masa  saat ini, kamu sebenarnya mampu mengorder santapan praktis walaupun tidak harus ribet mengolahnya terlebih dahulu. Tapi banyak juga lho mereka yang memang mau menghidangkan yang terbaik untuk orang yang dicintainya. Lantaran, menyajikan masakan yang dibuat sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan makanan tersebut sesuai dengan selera orang tercinta. 



Mungkinkah anda seorang penggemar ayam kfc simpel, kriuk?. Tahukah kamu, ayam kfc simpel, kriuk merupakan hidangan khas di Indonesia yang kini disenangi oleh orang-orang dari hampir setiap wilayah di Indonesia. Kalian bisa menyajikan ayam kfc simpel, kriuk olahan sendiri di rumah dan dapat dijadikan santapan favoritmu di akhir pekan.

Kalian tak perlu bingung jika kamu ingin memakan ayam kfc simpel, kriuk, karena ayam kfc simpel, kriuk tidak sulit untuk dicari dan juga kamu pun bisa memasaknya sendiri di rumah. ayam kfc simpel, kriuk dapat diolah dengan berbagai cara. Kini pun telah banyak banget resep kekinian yang membuat ayam kfc simpel, kriuk semakin lebih mantap.

Resep ayam kfc simpel, kriuk pun gampang dihidangkan, lho. Kamu jangan ribet-ribet untuk membeli ayam kfc simpel, kriuk, sebab Anda mampu menyiapkan ditempatmu. Bagi Kamu yang akan mencobanya, di bawah ini adalah resep untuk menyajikan ayam kfc simpel, kriuk yang enak yang bisa Anda coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Ayam kfc simpel, kriuk:

1. Sediakan 1/2 kg ayam
1. Gunakan  bumbu marinasi
1. Gunakan 2 bawang putih dihaluskan
1. Gunakan 1/2 sdt lada bubuk
1. Sediakan 1/2 sdt jahe bubuk (optional yaa)
1. Gunakan 1/4 sdt kunyit bubuk
1. Gunakan secukupnya boncabe (kalo mau pedes2)
1. Sediakan 1 sdt garam
1. Siapkan  bumbu tepung
1. Ambil 4 sdm tepung
1. Ambil 2 sdm tepung maisena
1. Sediakan 1/2 bks royko
1. Gunakan 1/2 sdt baking soda (optional)
1. Sediakan  air dingin
1. Gunakan  minyak utk menggoreng




<!--inarticleads2-->

##### Cara membuat Ayam kfc simpel, kriuk:

1. Cuci ayam sampai bersih, beri sayatan didagingnya agar meresap lalu beri bumbu marinasinya aduk2 sampai rata lalu diamkan di kulkas semalaman, kalo mau langsung di goreng minimal 2 jam udh di marinasi
1. Campur semua bahan tepung pisahkan sedikit adonan tepungnya utk bahan basah, (setelah adonan diaduk rata ambil 2 sdm utk di campur air dingin)
1. Lalu setelah ayam di marinasi, campur dengan tepung kering lalu celup ke tepung basah, kemudian ke tepung kering kembali sambil di pijat2 yah agar meresap
1. Lalu panaskan minyaknya, setelah panas kecilkan api masukan ayam lalu goreng sampai coklat keemasan atau sampai benar2 kering kedalam
1. Setelah dirasa sudah matang, angkat dan sajikan selagi hangat 😋😋😋😋😋




Wah ternyata cara buat ayam kfc simpel, kriuk yang lezat tidak rumit ini mudah banget ya! Kamu semua bisa memasaknya. Cara Membuat ayam kfc simpel, kriuk Sangat sesuai sekali untuk anda yang baru akan belajar memasak ataupun juga bagi anda yang telah ahli memasak.

Tertarik untuk mencoba buat resep ayam kfc simpel, kriuk lezat tidak ribet ini? Kalau anda ingin, ayo kamu segera buruan siapkan alat dan bahannya, lantas buat deh Resep ayam kfc simpel, kriuk yang nikmat dan tidak ribet ini. Sungguh taidak sulit kan. 

Jadi, daripada kamu berlama-lama, maka langsung aja hidangkan resep ayam kfc simpel, kriuk ini. Pasti kamu tiidak akan menyesal sudah bikin resep ayam kfc simpel, kriuk lezat sederhana ini! Selamat berkreasi dengan resep ayam kfc simpel, kriuk enak sederhana ini di tempat tinggal kalian sendiri,oke!.

