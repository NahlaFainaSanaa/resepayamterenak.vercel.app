---
description: "Cara membuat Kari Ayam Khas Aceh yang enak Untuk Jualan"
title: "Cara membuat Kari Ayam Khas Aceh yang enak Untuk Jualan"
slug: 176-cara-membuat-kari-ayam-khas-aceh-yang-enak-untuk-jualan
date: 2021-03-08T21:02:24.798Z
image: https://img-global.cpcdn.com/recipes/0d90e011ff21dcd7/680x482cq70/kari-ayam-khas-aceh-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0d90e011ff21dcd7/680x482cq70/kari-ayam-khas-aceh-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0d90e011ff21dcd7/680x482cq70/kari-ayam-khas-aceh-foto-resep-utama.jpg
author: Rebecca Morris
ratingvalue: 3.7
reviewcount: 10
recipeingredient:
- "1 ekor ayam 1 kg potong2 sesuai selera"
- "500 ml santan"
- "4 sdm kelapa gongseng bubuk"
- "2 sdm minyak utk menumis"
- " Bumbu ungkep tanpa air marinasi 1 "
- "1 sdt garam"
- "1 sdt kunyit bubuk"
- "1 sdt ketumbar"
- "1/2 sdt lada bubuk"
- "1 sdm air jeruk nipis"
- " Bumbu yang dihaluskan marinasi 2"
- "5 siung bawang merah"
- "3 siung bawang putih"
- "1 sdt ketumbar bubuk"
- "1/2 sdt lada bubuk"
- "1/2 sdt jinten"
- "1/4 buah pala"
- " Bumbu rempah tumisan "
- "2 siung bawang merah iris"
- "1 buah kapulaga"
- "1 buah bunga lawangcengkeh"
- "1 lembar daun pandan muda"
- "1 batang daun kari"
- " Seasoning sesuaikan selera"
- "1 sdt kaldu bubuk"
- "1 sdt garam"
- "1,5 sdt gula pasir"
recipeinstructions:
- "Daging ayam yg sudah dicuci bersih, dimasukkan kedlm wajan. Beri bumbu marinasi 1, aduk rata. Tanpa menggunakan air ya, krn nanti ayam akan mengeluarkan air kaldunya.  Tutup wajan, ungkep ayam hingga setengah matang (kurleb 15 menit). Sesekali diaduk."
- "Sambil menunggu ungkep ayam, siapkan bahan dan bumbu lainnya."
- "Setelah diungkep, daging ayam ditiriskan. Masukkan kedlm wadah. Beri bumbu yg dihaluskan dan kelapa gongseng. Tambahkan sekitar 5 sdm santan dari santan yg sdh disiapkan. Aduk secara merata. Biarkan ayam terlumuri bumbu beberapa saat (marinasi ke 2). Kurang lebih 3 menitan."
- "Panaskan minyak. Tumis bahan bumbu rempah tumisan hingga wangi. Lalu masukkan ayam beserta semua bumbu marinasinya. Masak sebentar.   Tambahkan santan sisa dan seasoning. Adukrata"
- "Masak ayam hingga kuahnya menyusut dan mengeluarkan minyak. Tes rasa. Matikan kompor. Sajikan."
categories:
- Resep
tags:
- kari
- ayam
- khas

katakunci: kari ayam khas 
nutrition: 288 calories
recipecuisine: Indonesian
preptime: "PT26M"
cooktime: "PT53M"
recipeyield: "2"
recipecategory: Dinner

---


![Kari Ayam Khas Aceh](https://img-global.cpcdn.com/recipes/0d90e011ff21dcd7/680x482cq70/kari-ayam-khas-aceh-foto-resep-utama.jpg)

Sebagai seorang wanita, mempersiapkan santapan lezat kepada famili adalah hal yang menyenangkan bagi anda sendiri. Tanggung jawab seorang ibu bukan hanya mengatur rumah saja, namun kamu juga wajib memastikan keperluan nutrisi tercukupi dan juga santapan yang dikonsumsi orang tercinta wajib lezat.

Di masa  sekarang, kamu sebenarnya bisa membeli hidangan siap saji walaupun tanpa harus ribet memasaknya terlebih dahulu. Tapi ada juga lho mereka yang memang ingin menghidangkan yang terbaik bagi orang yang dicintainya. Karena, memasak yang diolah sendiri jauh lebih higienis dan bisa menyesuaikan hidangan tersebut sesuai masakan kesukaan famili. 



Mungkinkah anda merupakan salah satu penikmat kari ayam khas aceh?. Tahukah kamu, kari ayam khas aceh merupakan makanan khas di Indonesia yang kini disenangi oleh setiap orang di berbagai tempat di Nusantara. Kita dapat memasak kari ayam khas aceh olahan sendiri di rumahmu dan boleh dijadikan santapan favoritmu di akhir pekan.

Kita jangan bingung jika kamu ingin mendapatkan kari ayam khas aceh, karena kari ayam khas aceh sangat mudah untuk dicari dan kalian pun boleh memasaknya sendiri di rumah. kari ayam khas aceh bisa dibuat dengan beraneka cara. Kini telah banyak banget cara modern yang menjadikan kari ayam khas aceh semakin lebih nikmat.

Resep kari ayam khas aceh pun gampang sekali dibuat, lho. Kamu jangan repot-repot untuk memesan kari ayam khas aceh, tetapi Kita mampu menyiapkan sendiri di rumah. Untuk Anda yang ingin mencobanya, berikut resep membuat kari ayam khas aceh yang lezat yang dapat Kamu hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Kari Ayam Khas Aceh:

1. Ambil 1 ekor ayam (1 kg, potong2 sesuai selera)
1. Sediakan 500 ml santan
1. Gunakan 4 sdm kelapa gongseng bubuk
1. Gunakan 2 sdm minyak utk menumis
1. Ambil  ⏩Bumbu ungkep tanpa air (marinasi 1) :
1. Gunakan 1 sdt garam
1. Sediakan 1 sdt kunyit bubuk
1. Ambil 1 sdt ketumbar
1. Ambil 1/2 sdt lada bubuk
1. Ambil 1 sdm air jeruk nipis
1. Ambil  ⏩Bumbu yang dihaluskan (marinasi 2)
1. Gunakan 5 siung bawang merah
1. Siapkan 3 siung bawang putih
1. Ambil 1 sdt ketumbar bubuk
1. Ambil 1/2 sdt lada bubuk
1. Gunakan 1/2 sdt jinten
1. Sediakan 1/4 buah pala
1. Sediakan  ⏩Bumbu rempah tumisan :
1. Sediakan 2 siung bawang merah, iris
1. Gunakan 1 buah kapulaga
1. Sediakan 1 buah bunga lawang/cengkeh
1. Sediakan 1 lembar daun pandan muda
1. Sediakan 1 batang daun kari
1. Gunakan  ⏩Seasoning (sesuaikan selera)
1. Siapkan 1 sdt kaldu bubuk
1. Siapkan 1 sdt garam
1. Ambil 1,5 sdt gula pasir




<!--inarticleads2-->

##### Cara menyiapkan Kari Ayam Khas Aceh:

1. Daging ayam yg sudah dicuci bersih, dimasukkan kedlm wajan. Beri bumbu marinasi 1, aduk rata. Tanpa menggunakan air ya, krn nanti ayam akan mengeluarkan air kaldunya. -  - Tutup wajan, ungkep ayam hingga setengah matang (kurleb 15 menit). Sesekali diaduk.
1. Sambil menunggu ungkep ayam, siapkan bahan dan bumbu lainnya.
1. Setelah diungkep, daging ayam ditiriskan. Masukkan kedlm wadah. Beri bumbu yg dihaluskan dan kelapa gongseng. Tambahkan sekitar 5 sdm santan dari santan yg sdh disiapkan. Aduk secara merata. Biarkan ayam terlumuri bumbu beberapa saat (marinasi ke 2). Kurang lebih 3 menitan.
1. Panaskan minyak. Tumis bahan bumbu rempah tumisan hingga wangi. Lalu masukkan ayam beserta semua bumbu marinasinya. Masak sebentar.  -  - Tambahkan santan sisa dan seasoning. Adukrata
1. Masak ayam hingga kuahnya menyusut dan mengeluarkan minyak. Tes rasa. Matikan kompor. Sajikan.




Wah ternyata cara membuat kari ayam khas aceh yang lezat tidak ribet ini gampang banget ya! Semua orang mampu mencobanya. Cara buat kari ayam khas aceh Sangat sesuai sekali buat kita yang baru akan belajar memasak maupun juga bagi anda yang telah jago memasak.

Tertarik untuk mencoba bikin resep kari ayam khas aceh mantab sederhana ini? Kalau mau, ayo kamu segera menyiapkan alat-alat dan bahannya, lantas bikin deh Resep kari ayam khas aceh yang enak dan tidak ribet ini. Sungguh taidak sulit kan. 

Oleh karena itu, daripada kamu berlama-lama, ayo kita langsung saja buat resep kari ayam khas aceh ini. Dijamin anda tiidak akan nyesel bikin resep kari ayam khas aceh enak tidak ribet ini! Selamat berkreasi dengan resep kari ayam khas aceh mantab simple ini di tempat tinggal kalian masing-masing,oke!.

