---
description: "Cara membuat Ayam Crispy Saus Bangkok yang enak dan Mudah Dibuat"
title: "Cara membuat Ayam Crispy Saus Bangkok yang enak dan Mudah Dibuat"
slug: 327-cara-membuat-ayam-crispy-saus-bangkok-yang-enak-dan-mudah-dibuat
date: 2021-07-04T20:21:12.342Z
image: https://img-global.cpcdn.com/recipes/10f965a98a4ac83f/680x482cq70/ayam-crispy-saus-bangkok-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/10f965a98a4ac83f/680x482cq70/ayam-crispy-saus-bangkok-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/10f965a98a4ac83f/680x482cq70/ayam-crispy-saus-bangkok-foto-resep-utama.jpg
author: Melvin Logan
ratingvalue: 3.4
reviewcount: 15
recipeingredient:
- "  Ayam Crispy "
- "150 gr daging ayam fillet me  bagian dada"
- "  Bumbu Marinasi "
- "2 siung bawang putih haluskan"
- "1 sdm kecap asin"
- "Secukupnya garam  lada bubuk"
- "  Tepung Pelapis "
- "80 gr tepung terigu"
- "20 gr tepung tapioka"
- "1/2 sdt baking powder"
- "Secukupnya garam lada bubuk  kaldu ayam bubuk"
- "1 butir telur kocok lepas"
- "  Saus Bangkok "
- "5 buah cabe rawit merah uleg kasar"
- "3 siung bawang putih cincang halus"
- "5 sdm gula pasir"
- "2 sdt garam"
- "3 sdm saus sambal botolan"
- "2 sdm saus tomat botolan"
- "2 sdm kecap ikan"
- "2 sdm air jeruk nipis"
- "300 ml air"
- "1/2 sdm tepung maizena larutkan dengan 50ml air"
- "  Tumis Pokchoy "
- "1 ikat pokchoy"
- "1 siung bawang putih geprek lalu cincang halus"
- "1 sdt saus tiram"
- "Secukupnya gula garam  sesikit air"
- "Secukupnya minyak  margarin untuk menumis"
recipeinstructions:
- "▶️ Ayam Crispy : Cuci ayam dengan jeruk nipis, lalu marinasi ayam selama 30 menit. Kemudian jika sudah, celupkan ayam pada kocokan telur lalu gulingkan pada tepung pelapis. Goreng hingga berubah warna menjadi kuning kecoklatan."
- "▶️ Saus Bangkok : Siapkan panci, masukan semua bahan kecuali larutan tepung maizena. Masak pada api kecil hingga mendidih, lalu masukan larutan tepung maizena sedikit demi sedikit. Aduk hingga semua bahan tercampur rata dan mengental. Jangan lupa untuk tes rasa, seimbangkan rasa saus perpaduan manis, asin, dan asam nya hingga seimbang. Angkat, sisihkan."
- "▶️ Tumis Pokchoy : Panaskan minyak + margarin, tumis bawang hingga berwarna kecoklatan. Masukan potongan pokchoy, tambahkan sedikit air, gula, garam, &amp; saus tiram. Aduk cepat, tes rasa. Angkat, sisihkan."
- "▶️ Penyelesaian : Taruh potongan ayam crispy pada piring, siram dengan saus bangkok. Sajikan bersama nasi hangat dan tumis pokchoy."
categories:
- Resep
tags:
- ayam
- crispy
- saus

katakunci: ayam crispy saus 
nutrition: 169 calories
recipecuisine: Indonesian
preptime: "PT20M"
cooktime: "PT30M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam Crispy Saus Bangkok](https://img-global.cpcdn.com/recipes/10f965a98a4ac83f/680x482cq70/ayam-crispy-saus-bangkok-foto-resep-utama.jpg)

Selaku seorang orang tua, menyuguhkan olahan nikmat buat famili adalah suatu hal yang sangat menyenangkan untuk kamu sendiri. Tugas seorang  wanita Tidak sekadar mengatur rumah saja, namun anda pun harus memastikan kebutuhan nutrisi tercukupi dan olahan yang disantap orang tercinta harus enak.

Di masa  saat ini, kita memang dapat memesan panganan siap saji walaupun tanpa harus susah mengolahnya dahulu. Tapi banyak juga lho mereka yang selalu mau menghidangkan yang terlezat bagi orang yang dicintainya. Pasalnya, memasak yang diolah sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan hidangan tersebut sesuai selera keluarga. 



Apakah kamu salah satu penggemar ayam crispy saus bangkok?. Asal kamu tahu, ayam crispy saus bangkok adalah sajian khas di Nusantara yang sekarang disukai oleh banyak orang di berbagai wilayah di Nusantara. Kalian dapat menghidangkan ayam crispy saus bangkok sendiri di rumah dan boleh jadi camilan kesenanganmu di akhir pekan.

Kamu tak perlu bingung untuk menyantap ayam crispy saus bangkok, karena ayam crispy saus bangkok tidak sulit untuk didapatkan dan juga kamu pun dapat menghidangkannya sendiri di rumah. ayam crispy saus bangkok boleh dibuat memalui beragam cara. Sekarang ada banyak banget resep kekinian yang membuat ayam crispy saus bangkok semakin nikmat.

Resep ayam crispy saus bangkok juga sangat mudah dibuat, lho. Kalian tidak usah capek-capek untuk membeli ayam crispy saus bangkok, karena Kamu mampu menyajikan di rumah sendiri. Untuk Kita yang hendak mencobanya, di bawah ini adalah resep untuk membuat ayam crispy saus bangkok yang nikamat yang bisa Kamu buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Ayam Crispy Saus Bangkok:

1. Siapkan  ▶️ Ayam Crispy :
1. Ambil 150 gr daging ayam fillet (me : bagian dada)
1. Sediakan  ▶️ Bumbu Marinasi :
1. Siapkan 2 siung bawang putih (haluskan)
1. Gunakan 1 sdm kecap asin
1. Sediakan Secukupnya garam &amp; lada bubuk
1. Gunakan  ▶️ Tepung Pelapis :
1. Sediakan 80 gr tepung terigu
1. Sediakan 20 gr tepung tapioka
1. Ambil 1/2 sdt baking powder
1. Ambil Secukupnya garam, lada bubuk, &amp; kaldu ayam bubuk
1. Ambil 1 butir telur (kocok lepas)
1. Ambil  ▶️ Saus Bangkok :
1. Ambil 5 buah cabe rawit merah (uleg kasar)
1. Sediakan 3 siung bawang putih (cincang halus)
1. Siapkan 5 sdm gula pasir
1. Sediakan 2 sdt garam
1. Siapkan 3 sdm saus sambal botolan
1. Gunakan 2 sdm saus tomat botolan
1. Sediakan 2 sdm kecap ikan
1. Siapkan 2 sdm air jeruk nipis
1. Siapkan 300 ml air
1. Sediakan 1/2 sdm tepung maizena (larutkan dengan 50ml air)
1. Sediakan  ▶️ Tumis Pokchoy :
1. Siapkan 1 ikat pokchoy
1. Siapkan 1 siung bawang putih (geprek, lalu cincang halus)
1. Ambil 1 sdt saus tiram
1. Siapkan Secukupnya gula, garam, &amp; sesikit air
1. Gunakan Secukupnya minyak + margarin (untuk menumis)




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam Crispy Saus Bangkok:

1. ▶️ Ayam Crispy : Cuci ayam dengan jeruk nipis, lalu marinasi ayam selama 30 menit. Kemudian jika sudah, celupkan ayam pada kocokan telur lalu gulingkan pada tepung pelapis. Goreng hingga berubah warna menjadi kuning kecoklatan.
1. ▶️ Saus Bangkok : Siapkan panci, masukan semua bahan kecuali larutan tepung maizena. Masak pada api kecil hingga mendidih, lalu masukan larutan tepung maizena sedikit demi sedikit. Aduk hingga semua bahan tercampur rata dan mengental. Jangan lupa untuk tes rasa, seimbangkan rasa saus perpaduan manis, asin, dan asam nya hingga seimbang. Angkat, sisihkan.
1. ▶️ Tumis Pokchoy : Panaskan minyak + margarin, tumis bawang hingga berwarna kecoklatan. Masukan potongan pokchoy, tambahkan sedikit air, gula, garam, &amp; saus tiram. Aduk cepat, tes rasa. Angkat, sisihkan.
1. ▶️ Penyelesaian : Taruh potongan ayam crispy pada piring, siram dengan saus bangkok. Sajikan bersama nasi hangat dan tumis pokchoy.




Wah ternyata cara membuat ayam crispy saus bangkok yang nikamt tidak ribet ini enteng banget ya! Kita semua dapat menghidangkannya. Cara Membuat ayam crispy saus bangkok Sesuai sekali buat kalian yang sedang belajar memasak ataupun juga untuk kalian yang sudah pandai memasak.

Apakah kamu tertarik mulai mencoba bikin resep ayam crispy saus bangkok lezat tidak ribet ini? Kalau kalian mau, ayo kalian segera buruan siapkan peralatan dan bahannya, lalu buat deh Resep ayam crispy saus bangkok yang nikmat dan sederhana ini. Benar-benar taidak sulit kan. 

Oleh karena itu, daripada kita berlama-lama, ayo kita langsung saja hidangkan resep ayam crispy saus bangkok ini. Dijamin kamu tiidak akan nyesel sudah bikin resep ayam crispy saus bangkok mantab simple ini! Selamat berkreasi dengan resep ayam crispy saus bangkok lezat tidak rumit ini di tempat tinggal kalian sendiri,ya!.

