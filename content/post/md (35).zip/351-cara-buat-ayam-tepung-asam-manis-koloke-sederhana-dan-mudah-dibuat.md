---
description: "Cara buat Ayam Tepung Asam Manis/ Koloke Sederhana dan Mudah Dibuat"
title: "Cara buat Ayam Tepung Asam Manis/ Koloke Sederhana dan Mudah Dibuat"
slug: 351-cara-buat-ayam-tepung-asam-manis-koloke-sederhana-dan-mudah-dibuat
date: 2021-06-24T12:03:32.571Z
image: https://img-global.cpcdn.com/recipes/f180156a8b080483/680x482cq70/ayam-tepung-asam-manis-koloke-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f180156a8b080483/680x482cq70/ayam-tepung-asam-manis-koloke-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f180156a8b080483/680x482cq70/ayam-tepung-asam-manis-koloke-foto-resep-utama.jpg
author: Rebecca Garner
ratingvalue: 3.6
reviewcount: 9
recipeingredient:
- " Marinade ayam"
- "1/2 kg Dada Ayam Fillet"
- "Secukupnya Garam Merica Bubuk"
- " Baluran Untuk Ayam"
- "Secukupnya Tepung Kanji"
- "2 btr Telur Ayam  secukupnya garam  merica bubuk"
- "7-8 sdm Tepung Segitiga  1sdm Tepung Kanji  secukupnya garam masako merica bubuk"
- "Secukupnya Minyak Goreng"
recipeinstructions:
- "Fillet ayam, potong semua menjadi kecil2 &amp; tipis2 sekitar 2x3cm (semakin tipis semakin enak)"
- "Marinade ayam dengan garam &amp; merica bubuk sesuai selera"
- "Balur ayam ke dalam 3 tahap: 1. Tepung Kanji, 2. Kocokan telur + garam + merica bubuk, 3. Campuran tepung segitiga + tepung kanji + garam + masako + merica bubuk.. Lakukan hal yg sama kepada semua potongan ayam dari no 1-3.."
- "Panaskan minyak, goreng pada api sedang hingga golden brown.. Angkat, tiriskan. Plating gorengan ayam &amp; siramkan saus asam manis..(boleh jg disajikan terpisah) Koloke siap dihidangkan &amp; dinikmati.. Semoga Syukaaa.. 😊"
categories:
- Resep
tags:
- ayam
- tepung
- asam

katakunci: ayam tepung asam 
nutrition: 165 calories
recipecuisine: Indonesian
preptime: "PT29M"
cooktime: "PT51M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam Tepung Asam Manis/ Koloke](https://img-global.cpcdn.com/recipes/f180156a8b080483/680x482cq70/ayam-tepung-asam-manis-koloke-foto-resep-utama.jpg)

Andai kamu seorang orang tua, menyuguhkan olahan menggugah selera kepada keluarga merupakan hal yang menyenangkan bagi kamu sendiri. Kewajiban seorang  wanita Tidak hanya mengerjakan pekerjaan rumah saja, tapi anda pun wajib memastikan kebutuhan nutrisi terpenuhi dan hidangan yang dikonsumsi anak-anak mesti menggugah selera.

Di masa  sekarang, kalian sebenarnya bisa mengorder hidangan yang sudah jadi walaupun tanpa harus repot memasaknya lebih dulu. Tapi banyak juga mereka yang selalu mau menghidangkan yang terenak untuk orang yang dicintainya. Karena, menyajikan masakan yang diolah sendiri jauh lebih bersih dan bisa menyesuaikan hidangan tersebut sesuai dengan makanan kesukaan famili. 



Apakah anda salah satu penyuka ayam tepung asam manis/ koloke?. Asal kamu tahu, ayam tepung asam manis/ koloke merupakan hidangan khas di Indonesia yang sekarang disukai oleh setiap orang dari berbagai tempat di Nusantara. Kamu bisa menghidangkan ayam tepung asam manis/ koloke sendiri di rumahmu dan dapat dijadikan santapan kesenanganmu di hari libur.

Kita tak perlu bingung jika kamu ingin mendapatkan ayam tepung asam manis/ koloke, lantaran ayam tepung asam manis/ koloke mudah untuk ditemukan dan kita pun bisa mengolahnya sendiri di tempatmu. ayam tepung asam manis/ koloke dapat diolah dengan beraneka cara. Sekarang telah banyak sekali resep modern yang membuat ayam tepung asam manis/ koloke semakin lebih nikmat.

Resep ayam tepung asam manis/ koloke pun mudah sekali dibuat, lho. Anda jangan repot-repot untuk membeli ayam tepung asam manis/ koloke, tetapi Anda mampu menghidangkan di rumahmu. Untuk Anda yang ingin menyajikannya, di bawah ini adalah cara untuk menyajikan ayam tepung asam manis/ koloke yang enak yang bisa Kalian hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Ayam Tepung Asam Manis/ Koloke:

1. Siapkan  Marinade ayam:
1. Siapkan 1/2 kg Dada Ayam Fillet
1. Sediakan Secukupnya Garam, Merica Bubuk
1. Ambil  Baluran Untuk Ayam:
1. Sediakan Secukupnya Tepung Kanji
1. Siapkan 2 btr Telur Ayam + secukupnya garam &amp; merica bubuk
1. Ambil 7-8 sdm Tepung Segitiga + 1½sdm Tepung Kanji + secukupnya garam, masako, merica bubuk
1. Siapkan Secukupnya Minyak Goreng




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam Tepung Asam Manis/ Koloke:

1. Fillet ayam, potong semua menjadi kecil2 &amp; tipis2 sekitar 2x3cm (semakin tipis semakin enak)
1. Marinade ayam dengan garam &amp; merica bubuk sesuai selera
1. Balur ayam ke dalam 3 tahap: 1. Tepung Kanji, 2. Kocokan telur + garam + merica bubuk, 3. Campuran tepung segitiga + tepung kanji + garam + masako + merica bubuk.. Lakukan hal yg sama kepada semua potongan ayam dari no 1-3..
1. Panaskan minyak, goreng pada api sedang hingga golden brown.. Angkat, tiriskan. Plating gorengan ayam &amp; siramkan saus asam manis..(boleh jg disajikan terpisah) Koloke siap dihidangkan &amp; dinikmati.. Semoga Syukaaa.. 😊




Wah ternyata cara membuat ayam tepung asam manis/ koloke yang nikamt tidak rumit ini gampang banget ya! Kamu semua bisa membuatnya. Cara Membuat ayam tepung asam manis/ koloke Sesuai sekali buat kamu yang baru belajar memasak maupun untuk kalian yang sudah ahli dalam memasak.

Tertarik untuk mulai mencoba membikin resep ayam tepung asam manis/ koloke lezat sederhana ini? Kalau anda tertarik, ayo kalian segera siapkan alat dan bahannya, lalu buat deh Resep ayam tepung asam manis/ koloke yang enak dan tidak ribet ini. Sungguh mudah kan. 

Maka, daripada kita diam saja, ayo langsung aja bikin resep ayam tepung asam manis/ koloke ini. Dijamin kamu tak akan menyesal sudah membuat resep ayam tepung asam manis/ koloke lezat simple ini! Selamat mencoba dengan resep ayam tepung asam manis/ koloke mantab tidak ribet ini di rumah masing-masing,ya!.

