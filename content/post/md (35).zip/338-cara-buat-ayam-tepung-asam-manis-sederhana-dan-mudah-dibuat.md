---
description: "Cara buat Ayam Tepung Asam Manis Sederhana dan Mudah Dibuat"
title: "Cara buat Ayam Tepung Asam Manis Sederhana dan Mudah Dibuat"
slug: 338-cara-buat-ayam-tepung-asam-manis-sederhana-dan-mudah-dibuat
date: 2021-06-22T11:40:02.636Z
image: https://img-global.cpcdn.com/recipes/f9690e69657f8834/680x482cq70/ayam-tepung-asam-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f9690e69657f8834/680x482cq70/ayam-tepung-asam-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f9690e69657f8834/680x482cq70/ayam-tepung-asam-manis-foto-resep-utama.jpg
author: Elnora Powers
ratingvalue: 4.2
reviewcount: 4
recipeingredient:
- "1 buah dada ayam cuci bersih"
- "1/2 sdt bawang putih bubuk"
- "secukupnya Garam"
- "secukupnya Kaldu jamur"
- " Tepung krispi serbaguna"
- "1 buah bawang bombay"
- "2 siung bawang putih"
- "2 buah cabe merah besar"
- "2 buah cabe hijau besar"
- "1 sdt saus tiram"
- "1 sdt kecap manis"
- "5 sdm saus tomat"
- "secukupnya Taburan wijen"
recipeinstructions:
- "Potong dadu dada ayam lumuri dengan bawang putih bubuk, garam, dan kaldu jamur aduk sampai rata cek rasa. Diamkan dikulkas selama 3-4 jam. Setelah 3 jam keluarkan dari kulkas, baluri dengan tepung serbaguna aduk rata diamkan hingga suhu ruangan."
- "Kemudian siapkan tepung serbaguna kering dan panaskan minyak goreng. Baluri ayam dengan tepung kering kemudian goreng hingga kecoklatan angkat dan sisihkan."
- "Tumis duo bawang dan cabe hingga harum tambahkan sedikit air masak hingga layu."
- "Tambahkan saus tiram, kecap manis, saus tomat, garam dan kaldu bubuk. Aduk rata dan cek rasa."
- "Masukkan ayam goreng aduk rata sebentar saja. Pindahkan ke mangkuk lalu taburi wijen."
categories:
- Resep
tags:
- ayam
- tepung
- asam

katakunci: ayam tepung asam 
nutrition: 161 calories
recipecuisine: Indonesian
preptime: "PT40M"
cooktime: "PT37M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Tepung Asam Manis](https://img-global.cpcdn.com/recipes/f9690e69657f8834/680x482cq70/ayam-tepung-asam-manis-foto-resep-utama.jpg)

Sebagai seorang ibu, menyediakan masakan sedap buat keluarga adalah suatu hal yang membahagiakan untuk kita sendiri. Kewajiban seorang  wanita bukan saja menangani rumah saja, namun anda pun harus memastikan keperluan nutrisi tercukupi dan olahan yang dimakan anak-anak harus menggugah selera.

Di era  saat ini, anda memang bisa mengorder hidangan jadi meski tidak harus repot memasaknya dulu. Namun banyak juga lho orang yang selalu ingin memberikan hidangan yang terlezat untuk orang yang dicintainya. Pasalnya, menyajikan masakan yang diolah sendiri jauh lebih higienis dan kita juga bisa menyesuaikan masakan tersebut berdasarkan kesukaan keluarga tercinta. 



Mungkinkah anda seorang penggemar ayam tepung asam manis?. Asal kamu tahu, ayam tepung asam manis merupakan sajian khas di Nusantara yang sekarang disukai oleh setiap orang di berbagai tempat di Nusantara. Kamu bisa menyajikan ayam tepung asam manis sendiri di rumahmu dan pasti jadi santapan favoritmu di hari libur.

Anda tidak perlu bingung jika kamu ingin memakan ayam tepung asam manis, karena ayam tepung asam manis mudah untuk didapatkan dan juga kamu pun dapat memasaknya sendiri di tempatmu. ayam tepung asam manis dapat dimasak memalui beraneka cara. Kini pun telah banyak sekali resep kekinian yang menjadikan ayam tepung asam manis semakin enak.

Resep ayam tepung asam manis pun sangat gampang dibikin, lho. Kita jangan ribet-ribet untuk membeli ayam tepung asam manis, sebab Kita mampu menyajikan ditempatmu. Bagi Kita yang akan membuatnya, di bawah ini adalah cara menyajikan ayam tepung asam manis yang nikamat yang bisa Kalian coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Ayam Tepung Asam Manis:

1. Siapkan 1 buah dada ayam cuci bersih
1. Sediakan 1/2 sdt bawang putih bubuk
1. Sediakan secukupnya Garam
1. Ambil secukupnya Kaldu jamur
1. Siapkan  Tepung krispi serbaguna
1. Gunakan 1 buah bawang bombay
1. Sediakan 2 siung bawang putih
1. Siapkan 2 buah cabe merah besar
1. Siapkan 2 buah cabe hijau besar
1. Siapkan 1 sdt saus tiram
1. Sediakan 1 sdt kecap manis
1. Ambil 5 sdm saus tomat
1. Siapkan secukupnya Taburan wijen




<!--inarticleads2-->

##### Cara membuat Ayam Tepung Asam Manis:

1. Potong dadu dada ayam lumuri dengan bawang putih bubuk, garam, dan kaldu jamur aduk sampai rata cek rasa. Diamkan dikulkas selama 3-4 jam. Setelah 3 jam keluarkan dari kulkas, baluri dengan tepung serbaguna aduk rata diamkan hingga suhu ruangan.
1. Kemudian siapkan tepung serbaguna kering dan panaskan minyak goreng. Baluri ayam dengan tepung kering kemudian goreng hingga kecoklatan angkat dan sisihkan.
1. Tumis duo bawang dan cabe hingga harum tambahkan sedikit air masak hingga layu.
1. Tambahkan saus tiram, kecap manis, saus tomat, garam dan kaldu bubuk. Aduk rata dan cek rasa.
1. Masukkan ayam goreng aduk rata sebentar saja. Pindahkan ke mangkuk lalu taburi wijen.




Ternyata cara buat ayam tepung asam manis yang nikamt tidak ribet ini mudah banget ya! Semua orang dapat menghidangkannya. Cara Membuat ayam tepung asam manis Sangat sesuai banget buat kita yang baru mau belajar memasak atau juga bagi anda yang sudah jago memasak.

Tertarik untuk mencoba membuat resep ayam tepung asam manis lezat sederhana ini? Kalau mau, ayo kalian segera buruan menyiapkan alat dan bahannya, setelah itu bikin deh Resep ayam tepung asam manis yang enak dan sederhana ini. Sungguh taidak sulit kan. 

Maka, ketimbang kalian diam saja, ayo langsung aja buat resep ayam tepung asam manis ini. Pasti kamu gak akan nyesel sudah buat resep ayam tepung asam manis nikmat simple ini! Selamat mencoba dengan resep ayam tepung asam manis enak tidak ribet ini di tempat tinggal sendiri,oke!.

