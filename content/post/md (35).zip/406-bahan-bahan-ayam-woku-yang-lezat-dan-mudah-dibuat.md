---
description: "Bahan-bahan Ayam woku yang lezat dan Mudah Dibuat"
title: "Bahan-bahan Ayam woku yang lezat dan Mudah Dibuat"
slug: 406-bahan-bahan-ayam-woku-yang-lezat-dan-mudah-dibuat
date: 2021-01-16T20:02:53.576Z
image: https://img-global.cpcdn.com/recipes/971df61ed7ce6d07/680x482cq70/ayam-woku-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/971df61ed7ce6d07/680x482cq70/ayam-woku-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/971df61ed7ce6d07/680x482cq70/ayam-woku-foto-resep-utama.jpg
author: Chase Goodwin
ratingvalue: 4.5
reviewcount: 10
recipeingredient:
- "1 ekor ayam kampung cuci bersih"
- "1 batang serai"
- "2 lembar daun salam"
- "1 lembar daun kunyit"
- "3 lembar daun jeruk"
- "2 ikat kemangi"
- "1/2 buah tomat potong2"
- "1 batang daun bawang potong 1 cm"
- " Bumbu halus"
- "1 ruas kunyit"
- "1/2 ruas jahe"
- "4 buah cabe merah sesuaikan rasa pedasnya dg selera"
- "10 siung bawang merah"
- "2 siung bawang putih"
- "6 siung kemiri"
- "Secukupnya garamkaldu"
recipeinstructions:
- "Lumuri ayam.dg garam dan jeruk lemon"
- "Tumis bumbu halus hg matang, masukkan ayam aduk rata. Lalu tambahkan air, masak hg ayam matang."
- "Tes rasa, masukkan kemangi+tomat+daun bawang+½ sdt air lemon, aduk sebentar. Angkat"
categories:
- Resep
tags:
- ayam
- woku

katakunci: ayam woku 
nutrition: 162 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT42M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam woku](https://img-global.cpcdn.com/recipes/971df61ed7ce6d07/680x482cq70/ayam-woku-foto-resep-utama.jpg)

Jika kalian seorang ibu, menyediakan masakan menggugah selera pada keluarga adalah suatu hal yang menggembirakan bagi anda sendiri. Tugas seorang ibu bukan cuman mengerjakan pekerjaan rumah saja, tapi anda pun wajib memastikan kebutuhan gizi terpenuhi dan juga olahan yang dikonsumsi keluarga tercinta wajib nikmat.

Di zaman  sekarang, kalian sebenarnya bisa memesan olahan jadi walaupun tidak harus capek membuatnya dahulu. Tapi banyak juga mereka yang selalu mau memberikan yang terenak untuk orang yang dicintainya. Karena, menghidangkan masakan yang diolah sendiri jauh lebih bersih dan kita juga bisa menyesuaikan makanan tersebut sesuai selera keluarga tercinta. 



Mungkinkah kamu seorang penggemar ayam woku?. Asal kamu tahu, ayam woku merupakan sajian khas di Indonesia yang sekarang disenangi oleh kebanyakan orang di berbagai wilayah di Nusantara. Anda bisa memasak ayam woku buatan sendiri di rumahmu dan pasti jadi makanan kesenanganmu di hari libur.

Anda tidak perlu bingung jika kamu ingin menyantap ayam woku, karena ayam woku tidak sukar untuk didapatkan dan juga anda pun boleh menghidangkannya sendiri di rumah. ayam woku boleh dimasak lewat berbagai cara. Kini pun telah banyak banget resep kekinian yang menjadikan ayam woku semakin lebih mantap.

Resep ayam woku pun gampang sekali dihidangkan, lho. Kita tidak usah repot-repot untuk membeli ayam woku, tetapi Kamu mampu menyiapkan di rumah sendiri. Bagi Anda yang hendak menghidangkannya, dibawah ini merupakan cara membuat ayam woku yang enak yang dapat Anda buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Ayam woku:

1. Gunakan 1 ekor ayam kampung, cuci bersih
1. Sediakan 1 batang serai
1. Gunakan 2 lembar daun salam
1. Ambil 1 lembar daun kunyit
1. Siapkan 3 lembar daun jeruk
1. Sediakan 2 ikat kemangi
1. Sediakan 1/2 buah tomat potong2
1. Sediakan 1 batang daun bawang, potong 1 cm
1. Gunakan  Bumbu halus
1. Gunakan 1 ruas kunyit
1. Ambil 1/2 ruas jahe
1. Siapkan 4 buah cabe merah (sesuaikan rasa pedasnya dg selera)
1. Gunakan 10 siung bawang merah
1. Siapkan 2 siung bawang putih
1. Gunakan 6 siung kemiri
1. Gunakan Secukupnya garam,kaldu




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam woku:

1. Lumuri ayam.dg garam dan jeruk lemon
1. Tumis bumbu halus hg matang, masukkan ayam aduk rata. Lalu tambahkan air, masak hg ayam matang.
1. Tes rasa, masukkan kemangi+tomat+daun bawang+½ sdt air lemon, aduk sebentar. Angkat




Ternyata resep ayam woku yang enak tidak rumit ini gampang sekali ya! Anda Semua bisa memasaknya. Resep ayam woku Sangat sesuai banget buat kamu yang baru akan belajar memasak maupun untuk kamu yang sudah pandai memasak.

Apakah kamu tertarik mulai mencoba buat resep ayam woku enak sederhana ini? Kalau kalian tertarik, mending kamu segera siapkan alat dan bahannya, maka buat deh Resep ayam woku yang mantab dan sederhana ini. Sangat mudah kan. 

Maka dari itu, ketimbang kamu diam saja, hayo kita langsung saja hidangkan resep ayam woku ini. Pasti anda gak akan nyesel bikin resep ayam woku lezat simple ini! Selamat mencoba dengan resep ayam woku mantab tidak rumit ini di tempat tinggal sendiri,oke!.

