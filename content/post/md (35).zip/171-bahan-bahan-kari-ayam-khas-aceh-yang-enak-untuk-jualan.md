---
description: "Bahan-bahan Kari Ayam Khas Aceh yang enak Untuk Jualan"
title: "Bahan-bahan Kari Ayam Khas Aceh yang enak Untuk Jualan"
slug: 171-bahan-bahan-kari-ayam-khas-aceh-yang-enak-untuk-jualan
date: 2021-03-08T20:13:49.870Z
image: https://img-global.cpcdn.com/recipes/fc533e05e81c011b/680x482cq70/kari-ayam-khas-aceh-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/fc533e05e81c011b/680x482cq70/kari-ayam-khas-aceh-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/fc533e05e81c011b/680x482cq70/kari-ayam-khas-aceh-foto-resep-utama.jpg
author: Russell Hall
ratingvalue: 4.1
reviewcount: 9
recipeingredient:
- "500 gr ayam"
- "1 sdm ketumbar bubuk"
- "1/2 sdm kunyit bubuk"
- " Perasan jeruk nipis"
- "1 sdt garam"
- "1 sdt gula"
- "1/2 sdt kaldu bubuk"
- "200 ml santan instant kara"
- " Bumbu Halus"
- "4 siung bawang putih"
- "8 butir bawang merah"
- "7 buah cabe merah keriting"
- "15 buah cabe rawit merah"
- "1 sdt ketumbar"
- "1/2 sdt lada"
- "1/2 sdt pala"
- "1/4 sdt adas"
- "1/4 sdt jinten"
- "4 sdm kelapa sangrai yang dihaluskan"
- " Bumbu Rempah Tumisan"
- "1 butir bawang merah iris"
- "3 butir cengkeh"
- "1 buah bunga lawang"
- "2 buah kapulaga"
- "1 lembar daun pandan"
- "1 batang daun kari"
recipeinstructions:
- "Ungkep ayam dengan ketumbar, kunyit, perasan jeruk nipis dan garam, sisihkan"
- "Uleg bumbu halus"
- "Tambahkan kelapa sangrai yang dihaluskan bersama bumbu halus"
- "Campur bumbu halus, ayam ungkep dan santan. Aduk rata dan biarkan sebentar agar bumbu meresap"
- "Tumis bumbu rempah hingga wangi lalu masukkan ayam yang sudah terbalur bumbu. Aduk rata"
- "Tambahkan air dan masak hingga kuah menyusut dan ayam matang. Sajikan"
categories:
- Resep
tags:
- kari
- ayam
- khas

katakunci: kari ayam khas 
nutrition: 253 calories
recipecuisine: Indonesian
preptime: "PT10M"
cooktime: "PT55M"
recipeyield: "4"
recipecategory: Dinner

---


![Kari Ayam Khas Aceh](https://img-global.cpcdn.com/recipes/fc533e05e81c011b/680x482cq70/kari-ayam-khas-aceh-foto-resep-utama.jpg)

Selaku seorang yang hobi memasak, menyuguhkan olahan nikmat bagi keluarga merupakan suatu hal yang menyenangkan untuk kita sendiri. Kewajiban seorang  wanita Tidak cuma menangani rumah saja, tapi anda juga harus menyediakan kebutuhan nutrisi tercukupi dan santapan yang dimakan keluarga tercinta harus enak.

Di masa  sekarang, kamu memang dapat mengorder olahan instan meski tanpa harus capek mengolahnya terlebih dahulu. Namun banyak juga lho mereka yang selalu mau memberikan makanan yang terenak untuk orang tercintanya. Lantaran, menghidangkan masakan yang dibuat sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan berdasarkan kesukaan keluarga tercinta. 



Mungkinkah anda adalah seorang penggemar kari ayam khas aceh?. Tahukah kamu, kari ayam khas aceh adalah sajian khas di Nusantara yang kini digemari oleh kebanyakan orang dari berbagai wilayah di Nusantara. Kamu dapat menghidangkan kari ayam khas aceh sendiri di rumah dan boleh jadi camilan kesukaanmu di akhir pekan.

Kita jangan bingung jika kamu ingin menyantap kari ayam khas aceh, lantaran kari ayam khas aceh sangat mudah untuk ditemukan dan anda pun dapat membuatnya sendiri di rumah. kari ayam khas aceh boleh dibuat lewat berbagai cara. Sekarang sudah banyak banget cara modern yang menjadikan kari ayam khas aceh semakin nikmat.

Resep kari ayam khas aceh pun gampang untuk dibikin, lho. Kalian tidak perlu ribet-ribet untuk membeli kari ayam khas aceh, lantaran Anda mampu menyiapkan di rumahmu. Bagi Kamu yang ingin mencobanya, inilah cara menyajikan kari ayam khas aceh yang enak yang bisa Anda buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Kari Ayam Khas Aceh:

1. Ambil 500 gr ayam
1. Siapkan 1 sdm ketumbar bubuk
1. Gunakan 1/2 sdm kunyit bubuk
1. Sediakan  Perasan jeruk nipis
1. Gunakan 1 sdt garam
1. Gunakan 1 sdt gula
1. Gunakan 1/2 sdt kaldu bubuk
1. Gunakan 200 ml santan instant kara
1. Ambil  Bumbu Halus
1. Gunakan 4 siung bawang putih
1. Ambil 8 butir bawang merah
1. Ambil 7 buah cabe merah keriting
1. Gunakan 15 buah cabe rawit merah
1. Ambil 1 sdt ketumbar
1. Ambil 1/2 sdt lada
1. Sediakan 1/2 sdt pala
1. Siapkan 1/4 sdt adas
1. Gunakan 1/4 sdt jinten
1. Ambil 4 sdm kelapa sangrai yang dihaluskan
1. Ambil  Bumbu Rempah Tumisan
1. Siapkan 1 butir bawang merah, iris
1. Sediakan 3 butir cengkeh
1. Gunakan 1 buah bunga lawang
1. Gunakan 2 buah kapulaga
1. Siapkan 1 lembar daun pandan
1. Siapkan 1 batang daun kari




<!--inarticleads2-->

##### Langkah-langkah membuat Kari Ayam Khas Aceh:

1. Ungkep ayam dengan ketumbar, kunyit, perasan jeruk nipis dan garam, sisihkan
1. Uleg bumbu halus
1. Tambahkan kelapa sangrai yang dihaluskan bersama bumbu halus
1. Campur bumbu halus, ayam ungkep dan santan. Aduk rata dan biarkan sebentar agar bumbu meresap
1. Tumis bumbu rempah hingga wangi lalu masukkan ayam yang sudah terbalur bumbu. Aduk rata
1. Tambahkan air dan masak hingga kuah menyusut dan ayam matang. Sajikan




Wah ternyata resep kari ayam khas aceh yang lezat simple ini gampang banget ya! Kalian semua mampu memasaknya. Resep kari ayam khas aceh Sangat sesuai banget buat kalian yang sedang belajar memasak atau juga untuk anda yang sudah pandai memasak.

Tertarik untuk mencoba buat resep kari ayam khas aceh enak tidak ribet ini? Kalau kalian tertarik, mending kamu segera buruan menyiapkan alat-alat dan bahan-bahannya, setelah itu bikin deh Resep kari ayam khas aceh yang nikmat dan sederhana ini. Betul-betul gampang kan. 

Jadi, ketimbang kalian berfikir lama-lama, ayo langsung aja bikin resep kari ayam khas aceh ini. Dijamin kalian tiidak akan menyesal sudah bikin resep kari ayam khas aceh nikmat sederhana ini! Selamat berkreasi dengan resep kari ayam khas aceh lezat sederhana ini di rumah masing-masing,ya!.

