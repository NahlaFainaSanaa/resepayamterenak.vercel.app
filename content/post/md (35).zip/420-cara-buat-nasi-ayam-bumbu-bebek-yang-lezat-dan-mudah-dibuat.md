---
description: "Cara buat Nasi Ayam Bumbu Bebek yang lezat dan Mudah Dibuat"
title: "Cara buat Nasi Ayam Bumbu Bebek yang lezat dan Mudah Dibuat"
slug: 420-cara-buat-nasi-ayam-bumbu-bebek-yang-lezat-dan-mudah-dibuat
date: 2021-05-11T16:50:25.903Z
image: https://img-global.cpcdn.com/recipes/35a7faf9c4ae2cb7/680x482cq70/nasi-ayam-bumbu-bebek-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/35a7faf9c4ae2cb7/680x482cq70/nasi-ayam-bumbu-bebek-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/35a7faf9c4ae2cb7/680x482cq70/nasi-ayam-bumbu-bebek-foto-resep-utama.jpg
author: Allen McGuire
ratingvalue: 3.6
reviewcount: 12
recipeingredient:
- "500 gr Ayam potong sesuai selera"
- "2 btg Serai boleh digeprek atau dihaluskan bersama bumbu halus"
- "10 lmbr Daun jeruk"
- "2 lmbr Daun salam"
- " Bumbu halus "
- "5 bh Bawang putih"
- "2 cm Kunyit"
- "3 bh Kemiri"
- "5 cm lengkuas"
- "5 bh Cabe merah buang isinya"
- "2 cm Jahe"
- "1/2 sdm Ketumbar"
- "1/2 sdm Gula merah"
- "Secukupnya Garam"
- "1 sdt Air asam jawa"
- " Pelengkap "
- " Nasi hangat"
- " Sambel korek"
- " Lalapan"
recipeinstructions:
- "Tumis bumbu halus sampai wangi dan matang. Tambahkan air masak sampai mendidih &amp; air menyusut. Tambahkan minyak tumis kembali bumbu halus sampai kadar air menyusut &amp; habis. Boleh diulang2 metode tersebut sampai mendapatkan warna gelap seperti bumbu bebek hitam madura."
- "Masukan ayam kedalam panci presto beri bumbu halus yg sudah ditumis. Tambahkan serai, daun jeruk &amp; daun salam. Presto selama 2 menit jangan kelamaan ya nanti hancur ayamnya... 😁"
- "Angkat ayam tiriskan dari bumbunya. Tumis kembali bumbu sampai kadar air hilang boleh ditambahkan minyak bila dirasa kurang..."
- "Penyelesaian : goreng ayam sampai kecoklatan, tiriskan. Tata ayam goreng, nasi hangat beri diatas nasi bumbu kuningnya. Beri sambal korek &amp; lalapan...."
- "Enjoooyyy.... 😁👌😋"
categories:
- Resep
tags:
- nasi
- ayam
- bumbu

katakunci: nasi ayam bumbu 
nutrition: 148 calories
recipecuisine: Indonesian
preptime: "PT32M"
cooktime: "PT42M"
recipeyield: "1"
recipecategory: Lunch

---


![Nasi Ayam Bumbu Bebek](https://img-global.cpcdn.com/recipes/35a7faf9c4ae2cb7/680x482cq70/nasi-ayam-bumbu-bebek-foto-resep-utama.jpg)

Selaku seorang yang hobi memasak, menyediakan panganan enak buat orang tercinta merupakan hal yang menyenangkan untuk kamu sendiri. Tugas seorang  wanita bukan cuma mengerjakan pekerjaan rumah saja, tetapi kamu juga harus memastikan kebutuhan nutrisi tercukupi dan masakan yang dimakan anak-anak mesti menggugah selera.

Di zaman  sekarang, kamu memang bisa membeli panganan yang sudah jadi walaupun tanpa harus susah memasaknya dulu. Tapi banyak juga lho orang yang memang mau memberikan makanan yang terlezat bagi orang tercintanya. Pasalnya, menyajikan masakan sendiri jauh lebih higienis dan bisa menyesuaikan sesuai makanan kesukaan keluarga tercinta. 



Mungkinkah kamu salah satu penyuka nasi ayam bumbu bebek?. Tahukah kamu, nasi ayam bumbu bebek merupakan makanan khas di Nusantara yang saat ini disukai oleh setiap orang di berbagai wilayah di Nusantara. Kalian dapat memasak nasi ayam bumbu bebek olahan sendiri di rumah dan pasti jadi camilan kegemaranmu di akhir pekan.

Kita tak perlu bingung jika kamu ingin menyantap nasi ayam bumbu bebek, karena nasi ayam bumbu bebek tidak sulit untuk ditemukan dan juga kamu pun dapat mengolahnya sendiri di rumah. nasi ayam bumbu bebek bisa dimasak dengan beraneka cara. Kini sudah banyak banget cara modern yang membuat nasi ayam bumbu bebek lebih enak.

Resep nasi ayam bumbu bebek pun mudah sekali untuk dibikin, lho. Anda tidak usah capek-capek untuk memesan nasi ayam bumbu bebek, tetapi Anda bisa menyiapkan ditempatmu. Bagi Kalian yang akan menghidangkannya, dibawah ini merupakan cara membuat nasi ayam bumbu bebek yang nikamat yang bisa Anda coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Nasi Ayam Bumbu Bebek:

1. Ambil 500 gr Ayam, potong sesuai selera
1. Siapkan 2 btg Serai (boleh digeprek atau dihaluskan bersama bumbu halus)
1. Sediakan 10 lmbr Daun jeruk
1. Gunakan 2 lmbr Daun salam
1. Ambil  Bumbu halus :
1. Gunakan 5 bh Bawang putih
1. Gunakan 2 cm Kunyit
1. Ambil 3 bh Kemiri
1. Ambil 5 cm lengkuas
1. Ambil 5 bh Cabe merah, buang isinya
1. Ambil 2 cm Jahe
1. Ambil 1/2 sdm Ketumbar
1. Sediakan 1/2 sdm Gula merah
1. Siapkan Secukupnya Garam
1. Ambil 1 sdt Air asam jawa
1. Siapkan  Pelengkap :
1. Siapkan  Nasi hangat
1. Sediakan  Sambel korek
1. Gunakan  Lalapan




<!--inarticleads2-->

##### Langkah-langkah membuat Nasi Ayam Bumbu Bebek:

1. Tumis bumbu halus sampai wangi dan matang. Tambahkan air masak sampai mendidih &amp; air menyusut. Tambahkan minyak tumis kembali bumbu halus sampai kadar air menyusut &amp; habis. Boleh diulang2 metode tersebut sampai mendapatkan warna gelap seperti bumbu bebek hitam madura.
1. Masukan ayam kedalam panci presto beri bumbu halus yg sudah ditumis. Tambahkan serai, daun jeruk &amp; daun salam. Presto selama 2 menit jangan kelamaan ya nanti hancur ayamnya... 😁
1. Angkat ayam tiriskan dari bumbunya. Tumis kembali bumbu sampai kadar air hilang boleh ditambahkan minyak bila dirasa kurang...
1. Penyelesaian : goreng ayam sampai kecoklatan, tiriskan. Tata ayam goreng, nasi hangat beri diatas nasi bumbu kuningnya. Beri sambal korek &amp; lalapan....
1. Enjoooyyy.... 😁👌😋




Wah ternyata resep nasi ayam bumbu bebek yang nikamt tidak rumit ini enteng sekali ya! Semua orang bisa menghidangkannya. Cara buat nasi ayam bumbu bebek Sangat sesuai sekali untuk anda yang baru mau belajar memasak ataupun juga bagi kalian yang telah hebat memasak.

Tertarik untuk mencoba buat resep nasi ayam bumbu bebek enak simple ini? Kalau anda mau, mending kamu segera siapin peralatan dan bahan-bahannya, lalu bikin deh Resep nasi ayam bumbu bebek yang mantab dan tidak ribet ini. Sungguh taidak sulit kan. 

Maka, ketimbang anda berlama-lama, yuk kita langsung saja sajikan resep nasi ayam bumbu bebek ini. Dijamin kamu tiidak akan nyesel bikin resep nasi ayam bumbu bebek mantab sederhana ini! Selamat mencoba dengan resep nasi ayam bumbu bebek mantab simple ini di rumah kalian masing-masing,oke!.

