---
description: "Resep Paha Ayam Kodok (Payko) yang lezat dan Mudah Dibuat"
title: "Resep Paha Ayam Kodok (Payko) yang lezat dan Mudah Dibuat"
slug: 203-resep-paha-ayam-kodok-payko-yang-lezat-dan-mudah-dibuat
date: 2021-02-24T05:11:03.401Z
image: https://img-global.cpcdn.com/recipes/1f3e71fb2447ec85/680x482cq70/paha-ayam-kodok-payko-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1f3e71fb2447ec85/680x482cq70/paha-ayam-kodok-payko-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1f3e71fb2447ec85/680x482cq70/paha-ayam-kodok-payko-foto-resep-utama.jpg
author: Sophia George
ratingvalue: 3.2
reviewcount: 14
recipeingredient:
- "6 pcs paha ayam bag bawah"
- "200 gr daging giling"
- "6 btr telur puyuh rebus kupas"
- "1/4 bawang bombay cincang"
- "2 siung bawang putih"
- "3 sdm tepung rotipanir"
- "1 butir telur ayam"
- "50 ml susu cair"
- "1 sdt garam"
- "1 sdm gula pasir"
- "1/2-1 sdt lada bubuk"
- "1/4 sdt pala bubuk"
- " Saus "
- "1/2 bawang bombay cincang"
- "200 ml air kaldu ayam"
- "1 sdm saus inggris"
- "2 sdm kecap manis"
- "1/2 sdt lada bubuk"
- "1/2 sdt garam"
- "2 sdm mentega utk menumis"
- "1 1/2 sdm maizena cairkan dengan sedikit air"
- " Bumbu Oles Panggang "
- "1 sdm margarin"
- "1 sdm kecap"
- "1 sdt madu"
- " Pelengkap "
- " Kentang gorengwedgesfrench fries"
- " Mixed vegetable yang ditumis dengan sedikit mentega  bawput"
recipeinstructions:
- "Kuliti paha, ambil daging dan tulangnya, sisakan di ujung untuk pegangan. Cincang lembut daging ayam/bisa dihaluskan di FP. Sisihkan. Sementara rebus tulang ayam dengan 300 ml air dengam api kecil hingga kuah bening, saring dan sisihkan. (Nanti yg dipakai hanya 200ml)"
- "Tumis bawang bombay dgn mentega hingga harum. Sisihkan. Campur semua bahan : ayam, daging, bumbu dsb. Uleni hingga rata. Jangan lupa tes icip dengan sedikit memggoreng adonan. Jika rasa sudahbpas, masukkan ke dalam plastik segitiga untuk memudahkan pengisian ke dalam kulit paha. Isikan sebagian, masukkan 1 telur puyuh dan iso lagi dengan adonan hingga penuh sambil dipadatkan. Kukus selama 30 menit atau hingga matang. Di menit 10 tusuki permukaan kulitnya dengan tusuk gigi agar air keluar."
- "Panaskan pan..dan panggang paha sambil dioles bahan olesan yang sudah diaduk rata. Panggang hingga kecoklatan. Angkat. Utk saus : tumis bombay hingga harum, tuang air kaldu dan didihkan. Bumbui. Tes icip. Dan kentalkan dengan memasukkan larutan maizena. Angkat.Sajikan Payko dengan kentang goreng, tumisan mix vegetable.dan disiram saus."
- "Note untuk yang dibikin Rolade : siapkan selembar alumunium foil, taruh adonan daging, tata telur/telur puyuh rebus di atasnya. Tutup lagi dengan adinan daging. Gulung dan padatkan dengan alumunium foul. Tusuk2 dengan tusuk gigi permukaan rol. Kukus selama 30-45 menit. Angkat di bisa disimpan jika sudah dingin"
categories:
- Resep
tags:
- paha
- ayam
- kodok

katakunci: paha ayam kodok 
nutrition: 213 calories
recipecuisine: Indonesian
preptime: "PT17M"
cooktime: "PT50M"
recipeyield: "1"
recipecategory: Dessert

---


![Paha Ayam Kodok (Payko)](https://img-global.cpcdn.com/recipes/1f3e71fb2447ec85/680x482cq70/paha-ayam-kodok-payko-foto-resep-utama.jpg)

Apabila kamu seorang ibu, menyajikan hidangan lezat untuk keluarga adalah suatu hal yang menggembirakan untuk anda sendiri. Tanggung jawab seorang  wanita bukan sekedar menangani rumah saja, tapi kamu juga harus memastikan keperluan nutrisi terpenuhi dan juga panganan yang disantap orang tercinta mesti lezat.

Di era  saat ini, kamu memang dapat mengorder panganan instan tanpa harus ribet membuatnya dulu. Tapi banyak juga lho mereka yang selalu ingin menghidangkan yang terenak bagi orang tercintanya. Pasalnya, menyajikan masakan sendiri jauh lebih bersih dan kita juga bisa menyesuaikan makanan tersebut sesuai dengan selera famili. 



Apakah anda merupakan seorang penggemar paha ayam kodok (payko)?. Asal kamu tahu, paha ayam kodok (payko) merupakan sajian khas di Indonesia yang sekarang disenangi oleh setiap orang di hampir setiap wilayah di Nusantara. Anda dapat memasak paha ayam kodok (payko) buatan sendiri di rumahmu dan boleh dijadikan santapan favorit di akhir pekanmu.

Anda tidak perlu bingung jika kamu ingin mendapatkan paha ayam kodok (payko), sebab paha ayam kodok (payko) tidak sulit untuk ditemukan dan juga anda pun boleh membuatnya sendiri di tempatmu. paha ayam kodok (payko) bisa diolah memalui bermacam cara. Saat ini telah banyak sekali resep kekinian yang membuat paha ayam kodok (payko) semakin enak.

Resep paha ayam kodok (payko) pun mudah dihidangkan, lho. Anda jangan capek-capek untuk memesan paha ayam kodok (payko), sebab Kamu mampu menyajikan sendiri di rumah. Bagi Kamu yang akan mencobanya, berikut cara menyajikan paha ayam kodok (payko) yang mantab yang dapat Anda hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Paha Ayam Kodok (Payko):

1. Siapkan 6 pcs paha ayam bag. bawah
1. Sediakan 200 gr daging giling
1. Sediakan 6 btr telur puyuh rebus, kupas
1. Ambil 1/4 bawang bombay cincang
1. Siapkan 2 siung bawang putih
1. Ambil 3 sdm tepung roti/panir
1. Sediakan 1 butir telur ayam
1. Gunakan 50 ml susu cair
1. Siapkan 1 sdt garam
1. Gunakan 1 sdm gula pasir
1. Sediakan 1/2-1 sdt lada bubuk
1. Gunakan 1/4 sdt pala bubuk
1. Siapkan  Saus :
1. Gunakan 1/2 bawang bombay cincang
1. Gunakan 200 ml air kaldu ayam
1. Gunakan 1 sdm saus inggris
1. Siapkan 2 sdm kecap manis
1. Siapkan 1/2 sdt lada bubuk
1. Ambil 1/2 sdt garam
1. Ambil 2 sdm mentega utk menumis
1. Sediakan 1 1/2 sdm maizena cairkan dengan sedikit air
1. Ambil  Bumbu Oles Panggang :
1. Siapkan 1 sdm margarin
1. Siapkan 1 sdm kecap
1. Siapkan 1 sdt madu
1. Gunakan  Pelengkap :
1. Sediakan  Kentang goreng/wedges/french fries
1. Siapkan  Mixed vegetable yang ditumis dengan sedikit mentega + bawput




<!--inarticleads2-->

##### Cara menyiapkan Paha Ayam Kodok (Payko):

1. Kuliti paha, ambil daging dan tulangnya, sisakan di ujung untuk pegangan. Cincang lembut daging ayam/bisa dihaluskan di FP. Sisihkan. Sementara rebus tulang ayam dengan 300 ml air dengam api kecil hingga kuah bening, saring dan sisihkan. (Nanti yg dipakai hanya 200ml)
1. Tumis bawang bombay dgn mentega hingga harum. Sisihkan. Campur semua bahan : ayam, daging, bumbu dsb. Uleni hingga rata. Jangan lupa tes icip dengan sedikit memggoreng adonan. Jika rasa sudahbpas, masukkan ke dalam plastik segitiga untuk memudahkan pengisian ke dalam kulit paha. Isikan sebagian, masukkan 1 telur puyuh dan iso lagi dengan adonan hingga penuh sambil dipadatkan. Kukus selama 30 menit atau hingga matang. Di menit 10 tusuki permukaan kulitnya dengan tusuk gigi agar air keluar.
1. Panaskan pan..dan panggang paha sambil dioles bahan olesan yang sudah diaduk rata. Panggang hingga kecoklatan. Angkat. Utk saus : tumis bombay hingga harum, tuang air kaldu dan didihkan. Bumbui. Tes icip. Dan kentalkan dengan memasukkan larutan maizena. Angkat.Sajikan Payko dengan kentang goreng, tumisan mix vegetable.dan disiram saus.
1. Note untuk yang dibikin Rolade : siapkan selembar alumunium foil, taruh adonan daging, tata telur/telur puyuh rebus di atasnya. Tutup lagi dengan adinan daging. Gulung dan padatkan dengan alumunium foul. Tusuk2 dengan tusuk gigi permukaan rol. Kukus selama 30-45 menit. Angkat di bisa disimpan jika sudah dingin




Ternyata resep paha ayam kodok (payko) yang mantab tidak rumit ini enteng sekali ya! Semua orang mampu menghidangkannya. Resep paha ayam kodok (payko) Sesuai sekali untuk kita yang sedang belajar memasak ataupun bagi kamu yang sudah lihai dalam memasak.

Tertarik untuk mencoba buat resep paha ayam kodok (payko) lezat tidak rumit ini? Kalau kamu mau, yuk kita segera menyiapkan peralatan dan bahannya, setelah itu bikin deh Resep paha ayam kodok (payko) yang mantab dan tidak ribet ini. Benar-benar mudah kan. 

Maka, daripada anda diam saja, ayo langsung aja bikin resep paha ayam kodok (payko) ini. Dijamin kalian gak akan menyesal bikin resep paha ayam kodok (payko) mantab tidak rumit ini! Selamat berkreasi dengan resep paha ayam kodok (payko) lezat simple ini di tempat tinggal kalian masing-masing,oke!.

