---
description: "Resep Ayam kriuk ala² KFC &amp;amp; Kentang goreng crispy yang enak dan Mudah Dibuat"
title: "Resep Ayam kriuk ala² KFC &amp;amp; Kentang goreng crispy yang enak dan Mudah Dibuat"
slug: 381-resep-ayam-kriuk-ala-kfc-and-amp-kentang-goreng-crispy-yang-enak-dan-mudah-dibuat
date: 2021-07-07T11:49:32.234Z
image: https://img-global.cpcdn.com/recipes/362efb7929c37239/680x482cq70/ayam-kriuk-ala-kfc-kentang-goreng-crispy-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/362efb7929c37239/680x482cq70/ayam-kriuk-ala-kfc-kentang-goreng-crispy-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/362efb7929c37239/680x482cq70/ayam-kriuk-ala-kfc-kentang-goreng-crispy-foto-resep-utama.jpg
author: Effie Moody
ratingvalue: 3.9
reviewcount: 15
recipeingredient:
- "1/4 kg ayam potong jadi 24 sesuai selera"
- "2-4 biji kentang"
- " _Bumbu Marinasi"
- "1 sdm cabe bubuk"
- "1/2 sdm ketumbar bubuk"
- "1/2 sdm merica bubuk"
- "1/4 sdm MasakoRoyco dll"
- "1/4 sdm kunyit bubuk"
- "1/2 sdt garam"
- " _Bahan buat menggoreng"
- "10 SDM tepung terigu segitigakunci biru"
- "500 ml minyak goreng"
- " Bahan diatas bisa dikurang bisa ditambah ya sesuai kebutuhan"
recipeinstructions:
- "Bersihkan ayam dan potong², taburi bumbu Marinasi, dan diamkan selama 30-1 jam, bisa di diamkan 24 jam jika ingin bumbunya makin meresap, taruh di kulkas, tapi jika ingin cepat cukup 30 saja"
- "Ambil plastik yg ada tutupnya, masukan tepung terigu dan tambahkan bumbu Marinasi, sambil dikira² tingkat keasinanya ya, jika semua sudah dicampur, tutup plastik kemudian goyang²kan sampai bumbu dan tepung tercampur rata, sisihkan"
- "Kupas kentang iris memanjang dan rebus setengah matang, tiriskan hilangkan airnya"
- "Panaskan minyak dengan api kecil, sambil menunggu api panas, siapkan ayam dan tepungnya, ambil mangkok kecil tuang sedikit air dan 1 sdm tepung yg sudah di kasi bumbu"
- "Guling²kan ayam di tepung sampai seluruh permukaan tertutup, angkat dan celupkan ke air larutan 1 sdm tepung tadi, setelah dicelupkan ke air, guling²kan lagi ke tepung sampai semua permukaan tertutup lalu goreng, lakukan sampai semua ayam habis"
- "Setelah semua ayam di goreng, giliran kentangnya,"
- "Masukan semua kentang ke tepung bekas lumuran ayam tadi, tutup dan goyang²nya agar tepungnya menempel di tepung, setelah goreng hingga matang,"
- "Ayam goreng dan kentang goreng siap di sajikan dengan saos cocolan😃🙏"
- "Tepung sisanya bisa disimpan di kulkas sewaktu² bisa di pakai goreng kentang /ayam lagi"
categories:
- Resep
tags:
- ayam
- kriuk
- ala

katakunci: ayam kriuk ala 
nutrition: 174 calories
recipecuisine: Indonesian
preptime: "PT32M"
cooktime: "PT60M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam kriuk ala² KFC &amp; Kentang goreng crispy](https://img-global.cpcdn.com/recipes/362efb7929c37239/680x482cq70/ayam-kriuk-ala-kfc-kentang-goreng-crispy-foto-resep-utama.jpg)

Sebagai seorang istri, menyajikan masakan nikmat kepada orang tercinta merupakan suatu hal yang membahagiakan untuk kita sendiri. Tanggung jawab seorang istri Tidak sekadar mengurus rumah saja, tapi anda juga harus memastikan kebutuhan nutrisi terpenuhi dan olahan yang disantap keluarga tercinta mesti mantab.

Di masa  sekarang, kita sebenarnya mampu membeli masakan instan walaupun tidak harus ribet mengolahnya lebih dulu. Tetapi banyak juga lho mereka yang selalu mau memberikan yang terbaik untuk keluarganya. Sebab, memasak yang diolah sendiri jauh lebih bersih dan kita pun bisa menyesuaikan masakan tersebut berdasarkan makanan kesukaan keluarga. 



Apakah kamu salah satu penggemar ayam kriuk ala² kfc &amp; kentang goreng crispy?. Tahukah kamu, ayam kriuk ala² kfc &amp; kentang goreng crispy merupakan hidangan khas di Indonesia yang saat ini disukai oleh kebanyakan orang dari hampir setiap daerah di Nusantara. Kita bisa menghidangkan ayam kriuk ala² kfc &amp; kentang goreng crispy sendiri di rumah dan dapat dijadikan santapan kesukaanmu di akhir pekanmu.

Kalian jangan bingung jika kamu ingin menyantap ayam kriuk ala² kfc &amp; kentang goreng crispy, lantaran ayam kriuk ala² kfc &amp; kentang goreng crispy gampang untuk ditemukan dan kamu pun bisa membuatnya sendiri di tempatmu. ayam kriuk ala² kfc &amp; kentang goreng crispy bisa diolah dengan beragam cara. Kini pun sudah banyak banget cara modern yang membuat ayam kriuk ala² kfc &amp; kentang goreng crispy semakin enak.

Resep ayam kriuk ala² kfc &amp; kentang goreng crispy juga sangat mudah dibikin, lho. Kita jangan capek-capek untuk memesan ayam kriuk ala² kfc &amp; kentang goreng crispy, karena Kamu mampu menghidangkan di rumah sendiri. Bagi Kamu yang akan menyajikannya, di bawah ini adalah resep menyajikan ayam kriuk ala² kfc &amp; kentang goreng crispy yang nikamat yang bisa Kita coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Ayam kriuk ala² KFC &amp; Kentang goreng crispy:

1. Ambil 1/4 kg ayam (potong jadi 2-4 sesuai selera)
1. Ambil 2-4 biji kentang
1. Sediakan  _*Bumbu Marinasi
1. Siapkan 1 sdm cabe bubuk
1. Gunakan 1/2 sdm ketumbar bubuk
1. Sediakan 1/2 sdm merica bubuk
1. Ambil 1/4 sdm Masako/Royco dll
1. Gunakan 1/4 sdm kunyit bubuk
1. Ambil 1/2 sdt garam
1. Gunakan  _*Bahan buat menggoreng
1. Ambil 10 SDM tepung terigu segitiga/kunci biru
1. Siapkan 500 ml minyak goreng
1. Ambil  Bahan diatas bisa dikurang bisa ditambah ya sesuai kebutuhan,




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam kriuk ala² KFC &amp; Kentang goreng crispy:

1. Bersihkan ayam dan potong², taburi bumbu Marinasi, dan diamkan selama 30-1 jam, bisa di diamkan 24 jam jika ingin bumbunya makin meresap, taruh di kulkas, tapi jika ingin cepat cukup 30 saja
1. Ambil plastik yg ada tutupnya, masukan tepung terigu dan tambahkan bumbu Marinasi, sambil dikira² tingkat keasinanya ya, jika semua sudah dicampur, tutup plastik kemudian goyang²kan sampai bumbu dan tepung tercampur rata, sisihkan
1. Kupas kentang iris memanjang dan rebus setengah matang, tiriskan hilangkan airnya
1. Panaskan minyak dengan api kecil, sambil menunggu api panas, siapkan ayam dan tepungnya, ambil mangkok kecil tuang sedikit air dan 1 sdm tepung yg sudah di kasi bumbu
1. Guling²kan ayam di tepung sampai seluruh permukaan tertutup, angkat dan celupkan ke air larutan 1 sdm tepung tadi, setelah dicelupkan ke air, guling²kan lagi ke tepung sampai semua permukaan tertutup lalu goreng, lakukan sampai semua ayam habis
1. Setelah semua ayam di goreng, giliran kentangnya,
1. Masukan semua kentang ke tepung bekas lumuran ayam tadi, tutup dan goyang²nya agar tepungnya menempel di tepung, setelah goreng hingga matang,
1. Ayam goreng dan kentang goreng siap di sajikan dengan saos cocolan😃🙏
1. Tepung sisanya bisa disimpan di kulkas sewaktu² bisa di pakai goreng kentang /ayam lagi




Ternyata cara buat ayam kriuk ala² kfc &amp; kentang goreng crispy yang lezat sederhana ini mudah banget ya! Kita semua bisa menghidangkannya. Cara Membuat ayam kriuk ala² kfc &amp; kentang goreng crispy Sangat sesuai sekali buat kita yang baru mau belajar memasak ataupun bagi anda yang sudah hebat memasak.

Apakah kamu ingin mencoba buat resep ayam kriuk ala² kfc &amp; kentang goreng crispy lezat tidak rumit ini? Kalau kalian ingin, yuk kita segera buruan siapkan alat-alat dan bahan-bahannya, lalu bikin deh Resep ayam kriuk ala² kfc &amp; kentang goreng crispy yang mantab dan tidak rumit ini. Sangat taidak sulit kan. 

Oleh karena itu, daripada kamu berfikir lama-lama, yuk kita langsung buat resep ayam kriuk ala² kfc &amp; kentang goreng crispy ini. Pasti kamu tak akan nyesel bikin resep ayam kriuk ala² kfc &amp; kentang goreng crispy nikmat tidak ribet ini! Selamat mencoba dengan resep ayam kriuk ala² kfc &amp; kentang goreng crispy nikmat tidak ribet ini di rumah kalian sendiri,oke!.

