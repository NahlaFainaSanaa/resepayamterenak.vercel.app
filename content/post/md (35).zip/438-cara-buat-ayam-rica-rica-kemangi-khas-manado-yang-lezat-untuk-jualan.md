---
description: "Cara buat Ayam rica-rica kemangi khas manado yang lezat Untuk Jualan"
title: "Cara buat Ayam rica-rica kemangi khas manado yang lezat Untuk Jualan"
slug: 438-cara-buat-ayam-rica-rica-kemangi-khas-manado-yang-lezat-untuk-jualan
date: 2021-05-04T06:12:14.594Z
image: https://img-global.cpcdn.com/recipes/4f74f6f296c2dcfc/680x482cq70/ayam-rica-rica-kemangi-khas-manado-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4f74f6f296c2dcfc/680x482cq70/ayam-rica-rica-kemangi-khas-manado-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4f74f6f296c2dcfc/680x482cq70/ayam-rica-rica-kemangi-khas-manado-foto-resep-utama.jpg
author: Rosa Lynch
ratingvalue: 3.1
reviewcount: 9
recipeingredient:
- "1 1/2 ekor ayam"
- "6 cabai merah"
- "20 cabai rawit"
- "10 siung bawang merah"
- "4 siung bawang putih"
- "1 ikat kemangi"
- "1 biji kunyit"
- "1 biji jahe"
- "4 butir kemiri"
- "1/2 sdm garam"
- "1 sdm gula"
- "3 biji serai"
- "5 lembar daun jeruk"
- "3 lembar daun salam"
- "2 biji jeruk nipis asli"
- "1/2 sdm lada putih dan hitam sesuai selera"
recipeinstructions:
- "Bersihkan daging ayamnya, lalu taburkan garam dan jeruk nipis ke dalam rendaman ayam yang telah dibersihkan diamkan selama kurang lebih 15 menit supaya garam dan jeruk nipisnya menyerap ke daging ayam."
- "Haluskan bawang merah, bawang putih, jahe, kunyit, cabai merah, cabai rawit, kemiri, lada hitam dan putih lalu berikan sedikit air supaya bumbu dapat di blender dengan halus."
- "Goreng daging ayam sampai warna nya coklat dan jangan terlalu kering sekali gorengnya."
- "Tumis bumbu yang sudah dihaluskan tadi sampai benar-benar tanang dan harum, setelah bumbu tanak atau masak masukkan daging ayam yang sudah digoreng tadi sampai benar-benar bumbunya meresap ke dalam daging ayam yang sudah di goreng."
- "Siap disajikan."
categories:
- Resep
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 124 calories
recipecuisine: Indonesian
preptime: "PT13M"
cooktime: "PT49M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam rica-rica kemangi khas manado](https://img-global.cpcdn.com/recipes/4f74f6f296c2dcfc/680x482cq70/ayam-rica-rica-kemangi-khas-manado-foto-resep-utama.jpg)

Andai kamu seorang ibu, menyuguhkan panganan enak kepada famili merupakan hal yang menyenangkan bagi kita sendiri. Tugas seorang istri bukan hanya mengerjakan pekerjaan rumah saja, tapi kamu juga wajib memastikan keperluan gizi tercukupi dan juga panganan yang dimakan keluarga tercinta wajib mantab.

Di zaman  saat ini, anda sebenarnya dapat memesan masakan praktis tanpa harus capek memasaknya lebih dulu. Namun banyak juga lho mereka yang selalu ingin memberikan yang terbaik untuk keluarganya. Sebab, memasak yang diolah sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan sesuai kesukaan keluarga. 



Apakah anda adalah salah satu penikmat ayam rica-rica kemangi khas manado?. Tahukah kamu, ayam rica-rica kemangi khas manado merupakan makanan khas di Nusantara yang kini digemari oleh orang-orang di berbagai daerah di Nusantara. Kita dapat memasak ayam rica-rica kemangi khas manado buatan sendiri di rumah dan boleh jadi makanan kegemaranmu di hari libur.

Kamu tidak usah bingung untuk memakan ayam rica-rica kemangi khas manado, lantaran ayam rica-rica kemangi khas manado sangat mudah untuk dicari dan juga kalian pun boleh mengolahnya sendiri di tempatmu. ayam rica-rica kemangi khas manado dapat dimasak dengan beragam cara. Kini pun telah banyak sekali cara modern yang membuat ayam rica-rica kemangi khas manado semakin lebih lezat.

Resep ayam rica-rica kemangi khas manado juga gampang sekali dihidangkan, lho. Anda jangan capek-capek untuk membeli ayam rica-rica kemangi khas manado, tetapi Kita dapat membuatnya sendiri di rumah. Untuk Kalian yang akan menghidangkannya, berikut ini cara membuat ayam rica-rica kemangi khas manado yang nikamat yang dapat Kita buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Ayam rica-rica kemangi khas manado:

1. Sediakan 1 1/2 ekor ayam
1. Gunakan 6 cabai merah
1. Gunakan 20 cabai rawit
1. Siapkan 10 siung bawang merah
1. Sediakan 4 siung bawang putih
1. Gunakan 1 ikat kemangi
1. Siapkan 1 biji kunyit
1. Sediakan 1 biji jahe
1. Siapkan 4 butir kemiri
1. Siapkan 1/2 sdm garam
1. Ambil 1 sdm gula
1. Siapkan 3 biji serai
1. Gunakan 5 lembar daun jeruk
1. Ambil 3 lembar daun salam
1. Sediakan 2 biji jeruk nipis asli
1. Ambil 1/2 sdm lada putih dan hitam sesuai selera




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam rica-rica kemangi khas manado:

1. Bersihkan daging ayamnya, lalu taburkan garam dan jeruk nipis ke dalam rendaman ayam yang telah dibersihkan diamkan selama kurang lebih 15 menit supaya garam dan jeruk nipisnya menyerap ke daging ayam.
1. Haluskan bawang merah, bawang putih, jahe, kunyit, cabai merah, cabai rawit, kemiri, lada hitam dan putih lalu berikan sedikit air supaya bumbu dapat di blender dengan halus.
1. Goreng daging ayam sampai warna nya coklat dan jangan terlalu kering sekali gorengnya.
1. Tumis bumbu yang sudah dihaluskan tadi sampai benar-benar tanang dan harum, setelah bumbu tanak atau masak masukkan daging ayam yang sudah digoreng tadi sampai benar-benar bumbunya meresap ke dalam daging ayam yang sudah di goreng.
1. Siap disajikan.




Wah ternyata cara membuat ayam rica-rica kemangi khas manado yang enak simple ini mudah sekali ya! Kamu semua bisa mencobanya. Resep ayam rica-rica kemangi khas manado Cocok banget buat kalian yang baru belajar memasak maupun untuk kalian yang telah jago dalam memasak.

Tertarik untuk mulai mencoba membuat resep ayam rica-rica kemangi khas manado mantab tidak ribet ini? Kalau kalian mau, yuk kita segera menyiapkan alat dan bahan-bahannya, setelah itu buat deh Resep ayam rica-rica kemangi khas manado yang enak dan sederhana ini. Betul-betul mudah kan. 

Jadi, ketimbang kita berfikir lama-lama, hayo kita langsung saja hidangkan resep ayam rica-rica kemangi khas manado ini. Pasti kamu tak akan nyesel membuat resep ayam rica-rica kemangi khas manado nikmat simple ini! Selamat berkreasi dengan resep ayam rica-rica kemangi khas manado enak simple ini di rumah masing-masing,ya!.

