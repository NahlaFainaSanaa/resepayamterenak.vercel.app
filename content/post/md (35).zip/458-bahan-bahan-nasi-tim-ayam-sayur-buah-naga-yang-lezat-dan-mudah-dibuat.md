---
description: "Bahan-bahan Nasi Tim Ayam Sayur Buah Naga yang lezat dan Mudah Dibuat"
title: "Bahan-bahan Nasi Tim Ayam Sayur Buah Naga yang lezat dan Mudah Dibuat"
slug: 458-bahan-bahan-nasi-tim-ayam-sayur-buah-naga-yang-lezat-dan-mudah-dibuat
date: 2021-03-21T01:31:39.791Z
image: https://img-global.cpcdn.com/recipes/8e96a74847617caf/680x482cq70/nasi-tim-ayam-sayur-buah-naga-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8e96a74847617caf/680x482cq70/nasi-tim-ayam-sayur-buah-naga-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8e96a74847617caf/680x482cq70/nasi-tim-ayam-sayur-buah-naga-foto-resep-utama.jpg
author: Chase Burgess
ratingvalue: 3.1
reviewcount: 14
recipeingredient:
- "  Nasi Tim Buah Naga "
- "2 cup Beras cuci bersih"
- "125 g Daging buah Naga merah haluskan"
- "secukupnya Air"
- "  Tumisan Ayam Sayur "
- "400 g Ayam fillet potong dadu kecil saya pake fillet paha"
- "1 buah Zukini ukuran sedang potong dadu kecil"
- "9 buah Jamur champignon potong2"
- "6 siung Bawang putih cincang halus"
- "9 butir Bawang merah iris tipis"
- "2 ruas Jahe geprek"
- "2 sdm Saos tiram"
- "2 sdm Kecap asin"
- "1 sdm Kecap asin hitam kalo ga ada ganti kecap asin biasa"
- "5 sdm Kecap manis"
- "1 sdm Minyak wijen"
- "150-200 ml Air"
- "secukupnya Garam gula pasir lada bubuk  kaldu jamur"
- "secukupnya Minyak goreng"
- "  Bahan Kuah "
- " Tulangan ayam"
- "1/2-1 liter Air"
- "1 batang Daun seledri iris2"
- "2 batang Daun bawang iris2"
- "secukupnya Garam lada bubuk  kaldu jamur"
- "  Pelengkap "
- " Telur rebus"
- "Irisan daun bawang"
- " Bawang goreng"
recipeinstructions:
- "Tumisan Ayam Sayur : Tumis bawang merah hingga harum &amp; layu. Kemudian masukkan bawang putih &amp; jahe, tumis hingga harum &amp; bawang berwarna kuning keemasaan."
- "Sisihkan bawang &amp; jahe ke pinggir wajan. Lalu masukkan 1 sdm gula pasir ke dalam minyak, biarkan hingga gula larut sendiri &amp; berwarna coklat muda membentuk karamel (apinya jangan besar2 ya supaya gula tidak gosong, nanti pahit)."
- "Setelah itu masukkan ayam, aduk rata &amp; tumis hingga ayam berubah warna. Masukkan jamur &amp; zukini, tumis hingga sayuran cukup layu."
- "Masukkan sisa bumbu &amp; air, aduk rata. Masak hingga matang, bumbu menyerap &amp; air cukup menyusut. Jangan lupa tes rasa ya. Matikan api &amp; sisihkan."
- "Nasi Buah Naga : Saring buah Naga yang telah dihaluskan. Lalu campur beras, sari buah Naga &amp; air sebanyak untuk memasak nasi tapi dilebihin lagi airnya supaya hasilnya lebih lembek. Masak dengan rice cooker hingga matang. Setelah matang, aduk2 nasi &amp; sisihkan."
- "Kuah : Rebus tulangan ayam sebentar lalu buang air rebusan pertamanya untuk membuang kotoran. Rebus kembali tulangan ayam dengan air yang baru, masukkan daun seledri &amp; daun bawang. Masak dengan api kecil. Bumbui dengan garam, lada bubuk &amp; kaldu jamur. Matikan api &amp; sisihkan."
- "Penyelesaian : Siapkan mangkok, masukkan telur rebus yang dibelah 2 &amp; tumisan ayam sayur di dasar mangkok. Kemudian masukkan nasi, padatkan. Isinya jangan terlalu penuh ya kalau nasinya mau dikukus lagi. Tuang air kaldu secukupnya kemudian kukus kurang lebih 10-15 menit. Gunakan mangkok tahan panas ya. Nasi tim saya ga dikukus lagi, langsung cetak aja jadi ga dituang air kaldu lagi di nasinya. Sajikan nasi tim panas2 dengan kuah kaldu. Jangan lupa taburi daun bawang &amp; bawang goreng. Yummy.. 😋"
categories:
- Resep
tags:
- nasi
- tim
- ayam

katakunci: nasi tim ayam 
nutrition: 236 calories
recipecuisine: Indonesian
preptime: "PT14M"
cooktime: "PT55M"
recipeyield: "3"
recipecategory: Lunch

---


![Nasi Tim Ayam Sayur Buah Naga](https://img-global.cpcdn.com/recipes/8e96a74847617caf/680x482cq70/nasi-tim-ayam-sayur-buah-naga-foto-resep-utama.jpg)

Sebagai seorang istri, menyajikan masakan sedap bagi keluarga tercinta merupakan suatu hal yang memuaskan bagi kita sendiri. Peran seorang  wanita bukan cuman menjaga rumah saja, namun kamu juga harus memastikan keperluan nutrisi terpenuhi dan hidangan yang disantap orang tercinta mesti sedap.

Di waktu  sekarang, kalian memang mampu membeli masakan jadi meski tanpa harus repot membuatnya terlebih dahulu. Tapi ada juga orang yang selalu ingin menyajikan yang terlezat bagi orang tercintanya. Sebab, menyajikan masakan sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan hidangan tersebut berdasarkan makanan kesukaan famili. 



Apakah anda adalah salah satu penikmat nasi tim ayam sayur buah naga?. Asal kamu tahu, nasi tim ayam sayur buah naga adalah sajian khas di Indonesia yang kini disenangi oleh kebanyakan orang di hampir setiap daerah di Nusantara. Anda dapat menghidangkan nasi tim ayam sayur buah naga olahan sendiri di rumahmu dan dapat dijadikan camilan kesukaanmu di hari libur.

Kamu tidak perlu bingung jika kamu ingin memakan nasi tim ayam sayur buah naga, karena nasi tim ayam sayur buah naga sangat mudah untuk didapatkan dan juga anda pun dapat membuatnya sendiri di rumah. nasi tim ayam sayur buah naga dapat dibuat lewat bermacam cara. Sekarang sudah banyak resep modern yang menjadikan nasi tim ayam sayur buah naga semakin lebih nikmat.

Resep nasi tim ayam sayur buah naga juga sangat gampang dihidangkan, lho. Kita jangan capek-capek untuk membeli nasi tim ayam sayur buah naga, tetapi Kalian dapat membuatnya di rumah sendiri. Bagi Kita yang mau mencobanya, inilah cara untuk membuat nasi tim ayam sayur buah naga yang lezat yang mampu Kamu buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Nasi Tim Ayam Sayur Buah Naga:

1. Sediakan  🍙 Nasi Tim Buah Naga :
1. Sediakan 2 cup Beras, cuci bersih
1. Sediakan 125 g Daging buah Naga merah, haluskan
1. Siapkan secukupnya Air
1. Gunakan  🍄 Tumisan Ayam Sayur :
1. Ambil 400 g Ayam fillet, potong dadu kecil (saya pake fillet paha)
1. Gunakan 1 buah Zukini ukuran sedang, potong dadu kecil
1. Gunakan 9 buah Jamur champignon, potong2
1. Ambil 6 siung Bawang putih, cincang halus
1. Sediakan 9 butir Bawang merah, iris tipis
1. Siapkan 2 ruas Jahe, geprek
1. Sediakan 2 sdm Saos tiram
1. Siapkan 2 sdm Kecap asin
1. Siapkan 1 sdm Kecap asin hitam (kalo ga ada ganti kecap asin biasa)
1. Gunakan 5 sdm Kecap manis
1. Gunakan 1 sdm Minyak wijen
1. Sediakan 150-200 ml Air
1. Sediakan secukupnya Garam, gula pasir, lada bubuk &amp; kaldu jamur
1. Ambil secukupnya Minyak goreng
1. Gunakan  🥣 Bahan Kuah :
1. Sediakan  Tulangan ayam
1. Gunakan 1/2-1 liter Air
1. Gunakan 1 batang Daun seledri, iris2
1. Sediakan 2 batang Daun bawang, iris2
1. Sediakan secukupnya Garam, lada bubuk &amp; kaldu jamur
1. Gunakan  🥚 Pelengkap :
1. Gunakan  Telur rebus
1. Ambil Irisan daun bawang
1. Sediakan  Bawang goreng




<!--inarticleads2-->

##### Langkah-langkah membuat Nasi Tim Ayam Sayur Buah Naga:

1. Tumisan Ayam Sayur : Tumis bawang merah hingga harum &amp; layu. Kemudian masukkan bawang putih &amp; jahe, tumis hingga harum &amp; bawang berwarna kuning keemasaan.
1. Sisihkan bawang &amp; jahe ke pinggir wajan. Lalu masukkan 1 sdm gula pasir ke dalam minyak, biarkan hingga gula larut sendiri &amp; berwarna coklat muda membentuk karamel (apinya jangan besar2 ya supaya gula tidak gosong, nanti pahit).
1. Setelah itu masukkan ayam, aduk rata &amp; tumis hingga ayam berubah warna. Masukkan jamur &amp; zukini, tumis hingga sayuran cukup layu.
1. Masukkan sisa bumbu &amp; air, aduk rata. Masak hingga matang, bumbu menyerap &amp; air cukup menyusut. Jangan lupa tes rasa ya. Matikan api &amp; sisihkan.
1. Nasi Buah Naga : Saring buah Naga yang telah dihaluskan. Lalu campur beras, sari buah Naga &amp; air sebanyak untuk memasak nasi tapi dilebihin lagi airnya supaya hasilnya lebih lembek. Masak dengan rice cooker hingga matang. Setelah matang, aduk2 nasi &amp; sisihkan.
1. Kuah : Rebus tulangan ayam sebentar lalu buang air rebusan pertamanya untuk membuang kotoran. Rebus kembali tulangan ayam dengan air yang baru, masukkan daun seledri &amp; daun bawang. Masak dengan api kecil. Bumbui dengan garam, lada bubuk &amp; kaldu jamur. Matikan api &amp; sisihkan.
1. Penyelesaian : Siapkan mangkok, masukkan telur rebus yang dibelah 2 &amp; tumisan ayam sayur di dasar mangkok. Kemudian masukkan nasi, padatkan. Isinya jangan terlalu penuh ya kalau nasinya mau dikukus lagi. Tuang air kaldu secukupnya kemudian kukus kurang lebih 10-15 menit. Gunakan mangkok tahan panas ya. Nasi tim saya ga dikukus lagi, langsung cetak aja jadi ga dituang air kaldu lagi di nasinya. Sajikan nasi tim panas2 dengan kuah kaldu. Jangan lupa taburi daun bawang &amp; bawang goreng. Yummy.. 😋




Ternyata cara membuat nasi tim ayam sayur buah naga yang nikamt sederhana ini enteng sekali ya! Kamu semua mampu memasaknya. Resep nasi tim ayam sayur buah naga Cocok sekali buat kamu yang baru akan belajar memasak maupun juga bagi kalian yang sudah lihai dalam memasak.

Apakah kamu tertarik mencoba bikin resep nasi tim ayam sayur buah naga enak simple ini? Kalau anda tertarik, ayo kalian segera siapkan alat-alat dan bahan-bahannya, lantas buat deh Resep nasi tim ayam sayur buah naga yang mantab dan tidak rumit ini. Sangat gampang kan. 

Jadi, daripada anda berfikir lama-lama, ayo kita langsung bikin resep nasi tim ayam sayur buah naga ini. Dijamin anda gak akan menyesal sudah membuat resep nasi tim ayam sayur buah naga mantab tidak rumit ini! Selamat mencoba dengan resep nasi tim ayam sayur buah naga enak tidak ribet ini di rumah kalian sendiri,ya!.

