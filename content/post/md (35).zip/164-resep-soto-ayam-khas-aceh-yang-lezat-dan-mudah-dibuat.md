---
description: "Resep Soto Ayam Khas Aceh yang lezat dan Mudah Dibuat"
title: "Resep Soto Ayam Khas Aceh yang lezat dan Mudah Dibuat"
slug: 164-resep-soto-ayam-khas-aceh-yang-lezat-dan-mudah-dibuat
date: 2021-04-11T09:31:42.544Z
image: https://img-global.cpcdn.com/recipes/dce4bf858d8fdef0/680x482cq70/soto-ayam-khas-aceh-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/dce4bf858d8fdef0/680x482cq70/soto-ayam-khas-aceh-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/dce4bf858d8fdef0/680x482cq70/soto-ayam-khas-aceh-foto-resep-utama.jpg
author: Lulu Ray
ratingvalue: 4.9
reviewcount: 6
recipeingredient:
- " Bahan Soto"
- "1/2 ekor ayam kampungsy pakai ayam negeri"
- "150 ml santan kental"
- "1 buah jeruk nipis"
- "1 batang daun bawangiris"
- "1 batang daun seledriiris"
- "2 siung bawang merahiris untuk ditumis"
- "1200 ml air bersih"
- " Bumbu Halus"
- "6 siung bawang merah"
- "5 siung bawang putih"
- "4 butir kemiri"
- "2 cm jahe"
- "1 sdt jintan"
- "1 sdt kunyit bubuk"
- "1 sdt ketumbar bubuk"
- "1/2 sdt lada bubuk"
- "1/2 sdt pala bubuk"
- " Rempah Cemplung"
- "3 lembar daun salamsobek2"
- "1 batang serehmemarkan"
- "4 butir cengkeh"
- "1 sdt garambisa  jika kurang"
- "1 sdt gula pasirbisa  jika kurang"
- "1 sdt kaldu jamurbisa  jika kurang"
- " Pelengkap"
- " Telur Rebus"
- " Perkedel"
- " Bawang Merah Goreng"
recipeinstructions:
- "Siapkan dan cuci bersih ayam (jika pakai ayam negeri beri perasan air jeruk nipis, diamkan 10 menit)bilas kembali"
- "Siapkan 500 ml air bersih, untuk rebusan pertama didihkan dan masukkan ayam,masak sekitar 10 menit,lalu buang air rebusan pertama,ganti dengan 700 ml air bersih untuk rebusan kedua"
- "Siapkan bahan bumbu halus, lalu blender bahan bumbu halus hingga halus"
- "Siapkan pan,tumis bawang merah iris hingga harum, masukkan juga bumbu halus,sereh,cengkeh,tumis hingga harum dan bumbu mengeluarkan minyak"
- "Didihkan kembali rebusan Ayam tadi,tambahkan bumbu halus,masak sebentar hingga kuah kaldu ayam mendidih kembali"
- "Setelah Daging Ayam setengah empuk,masukkan santan kental,bubuhi gula pasir, garam, kaldu jamur, serta koreksi rasa,masak hingga Daging Ayam empuk dan bumbu meresap Sajikan Soto Ayam Khas Aceh dengan pelengkap"
categories:
- Resep
tags:
- soto
- ayam
- khas

katakunci: soto ayam khas 
nutrition: 169 calories
recipecuisine: Indonesian
preptime: "PT28M"
cooktime: "PT46M"
recipeyield: "3"
recipecategory: Dinner

---


![Soto Ayam Khas Aceh](https://img-global.cpcdn.com/recipes/dce4bf858d8fdef0/680x482cq70/soto-ayam-khas-aceh-foto-resep-utama.jpg)

Sebagai seorang ibu, menyuguhkan masakan sedap pada keluarga tercinta merupakan suatu hal yang sangat menyenangkan bagi anda sendiri. Peran seorang ibu Tidak cuman menjaga rumah saja, tapi kamu juga wajib memastikan kebutuhan gizi tercukupi dan juga masakan yang dikonsumsi orang tercinta mesti menggugah selera.

Di waktu  saat ini, kamu memang mampu membeli santapan jadi tidak harus repot mengolahnya terlebih dahulu. Tapi banyak juga orang yang memang ingin memberikan makanan yang terenak bagi orang tercintanya. Karena, memasak yang dibuat sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan masakan tersebut sesuai dengan kesukaan keluarga. 



Apakah anda seorang penikmat soto ayam khas aceh?. Tahukah kamu, soto ayam khas aceh merupakan hidangan khas di Indonesia yang kini disukai oleh orang-orang di hampir setiap tempat di Indonesia. Anda dapat membuat soto ayam khas aceh sendiri di rumahmu dan boleh jadi camilan favorit di akhir pekan.

Kamu tak perlu bingung jika kamu ingin memakan soto ayam khas aceh, lantaran soto ayam khas aceh gampang untuk didapatkan dan anda pun dapat memasaknya sendiri di tempatmu. soto ayam khas aceh dapat dimasak memalui berbagai cara. Kini pun ada banyak banget cara modern yang membuat soto ayam khas aceh semakin lebih enak.

Resep soto ayam khas aceh pun sangat mudah dibikin, lho. Anda tidak perlu ribet-ribet untuk memesan soto ayam khas aceh, tetapi Kita dapat menyiapkan ditempatmu. Bagi Kalian yang ingin menyajikannya, di bawah ini adalah resep untuk membuat soto ayam khas aceh yang enak yang bisa Kamu buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Soto Ayam Khas Aceh:

1. Gunakan  👉Bahan Soto
1. Sediakan 1/2 ekor ayam kampung(sy pakai ayam negeri)
1. Ambil 150 ml santan kental
1. Gunakan 1 buah jeruk nipis
1. Gunakan 1 batang daun bawang,iris
1. Ambil 1 batang daun seledri,iris
1. Ambil 2 siung bawang merah,iris untuk ditumis
1. Gunakan 1200 ml air bersih
1. Ambil  👉Bumbu Halus
1. Ambil 6 siung bawang merah
1. Ambil 5 siung bawang putih
1. Gunakan 4 butir kemiri
1. Sediakan 2 cm jahe
1. Ambil 1 sdt jintan
1. Ambil 1 sdt kunyit bubuk
1. Ambil 1 sdt ketumbar bubuk
1. Ambil 1/2 sdt lada bubuk
1. Ambil 1/2 sdt pala bubuk
1. Siapkan  👉Rempah Cemplung
1. Gunakan 3 lembar daun salam,sobek2
1. Sediakan 1 batang sereh,memarkan
1. Siapkan 4 butir cengkeh
1. Sediakan 1 sdt garam(bisa + jika kurang)
1. Siapkan 1 sdt gula pasir(bisa + jika kurang)
1. Siapkan 1 sdt kaldu jamur(bisa + jika kurang)
1. Ambil  👉Pelengkap
1. Siapkan  Telur Rebus
1. Siapkan  Perkedel
1. Gunakan  Bawang Merah Goreng




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Soto Ayam Khas Aceh:

1. Siapkan dan cuci bersih ayam (jika pakai ayam negeri beri perasan air jeruk nipis, diamkan 10 menit)bilas kembali
1. Siapkan 500 ml air bersih, untuk rebusan pertama didihkan dan masukkan ayam,masak sekitar 10 menit,lalu buang air rebusan pertama,ganti dengan 700 ml air bersih untuk rebusan kedua
1. Siapkan bahan bumbu halus, lalu blender bahan bumbu halus hingga halus
1. Siapkan pan,tumis bawang merah iris hingga harum, masukkan juga bumbu halus,sereh,cengkeh,tumis hingga harum dan bumbu mengeluarkan minyak
1. Didihkan kembali rebusan Ayam tadi,tambahkan bumbu halus,masak sebentar hingga kuah kaldu ayam mendidih kembali
1. Setelah Daging Ayam setengah empuk,masukkan santan kental,bubuhi gula pasir, garam, kaldu jamur, serta koreksi rasa,masak hingga Daging Ayam empuk dan bumbu meresap - Sajikan Soto Ayam Khas Aceh dengan pelengkap
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Soto Ayam Khas Aceh">



Ternyata cara buat soto ayam khas aceh yang nikamt tidak ribet ini gampang sekali ya! Semua orang dapat menghidangkannya. Resep soto ayam khas aceh Sesuai sekali buat kalian yang baru belajar memasak ataupun untuk kamu yang sudah hebat dalam memasak.

Apakah kamu mau mulai mencoba buat resep soto ayam khas aceh nikmat tidak ribet ini? Kalau kamu mau, mending kamu segera siapkan peralatan dan bahannya, lantas bikin deh Resep soto ayam khas aceh yang enak dan sederhana ini. Sungguh gampang kan. 

Maka dari itu, daripada kalian berlama-lama, maka kita langsung saja hidangkan resep soto ayam khas aceh ini. Dijamin kamu tiidak akan menyesal bikin resep soto ayam khas aceh enak sederhana ini! Selamat berkreasi dengan resep soto ayam khas aceh lezat sederhana ini di tempat tinggal masing-masing,oke!.

