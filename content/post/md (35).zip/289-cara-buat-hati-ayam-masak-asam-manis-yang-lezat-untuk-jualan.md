---
description: "Cara buat Hati Ayam Masak Asam Manis yang lezat Untuk Jualan"
title: "Cara buat Hati Ayam Masak Asam Manis yang lezat Untuk Jualan"
slug: 289-cara-buat-hati-ayam-masak-asam-manis-yang-lezat-untuk-jualan
date: 2021-06-26T01:26:26.084Z
image: https://img-global.cpcdn.com/recipes/d65138a4ae7c883d/680x482cq70/hati-ayam-masak-asam-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d65138a4ae7c883d/680x482cq70/hati-ayam-masak-asam-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d65138a4ae7c883d/680x482cq70/hati-ayam-masak-asam-manis-foto-resep-utama.jpg
author: Irene Mathis
ratingvalue: 4.2
reviewcount: 4
recipeingredient:
- "3 bh Hati Ayam Kampung"
- "5 siung Bawang merah"
- "4 siung Bawang putih"
- "1 bh Bawang merah besar"
- "4 bh Cabe Hijau besar"
- "1 bh Tomat"
- "2 papan petai kupas"
- "1 bks Terasi larutkan dengan air"
- "1 sdm Gula merah serut"
- " Garam"
- " Gula pasir"
- " Penyedap rasa"
recipeinstructions:
- "Bersihkan hati ayam, potong persegi kecil. Beri perasan air jeruk nipis dan garam. Diamkan sebentar. Cuci bersih."
- "Rebus hati ayam sebentar, tiriskan. Sisihkan."
- "Siapkan bahan-bahan lainnya, iris bawang, cabe merah, cabe hijau, tomat, petai."
- "Tumis bumbu iris sampai harum dan layu"
- "Masukkan hati ayam, aduk rata. Tumis sebentar. Masukkan air terasi."
- "Masukkan petai dan Tambahkan sedikit air, beri garam, gula pasir, gula merah, dan penyedap. Aduk rata."
- "Masak sampai kuah menyusut dan hati matang, cek rasa, bila sudah pas, angkat. Sajikan."
categories:
- Resep
tags:
- hati
- ayam
- masak

katakunci: hati ayam masak 
nutrition: 101 calories
recipecuisine: Indonesian
preptime: "PT29M"
cooktime: "PT57M"
recipeyield: "4"
recipecategory: Dinner

---


![Hati Ayam Masak Asam Manis](https://img-global.cpcdn.com/recipes/d65138a4ae7c883d/680x482cq70/hati-ayam-masak-asam-manis-foto-resep-utama.jpg)

Andai anda seorang yang hobi masak, menyajikan santapan nikmat bagi keluarga tercinta adalah hal yang menggembirakan bagi anda sendiri. Tugas seorang ibu Tidak sekadar mengerjakan pekerjaan rumah saja, namun anda juga harus memastikan kebutuhan gizi terpenuhi dan juga olahan yang disantap keluarga tercinta harus enak.

Di masa  sekarang, kamu sebenarnya dapat membeli panganan yang sudah jadi tanpa harus repot mengolahnya terlebih dahulu. Tetapi banyak juga lho mereka yang selalu ingin memberikan yang terbaik bagi keluarganya. Karena, menyajikan masakan yang dibuat sendiri jauh lebih bersih dan bisa menyesuaikan masakan tersebut berdasarkan selera orang tercinta. 



Apakah anda seorang penggemar hati ayam masak asam manis?. Tahukah kamu, hati ayam masak asam manis merupakan makanan khas di Nusantara yang sekarang disukai oleh setiap orang di berbagai wilayah di Nusantara. Kalian dapat memasak hati ayam masak asam manis hasil sendiri di rumah dan boleh dijadikan makanan favoritmu di akhir pekan.

Kamu tidak usah bingung jika kamu ingin memakan hati ayam masak asam manis, lantaran hati ayam masak asam manis tidak sukar untuk dicari dan juga anda pun bisa menghidangkannya sendiri di rumah. hati ayam masak asam manis bisa dimasak memalui beraneka cara. Kini pun telah banyak sekali cara modern yang membuat hati ayam masak asam manis lebih mantap.

Resep hati ayam masak asam manis pun mudah sekali dibikin, lho. Kita jangan ribet-ribet untuk memesan hati ayam masak asam manis, sebab Kita mampu menghidangkan di rumah sendiri. Bagi Anda yang mau menyajikannya, dibawah ini merupakan resep untuk menyajikan hati ayam masak asam manis yang nikamat yang bisa Kamu coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Hati Ayam Masak Asam Manis:

1. Siapkan 3 bh Hati Ayam Kampung
1. Siapkan 5 siung Bawang merah
1. Gunakan 4 siung Bawang putih
1. Gunakan 1 bh Bawang merah besar
1. Siapkan 4 bh Cabe Hijau besar
1. Ambil 1 bh Tomat
1. Siapkan 2 papan petai, kupas
1. Sediakan 1 bks Terasi, larutkan dengan air
1. Gunakan 1 sdm Gula merah, serut
1. Siapkan  Garam
1. Ambil  Gula pasir
1. Gunakan  Penyedap rasa




<!--inarticleads2-->

##### Langkah-langkah membuat Hati Ayam Masak Asam Manis:

1. Bersihkan hati ayam, potong persegi kecil. Beri perasan air jeruk nipis dan garam. Diamkan sebentar. Cuci bersih.
1. Rebus hati ayam sebentar, tiriskan. Sisihkan.
1. Siapkan bahan-bahan lainnya, iris bawang, cabe merah, cabe hijau, tomat, petai.
1. Tumis bumbu iris sampai harum dan layu
1. Masukkan hati ayam, aduk rata. Tumis sebentar. Masukkan air terasi.
1. Masukkan petai dan Tambahkan sedikit air, beri garam, gula pasir, gula merah, dan penyedap. Aduk rata.
1. Masak sampai kuah menyusut dan hati matang, cek rasa, bila sudah pas, angkat. Sajikan.




Ternyata cara membuat hati ayam masak asam manis yang enak tidak ribet ini enteng sekali ya! Kamu semua bisa menghidangkannya. Cara buat hati ayam masak asam manis Sangat cocok banget buat kamu yang sedang belajar memasak atau juga untuk kamu yang telah hebat memasak.

Apakah kamu ingin mulai mencoba bikin resep hati ayam masak asam manis nikmat simple ini? Kalau kalian ingin, ayo kalian segera siapkan peralatan dan bahan-bahannya, lantas buat deh Resep hati ayam masak asam manis yang enak dan simple ini. Benar-benar gampang kan. 

Jadi, daripada anda berfikir lama-lama, yuk kita langsung bikin resep hati ayam masak asam manis ini. Dijamin kalian tiidak akan nyesel bikin resep hati ayam masak asam manis mantab tidak ribet ini! Selamat mencoba dengan resep hati ayam masak asam manis enak sederhana ini di tempat tinggal kalian sendiri,ya!.

