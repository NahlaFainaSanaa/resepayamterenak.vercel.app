---
description: "Cara buat Semur Ayam yang lezat dan Mudah Dibuat"
title: "Cara buat Semur Ayam yang lezat dan Mudah Dibuat"
slug: 200-cara-buat-semur-ayam-yang-lezat-dan-mudah-dibuat
date: 2021-01-29T03:42:07.121Z
image: https://img-global.cpcdn.com/recipes/0ff80d21466f2d33/680x482cq70/semur-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0ff80d21466f2d33/680x482cq70/semur-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0ff80d21466f2d33/680x482cq70/semur-ayam-foto-resep-utama.jpg
author: Nathan Townsend
ratingvalue: 4.9
reviewcount: 6
recipeingredient:
- " Bumbu Ayam"
- "500 gram ayam fillet"
- "1/2 sdt lada garam dan kaldu bubuk"
- "1 buah jeruk nipis"
- " Bumbu Halus"
- "2 buah cabe rawit setan"
- "3 siung bawang merah"
- "2 siung bawang putih"
- "1/2 sdt lada bubuk kunyit bubuk ketumbar garam"
- "3 butir kemiri skip"
- " Bahan tambahan"
- "2 sdm kecap manis"
- "2 sdt gula pasir"
- "3 lembar daun salam"
- "5 lembar daun jeruk"
- "2 batang sereh"
- "2 buah kentang potong2 jadi 4 bagian"
- "secukupnya Minyak goreng"
- "secukupnya Air matang"
recipeinstructions:
- "Siapkan semua bahan ayam dan bumbu halus."
- "Kemudian marinasi bahan ayam selama 1 jam"
- "Panaskan minyak goreng dan tumis bumbu halus hingga tercium aromanya."
- "Masukkan bahan tambahan seperti daun jeruk, daun salam, jahe, lengkuas, sereh, kecap manis dan gula pasir."
- "Lalu masukkan ayam yg sudah di marinasi, kentang dan aduk hingga merata. Kemudian tambahkan air matang dan tunggu hingga mendidih dan ayam empuk."
- "Terakhir koreksi rasa, bila di rasa sudah cukup pisahkan bumbu tambahan seperti daun jeruk, daun salam, sereh dan pindahkan semur ayam ke dalam wadah."
- "Semur ayam siap untuk di sajikan dengan nasi hangat dan taburan bawang goreng instan"
- "Ketika s"
categories:
- Resep
tags:
- semur
- ayam

katakunci: semur ayam 
nutrition: 224 calories
recipecuisine: Indonesian
preptime: "PT24M"
cooktime: "PT41M"
recipeyield: "2"
recipecategory: Dessert

---


![Semur Ayam](https://img-global.cpcdn.com/recipes/0ff80d21466f2d33/680x482cq70/semur-ayam-foto-resep-utama.jpg)

Sebagai seorang wanita, mempersiapkan hidangan mantab bagi keluarga tercinta adalah suatu hal yang memuaskan untuk kita sendiri. Peran seorang istri Tidak cuma mengerjakan pekerjaan rumah saja, tetapi anda juga wajib memastikan keperluan nutrisi tercukupi dan juga olahan yang disantap keluarga tercinta harus menggugah selera.

Di era  saat ini, kita memang dapat membeli hidangan yang sudah jadi meski tidak harus repot mengolahnya lebih dulu. Tapi banyak juga lho orang yang memang ingin memberikan hidangan yang terenak untuk orang yang dicintainya. Sebab, memasak yang dibuat sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan sesuai makanan kesukaan keluarga tercinta. 



Mungkinkah anda adalah seorang penikmat semur ayam?. Asal kamu tahu, semur ayam merupakan hidangan khas di Nusantara yang saat ini digemari oleh orang-orang dari hampir setiap tempat di Nusantara. Kalian bisa memasak semur ayam sendiri di rumah dan dapat dijadikan santapan favoritmu di hari liburmu.

Anda tidak usah bingung jika kamu ingin mendapatkan semur ayam, sebab semur ayam mudah untuk didapatkan dan anda pun boleh memasaknya sendiri di rumah. semur ayam bisa dimasak memalui bermacam cara. Saat ini sudah banyak banget resep modern yang menjadikan semur ayam lebih mantap.

Resep semur ayam pun gampang sekali dibikin, lho. Kamu tidak usah ribet-ribet untuk memesan semur ayam, sebab Anda bisa menghidangkan di rumah sendiri. Bagi Kalian yang ingin menghidangkannya, inilah resep membuat semur ayam yang enak yang mampu Kita coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Semur Ayam:

1. Siapkan  Bumbu Ayam
1. Gunakan 500 gram ayam fillet
1. Gunakan 1/2 sdt lada, garam, dan kaldu bubuk
1. Siapkan 1 buah jeruk nipis
1. Sediakan  Bumbu Halus
1. Ambil 2 buah cabe rawit setan
1. Gunakan 3 siung bawang merah
1. Siapkan 2 siung bawang putih
1. Gunakan 1/2 sdt lada bubuk, kunyit bubuk, ketumbar, garam
1. Sediakan 3 butir kemiri (skip)
1. Gunakan  Bahan tambahan
1. Siapkan 2 sdm kecap manis
1. Gunakan 2 sdt gula pasir
1. Siapkan 3 lembar daun salam
1. Ambil 5 lembar daun jeruk
1. Sediakan 2 batang sereh
1. Sediakan 2 buah kentang (potong2 jadi 4 bagian)
1. Siapkan secukupnya Minyak goreng
1. Gunakan secukupnya Air matang




<!--inarticleads2-->

##### Langkah-langkah membuat Semur Ayam:

1. Siapkan semua bahan ayam dan bumbu halus.
1. Kemudian marinasi bahan ayam selama 1 jam
1. Panaskan minyak goreng dan tumis bumbu halus hingga tercium aromanya.
1. Masukkan bahan tambahan seperti daun jeruk, daun salam, jahe, lengkuas, sereh, kecap manis dan gula pasir.
1. Lalu masukkan ayam yg sudah di marinasi, kentang dan aduk hingga merata. Kemudian tambahkan air matang dan tunggu hingga mendidih dan ayam empuk.
1. Terakhir koreksi rasa, bila di rasa sudah cukup pisahkan bumbu tambahan seperti daun jeruk, daun salam, sereh dan pindahkan semur ayam ke dalam wadah.
1. Semur ayam siap untuk di sajikan dengan nasi hangat dan taburan bawang goreng instan
1. Ketika s




Wah ternyata cara buat semur ayam yang mantab sederhana ini enteng sekali ya! Kita semua dapat mencobanya. Cara Membuat semur ayam Sangat cocok sekali untuk anda yang baru mau belajar memasak maupun untuk kalian yang telah jago memasak.

Apakah kamu ingin mulai mencoba buat resep semur ayam enak tidak rumit ini? Kalau kalian ingin, yuk kita segera siapin alat dan bahannya, lalu bikin deh Resep semur ayam yang nikmat dan tidak ribet ini. Sungguh mudah kan. 

Oleh karena itu, ketimbang kalian diam saja, maka kita langsung saja bikin resep semur ayam ini. Pasti kamu tak akan menyesal sudah bikin resep semur ayam lezat tidak ribet ini! Selamat berkreasi dengan resep semur ayam nikmat tidak ribet ini di rumah kalian masing-masing,oke!.

