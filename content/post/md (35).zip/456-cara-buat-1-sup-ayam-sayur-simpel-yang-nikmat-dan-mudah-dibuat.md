---
description: "Cara buat #1 Sup Ayam Sayur Simpel yang nikmat dan Mudah Dibuat"
title: "Cara buat #1 Sup Ayam Sayur Simpel yang nikmat dan Mudah Dibuat"
slug: 456-cara-buat-1-sup-ayam-sayur-simpel-yang-nikmat-dan-mudah-dibuat
date: 2021-06-10T13:25:34.140Z
image: https://img-global.cpcdn.com/recipes/96a88dfdb1287f90/680x482cq70/1-sup-ayam-sayur-simpel-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/96a88dfdb1287f90/680x482cq70/1-sup-ayam-sayur-simpel-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/96a88dfdb1287f90/680x482cq70/1-sup-ayam-sayur-simpel-foto-resep-utama.jpg
author: Jacob Davis
ratingvalue: 3.6
reviewcount: 4
recipeingredient:
- " Isi Sup"
- "1 buah wortel irisiris"
- "12 buah buncis potong memanjang"
- "2 buah kentang kecil kalau besar 1 aja potong dadu"
- "potong dadu Daging dada ayam secukupnya"
- " Kol  dibuka lembarannya robek sebesar selera masing2"
- " Bawang putih 8 siung kalau ga suka boleh kurangi"
- "1,5 L Air"
- " Bumbu"
- " Daun bawang"
- "sesuai selera Garam"
- "sesuai selera Lada"
- " Royco ayam sesuai selera ga pakai juga ok"
- " Opsional"
- "Iris bawang merah dan buat bawang goreng makin enak"
recipeinstructions:
- "Siapkan semua bahan dulu."
- "Didihkan air di panci."
- "Masukan potongan ayam, rebus hingga putih dan mulai matang sekitar 2-3 menit."
- "Masukkan bawang putih, kentang, dan wortel. Biarkan sekitar 5-8 menit."
- "Masukkan buncis dan ketika terlihat sudah mulai matang (agak mengembang dan mengambang), masukkan kol."
- "Tambahkan garam sampai asinnya pas."
- "Masukkan daun bawang, aduk sebentar sekitar 30 detik, lalu matikan kompor."
- "Masukkan Royco dan lada di sendok sayur, cairkan dengan sedikit air di panci lalu aduk merata di sup."
- "Siap disajikan dengan bawang goreng, resep menyusul."
categories:
- Resep
tags:
- 1
- sup
- ayam

katakunci: 1 sup ayam 
nutrition: 213 calories
recipecuisine: Indonesian
preptime: "PT36M"
cooktime: "PT49M"
recipeyield: "1"
recipecategory: Lunch

---


![#1 Sup Ayam Sayur Simpel](https://img-global.cpcdn.com/recipes/96a88dfdb1287f90/680x482cq70/1-sup-ayam-sayur-simpel-foto-resep-utama.jpg)

Jika kita seorang wanita, menyajikan masakan nikmat untuk keluarga tercinta adalah suatu hal yang mengasyikan bagi anda sendiri. Kewajiban seorang  wanita bukan sekedar menangani rumah saja, namun kamu juga harus menyediakan kebutuhan nutrisi terpenuhi dan juga hidangan yang disantap orang tercinta wajib lezat.

Di waktu  saat ini, kamu memang bisa mengorder masakan praktis meski tanpa harus repot mengolahnya dulu. Tetapi ada juga mereka yang memang ingin memberikan hidangan yang terenak untuk orang tercintanya. Sebab, menyajikan masakan yang diolah sendiri jauh lebih bersih dan kita juga bisa menyesuaikan sesuai masakan kesukaan keluarga. 



Mungkinkah anda merupakan salah satu penyuka #1 sup ayam sayur simpel?. Asal kamu tahu, #1 sup ayam sayur simpel merupakan sajian khas di Nusantara yang kini disukai oleh banyak orang di berbagai daerah di Indonesia. Kalian dapat memasak #1 sup ayam sayur simpel hasil sendiri di rumahmu dan boleh dijadikan camilan kegemaranmu di hari liburmu.

Kamu tak perlu bingung jika kamu ingin memakan #1 sup ayam sayur simpel, karena #1 sup ayam sayur simpel tidak sukar untuk didapatkan dan juga kalian pun boleh menghidangkannya sendiri di rumah. #1 sup ayam sayur simpel bisa dimasak lewat berbagai cara. Kini telah banyak banget cara modern yang membuat #1 sup ayam sayur simpel lebih enak.

Resep #1 sup ayam sayur simpel juga gampang dibuat, lho. Kamu tidak perlu capek-capek untuk memesan #1 sup ayam sayur simpel, sebab Kita bisa menyajikan di rumahmu. Untuk Anda yang akan membuatnya, di bawah ini adalah cara menyajikan #1 sup ayam sayur simpel yang nikamat yang dapat Anda hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan #1 Sup Ayam Sayur Simpel:

1. Siapkan  Isi Sup
1. Gunakan 1 buah wortel, iris-iris
1. Ambil 12 buah buncis, potong memanjang
1. Siapkan 2 buah kentang kecil (kalau besar 1 aja), potong dadu
1. Siapkan potong dadu Daging dada ayam secukupnya,
1. Ambil  Kol ¼, dibuka lembarannya, robek sebesar selera masing2
1. Gunakan  Bawang putih 8 siung (kalau ga suka boleh kurangi)
1. Siapkan 1,5 L Air
1. Siapkan  Bumbu
1. Siapkan  Daun bawang
1. Siapkan sesuai selera Garam
1. Gunakan sesuai selera Lada
1. Sediakan  Royco ayam sesuai selera, ga pakai juga ok
1. Siapkan  Opsional
1. Ambil Iris bawang merah dan buat bawang goreng, makin enak




<!--inarticleads2-->

##### Langkah-langkah menyiapkan #1 Sup Ayam Sayur Simpel:

1. Siapkan semua bahan dulu.
1. Didihkan air di panci.
1. Masukan potongan ayam, rebus hingga putih dan mulai matang sekitar 2-3 menit.
1. Masukkan bawang putih, kentang, dan wortel. Biarkan sekitar 5-8 menit.
1. Masukkan buncis dan ketika terlihat sudah mulai matang (agak mengembang dan mengambang), masukkan kol.
1. Tambahkan garam sampai asinnya pas.
1. Masukkan daun bawang, aduk sebentar sekitar 30 detik, lalu matikan kompor.
1. Masukkan Royco dan lada di sendok sayur, cairkan dengan sedikit air di panci lalu aduk merata di sup.
1. Siap disajikan dengan bawang goreng, resep menyusul.




Ternyata cara buat #1 sup ayam sayur simpel yang nikamt simple ini enteng sekali ya! Semua orang mampu membuatnya. Cara buat #1 sup ayam sayur simpel Sangat cocok banget buat kalian yang baru mau belajar memasak maupun juga untuk kalian yang telah pandai dalam memasak.

Tertarik untuk mulai mencoba membuat resep #1 sup ayam sayur simpel enak sederhana ini? Kalau ingin, ayo kalian segera buruan menyiapkan alat-alat dan bahannya, lantas bikin deh Resep #1 sup ayam sayur simpel yang enak dan tidak ribet ini. Benar-benar mudah kan. 

Oleh karena itu, ketimbang kita diam saja, ayo kita langsung saja bikin resep #1 sup ayam sayur simpel ini. Pasti kamu tak akan menyesal sudah membuat resep #1 sup ayam sayur simpel enak simple ini! Selamat berkreasi dengan resep #1 sup ayam sayur simpel mantab tidak ribet ini di rumah kalian masing-masing,oke!.

