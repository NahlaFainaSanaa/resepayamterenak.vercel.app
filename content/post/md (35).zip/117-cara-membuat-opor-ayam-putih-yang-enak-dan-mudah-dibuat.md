---
description: "Cara membuat Opor Ayam Putih yang enak dan Mudah Dibuat"
title: "Cara membuat Opor Ayam Putih yang enak dan Mudah Dibuat"
slug: 117-cara-membuat-opor-ayam-putih-yang-enak-dan-mudah-dibuat
date: 2021-02-04T17:32:08.812Z
image: https://img-global.cpcdn.com/recipes/a81f0418b6ca9bbb/680x482cq70/opor-ayam-putih-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a81f0418b6ca9bbb/680x482cq70/opor-ayam-putih-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a81f0418b6ca9bbb/680x482cq70/opor-ayam-putih-foto-resep-utama.jpg
author: Etta Howard
ratingvalue: 4.8
reviewcount: 15
recipeingredient:
- " Bahan Dasar"
- "500 gr ayam"
- "1/2 papan tempepotong2"
- "4 butir telur rebuskupas"
- "2 kotak tahu suterapotong2"
- " Minyak goreng untuk menumis"
- "130 ml 2 bungkus santan instan sy kara"
- "1 sdm garam"
- "1,5 sdm kaldu jamur"
- "1,5 sdm gula"
- "1 liter air"
- " Bumbu Cemplung"
- "1-2 batang sereh geprek"
- "4 lembar daun salam"
- "4 lembar daun jeruk"
- "Sejempol lengkuas"
- " Bumbu halus"
- "7 suing bawang merah"
- "5 siung bawang putih"
- "3 butir kemiri"
- "1 sdt ketumbar"
- "1/2 sdt jinten"
- "2 cm jahe"
- "1 bungkus bumbu opor instan sy Bamboee Boleh skip"
recipeinstructions:
- "Siapkan bahan2 nya, sebelumnya cuci ayam dgn air matang,lalu marinasi ayam dengan jeruk nipis dan diamkan minimal 15 menit."
- "Haluskan bumbu halus,lalu panaskan minyak dlm wajan, lalu tumis bumbu halus sampai matang dan minyaknya terpisah."
- "Setelah itu masukkan bumbu2 cemplungnya"
- "Dilanjut dengan ayamnya,aduk hingga ayam berubah warna, lalu tambahkan air. Setelah air mendidih, masukkan bahan2 lain. Saya wajannya tidak muat, lalu ganti pakai panci."
- "Lalu masukkan gula,garam,dan kaldu jamur. Setelah benar2 mendidih lagi, baru masukkan santan. Lalu kecilkan api dan aduk2 terus agar santan tidak pecah.Lakukan tes rasa, setelah pas, lalu terus diaduk dan didihkan hingga kuah menyusut sesuai selera.Selamat memasak :)"
- "Cocok dinikmati bersama nasi hangat"
categories:
- Resep
tags:
- opor
- ayam
- putih

katakunci: opor ayam putih 
nutrition: 157 calories
recipecuisine: Indonesian
preptime: "PT16M"
cooktime: "PT35M"
recipeyield: "4"
recipecategory: Dessert

---


![Opor Ayam Putih](https://img-global.cpcdn.com/recipes/a81f0418b6ca9bbb/680x482cq70/opor-ayam-putih-foto-resep-utama.jpg)

Apabila kita seorang istri, menyuguhkan hidangan sedap kepada keluarga adalah hal yang membahagiakan bagi kita sendiri. Kewajiban seorang  wanita Tidak saja mengerjakan pekerjaan rumah saja, tetapi anda pun harus menyediakan kebutuhan nutrisi tercukupi dan juga olahan yang dikonsumsi anak-anak wajib sedap.

Di masa  sekarang, kamu memang mampu mengorder hidangan jadi meski tanpa harus capek membuatnya lebih dulu. Tetapi banyak juga mereka yang selalu mau menghidangkan yang terbaik bagi orang tercintanya. Sebab, memasak yang diolah sendiri jauh lebih higienis dan kita pun bisa menyesuaikan masakan tersebut sesuai makanan kesukaan keluarga tercinta. 



Mungkinkah anda merupakan salah satu penikmat opor ayam putih?. Tahukah kamu, opor ayam putih merupakan hidangan khas di Nusantara yang sekarang disukai oleh orang-orang dari berbagai daerah di Indonesia. Kita dapat menyajikan opor ayam putih sendiri di rumahmu dan dapat dijadikan hidangan favorit di hari libur.

Kamu tidak usah bingung untuk memakan opor ayam putih, lantaran opor ayam putih gampang untuk dicari dan juga kalian pun bisa mengolahnya sendiri di tempatmu. opor ayam putih boleh dimasak dengan beraneka cara. Saat ini ada banyak banget resep kekinian yang membuat opor ayam putih semakin lebih nikmat.

Resep opor ayam putih pun mudah dihidangkan, lho. Kamu tidak perlu repot-repot untuk membeli opor ayam putih, lantaran Kalian dapat menyiapkan ditempatmu. Untuk Kamu yang akan mencobanya, berikut cara membuat opor ayam putih yang mantab yang dapat Kamu buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Opor Ayam Putih:

1. Ambil  Bahan Dasar:
1. Siapkan 500 gr ayam
1. Ambil 1/2 papan tempe,potong2
1. Siapkan 4 butir telur rebus,kupas
1. Ambil 2 kotak tahu sutera,potong2
1. Gunakan  Minyak goreng untuk menumis
1. Siapkan 130 ml /2 bungkus santan instan (sy kara)
1. Siapkan 1 sdm garam
1. Ambil 1,5 sdm kaldu jamur
1. Sediakan 1,5 sdm gula
1. Gunakan 1 liter air
1. Ambil  Bumbu Cemplung:
1. Ambil 1-2 batang sereh, geprek
1. Gunakan 4 lembar daun salam
1. Gunakan 4 lembar daun jeruk
1. Siapkan Sejempol lengkuas
1. Ambil  Bumbu halus
1. Gunakan 7 suing bawang merah
1. Ambil 5 siung bawang putih
1. Siapkan 3 butir kemiri
1. Gunakan 1 sdt ketumbar
1. Gunakan 1/2 sdt jinten
1. Gunakan 2 cm jahe
1. Ambil 1 bungkus bumbu opor instan (sy Bamboee) Boleh skip




<!--inarticleads2-->

##### Langkah-langkah membuat Opor Ayam Putih:

1. Siapkan bahan2 nya, sebelumnya cuci ayam dgn air matang,lalu marinasi ayam dengan jeruk nipis dan diamkan minimal 15 menit.
1. Haluskan bumbu halus,lalu panaskan minyak dlm wajan, lalu tumis bumbu halus sampai matang dan minyaknya terpisah.
1. Setelah itu masukkan bumbu2 cemplungnya
1. Dilanjut dengan ayamnya,aduk hingga ayam berubah warna, lalu tambahkan air. Setelah air mendidih, masukkan bahan2 lain. Saya wajannya tidak muat, lalu ganti pakai panci.
1. Lalu masukkan gula,garam,dan kaldu jamur. Setelah benar2 mendidih lagi, baru masukkan santan. Lalu kecilkan api dan aduk2 terus agar santan tidak pecah.Lakukan tes rasa, setelah pas, lalu terus diaduk dan didihkan hingga kuah menyusut sesuai selera.Selamat memasak :)
1. Cocok dinikmati bersama nasi hangat




Wah ternyata cara buat opor ayam putih yang mantab tidak rumit ini mudah banget ya! Anda Semua bisa membuatnya. Resep opor ayam putih Sangat sesuai sekali buat anda yang sedang belajar memasak maupun untuk kalian yang sudah ahli dalam memasak.

Apakah kamu mau mulai mencoba buat resep opor ayam putih nikmat tidak rumit ini? Kalau tertarik, ayo kamu segera buruan siapkan alat-alat dan bahan-bahannya, maka bikin deh Resep opor ayam putih yang mantab dan tidak rumit ini. Sangat gampang kan. 

Maka dari itu, daripada kalian berlama-lama, ayo kita langsung saja hidangkan resep opor ayam putih ini. Pasti anda tak akan menyesal membuat resep opor ayam putih nikmat simple ini! Selamat berkreasi dengan resep opor ayam putih enak sederhana ini di tempat tinggal masing-masing,ya!.

