---
description: "Cara buat Roti Cane Aceh/ Roti Maryam dengan Kari Ayam Sederhana dan Mudah Dibuat"
title: "Cara buat Roti Cane Aceh/ Roti Maryam dengan Kari Ayam Sederhana dan Mudah Dibuat"
slug: 165-cara-buat-roti-cane-aceh-roti-maryam-dengan-kari-ayam-sederhana-dan-mudah-dibuat
date: 2021-02-01T19:28:37.616Z
image: https://img-global.cpcdn.com/recipes/c2bed4c63a577f5d/680x482cq70/roti-cane-aceh-roti-maryam-dengan-kari-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c2bed4c63a577f5d/680x482cq70/roti-cane-aceh-roti-maryam-dengan-kari-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c2bed4c63a577f5d/680x482cq70/roti-cane-aceh-roti-maryam-dengan-kari-ayam-foto-resep-utama.jpg
author: Derrick Rose
ratingvalue: 4.5
reviewcount: 15
recipeingredient:
- " Bahan Kari Ayam "
- "500 gr ayam pejantan me ayam negeri"
- "1 saset kara"
- "500 ml air"
- "1/2 sdt garam"
- "1/2 sdt gula pasirme  1 sdm selera"
- "1/4 sdt kaldu jamur"
- " Bahan ungkepan Ayam"
- "1 sdt garam"
- " 1 sdt lada bubuk"
- "1 sdt kunyit bubuk"
- "1/2 butir jeruk nipis"
- " Bahan bumbu Halus"
- "3 siung bawang putih"
- "4 siung bawang merah"
- "7 buah cabe merah"
- "1 sdt ketumbar butiran"
- "1/2 sdt lada butiran"
- "1/2 sdt pala bubuk"
- "1/2 sdt jinten"
- "4 sdm kelapa sangrai kasar bisa lihat resep di nasi krawu cara bikin kelapa sangrai           lihat resep"
- " Bumbu Rempah tumisan"
- "1 siung bawang merah"
- "1 buah cengkeh"
- "1 buah kembang lawang"
- "1 butir kapulaga"
- "1 lembat daun pandan"
- "1 batang daun kari salam koja"
- "  Bahan Roti Cane"
- " Bahan A"
- "300 gr tepung pro tinggi"
- "1/2 sdt garam"
- "1 sdm gula halus me  gula kastrol"
- " Bahan B"
- "30 gr mentega cair"
- "1 butir telur utuh"
- "1 butir kuning telur"
- "130 gr susu cair hangat"
- "30 ml minyak zaitun me  minyak goreng"
- " Bahan c"
- "100 ml minyak goreng"
- " Bahan Tambahan"
- " Mentega buat olesan me skip"
recipeinstructions:
- "Membuat kari Ayam : Ungkep ayam, berserta bahan ungkepan sampai ayam setengah matang, saring, lalu angkat dan sisihkan"
- "Siapkan bumbu halus dan bumbu rempah tumisan"
- "Campur bumbu halus dengan santan dan ayam ungkep. Aduk biarkan sebentar biar bumbu tercampur.  Tumis bumbu rempah, sampai harum, masukkan dalam ayam yang, campur rata."
- "Masak ayam yang sudah dicampur bumbu, masak sebentar lalu masukkan air, masak sampai bumbu meresap dan kuah kental. Sisihkan terlebih dahulu"
- "Membuat Roti Cane : Masukkan bahan A, campur rata. Tambahkan bahan B yang sudah di kocok rata, kemudian uleni sampai kalis."
- "Setelah kalis, istirahatkan 20 menit. Setelah 20 menit bagi adonan menjadi masing2 50 gr (11 buah). Lalu rendam dalam minyak (bahan c) selama 2 jam"
- "Setelah 2 jam pipihkan adonan, lalu oles dengan mentega (me: pake minyak sisa rendaman) lalu tabur tepung terigu bolak balik."
- "Setelah itu lipat seperti membuat kipas, lalu gulung menyerupai obat nyamuk.  Lakukan sampai semua adonan habis. Istirahatkan lagi 20 menit."
- "Setelah itu pipihkan adoanan, lalu panaskan dalam teflon dengan cara di bolak balik, sampai kedua sisinya matang."
- "Cara penyajian:  Siapkan kuah kari dan potongan ayam kari. Cocolkan roti kedalam kuah kari dan potongan ayam kari.  Roti Cane aceh dengan kari Ayam siap di sajikan."
categories:
- Resep
tags:
- roti
- cane
- aceh

katakunci: roti cane aceh 
nutrition: 166 calories
recipecuisine: Indonesian
preptime: "PT13M"
cooktime: "PT41M"
recipeyield: "3"
recipecategory: Dinner

---


![Roti Cane Aceh/ Roti Maryam dengan Kari Ayam](https://img-global.cpcdn.com/recipes/c2bed4c63a577f5d/680x482cq70/roti-cane-aceh-roti-maryam-dengan-kari-ayam-foto-resep-utama.jpg)

Jika kalian seorang yang hobi memasak, menyajikan santapan nikmat bagi keluarga merupakan hal yang menyenangkan untuk kamu sendiri. Kewajiban seorang  wanita bukan sekedar mengurus rumah saja, namun kamu pun wajib menyediakan keperluan nutrisi tercukupi dan juga santapan yang dimakan anak-anak mesti enak.

Di waktu  saat ini, anda sebenarnya bisa membeli panganan siap saji walaupun tidak harus ribet memasaknya lebih dulu. Tapi ada juga mereka yang memang ingin memberikan yang terlezat bagi orang tercintanya. Karena, memasak sendiri jauh lebih higienis dan kita juga bisa menyesuaikan hidangan tersebut sesuai masakan kesukaan keluarga. 



Mungkinkah anda merupakan salah satu penikmat roti cane aceh/ roti maryam dengan kari ayam?. Tahukah kamu, roti cane aceh/ roti maryam dengan kari ayam adalah makanan khas di Indonesia yang sekarang disenangi oleh kebanyakan orang dari hampir setiap wilayah di Indonesia. Kalian bisa memasak roti cane aceh/ roti maryam dengan kari ayam hasil sendiri di rumah dan pasti jadi hidangan kesukaanmu di hari liburmu.

Anda jangan bingung untuk menyantap roti cane aceh/ roti maryam dengan kari ayam, lantaran roti cane aceh/ roti maryam dengan kari ayam sangat mudah untuk ditemukan dan juga kita pun bisa menghidangkannya sendiri di tempatmu. roti cane aceh/ roti maryam dengan kari ayam boleh diolah memalui bermacam cara. Sekarang sudah banyak banget resep modern yang menjadikan roti cane aceh/ roti maryam dengan kari ayam semakin enak.

Resep roti cane aceh/ roti maryam dengan kari ayam pun gampang sekali dibikin, lho. Kalian jangan repot-repot untuk memesan roti cane aceh/ roti maryam dengan kari ayam, sebab Anda dapat menyiapkan di rumahmu. Bagi Kalian yang mau menyajikannya, berikut resep untuk membuat roti cane aceh/ roti maryam dengan kari ayam yang nikamat yang mampu Kalian coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Roti Cane Aceh/ Roti Maryam dengan Kari Ayam:

1. Ambil  🍲Bahan Kari Ayam 👇👇
1. Gunakan 500 gr ayam pejantan (me: ayam negeri)
1. Siapkan 1 saset kara
1. Siapkan 500 ml air
1. Siapkan 1/2 sdt garam
1. Gunakan 1/2 sdt gula pasir(me : 1 sdm)/ selera
1. Siapkan 1/4 sdt kaldu jamur
1. Gunakan  Bahan ungkepan Ayam:
1. Sediakan 1 sdt garam
1. Siapkan  1 sdt lada bubuk
1. Gunakan 1 sdt kunyit bubuk
1. Sediakan 1/2 butir jeruk nipis
1. Siapkan  Bahan bumbu Halus:
1. Sediakan 3 siung bawang putih
1. Ambil 4 siung bawang merah
1. Sediakan 7 buah cabe merah
1. Ambil 1 sdt ketumbar butiran
1. Gunakan 1/2 sdt lada butiran
1. Ambil 1/2 sdt pala bubuk
1. Sediakan 1/2 sdt jinten
1. Ambil 4 sdm kelapa sangrai kasar (bisa lihat resep di nasi krawu cara bikin kelapa sangrai)           (lihat resep)
1. Ambil  Bumbu Rempah tumisan
1. Ambil 1 siung bawang merah
1. Ambil 1 buah cengkeh
1. Gunakan 1 buah kembang lawang
1. Gunakan 1 butir kapulaga
1. Siapkan 1 lembat daun pandan
1. Ambil 1 batang daun kari/ salam koja
1. Gunakan  🌮 Bahan Roti Cane
1. Gunakan  Bahan A
1. Ambil 300 gr tepung pro tinggi
1. Sediakan 1/2 sdt garam
1. Gunakan 1 sdm gula halus (me : gula kastrol)
1. Ambil  Bahan B
1. Sediakan 30 gr mentega cair
1. Ambil 1 butir telur utuh
1. Siapkan 1 butir kuning telur
1. Siapkan 130 gr susu cair hangat
1. Gunakan 30 ml minyak zaitun (me : minyak goreng)
1. Siapkan  Bahan c
1. Gunakan 100 ml minyak goreng
1. Siapkan  Bahan Tambahan
1. Gunakan  Mentega buat olesan (me :skip)




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Roti Cane Aceh/ Roti Maryam dengan Kari Ayam:

1. Membuat kari Ayam : - Ungkep ayam, berserta bahan ungkepan sampai ayam setengah matang, saring, lalu angkat dan sisihkan
1. Siapkan bumbu halus dan bumbu rempah tumisan
1. Campur bumbu halus dengan santan dan ayam ungkep. Aduk biarkan sebentar biar bumbu tercampur. -  - Tumis bumbu rempah, sampai harum, masukkan dalam ayam yang, campur rata.
1. Masak ayam yang sudah dicampur bumbu, masak sebentar lalu masukkan air, masak sampai bumbu meresap dan kuah kental. Sisihkan terlebih dahulu
1. Membuat Roti Cane : - Masukkan bahan A, campur rata. - Tambahkan bahan B yang sudah di kocok rata, kemudian uleni sampai kalis.
1. Setelah kalis, istirahatkan 20 menit. - Setelah 20 menit bagi adonan menjadi masing2 50 gr (11 buah). - Lalu rendam dalam minyak (bahan c) selama 2 jam
1. Setelah 2 jam pipihkan adonan, lalu oles dengan mentega (me: pake minyak sisa rendaman) lalu tabur tepung terigu bolak balik.
1. Setelah itu lipat seperti membuat kipas, lalu gulung menyerupai obat nyamuk.  - Lakukan sampai semua adonan habis. Istirahatkan lagi 20 menit.
1. Setelah itu pipihkan adoanan, lalu panaskan dalam teflon dengan cara di bolak balik, sampai kedua sisinya matang.
1. Cara penyajian:  - Siapkan kuah kari dan potongan ayam kari. - Cocolkan roti kedalam kuah kari dan potongan ayam kari. -  - Roti Cane aceh dengan kari Ayam siap di sajikan.




Wah ternyata cara membuat roti cane aceh/ roti maryam dengan kari ayam yang lezat simple ini enteng sekali ya! Anda Semua mampu menghidangkannya. Cara Membuat roti cane aceh/ roti maryam dengan kari ayam Sangat cocok banget untuk kita yang baru mau belajar memasak ataupun untuk kamu yang sudah ahli memasak.

Tertarik untuk mulai mencoba buat resep roti cane aceh/ roti maryam dengan kari ayam mantab sederhana ini? Kalau kamu tertarik, ayo kalian segera siapkan peralatan dan bahannya, lantas buat deh Resep roti cane aceh/ roti maryam dengan kari ayam yang lezat dan tidak ribet ini. Sangat gampang kan. 

Jadi, ketimbang kamu diam saja, maka kita langsung saja bikin resep roti cane aceh/ roti maryam dengan kari ayam ini. Dijamin kalian tak akan menyesal bikin resep roti cane aceh/ roti maryam dengan kari ayam mantab tidak rumit ini! Selamat mencoba dengan resep roti cane aceh/ roti maryam dengan kari ayam mantab tidak rumit ini di rumah kalian masing-masing,oke!.

