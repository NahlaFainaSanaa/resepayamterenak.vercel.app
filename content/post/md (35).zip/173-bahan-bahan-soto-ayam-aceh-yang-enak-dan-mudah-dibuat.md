---
description: "Bahan-bahan Soto Ayam Aceh yang enak dan Mudah Dibuat"
title: "Bahan-bahan Soto Ayam Aceh yang enak dan Mudah Dibuat"
slug: 173-bahan-bahan-soto-ayam-aceh-yang-enak-dan-mudah-dibuat
date: 2021-02-04T23:56:16.323Z
image: https://img-global.cpcdn.com/recipes/039fc59621c1d16b/680x482cq70/soto-ayam-aceh-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/039fc59621c1d16b/680x482cq70/soto-ayam-aceh-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/039fc59621c1d16b/680x482cq70/soto-ayam-aceh-foto-resep-utama.jpg
author: Ricky Knight
ratingvalue: 4.5
reviewcount: 9
recipeingredient:
- "1/2 ekor ayam potong kecil"
- "1 buah jeruk nipis"
- "150 ml santan kental"
- "1 batang daun bawangiris"
- "1 helai seledriiris"
- "1 buah tomatpotong"
- "2 siung bawang putihutk menumis"
- "Secukupnya garam"
- "Secukupnya gula"
- "Secukupnya kaldu bubuk"
- "Secukupnya minyakgoreng"
- "Secukupnya penyedapbole skip"
- "Secukupnya air"
- " Bumbu halus"
- "5 siung bawang putih"
- "6 siung bawang merah"
- "2 butir kemiri"
- "2 cm jahe"
- "1 sdt jinten"
- "1 sdt ketumbar bubuk"
- "1 sdt kunyit bubuk"
- "1/2 sdt lada bubuk"
- "1/2 sdt palabubuk"
- " Bumbu cemplung"
- "3 lembar daun salam"
- "1 batangserai geprek"
- "4 buah cengkeh"
- " Pelengkap"
- " Telur rebus"
- " Bawang goreng"
- " Sambel"
- " Perkedeltp sy skip"
recipeinstructions:
- "Tumis bawang merah hingga kecoklatan..masukkan bumbu halus dan bumbu cemplung.tmbhak air secukupnya lalu masukkan ayam.masak hingga ayam matang"
- "Setelah ayam matang,masuk kan santan,tomat,daun bawang"
- "Masukkan juga garam,gula dan kaldu bubuk.koreksi rasa...siap disajikan bersama pelengkap nya"
categories:
- Resep
tags:
- soto
- ayam
- aceh

katakunci: soto ayam aceh 
nutrition: 103 calories
recipecuisine: Indonesian
preptime: "PT23M"
cooktime: "PT37M"
recipeyield: "2"
recipecategory: Dinner

---


![Soto Ayam Aceh](https://img-global.cpcdn.com/recipes/039fc59621c1d16b/680x482cq70/soto-ayam-aceh-foto-resep-utama.jpg)

Sebagai seorang ibu, menyuguhkan olahan lezat pada keluarga merupakan hal yang sangat menyenangkan untuk kita sendiri. Tanggung jawab seorang istri bukan cuma menangani rumah saja, tetapi kamu juga harus menyediakan kebutuhan nutrisi terpenuhi dan hidangan yang disantap anak-anak harus sedap.

Di era  sekarang, kamu memang mampu memesan hidangan praktis meski tanpa harus capek mengolahnya dahulu. Tetapi banyak juga lho orang yang selalu ingin menyajikan yang terbaik bagi orang tercintanya. Karena, menyajikan masakan yang diolah sendiri jauh lebih higienis dan kita juga bisa menyesuaikan makanan tersebut sesuai masakan kesukaan keluarga. 



Apakah kamu salah satu penyuka soto ayam aceh?. Tahukah kamu, soto ayam aceh adalah makanan khas di Nusantara yang saat ini disukai oleh kebanyakan orang di hampir setiap daerah di Nusantara. Kita dapat membuat soto ayam aceh sendiri di rumah dan boleh dijadikan makanan kegemaranmu di akhir pekan.

Kita tidak perlu bingung untuk memakan soto ayam aceh, karena soto ayam aceh sangat mudah untuk ditemukan dan kalian pun dapat memasaknya sendiri di rumah. soto ayam aceh bisa dimasak lewat bermacam cara. Sekarang sudah banyak sekali cara modern yang menjadikan soto ayam aceh semakin mantap.

Resep soto ayam aceh juga sangat gampang dibikin, lho. Kamu jangan ribet-ribet untuk memesan soto ayam aceh, sebab Kalian mampu menyajikan di rumah sendiri. Bagi Kamu yang akan mencobanya, inilah cara menyajikan soto ayam aceh yang enak yang mampu Kita coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Soto Ayam Aceh:

1. Siapkan 1/2 ekor ayam potong kecil
1. Sediakan 1 buah jeruk nipis
1. Ambil 150 ml santan kental
1. Ambil 1 batang daun bawang,iris
1. Siapkan 1 helai seledri,iris
1. Siapkan 1 buah tomat,potong
1. Ambil 2 siung bawang putih,utk menumis
1. Siapkan Secukupnya garam
1. Gunakan Secukupnya gula
1. Gunakan Secukupnya kaldu bubuk
1. Gunakan Secukupnya minyak.goreng
1. Siapkan Secukupnya penyedap(bole skip)
1. Ambil Secukupnya air
1. Sediakan  Bumbu halus:
1. Gunakan 5 siung bawang putih
1. Gunakan 6 siung bawang merah
1. Sediakan 2 butir kemiri
1. Ambil 2 cm jahe
1. Gunakan 1 sdt jinten
1. Gunakan 1 sdt ketumbar bubuk
1. Ambil 1 sdt kunyit bubuk
1. Siapkan 1/2 sdt lada bubuk
1. Siapkan 1/2 sdt palabubuk
1. Siapkan  Bumbu cemplung:
1. Ambil 3 lembar daun salam
1. Siapkan 1 batangserai geprek
1. Siapkan 4 buah cengkeh
1. Ambil  Pelengkap:
1. Siapkan  Telur rebus
1. Sediakan  Bawang goreng
1. Gunakan  Sambel
1. Siapkan  Perkedel(tp sy skip)




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Soto Ayam Aceh:

1. Tumis bawang merah hingga kecoklatan..masukkan bumbu halus dan bumbu cemplung.tmbhak air secukupnya lalu masukkan ayam.masak hingga ayam matang
1. Setelah ayam matang,masuk kan santan,tomat,daun bawang
1. Masukkan juga garam,gula dan kaldu bubuk.koreksi rasa...siap disajikan bersama pelengkap nya




Ternyata resep soto ayam aceh yang nikamt simple ini gampang banget ya! Semua orang bisa membuatnya. Cara Membuat soto ayam aceh Sangat sesuai banget untuk kita yang sedang belajar memasak ataupun bagi kalian yang telah pandai dalam memasak.

Tertarik untuk mencoba membuat resep soto ayam aceh mantab simple ini? Kalau anda tertarik, ayo kamu segera menyiapkan peralatan dan bahan-bahannya, lantas buat deh Resep soto ayam aceh yang nikmat dan simple ini. Benar-benar gampang kan. 

Maka, ketimbang kalian berfikir lama-lama, ayo kita langsung saja hidangkan resep soto ayam aceh ini. Dijamin kalian gak akan nyesel sudah membuat resep soto ayam aceh mantab tidak ribet ini! Selamat mencoba dengan resep soto ayam aceh lezat sederhana ini di tempat tinggal sendiri,ya!.

