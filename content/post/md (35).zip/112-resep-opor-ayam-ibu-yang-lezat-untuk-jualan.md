---
description: "Resep Opor ayam ibu yang lezat Untuk Jualan"
title: "Resep Opor ayam ibu yang lezat Untuk Jualan"
slug: 112-resep-opor-ayam-ibu-yang-lezat-untuk-jualan
date: 2021-02-24T09:54:49.226Z
image: https://img-global.cpcdn.com/recipes/14f8628e52967751/680x482cq70/opor-ayam-ibu-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/14f8628e52967751/680x482cq70/opor-ayam-ibu-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/14f8628e52967751/680x482cq70/opor-ayam-ibu-foto-resep-utama.jpg
author: Eleanor Elliott
ratingvalue: 4.2
reviewcount: 10
recipeingredient:
- "3 kg ayam me campur"
- " Bumbu ayam untuk goreng  marinasi diulek"
- " Lada putih utuh"
- " Bawang putih"
- " Kunyit"
- " Garam royco sasa"
- " Minyak untuk menggoreng"
- " Bumbu Opor yang digoreng dan diulek"
- "1 sdm lada putih utuh butiran"
- "2 sdm ketumbar utuh butiran"
- "2 iris pala utuh"
- "4 ruas kunyit"
- "1 buah cabe merah"
- "6-7 siung bawang putih"
- "8-9 siung bawang merah"
- "15 buah kemiri"
- " Tambahan untuk diulek yang mentah"
- "6 siung bawang putih sedang"
- "4 siung bawang merah besar"
- " 3  5 siung Bawang merah iris"
- " Bahan A"
- "3 ikat sereh geprek"
- "7 ruas lengkuas geprek"
- "3 ruas jahe geprek"
- "5 lembar daun salam"
- " Bahan B"
- "3 tangkai daun bawang iris"
- "2 buah tomat iris"
- " Bahan C"
- "1-2 sdm gula merah"
- "1 sdm garam"
- "1 sdm Royco"
- "1/2 sdm penyedap rasa sasa"
- " Bahan D perlahan"
- " Sekitar 10 liter air bisa disesuaikan sesuai taste"
- "3 buah batok kelapa tua buat santan encer dan kental"
recipeinstructions:
- "Goreng ayam jangan terlalu kering dengan marinasi lada putih, bawang putih, kunyit, garam, royco dan sasa secukupnya, sisihkan"
- "Untuk bumbu ulek, goreng kunyit terlebih dahulu bila sudah sedikit layu, masukkan kemiri sampai agak matang, lalu masukkan bawang putih - bawang merah sampai layu dan masukkan cabe merah. Masak hingga matang / wangi dan layu. Angkat, tiriskan dan sisihkan."
- "Goreng lada putih utuh, ketumbar dan pala hingga matang. Angkat, tiriskan dan sisihkan."
- "Haluskan bumbu opor yg digoreng dan yg mentah"
- ""
- ""
- ""
- "Panaskan minyak, tumis bawang merah yg sudah diiris hingga layu"
- "Lalu masukkan bumbu ulek dan Bahan A, aduk aduk hingga harum."
- ""
- "Lanjut masukkan Bahan B dan Bahan C, aduk merata, bila sudah matang masukkan ayam yg sudah digoreng, beri sedikit air dan aduk rata"
- "Bila sudah rata masukkan air secara perlahan sambil diaduk hingga mendidih."
- "Masukkan santan encer, perlahan lalu masukkan santan kental dan aduk aduk agak tidak pecah. Masak hingga matang."
- "Dan siap disajikan lebih enak dengan ketupat, bawang goreng, kecap, sambel goreng kentang juga kerupuk udang."
- "Selamat mencoba."
categories:
- Resep
tags:
- opor
- ayam
- ibu

katakunci: opor ayam ibu 
nutrition: 203 calories
recipecuisine: Indonesian
preptime: "PT33M"
cooktime: "PT45M"
recipeyield: "3"
recipecategory: Dinner

---


![Opor ayam ibu](https://img-global.cpcdn.com/recipes/14f8628e52967751/680x482cq70/opor-ayam-ibu-foto-resep-utama.jpg)

Sebagai seorang yang hobi memasak, menyediakan olahan sedap kepada keluarga merupakan hal yang sangat menyenangkan untuk kita sendiri. Tanggung jawab seorang ibu bukan sekedar mengatur rumah saja, tapi anda pun harus menyediakan kebutuhan gizi terpenuhi dan juga olahan yang disantap anak-anak harus enak.

Di zaman  saat ini, anda sebenarnya dapat membeli panganan siap saji tanpa harus ribet mengolahnya dahulu. Tetapi banyak juga mereka yang memang mau menghidangkan yang terenak bagi keluarganya. Sebab, memasak yang dibuat sendiri jauh lebih higienis dan kita juga bisa menyesuaikan masakan tersebut sesuai kesukaan orang tercinta. 



Mungkinkah anda adalah seorang penikmat opor ayam ibu?. Tahukah kamu, opor ayam ibu adalah makanan khas di Indonesia yang sekarang disukai oleh kebanyakan orang di berbagai daerah di Indonesia. Anda dapat menyajikan opor ayam ibu hasil sendiri di rumah dan boleh jadi camilan favorit di akhir pekanmu.

Kalian tidak perlu bingung untuk memakan opor ayam ibu, lantaran opor ayam ibu mudah untuk dicari dan kalian pun dapat memasaknya sendiri di tempatmu. opor ayam ibu bisa dibuat memalui beragam cara. Sekarang telah banyak cara kekinian yang menjadikan opor ayam ibu lebih enak.

Resep opor ayam ibu juga sangat gampang untuk dibuat, lho. Kita jangan repot-repot untuk membeli opor ayam ibu, tetapi Kamu mampu membuatnya di rumah sendiri. Untuk Kalian yang mau membuatnya, berikut ini cara menyajikan opor ayam ibu yang nikamat yang bisa Kalian coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Opor ayam ibu:

1. Ambil 3 kg ayam (me campur)
1. Ambil  Bumbu ayam untuk goreng / marinasi diulek
1. Sediakan  Lada putih utuh
1. Ambil  Bawang putih
1. Gunakan  Kunyit
1. Siapkan  Garam, royco, sasa
1. Siapkan  Minyak untuk menggoreng
1. Ambil  Bumbu Opor yang digoreng dan diulek
1. Gunakan 1 sdm lada putih utuh (butiran)
1. Gunakan 2 sdm ketumbar utuh (butiran)
1. Gunakan 2 iris pala utuh
1. Sediakan 4 ruas kunyit
1. Siapkan 1 buah cabe merah
1. Siapkan 6-7 siung bawang putih
1. Siapkan 8-9 siung bawang merah
1. Siapkan 15 buah kemiri
1. Sediakan  Tambahan untuk diulek yang mentah
1. Sediakan 6 siung bawang putih sedang
1. Ambil 4 siung bawang merah besar
1. Sediakan  3 - 5 siung Bawang merah iris
1. Gunakan  Bahan A
1. Sediakan 3 ikat sereh geprek
1. Sediakan 7 ruas lengkuas geprek
1. Sediakan 3 ruas jahe geprek
1. Ambil 5 lembar daun salam
1. Siapkan  Bahan B
1. Siapkan 3 tangkai daun bawang iris
1. Sediakan 2 buah tomat iris
1. Sediakan  Bahan C
1. Siapkan 1-2 sdm gula merah
1. Siapkan 1 sdm garam
1. Sediakan 1 sdm Royco
1. Ambil 1/2 sdm penyedap rasa (sasa)
1. Ambil  Bahan D perlahan
1. Gunakan  Sekitar 10 liter air bisa disesuaikan sesuai taste
1. Gunakan 3 buah batok kelapa tua (buat santan encer dan kental)




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Opor ayam ibu:

1. Goreng ayam jangan terlalu kering dengan marinasi lada putih, bawang putih, kunyit, garam, royco dan sasa secukupnya, sisihkan
1. Untuk bumbu ulek, goreng kunyit terlebih dahulu bila sudah sedikit layu, masukkan kemiri sampai agak matang, lalu masukkan bawang putih - bawang merah sampai layu dan masukkan cabe merah. Masak hingga matang / wangi dan layu. Angkat, tiriskan dan sisihkan.
1. Goreng lada putih utuh, ketumbar dan pala hingga matang. Angkat, tiriskan dan sisihkan.
1. Haluskan bumbu opor yg digoreng dan yg mentah
1. 
1. 
1. 
1. Panaskan minyak, tumis bawang merah yg sudah diiris hingga layu
1. Lalu masukkan bumbu ulek dan Bahan A, aduk aduk hingga harum.
1. 
1. Lanjut masukkan Bahan B dan Bahan C, aduk merata, bila sudah matang masukkan ayam yg sudah digoreng, beri sedikit air dan aduk rata
1. Bila sudah rata masukkan air secara perlahan sambil diaduk hingga mendidih.
1. Masukkan santan encer, perlahan lalu masukkan santan kental dan aduk aduk agak tidak pecah. Masak hingga matang.
1. Dan siap disajikan lebih enak dengan ketupat, bawang goreng, kecap, sambel goreng kentang juga kerupuk udang.
1. Selamat mencoba.




Ternyata resep opor ayam ibu yang mantab simple ini mudah sekali ya! Kamu semua dapat mencobanya. Cara buat opor ayam ibu Sangat sesuai sekali untuk kita yang baru belajar memasak atau juga untuk anda yang sudah hebat memasak.

Apakah kamu mau mulai mencoba bikin resep opor ayam ibu nikmat simple ini? Kalau anda ingin, yuk kita segera siapin alat dan bahan-bahannya, maka bikin deh Resep opor ayam ibu yang mantab dan tidak rumit ini. Sungguh gampang kan. 

Jadi, daripada anda berfikir lama-lama, yuk kita langsung bikin resep opor ayam ibu ini. Dijamin anda tiidak akan nyesel sudah membuat resep opor ayam ibu lezat sederhana ini! Selamat mencoba dengan resep opor ayam ibu mantab sederhana ini di tempat tinggal sendiri,oke!.

