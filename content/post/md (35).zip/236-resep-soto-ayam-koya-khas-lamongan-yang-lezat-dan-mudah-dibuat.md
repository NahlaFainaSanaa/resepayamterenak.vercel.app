---
description: "Resep Soto Ayam Koya Khas Lamongan yang lezat dan Mudah Dibuat"
title: "Resep Soto Ayam Koya Khas Lamongan yang lezat dan Mudah Dibuat"
slug: 236-resep-soto-ayam-koya-khas-lamongan-yang-lezat-dan-mudah-dibuat
date: 2021-04-15T11:48:26.310Z
image: https://img-global.cpcdn.com/recipes/1f99293e81c40581/680x482cq70/soto-ayam-koya-khas-lamongan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1f99293e81c40581/680x482cq70/soto-ayam-koya-khas-lamongan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1f99293e81c40581/680x482cq70/soto-ayam-koya-khas-lamongan-foto-resep-utama.jpg
author: Rachel Pearson
ratingvalue: 3
reviewcount: 6
recipeingredient:
- " Bahan Koya"
- "7-8 keping kerupuk udang goreng"
- "1 siung bawang putih iris tipis dan goreng"
- " Topping Soto"
- "2 sdm bawang goreng"
- "Secukupnya kol cuci dan iris tipis"
- "2 butir telur ayam rebus"
- "Secukupnya ayam goreng suwir saya pakai 2 potong paha atas"
- "1 butir jeruk nipis peras"
- " Bahan Pelengkap Kuah Soto"
- "2 batang daun bawang iris"
- "2 batang daun seledri iris"
- "1 sachet kaldu ayam bubuk"
- "Secukupnya gula dan garam"
- "Secukupnya penyedap rasamicin"
- "1,2-1,5 liter air"
- " Bahan Bumbu Tumis"
- "6 butir bawang merah haluskan"
- "3 siung bawang putih haluskan"
- "2 butir kemiri haluskan"
- "1 sdt ketumbar bubuk"
- "1/2 sdt lada bubuk"
- "1 sdt kunyit bubuk"
- "1 cm jahe haluskan"
- "1 batang sereh geprek"
- "2 lembar daun salam sobek"
- "2 lembar daun jeruk sobek"
- " Bahan Sambal Kemiri"
- "1 siung bawang putih"
- "6 buah cabe rawit setan  sesuai selera"
- "1 butir kemiri"
- "Secukupnya gula dan garam"
recipeinstructions:
- "Cara Membuat Koya: Tumbuk halus kerupuk udang dan irisan bawang putih yang telah digoreng. Jangan overcook karena rasanya bisa pahit. Sisihkan."
- "Cara Membuat Kuah Soto: Panaskan sedikit minyak dengan api sedang. Tumis semua bahan bumbu hingga matang dan harum. Matikan api."
- "Didihkan air. Masukkan daun bawang, seledri, dan bumbu tumis. Lalu tambahkan kaldu ayam bubuk, gula, garam, penyedap rasa/micin. Aduk rata dan tes rasa. Matikan api."
- "Cara Membuat Sambal Kemiri: Didihkan sedikit air. Rebus semua bahan sambal kemiri hingga matang. Siapkan cobek. Haluskan sambal kemiri yang telah direbus. Tambahkan garam, gula, dan sedikit air panas. Sisihkan."
- "Cara Penyajian: Siapkan mangkok. Tata nasi, siram dengan kuah soto. Beri topping ayam goreng suwir, kol, bawang goreng, telur, jeruk nipis, dan jangan lupa taburi koya di atasnya agar kuah lebih gurih dan kental. Siap santap ❤"
categories:
- Resep
tags:
- soto
- ayam
- koya

katakunci: soto ayam koya 
nutrition: 181 calories
recipecuisine: Indonesian
preptime: "PT17M"
cooktime: "PT49M"
recipeyield: "2"
recipecategory: Dinner

---


![Soto Ayam Koya Khas Lamongan](https://img-global.cpcdn.com/recipes/1f99293e81c40581/680x482cq70/soto-ayam-koya-khas-lamongan-foto-resep-utama.jpg)

Selaku seorang istri, menyediakan masakan mantab buat orang tercinta adalah hal yang memuaskan bagi kita sendiri. Tugas seorang istri bukan sekedar mengerjakan pekerjaan rumah saja, tetapi kamu juga wajib memastikan kebutuhan nutrisi tercukupi dan juga panganan yang disantap anak-anak wajib lezat.

Di masa  sekarang, kita sebenarnya bisa membeli hidangan praktis walaupun tanpa harus capek memasaknya lebih dulu. Tapi banyak juga orang yang memang mau memberikan makanan yang terenak bagi keluarganya. Karena, memasak sendiri jauh lebih higienis dan bisa menyesuaikan sesuai dengan makanan kesukaan keluarga. 



Apakah anda seorang penikmat soto ayam koya khas lamongan?. Tahukah kamu, soto ayam koya khas lamongan adalah hidangan khas di Indonesia yang sekarang disukai oleh banyak orang dari hampir setiap daerah di Indonesia. Kalian bisa memasak soto ayam koya khas lamongan olahan sendiri di rumah dan boleh jadi makanan favorit di hari libur.

Anda tak perlu bingung jika kamu ingin mendapatkan soto ayam koya khas lamongan, sebab soto ayam koya khas lamongan tidak sulit untuk didapatkan dan juga kalian pun bisa memasaknya sendiri di rumah. soto ayam koya khas lamongan bisa dibuat memalui bermacam cara. Saat ini telah banyak banget resep kekinian yang menjadikan soto ayam koya khas lamongan lebih enak.

Resep soto ayam koya khas lamongan juga sangat gampang dibikin, lho. Kamu tidak usah ribet-ribet untuk membeli soto ayam koya khas lamongan, lantaran Anda mampu membuatnya di rumah sendiri. Bagi Kalian yang hendak menyajikannya, inilah resep untuk membuat soto ayam koya khas lamongan yang mantab yang mampu Kalian hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Soto Ayam Koya Khas Lamongan:

1. Siapkan  Bahan Koya
1. Ambil 7-8 keping kerupuk udang (goreng)
1. Gunakan 1 siung bawang putih (iris tipis dan goreng)
1. Ambil  Topping Soto
1. Gunakan 2 sdm bawang goreng
1. Ambil Secukupnya kol (cuci dan iris tipis)
1. Sediakan 2 butir telur ayam rebus
1. Ambil Secukupnya ayam goreng suwir (saya pakai 2 potong paha atas)
1. Sediakan 1 butir jeruk nipis (peras)
1. Ambil  Bahan Pelengkap Kuah Soto
1. Siapkan 2 batang daun bawang (iris)
1. Sediakan 2 batang daun seledri (iris)
1. Gunakan 1 sachet kaldu ayam bubuk
1. Ambil Secukupnya gula dan garam
1. Sediakan Secukupnya penyedap rasa/micin
1. Ambil 1,2-1,5 liter air
1. Siapkan  Bahan Bumbu Tumis
1. Siapkan 6 butir bawang merah (haluskan)
1. Siapkan 3 siung bawang putih (haluskan)
1. Gunakan 2 butir kemiri (haluskan)
1. Siapkan 1 sdt ketumbar bubuk
1. Ambil 1/2 sdt lada bubuk
1. Gunakan 1 sdt kunyit bubuk
1. Siapkan 1 cm jahe (haluskan)
1. Ambil 1 batang sereh (geprek)
1. Sediakan 2 lembar daun salam (sobek)
1. Gunakan 2 lembar daun jeruk (sobek)
1. Ambil  Bahan Sambal Kemiri
1. Siapkan 1 siung bawang putih
1. Ambil 6 buah cabe rawit setan / sesuai selera
1. Ambil 1 butir kemiri
1. Sediakan Secukupnya gula dan garam




<!--inarticleads2-->

##### Langkah-langkah membuat Soto Ayam Koya Khas Lamongan:

1. Cara Membuat Koya: - Tumbuk halus kerupuk udang dan irisan bawang putih yang telah digoreng. Jangan overcook karena rasanya bisa pahit. Sisihkan.
1. Cara Membuat Kuah Soto: - Panaskan sedikit minyak dengan api sedang. Tumis semua bahan bumbu hingga matang dan harum. Matikan api.
1. Didihkan air. Masukkan daun bawang, seledri, dan bumbu tumis. Lalu tambahkan kaldu ayam bubuk, gula, garam, penyedap rasa/micin. Aduk rata dan tes rasa. Matikan api.
1. Cara Membuat Sambal Kemiri: - Didihkan sedikit air. Rebus semua bahan sambal kemiri hingga matang. Siapkan cobek. Haluskan sambal kemiri yang telah direbus. Tambahkan garam, gula, dan sedikit air panas. Sisihkan.
1. Cara Penyajian: - Siapkan mangkok. Tata nasi, siram dengan kuah soto. Beri topping ayam goreng suwir, kol, bawang goreng, telur, jeruk nipis, dan jangan lupa taburi koya di atasnya agar kuah lebih gurih dan kental. Siap santap ❤




Ternyata resep soto ayam koya khas lamongan yang enak tidak ribet ini mudah sekali ya! Anda Semua dapat mencobanya. Cara Membuat soto ayam koya khas lamongan Sangat cocok sekali buat kita yang baru belajar memasak atau juga untuk anda yang telah pandai dalam memasak.

Apakah kamu mau mulai mencoba membuat resep soto ayam koya khas lamongan mantab tidak rumit ini? Kalau anda tertarik, ayo kalian segera siapin alat dan bahannya, lalu buat deh Resep soto ayam koya khas lamongan yang mantab dan tidak ribet ini. Sangat mudah kan. 

Oleh karena itu, daripada kalian berlama-lama, hayo langsung aja hidangkan resep soto ayam koya khas lamongan ini. Pasti anda tak akan menyesal sudah buat resep soto ayam koya khas lamongan nikmat tidak rumit ini! Selamat berkreasi dengan resep soto ayam koya khas lamongan nikmat simple ini di tempat tinggal masing-masing,ya!.

