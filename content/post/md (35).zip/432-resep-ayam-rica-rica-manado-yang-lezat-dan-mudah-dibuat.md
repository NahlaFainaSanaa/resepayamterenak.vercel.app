---
description: "Resep Ayam Rica Rica Manado yang lezat dan Mudah Dibuat"
title: "Resep Ayam Rica Rica Manado yang lezat dan Mudah Dibuat"
slug: 432-resep-ayam-rica-rica-manado-yang-lezat-dan-mudah-dibuat
date: 2021-03-20T21:21:56.709Z
image: https://img-global.cpcdn.com/recipes/ee55b01017b3a2f8/680x482cq70/ayam-rica-rica-manado-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ee55b01017b3a2f8/680x482cq70/ayam-rica-rica-manado-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ee55b01017b3a2f8/680x482cq70/ayam-rica-rica-manado-foto-resep-utama.jpg
author: Raymond Briggs
ratingvalue: 3.4
reviewcount: 5
recipeingredient:
- "1 Ekor Ayam Potong Menjadi Bagian KecilKecil"
- " Jahe"
- " Lengkuas"
- " Kemiri"
- "sesuai selera Cabe rawit"
- "sesuai selera Cabe Merah"
- "4 lembar Daun salam"
- "2 Batang Serai"
- " Daun kemangi"
- "6 Siung Bawang Merah"
- "2 Siung Bawang putih"
- " Daun jeruk 3 lembar iris"
recipeinstructions:
- "Potong Ayam menjadi beberapa Bagian, dan goreng sebentar saja"
- "Blender bumbu halus (Cabe merah, cabe rawit, jahe, lengkuas, bawang merah, bawang putih, kemiri)"
- "Tumis bumbu yang sudah dihaluskan sampai harum, setelah nya masukan serai yang sudah digeprek, daun Salam dan daun jeruk yang sudah diris iris"
- "Masukan ayam yang sudah digoreng tadi, aduk hingga rata sampai tercampur dengan bumbu nya"
- "Tambahkan sedikir air, beri penyedap/kaldu bubuk, gula, garam. Aduk hingga rata (tes rasa). Biarkan airnya sampai sedikit menyusut"
- "Terakhir, tambahkan daun kemangi lalu aduk kembali. Angkat dan sajikan"
categories:
- Resep
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 216 calories
recipecuisine: Indonesian
preptime: "PT11M"
cooktime: "PT52M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Rica Rica Manado](https://img-global.cpcdn.com/recipes/ee55b01017b3a2f8/680x482cq70/ayam-rica-rica-manado-foto-resep-utama.jpg)

Selaku seorang istri, menyediakan masakan enak kepada keluarga tercinta adalah suatu hal yang membahagiakan bagi anda sendiri. Kewajiban seorang ibu Tidak cuman mengurus rumah saja, tetapi kamu pun harus menyediakan keperluan nutrisi terpenuhi dan juga panganan yang disantap keluarga tercinta mesti mantab.

Di masa  saat ini, anda sebenarnya dapat mengorder masakan yang sudah jadi walaupun tanpa harus repot membuatnya lebih dulu. Namun ada juga orang yang selalu mau memberikan makanan yang terenak untuk keluarganya. Karena, memasak yang diolah sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan makanan tersebut berdasarkan masakan kesukaan keluarga tercinta. 



Mungkinkah anda merupakan salah satu penyuka ayam rica rica manado?. Asal kamu tahu, ayam rica rica manado merupakan sajian khas di Nusantara yang sekarang disenangi oleh kebanyakan orang dari berbagai daerah di Nusantara. Kalian bisa menghidangkan ayam rica rica manado buatan sendiri di rumah dan boleh jadi camilan kesukaanmu di akhir pekanmu.

Kamu tidak perlu bingung jika kamu ingin mendapatkan ayam rica rica manado, sebab ayam rica rica manado sangat mudah untuk didapatkan dan juga anda pun dapat membuatnya sendiri di rumah. ayam rica rica manado dapat dimasak lewat bermacam cara. Sekarang telah banyak cara kekinian yang menjadikan ayam rica rica manado lebih enak.

Resep ayam rica rica manado juga gampang sekali untuk dibuat, lho. Kamu tidak usah ribet-ribet untuk memesan ayam rica rica manado, sebab Kamu bisa membuatnya ditempatmu. Bagi Anda yang mau menyajikannya, berikut ini cara membuat ayam rica rica manado yang enak yang bisa Kalian coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Ayam Rica Rica Manado:

1. Ambil 1 Ekor Ayam (Potong Menjadi Bagian Kecil-Kecil)
1. Ambil  Jahe
1. Ambil  Lengkuas
1. Siapkan  Kemiri
1. Ambil sesuai selera Cabe rawit
1. Sediakan sesuai selera Cabe Merah
1. Sediakan 4 lembar Daun salam
1. Gunakan 2 Batang Serai
1. Siapkan  Daun kemangi
1. Sediakan 6 Siung Bawang Merah
1. Ambil 2 Siung Bawang putih
1. Gunakan  Daun jeruk 3 lembar (iris)




<!--inarticleads2-->

##### Cara membuat Ayam Rica Rica Manado:

1. Potong Ayam menjadi beberapa Bagian, dan goreng sebentar saja
1. Blender bumbu halus (Cabe merah, cabe rawit, jahe, lengkuas, bawang merah, bawang putih, kemiri)
1. Tumis bumbu yang sudah dihaluskan sampai harum, setelah nya masukan serai yang sudah digeprek, daun Salam dan daun jeruk yang sudah diris iris
1. Masukan ayam yang sudah digoreng tadi, aduk hingga rata sampai tercampur dengan bumbu nya
1. Tambahkan sedikir air, beri penyedap/kaldu bubuk, gula, garam. Aduk hingga rata (tes rasa). Biarkan airnya sampai sedikit menyusut
1. Terakhir, tambahkan daun kemangi lalu aduk kembali. Angkat dan sajikan




Ternyata resep ayam rica rica manado yang mantab tidak ribet ini mudah sekali ya! Semua orang dapat membuatnya. Cara Membuat ayam rica rica manado Cocok sekali buat kita yang baru belajar memasak maupun juga untuk kalian yang sudah pandai dalam memasak.

Tertarik untuk mencoba membikin resep ayam rica rica manado nikmat sederhana ini? Kalau kamu tertarik, ayo kalian segera buruan menyiapkan alat dan bahannya, lantas buat deh Resep ayam rica rica manado yang enak dan tidak ribet ini. Sangat taidak sulit kan. 

Maka, ketimbang anda berlama-lama, hayo kita langsung saja hidangkan resep ayam rica rica manado ini. Dijamin kamu tak akan nyesel bikin resep ayam rica rica manado mantab simple ini! Selamat mencoba dengan resep ayam rica rica manado enak tidak rumit ini di rumah sendiri,oke!.

