---
description: "Cara membuat Ayam goreng kremes sambal bawang ala bu Rudi Sederhana dan Mudah Dibuat"
title: "Cara membuat Ayam goreng kremes sambal bawang ala bu Rudi Sederhana dan Mudah Dibuat"
slug: 492-cara-membuat-ayam-goreng-kremes-sambal-bawang-ala-bu-rudi-sederhana-dan-mudah-dibuat
date: 2021-04-29T13:07:35.649Z
image: https://img-global.cpcdn.com/recipes/d18b3ce439df5075/680x482cq70/ayam-goreng-kremes-sambal-bawang-ala-bu-rudi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d18b3ce439df5075/680x482cq70/ayam-goreng-kremes-sambal-bawang-ala-bu-rudi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d18b3ce439df5075/680x482cq70/ayam-goreng-kremes-sambal-bawang-ala-bu-rudi-foto-resep-utama.jpg
author: Phoebe Conner
ratingvalue: 4.9
reviewcount: 3
recipeingredient:
- " Bahan ayam goreng "
- "4 pt daging ayam  tahutempe"
- " Minyak untuk menggoreng"
- "200 ml air"
- " Bumbu ungkep ayam "
- "2 siung bawang merah"
- "4 siung bawang putih"
- "secukupnya Ketumbar"
- "1 jari kunyit"
- "2 buah kemiri"
- "1 sdt Garam"
- "1/4 sdt gula pasir"
- " Penyedap rasa"
- " Serai daun salam dan lengkuas"
- " Bahan kremesan "
- "4 sdm tepung tapioka"
- "1 sdm tepung ketanberas"
- "1 butir telur ayam ukuran kecil"
- "1/2 sdt baking powder"
- "1/2 sdt baking soda"
- " Penyedap"
- "1/4 gelas air"
- " Bumbu sisa ungkepan ayam"
- " Bahan sambel bawang ala bu Rudi "
- "5 siung bawang merah cincang halus"
- "1/2 ons cabe rawit campur rawit merah  ijo"
- "2 siung bawang putih"
- " Garam gula pasir penyedap rasa"
- "secukupnya Minyak"
recipeinstructions:
- "Bersihkan ayam, haluskan bumbu ungkepan, lumuri ayam+tahu/tempe dengan bumbu, tambahkan garam, gula pasir, penyedap, lengkuas, daun salam, dan air. Rebus hingga air surut."
- "Setelah ayam selesai diungkep pisahkan bumbu untuk membuat kremesan. Campur semua bahan aduk rata lalu saring. (bahan kremesan dicampur sesaat sebelum mau digoreng agar kriuk)"
- "Panas kan minyak hingga benar2 panas, lalu goreng adonan kremesan hingga habis. Tiriskan dengan dilapis tissu agar minyak terserap."
- "Lanjut goreng ayam hingga matang tiriskan."
- "Untuk sambel uleg cabai dan bawang putih. Panaskan minyak tumis cincangan bawang merah lalu disusul uleg an cabai dan bawang putih. Tambahkan garam, gula pasir dan penyedap rasa. Masak hingga bawang merah berwarna bening."
- "Setelah matang masukkan kedalam toples kaca tutup dan dinginkan lalu simpan dikulkas bisa tahan 1 minggu."
- "Setelah semua matang ayam goreng, kremesan dan sambal siap dihidangkan."
- "Selamat mencoba dan menikmati."
categories:
- Resep
tags:
- ayam
- goreng
- kremes

katakunci: ayam goreng kremes 
nutrition: 249 calories
recipecuisine: Indonesian
preptime: "PT16M"
cooktime: "PT31M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam goreng kremes sambal bawang ala bu Rudi](https://img-global.cpcdn.com/recipes/d18b3ce439df5075/680x482cq70/ayam-goreng-kremes-sambal-bawang-ala-bu-rudi-foto-resep-utama.jpg)

Sebagai seorang wanita, menyajikan santapan lezat buat orang tercinta merupakan hal yang sangat menyenangkan untuk anda sendiri. Kewajiban seorang  wanita bukan cuma mengurus rumah saja, tetapi kamu pun harus memastikan keperluan nutrisi terpenuhi dan olahan yang disantap orang tercinta wajib enak.

Di masa  sekarang, kalian memang dapat memesan olahan praktis tanpa harus ribet memasaknya dahulu. Tetapi banyak juga lho mereka yang memang mau memberikan makanan yang terbaik untuk orang yang dicintainya. Lantaran, menyajikan masakan yang dibuat sendiri jauh lebih bersih dan bisa menyesuaikan masakan tersebut berdasarkan kesukaan keluarga tercinta. 

Resep sambel bu rudy rasanya mirip banget Ayam geprek krispy sambel bawang. • cara membuat sambal bawang yang mantap ala enny tangerang!!! Lihat juga resep Sambal Ayam Kremes enak lainnya.

Apakah anda seorang penggemar ayam goreng kremes sambal bawang ala bu rudi?. Asal kamu tahu, ayam goreng kremes sambal bawang ala bu rudi merupakan makanan khas di Indonesia yang sekarang disukai oleh kebanyakan orang dari hampir setiap tempat di Nusantara. Kita dapat membuat ayam goreng kremes sambal bawang ala bu rudi sendiri di rumahmu dan boleh jadi santapan kesenanganmu di akhir pekanmu.

Kalian tak perlu bingung untuk mendapatkan ayam goreng kremes sambal bawang ala bu rudi, lantaran ayam goreng kremes sambal bawang ala bu rudi tidak sukar untuk dicari dan juga kita pun bisa menghidangkannya sendiri di tempatmu. ayam goreng kremes sambal bawang ala bu rudi bisa dibuat dengan beragam cara. Saat ini sudah banyak banget cara modern yang membuat ayam goreng kremes sambal bawang ala bu rudi semakin mantap.

Resep ayam goreng kremes sambal bawang ala bu rudi juga gampang untuk dibikin, lho. Anda tidak perlu repot-repot untuk membeli ayam goreng kremes sambal bawang ala bu rudi, sebab Kalian dapat menghidangkan ditempatmu. Bagi Kita yang mau menyajikannya, di bawah ini adalah resep membuat ayam goreng kremes sambal bawang ala bu rudi yang mantab yang dapat Kalian coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Ayam goreng kremes sambal bawang ala bu Rudi:

1. Ambil  Bahan ayam goreng :
1. Sediakan 4 pt daging ayam + tahu/tempe
1. Ambil  Minyak untuk menggoreng
1. Ambil 200 ml air
1. Siapkan  Bumbu ungkep ayam :
1. Ambil 2 siung bawang merah
1. Ambil 4 siung bawang putih
1. Ambil secukupnya Ketumbar
1. Sediakan 1 jari kunyit
1. Gunakan 2 buah kemiri
1. Sediakan 1 sdt Garam
1. Siapkan 1/4 sdt gula pasir
1. Ambil  Penyedap rasa
1. Ambil  Serai, daun salam dan lengkuas
1. Siapkan  Bahan kremesan :
1. Siapkan 4 sdm tepung tapioka
1. Siapkan 1 sdm tepung ketan/beras
1. Gunakan 1 butir telur ayam ukuran kecil
1. Sediakan 1/2 sdt baking powder
1. Sediakan 1/2 sdt baking soda
1. Ambil  Penyedap
1. Ambil 1/4 gelas air
1. Ambil  Bumbu sisa ungkepan ayam
1. Ambil  Bahan sambel bawang ala bu Rudi :
1. Siapkan 5 siung bawang merah (cincang halus)
1. Gunakan 1/2 ons cabe rawit campur rawit merah + ijo
1. Sediakan 2 siung bawang putih
1. Siapkan  Garam, gula pasir, penyedap rasa
1. Gunakan secukupnya Minyak


Enak dipadu bersama dengan nasi hangat, kremesan dan juga sambal. Ayam yang digunakan bisa dipilih ayam. Ayam Goreng Kremes, ibarat ayam KFC a la Indonesia. Jika anda sudah pernah menyantap Ayam Goreng Mbok Berek atau Ayam Goreng Nyonya Catatan: Membuat ayam goreng berbalut kremes tidak susah asal takaran adonan benar dan tahu teknik yang tepat. 

<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam goreng kremes sambal bawang ala bu Rudi:

1. Bersihkan ayam, haluskan bumbu ungkepan, lumuri ayam+tahu/tempe dengan bumbu, tambahkan garam, gula pasir, penyedap, lengkuas, daun salam, dan air. Rebus hingga air surut.
1. Setelah ayam selesai diungkep pisahkan bumbu untuk membuat kremesan. Campur semua bahan aduk rata lalu saring. (bahan kremesan dicampur sesaat sebelum mau digoreng agar kriuk)
1. Panas kan minyak hingga benar2 panas, lalu goreng adonan kremesan hingga habis. Tiriskan dengan dilapis tissu agar minyak terserap.
1. Lanjut goreng ayam hingga matang tiriskan.
1. Untuk sambel uleg cabai dan bawang putih. Panaskan minyak tumis cincangan bawang merah lalu disusul uleg an cabai dan bawang putih. Tambahkan garam, gula pasir dan penyedap rasa. Masak hingga bawang merah berwarna bening.
1. Setelah matang masukkan kedalam toples kaca tutup dan dinginkan lalu simpan dikulkas bisa tahan 1 minggu.
1. Setelah semua matang ayam goreng, kremesan dan sambal siap dihidangkan.
1. Selamat mencoba dan menikmati.


Ayam geprek krispy sambal bawang perpaduan dari ayam krispy ala KFC dan sambal bawang membuat sensasi yang unik. Tepung yang krispy garing diluar ayam yang gurih dan sambel yang pedas, cocok untuk pecinta kuliner selera pedas, bakalan kepingin nambah terus. Places Sragen, Jawa Tengah, Indonesia RestaurantAsian restaurantIndonesian restaurant Ayam Goreng Kremes Mbak Eny. Sambal bawang pedas a la bu rudy. Masukkan bawang merah dan cabe rawit. 

Ternyata cara buat ayam goreng kremes sambal bawang ala bu rudi yang enak sederhana ini enteng sekali ya! Kalian semua dapat mencobanya. Resep ayam goreng kremes sambal bawang ala bu rudi Cocok banget untuk kamu yang sedang belajar memasak maupun untuk anda yang telah jago memasak.

Tertarik untuk mulai mencoba bikin resep ayam goreng kremes sambal bawang ala bu rudi enak sederhana ini? Kalau kalian mau, ayo kalian segera siapkan peralatan dan bahan-bahannya, setelah itu bikin deh Resep ayam goreng kremes sambal bawang ala bu rudi yang mantab dan tidak ribet ini. Benar-benar mudah kan. 

Maka dari itu, daripada kita berlama-lama, yuk kita langsung saja sajikan resep ayam goreng kremes sambal bawang ala bu rudi ini. Dijamin kalian tak akan menyesal membuat resep ayam goreng kremes sambal bawang ala bu rudi enak sederhana ini! Selamat berkreasi dengan resep ayam goreng kremes sambal bawang ala bu rudi mantab tidak rumit ini di tempat tinggal masing-masing,oke!.

