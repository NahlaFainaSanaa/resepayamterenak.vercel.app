---
description: "Resep Ayam Tangkap Khas Aceh yang nikmat dan Mudah Dibuat"
title: "Resep Ayam Tangkap Khas Aceh yang nikmat dan Mudah Dibuat"
slug: 162-resep-ayam-tangkap-khas-aceh-yang-nikmat-dan-mudah-dibuat
date: 2021-05-22T14:50:06.596Z
image: https://img-global.cpcdn.com/recipes/7915a5783234d5af/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7915a5783234d5af/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7915a5783234d5af/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg
author: Charles Yates
ratingvalue: 4.5
reviewcount: 8
recipeingredient:
- "1/4 ekor ayam saya pakai bagian paha"
- "Secukupnya minyak goreng"
- " Bahan Ungkep Ayam "
- "400 ml air kelapa"
- "1/2 sdt ketumbar bubuk"
- "1/2 sdt kunyit bubuk"
- "1/4 sdt lada bubuk"
- "1/2 sdt kaldu ayam bubuk"
- "1 sdt garam"
- "1/2 sdt gula pasir"
- "2 siung bawang putih haluskan"
- "2 butir bawang merah haluskan"
- "1 cm jahe haluskan"
- " Bumbu Iris "
- "5 butir bawang merah"
- "2 siung bawang putih"
- "5 buah cabe rawit"
- "4 buah cabe ijo keriting"
- "2 lembar daun pandan"
- "5 lembar daun salam koja  salam biasa tambahan saya"
recipeinstructions:
- "Siapkan semua bahan. Cuci ayam, lumuri jeruk nipis, diamkan sebentar lalu bilas. Siapkan bumbu iris juga."
- "Ungkep ayam : siapkan panci/wajan, masukkan ayam, tuang air kelapa. Tambahkan semua bumbu bubuk, garam, gula, aduk rata. Masak sampai mendidih. Jika sudah mendidih, masukkan bumbu ungkep halus, aduk rata. Masak sampai air menyusut, gunakan api sedang."
- "Jika air sudah susut (tidak sampai habis ya airnya) angkat ayamnya. Siapkan wajan/panci untuk menggoreng, panaskan minyak. Goreng ayam dengan api kecil sampai berwarna keemasan. Di tengah-tengah menggoreng, masukkan air ungkep ayam tadi 2-3x."
- "Saya tiriskan dulu ayam, kurangi sedikit minyaknya. Tumis bawang merah dan bawang putih iris hingga harum, masukkan ayam yang telah digoreng. Masukkan semua bumbu iris, aduk-aduk merata, masak sampai bumbu layu dan wanginya keluar. Matikan kompor, angkat."
- "Sajikan 💜"
categories:
- Resep
tags:
- ayam
- tangkap
- khas

katakunci: ayam tangkap khas 
nutrition: 158 calories
recipecuisine: Indonesian
preptime: "PT12M"
cooktime: "PT37M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Tangkap Khas Aceh](https://img-global.cpcdn.com/recipes/7915a5783234d5af/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg)

Selaku seorang ibu, menyediakan olahan nikmat buat orang tercinta adalah hal yang membahagiakan bagi kita sendiri. Tugas seorang istri bukan hanya menjaga rumah saja, namun anda pun harus menyediakan keperluan gizi tercukupi dan santapan yang dimakan anak-anak harus menggugah selera.

Di waktu  saat ini, kamu memang mampu membeli santapan instan walaupun tidak harus capek membuatnya dulu. Tetapi ada juga mereka yang selalu ingin memberikan makanan yang terbaik bagi keluarganya. Pasalnya, memasak yang diolah sendiri jauh lebih bersih dan kita juga bisa menyesuaikan masakan tersebut sesuai makanan kesukaan orang tercinta. 



Mungkinkah anda seorang penyuka ayam tangkap khas aceh?. Asal kamu tahu, ayam tangkap khas aceh merupakan hidangan khas di Nusantara yang saat ini disukai oleh banyak orang di hampir setiap wilayah di Nusantara. Anda dapat menyajikan ayam tangkap khas aceh sendiri di rumahmu dan dapat dijadikan camilan favorit di hari libur.

Kita jangan bingung jika kamu ingin mendapatkan ayam tangkap khas aceh, sebab ayam tangkap khas aceh tidak sulit untuk dicari dan anda pun dapat membuatnya sendiri di tempatmu. ayam tangkap khas aceh bisa diolah lewat bermacam cara. Kini ada banyak cara modern yang membuat ayam tangkap khas aceh semakin enak.

Resep ayam tangkap khas aceh juga gampang dihidangkan, lho. Kamu jangan capek-capek untuk memesan ayam tangkap khas aceh, sebab Kita dapat membuatnya sendiri di rumah. Untuk Anda yang hendak menghidangkannya, berikut ini resep untuk menyajikan ayam tangkap khas aceh yang mantab yang bisa Anda coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Ayam Tangkap Khas Aceh:

1. Ambil 1/4 ekor ayam (saya pakai bagian paha)
1. Siapkan Secukupnya minyak goreng
1. Sediakan  Bahan Ungkep Ayam :
1. Sediakan 400 ml air kelapa
1. Ambil 1/2 sdt ketumbar bubuk
1. Ambil 1/2 sdt kunyit bubuk
1. Ambil 1/4 sdt lada bubuk
1. Gunakan 1/2 sdt kaldu ayam bubuk
1. Siapkan 1 sdt garam
1. Siapkan 1/2 sdt gula pasir
1. Ambil 2 siung bawang putih haluskan
1. Siapkan 2 butir bawang merah haluskan
1. Sediakan 1 cm jahe haluskan
1. Ambil  Bumbu Iris :
1. Siapkan 5 butir bawang merah
1. Sediakan 2 siung bawang putih
1. Sediakan 5 buah cabe rawit
1. Sediakan 4 buah cabe ijo keriting
1. Siapkan 2 lembar daun pandan
1. Gunakan 5 lembar daun salam koja / salam biasa (tambahan saya)




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam Tangkap Khas Aceh:

1. Siapkan semua bahan. Cuci ayam, lumuri jeruk nipis, diamkan sebentar lalu bilas. Siapkan bumbu iris juga.
1. Ungkep ayam : siapkan panci/wajan, masukkan ayam, tuang air kelapa. Tambahkan semua bumbu bubuk, garam, gula, aduk rata. Masak sampai mendidih. Jika sudah mendidih, masukkan bumbu ungkep halus, aduk rata. Masak sampai air menyusut, gunakan api sedang.
1. Jika air sudah susut (tidak sampai habis ya airnya) angkat ayamnya. Siapkan wajan/panci untuk menggoreng, panaskan minyak. Goreng ayam dengan api kecil sampai berwarna keemasan. Di tengah-tengah menggoreng, masukkan air ungkep ayam tadi 2-3x.
1. Saya tiriskan dulu ayam, kurangi sedikit minyaknya. Tumis bawang merah dan bawang putih iris hingga harum, masukkan ayam yang telah digoreng. Masukkan semua bumbu iris, aduk-aduk merata, masak sampai bumbu layu dan wanginya keluar. Matikan kompor, angkat.
1. Sajikan 💜




Ternyata cara membuat ayam tangkap khas aceh yang enak simple ini gampang banget ya! Anda Semua dapat memasaknya. Cara buat ayam tangkap khas aceh Cocok sekali buat kamu yang sedang belajar memasak ataupun juga bagi anda yang sudah jago memasak.

Apakah kamu ingin mencoba membikin resep ayam tangkap khas aceh lezat tidak rumit ini? Kalau anda tertarik, ayo kalian segera siapkan alat dan bahan-bahannya, lalu bikin deh Resep ayam tangkap khas aceh yang mantab dan simple ini. Betul-betul gampang kan. 

Maka, ketimbang anda diam saja, ayo langsung aja bikin resep ayam tangkap khas aceh ini. Pasti kalian tak akan nyesel sudah buat resep ayam tangkap khas aceh mantab sederhana ini! Selamat berkreasi dengan resep ayam tangkap khas aceh lezat tidak rumit ini di tempat tinggal sendiri,oke!.

