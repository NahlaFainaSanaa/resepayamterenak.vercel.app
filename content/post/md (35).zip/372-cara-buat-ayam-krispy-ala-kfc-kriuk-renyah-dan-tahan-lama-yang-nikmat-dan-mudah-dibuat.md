---
description: "Cara buat Ayam krispy ala kfc kriuk renyah dan tahan lama yang nikmat dan Mudah Dibuat"
title: "Cara buat Ayam krispy ala kfc kriuk renyah dan tahan lama yang nikmat dan Mudah Dibuat"
slug: 372-cara-buat-ayam-krispy-ala-kfc-kriuk-renyah-dan-tahan-lama-yang-nikmat-dan-mudah-dibuat
date: 2021-05-20T14:24:31.887Z
image: https://img-global.cpcdn.com/recipes/203764cba15f4399/680x482cq70/ayam-krispy-ala-kfc-kriuk-renyah-dan-tahan-lama-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/203764cba15f4399/680x482cq70/ayam-krispy-ala-kfc-kriuk-renyah-dan-tahan-lama-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/203764cba15f4399/680x482cq70/ayam-krispy-ala-kfc-kriuk-renyah-dan-tahan-lama-foto-resep-utama.jpg
author: James Ferguson
ratingvalue: 3
reviewcount: 6
recipeingredient:
- "1 ekor ayam uk  1kg"
- " Bumbu perendam "
- " Haluskan"
- "5-10 siung bawang putih"
- "2 buah cabe merah"
- "1 bungkus kaldu bubuk rasa ayam"
- "1 sendok teh merica bubuk"
- "1 sendok makan garam"
- "1 sendok makan ketumbar bubuk"
- "1 sendok teh cabai bubuk boleh skip"
- "1/2 sensok makan saus tiram"
- "1 butir telur kocok lepas dimasukan dibagian akhir setelah direndam"
- " Tepung kriuk"
- "400 gr terigu cakra  protein tinggi"
- "100 gr tepung maizena"
- "1 bungkus kaldu bubuk rasa ayam"
- "1 sendok makan bubuk cabai boleh dikurangidi skip"
- "1/2 sdt merica bubuk"
- "Secukupnya garam"
- " Bahan pelapis "
- "100 ml air"
- "3-4 cube es batu"
- "1 sendok teh soda kue"
- "5 sendok makan campuran tepung kriuk"
- " Minyak yang banyak untuk menggoreng dengan deep fried"
recipeinstructions:
- "Campur bumbu yang dihaluskan dengan bumbu perendam lainnya."
- "Siapkan ayam, tusuk-tusuk dengan garpu.. tambahkan campuran bumbu perendam. Remas-remas.. diamkan minimal 1 jam.. (rendam 1 malam didalam kulkas jika mau bumbunya lebih meresap)"
- "Siapkan campuran tepung kriuk.."
- "Siapkan campuran bumbu perendam"
- "Panaskan minyak, yang banyak ya. Supaya nnti ayamnya bisa terendam saat di goreng."
- "Siapkan ayam yang telah direndam. Masukan telur yang dikocok lepas. Aduk merata."
- "Masukan ayam ke dalam tepung kriuk. Remas remas sampai tepung menempel. Ketuk2 ayam kepinggiran baskom agar tepung yang tidak menempel akan jatuh."
- "Masukkan kedalam bumbu pelapis"
- "Masukkan lagi kedalam tepung kriuk. Remas-remas sambil di boleh balik sampai tepungnya menempel.."
- "Ketuk2 lagi dipinggir baskom sampai terbentuk kriwil-kriwilnya.."
- "Segera goreng dalam minyak panas yang banyak dengan api sedang. Ayam harus terendam semua didalam minyak ya. (emak pakai panci magic com kecil yang sudah tidak terpakai 😬😬)"
- "Goreng sampai kulit terlihat kuning kecoklatan. Pencet ayam dengan capit untuk memastikan sudah tidak lembek dan matang)"
- "Angkat dan tiriskan."
categories:
- Resep
tags:
- ayam
- krispy
- ala

katakunci: ayam krispy ala 
nutrition: 236 calories
recipecuisine: Indonesian
preptime: "PT36M"
cooktime: "PT41M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam krispy ala kfc kriuk renyah dan tahan lama](https://img-global.cpcdn.com/recipes/203764cba15f4399/680x482cq70/ayam-krispy-ala-kfc-kriuk-renyah-dan-tahan-lama-foto-resep-utama.jpg)

Jika kalian seorang orang tua, mempersiapkan panganan menggugah selera buat keluarga merupakan suatu hal yang menggembirakan untuk anda sendiri. Peran seorang istri Tidak sekedar menangani rumah saja, namun kamu juga harus menyediakan kebutuhan nutrisi tercukupi dan masakan yang dikonsumsi keluarga tercinta wajib lezat.

Di era  sekarang, kita sebenarnya mampu membeli santapan siap saji walaupun tanpa harus ribet mengolahnya terlebih dahulu. Namun ada juga mereka yang selalu ingin menyajikan yang terenak untuk keluarganya. Pasalnya, menghidangkan masakan yang diolah sendiri jauh lebih bersih dan kita juga bisa menyesuaikan berdasarkan kesukaan famili. 



Apakah anda seorang penggemar ayam krispy ala kfc kriuk renyah dan tahan lama?. Tahukah kamu, ayam krispy ala kfc kriuk renyah dan tahan lama adalah sajian khas di Indonesia yang sekarang disukai oleh banyak orang dari berbagai wilayah di Nusantara. Kalian bisa memasak ayam krispy ala kfc kriuk renyah dan tahan lama sendiri di rumah dan pasti jadi hidangan favoritmu di akhir pekanmu.

Kita tak perlu bingung jika kamu ingin memakan ayam krispy ala kfc kriuk renyah dan tahan lama, lantaran ayam krispy ala kfc kriuk renyah dan tahan lama mudah untuk didapatkan dan kalian pun boleh membuatnya sendiri di rumah. ayam krispy ala kfc kriuk renyah dan tahan lama boleh diolah memalui berbagai cara. Kini pun telah banyak banget cara kekinian yang menjadikan ayam krispy ala kfc kriuk renyah dan tahan lama semakin lezat.

Resep ayam krispy ala kfc kriuk renyah dan tahan lama pun gampang sekali dihidangkan, lho. Kamu tidak usah ribet-ribet untuk membeli ayam krispy ala kfc kriuk renyah dan tahan lama, lantaran Anda mampu menyiapkan di rumah sendiri. Untuk Kalian yang akan mencobanya, dibawah ini merupakan cara untuk menyajikan ayam krispy ala kfc kriuk renyah dan tahan lama yang lezat yang mampu Kalian hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Ayam krispy ala kfc kriuk renyah dan tahan lama:

1. Siapkan 1 ekor ayam uk +/- 1kg
1. Ambil  Bumbu perendam :
1. Gunakan  Haluskan:
1. Siapkan 5-10 siung bawang putih
1. Ambil 2 buah cabe merah
1. Siapkan 1 bungkus kaldu bubuk rasa ayam
1. Ambil 1 sendok teh merica bubuk
1. Ambil 1 sendok makan garam
1. Sediakan 1 sendok makan ketumbar bubuk
1. Siapkan 1 sendok teh cabai bubuk (boleh skip)
1. Sediakan 1/2 sensok makan saus tiram
1. Gunakan 1 butir telur, kocok lepas (dimasukan dibagian akhir setelah direndam)
1. Ambil  Tepung kriuk:
1. Gunakan 400 gr terigu cakra / protein tinggi
1. Siapkan 100 gr tepung maizena
1. Siapkan 1 bungkus kaldu bubuk rasa ayam
1. Siapkan 1 sendok makan bubuk cabai (boleh dikurangi/di skip)
1. Sediakan 1/2 sdt merica bubuk
1. Gunakan Secukupnya garam
1. Siapkan  Bahan pelapis :
1. Gunakan 100 ml air
1. Siapkan 3-4 cube es batu
1. Ambil 1 sendok teh soda kue
1. Ambil 5 sendok makan campuran tepung kriuk
1. Ambil  Minyak yang banyak untuk menggoreng dengan deep fried




<!--inarticleads2-->

##### Cara menyiapkan Ayam krispy ala kfc kriuk renyah dan tahan lama:

1. Campur bumbu yang dihaluskan dengan bumbu perendam lainnya.
1. Siapkan ayam, tusuk-tusuk dengan garpu.. tambahkan campuran bumbu perendam. Remas-remas.. diamkan minimal 1 jam.. (rendam 1 malam didalam kulkas jika mau bumbunya lebih meresap)
1. Siapkan campuran tepung kriuk..
1. Siapkan campuran bumbu perendam
1. Panaskan minyak, yang banyak ya. Supaya nnti ayamnya bisa terendam saat di goreng.
1. Siapkan ayam yang telah direndam. Masukan telur yang dikocok lepas. Aduk merata.
1. Masukan ayam ke dalam tepung kriuk. Remas remas sampai tepung menempel. Ketuk2 ayam kepinggiran baskom agar tepung yang tidak menempel akan jatuh.
1. Masukkan kedalam bumbu pelapis
1. Masukkan lagi kedalam tepung kriuk. Remas-remas sambil di boleh balik sampai tepungnya menempel..
1. Ketuk2 lagi dipinggir baskom sampai terbentuk kriwil-kriwilnya..
1. Segera goreng dalam minyak panas yang banyak dengan api sedang. Ayam harus terendam semua didalam minyak ya. (emak pakai panci magic com kecil yang sudah tidak terpakai 😬😬)
1. Goreng sampai kulit terlihat kuning kecoklatan. Pencet ayam dengan capit untuk memastikan sudah tidak lembek dan matang)
1. Angkat dan tiriskan.




Ternyata resep ayam krispy ala kfc kriuk renyah dan tahan lama yang mantab simple ini mudah banget ya! Semua orang mampu menghidangkannya. Cara buat ayam krispy ala kfc kriuk renyah dan tahan lama Sangat sesuai sekali untuk kamu yang baru akan belajar memasak maupun juga untuk kamu yang telah jago memasak.

Tertarik untuk mencoba membikin resep ayam krispy ala kfc kriuk renyah dan tahan lama nikmat sederhana ini? Kalau kamu tertarik, yuk kita segera buruan menyiapkan peralatan dan bahannya, lantas bikin deh Resep ayam krispy ala kfc kriuk renyah dan tahan lama yang enak dan tidak ribet ini. Sangat gampang kan. 

Maka, daripada kamu berlama-lama, maka kita langsung hidangkan resep ayam krispy ala kfc kriuk renyah dan tahan lama ini. Dijamin kalian gak akan nyesel membuat resep ayam krispy ala kfc kriuk renyah dan tahan lama enak simple ini! Selamat berkreasi dengan resep ayam krispy ala kfc kriuk renyah dan tahan lama enak tidak ribet ini di rumah kalian sendiri,ya!.

