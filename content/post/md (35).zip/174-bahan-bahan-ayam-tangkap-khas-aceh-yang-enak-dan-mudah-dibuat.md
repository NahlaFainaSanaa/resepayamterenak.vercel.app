---
description: "Bahan-bahan Ayam tangkap khas Aceh yang enak dan Mudah Dibuat"
title: "Bahan-bahan Ayam tangkap khas Aceh yang enak dan Mudah Dibuat"
slug: 174-bahan-bahan-ayam-tangkap-khas-aceh-yang-enak-dan-mudah-dibuat
date: 2021-02-18T06:42:08.701Z
image: https://img-global.cpcdn.com/recipes/2b122bcb026a7b5f/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2b122bcb026a7b5f/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2b122bcb026a7b5f/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg
author: Eliza Rodriguez
ratingvalue: 4.4
reviewcount: 8
recipeingredient:
- "1 ekor ayam kampung sy 500 gr ayam potong"
- "1 bh jeruk nipis ambil airnya sy jeruk cui"
- "3 sdm air asam jawa sy skip"
- "2 sdt garam sesuai selera sy 1 sdt"
- "300 ml air kelapa dr 1 bh kelapa"
- "Secukupnya minyak goreng"
- " Bumbu halus"
- "6 siung bawang merah"
- "3 siung bawang putih"
- "5-8 bh cabe rawit optional sy cabe merah"
- "1 sdt kunyit bubuk"
- "1/2 sdt merica bubuk"
- "1 ruas jari Jahe"
- " Bahan lain"
- "10 tangkai daun kari ambil daunnya"
- "7 lmbr daun pandan potong kecil kecil sy 4 lmbr"
- "8 bh cabe hijau sy 4 bh potong serong"
- "8 siung bawang merah iris tipis sy 4 siung"
recipeinstructions:
- "Potong-potong ayam, cuci bersih, tiriskan, beri air jeruk nipis, diamkan beberapa saat, lalu bilas kembali, tiriskan. Siapkan juga bumbu dan bahan rempah daunnya."
- "Masukkan bumbu yang sudah halus ke dalam ayam, ratakan. Tambahkan air kelapa, kmdn ungkep ayam sambil ditutup sampai air menyusut dan bumbu meresap.  Note: jika menggunakan ayam kampung, banyaknya air kelapa bisa disesuaikan."
- "Panaskan minyak goreng (minyak banyak), goreng ayam dgn api sedang, kemudian balik ayam. Setelah ayam mulai berwarna kecoklatan, masukkan daun kari, daun pandan, cabai hijau dan bawang merah iris. Goreng sampai ayam berwarna kecoklatan dan rempah daunnya kering serta bawang merahnya kecoklatan."
- "Setelah ayam matang berwarna kuning kecoklatan dan rempah daun kering, angkat dan tiriskan."
- "Sajikan ayam bersama rempah daun kering, cabai hijau dan bawang goreng keringnya. Ayam ini enak disajikan saat panas-panas, sehingga rempah daunnya masih kriuk."
categories:
- Resep
tags:
- ayam
- tangkap
- khas

katakunci: ayam tangkap khas 
nutrition: 190 calories
recipecuisine: Indonesian
preptime: "PT18M"
cooktime: "PT57M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam tangkap khas Aceh](https://img-global.cpcdn.com/recipes/2b122bcb026a7b5f/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg)

Sebagai seorang wanita, menyediakan panganan mantab buat keluarga adalah hal yang sangat menyenangkan untuk kamu sendiri. Tanggung jawab seorang  wanita Tidak cuman mengatur rumah saja, namun anda pun wajib memastikan kebutuhan gizi terpenuhi dan juga masakan yang dimakan orang tercinta wajib menggugah selera.

Di masa  saat ini, kalian memang dapat memesan panganan instan tidak harus capek memasaknya dahulu. Tapi banyak juga lho mereka yang selalu mau menghidangkan yang terenak untuk orang tercintanya. Lantaran, menghidangkan masakan yang dibuat sendiri akan jauh lebih bersih dan bisa menyesuaikan hidangan tersebut sesuai dengan selera famili. 



Mungkinkah anda seorang penggemar ayam tangkap khas aceh?. Asal kamu tahu, ayam tangkap khas aceh merupakan hidangan khas di Indonesia yang saat ini disukai oleh setiap orang dari hampir setiap tempat di Nusantara. Anda bisa menghidangkan ayam tangkap khas aceh sendiri di rumahmu dan boleh jadi hidangan favoritmu di hari libur.

Kamu jangan bingung untuk memakan ayam tangkap khas aceh, sebab ayam tangkap khas aceh mudah untuk didapatkan dan juga kamu pun dapat mengolahnya sendiri di tempatmu. ayam tangkap khas aceh boleh dibuat memalui beraneka cara. Kini pun ada banyak banget cara kekinian yang membuat ayam tangkap khas aceh semakin nikmat.

Resep ayam tangkap khas aceh juga sangat mudah untuk dibuat, lho. Kamu jangan ribet-ribet untuk membeli ayam tangkap khas aceh, tetapi Kamu dapat membuatnya sendiri di rumah. Untuk Anda yang ingin menghidangkannya, berikut resep untuk menyajikan ayam tangkap khas aceh yang lezat yang mampu Kita hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Ayam tangkap khas Aceh:

1. Gunakan 1 ekor ayam kampung (sy 500 gr ayam potong)
1. Siapkan 1 bh jeruk nipis ambil airnya (sy jeruk cui)
1. Ambil 3 sdm air asam jawa (sy skip)
1. Ambil 2 sdt garam (sesuai selera, sy 1 sdt)
1. Gunakan 300 ml air kelapa (dr 1 bh kelapa)
1. Sediakan Secukupnya minyak goreng
1. Gunakan  Bumbu halus:
1. Gunakan 6 siung bawang merah
1. Gunakan 3 siung bawang putih
1. Gunakan 5-8 bh cabe rawit /optional (sy cabe merah)
1. Siapkan 1 sdt kunyit bubuk
1. Sediakan 1/2 sdt merica bubuk
1. Siapkan 1 ruas jari Jahe
1. Gunakan  Bahan lain:
1. Gunakan 10 tangkai daun kari ambil daunnya
1. Gunakan 7 lmbr daun pandan potong kecil kecil (sy 4 lmbr)
1. Siapkan 8 bh cabe hijau (sy 4 bh potong serong)
1. Sediakan 8 siung bawang merah iris tipis (sy 4 siung)




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam tangkap khas Aceh:

1. Potong-potong ayam, cuci bersih, tiriskan, beri air jeruk nipis, diamkan beberapa saat, lalu bilas kembali, tiriskan. Siapkan juga bumbu dan bahan rempah daunnya.
1. Masukkan bumbu yang sudah halus ke dalam ayam, ratakan. Tambahkan air kelapa, kmdn ungkep ayam sambil ditutup sampai air menyusut dan bumbu meresap.  - Note: jika menggunakan ayam kampung, banyaknya air kelapa bisa disesuaikan.
1. Panaskan minyak goreng (minyak banyak), goreng ayam dgn api sedang, kemudian balik ayam. Setelah ayam mulai berwarna kecoklatan, masukkan daun kari, daun pandan, cabai hijau dan bawang merah iris. Goreng sampai ayam berwarna kecoklatan dan rempah daunnya kering serta bawang merahnya kecoklatan.
1. Setelah ayam matang berwarna kuning kecoklatan dan rempah daun kering, angkat dan tiriskan.
1. Sajikan ayam bersama rempah daun kering, cabai hijau dan bawang goreng keringnya. Ayam ini enak disajikan saat panas-panas, sehingga rempah daunnya masih kriuk.




Ternyata cara buat ayam tangkap khas aceh yang lezat tidak ribet ini gampang sekali ya! Kalian semua bisa menghidangkannya. Resep ayam tangkap khas aceh Cocok banget buat kamu yang baru akan belajar memasak atau juga bagi kalian yang sudah hebat dalam memasak.

Apakah kamu tertarik mencoba buat resep ayam tangkap khas aceh mantab tidak ribet ini? Kalau anda tertarik, ayo kamu segera siapkan alat-alat dan bahannya, setelah itu buat deh Resep ayam tangkap khas aceh yang lezat dan sederhana ini. Sungguh taidak sulit kan. 

Jadi, ketimbang kamu berfikir lama-lama, maka kita langsung saja buat resep ayam tangkap khas aceh ini. Dijamin kalian gak akan nyesel sudah buat resep ayam tangkap khas aceh nikmat simple ini! Selamat berkreasi dengan resep ayam tangkap khas aceh enak tidak ribet ini di tempat tinggal masing-masing,ya!.

