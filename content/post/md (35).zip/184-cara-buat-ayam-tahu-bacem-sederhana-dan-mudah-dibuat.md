---
description: "Cara buat Ayam Tahu Bacem Sederhana dan Mudah Dibuat"
title: "Cara buat Ayam Tahu Bacem Sederhana dan Mudah Dibuat"
slug: 184-cara-buat-ayam-tahu-bacem-sederhana-dan-mudah-dibuat
date: 2021-01-13T13:05:12.681Z
image: https://img-global.cpcdn.com/recipes/27c471f72e4af821/680x482cq70/ayam-tahu-bacem-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/27c471f72e4af821/680x482cq70/ayam-tahu-bacem-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/27c471f72e4af821/680x482cq70/ayam-tahu-bacem-foto-resep-utama.jpg
author: Flora Kelly
ratingvalue: 3.7
reviewcount: 9
recipeingredient:
- "1 kg ayam potong sesuai selera"
- "5 potong tahu"
- " Bumbu Halus"
- "7 siung Bawang merah"
- "5 siung Bawang Putih"
- "4 buah kemiri"
- " Bahan Tambahan"
- "1 ruas Lengkuas 3 cm memarkan"
- "1 batang sereh memarkan"
- "2 lembar daun salam"
- "2 lembar daun jeruk"
- "4 buah gula merah uk kecil diiris tipis agar mudah larut"
- "2 sdm kecap manis"
- " Garam dan penyedap rasa secukupjya"
- " Air secukupnya sampai ayam terendam"
recipeinstructions:
- "Potong ayam menjadi beberapa bagian lalu cuci bersih."
- "Masukkan bumbu halus, bahan tambahan, air dan ayam kedalam panci lalu ungkep sampai airnya hampir habis atau ayamnya matang dan bumbu meresap. Tahu bisa diletakkan dibagian paling atas ya agar tidak hancur."
- "Goreng ayam dan tahu sebentar hingga berwarna kecoklatan. Ayam tahu bacem siap dihidangkan."
- "Sisa ayam ungkep yang belum digoreng bisa disimpan didalam kulkas ya. Kalau dibagian chiller biasanya tahan maksimal 1 minggu."
categories:
- Resep
tags:
- ayam
- tahu
- bacem

katakunci: ayam tahu bacem 
nutrition: 191 calories
recipecuisine: Indonesian
preptime: "PT39M"
cooktime: "PT45M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam Tahu Bacem](https://img-global.cpcdn.com/recipes/27c471f72e4af821/680x482cq70/ayam-tahu-bacem-foto-resep-utama.jpg)

Selaku seorang wanita, menyajikan panganan mantab bagi keluarga adalah suatu hal yang menyenangkan bagi anda sendiri. Kewajiban seorang istri bukan hanya mengurus rumah saja, tetapi anda pun wajib memastikan keperluan nutrisi tercukupi dan olahan yang disantap orang tercinta mesti sedap.

Di waktu  saat ini, anda sebenarnya bisa membeli hidangan siap saji meski tidak harus ribet mengolahnya terlebih dahulu. Tapi ada juga orang yang memang mau memberikan makanan yang terlezat untuk keluarganya. Pasalnya, memasak sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan masakan tersebut sesuai makanan kesukaan orang tercinta. 



Apakah anda adalah salah satu penikmat ayam tahu bacem?. Tahukah kamu, ayam tahu bacem merupakan makanan khas di Nusantara yang sekarang digemari oleh orang-orang di hampir setiap wilayah di Nusantara. Anda dapat menyajikan ayam tahu bacem sendiri di rumah dan dapat dijadikan makanan kesenanganmu di akhir pekanmu.

Anda jangan bingung jika kamu ingin menyantap ayam tahu bacem, karena ayam tahu bacem tidak sulit untuk didapatkan dan kita pun bisa mengolahnya sendiri di rumah. ayam tahu bacem boleh dimasak dengan bermacam cara. Saat ini sudah banyak banget cara kekinian yang menjadikan ayam tahu bacem semakin nikmat.

Resep ayam tahu bacem juga sangat mudah dihidangkan, lho. Kamu tidak usah ribet-ribet untuk membeli ayam tahu bacem, sebab Kamu mampu membuatnya di rumah sendiri. Untuk Anda yang hendak mencobanya, dibawah ini merupakan cara membuat ayam tahu bacem yang lezat yang bisa Kita hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Ayam Tahu Bacem:

1. Sediakan 1 kg ayam (potong sesuai selera)
1. Ambil 5 potong tahu
1. Sediakan  Bumbu Halus
1. Sediakan 7 siung Bawang merah
1. Sediakan 5 siung Bawang Putih
1. Siapkan 4 buah kemiri
1. Sediakan  Bahan Tambahan
1. Siapkan 1 ruas Lengkuas (3 cm) memarkan
1. Siapkan 1 batang sereh memarkan
1. Gunakan 2 lembar daun salam
1. Ambil 2 lembar daun jeruk
1. Sediakan 4 buah gula merah uk kecil (diiris tipis agar mudah larut)
1. Siapkan 2 sdm kecap manis
1. Ambil  Garam dan penyedap rasa secukupjya
1. Gunakan  Air secukupnya (sampai ayam terendam)




<!--inarticleads2-->

##### Cara membuat Ayam Tahu Bacem:

1. Potong ayam menjadi beberapa bagian lalu cuci bersih.
1. Masukkan bumbu halus, bahan tambahan, air dan ayam kedalam panci lalu ungkep sampai airnya hampir habis atau ayamnya matang dan bumbu meresap. Tahu bisa diletakkan dibagian paling atas ya agar tidak hancur.
1. Goreng ayam dan tahu sebentar hingga berwarna kecoklatan. Ayam tahu bacem siap dihidangkan.
1. Sisa ayam ungkep yang belum digoreng bisa disimpan didalam kulkas ya. Kalau dibagian chiller biasanya tahan maksimal 1 minggu.




Ternyata resep ayam tahu bacem yang mantab tidak rumit ini mudah sekali ya! Semua orang mampu mencobanya. Cara Membuat ayam tahu bacem Sesuai sekali buat anda yang baru akan belajar memasak ataupun juga untuk kamu yang telah pandai memasak.

Apakah kamu tertarik mencoba membuat resep ayam tahu bacem mantab tidak ribet ini? Kalau mau, ayo kalian segera buruan menyiapkan peralatan dan bahan-bahannya, setelah itu buat deh Resep ayam tahu bacem yang lezat dan simple ini. Sungguh mudah kan. 

Jadi, daripada kamu diam saja, maka kita langsung saja sajikan resep ayam tahu bacem ini. Pasti anda tak akan nyesel sudah membuat resep ayam tahu bacem enak simple ini! Selamat berkreasi dengan resep ayam tahu bacem enak tidak ribet ini di tempat tinggal masing-masing,oke!.

