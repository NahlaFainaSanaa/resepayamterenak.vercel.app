---
description: "Cara buat Soto Ayam Koya Khas Lamongan Sederhana dan Mudah Dibuat"
title: "Cara buat Soto Ayam Koya Khas Lamongan Sederhana dan Mudah Dibuat"
slug: 227-cara-buat-soto-ayam-koya-khas-lamongan-sederhana-dan-mudah-dibuat
date: 2021-05-28T19:40:37.942Z
image: https://img-global.cpcdn.com/recipes/8e0d01ca0a3bef58/680x482cq70/soto-ayam-koya-khas-lamongan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8e0d01ca0a3bef58/680x482cq70/soto-ayam-koya-khas-lamongan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8e0d01ca0a3bef58/680x482cq70/soto-ayam-koya-khas-lamongan-foto-resep-utama.jpg
author: Belle Fleming
ratingvalue: 4.2
reviewcount: 10
recipeingredient:
- "1/4 ekor Ayam utuh saja"
- "1 liter Air sesuai selera ya"
- "1 cm Jahe geprek"
- "2 lembar Daun salam"
- "3 lembar Daun jeruk"
- "1 batang Serai geprek"
- "2 cm Laos geprek"
- "Secukupnya Garam"
- "Secukupnya Kaldu ayam bubuk"
- " Bumbu halus"
- "4 siung Bawang merah"
- "3 siung Bawang putih"
- "2 cm Kunyit"
- "2 butir kemiri"
- "1/2 sdt Merica butiran"
- " Pelengkap"
- "Secukupnya Soun seduh air panas tiriskan"
- "Secukupnya Toge seduh air panas tiriskan"
- "Secukupnya daun bawang sledri dan tomat iris tipis"
- "Secukupnya Telur rebus"
- "Secukupnya Sambal"
- "Secukupnya jeruk nipis"
- " Bubuk koya"
- "4 buah krupuk udang"
- "2 siung bawang putih iris tipis lalu goreng"
recipeinstructions:
- "Rebus ayam dg jahe smp mendidih, lalu buang busanya."
- "Tumis bumbu halus smp harum, masukkan daun salam, daun jeruk, laos dan serai, tumis smp daun layu dan bumbu matang. Lalu tuang ke rebusan ayam, rebus smp ayam matang"
- "Angkat ayam, tiriskan, goreng 1/2 kering, suwir2 dagingnya. Rebus juga telurnya, setelah matang kupas dan belah 2, sisihkan."
- "Siapkan pelengkap soto."
- "Koya : haluskan kerupuk udang + bawang putih goreng, takaran sesuai selera sj yaa."
- "Tata nasi putih, soun, toge, irisan tomat, daun bawang, sledri, ayam suwir, telur, dan Koya, lalu siram kuah panas."
- "Sajikan dengan sambal dan prasan jeruk nipis. Selamat menikmati"
categories:
- Resep
tags:
- soto
- ayam
- koya

katakunci: soto ayam koya 
nutrition: 187 calories
recipecuisine: Indonesian
preptime: "PT28M"
cooktime: "PT45M"
recipeyield: "4"
recipecategory: Dessert

---


![Soto Ayam Koya Khas Lamongan](https://img-global.cpcdn.com/recipes/8e0d01ca0a3bef58/680x482cq70/soto-ayam-koya-khas-lamongan-foto-resep-utama.jpg)

Apabila kita seorang wanita, menyediakan hidangan mantab buat keluarga adalah hal yang mengasyikan untuk anda sendiri. Kewajiban seorang  wanita Tidak sekedar menangani rumah saja, namun kamu pun wajib memastikan kebutuhan nutrisi terpenuhi dan juga masakan yang dimakan keluarga tercinta harus menggugah selera.

Di waktu  sekarang, anda memang bisa memesan hidangan instan meski tidak harus capek mengolahnya dahulu. Tetapi ada juga lho mereka yang memang mau menyajikan yang terenak bagi orang tercintanya. Sebab, memasak yang dibuat sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan makanan tersebut sesuai dengan masakan kesukaan famili. 



Mungkinkah anda seorang penikmat soto ayam koya khas lamongan?. Asal kamu tahu, soto ayam koya khas lamongan merupakan hidangan khas di Nusantara yang kini disukai oleh kebanyakan orang dari berbagai daerah di Nusantara. Kalian dapat memasak soto ayam koya khas lamongan sendiri di rumahmu dan pasti jadi camilan favorit di akhir pekan.

Kamu jangan bingung jika kamu ingin mendapatkan soto ayam koya khas lamongan, lantaran soto ayam koya khas lamongan tidak sulit untuk ditemukan dan kamu pun bisa menghidangkannya sendiri di rumah. soto ayam koya khas lamongan dapat dimasak dengan beragam cara. Kini sudah banyak sekali resep kekinian yang menjadikan soto ayam koya khas lamongan lebih nikmat.

Resep soto ayam koya khas lamongan juga sangat mudah dibuat, lho. Kalian tidak perlu ribet-ribet untuk membeli soto ayam koya khas lamongan, tetapi Kalian dapat menyiapkan sendiri di rumah. Untuk Kamu yang hendak menghidangkannya, berikut ini resep untuk membuat soto ayam koya khas lamongan yang nikamat yang bisa Kamu coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Soto Ayam Koya Khas Lamongan:

1. Gunakan 1/4 ekor Ayam, utuh saja
1. Siapkan 1 liter Air (sesuai selera ya)
1. Gunakan 1 cm Jahe, geprek
1. Gunakan 2 lembar Daun salam
1. Ambil 3 lembar Daun jeruk
1. Sediakan 1 batang Serai, geprek
1. Ambil 2 cm Laos, geprek
1. Siapkan Secukupnya Garam
1. Gunakan Secukupnya Kaldu ayam bubuk
1. Ambil  Bumbu halus
1. Ambil 4 siung Bawang merah
1. Gunakan 3 siung Bawang putih
1. Sediakan 2 cm Kunyit
1. Siapkan 2 butir kemiri
1. Sediakan 1/2 sdt Merica butiran
1. Gunakan  Pelengkap
1. Sediakan Secukupnya Soun, seduh air panas, tiriskan
1. Siapkan Secukupnya Toge, seduh air panas, tiriskan
1. Ambil Secukupnya daun bawang, sledri dan tomat, iris tipis
1. Gunakan Secukupnya Telur rebus
1. Ambil Secukupnya Sambal
1. Ambil Secukupnya jeruk nipis
1. Sediakan  Bubuk koya
1. Siapkan 4 buah krupuk udang
1. Ambil 2 siung bawang putih iris tipis lalu goreng




<!--inarticleads2-->

##### Cara menyiapkan Soto Ayam Koya Khas Lamongan:

1. Rebus ayam dg jahe smp mendidih, lalu buang busanya.
1. Tumis bumbu halus smp harum, masukkan daun salam, daun jeruk, laos dan serai, tumis smp daun layu dan bumbu matang. Lalu tuang ke rebusan ayam, rebus smp ayam matang
1. Angkat ayam, tiriskan, goreng 1/2 kering, suwir2 dagingnya. Rebus juga telurnya, setelah matang kupas dan belah 2, sisihkan.
1. Siapkan pelengkap soto.
1. Koya : haluskan kerupuk udang + bawang putih goreng, takaran sesuai selera sj yaa.
1. Tata nasi putih, soun, toge, irisan tomat, daun bawang, sledri, ayam suwir, telur, dan Koya, lalu siram kuah panas.
1. Sajikan dengan sambal dan prasan jeruk nipis. Selamat menikmati




Ternyata resep soto ayam koya khas lamongan yang lezat simple ini gampang sekali ya! Kalian semua bisa memasaknya. Cara Membuat soto ayam koya khas lamongan Sangat sesuai banget untuk kalian yang baru belajar memasak ataupun juga untuk kalian yang sudah lihai memasak.

Apakah kamu ingin mulai mencoba buat resep soto ayam koya khas lamongan enak tidak ribet ini? Kalau anda mau, mending kamu segera siapkan alat dan bahannya, lalu bikin deh Resep soto ayam koya khas lamongan yang nikmat dan tidak rumit ini. Sungguh mudah kan. 

Jadi, ketimbang kamu berfikir lama-lama, yuk kita langsung bikin resep soto ayam koya khas lamongan ini. Pasti kalian tiidak akan menyesal bikin resep soto ayam koya khas lamongan enak simple ini! Selamat mencoba dengan resep soto ayam koya khas lamongan enak simple ini di tempat tinggal masing-masing,oke!.

