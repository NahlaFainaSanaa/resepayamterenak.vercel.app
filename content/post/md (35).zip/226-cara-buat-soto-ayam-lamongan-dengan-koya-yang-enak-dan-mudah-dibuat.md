---
description: "Cara buat Soto Ayam Lamongan dengan Koya yang enak dan Mudah Dibuat"
title: "Cara buat Soto Ayam Lamongan dengan Koya yang enak dan Mudah Dibuat"
slug: 226-cara-buat-soto-ayam-lamongan-dengan-koya-yang-enak-dan-mudah-dibuat
date: 2021-02-16T18:14:28.259Z
image: https://img-global.cpcdn.com/recipes/8f29780d9311e2b0/680x482cq70/soto-ayam-lamongan-dengan-koya-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8f29780d9311e2b0/680x482cq70/soto-ayam-lamongan-dengan-koya-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8f29780d9311e2b0/680x482cq70/soto-ayam-lamongan-dengan-koya-foto-resep-utama.jpg
author: Cecilia Jimenez
ratingvalue: 3.8
reviewcount: 3
recipeingredient:
- "1 ekor ayam kampung"
- "1 buah jeruk nipis"
- "2 batang sereh geprek"
- "5 lembar daun jeruk"
- "2 cm lengkuas geprek"
- "2 lembar daun salam"
- "2 barang daun bawang prei"
- "1 sdm garam"
- "1 sdt kaldu bubuk saya  kaldu jamur totole"
- "2 sdt gula pasir"
- "1/2 sdt merica bubuk"
- "1 sdt bawang putih goreng remas"
- "secukupnya air kurang lebih 112 liter"
- "secukupnya minyak goreng untuk menumis"
- "  bumbu dihaluskan "
- "6 siung bawang merah"
- "6 siung bawang putih"
- "4 butir kemiri sangrai"
- "3 cm jahe"
- "3 cm kunyit"
- "1 sdt ketumbar bubuk"
- "1/4 sdt jinten"
- "  Pelengkap "
- " Soun"
- " Telur rebus"
- " Kol kubis"
- " Koya 4 krupuk udang besar  1 sdm bawang putih goreng"
- " Jeruk nipis"
- " Seledri"
- " Sambal cabe Rawit"
- " Bawang merah goreng taburan"
recipeinstructions:
- "Ayam yang sudah di potong dan di cuci bersih di beri perasan air jeruk nipis, diamkan 15 menit lalu bilas....siapkan bumbu cemplungnya, sereh dan lengkuas di geprek, daun jeruk dibuang tulang daunnya."
- "Didihkan air dalam panci...bila sudah mendidih masukkan ayamnya....masukkan juga bumbu cemplungnya (sereh, daun salam, lengkuas dan daun jeruk), masak dengan api sedang cenderung kecil."
- "Siapkan semua bahan untuk membuat bumbu halusnya... haluskan bumbu bisa diulek atau blender...... jika di blender tambahkan minyak goreng agar mudah halusnya."
- "Tumis bumbu halus sampai wangi....lalu beri irisan daun bawang prei (1 batang), aduk rata....masukkan tumisan bumbu ke panci yang berisi ayam."
- "Lalu masukkan garam....masukkan gula pasir....masukkan merica bubuknya."
- "Masukkan juga kaldu jamurnya, aduk rata cek rasanya....bila ayam sudah empuk, sesaat sebelum dimatikan api kompornya masukkan irisan daun bawang prei (1 batang).... serta beri taburan bawang putih goreng yang di remas. Ayamnya bisa diangkat untuk disuwir dagingnya."
- "Untuk membuat sambalnya : cabe rawit di rebus....setelah cukup matang angkat lalu tiriskan, letakkan di cobek dan beri sedikit garam....ulek sampai cukup halus. sajikan"
- "Pelengkap lainnya : didihkan air, lalu masukkan soun sampai cukup lunak, angkat dan tiriskan.....Untuk bawang putih goreng buat koya: 5 siung bawang putih iris tipis, lalu beri garam dan aduk aduk sambil diremas perlahan agar getahnya keluar. bilas beberapa kali sampai bersih lalu goreng sampai kekuningan. (sebagian untuk taburan kuah soto)."
- "Koya : krupuk udang dipotong potong kecil, lalu masukkan ke tempat blender kecil....tambahkan bawang putih goreng, blender sampai halus."
- "Penyajian : pada mangkuk masukkan nasi, diatasnya letakkan soun....diatas soun letakkan irisan kol/ kubis....lalu siram kuah soto, beri suwiran daging ayam, irisan telur rebus serta pelengkap lainnya."
- "Soto ayam juga bisa disajikan tanpa di suwir daging ayamnya....tanpa di suwir ada ke asyikkan tersendiri yaitu kita bisa sambil gigit tulang ayam untuk mencari daging yang menempel ☺👍"
- "Sajikan Soto Ayam Lamongan dengan Koya.....Sedaaap 👍🏻😊"
categories:
- Resep
tags:
- soto
- ayam
- lamongan

katakunci: soto ayam lamongan 
nutrition: 231 calories
recipecuisine: Indonesian
preptime: "PT39M"
cooktime: "PT37M"
recipeyield: "2"
recipecategory: Dessert

---


![Soto Ayam Lamongan dengan Koya](https://img-global.cpcdn.com/recipes/8f29780d9311e2b0/680x482cq70/soto-ayam-lamongan-dengan-koya-foto-resep-utama.jpg)

Sebagai seorang ibu, menyajikan olahan mantab buat keluarga merupakan suatu hal yang menyenangkan untuk kita sendiri. Kewajiban seorang ibu Tidak sekadar mengurus rumah saja, namun kamu pun wajib menyediakan keperluan nutrisi tercukupi dan juga masakan yang disantap orang tercinta wajib nikmat.

Di waktu  sekarang, kita memang dapat memesan olahan yang sudah jadi tidak harus repot membuatnya dahulu. Tapi banyak juga lho orang yang selalu ingin memberikan makanan yang terenak untuk keluarganya. Karena, menyajikan masakan sendiri jauh lebih higienis dan kita juga bisa menyesuaikan sesuai masakan kesukaan famili. 



Mungkinkah kamu salah satu penyuka soto ayam lamongan dengan koya?. Tahukah kamu, soto ayam lamongan dengan koya adalah sajian khas di Indonesia yang sekarang digemari oleh banyak orang dari berbagai daerah di Nusantara. Kita bisa membuat soto ayam lamongan dengan koya kreasi sendiri di rumahmu dan boleh jadi santapan kesenanganmu di hari liburmu.

Kita tidak usah bingung untuk memakan soto ayam lamongan dengan koya, sebab soto ayam lamongan dengan koya mudah untuk didapatkan dan anda pun bisa mengolahnya sendiri di rumah. soto ayam lamongan dengan koya boleh diolah lewat bermacam cara. Kini pun ada banyak banget resep kekinian yang menjadikan soto ayam lamongan dengan koya semakin lebih enak.

Resep soto ayam lamongan dengan koya juga gampang untuk dibikin, lho. Kamu jangan ribet-ribet untuk memesan soto ayam lamongan dengan koya, karena Kalian dapat menyiapkan sendiri di rumah. Bagi Kita yang ingin mencobanya, dibawah ini merupakan cara untuk menyajikan soto ayam lamongan dengan koya yang lezat yang mampu Kalian hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Soto Ayam Lamongan dengan Koya:

1. Sediakan 1 ekor ayam kampung
1. Ambil 1 buah jeruk nipis
1. Siapkan 2 batang sereh (geprek)
1. Sediakan 5 lembar daun jeruk
1. Sediakan 2 cm lengkuas (geprek)
1. Siapkan 2 lembar daun salam
1. Ambil 2 barang daun bawang prei
1. Siapkan 1 sdm garam
1. Gunakan 1 sdt kaldu bubuk (saya : kaldu jamur/ totole)
1. Ambil 2 sdt gula pasir
1. Ambil 1/2 sdt merica bubuk
1. Gunakan 1 sdt bawang putih goreng (remas)
1. Gunakan secukupnya air (kurang lebih 11/2 liter)
1. Ambil secukupnya minyak goreng untuk menumis
1. Gunakan  👉 bumbu dihaluskan :
1. Siapkan 6 siung bawang merah
1. Gunakan 6 siung bawang putih
1. Gunakan 4 butir kemiri sangrai
1. Gunakan 3 cm jahe
1. Siapkan 3 cm kunyit
1. Siapkan 1 sdt ketumbar bubuk
1. Ambil 1/4 sdt jinten
1. Sediakan  👉 Pelengkap :
1. Ambil  Soun
1. Sediakan  Telur rebus
1. Gunakan  Kol/ kubis
1. Gunakan  Koya (4 krupuk udang besar + 1 sdm bawang putih goreng)
1. Gunakan  Jeruk nipis
1. Sediakan  Seledri
1. Siapkan  Sambal cabe Rawit
1. Siapkan  Bawang merah goreng (taburan)




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Soto Ayam Lamongan dengan Koya:

1. Ayam yang sudah di potong dan di cuci bersih di beri perasan air jeruk nipis, diamkan 15 menit lalu bilas....siapkan bumbu cemplungnya, sereh dan lengkuas di geprek, daun jeruk dibuang tulang daunnya.
1. Didihkan air dalam panci...bila sudah mendidih masukkan ayamnya....masukkan juga bumbu cemplungnya (sereh, daun salam, lengkuas dan daun jeruk), masak dengan api sedang cenderung kecil.
1. Siapkan semua bahan untuk membuat - bumbu halusnya... haluskan bumbu bisa diulek atau blender...... jika di blender tambahkan minyak goreng agar mudah halusnya.
1. Tumis bumbu halus sampai wangi....lalu beri irisan daun bawang prei (1 batang), aduk rata....masukkan tumisan bumbu ke panci yang berisi ayam.
1. Lalu masukkan garam....masukkan gula pasir....masukkan merica bubuknya.
1. Masukkan juga kaldu jamurnya, aduk rata cek rasanya....bila ayam sudah empuk, sesaat sebelum dimatikan api kompornya masukkan irisan daun bawang prei (1 batang).... serta beri taburan bawang putih goreng yang di remas. Ayamnya bisa diangkat untuk disuwir dagingnya.
1. Untuk membuat sambalnya : cabe rawit di rebus....setelah cukup matang angkat lalu tiriskan, letakkan di cobek dan beri sedikit garam....ulek sampai cukup halus. sajikan
1. Pelengkap lainnya : didihkan air, lalu masukkan soun sampai cukup lunak, angkat dan tiriskan.....Untuk bawang putih goreng buat koya: 5 siung bawang putih iris tipis, lalu beri garam dan aduk aduk sambil diremas perlahan agar getahnya keluar. bilas beberapa kali sampai bersih lalu goreng sampai kekuningan. (sebagian untuk taburan kuah soto).
1. Koya : krupuk udang dipotong potong kecil, lalu masukkan ke tempat blender kecil....tambahkan bawang putih goreng, blender sampai halus.
1. Penyajian : pada mangkuk masukkan nasi, diatasnya letakkan soun....diatas soun letakkan irisan kol/ kubis....lalu siram kuah soto, beri suwiran daging ayam, irisan telur rebus serta pelengkap lainnya.
1. Soto ayam juga bisa disajikan tanpa di suwir daging ayamnya....tanpa di suwir ada ke asyikkan tersendiri yaitu kita bisa sambil gigit tulang ayam untuk mencari daging yang menempel ☺👍
1. Sajikan Soto Ayam Lamongan dengan Koya.....Sedaaap 👍🏻😊




Wah ternyata cara buat soto ayam lamongan dengan koya yang enak simple ini enteng banget ya! Anda Semua dapat memasaknya. Cara buat soto ayam lamongan dengan koya Sesuai sekali untuk kalian yang baru mau belajar memasak ataupun untuk anda yang sudah jago memasak.

Apakah kamu ingin mencoba bikin resep soto ayam lamongan dengan koya mantab sederhana ini? Kalau kamu ingin, yuk kita segera buruan menyiapkan peralatan dan bahannya, lantas buat deh Resep soto ayam lamongan dengan koya yang enak dan tidak ribet ini. Sangat gampang kan. 

Oleh karena itu, ketimbang anda diam saja, maka langsung aja sajikan resep soto ayam lamongan dengan koya ini. Pasti kamu tak akan menyesal sudah buat resep soto ayam lamongan dengan koya mantab sederhana ini! Selamat mencoba dengan resep soto ayam lamongan dengan koya lezat tidak rumit ini di rumah sendiri,oke!.

