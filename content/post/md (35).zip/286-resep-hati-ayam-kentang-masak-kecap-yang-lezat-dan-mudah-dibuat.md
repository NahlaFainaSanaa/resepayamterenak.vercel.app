---
description: "Resep Hati ayam kentang masak kecap yang lezat dan Mudah Dibuat"
title: "Resep Hati ayam kentang masak kecap yang lezat dan Mudah Dibuat"
slug: 286-resep-hati-ayam-kentang-masak-kecap-yang-lezat-dan-mudah-dibuat
date: 2021-02-07T20:49:46.930Z
image: https://img-global.cpcdn.com/recipes/2f1d81f284043d58/680x482cq70/hati-ayam-kentang-masak-kecap-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2f1d81f284043d58/680x482cq70/hati-ayam-kentang-masak-kecap-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2f1d81f284043d58/680x482cq70/hati-ayam-kentang-masak-kecap-foto-resep-utama.jpg
author: Duane Klein
ratingvalue: 3.9
reviewcount: 14
recipeingredient:
- "4 bh hati ayam"
- "4 bh kentang"
- "3 bh bawang merah  1 bh bombay"
- "2 bh bawang putih"
- "secukupnya Merica"
- "2 helai daun bawang iris"
- "1 bh tomat besar iris"
- "1 ruas jahe"
- "2 sdm kecap manis"
- "1 sdt saori saus tiram"
- "secukupnya Garampenyedap"
- "secukupnya Air"
recipeinstructions:
- "Rebus hati ayam,stlh masak potong dan sisihkan"
- "Kupas dan potong kentang sesuai selera,lalu digoreng"
- "Iris bawang merah,geprek bawang putih dan jahe"
- "Tumis bawang,jahe dan merica hingga harum"
- "Tambahkan garam,penyedap dan air"
- "Lalu masukkan saori,dan kecap manis"
- "Masukkan hati ayam dan kentang,aduk rata dan diamkan sejenak sampai seluruh bumbu meresap."
- "Terakhir masukkan irisan daun bawang dan tomat sbg pelengkap,aduk rata"
- "Siap dihidangkan🤗"
categories:
- Resep
tags:
- hati
- ayam
- kentang

katakunci: hati ayam kentang 
nutrition: 167 calories
recipecuisine: Indonesian
preptime: "PT23M"
cooktime: "PT53M"
recipeyield: "3"
recipecategory: Dinner

---


![Hati ayam kentang masak kecap](https://img-global.cpcdn.com/recipes/2f1d81f284043d58/680x482cq70/hati-ayam-kentang-masak-kecap-foto-resep-utama.jpg)

Sebagai seorang istri, menyuguhkan masakan menggugah selera buat keluarga tercinta merupakan hal yang memuaskan untuk anda sendiri. Kewajiban seorang istri Tidak hanya mengurus rumah saja, namun kamu juga wajib menyediakan kebutuhan gizi tercukupi dan panganan yang dimakan orang tercinta harus sedap.

Di masa  sekarang, kalian sebenarnya bisa membeli masakan yang sudah jadi meski tanpa harus susah membuatnya terlebih dahulu. Tetapi banyak juga mereka yang memang mau memberikan hidangan yang terbaik bagi keluarganya. Karena, menyajikan masakan sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan masakan tersebut sesuai selera orang tercinta. 



Mungkinkah anda salah satu penikmat hati ayam kentang masak kecap?. Tahukah kamu, hati ayam kentang masak kecap adalah sajian khas di Nusantara yang kini digemari oleh banyak orang dari berbagai wilayah di Nusantara. Kalian bisa memasak hati ayam kentang masak kecap olahan sendiri di rumahmu dan dapat dijadikan santapan kegemaranmu di hari liburmu.

Anda tidak perlu bingung jika kamu ingin memakan hati ayam kentang masak kecap, lantaran hati ayam kentang masak kecap tidak sukar untuk dicari dan juga kalian pun boleh membuatnya sendiri di rumah. hati ayam kentang masak kecap dapat dimasak lewat berbagai cara. Saat ini ada banyak banget resep kekinian yang menjadikan hati ayam kentang masak kecap semakin lebih nikmat.

Resep hati ayam kentang masak kecap juga mudah dibikin, lho. Kamu jangan repot-repot untuk membeli hati ayam kentang masak kecap, lantaran Kalian mampu menyajikan di rumah sendiri. Bagi Kita yang hendak menghidangkannya, berikut ini resep untuk menyajikan hati ayam kentang masak kecap yang lezat yang mampu Kamu hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Hati ayam kentang masak kecap:

1. Ambil 4 bh hati ayam
1. Gunakan 4 bh kentang
1. Siapkan 3 bh bawang merah / 1 bh bombay
1. Gunakan 2 bh bawang putih
1. Ambil secukupnya Merica
1. Gunakan 2 helai daun bawang, iris
1. Gunakan 1 bh tomat besar, iris
1. Siapkan 1 ruas jahe
1. Siapkan 2 sdm kecap manis
1. Sediakan 1 sdt saori saus tiram
1. Sediakan secukupnya Garam,penyedap
1. Siapkan secukupnya Air




<!--inarticleads2-->

##### Cara menyiapkan Hati ayam kentang masak kecap:

1. Rebus hati ayam,stlh masak potong dan sisihkan
1. Kupas dan potong kentang sesuai selera,lalu digoreng
1. Iris bawang merah,geprek bawang putih dan jahe
1. Tumis bawang,jahe dan merica hingga harum
1. Tambahkan garam,penyedap dan air
1. Lalu masukkan saori,dan kecap manis
1. Masukkan hati ayam dan kentang,aduk rata dan diamkan sejenak sampai seluruh bumbu meresap.
1. Terakhir masukkan irisan daun bawang dan tomat sbg pelengkap,aduk rata
1. Siap dihidangkan🤗




Wah ternyata resep hati ayam kentang masak kecap yang mantab tidak ribet ini mudah banget ya! Kalian semua bisa memasaknya. Resep hati ayam kentang masak kecap Sangat cocok sekali untuk anda yang baru mau belajar memasak ataupun juga untuk kamu yang telah pandai memasak.

Tertarik untuk mulai mencoba bikin resep hati ayam kentang masak kecap nikmat simple ini? Kalau kalian mau, mending kamu segera siapkan peralatan dan bahan-bahannya, maka buat deh Resep hati ayam kentang masak kecap yang enak dan sederhana ini. Sangat gampang kan. 

Maka dari itu, daripada kita diam saja, yuk langsung aja hidangkan resep hati ayam kentang masak kecap ini. Dijamin kamu gak akan nyesel sudah bikin resep hati ayam kentang masak kecap enak tidak rumit ini! Selamat mencoba dengan resep hati ayam kentang masak kecap mantab tidak rumit ini di rumah sendiri,oke!.

