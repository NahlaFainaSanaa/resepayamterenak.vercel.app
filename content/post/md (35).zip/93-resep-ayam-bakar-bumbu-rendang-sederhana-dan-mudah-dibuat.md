---
description: "Resep Ayam Bakar Bumbu Rendang Sederhana dan Mudah Dibuat"
title: "Resep Ayam Bakar Bumbu Rendang Sederhana dan Mudah Dibuat"
slug: 93-resep-ayam-bakar-bumbu-rendang-sederhana-dan-mudah-dibuat
date: 2021-06-23T07:24:19.833Z
image: https://img-global.cpcdn.com/recipes/bdaff2e861ce7ef5/680x482cq70/ayam-bakar-bumbu-rendang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/bdaff2e861ce7ef5/680x482cq70/ayam-bakar-bumbu-rendang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/bdaff2e861ce7ef5/680x482cq70/ayam-bakar-bumbu-rendang-foto-resep-utama.jpg
author: Phoebe Manning
ratingvalue: 4.6
reviewcount: 8
recipeingredient:
- "1 ekor ayam potong sesuai jumlah selera"
- " Bahan Ungkep Ayam"
- "1 buah bumbu ungkep jadiinstan"
- "400 ml air"
- "3 buah bawang putih"
- "1 batang sereh geprek"
- "4 lembar daun jeruk"
- "1-2 sdt garam biasanya bumbu instan sudah asin"
- "1-2 sdt gula pasir"
- "1 sdt lada bubuk"
- "1 sdt kaldu bubuk ayam"
- " Bahan Oles"
- "1 buah bumbu rendang jadiinstan"
- "1 sdt garam"
- "1 sdt gula pasir"
- "Sedikit minyak sayur untuk menumis"
- " Sambal Ayam Bakar"
- "2 buah tomat tomatku ukuran kecil"
- "4 buah bawang merah"
- "2 buah bawang putih"
- "7 buah cabe merah"
- "18 buah cabe rawit merah"
- "2 buah kemiri"
- "1/2 keping gula jawa"
- "2 biji asem rendam dalam sedikit air lalu ambil airnya"
- "1 lembar daun jeruk"
- "1 sdt garam"
- "Secukupnya minyak sayur untuk menggoreng"
recipeinstructions:
- "Cuci bersih ayam. Didihkan air lalu masukkan ayam beserta bahan ungkep ayam. Masak hingga air asat dan ayam empuk. Jangan lupa koreksi rasa."
- "Tumis bahan oles, tambahkan sedikit air. Masak hingga air menyusut dan bumbu menjadi kental. Koreksi rasa."
- "Masukkan potongan ayam yg sudah diungkep ke atas teflon/bakaran, lalu oles dg bahan oles/bumbu rendang. Panggang/bakar hingga harum dan kecoklatan."
- "Buat sambal ayam bakarnya: goreng tomat cabe dua bawang kemiri hingga layu."
- "Haluskan (uleg/blender) bahan² yg sudah digoreng tadi. Karena aku pake blender, tambahkan sedikit minyak sayur yg tadi untuk menggoreng agar mudah diblender. Kalo pake blender jangan terlalu halus hasilnya."
- "Tuang ke dalam wajan, lalu tumis. Tambahkan gula jawa, garam, air asam, daun jeruk. Koreksi rasa (aku tambahkan sedikit gula pasir). Masak hingga sambal berwarna kecoklatan dan pekat. Siap disampingkan dg ayam bakar."
categories:
- Resep
tags:
- ayam
- bakar
- bumbu

katakunci: ayam bakar bumbu 
nutrition: 264 calories
recipecuisine: Indonesian
preptime: "PT21M"
cooktime: "PT50M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Bakar Bumbu Rendang](https://img-global.cpcdn.com/recipes/bdaff2e861ce7ef5/680x482cq70/ayam-bakar-bumbu-rendang-foto-resep-utama.jpg)

Selaku seorang ibu, mempersiapkan hidangan lezat kepada keluarga tercinta merupakan hal yang mengasyikan untuk anda sendiri. Tugas seorang istri bukan hanya mengerjakan pekerjaan rumah saja, tapi kamu juga harus menyediakan keperluan gizi tercukupi dan juga olahan yang dikonsumsi orang tercinta mesti sedap.

Di zaman  saat ini, kamu memang dapat memesan panganan instan tidak harus ribet memasaknya lebih dulu. Tapi ada juga lho mereka yang memang ingin memberikan yang terenak bagi orang yang dicintainya. Sebab, menyajikan masakan yang diolah sendiri jauh lebih bersih dan kita juga bisa menyesuaikan masakan tersebut berdasarkan kesukaan keluarga. 



Mungkinkah anda merupakan seorang penikmat ayam bakar bumbu rendang?. Tahukah kamu, ayam bakar bumbu rendang adalah makanan khas di Indonesia yang kini disukai oleh kebanyakan orang dari hampir setiap daerah di Indonesia. Anda dapat menyajikan ayam bakar bumbu rendang buatan sendiri di rumah dan pasti jadi makanan kesenanganmu di hari libur.

Kamu tak perlu bingung jika kamu ingin memakan ayam bakar bumbu rendang, sebab ayam bakar bumbu rendang sangat mudah untuk dicari dan kalian pun bisa membuatnya sendiri di rumah. ayam bakar bumbu rendang bisa dimasak dengan bermacam cara. Kini ada banyak banget cara modern yang membuat ayam bakar bumbu rendang semakin lebih nikmat.

Resep ayam bakar bumbu rendang juga gampang dibuat, lho. Anda tidak perlu capek-capek untuk membeli ayam bakar bumbu rendang, karena Kamu mampu menyajikan di rumahmu. Bagi Kalian yang hendak mencobanya, dibawah ini merupakan resep menyajikan ayam bakar bumbu rendang yang enak yang bisa Kita coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Ayam Bakar Bumbu Rendang:

1. Gunakan 1 ekor ayam, potong sesuai jumlah selera
1. Gunakan  Bahan Ungkep Ayam
1. Siapkan 1 buah bumbu ungkep jadi/instan
1. Siapkan 400 ml air
1. Siapkan 3 buah bawang putih
1. Sediakan 1 batang sereh, geprek
1. Gunakan 4 lembar daun jeruk
1. Gunakan 1-2 sdt garam (biasanya bumbu instan sudah asin)
1. Sediakan 1-2 sdt gula pasir
1. Ambil 1 sdt lada bubuk
1. Gunakan 1 sdt kaldu bubuk ayam
1. Ambil  Bahan Oles
1. Ambil 1 buah bumbu rendang jadi/instan
1. Siapkan 1 sdt garam
1. Siapkan 1 sdt gula pasir
1. Siapkan Sedikit minyak sayur untuk menumis
1. Siapkan  Sambal Ayam Bakar
1. Sediakan 2 buah tomat (tomatku ukuran kecil)
1. Gunakan 4 buah bawang merah
1. Sediakan 2 buah bawang putih
1. Siapkan 7 buah cabe merah
1. Siapkan 18 buah cabe rawit merah
1. Sediakan 2 buah kemiri
1. Gunakan 1/2 keping gula jawa
1. Siapkan 2 biji asem, rendam dalam sedikit air lalu ambil airnya
1. Ambil 1 lembar daun jeruk
1. Sediakan 1 sdt garam
1. Gunakan Secukupnya minyak sayur untuk menggoreng




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Bakar Bumbu Rendang:

1. Cuci bersih ayam. Didihkan air lalu masukkan ayam beserta bahan ungkep ayam. Masak hingga air asat dan ayam empuk. Jangan lupa koreksi rasa.
1. Tumis bahan oles, tambahkan sedikit air. Masak hingga air menyusut dan bumbu menjadi kental. Koreksi rasa.
1. Masukkan potongan ayam yg sudah diungkep ke atas teflon/bakaran, lalu oles dg bahan oles/bumbu rendang. Panggang/bakar hingga harum dan kecoklatan.
1. Buat sambal ayam bakarnya: goreng tomat cabe dua bawang kemiri hingga layu.
1. Haluskan (uleg/blender) bahan² yg sudah digoreng tadi. Karena aku pake blender, tambahkan sedikit minyak sayur yg tadi untuk menggoreng agar mudah diblender. Kalo pake blender jangan terlalu halus hasilnya.
1. Tuang ke dalam wajan, lalu tumis. Tambahkan gula jawa, garam, air asam, daun jeruk. Koreksi rasa (aku tambahkan sedikit gula pasir). Masak hingga sambal berwarna kecoklatan dan pekat. Siap disampingkan dg ayam bakar.




Ternyata cara buat ayam bakar bumbu rendang yang mantab tidak rumit ini gampang sekali ya! Semua orang bisa mencobanya. Cara buat ayam bakar bumbu rendang Sesuai sekali untuk kalian yang baru akan belajar memasak ataupun juga untuk kalian yang sudah lihai dalam memasak.

Apakah kamu tertarik mulai mencoba membuat resep ayam bakar bumbu rendang lezat tidak rumit ini? Kalau anda mau, ayo kalian segera siapin peralatan dan bahan-bahannya, kemudian bikin deh Resep ayam bakar bumbu rendang yang mantab dan sederhana ini. Sangat mudah kan. 

Oleh karena itu, ketimbang anda berfikir lama-lama, ayo kita langsung saja sajikan resep ayam bakar bumbu rendang ini. Pasti anda tiidak akan menyesal membuat resep ayam bakar bumbu rendang mantab sederhana ini! Selamat mencoba dengan resep ayam bakar bumbu rendang mantab simple ini di rumah masing-masing,oke!.

