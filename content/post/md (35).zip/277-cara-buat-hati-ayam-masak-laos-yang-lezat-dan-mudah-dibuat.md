---
description: "Cara buat Hati Ayam Masak Laos yang lezat dan Mudah Dibuat"
title: "Cara buat Hati Ayam Masak Laos yang lezat dan Mudah Dibuat"
slug: 277-cara-buat-hati-ayam-masak-laos-yang-lezat-dan-mudah-dibuat
date: 2021-05-22T17:23:05.107Z
image: https://img-global.cpcdn.com/recipes/5cf21d73fa2bf12f/680x482cq70/hati-ayam-masak-laos-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5cf21d73fa2bf12f/680x482cq70/hati-ayam-masak-laos-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5cf21d73fa2bf12f/680x482cq70/hati-ayam-masak-laos-foto-resep-utama.jpg
author: Louis Bowman
ratingvalue: 3.3
reviewcount: 7
recipeingredient:
- "300 gr Hati Ayam"
- "1 buah jeruk nipis"
- "2 lembar daun salam"
- "2 batang sereh keprek"
- "Secukupnya garamgulakaldu bubuk"
- "50 g laos  lengkuas diblender"
- "Secukupnya air dan minyak goreng"
- " Bumbu halus"
- "5 bawang merah"
- "3 bawang putih"
- "3 buah kemiri"
- "1 ruas jahe"
- "1 ruas kunyit"
- "Sejumput jinten"
- "1 sdm ketumbar"
recipeinstructions:
- "Cuci bersih hati ayam, beri air jeruk nipis, ratakan dan diamkan 5 menit, kemudian bilas hingga bersih."
- "Blender laos atau diparut. Ukek atau proses bumbu halusnya."
- "Panaskan minyak dan tumis bumbu halus hingga tercium aroma yang harum, lalu masukkan serai dan daun salam, dan laos parut."
- "Masukkan hati ayam, aduk perlahan jingga hati ayam berubah warna dan kaku. Setelah itu beri air, garam, gula dan kaldu bubuk. Cek rasa.. Masak hingga airnya sat."
- "Kemudian goreng hati ayam hingga kecoklatan dan bumbu laosnya mengering. Jadi deh🥰"
categories:
- Resep
tags:
- hati
- ayam
- masak

katakunci: hati ayam masak 
nutrition: 121 calories
recipecuisine: Indonesian
preptime: "PT27M"
cooktime: "PT44M"
recipeyield: "1"
recipecategory: Dinner

---


![Hati Ayam Masak Laos](https://img-global.cpcdn.com/recipes/5cf21d73fa2bf12f/680x482cq70/hati-ayam-masak-laos-foto-resep-utama.jpg)

Apabila kamu seorang orang tua, menyajikan masakan menggugah selera untuk orang tercinta adalah suatu hal yang mengasyikan untuk kita sendiri. Tanggung jawab seorang ibu bukan sekadar menangani rumah saja, tetapi kamu pun wajib menyediakan kebutuhan nutrisi tercukupi dan olahan yang disantap anak-anak harus mantab.

Di zaman  saat ini, kamu sebenarnya bisa memesan santapan siap saji meski tidak harus capek mengolahnya lebih dulu. Tetapi ada juga orang yang memang ingin menghidangkan yang terlezat untuk keluarganya. Lantaran, menghidangkan masakan sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan sesuai selera keluarga. 



Mungkinkah anda salah satu penggemar hati ayam masak laos?. Tahukah kamu, hati ayam masak laos merupakan hidangan khas di Indonesia yang saat ini disukai oleh banyak orang dari berbagai wilayah di Nusantara. Anda dapat membuat hati ayam masak laos sendiri di rumah dan boleh dijadikan makanan kegemaranmu di hari libur.

Kalian tidak usah bingung untuk memakan hati ayam masak laos, sebab hati ayam masak laos mudah untuk dicari dan kamu pun boleh memasaknya sendiri di rumah. hati ayam masak laos boleh diolah lewat beragam cara. Sekarang sudah banyak banget resep modern yang menjadikan hati ayam masak laos semakin mantap.

Resep hati ayam masak laos juga sangat gampang untuk dibuat, lho. Kita jangan ribet-ribet untuk membeli hati ayam masak laos, tetapi Kalian dapat membuatnya di rumahmu. Untuk Anda yang ingin mencobanya, inilah cara untuk menyajikan hati ayam masak laos yang nikamat yang bisa Kamu coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Hati Ayam Masak Laos:

1. Ambil 300 gr Hati Ayam
1. Ambil 1 buah jeruk nipis
1. Sediakan 2 lembar daun salam
1. Siapkan 2 batang sereh keprek
1. Siapkan Secukupnya garam,gula,kaldu bubuk
1. Gunakan 50 g laos / lengkuas diblender
1. Sediakan Secukupnya air dan minyak goreng
1. Gunakan  Bumbu halus:
1. Ambil 5 bawang merah
1. Siapkan 3 bawang putih
1. Ambil 3 buah kemiri
1. Ambil 1 ruas jahe
1. Siapkan 1 ruas kunyit
1. Sediakan Sejumput jinten
1. Gunakan 1 sdm ketumbar




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Hati Ayam Masak Laos:

1. Cuci bersih hati ayam, beri air jeruk nipis, ratakan dan diamkan 5 menit, kemudian bilas hingga bersih.
1. Blender laos atau diparut. Ukek atau proses bumbu halusnya.
1. Panaskan minyak dan tumis bumbu halus hingga tercium aroma yang harum, lalu masukkan serai dan daun salam, dan laos parut.
1. Masukkan hati ayam, aduk perlahan jingga hati ayam berubah warna dan kaku. Setelah itu beri air, garam, gula dan kaldu bubuk. Cek rasa.. Masak hingga airnya sat.
1. Kemudian goreng hati ayam hingga kecoklatan dan bumbu laosnya mengering. Jadi deh🥰




Ternyata cara membuat hati ayam masak laos yang nikamt tidak rumit ini enteng sekali ya! Kita semua mampu menghidangkannya. Cara Membuat hati ayam masak laos Sesuai sekali buat kita yang baru mau belajar memasak ataupun untuk anda yang telah jago memasak.

Apakah kamu tertarik mulai mencoba membikin resep hati ayam masak laos mantab tidak rumit ini? Kalau kamu mau, ayo kamu segera siapin alat-alat dan bahan-bahannya, lalu bikin deh Resep hati ayam masak laos yang nikmat dan simple ini. Sangat gampang kan. 

Jadi, daripada kita berfikir lama-lama, ayo langsung aja bikin resep hati ayam masak laos ini. Dijamin anda tak akan nyesel sudah bikin resep hati ayam masak laos nikmat sederhana ini! Selamat mencoba dengan resep hati ayam masak laos nikmat sederhana ini di rumah masing-masing,oke!.

