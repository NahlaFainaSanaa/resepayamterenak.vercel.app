---
description: "Resep Ayam goreng kriuk ala ala KFC yang nikmat dan Mudah Dibuat"
title: "Resep Ayam goreng kriuk ala ala KFC yang nikmat dan Mudah Dibuat"
slug: 388-resep-ayam-goreng-kriuk-ala-ala-kfc-yang-nikmat-dan-mudah-dibuat
date: 2021-05-07T22:06:52.644Z
image: https://img-global.cpcdn.com/recipes/db4ed9bcdb5b5cd0/680x482cq70/ayam-goreng-kriuk-ala-ala-kfc-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/db4ed9bcdb5b5cd0/680x482cq70/ayam-goreng-kriuk-ala-ala-kfc-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/db4ed9bcdb5b5cd0/680x482cq70/ayam-goreng-kriuk-ala-ala-kfc-foto-resep-utama.jpg
author: Millie McGuire
ratingvalue: 4.2
reviewcount: 7
recipeingredient:
- "1/2 ayam dipotong menjadi 7 bagian cuci bersih dan rendam dengan perasan jeruk nipis selama 12 jam Cuci bersih sisihkan Untuk menghilangkan bau anyir"
- "1 liter minyak goreng untuk menggoreng"
- " Bumbu rendaman"
- "4 siung bawang putih"
- "1/2 sdt garam"
- "1/2 sdt merica halus"
- " Bahan basah"
- "250 ml air"
- "1/2 sdt garam halus"
- "1 buah putih telur"
- "4 sdm tepung terigu"
- " Bahan kering "
- "250 gram tepung terigu"
- "1 sdt garam"
- "1/2 sdt merica halus"
- "1 sdt kaldu bubuk"
recipeinstructions:
- "Cara membuat : haluskan bumbu marinate, lumurkan ke daging ayam hingga rata, diamkan dikulkas minimum 30 menit."
- "Siapkan baskom, isi dengan adonan basah. Campurkan sampai merata. Siapkan baskom lain isi dengan adonan kering, aduk hingga tercampur rata."
- "Lumuri daging ayam yang sudah dimarinate kedalam adonan kering hingga merata. Lalu celupkan kedalam adonan basah dengan menggunakan capitan, agar tangan tidak kotor dan basah.kemudian masukkan kedalam adonan kering sambil di cubit-cubit dan diremas-remas dengan menggunakan tangan, agar tepungnya menempel dan keriting."
- "Ulangi yang terakhir, masukkan kedalam adonan basah lagi, kemudian adonan kering lagi. Dengan cara yang sama."
- "Siapkan penggorengan, tuang minyak yang banyak karena ayam akan digoreng dengan metode deep frying."
- "Panaskan minyak hingga minyak benar-benar panas, kecilkan api, kemudian goreng ayam hingga matang berwarna coklat keemasan."
- "Sajikan dengan nasi hangat dan saos sambal."
categories:
- Resep
tags:
- ayam
- goreng
- kriuk

katakunci: ayam goreng kriuk 
nutrition: 209 calories
recipecuisine: Indonesian
preptime: "PT39M"
cooktime: "PT45M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam goreng kriuk ala ala KFC](https://img-global.cpcdn.com/recipes/db4ed9bcdb5b5cd0/680x482cq70/ayam-goreng-kriuk-ala-ala-kfc-foto-resep-utama.jpg)

Selaku seorang istri, mempersiapkan panganan nikmat pada famili adalah suatu hal yang sangat menyenangkan bagi anda sendiri. Peran seorang ibu bukan hanya menjaga rumah saja, namun anda pun harus menyediakan kebutuhan nutrisi tercukupi dan juga hidangan yang dimakan orang tercinta wajib nikmat.

Di era  sekarang, kalian memang dapat mengorder masakan instan tidak harus capek membuatnya dahulu. Tetapi ada juga orang yang selalu mau menyajikan yang terlezat untuk orang tercintanya. Karena, menyajikan masakan yang dibuat sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan masakan tersebut berdasarkan kesukaan famili. 



Mungkinkah anda merupakan seorang penyuka ayam goreng kriuk ala ala kfc?. Asal kamu tahu, ayam goreng kriuk ala ala kfc merupakan sajian khas di Nusantara yang sekarang digemari oleh kebanyakan orang di hampir setiap daerah di Nusantara. Anda bisa menyajikan ayam goreng kriuk ala ala kfc sendiri di rumah dan boleh jadi hidangan kegemaranmu di akhir pekanmu.

Kalian tak perlu bingung jika kamu ingin menyantap ayam goreng kriuk ala ala kfc, lantaran ayam goreng kriuk ala ala kfc tidak sulit untuk ditemukan dan anda pun boleh mengolahnya sendiri di rumah. ayam goreng kriuk ala ala kfc dapat dibuat memalui beraneka cara. Kini telah banyak resep modern yang membuat ayam goreng kriuk ala ala kfc semakin lezat.

Resep ayam goreng kriuk ala ala kfc juga mudah untuk dibuat, lho. Kalian tidak perlu ribet-ribet untuk memesan ayam goreng kriuk ala ala kfc, karena Kita dapat menyajikan di rumahmu. Bagi Kalian yang akan mencobanya, inilah cara menyajikan ayam goreng kriuk ala ala kfc yang lezat yang mampu Anda coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Ayam goreng kriuk ala ala KFC:

1. Siapkan 1/2 ayam dipotong menjadi 7 bagian, cuci bersih dan rendam dengan perasan jeruk nipis selama 1/2 jam. Cuci bersih, sisihkan. (Untuk menghilangkan bau anyir)
1. Siapkan 1 liter minyak goreng untuk menggoreng
1. Gunakan  Bumbu rendaman:
1. Gunakan 4 siung bawang putih
1. Ambil 1/2 sdt garam
1. Gunakan 1/2 sdt merica halus
1. Ambil  Bahan basah:
1. Ambil 250 ml air
1. Siapkan 1/2 sdt garam halus
1. Ambil 1 buah putih telur
1. Siapkan 4 sdm tepung terigu
1. Sediakan  Bahan kering :
1. Siapkan 250 gram tepung terigu
1. Siapkan 1 sdt garam
1. Gunakan 1/2 sdt merica halus
1. Sediakan 1 sdt kaldu bubuk




<!--inarticleads2-->

##### Cara menyiapkan Ayam goreng kriuk ala ala KFC:

1. Cara membuat : haluskan bumbu marinate, lumurkan ke daging ayam hingga rata, diamkan dikulkas minimum 30 menit.
1. Siapkan baskom, isi dengan adonan basah. Campurkan sampai merata. Siapkan baskom lain isi dengan adonan kering, aduk hingga tercampur rata.
1. Lumuri daging ayam yang sudah dimarinate kedalam adonan kering hingga merata. Lalu celupkan kedalam adonan basah dengan menggunakan capitan, agar tangan tidak kotor dan basah.kemudian masukkan kedalam adonan kering sambil di cubit-cubit dan diremas-remas dengan menggunakan tangan, agar tepungnya menempel dan keriting.
1. Ulangi yang terakhir, masukkan kedalam adonan basah lagi, kemudian adonan kering lagi. Dengan cara yang sama.
1. Siapkan penggorengan, tuang minyak yang banyak karena ayam akan digoreng dengan metode deep frying.
1. Panaskan minyak hingga minyak benar-benar panas, kecilkan api, kemudian goreng ayam hingga matang berwarna coklat keemasan.
1. Sajikan dengan nasi hangat dan saos sambal.




Ternyata resep ayam goreng kriuk ala ala kfc yang nikamt sederhana ini enteng banget ya! Kalian semua mampu mencobanya. Resep ayam goreng kriuk ala ala kfc Sangat cocok banget buat kamu yang baru mau belajar memasak maupun juga bagi kalian yang telah pandai memasak.

Tertarik untuk mencoba buat resep ayam goreng kriuk ala ala kfc nikmat simple ini? Kalau anda mau, mending kamu segera buruan menyiapkan alat dan bahan-bahannya, maka buat deh Resep ayam goreng kriuk ala ala kfc yang nikmat dan sederhana ini. Sungguh mudah kan. 

Maka, daripada anda berlama-lama, hayo langsung aja sajikan resep ayam goreng kriuk ala ala kfc ini. Dijamin kamu gak akan menyesal sudah buat resep ayam goreng kriuk ala ala kfc nikmat tidak rumit ini! Selamat berkreasi dengan resep ayam goreng kriuk ala ala kfc enak simple ini di tempat tinggal masing-masing,oke!.

