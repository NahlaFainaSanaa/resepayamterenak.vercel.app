---
description: "Cara buat Ayam Rica-Rica yang enak dan Mudah Dibuat"
title: "Cara buat Ayam Rica-Rica yang enak dan Mudah Dibuat"
slug: 434-cara-buat-ayam-rica-rica-yang-enak-dan-mudah-dibuat
date: 2021-02-11T07:29:13.976Z
image: https://img-global.cpcdn.com/recipes/2e8b4f17f5c9bfcd/680x482cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2e8b4f17f5c9bfcd/680x482cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2e8b4f17f5c9bfcd/680x482cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Millie Norris
ratingvalue: 4.5
reviewcount: 5
recipeingredient:
- "1/2 ekor ayam"
- "1 buah Jeruk nipis  peras"
- "secukupnya Daun kemangi"
- "1 buah Tomat  iris opsi"
- "3 batang Serai  geprek"
- "3 lembar Daun jeruk"
- "3 lembar Daun salam"
- "1 cm Jahe  geprek"
- "1 cm Lengkuas  geprek"
- "secukupnya Gula  Garam"
- "secukupnya Penyedap rasa"
- " Bumbu Halus "
- "6 butir Bawang merah"
- "3 siung Bawang putih"
- "sesuai selera Cabe rawit"
- "1 cm Kunyit"
- "3 butir Kemiri"
- "secukupnya Ketumbar"
recipeinstructions:
- "Potong ayam agak kecil, cuci bersih lalu lumuri perasan jeruk nipis,diamkan 10 menit, bilas hingga bersih kemudian goreng setengah matang."
- "Panaskan 2 sdm minyak goreng, masukkan bumbu halus,tambahkan serai, daun jeruk, daun salam, lengkuas, jahe, gula,garam dan penyedap. Tumis hingga harum."
- "Masukkan ayam dan tomat,, tambahkan sedikit air, biarkan hingga bumbu meresap dan matang sempurna. Matikan api, lalu masukkan daun kemangi, aduk rata.Ayam rica siap dihidangkan bersama nasi hangat."
categories:
- Resep
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 104 calories
recipecuisine: Indonesian
preptime: "PT36M"
cooktime: "PT57M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam Rica-Rica](https://img-global.cpcdn.com/recipes/2e8b4f17f5c9bfcd/680x482cq70/ayam-rica-rica-foto-resep-utama.jpg)

Sebagai seorang istri, mempersiapkan panganan sedap kepada keluarga adalah hal yang membahagiakan untuk kamu sendiri. Peran seorang  wanita bukan cuman mengurus rumah saja, tapi kamu juga wajib menyediakan kebutuhan gizi tercukupi dan santapan yang dikonsumsi keluarga tercinta harus enak.

Di waktu  sekarang, kalian memang mampu membeli masakan jadi tanpa harus capek memasaknya dulu. Tapi banyak juga lho orang yang selalu mau menghidangkan yang terenak untuk orang yang dicintainya. Sebab, menghidangkan masakan yang diolah sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan masakan tersebut sesuai kesukaan orang tercinta. 



Mungkinkah kamu salah satu penyuka ayam rica-rica?. Tahukah kamu, ayam rica-rica adalah makanan khas di Indonesia yang saat ini digemari oleh orang-orang dari berbagai daerah di Indonesia. Kalian dapat membuat ayam rica-rica sendiri di rumahmu dan dapat dijadikan santapan favoritmu di hari libur.

Kalian tidak perlu bingung jika kamu ingin menyantap ayam rica-rica, karena ayam rica-rica mudah untuk ditemukan dan kita pun bisa menghidangkannya sendiri di tempatmu. ayam rica-rica boleh dibuat memalui beraneka cara. Kini pun sudah banyak cara kekinian yang menjadikan ayam rica-rica semakin lebih enak.

Resep ayam rica-rica pun gampang sekali dibuat, lho. Kamu tidak usah ribet-ribet untuk membeli ayam rica-rica, tetapi Kita mampu menyajikan di rumah sendiri. Untuk Kalian yang ingin menghidangkannya, berikut ini cara membuat ayam rica-rica yang enak yang mampu Kalian buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Ayam Rica-Rica:

1. Ambil 1/2 ekor ayam
1. Sediakan 1 buah Jeruk nipis , peras
1. Ambil secukupnya Daun kemangi
1. Gunakan 1 buah Tomat , iris (opsi)
1. Ambil 3 batang Serai , geprek
1. Siapkan 3 lembar Daun jeruk
1. Sediakan 3 lembar Daun salam
1. Ambil 1 cm Jahe , geprek
1. Gunakan 1 cm Lengkuas , geprek
1. Gunakan secukupnya Gula &amp; Garam
1. Gunakan secukupnya Penyedap rasa
1. Ambil  Bumbu Halus :
1. Ambil 6 butir Bawang merah
1. Ambil 3 siung Bawang putih
1. Siapkan sesuai selera Cabe rawit
1. Siapkan 1 cm Kunyit
1. Gunakan 3 butir Kemiri
1. Sediakan secukupnya Ketumbar




<!--inarticleads2-->

##### Cara menyiapkan Ayam Rica-Rica:

1. Potong ayam agak kecil, cuci bersih lalu lumuri perasan jeruk nipis,diamkan 10 menit, bilas hingga bersih kemudian goreng setengah matang.
1. Panaskan 2 sdm minyak goreng, masukkan bumbu halus,tambahkan serai, daun jeruk, daun salam, lengkuas, jahe, gula,garam dan penyedap. Tumis hingga harum.
1. Masukkan ayam dan tomat,, tambahkan sedikit air, biarkan hingga bumbu meresap dan matang sempurna. Matikan api, lalu masukkan daun kemangi, aduk rata.Ayam rica siap dihidangkan bersama nasi hangat.




Ternyata cara membuat ayam rica-rica yang nikamt simple ini mudah sekali ya! Anda Semua bisa membuatnya. Resep ayam rica-rica Sangat cocok banget buat kamu yang baru belajar memasak ataupun untuk kalian yang telah lihai dalam memasak.

Tertarik untuk mulai mencoba membuat resep ayam rica-rica enak simple ini? Kalau anda tertarik, ayo kalian segera buruan menyiapkan alat-alat dan bahan-bahannya, lalu buat deh Resep ayam rica-rica yang nikmat dan tidak ribet ini. Sungguh taidak sulit kan. 

Jadi, daripada anda berlama-lama, maka kita langsung sajikan resep ayam rica-rica ini. Dijamin kamu gak akan nyesel bikin resep ayam rica-rica mantab simple ini! Selamat berkreasi dengan resep ayam rica-rica lezat tidak rumit ini di tempat tinggal masing-masing,ya!.

