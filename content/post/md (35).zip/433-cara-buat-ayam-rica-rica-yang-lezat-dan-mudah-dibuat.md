---
description: "Cara buat Ayam Rica-rica yang lezat dan Mudah Dibuat"
title: "Cara buat Ayam Rica-rica yang lezat dan Mudah Dibuat"
slug: 433-cara-buat-ayam-rica-rica-yang-lezat-dan-mudah-dibuat
date: 2021-02-10T18:24:57.593Z
image: https://img-global.cpcdn.com/recipes/032c14f700e6f94f/680x482cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/032c14f700e6f94f/680x482cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/032c14f700e6f94f/680x482cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Cecilia Carroll
ratingvalue: 3.9
reviewcount: 4
recipeingredient:
- "1/2 kg ayampotong sesuai selera"
- "1 ikat kemangipetik daunnya saja"
- "1 btg serai geprek"
- "2 lembar daun jeruk"
- "2 siung bawang putih cincang"
- "1/2 biji jeruk nipis"
- "1/2 sdt merica bubuk"
- "secukupnya Kaldu jamurgaram dan gula pasir"
- "secukupnya Air"
- " Minyak makan buat menumis nanti"
- " Bumbu halus"
- "5 siung bawang merah"
- "2 siung bawang putih"
- "5-10 bh cabe merah"
- "10 bj cabe rawit"
- "3 cm jahe"
- "2 bj kemiri"
- "2 ruas kelingking kunyit"
recipeinstructions:
- "Cuci bersih ayam yang sudah dipotong-potong tadi, kemudian marinasi dengan melumuri jeruk nipis, bawang putih cincang, garam dan merica bubuk. Diamkan sekitar 15 menit, kemudian digoreng 3/4 matang. Jadi jangan sampai kecoklatan,sisihkan"
- "Tumis bumbu halus, masukkan serai,daun jeruk sampai matang lalu masukkan garam, kaldu jamur dan gula pasir aduk rata dan masukkan air secukupnya, cek rasa"
- "Masukkan ayam, aduk-aduk dan biarkn hingga airnya berkurang agar bumbu lebih meresap,"
- "Setelah airnya sudah mulai berkurang dan setengah kering,masukkan daun kemangi dan daun bawang, aduk-aduk hingga kemangi agak layu, kemudian angkat"
- "Sajikan dengan nasi hangat Selamat menikmati 😘"
categories:
- Resep
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 122 calories
recipecuisine: Indonesian
preptime: "PT28M"
cooktime: "PT57M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Rica-rica](https://img-global.cpcdn.com/recipes/032c14f700e6f94f/680x482cq70/ayam-rica-rica-foto-resep-utama.jpg)

Sebagai seorang ibu, menyajikan olahan nikmat kepada famili merupakan hal yang memuaskan untuk anda sendiri. Kewajiban seorang ibu Tidak sekedar menangani rumah saja, namun kamu pun wajib menyediakan kebutuhan nutrisi tercukupi dan juga masakan yang disantap orang tercinta harus menggugah selera.

Di zaman  saat ini, kamu memang mampu memesan hidangan jadi tanpa harus repot membuatnya dahulu. Tapi ada juga orang yang memang ingin menghidangkan yang terenak bagi orang yang dicintainya. Lantaran, menghidangkan masakan yang dibuat sendiri akan jauh lebih bersih dan bisa menyesuaikan sesuai selera famili. 



Mungkinkah anda seorang penikmat ayam rica-rica?. Tahukah kamu, ayam rica-rica adalah sajian khas di Indonesia yang kini digemari oleh orang-orang di berbagai daerah di Nusantara. Kalian bisa menyajikan ayam rica-rica sendiri di rumah dan dapat dijadikan makanan favorit di hari liburmu.

Kalian tidak usah bingung untuk menyantap ayam rica-rica, sebab ayam rica-rica tidak sukar untuk ditemukan dan juga anda pun dapat membuatnya sendiri di tempatmu. ayam rica-rica bisa dimasak memalui bermacam cara. Saat ini telah banyak sekali cara kekinian yang membuat ayam rica-rica semakin lebih nikmat.

Resep ayam rica-rica pun gampang untuk dibikin, lho. Kalian tidak usah ribet-ribet untuk membeli ayam rica-rica, karena Kamu bisa membuatnya sendiri di rumah. Untuk Kalian yang ingin menghidangkannya, di bawah ini adalah resep membuat ayam rica-rica yang enak yang mampu Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Ayam Rica-rica:

1. Sediakan 1/2 kg ayam,potong sesuai selera
1. Siapkan 1 ikat kemangi,petik daunnya saja
1. Siapkan 1 btg serai geprek
1. Gunakan 2 lembar daun jeruk
1. Sediakan 2 siung bawang putih cincang
1. Ambil 1/2 biji jeruk nipis
1. Sediakan 1/2 sdt merica bubuk
1. Ambil secukupnya Kaldu jamur,garam dan gula pasir
1. Gunakan secukupnya Air
1. Ambil  Minyak makan buat menumis nanti
1. Sediakan  Bumbu halus
1. Ambil 5 siung bawang merah
1. Ambil 2 siung bawang putih
1. Sediakan 5-10 bh cabe merah
1. Sediakan 10 bj cabe rawit
1. Siapkan 3 cm jahe
1. Ambil 2 bj kemiri
1. Sediakan 2 ruas kelingking kunyit




<!--inarticleads2-->

##### Cara menyiapkan Ayam Rica-rica:

1. Cuci bersih ayam yang sudah dipotong-potong tadi, kemudian marinasi dengan melumuri jeruk nipis, bawang putih cincang, garam dan merica bubuk. Diamkan sekitar 15 menit, kemudian digoreng 3/4 matang. Jadi jangan sampai kecoklatan,sisihkan
1. Tumis bumbu halus, masukkan serai,daun jeruk sampai matang lalu masukkan garam, kaldu jamur dan gula pasir aduk rata dan masukkan air secukupnya, cek rasa
1. Masukkan ayam, aduk-aduk dan biarkn hingga airnya berkurang agar bumbu lebih meresap,
1. Setelah airnya sudah mulai berkurang dan setengah kering,masukkan daun kemangi dan daun bawang, aduk-aduk hingga kemangi agak layu, kemudian angkat
1. Sajikan dengan nasi hangat - Selamat menikmati 😘




Ternyata cara membuat ayam rica-rica yang mantab tidak rumit ini enteng banget ya! Kamu semua mampu menghidangkannya. Cara Membuat ayam rica-rica Sangat cocok banget buat anda yang baru akan belajar memasak maupun bagi kamu yang telah hebat memasak.

Tertarik untuk mencoba buat resep ayam rica-rica mantab tidak ribet ini? Kalau kalian tertarik, yuk kita segera buruan siapkan alat dan bahan-bahannya, kemudian bikin deh Resep ayam rica-rica yang nikmat dan tidak ribet ini. Betul-betul taidak sulit kan. 

Maka, ketimbang kalian diam saja, hayo langsung aja buat resep ayam rica-rica ini. Pasti kamu tak akan menyesal bikin resep ayam rica-rica lezat sederhana ini! Selamat berkreasi dengan resep ayam rica-rica enak tidak ribet ini di rumah kalian sendiri,oke!.

