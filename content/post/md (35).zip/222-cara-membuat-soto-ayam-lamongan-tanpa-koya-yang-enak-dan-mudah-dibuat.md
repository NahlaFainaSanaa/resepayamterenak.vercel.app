---
description: "Cara membuat Soto Ayam Lamongan (tanpa koya) yang enak dan Mudah Dibuat"
title: "Cara membuat Soto Ayam Lamongan (tanpa koya) yang enak dan Mudah Dibuat"
slug: 222-cara-membuat-soto-ayam-lamongan-tanpa-koya-yang-enak-dan-mudah-dibuat
date: 2021-02-27T00:50:30.680Z
image: https://img-global.cpcdn.com/recipes/bb0e66762a1c5052/680x482cq70/soto-ayam-lamongan-tanpa-koya-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/bb0e66762a1c5052/680x482cq70/soto-ayam-lamongan-tanpa-koya-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/bb0e66762a1c5052/680x482cq70/soto-ayam-lamongan-tanpa-koya-foto-resep-utama.jpg
author: Betty Douglas
ratingvalue: 3.1
reviewcount: 6
recipeingredient:
- "500 gram ayam bagian dada ayam kampung lebih nikmat"
- "1 batang sereh"
- "3 lbr daun salam"
- "3 lbr daun jeruk"
- "1 ruas jari lengkuas"
- "Secukupnya minyak goreng"
- "Secukupnya garam"
- "Secukupnya gula pasir"
- "Secukupnya kaldu jamur  penyedap"
- " Bumbu halus"
- "8 siung bawang merah"
- "4 siung bawang putih"
- "1 sdt ketumbar"
- "1 ruas jari kunyit"
- "1 ruas jari jahe"
- "1 sdt merica  lada bubuk"
- "3 butir kemiri"
- " Bahan Pelengkap"
- "4 butir telur ayam"
- "1 bks bihun jagung"
- "2 genggam tauge"
- "1 batang daun bawang"
- "2 batang seledri"
- "Secukupnya bawang merah goreng"
recipeinstructions:
- "Cuci bersih ayam, rebus selama 3 menit, buang airnya, lalu ganti dengan air baru, rebus lagi"
- "Selagi menunggu rebusan ayam, haluskan bumbu halus, lalu tumis, masukkan daun salam, daun jeruk, sereh, dan lengkuas, aduk hingga harum"
- "Setelah bumbu harum, masukkan kedalam rebusan ayam, tambahkan garam, gula, penyedap, aduk dan tunggu hingga ayam matang"
- "Di panci lain, siapkan air rebusan untuk telur, tauge, dan bihun, lalu sisihkan untuk masing2 bahan"
- "Setelah kuah matang, angkat ayam dan goreng pada minyak panas, lalu suwir-suwir ayamnya"
- "Potong-potong daun bawang dan seledri, lalu sajikan seluruh bahan kedalam mangkok seperti pada gambar dengan taburan bawang goreng di atasnya"
categories:
- Resep
tags:
- soto
- ayam
- lamongan

katakunci: soto ayam lamongan 
nutrition: 116 calories
recipecuisine: Indonesian
preptime: "PT13M"
cooktime: "PT50M"
recipeyield: "3"
recipecategory: Dinner

---


![Soto Ayam Lamongan (tanpa koya)](https://img-global.cpcdn.com/recipes/bb0e66762a1c5052/680x482cq70/soto-ayam-lamongan-tanpa-koya-foto-resep-utama.jpg)

Sebagai seorang yang hobi masak, menyajikan masakan mantab buat keluarga merupakan hal yang menyenangkan bagi anda sendiri. Tugas seorang ibu bukan sekedar mengurus rumah saja, namun anda pun harus menyediakan kebutuhan gizi terpenuhi dan masakan yang disantap keluarga tercinta wajib menggugah selera.

Di waktu  sekarang, kamu sebenarnya mampu memesan hidangan siap saji walaupun tanpa harus ribet membuatnya dahulu. Tetapi banyak juga lho mereka yang selalu ingin memberikan yang terlezat bagi keluarganya. Sebab, menyajikan masakan sendiri akan jauh lebih bersih dan bisa menyesuaikan hidangan tersebut berdasarkan masakan kesukaan famili. 



Mungkinkah kamu salah satu penggemar soto ayam lamongan (tanpa koya)?. Tahukah kamu, soto ayam lamongan (tanpa koya) merupakan hidangan khas di Indonesia yang sekarang digemari oleh orang-orang dari berbagai daerah di Indonesia. Kalian bisa menghidangkan soto ayam lamongan (tanpa koya) olahan sendiri di rumah dan boleh jadi camilan kesukaanmu di hari libur.

Kita tidak perlu bingung jika kamu ingin memakan soto ayam lamongan (tanpa koya), sebab soto ayam lamongan (tanpa koya) tidak sulit untuk dicari dan kalian pun boleh mengolahnya sendiri di rumah. soto ayam lamongan (tanpa koya) boleh dimasak memalui beragam cara. Sekarang telah banyak sekali resep modern yang membuat soto ayam lamongan (tanpa koya) semakin lebih nikmat.

Resep soto ayam lamongan (tanpa koya) pun mudah dibuat, lho. Anda jangan ribet-ribet untuk memesan soto ayam lamongan (tanpa koya), lantaran Kita dapat menghidangkan ditempatmu. Untuk Kamu yang akan mencobanya, berikut resep untuk membuat soto ayam lamongan (tanpa koya) yang mantab yang bisa Kamu coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Soto Ayam Lamongan (tanpa koya):

1. Siapkan 500 gram ayam bagian dada (ayam kampung lebih nikmat)
1. Ambil 1 batang sereh
1. Sediakan 3 lbr daun salam
1. Siapkan 3 lbr daun jeruk
1. Ambil 1 ruas jari lengkuas
1. Siapkan Secukupnya minyak goreng
1. Gunakan Secukupnya garam
1. Ambil Secukupnya gula pasir
1. Sediakan Secukupnya kaldu jamur / penyedap
1. Ambil  Bumbu halus
1. Siapkan 8 siung bawang merah
1. Siapkan 4 siung bawang putih
1. Siapkan 1 sdt ketumbar
1. Gunakan 1 ruas jari kunyit
1. Sediakan 1 ruas jari jahe
1. Gunakan 1 sdt merica / lada bubuk
1. Ambil 3 butir kemiri
1. Gunakan  Bahan Pelengkap
1. Ambil 4 butir telur ayam
1. Gunakan 1 bks bihun jagung
1. Siapkan 2 genggam tauge
1. Siapkan 1 batang daun bawang
1. Ambil 2 batang seledri
1. Sediakan Secukupnya bawang merah goreng




<!--inarticleads2-->

##### Cara membuat Soto Ayam Lamongan (tanpa koya):

1. Cuci bersih ayam, rebus selama 3 menit, buang airnya, lalu ganti dengan air baru, rebus lagi
1. Selagi menunggu rebusan ayam, haluskan bumbu halus, lalu tumis, masukkan daun salam, daun jeruk, sereh, dan lengkuas, aduk hingga harum
1. Setelah bumbu harum, masukkan kedalam rebusan ayam, tambahkan garam, gula, penyedap, aduk dan tunggu hingga ayam matang
1. Di panci lain, siapkan air rebusan untuk telur, tauge, dan bihun, lalu sisihkan untuk masing2 bahan
1. Setelah kuah matang, angkat ayam dan goreng pada minyak panas, lalu suwir-suwir ayamnya
1. Potong-potong daun bawang dan seledri, lalu sajikan seluruh bahan kedalam mangkok seperti pada gambar dengan taburan bawang goreng di atasnya




Wah ternyata resep soto ayam lamongan (tanpa koya) yang nikamt sederhana ini enteng sekali ya! Kamu semua dapat membuatnya. Cara Membuat soto ayam lamongan (tanpa koya) Sesuai sekali untuk anda yang baru belajar memasak atau juga untuk kamu yang sudah pandai dalam memasak.

Tertarik untuk mencoba bikin resep soto ayam lamongan (tanpa koya) enak simple ini? Kalau mau, mending kamu segera siapin alat dan bahan-bahannya, lalu buat deh Resep soto ayam lamongan (tanpa koya) yang enak dan tidak ribet ini. Sungguh taidak sulit kan. 

Maka, daripada kamu diam saja, yuk kita langsung sajikan resep soto ayam lamongan (tanpa koya) ini. Pasti kalian tak akan menyesal bikin resep soto ayam lamongan (tanpa koya) nikmat simple ini! Selamat mencoba dengan resep soto ayam lamongan (tanpa koya) mantab sederhana ini di tempat tinggal masing-masing,ya!.

