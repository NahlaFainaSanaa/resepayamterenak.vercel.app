---
description: "Bahan-bahan Tahu dan Ati Ayam Masak Sambal yang nikmat dan Mudah Dibuat"
title: "Bahan-bahan Tahu dan Ati Ayam Masak Sambal yang nikmat dan Mudah Dibuat"
slug: 273-bahan-bahan-tahu-dan-ati-ayam-masak-sambal-yang-nikmat-dan-mudah-dibuat
date: 2021-06-25T03:16:22.739Z
image: https://img-global.cpcdn.com/recipes/7730efe4abe61b5a/680x482cq70/tahu-dan-ati-ayam-masak-sambal-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7730efe4abe61b5a/680x482cq70/tahu-dan-ati-ayam-masak-sambal-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7730efe4abe61b5a/680x482cq70/tahu-dan-ati-ayam-masak-sambal-foto-resep-utama.jpg
author: Elsie Olson
ratingvalue: 4.6
reviewcount: 12
recipeingredient:
- "4 buah Tahu ukuran sedang goreng"
- "250 gram Hati ayam rebus lalu goreng"
- "2 cm lengkuas geprek"
- "2 lembar daun salam"
- "1 sdt Garam"
- "1 sdt Gula"
- "1/2 sdt Merica"
- "2 sdm Kecap manis jika suka"
- " Kaldu udang 1 sdt bisa juga kaldu jamur atau lainnya           lihat resep"
- " Bumbu halus "
- "6 buah Bawang merah"
- "3 siung Bawang putih"
- "3 buah Cabe merah besar"
- "15 buah cabe rawit sesuai selera"
recipeinstructions:
- "Siapkan bahan : Goreng tahu. Rebus dan goreng hati sapi. Haluskan bumbu."
- "Tumis bumbu dengan sedikit minyak, masukkan Lengkuas dan daun salam. Aduk rata biarkan hingga harum, selagi menunggu, potong² hati sapi. Setelah bumbu harum masukkan kedua bahan utama. Aduk rata."
- "Beri sedikit air, masukkan, gula, garam, merica, kaldu udang, kecap. Aduk rata. Test rasa. Masak hingga air menyusut dan bumbu meresap."
- "Tahu dan Ati Ayam masak sambal, siap di sajikan dengan nasi hangat. Selamat mencoba. Praktis dan enak."
categories:
- Resep
tags:
- tahu
- dan
- ati

katakunci: tahu dan ati 
nutrition: 154 calories
recipecuisine: Indonesian
preptime: "PT36M"
cooktime: "PT57M"
recipeyield: "2"
recipecategory: Lunch

---


![Tahu dan Ati Ayam Masak Sambal](https://img-global.cpcdn.com/recipes/7730efe4abe61b5a/680x482cq70/tahu-dan-ati-ayam-masak-sambal-foto-resep-utama.jpg)

Sebagai seorang yang hobi masak, mempersiapkan panganan nikmat bagi keluarga tercinta adalah hal yang menyenangkan untuk kamu sendiri. Peran seorang  wanita bukan cuma menjaga rumah saja, tapi anda juga harus menyediakan kebutuhan nutrisi tercukupi dan olahan yang dimakan keluarga tercinta wajib menggugah selera.

Di masa  saat ini, kamu memang mampu membeli panganan jadi meski tanpa harus ribet memasaknya terlebih dahulu. Tapi ada juga lho mereka yang memang ingin menyajikan yang terbaik bagi orang tercintanya. Sebab, menghidangkan masakan yang diolah sendiri jauh lebih bersih dan kita pun bisa menyesuaikan makanan tersebut berdasarkan masakan kesukaan keluarga tercinta. 



Mungkinkah anda adalah seorang penyuka tahu dan ati ayam masak sambal?. Asal kamu tahu, tahu dan ati ayam masak sambal adalah sajian khas di Indonesia yang saat ini disenangi oleh kebanyakan orang di berbagai daerah di Nusantara. Anda dapat membuat tahu dan ati ayam masak sambal buatan sendiri di rumahmu dan pasti jadi camilan kegemaranmu di akhir pekan.

Kamu tak perlu bingung untuk menyantap tahu dan ati ayam masak sambal, sebab tahu dan ati ayam masak sambal mudah untuk ditemukan dan kamu pun dapat memasaknya sendiri di tempatmu. tahu dan ati ayam masak sambal boleh dibuat lewat bermacam cara. Saat ini telah banyak sekali cara kekinian yang menjadikan tahu dan ati ayam masak sambal semakin lebih lezat.

Resep tahu dan ati ayam masak sambal juga gampang sekali dihidangkan, lho. Kita tidak perlu ribet-ribet untuk membeli tahu dan ati ayam masak sambal, karena Kalian dapat menyiapkan sendiri di rumah. Bagi Kita yang ingin menghidangkannya, di bawah ini adalah resep menyajikan tahu dan ati ayam masak sambal yang nikamat yang mampu Anda buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Tahu dan Ati Ayam Masak Sambal:

1. Siapkan 4 buah Tahu ukuran sedang (goreng)
1. Siapkan 250 gram Hati ayam (rebus lalu goreng)
1. Gunakan 2 cm lengkuas geprek
1. Gunakan 2 lembar daun salam
1. Siapkan 1 sdt Garam
1. Siapkan 1 sdt Gula
1. Siapkan 1/2 sdt Merica
1. Gunakan 2 sdm Kecap manis (jika suka)
1. Siapkan  Kaldu udang 1 sdt (bisa juga kaldu jamur atau lainnya)           (lihat resep)
1. Ambil  Bumbu halus :
1. Gunakan 6 buah Bawang merah
1. Sediakan 3 siung Bawang putih
1. Gunakan 3 buah Cabe merah besar
1. Gunakan 15 buah cabe rawit (sesuai selera)




<!--inarticleads2-->

##### Cara menyiapkan Tahu dan Ati Ayam Masak Sambal:

1. Siapkan bahan : Goreng tahu. Rebus dan goreng hati sapi. Haluskan bumbu.
1. Tumis bumbu dengan sedikit minyak, masukkan Lengkuas dan daun salam. Aduk rata biarkan hingga harum, selagi menunggu, potong² hati sapi. Setelah bumbu harum masukkan kedua bahan utama. Aduk rata.
1. Beri sedikit air, masukkan, gula, garam, merica, kaldu udang, kecap. Aduk rata. Test rasa. Masak hingga air menyusut dan bumbu meresap.
1. Tahu dan Ati Ayam masak sambal, siap di sajikan dengan nasi hangat. Selamat mencoba. Praktis dan enak.




Wah ternyata cara buat tahu dan ati ayam masak sambal yang mantab sederhana ini gampang banget ya! Semua orang bisa memasaknya. Resep tahu dan ati ayam masak sambal Cocok banget buat anda yang baru akan belajar memasak atau juga untuk anda yang sudah jago memasak.

Apakah kamu ingin mencoba membikin resep tahu dan ati ayam masak sambal mantab sederhana ini? Kalau kalian tertarik, ayo kamu segera menyiapkan alat-alat dan bahan-bahannya, lantas buat deh Resep tahu dan ati ayam masak sambal yang enak dan simple ini. Sangat mudah kan. 

Jadi, daripada anda diam saja, maka kita langsung sajikan resep tahu dan ati ayam masak sambal ini. Dijamin anda tiidak akan menyesal sudah membuat resep tahu dan ati ayam masak sambal nikmat simple ini! Selamat mencoba dengan resep tahu dan ati ayam masak sambal enak sederhana ini di rumah kalian masing-masing,oke!.

