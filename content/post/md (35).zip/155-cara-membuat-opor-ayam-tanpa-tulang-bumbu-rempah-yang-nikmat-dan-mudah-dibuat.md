---
description: "Cara membuat Opor Ayam Tanpa Tulang Bumbu Rempah yang nikmat dan Mudah Dibuat"
title: "Cara membuat Opor Ayam Tanpa Tulang Bumbu Rempah yang nikmat dan Mudah Dibuat"
slug: 155-cara-membuat-opor-ayam-tanpa-tulang-bumbu-rempah-yang-nikmat-dan-mudah-dibuat
date: 2021-02-25T19:45:02.352Z
image: https://img-global.cpcdn.com/recipes/e67db22f79d7268d/680x482cq70/opor-ayam-tanpa-tulang-bumbu-rempah-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e67db22f79d7268d/680x482cq70/opor-ayam-tanpa-tulang-bumbu-rempah-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e67db22f79d7268d/680x482cq70/opor-ayam-tanpa-tulang-bumbu-rempah-foto-resep-utama.jpg
author: Delia Hamilton
ratingvalue: 3.7
reviewcount: 10
recipeingredient:
- "1/2 kg ayam me400 gr ayam fillet"
- "3 buah tahu me4 telur rebus"
- "1 bungkus santan kara dilarutkan segelas air"
- "700 ml air"
- "2 lembar daun salam"
- "2 lembar daun jeruk"
- "2 buah kapulaga"
- "2 buah pekak"
- "5 cm kayu manis mesdt bubuk kayu manis"
- "1 batang serai geprek"
- "1/2 bawang bombay kecil"
- "1 lembar daun kunyit tambahan dari saya"
- "1 ruas lengkuas geprektambahan dari saya"
- " Bumbu halus"
- "4 siung bawang merah"
- "4 siung bawang putih"
- "1/2 sdt ketumbar"
- "8 butir merica me1sdt merica bubuk"
- "1/4 sdt pala bubukmetidak pakai"
- "1/4 sdt jinten"
- "2 butir kemiri"
- "1 cm jahe"
- "1 cm kunyittambahan dari saya"
- "2 butir kemiri"
- "1 sdt garam"
- "1/2 sdt gula pasir tambahan dari saya"
- "1 sdt kaldu bubuk tambahan dari saya"
recipeinstructions:
- "Cuci bersih ayam. Potong-potong ayam fillet bentuk dadu."
- "Haluskan bumbu-bumbu yang termasuk dalam bumbu halus. Iris bawang bombay. Lalu tumis hingga harum. Masukkan kapulaga, pekak, daun jeruk, daun salam, daun kunyit, serai geprek, kayu manis dan lengkuas geprek. Tumis hingga layu."
- "Masukkan ayam fillet, telur rebus dan air. Aduk-aduk. Tambahkan santan. Bubuhi garam, gula, kaldu bubuk. Test rasa. Jika ayam sudah matang, matikan api. Sajikan."
categories:
- Resep
tags:
- opor
- ayam
- tanpa

katakunci: opor ayam tanpa 
nutrition: 271 calories
recipecuisine: Indonesian
preptime: "PT18M"
cooktime: "PT34M"
recipeyield: "4"
recipecategory: Dinner

---


![Opor Ayam Tanpa Tulang Bumbu Rempah](https://img-global.cpcdn.com/recipes/e67db22f79d7268d/680x482cq70/opor-ayam-tanpa-tulang-bumbu-rempah-foto-resep-utama.jpg)

Selaku seorang ibu, menyediakan hidangan nikmat untuk keluarga adalah hal yang menggembirakan bagi kamu sendiri. Tanggung jawab seorang istri bukan sekadar mengatur rumah saja, tapi anda juga wajib memastikan kebutuhan nutrisi tercukupi dan juga masakan yang disantap keluarga tercinta mesti menggugah selera.

Di masa  saat ini, kamu sebenarnya mampu memesan masakan siap saji meski tanpa harus capek memasaknya dahulu. Tetapi ada juga lho mereka yang selalu mau memberikan hidangan yang terbaik untuk orang tercintanya. Pasalnya, menyajikan masakan yang diolah sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan hidangan tersebut berdasarkan makanan kesukaan orang tercinta. 



Apakah anda salah satu penikmat opor ayam tanpa tulang bumbu rempah?. Tahukah kamu, opor ayam tanpa tulang bumbu rempah adalah makanan khas di Nusantara yang saat ini disukai oleh setiap orang di hampir setiap tempat di Indonesia. Anda bisa menyajikan opor ayam tanpa tulang bumbu rempah sendiri di rumah dan dapat dijadikan makanan favoritmu di hari libur.

Kamu jangan bingung jika kamu ingin menyantap opor ayam tanpa tulang bumbu rempah, lantaran opor ayam tanpa tulang bumbu rempah tidak sulit untuk didapatkan dan juga kalian pun dapat menghidangkannya sendiri di tempatmu. opor ayam tanpa tulang bumbu rempah bisa diolah dengan beraneka cara. Sekarang sudah banyak resep kekinian yang menjadikan opor ayam tanpa tulang bumbu rempah semakin lebih lezat.

Resep opor ayam tanpa tulang bumbu rempah juga gampang sekali untuk dibikin, lho. Kamu tidak perlu repot-repot untuk membeli opor ayam tanpa tulang bumbu rempah, tetapi Kita dapat menghidangkan di rumah sendiri. Untuk Kamu yang hendak menyajikannya, inilah cara menyajikan opor ayam tanpa tulang bumbu rempah yang enak yang dapat Kita coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Opor Ayam Tanpa Tulang Bumbu Rempah:

1. Sediakan 1/2 kg ayam. (me:400 gr ayam fillet)
1. Gunakan 3 buah tahu (me:4 telur rebus)
1. Siapkan 1 bungkus santan kara dilarutkan segelas air
1. Gunakan 700 ml air
1. Ambil 2 lembar daun salam
1. Gunakan 2 lembar daun jeruk
1. Ambil 2 buah kapulaga
1. Ambil 2 buah pekak
1. Sediakan 5 cm kayu manis (me:½sdt bubuk kayu manis)
1. Gunakan 1 batang serai geprek
1. Ambil 1/2 bawang bombay kecil
1. Sediakan 1 lembar daun kunyit (tambahan dari saya)
1. Ambil 1 ruas lengkuas geprek(tambahan dari saya)
1. Sediakan  Bumbu halus:
1. Sediakan 4 siung bawang merah
1. Ambil 4 siung bawang putih
1. Ambil 1/2 sdt ketumbar
1. Siapkan 8 butir merica (me:1sdt merica bubuk)
1. Ambil 1/4 sdt pala bubuk(me:tidak pakai)
1. Siapkan 1/4 sdt jinten
1. Sediakan 2 butir kemiri
1. Ambil 1 cm jahe
1. Gunakan 1 cm kunyit(tambahan dari saya)
1. Gunakan 2 butir kemiri
1. Gunakan 1 sdt garam
1. Sediakan 1/2 sdt gula pasir (tambahan dari saya)
1. Sediakan 1 sdt kaldu bubuk (tambahan dari saya)




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Opor Ayam Tanpa Tulang Bumbu Rempah:

1. Cuci bersih ayam. Potong-potong ayam fillet bentuk dadu.
1. Haluskan bumbu-bumbu yang termasuk dalam bumbu halus. Iris bawang bombay. Lalu tumis hingga harum. Masukkan kapulaga, pekak, daun jeruk, daun salam, daun kunyit, serai geprek, kayu manis dan lengkuas geprek. Tumis hingga layu.
1. Masukkan ayam fillet, telur rebus dan air. Aduk-aduk. Tambahkan santan. Bubuhi garam, gula, kaldu bubuk. Test rasa. Jika ayam sudah matang, matikan api. Sajikan.




Wah ternyata cara membuat opor ayam tanpa tulang bumbu rempah yang nikamt tidak rumit ini enteng banget ya! Kita semua bisa membuatnya. Cara Membuat opor ayam tanpa tulang bumbu rempah Cocok sekali untuk kamu yang sedang belajar memasak ataupun untuk kalian yang sudah pandai dalam memasak.

Tertarik untuk mulai mencoba membuat resep opor ayam tanpa tulang bumbu rempah lezat tidak ribet ini? Kalau kalian tertarik, yuk kita segera siapkan alat dan bahannya, lantas buat deh Resep opor ayam tanpa tulang bumbu rempah yang enak dan tidak ribet ini. Sangat mudah kan. 

Maka dari itu, daripada kamu berlama-lama, yuk kita langsung saja sajikan resep opor ayam tanpa tulang bumbu rempah ini. Pasti kalian gak akan nyesel sudah bikin resep opor ayam tanpa tulang bumbu rempah nikmat tidak ribet ini! Selamat berkreasi dengan resep opor ayam tanpa tulang bumbu rempah nikmat simple ini di tempat tinggal sendiri,ya!.

