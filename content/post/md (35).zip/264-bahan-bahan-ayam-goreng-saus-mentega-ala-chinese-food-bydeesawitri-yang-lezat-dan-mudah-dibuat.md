---
description: "Bahan-bahan Ayam Goreng Saus Mentega (ala chinese food) bydeesawitri yang lezat dan Mudah Dibuat"
title: "Bahan-bahan Ayam Goreng Saus Mentega (ala chinese food) bydeesawitri yang lezat dan Mudah Dibuat"
slug: 264-bahan-bahan-ayam-goreng-saus-mentega-ala-chinese-food-bydeesawitri-yang-lezat-dan-mudah-dibuat
date: 2021-05-07T18:19:34.157Z
image: https://img-global.cpcdn.com/recipes/63c9304f1ca25d8c/680x482cq70/ayam-goreng-saus-mentega-ala-chinese-food-bydeesawitri-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/63c9304f1ca25d8c/680x482cq70/ayam-goreng-saus-mentega-ala-chinese-food-bydeesawitri-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/63c9304f1ca25d8c/680x482cq70/ayam-goreng-saus-mentega-ala-chinese-food-bydeesawitri-foto-resep-utama.jpg
author: Madge Wheeler
ratingvalue: 4.6
reviewcount: 3
recipeingredient:
- " Bahan marinasi"
- "1/4 kg ayam potong kecil2 me  jdi 18 potong"
- "1 bawang putih paruthaluskan"
- "1 sdt garam"
- "1/2 sdt lada bubuk"
- " Bahan untuk menggoreng ayam"
- "1 telur"
- "3 sdm tepung bumbu me  kobe"
- "6 sdm tepung terigu me segitiga biru"
- "2 sdm maizena"
- " Bahan saus mentega"
- "5 sdm kecap inggirs me  asia harum sedap"
- "1 sdm saus tiram"
- "1 sdm kecap manis"
- "1 sdm saus tomat"
- "1 sdm gula pasir"
- "1/2 sdt totole boleh diskip"
- "1 sdm munjung mentega"
- " Bumbu Tumis"
- "1 sdm mentega"
- "1/2 bawang bombai potong tebal"
- " Bahan sambel korek"
- "1 cabai keriting"
- "5 cabai rawit"
- "1 bawang putih"
- "1/2 sdt garam"
- "2 sdm minyak panas ambil saat menggoreng ayam"
recipeinstructions:
- "Mari siapkan ayam : cuci bersih ayam, campur dengan bahan marinasi (tanpa air). Diamkan 15 menit di kulkas (bukan freezer). Sembari menunggu, haluskan semua bahan sambal korek."
- "Yuk gorenng ayamnya : Campur rata bahan tepung, ambil ayam dr bumbu marinasi (tidak perlu dicuci/dibilas air). Celupkan ke kocokan telur, masukkan ke tepung kering, campur sampai terbalut tepung. Goreng dengan minyak panas (api sedang) sampai kecoklatan. Sisihkan. Jangan lupa ambil 2 sdm untuk sambal."
- "Siapkan saus mentega : campur semua bahan saus mentega (kecuali mentega). Aduk rata, sisihkan."
- "Tumis bawang bombai dengan mentega sampai harum. Masukkan campuran saus, aduk rata dan tunggu sampai meletup-letup. Masukkan mentega, aduk smpai mencair dan tercampur rata."
- "Masukkan ayam goreng, aduk sampai merata. Tunggu sebentar. Angkat deh. Selamat menikmati ya 🤤"
categories:
- Resep
tags:
- ayam
- goreng
- saus

katakunci: ayam goreng saus 
nutrition: 250 calories
recipecuisine: Indonesian
preptime: "PT34M"
cooktime: "PT57M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Goreng Saus Mentega (ala chinese food) bydeesawitri](https://img-global.cpcdn.com/recipes/63c9304f1ca25d8c/680x482cq70/ayam-goreng-saus-mentega-ala-chinese-food-bydeesawitri-foto-resep-utama.jpg)

Apabila kalian seorang yang hobi masak, mempersiapkan santapan lezat bagi famili adalah suatu hal yang mengasyikan bagi anda sendiri. Tanggung jawab seorang ibu Tidak hanya menjaga rumah saja, tapi kamu juga wajib memastikan kebutuhan gizi terpenuhi dan hidangan yang dimakan anak-anak mesti menggugah selera.

Di masa  saat ini, kalian memang dapat membeli hidangan siap saji meski tanpa harus susah membuatnya dahulu. Tetapi ada juga lho mereka yang memang mau memberikan hidangan yang terbaik bagi orang tercintanya. Pasalnya, menghidangkan masakan yang diolah sendiri jauh lebih higienis dan kita juga bisa menyesuaikan masakan tersebut berdasarkan masakan kesukaan famili. 



Mungkinkah anda seorang penggemar ayam goreng saus mentega (ala chinese food) bydeesawitri?. Tahukah kamu, ayam goreng saus mentega (ala chinese food) bydeesawitri merupakan makanan khas di Indonesia yang sekarang digemari oleh orang-orang di berbagai wilayah di Indonesia. Kita dapat menyajikan ayam goreng saus mentega (ala chinese food) bydeesawitri hasil sendiri di rumah dan pasti jadi makanan favorit di hari libur.

Kita tidak usah bingung untuk mendapatkan ayam goreng saus mentega (ala chinese food) bydeesawitri, sebab ayam goreng saus mentega (ala chinese food) bydeesawitri tidak sukar untuk ditemukan dan juga kalian pun dapat mengolahnya sendiri di rumah. ayam goreng saus mentega (ala chinese food) bydeesawitri dapat dimasak dengan beragam cara. Sekarang telah banyak sekali cara kekinian yang membuat ayam goreng saus mentega (ala chinese food) bydeesawitri semakin enak.

Resep ayam goreng saus mentega (ala chinese food) bydeesawitri juga gampang dihidangkan, lho. Anda jangan repot-repot untuk membeli ayam goreng saus mentega (ala chinese food) bydeesawitri, karena Kita bisa menyajikan di rumah sendiri. Untuk Kita yang hendak menyajikannya, inilah resep untuk membuat ayam goreng saus mentega (ala chinese food) bydeesawitri yang lezat yang mampu Kita buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Ayam Goreng Saus Mentega (ala chinese food) bydeesawitri:

1. Siapkan  Bahan marinasi
1. Gunakan 1/4 kg ayam, potong kecil2 (me : jdi 18 potong)
1. Sediakan 1 bawang putih, parut/haluskan
1. Ambil 1 sdt garam
1. Sediakan 1/2 sdt lada bubuk
1. Ambil  Bahan untuk menggoreng ayam
1. Sediakan 1 telur
1. Siapkan 3 sdm tepung bumbu (me : kobe)
1. Sediakan 6 sdm tepung terigu (me: segitiga biru)
1. Ambil 2 sdm maizena
1. Sediakan  Bahan saus mentega
1. Ambil 5 sdm kecap inggirs (me : asia harum sedap)
1. Gunakan 1 sdm saus tiram
1. Siapkan 1 sdm kecap manis
1. Ambil 1 sdm saus tomat
1. Ambil 1 sdm gula pasir
1. Siapkan 1/2 sdt totole (boleh diskip)
1. Siapkan 1 sdm (munjung) mentega
1. Siapkan  Bumbu Tumis
1. Siapkan 1 sdm mentega
1. Siapkan 1/2 bawang bombai, potong tebal
1. Gunakan  Bahan sambel korek
1. Gunakan 1 cabai keriting
1. Sediakan 5 cabai rawit
1. Gunakan 1 bawang putih
1. Sediakan 1/2 sdt garam
1. Siapkan 2 sdm minyak panas (ambil saat menggoreng ayam)




<!--inarticleads2-->

##### Cara membuat Ayam Goreng Saus Mentega (ala chinese food) bydeesawitri:

1. Mari siapkan ayam : cuci bersih ayam, campur dengan bahan marinasi (tanpa air). Diamkan 15 menit di kulkas (bukan freezer). Sembari menunggu, haluskan semua bahan sambal korek.
1. Yuk gorenng ayamnya : Campur rata bahan tepung, ambil ayam dr bumbu marinasi (tidak perlu dicuci/dibilas air). Celupkan ke kocokan telur, masukkan ke tepung kering, campur sampai terbalut tepung. Goreng dengan minyak panas (api sedang) sampai kecoklatan. Sisihkan. Jangan lupa ambil 2 sdm untuk sambal.
1. Siapkan saus mentega : campur semua bahan saus mentega (kecuali mentega). Aduk rata, sisihkan.
1. Tumis bawang bombai dengan mentega sampai harum. Masukkan campuran saus, aduk rata dan tunggu sampai meletup-letup. Masukkan mentega, aduk smpai mencair dan tercampur rata.
1. Masukkan ayam goreng, aduk sampai merata. Tunggu sebentar. Angkat deh. Selamat menikmati ya 🤤




Wah ternyata cara buat ayam goreng saus mentega (ala chinese food) bydeesawitri yang lezat tidak rumit ini enteng sekali ya! Kita semua dapat membuatnya. Cara buat ayam goreng saus mentega (ala chinese food) bydeesawitri Sangat cocok sekali buat kamu yang baru mau belajar memasak atau juga bagi kamu yang sudah ahli memasak.

Tertarik untuk mulai mencoba bikin resep ayam goreng saus mentega (ala chinese food) bydeesawitri mantab simple ini? Kalau kalian ingin, ayo kalian segera siapkan peralatan dan bahan-bahannya, maka buat deh Resep ayam goreng saus mentega (ala chinese food) bydeesawitri yang lezat dan simple ini. Sungguh gampang kan. 

Maka, daripada anda berlama-lama, ayo kita langsung sajikan resep ayam goreng saus mentega (ala chinese food) bydeesawitri ini. Pasti kamu tiidak akan nyesel sudah membuat resep ayam goreng saus mentega (ala chinese food) bydeesawitri lezat tidak rumit ini! Selamat mencoba dengan resep ayam goreng saus mentega (ala chinese food) bydeesawitri enak tidak rumit ini di tempat tinggal kalian masing-masing,oke!.

