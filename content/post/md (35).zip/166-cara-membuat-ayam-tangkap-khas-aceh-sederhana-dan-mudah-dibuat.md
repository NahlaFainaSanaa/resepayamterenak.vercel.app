---
description: "Cara membuat Ayam Tangkap Khas Aceh Sederhana dan Mudah Dibuat"
title: "Cara membuat Ayam Tangkap Khas Aceh Sederhana dan Mudah Dibuat"
slug: 166-cara-membuat-ayam-tangkap-khas-aceh-sederhana-dan-mudah-dibuat
date: 2021-01-30T15:03:37.885Z
image: https://img-global.cpcdn.com/recipes/b9c7eb78531a3d66/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b9c7eb78531a3d66/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b9c7eb78531a3d66/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg
author: Alvin Austin
ratingvalue: 4.6
reviewcount: 9
recipeingredient:
- "1/2 ekor ayam kampung"
- "1 lembar daun pandan potongpotong"
- "2 cm Lengkuas"
- "2 lembar daun salam Koja atau Daun Kari"
- "1 batang sereh"
- "Secukupnya air matang"
- " Bumbu Halus"
- "2 cm jahe"
- "2 cm kunyit"
- "4 siung bawang putih"
- "1 sdt ketumbar"
- "1 sdt lada utuh"
- "Secukupnya Garam sesuai selera"
- "Secukupnya gula pasir sesuai selera"
- " Bahan pelengkap lainnya"
- "1 batang serai memarkan dan potongpotong"
- "3 lembar daun pandan yg besar potong2"
- "3 buah bawang merah rajang halus"
- "4 lembar daun Kari"
- "5 lembar daun jeruk"
- "7 Buah Cabe hijau"
- " Minyak goreng untuk menggoreng ayam"
recipeinstructions:
- "Cuci bersih ayam kampung, kemudian potong2 sesuai selera, beri perasan air jeruk lemon diamkan berberapa saat. Kemudian pindahkan ke panci atau wajan (tiriskan dari air yg tersisa) masukan Lengkuas, daun pandan, daun Kari Dan sereh yg sdh di potong2"
- "Siapkan bumbu yg akan dihaluskan. Kemudian haluskan dengan di ulek atau di blender (sesuai selera saja), jangan lupa tambahkan Garam, ulek hingga halus."
- "Masukkan bumbu halus kedalam wajan yg berisi ayam tadi, kemudian tambahkan air secukupnya (sampai ayam terendam) nyalakan api kemudian ungkep ayam hingga matang."
- "Aduk sesekali kemudian tambahkan gula sedikit, koreksi Rasa. Sambil menunggu ayam matang Kita siapkan bumbu pelengkap. Potong2 semua bumbu pelengkap, kemudian sisihkan."
- "Setelah ayam matang, matikan api. Kemudian siapkan wajan Dan minyak Siapkan minyak goreng dan bumbu pelengkap. Goreng ayam ungkep bersama dengan bumbu pelengkap. Goreng hingga matang kecokelatan, sesekali di Balik."
- "Angkat siap disajikan 😉🙏"
categories:
- Resep
tags:
- ayam
- tangkap
- khas

katakunci: ayam tangkap khas 
nutrition: 277 calories
recipecuisine: Indonesian
preptime: "PT21M"
cooktime: "PT48M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Tangkap Khas Aceh](https://img-global.cpcdn.com/recipes/b9c7eb78531a3d66/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg)

Selaku seorang istri, mempersiapkan olahan lezat kepada orang tercinta merupakan suatu hal yang menyenangkan untuk anda sendiri. Tugas seorang  wanita bukan hanya mengerjakan pekerjaan rumah saja, tetapi kamu juga harus memastikan keperluan nutrisi tercukupi dan panganan yang dikonsumsi anak-anak mesti menggugah selera.

Di masa  sekarang, kita sebenarnya bisa memesan hidangan yang sudah jadi walaupun tidak harus ribet mengolahnya lebih dulu. Namun ada juga lho mereka yang selalu ingin memberikan makanan yang terenak untuk keluarganya. Pasalnya, menghidangkan masakan sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan berdasarkan kesukaan orang tercinta. 



Mungkinkah anda merupakan seorang penggemar ayam tangkap khas aceh?. Tahukah kamu, ayam tangkap khas aceh adalah makanan khas di Indonesia yang kini disenangi oleh banyak orang dari hampir setiap tempat di Nusantara. Kita dapat menyajikan ayam tangkap khas aceh sendiri di rumah dan boleh jadi makanan kegemaranmu di hari libur.

Anda tak perlu bingung untuk menyantap ayam tangkap khas aceh, sebab ayam tangkap khas aceh sangat mudah untuk ditemukan dan kamu pun boleh menghidangkannya sendiri di tempatmu. ayam tangkap khas aceh boleh dimasak memalui beragam cara. Kini sudah banyak cara modern yang membuat ayam tangkap khas aceh semakin lebih mantap.

Resep ayam tangkap khas aceh juga gampang untuk dibikin, lho. Kamu jangan repot-repot untuk membeli ayam tangkap khas aceh, tetapi Kalian dapat menghidangkan di rumahmu. Bagi Kalian yang hendak menghidangkannya, dibawah ini merupakan resep untuk membuat ayam tangkap khas aceh yang lezat yang dapat Kalian coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Ayam Tangkap Khas Aceh:

1. Sediakan 1/2 ekor ayam kampung
1. Gunakan 1 lembar daun pandan, potong-potong
1. Sediakan 2 cm Lengkuas
1. Ambil 2 lembar daun salam Koja atau Daun Kari
1. Ambil 1 batang sereh
1. Ambil Secukupnya air matang
1. Sediakan  Bumbu Halus
1. Siapkan 2 cm jahe
1. Ambil 2 cm kunyit
1. Siapkan 4 siung bawang putih
1. Gunakan 1 sdt ketumbar
1. Ambil 1 sdt lada utuh
1. Siapkan Secukupnya Garam (sesuai selera)
1. Ambil Secukupnya gula pasir (sesuai selera)
1. Siapkan  Bahan pelengkap lainnya
1. Siapkan 1 batang serai, memarkan dan potong-potong
1. Siapkan 3 lembar daun pandan yg besar potong2
1. Siapkan 3 buah bawang merah rajang halus
1. Gunakan 4 lembar daun Kari
1. Ambil 5 lembar daun jeruk
1. Gunakan 7 Buah Cabe hijau
1. Gunakan  Minyak goreng untuk menggoreng ayam




<!--inarticleads2-->

##### Cara menyiapkan Ayam Tangkap Khas Aceh:

1. Cuci bersih ayam kampung, kemudian potong2 sesuai selera, beri perasan air jeruk lemon diamkan berberapa saat. Kemudian pindahkan ke panci atau wajan (tiriskan dari air yg tersisa) masukan Lengkuas, daun pandan, daun Kari Dan sereh yg sdh di potong2
1. Siapkan bumbu yg akan dihaluskan. Kemudian haluskan dengan di ulek atau di blender (sesuai selera saja), jangan lupa tambahkan Garam, ulek hingga halus.
1. Masukkan bumbu halus kedalam wajan yg berisi ayam tadi, kemudian tambahkan air secukupnya (sampai ayam terendam) nyalakan api kemudian ungkep ayam hingga matang.
1. Aduk sesekali kemudian tambahkan gula sedikit, koreksi Rasa. Sambil menunggu ayam matang Kita siapkan bumbu pelengkap. Potong2 semua bumbu pelengkap, kemudian sisihkan.
1. Setelah ayam matang, matikan api. Kemudian siapkan wajan Dan minyak Siapkan minyak goreng dan bumbu pelengkap. Goreng ayam ungkep bersama dengan bumbu pelengkap. Goreng hingga matang kecokelatan, sesekali di Balik.
1. Angkat siap disajikan 😉🙏




Wah ternyata cara buat ayam tangkap khas aceh yang lezat sederhana ini enteng sekali ya! Anda Semua mampu menghidangkannya. Cara Membuat ayam tangkap khas aceh Sangat cocok sekali untuk anda yang baru mau belajar memasak atau juga bagi anda yang telah jago dalam memasak.

Tertarik untuk mulai mencoba bikin resep ayam tangkap khas aceh mantab sederhana ini? Kalau anda ingin, ayo kamu segera buruan siapin alat dan bahan-bahannya, lalu buat deh Resep ayam tangkap khas aceh yang mantab dan sederhana ini. Benar-benar mudah kan. 

Maka, daripada kalian berlama-lama, yuk langsung aja bikin resep ayam tangkap khas aceh ini. Pasti anda tak akan menyesal sudah buat resep ayam tangkap khas aceh mantab sederhana ini! Selamat berkreasi dengan resep ayam tangkap khas aceh mantab sederhana ini di rumah kalian masing-masing,oke!.

