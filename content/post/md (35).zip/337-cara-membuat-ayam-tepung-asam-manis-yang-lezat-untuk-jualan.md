---
description: "Cara membuat Ayam tepung asam manis yang lezat Untuk Jualan"
title: "Cara membuat Ayam tepung asam manis yang lezat Untuk Jualan"
slug: 337-cara-membuat-ayam-tepung-asam-manis-yang-lezat-untuk-jualan
date: 2021-05-04T07:30:42.823Z
image: https://img-global.cpcdn.com/recipes/d28511a4b72f33a8/680x482cq70/ayam-tepung-asam-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d28511a4b72f33a8/680x482cq70/ayam-tepung-asam-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d28511a4b72f33a8/680x482cq70/ayam-tepung-asam-manis-foto-resep-utama.jpg
author: Kevin Christensen
ratingvalue: 3.2
reviewcount: 9
recipeingredient:
- "300 gr dada ayam filletpotong dadu"
- "4 sdm tepung maizena"
- " Bahan asam manis"
- "3 siung bawang putihiris"
- "1/2 siung bawang bombayiris"
- "3 buah cabe merahiris serong"
- "1 buah wortel ukuran kecil 12 besarpotong korek api"
- "4 sdm saos sambal"
- "4 sdm saso tomat"
- "1 sdt garam"
- "1/2 sdt merica"
- "1 sdt gula"
- "1 sdm kaldu jamur optional"
- "50 ml air"
- "75 ml larutan maizena 1 sdm tepung75 ml air"
recipeinstructions:
- "Baluri ayam yang sudah dipotong dadu dengan maizena,lalu goreng dengan minyak panas hingga kuning keemasan,angkat dan sisihkan"
- "Panaskan minyak,lalu tumis bawang putih +bawang bombay hingga wangi"
- "Masukkan cabe,tumis hingga agak layu"
- "Masukkan air+saos sambal+saos tomat,aduk rata."
- "Masukkan garam+merica+gula+kaldu jamur+wortel,masak hingga mendidih"
- "Masukkan larutan maizena,masak hingga agak mengental,lalu masukkan ayam,aduk rata,angkat dan siap disajikan"
categories:
- Resep
tags:
- ayam
- tepung
- asam

katakunci: ayam tepung asam 
nutrition: 129 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT59M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam tepung asam manis](https://img-global.cpcdn.com/recipes/d28511a4b72f33a8/680x482cq70/ayam-tepung-asam-manis-foto-resep-utama.jpg)

Sebagai seorang orang tua, menyediakan masakan mantab bagi keluarga merupakan hal yang membahagiakan untuk anda sendiri. Tugas seorang ibu Tidak sekedar menjaga rumah saja, tetapi kamu juga wajib menyediakan kebutuhan nutrisi tercukupi dan olahan yang dimakan orang tercinta wajib mantab.

Di era  saat ini, anda memang mampu memesan panganan jadi meski tanpa harus ribet memasaknya dulu. Namun banyak juga lho orang yang memang mau memberikan hidangan yang terenak untuk keluarganya. Lantaran, menghidangkan masakan yang diolah sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan makanan tersebut sesuai masakan kesukaan famili. 



Apakah anda salah satu penggemar ayam tepung asam manis?. Asal kamu tahu, ayam tepung asam manis merupakan hidangan khas di Nusantara yang saat ini digemari oleh kebanyakan orang di hampir setiap wilayah di Indonesia. Kamu bisa membuat ayam tepung asam manis sendiri di rumah dan dapat dijadikan santapan kesenanganmu di hari liburmu.

Anda tidak usah bingung jika kamu ingin menyantap ayam tepung asam manis, sebab ayam tepung asam manis sangat mudah untuk didapatkan dan juga anda pun bisa mengolahnya sendiri di tempatmu. ayam tepung asam manis bisa diolah lewat bermacam cara. Kini telah banyak sekali cara kekinian yang menjadikan ayam tepung asam manis lebih enak.

Resep ayam tepung asam manis juga mudah sekali untuk dibikin, lho. Kalian tidak usah capek-capek untuk membeli ayam tepung asam manis, lantaran Kalian bisa menghidangkan di rumahmu. Untuk Kamu yang hendak menghidangkannya, dibawah ini merupakan resep untuk membuat ayam tepung asam manis yang enak yang bisa Kalian hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Ayam tepung asam manis:

1. Sediakan 300 gr dada ayam fillet,potong dadu
1. Siapkan 4 sdm tepung maizena
1. Gunakan  Bahan asam manis:
1. Sediakan 3 siung bawang putih,iris
1. Sediakan 1/2 siung bawang bombay,iris
1. Sediakan 3 buah cabe merah,iris serong
1. Gunakan 1 buah wortel ukuran kecil (1/2 besar),potong korek api
1. Sediakan 4 sdm saos sambal
1. Sediakan 4 sdm saso tomat
1. Siapkan 1 sdt garam
1. Siapkan 1/2 sdt merica
1. Sediakan 1 sdt gula
1. Ambil 1 sdm kaldu jamur (optional)
1. Siapkan 50 ml air
1. Ambil 75 ml larutan maizena (1 sdm tepung,75 ml air)




<!--inarticleads2-->

##### Cara membuat Ayam tepung asam manis:

1. Baluri ayam yang sudah dipotong dadu dengan maizena,lalu goreng dengan minyak panas hingga kuning keemasan,angkat dan sisihkan
1. Panaskan minyak,lalu tumis bawang putih +bawang bombay hingga wangi
1. Masukkan cabe,tumis hingga agak layu
1. Masukkan air+saos sambal+saos tomat,aduk rata.
1. Masukkan garam+merica+gula+kaldu jamur+wortel,masak hingga mendidih
1. Masukkan larutan maizena,masak hingga agak mengental,lalu masukkan ayam,aduk rata,angkat dan siap disajikan




Wah ternyata resep ayam tepung asam manis yang lezat tidak rumit ini enteng banget ya! Kita semua mampu membuatnya. Cara buat ayam tepung asam manis Sangat sesuai banget untuk kita yang baru mau belajar memasak ataupun juga untuk kalian yang sudah pandai memasak.

Apakah kamu mau mencoba bikin resep ayam tepung asam manis lezat tidak rumit ini? Kalau kalian ingin, ayo kalian segera menyiapkan alat-alat dan bahan-bahannya, lantas bikin deh Resep ayam tepung asam manis yang nikmat dan sederhana ini. Sangat taidak sulit kan. 

Maka dari itu, daripada kamu diam saja, yuk kita langsung saja hidangkan resep ayam tepung asam manis ini. Pasti kalian tak akan nyesel membuat resep ayam tepung asam manis lezat tidak rumit ini! Selamat berkreasi dengan resep ayam tepung asam manis lezat sederhana ini di rumah kalian sendiri,oke!.

