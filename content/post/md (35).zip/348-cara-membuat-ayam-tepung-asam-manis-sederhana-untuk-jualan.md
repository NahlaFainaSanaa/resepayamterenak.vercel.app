---
description: "Cara membuat Ayam Tepung Asam Manis Sederhana Untuk Jualan"
title: "Cara membuat Ayam Tepung Asam Manis Sederhana Untuk Jualan"
slug: 348-cara-membuat-ayam-tepung-asam-manis-sederhana-untuk-jualan
date: 2021-06-23T02:30:12.647Z
image: https://img-global.cpcdn.com/recipes/4313ee8e1ed0832f/680x482cq70/ayam-tepung-asam-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4313ee8e1ed0832f/680x482cq70/ayam-tepung-asam-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4313ee8e1ed0832f/680x482cq70/ayam-tepung-asam-manis-foto-resep-utama.jpg
author: John Kelly
ratingvalue: 3.3
reviewcount: 15
recipeingredient:
- "1/2 kg dada fillet ayam cuci bersih"
- "1 sachet uk sdang Tepung bumbu kentaki serbagunaaku pakai kobe"
- "secukupnya Lada"
- " Bawang putih bubuk jika tdk ada pakai bawang putih di halus kan"
- " Saus tomat"
- " Saus cabe"
- "1 Bawang bombay 1 biji bawang putih untuk saus"
- " Garam penyedap rasa"
- " Saus tiram"
- " Tepung maizena"
- " Minyak untuk menggoreng"
recipeinstructions:
- "Cuci bersih ayam dada fillet"
- "Lalu potong kecil, ukuran besar jg bisa. Kalo saya ukuran kecil karna di rumah yg makan banyak hehe"
- "Balur ayam dengan bawang putih, lada secukupnya. Tunggu sebentar agar meresap. Kemudian balur dg tepung serba guna yang basah, lalu balur lagi dengan tepung serbaguna kering."
- "Lalu goreng dg minyak panas sampai warna kuning emas."
- "Saat ayam sudah selesai, siapkan bahan saus asam manisny"
- "Cincang halus bawang putih, potong memanjang bawang bombay, lalu panaskan minyak sedikit saja untuk menumis bawang"
- "Tumis bawang putih dg api sedang cenderung kecil. Lalu saat bawang putih 1/2 matang masukan bawang bombay sebentar saja. Lalu masukan saus tomat, saus cabe dan sedikit saus tiram."
- "Tunggu sampai blubuk blubuk, lalu masukan garam, penyedap dan (gula sedikit)"
- "Cicipi rasa, jika sudah pas lalu api kecilkan dan masukan tepung maizena. Aduk hingga mengental."
- "Jika sudah mengental lalu masukan ayam yg sudah digoreng tadi. Lalu ayam saus asam manis siap di hidangkan"
- "Tips : ketika ayam masuk ke tepung balur kering dan akan menggoreng, sebelum masuk minyak sebaiknya di tepuk2 agar tepung kering tdk terlalu banyak di ayam dan tepukan akan membuat tepung menjadi keriting crispi. Tepung maizena sebaiknya di larutkan di air putih dingin agar tdk menggumpal. Bisa tambahkan sayuran wortel. Dan nanas (biar segar)"
categories:
- Resep
tags:
- ayam
- tepung
- asam

katakunci: ayam tepung asam 
nutrition: 235 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT41M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Tepung Asam Manis](https://img-global.cpcdn.com/recipes/4313ee8e1ed0832f/680x482cq70/ayam-tepung-asam-manis-foto-resep-utama.jpg)

Selaku seorang wanita, menyediakan panganan sedap kepada orang tercinta adalah hal yang menggembirakan bagi kita sendiri. Kewajiban seorang  wanita bukan cuma mengatur rumah saja, tapi anda juga wajib memastikan kebutuhan gizi tercukupi dan juga hidangan yang disantap anak-anak harus lezat.

Di waktu  sekarang, kalian sebenarnya dapat membeli masakan praktis tanpa harus susah membuatnya dulu. Tetapi banyak juga orang yang memang mau memberikan hidangan yang terenak untuk orang tercintanya. Sebab, menyajikan masakan sendiri jauh lebih higienis dan kita pun bisa menyesuaikan makanan tersebut sesuai masakan kesukaan orang tercinta. 



Apakah anda merupakan seorang penikmat ayam tepung asam manis?. Tahukah kamu, ayam tepung asam manis adalah makanan khas di Indonesia yang kini disukai oleh banyak orang dari hampir setiap tempat di Nusantara. Kamu bisa membuat ayam tepung asam manis kreasi sendiri di rumahmu dan pasti jadi santapan kesenanganmu di hari libur.

Kita jangan bingung untuk mendapatkan ayam tepung asam manis, karena ayam tepung asam manis gampang untuk dicari dan kita pun boleh mengolahnya sendiri di rumah. ayam tepung asam manis boleh diolah memalui berbagai cara. Sekarang ada banyak resep kekinian yang membuat ayam tepung asam manis semakin lebih lezat.

Resep ayam tepung asam manis pun gampang dibikin, lho. Kamu jangan capek-capek untuk membeli ayam tepung asam manis, lantaran Kita dapat menyajikan di rumah sendiri. Bagi Kamu yang ingin mencobanya, dibawah ini merupakan resep menyajikan ayam tepung asam manis yang mantab yang mampu Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Ayam Tepung Asam Manis:

1. Gunakan 1/2 kg dada fillet ayam (cuci bersih)
1. Ambil 1 sachet uk sdang Tepung bumbu kentaki serbaguna(aku pakai kobe)
1. Gunakan secukupnya Lada
1. Gunakan  Bawang putih bubuk jika tdk ada pakai bawang putih di halus kan
1. Sediakan  Saus tomat
1. Sediakan  Saus cabe
1. Sediakan 1 Bawang bombay, 1 biji bawang putih untuk saus
1. Ambil  Garam, penyedap rasa
1. Ambil  Saus tiram
1. Ambil  Tepung maizena
1. Sediakan  Minyak untuk menggoreng




<!--inarticleads2-->

##### Cara menyiapkan Ayam Tepung Asam Manis:

1. Cuci bersih ayam dada fillet
1. Lalu potong kecil, ukuran besar jg bisa. Kalo saya ukuran kecil karna di rumah yg makan banyak hehe
1. Balur ayam dengan bawang putih, lada secukupnya. Tunggu sebentar agar meresap. Kemudian balur dg tepung serba guna yang basah, lalu balur lagi dengan tepung serbaguna kering.
1. Lalu goreng dg minyak panas sampai warna kuning emas.
1. Saat ayam sudah selesai, siapkan bahan saus asam manisny
1. Cincang halus bawang putih, potong memanjang bawang bombay, lalu panaskan minyak sedikit saja untuk menumis bawang
1. Tumis bawang putih dg api sedang cenderung kecil. Lalu saat bawang putih 1/2 matang masukan bawang bombay sebentar saja. Lalu masukan saus tomat, saus cabe dan sedikit saus tiram.
1. Tunggu sampai blubuk blubuk, lalu masukan garam, penyedap dan (gula sedikit)
1. Cicipi rasa, jika sudah pas lalu api kecilkan dan masukan tepung maizena. Aduk hingga mengental.
1. Jika sudah mengental lalu masukan ayam yg sudah digoreng tadi. Lalu ayam saus asam manis siap di hidangkan
1. Tips : ketika ayam masuk ke tepung balur kering dan akan menggoreng, sebelum masuk minyak sebaiknya di tepuk2 agar tepung kering tdk terlalu banyak di ayam dan tepukan akan membuat tepung menjadi keriting crispi. Tepung maizena sebaiknya di larutkan di air putih dingin agar tdk menggumpal. Bisa tambahkan sayuran wortel. Dan nanas (biar segar)




Ternyata cara membuat ayam tepung asam manis yang lezat tidak rumit ini mudah sekali ya! Anda Semua bisa memasaknya. Cara buat ayam tepung asam manis Cocok banget buat kalian yang baru akan belajar memasak atau juga bagi anda yang telah jago memasak.

Apakah kamu mau mencoba bikin resep ayam tepung asam manis lezat tidak ribet ini? Kalau kamu ingin, ayo kamu segera menyiapkan alat-alat dan bahan-bahannya, lantas bikin deh Resep ayam tepung asam manis yang lezat dan simple ini. Betul-betul gampang kan. 

Jadi, daripada anda berfikir lama-lama, hayo langsung aja buat resep ayam tepung asam manis ini. Dijamin anda tak akan nyesel membuat resep ayam tepung asam manis lezat simple ini! Selamat mencoba dengan resep ayam tepung asam manis nikmat tidak rumit ini di rumah kalian masing-masing,oke!.

