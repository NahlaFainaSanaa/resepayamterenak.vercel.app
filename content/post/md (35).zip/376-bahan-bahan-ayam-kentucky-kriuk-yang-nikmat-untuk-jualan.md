---
description: "Bahan-bahan Ayam Kentucky Kriuk yang nikmat Untuk Jualan"
title: "Bahan-bahan Ayam Kentucky Kriuk yang nikmat Untuk Jualan"
slug: 376-bahan-bahan-ayam-kentucky-kriuk-yang-nikmat-untuk-jualan
date: 2021-06-24T07:40:17.220Z
image: https://img-global.cpcdn.com/recipes/3e4eef1b2c0c7b77/680x482cq70/ayam-kentucky-kriuk-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/3e4eef1b2c0c7b77/680x482cq70/ayam-kentucky-kriuk-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/3e4eef1b2c0c7b77/680x482cq70/ayam-kentucky-kriuk-foto-resep-utama.jpg
author: Ola Stokes
ratingvalue: 3.2
reviewcount: 3
recipeingredient:
- "1 kg Ayam bagian paha"
- "1 butir telur tambahkan garam sejumput dan kocok lepas"
- "250 ml air dingin"
- "1 sdt Baking soda"
- " Minyak untuk menggoreng"
- " BUMBU MARINASI "
- "10 siung Bawang putih"
- "1 sdt Merica butiran"
- "1 ruas Jahe"
- "2 blok Kaldu Ayam merk Maggi"
- "1 sdt Garam"
- "1/2 sdt Ketumbar optional"
- "3 buah Cabe merah optional"
- "1 ruas Kunyit optional"
- "2 sdt Cabe bubuk"
- " BAHAN PELAPIS "
- "450 gr Terigu Cakra Kembar"
- "150 gr Maizena"
- "2 sdt Cabe bubuk optional"
- "1 sdt Oregano optional"
- "1 sdt Lada bubuk optional"
- "secukupnya Garam dan kaldu bubuk"
recipeinstructions:
- "Cuci ayam hingga bersih. Haluskan bumbu marinasi. Lalu marinasi ayam dengan bumbu marinasi aduk rata lalu simpan dikulkas semalaman. Atau minimal 3 jam."
- "Campur semua bahan pelapis dan aduk rata. Tingkat keasinan sesuai selera ya. Kemudian kita buat Bahan Pencelup : ambil 5 sdm bahan pelapis tambahkan baking soda dan air dingin. Simpan di kulkas agar tepung bisa menempel sempurna."
- "Panaskan minyak dengan api kecil. Saya menggunakan panci agar ayam nanti terendam dengan sempurna."
- "Ambil adonan pencelup tambahkan kocokan telur. Ambil ayam masukan dalam adonan pencelup hingga ayam terendam semua masukan adonan pelapis. Saya 2x pencelupan dan pelapis agar lebig tebal dan kriuk."
- "Cubit² ayam ya agar ayam jadi kribo. Hentakan ayam dibaskom agar tidak banyak tepung yang masuk kedalam minyak. Goreng hingga matang dan berubah warna. Kemudian angkat dan tiriskan."
- "Note : pastikan saat hendak menggoreng lalukan point ke 4 agar adonan tidak menunggu sehingga jadi keras dan tidak kriuk. Siap disajikan dengan saos atau sambal dadak. Selamat Mencoba."
categories:
- Resep
tags:
- ayam
- kentucky
- kriuk

katakunci: ayam kentucky kriuk 
nutrition: 260 calories
recipecuisine: Indonesian
preptime: "PT40M"
cooktime: "PT53M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Kentucky Kriuk](https://img-global.cpcdn.com/recipes/3e4eef1b2c0c7b77/680x482cq70/ayam-kentucky-kriuk-foto-resep-utama.jpg)

Sebagai seorang istri, menyajikan santapan sedap kepada keluarga adalah hal yang menggembirakan bagi kita sendiri. Peran seorang ibu bukan hanya mengerjakan pekerjaan rumah saja, tapi kamu pun harus menyediakan kebutuhan gizi terpenuhi dan hidangan yang disantap anak-anak wajib sedap.

Di waktu  sekarang, kita sebenarnya dapat mengorder panganan instan tidak harus susah memasaknya dulu. Tapi ada juga mereka yang selalu ingin memberikan makanan yang terlezat untuk orang yang dicintainya. Karena, menyajikan masakan yang dibuat sendiri jauh lebih bersih dan kita juga bisa menyesuaikan masakan tersebut berdasarkan makanan kesukaan orang tercinta. 



Apakah anda merupakan seorang penikmat ayam kentucky kriuk?. Asal kamu tahu, ayam kentucky kriuk adalah hidangan khas di Nusantara yang sekarang digemari oleh setiap orang di hampir setiap tempat di Indonesia. Kamu dapat membuat ayam kentucky kriuk buatan sendiri di rumahmu dan dapat dijadikan santapan favoritmu di hari libur.

Kalian tidak perlu bingung untuk memakan ayam kentucky kriuk, lantaran ayam kentucky kriuk tidak sukar untuk ditemukan dan juga kamu pun boleh memasaknya sendiri di rumah. ayam kentucky kriuk bisa diolah lewat berbagai cara. Kini ada banyak banget cara kekinian yang membuat ayam kentucky kriuk lebih nikmat.

Resep ayam kentucky kriuk juga mudah untuk dibuat, lho. Kita jangan ribet-ribet untuk membeli ayam kentucky kriuk, sebab Kalian mampu membuatnya di rumah sendiri. Bagi Kalian yang ingin membuatnya, berikut resep untuk menyajikan ayam kentucky kriuk yang enak yang dapat Kamu hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Ayam Kentucky Kriuk:

1. Gunakan 1 kg Ayam bagian paha
1. Siapkan 1 butir telur tambahkan garam sejumput dan kocok lepas
1. Siapkan 250 ml air dingin
1. Siapkan 1 sdt Baking soda
1. Ambil  Minyak untuk menggoreng
1. Siapkan  BUMBU MARINASI :
1. Gunakan 10 siung Bawang putih
1. Siapkan 1 sdt Merica butiran
1. Sediakan 1 ruas Jahe
1. Ambil 2 blok Kaldu Ayam merk Maggi
1. Ambil 1 sdt Garam
1. Ambil 1/2 sdt Ketumbar (optional)
1. Ambil 3 buah Cabe merah (optional)
1. Ambil 1 ruas Kunyit (optional)
1. Ambil 2 sdt Cabe bubuk
1. Ambil  BAHAN PELAPIS :
1. Gunakan 450 gr Terigu Cakra Kembar
1. Sediakan 150 gr Maizena
1. Sediakan 2 sdt Cabe bubuk (optional)
1. Gunakan 1 sdt Oregano (optional)
1. Siapkan 1 sdt Lada bubuk (optional)
1. Ambil secukupnya Garam dan kaldu bubuk




<!--inarticleads2-->

##### Cara membuat Ayam Kentucky Kriuk:

1. Cuci ayam hingga bersih. Haluskan bumbu marinasi. Lalu marinasi ayam dengan bumbu marinasi aduk rata lalu simpan dikulkas semalaman. Atau minimal 3 jam.
1. Campur semua bahan pelapis dan aduk rata. Tingkat keasinan sesuai selera ya. Kemudian kita buat Bahan Pencelup : ambil 5 sdm bahan pelapis tambahkan baking soda dan air dingin. Simpan di kulkas agar tepung bisa menempel sempurna.
1. Panaskan minyak dengan api kecil. Saya menggunakan panci agar ayam nanti terendam dengan sempurna.
1. Ambil adonan pencelup tambahkan kocokan telur. Ambil ayam masukan dalam adonan pencelup hingga ayam terendam semua masukan adonan pelapis. Saya 2x pencelupan dan pelapis agar lebig tebal dan kriuk.
1. Cubit² ayam ya agar ayam jadi kribo. Hentakan ayam dibaskom agar tidak banyak tepung yang masuk kedalam minyak. Goreng hingga matang dan berubah warna. Kemudian angkat dan tiriskan.
1. Note : pastikan saat hendak menggoreng lalukan point ke 4 agar adonan tidak menunggu sehingga jadi keras dan tidak kriuk. Siap disajikan dengan saos atau sambal dadak. Selamat Mencoba.




Wah ternyata cara membuat ayam kentucky kriuk yang nikamt tidak ribet ini enteng banget ya! Anda Semua bisa membuatnya. Cara Membuat ayam kentucky kriuk Sangat sesuai sekali buat kalian yang baru mau belajar memasak maupun untuk kalian yang sudah hebat dalam memasak.

Apakah kamu ingin mencoba buat resep ayam kentucky kriuk mantab sederhana ini? Kalau anda tertarik, yuk kita segera siapin peralatan dan bahan-bahannya, setelah itu buat deh Resep ayam kentucky kriuk yang enak dan tidak rumit ini. Benar-benar gampang kan. 

Maka, daripada anda berfikir lama-lama, ayo langsung aja buat resep ayam kentucky kriuk ini. Dijamin kalian tiidak akan menyesal bikin resep ayam kentucky kriuk lezat sederhana ini! Selamat mencoba dengan resep ayam kentucky kriuk lezat simple ini di tempat tinggal kalian sendiri,oke!.

