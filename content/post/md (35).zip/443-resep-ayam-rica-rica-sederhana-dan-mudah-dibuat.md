---
description: "Resep Ayam rica rica Sederhana dan Mudah Dibuat"
title: "Resep Ayam rica rica Sederhana dan Mudah Dibuat"
slug: 443-resep-ayam-rica-rica-sederhana-dan-mudah-dibuat
date: 2021-02-24T22:48:49.760Z
image: https://img-global.cpcdn.com/recipes/7d23bcae5dab834c/680x482cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7d23bcae5dab834c/680x482cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7d23bcae5dab834c/680x482cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Barry Neal
ratingvalue: 4
reviewcount: 7
recipeingredient:
- "1/2 kg ayam"
- " bumbu halus bisa diblender atau di tumbuk"
- "8 siung bawang merah"
- "4 siung bawang putih"
- "7 bh cabe merah keriting"
- "5 bh cabe rawit kecil"
- "1 ruas jahe"
- "1 ruas kunyit"
- "3 butir kemiri di sangrai dulu"
- " bumbu lainnya"
- "1 ruas lengkuas geprek"
- "1 btg serai geprek"
- "1 bh tomat iris"
- "2 lembar daun jeruk"
- "secukupnya garam bumbu penyedap"
- "1 sdm gula merah"
- "1 bh jeruk nipis"
recipeinstructions:
- "Potongan ayamnya di marinasi dg jeruk nipis kurang lebih 15 menit kemudian goreng ayamnya setengah mateng atau bisa sampai warna agak kecoklatan"
- "Tumis bumbu halus sampai wangi kemudian masukkan lengkuas, serai, tomat dan daun jeruk yg di sobek2. aduk sebentar"
- "Masukkan potongan ayam, tambahkan air, aduk rata.. tambahkan garam, bumbu penyedap dan gula merah.. aduk rata"
- "Test rasa jika sudah pas tunggu sbntr sampai air agak menyusut sekitar 15 menit atau lebih.. jika sudah, langsung angkat dan sajikan"
categories:
- Resep
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 220 calories
recipecuisine: Indonesian
preptime: "PT34M"
cooktime: "PT33M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam rica rica](https://img-global.cpcdn.com/recipes/7d23bcae5dab834c/680x482cq70/ayam-rica-rica-foto-resep-utama.jpg)

Sebagai seorang yang hobi masak, menyediakan santapan sedap pada famili adalah hal yang menggembirakan untuk kamu sendiri. Peran seorang  wanita bukan cuma mengurus rumah saja, tetapi anda pun harus menyediakan keperluan nutrisi tercukupi dan juga santapan yang disantap orang tercinta harus menggugah selera.

Di era  sekarang, kamu sebenarnya mampu membeli panganan jadi meski tidak harus susah memasaknya terlebih dahulu. Namun banyak juga mereka yang selalu mau memberikan yang terlezat bagi orang yang dicintainya. Pasalnya, menyajikan masakan yang dibuat sendiri akan jauh lebih bersih dan bisa menyesuaikan makanan tersebut sesuai dengan makanan kesukaan famili. 

Bahan bumbu ayam rica rica yang digunakan sebenarnya cukup simple dan sederhana, seperti : kunyit, jahe, serai, cabai merah, bawang putih, dan beberapa bumbu lainnya. Ayam rica-rica (Indonesian for chicken rica-rica) is an Indonesian hot and spicy chicken dish. It is made up of chicken that cooked in spicy red and green chili pepper.

Apakah anda merupakan salah satu penyuka ayam rica rica?. Asal kamu tahu, ayam rica rica adalah hidangan khas di Indonesia yang kini digemari oleh setiap orang di hampir setiap daerah di Indonesia. Kamu dapat menyajikan ayam rica rica buatan sendiri di rumah dan dapat dijadikan camilan kesukaanmu di hari libur.

Kamu tak perlu bingung jika kamu ingin memakan ayam rica rica, lantaran ayam rica rica gampang untuk didapatkan dan kita pun dapat menghidangkannya sendiri di rumah. ayam rica rica bisa diolah memalui beragam cara. Kini telah banyak banget resep modern yang menjadikan ayam rica rica lebih enak.

Resep ayam rica rica juga mudah dibikin, lho. Kalian tidak perlu ribet-ribet untuk membeli ayam rica rica, karena Kita mampu menyiapkan ditempatmu. Untuk Kita yang mau menghidangkannya, berikut resep membuat ayam rica rica yang mantab yang mampu Kita hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Ayam rica rica:

1. Gunakan 1/2 kg ayam
1. Sediakan  bumbu halus (bisa diblender atau di tumbuk)
1. Ambil 8 siung bawang merah
1. Sediakan 4 siung bawang putih
1. Siapkan 7 bh cabe merah keriting
1. Sediakan 5 bh cabe rawit kecil
1. Siapkan 1 ruas jahe
1. Ambil 1 ruas kunyit
1. Siapkan 3 butir kemiri (di sangrai dulu)
1. Sediakan  bumbu lainnya
1. Siapkan 1 ruas lengkuas geprek
1. Sediakan 1 btg serai geprek
1. Gunakan 1 bh tomat iris
1. Sediakan 2 lembar daun jeruk
1. Siapkan secukupnya garam, bumbu penyedap
1. Siapkan 1 sdm gula merah
1. Siapkan 1 bh jeruk nipis


Cara pembuatan ayam rica rica sebenarnya tidaklah terlalu sulit. Seperti olahan ayam yang lainnya, bumbu ayam rica rica ini menggunakan bumbu rempah asli Indonesia, seperti kunyit, jahe. Ayam rica-rica is specialty chicken dish from the city of Manado in Indonesia North Sulawesi. Rica means chili in North Sulawesi language, so ayam rica-rica translates to chicken with chili sauce. 

<!--inarticleads2-->

##### Cara menyiapkan Ayam rica rica:

1. Potongan ayamnya di marinasi dg jeruk nipis kurang lebih 15 menit kemudian goreng ayamnya setengah mateng atau bisa sampai warna agak kecoklatan
1. Tumis bumbu halus sampai wangi kemudian masukkan lengkuas, serai, tomat dan daun jeruk yg di sobek2. aduk sebentar
1. Masukkan potongan ayam, tambahkan air, aduk rata.. - tambahkan garam, bumbu penyedap dan gula merah.. aduk rata
1. Test rasa jika sudah pas tunggu sbntr sampai air agak menyusut sekitar 15 menit atau lebih.. jika sudah, langsung angkat dan sajikan


Cara pembuatan ayam rica-rica tidaklah sulit. Salah satunya adalah resep ayam rica rica. Makanan ini berasal dari kota Manado sulawesi utara. Kebanyakan orang mengenal bumbu rica rica hanya untuk olahan daging ayam saja. Ayam rica-rica atau rica-rica ayam bisa jadi pilihan lauk buat penyuka pedas. 

Ternyata resep ayam rica rica yang mantab tidak rumit ini gampang sekali ya! Kalian semua dapat membuatnya. Cara buat ayam rica rica Cocok sekali untuk kita yang baru belajar memasak ataupun untuk kalian yang telah lihai dalam memasak.

Tertarik untuk mulai mencoba buat resep ayam rica rica nikmat sederhana ini? Kalau kalian mau, ayo kalian segera menyiapkan alat-alat dan bahannya, setelah itu bikin deh Resep ayam rica rica yang lezat dan simple ini. Sangat taidak sulit kan. 

Jadi, daripada kalian diam saja, yuk kita langsung saja sajikan resep ayam rica rica ini. Pasti kamu tak akan nyesel sudah bikin resep ayam rica rica lezat tidak ribet ini! Selamat berkreasi dengan resep ayam rica rica lezat simple ini di tempat tinggal masing-masing,oke!.

