---
description: "Cara membuat Botok Ayam Tanpa Daun Pisang/Ayam Masak Santan yang lezat dan Mudah Dibuat"
title: "Cara membuat Botok Ayam Tanpa Daun Pisang/Ayam Masak Santan yang lezat dan Mudah Dibuat"
slug: 152-cara-membuat-botok-ayam-tanpa-daun-pisang-ayam-masak-santan-yang-lezat-dan-mudah-dibuat
date: 2021-04-21T04:35:31.952Z
image: https://img-global.cpcdn.com/recipes/1651d8d73944cde0/680x482cq70/botok-ayam-tanpa-daun-pisangayam-masak-santan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1651d8d73944cde0/680x482cq70/botok-ayam-tanpa-daun-pisangayam-masak-santan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1651d8d73944cde0/680x482cq70/botok-ayam-tanpa-daun-pisangayam-masak-santan-foto-resep-utama.jpg
author: Marcus Gross
ratingvalue: 3.1
reviewcount: 4
recipeingredient:
- "1/2 kg ayam"
- "6 lembar daun jeruk 3 pasang"
- "4 lembar daun salam"
- "5 cm Lengkuas"
- "1,5 bungkus santan instan"
- "1500 ml Air"
- " Bumbu "
- "3 sdt garam"
- "1/2 sdt penyedap"
- "1 keping gula jawa"
- "2.5 sdm gula pasir"
- " Bumbu Goreng "
- "3 bawang putih"
- "6 bawang merah"
- "10 cabai"
- "3 tomat"
recipeinstructions:
- "Haluskan semua bumbu yang sudah digoreng"
- "Tumis bumbu halus bersama daun jeruk, daun salam, lengkuas"
- "Tumis samapi daun jeruk harum, masukkan ayam sampai berubah pucat"
- "Masukkan air, garam, gula, penyedap"
- "Aduk rata, tutup &amp; masak sampai matang"
- "Tuang santan perlahan sambil terus diaduk sampai mendidih"
- "Koreksi rasa &amp; sajikan"
categories:
- Resep
tags:
- botok
- ayam
- tanpa

katakunci: botok ayam tanpa 
nutrition: 230 calories
recipecuisine: Indonesian
preptime: "PT16M"
cooktime: "PT48M"
recipeyield: "1"
recipecategory: Dinner

---


![Botok Ayam Tanpa Daun Pisang/Ayam Masak Santan](https://img-global.cpcdn.com/recipes/1651d8d73944cde0/680x482cq70/botok-ayam-tanpa-daun-pisangayam-masak-santan-foto-resep-utama.jpg)

Sebagai seorang istri, menyuguhkan santapan lezat untuk famili merupakan hal yang menyenangkan untuk anda sendiri. Kewajiban seorang  wanita Tidak cuma mengurus rumah saja, tetapi kamu juga harus memastikan kebutuhan gizi tercukupi dan masakan yang dimakan keluarga tercinta harus lezat.

Di waktu  saat ini, kamu memang bisa mengorder panganan yang sudah jadi walaupun tidak harus ribet memasaknya dahulu. Tetapi ada juga lho orang yang memang ingin menghidangkan yang terbaik untuk keluarganya. Lantaran, menghidangkan masakan yang diolah sendiri jauh lebih bersih dan kita pun bisa menyesuaikan makanan tersebut berdasarkan masakan kesukaan orang tercinta. 



Mungkinkah anda salah satu penggemar botok ayam tanpa daun pisang/ayam masak santan?. Asal kamu tahu, botok ayam tanpa daun pisang/ayam masak santan adalah makanan khas di Indonesia yang sekarang disukai oleh kebanyakan orang dari hampir setiap wilayah di Indonesia. Anda dapat membuat botok ayam tanpa daun pisang/ayam masak santan buatan sendiri di rumahmu dan boleh dijadikan camilan favorit di hari libur.

Kalian jangan bingung jika kamu ingin mendapatkan botok ayam tanpa daun pisang/ayam masak santan, sebab botok ayam tanpa daun pisang/ayam masak santan mudah untuk didapatkan dan juga kamu pun bisa menghidangkannya sendiri di rumah. botok ayam tanpa daun pisang/ayam masak santan bisa dimasak dengan berbagai cara. Sekarang telah banyak sekali resep modern yang membuat botok ayam tanpa daun pisang/ayam masak santan semakin lezat.

Resep botok ayam tanpa daun pisang/ayam masak santan pun sangat mudah untuk dibuat, lho. Kalian tidak perlu ribet-ribet untuk membeli botok ayam tanpa daun pisang/ayam masak santan, sebab Kamu mampu menyajikan di rumahmu. Untuk Kalian yang akan membuatnya, dibawah ini merupakan cara untuk membuat botok ayam tanpa daun pisang/ayam masak santan yang mantab yang dapat Kamu coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Botok Ayam Tanpa Daun Pisang/Ayam Masak Santan:

1. Gunakan 1/2 kg ayam
1. Ambil 6 lembar daun jeruk (3 pasang)
1. Gunakan 4 lembar daun salam
1. Siapkan 5 cm Lengkuas
1. Ambil 1,5 bungkus santan instan
1. Gunakan 1500 ml Air
1. Sediakan  Bumbu :
1. Sediakan 3 sdt garam
1. Ambil 1/2 sdt penyedap
1. Ambil 1 keping gula jawa
1. Ambil 2.5 sdm gula pasir
1. Gunakan  Bumbu Goreng :
1. Siapkan 3 bawang putih
1. Ambil 6 bawang merah
1. Gunakan 10 cabai
1. Gunakan 3 tomat




<!--inarticleads2-->

##### Cara menyiapkan Botok Ayam Tanpa Daun Pisang/Ayam Masak Santan:

1. Haluskan semua bumbu yang sudah digoreng
1. Tumis bumbu halus bersama daun jeruk, daun salam, lengkuas
1. Tumis samapi daun jeruk harum, masukkan ayam sampai berubah pucat
1. Masukkan air, garam, gula, penyedap
1. Aduk rata, tutup &amp; masak sampai matang
1. Tuang santan perlahan sambil terus diaduk sampai mendidih
1. Koreksi rasa &amp; sajikan




Ternyata resep botok ayam tanpa daun pisang/ayam masak santan yang enak simple ini mudah sekali ya! Kalian semua mampu mencobanya. Cara buat botok ayam tanpa daun pisang/ayam masak santan Sangat sesuai banget untuk kamu yang baru belajar memasak atau juga untuk kalian yang telah jago memasak.

Tertarik untuk mencoba bikin resep botok ayam tanpa daun pisang/ayam masak santan nikmat simple ini? Kalau anda ingin, mending kamu segera buruan siapkan alat-alat dan bahan-bahannya, lantas bikin deh Resep botok ayam tanpa daun pisang/ayam masak santan yang mantab dan tidak ribet ini. Sangat taidak sulit kan. 

Jadi, daripada kamu berlama-lama, ayo kita langsung sajikan resep botok ayam tanpa daun pisang/ayam masak santan ini. Dijamin anda tak akan nyesel bikin resep botok ayam tanpa daun pisang/ayam masak santan enak simple ini! Selamat mencoba dengan resep botok ayam tanpa daun pisang/ayam masak santan mantab tidak ribet ini di tempat tinggal sendiri,oke!.

