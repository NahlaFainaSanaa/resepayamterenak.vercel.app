---
description: "Cara membuat Ayam Goreng Lengkuas Kremes yang nikmat dan Mudah Dibuat"
title: "Cara membuat Ayam Goreng Lengkuas Kremes yang nikmat dan Mudah Dibuat"
slug: 494-cara-membuat-ayam-goreng-lengkuas-kremes-yang-nikmat-dan-mudah-dibuat
date: 2021-01-10T16:37:40.632Z
image: https://img-global.cpcdn.com/recipes/d10e9ba645103df6/680x482cq70/ayam-goreng-lengkuas-kremes-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d10e9ba645103df6/680x482cq70/ayam-goreng-lengkuas-kremes-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d10e9ba645103df6/680x482cq70/ayam-goreng-lengkuas-kremes-foto-resep-utama.jpg
author: Mabelle Keller
ratingvalue: 4.5
reviewcount: 7
recipeingredient:
- " Bahan utama"
- "1 ekor ayam potong jadi 8 "
- " Bumbu halus"
- "3 siung bawang putih"
- "4 siung bawang merah"
- "1 butir kemiri lebih juga boleh"
- "2 cm jahe"
- "1/2 sdt kunyit bubuk"
- "1/2 sdt garam"
- "1/2 sdt lada"
- " Bahan lainnya"
- "2 batang serai"
- "3 lembar daun jeruk daun salam jg bs"
- "2 cm lengkuas parut"
- "1 sdm minyak kelapa utk menumis"
- "100 ml kaldu ayam lihat resep saya"
- "250 ml minyak goreng"
- " Pelengkap"
- "5 lembar daun selada"
- "1 piring nasi merah"
recipeinstructions:
- "Siapkan bahan. Cuci bersih ayam, haluskan bumbu menggunakan uleg."
- "Tuang minyak kelapa, tumis bumbu halus hingga harum. Tambahkan serai, daun jeruk, dan lengkuas parut. Masukkan ayam dan kaldu, masak 10 menit hingga bumbu meresap."
- "Setelah bumbu meresap, Anda bisa menyimpan dalam kulkas jadi bisa di goreng kapan saja. Goreng dengan api kecil selama 10 menit. Sajikan dengan nasi merah. Enjoyed my lunch. So yummy 🤤"
categories:
- Resep
tags:
- ayam
- goreng
- lengkuas

katakunci: ayam goreng lengkuas 
nutrition: 130 calories
recipecuisine: Indonesian
preptime: "PT26M"
cooktime: "PT59M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Goreng Lengkuas Kremes](https://img-global.cpcdn.com/recipes/d10e9ba645103df6/680x482cq70/ayam-goreng-lengkuas-kremes-foto-resep-utama.jpg)

Apabila kalian seorang orang tua, menyuguhkan hidangan enak bagi famili merupakan suatu hal yang sangat menyenangkan untuk anda sendiri. Tugas seorang  wanita Tidak hanya mengerjakan pekerjaan rumah saja, tapi kamu pun harus menyediakan kebutuhan gizi terpenuhi dan hidangan yang disantap anak-anak wajib sedap.

Di masa  saat ini, anda memang dapat membeli hidangan instan meski tanpa harus susah mengolahnya terlebih dahulu. Tetapi ada juga lho orang yang selalu ingin menyajikan yang terbaik untuk orang yang dicintainya. Pasalnya, menyajikan masakan yang diolah sendiri akan jauh lebih bersih dan bisa menyesuaikan masakan tersebut sesuai masakan kesukaan keluarga tercinta. 



Mungkinkah anda adalah seorang penggemar ayam goreng lengkuas kremes?. Tahukah kamu, ayam goreng lengkuas kremes adalah hidangan khas di Indonesia yang saat ini disukai oleh kebanyakan orang di hampir setiap tempat di Nusantara. Kamu bisa menyajikan ayam goreng lengkuas kremes hasil sendiri di rumah dan boleh jadi makanan kegemaranmu di akhir pekan.

Kita tidak perlu bingung untuk memakan ayam goreng lengkuas kremes, lantaran ayam goreng lengkuas kremes tidak sukar untuk didapatkan dan anda pun dapat menghidangkannya sendiri di rumah. ayam goreng lengkuas kremes dapat dimasak memalui beragam cara. Sekarang sudah banyak resep modern yang membuat ayam goreng lengkuas kremes semakin lezat.

Resep ayam goreng lengkuas kremes pun sangat mudah dihidangkan, lho. Kamu tidak usah capek-capek untuk memesan ayam goreng lengkuas kremes, lantaran Anda dapat menyiapkan ditempatmu. Untuk Anda yang mau mencobanya, dibawah ini merupakan resep untuk membuat ayam goreng lengkuas kremes yang nikamat yang mampu Kamu coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Ayam Goreng Lengkuas Kremes:

1. Sediakan  Bahan utama:
1. Sediakan 1 ekor ayam (potong jadi 8) 🐓
1. Gunakan  Bumbu halus:
1. Sediakan 3 siung bawang putih
1. Gunakan 4 siung bawang merah
1. Gunakan 1 butir kemiri (lebih juga boleh)
1. Gunakan 2 cm jahe
1. Sediakan 1/2 sdt kunyit bubuk
1. Gunakan 1/2 sdt garam
1. Sediakan 1/2 sdt lada
1. Sediakan  Bahan lainnya:
1. Ambil 2 batang serai
1. Sediakan 3 lembar daun jeruk (daun salam jg bs)
1. Sediakan 2 cm lengkuas (parut)
1. Ambil 1 sdm minyak kelapa utk menumis
1. Gunakan 100 ml kaldu ayam (lihat resep saya)
1. Sediakan 250 ml minyak goreng
1. Siapkan  Pelengkap:
1. Ambil 5 lembar daun selada
1. Sediakan 1 piring nasi merah




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Goreng Lengkuas Kremes:

1. Siapkan bahan. Cuci bersih ayam, haluskan bumbu menggunakan uleg.
1. Tuang minyak kelapa, tumis bumbu halus hingga harum. Tambahkan serai, daun jeruk, dan lengkuas parut. Masukkan ayam dan kaldu, masak 10 menit hingga bumbu meresap.
1. Setelah bumbu meresap, Anda bisa menyimpan dalam kulkas jadi bisa di goreng kapan saja. Goreng dengan api kecil selama 10 menit. Sajikan dengan nasi merah. Enjoyed my lunch. So yummy 🤤




Wah ternyata cara buat ayam goreng lengkuas kremes yang mantab simple ini enteng sekali ya! Semua orang mampu memasaknya. Resep ayam goreng lengkuas kremes Sangat sesuai sekali untuk kita yang sedang belajar memasak atau juga bagi kamu yang telah ahli dalam memasak.

Tertarik untuk mencoba membuat resep ayam goreng lengkuas kremes lezat tidak ribet ini? Kalau kamu ingin, ayo kalian segera menyiapkan alat-alat dan bahan-bahannya, lantas bikin deh Resep ayam goreng lengkuas kremes yang mantab dan sederhana ini. Betul-betul taidak sulit kan. 

Jadi, daripada kalian diam saja, hayo langsung aja hidangkan resep ayam goreng lengkuas kremes ini. Pasti kalian tak akan menyesal sudah bikin resep ayam goreng lengkuas kremes nikmat tidak ribet ini! Selamat berkreasi dengan resep ayam goreng lengkuas kremes mantab simple ini di tempat tinggal sendiri,oke!.

