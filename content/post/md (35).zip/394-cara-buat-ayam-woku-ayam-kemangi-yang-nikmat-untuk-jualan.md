---
description: "Cara buat Ayam woku / ayam kemangi yang nikmat Untuk Jualan"
title: "Cara buat Ayam woku / ayam kemangi yang nikmat Untuk Jualan"
slug: 394-cara-buat-ayam-woku-ayam-kemangi-yang-nikmat-untuk-jualan
date: 2021-05-28T07:06:12.906Z
image: https://img-global.cpcdn.com/recipes/e0e0d558d311e3f2/680x482cq70/ayam-woku-ayam-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e0e0d558d311e3f2/680x482cq70/ayam-woku-ayam-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e0e0d558d311e3f2/680x482cq70/ayam-woku-ayam-kemangi-foto-resep-utama.jpg
author: Cora McDonald
ratingvalue: 3.3
reviewcount: 13
recipeingredient:
- "1/2 kg ayam"
- "3 siung bawang putih"
- "5 siung bawang merah"
- "1 ruas kunyit"
- "1 ruas jahe digeprek"
- "5 buah cabe keriting"
- "3 buah cabe rawit"
- "2 lembar daun salam"
- "1 batang sereh geprek"
- "2 lembar daun jeruk"
- " Lengkuas digeprek"
- " Garamgulakaldu bubuk"
- "1 ikat kemangi"
recipeinstructions:
- "Potong ayam menjadi kecil2, haluskan bumbu kecuali daun jeruk, sereh, salam, lengkuas, jahe"
- "Tumis bumbu halus, lalu masukkan daun salam, sereh, lengkuas, jahe, daun jeruk.. tumis sampai harum.."
- "Masukkan ayam nya.. beri sedikit air.. aduk2"
- "Tambahkan gula+garam+kaldu bubuk.. aduk rata.. lalu tutup tunggu sampai ayam empuk dan bumbu meresap.. tes rasa"
- "Setelah ayam sudah empuk dan hampir matang masukkan daun kemangi yang sudah dipetik dan dicuci bersih"
- "Aduh sampai kemangi layu.. ayam woku siap dihidangkan dengan nasi anget+ krupuk 😄"
categories:
- Resep
tags:
- ayam
- woku
- 

katakunci: ayam woku  
nutrition: 233 calories
recipecuisine: Indonesian
preptime: "PT10M"
cooktime: "PT38M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam woku / ayam kemangi](https://img-global.cpcdn.com/recipes/e0e0d558d311e3f2/680x482cq70/ayam-woku-ayam-kemangi-foto-resep-utama.jpg)

Selaku seorang wanita, mempersiapkan hidangan nikmat buat orang tercinta adalah suatu hal yang mengasyikan bagi anda sendiri. Tugas seorang  wanita bukan cuman mengurus rumah saja, tetapi anda pun wajib memastikan keperluan gizi tercukupi dan juga olahan yang disantap keluarga tercinta harus menggugah selera.

Di masa  sekarang, kita sebenarnya bisa memesan hidangan yang sudah jadi walaupun tidak harus ribet memasaknya dulu. Tetapi ada juga lho mereka yang memang mau memberikan makanan yang terlezat untuk keluarganya. Pasalnya, menyajikan masakan sendiri jauh lebih bersih dan kita juga bisa menyesuaikan hidangan tersebut sesuai dengan makanan kesukaan orang tercinta. 



Mungkinkah kamu salah satu penggemar ayam woku / ayam kemangi?. Tahukah kamu, ayam woku / ayam kemangi adalah makanan khas di Indonesia yang sekarang disenangi oleh setiap orang di hampir setiap wilayah di Indonesia. Kamu dapat menyajikan ayam woku / ayam kemangi olahan sendiri di rumah dan boleh dijadikan hidangan favoritmu di hari liburmu.

Kalian tidak usah bingung untuk memakan ayam woku / ayam kemangi, sebab ayam woku / ayam kemangi mudah untuk dicari dan anda pun boleh mengolahnya sendiri di tempatmu. ayam woku / ayam kemangi boleh dimasak lewat beraneka cara. Saat ini ada banyak resep kekinian yang menjadikan ayam woku / ayam kemangi semakin lebih enak.

Resep ayam woku / ayam kemangi pun gampang untuk dibuat, lho. Kamu tidak perlu ribet-ribet untuk membeli ayam woku / ayam kemangi, karena Kita dapat membuatnya sendiri di rumah. Untuk Anda yang mau menyajikannya, inilah resep membuat ayam woku / ayam kemangi yang mantab yang mampu Kalian coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Ayam woku / ayam kemangi:

1. Sediakan 1/2 kg ayam
1. Siapkan 3 siung bawang putih
1. Sediakan 5 siung bawang merah
1. Ambil 1 ruas kunyit
1. Sediakan 1 ruas jahe digeprek
1. Ambil 5 buah cabe keriting
1. Sediakan 3 buah cabe rawit
1. Gunakan 2 lembar daun salam
1. Siapkan 1 batang sereh geprek
1. Ambil 2 lembar daun jeruk
1. Gunakan  Lengkuas digeprek
1. Sediakan  Garam+gula+kaldu bubuk
1. Siapkan 1 ikat kemangi




<!--inarticleads2-->

##### Cara membuat Ayam woku / ayam kemangi:

1. Potong ayam menjadi kecil2, haluskan bumbu kecuali daun jeruk, sereh, salam, lengkuas, jahe
1. Tumis bumbu halus, lalu masukkan daun salam, sereh, lengkuas, jahe, daun jeruk.. tumis sampai harum..
1. Masukkan ayam nya.. beri sedikit air.. aduk2
1. Tambahkan gula+garam+kaldu bubuk.. aduk rata.. lalu tutup tunggu sampai ayam empuk dan bumbu meresap.. tes rasa
1. Setelah ayam sudah empuk dan hampir matang masukkan daun kemangi yang sudah dipetik dan dicuci bersih
1. Aduh sampai kemangi layu.. ayam woku siap dihidangkan dengan nasi anget+ krupuk 😄




Ternyata cara buat ayam woku / ayam kemangi yang nikamt tidak rumit ini enteng banget ya! Kalian semua dapat menghidangkannya. Resep ayam woku / ayam kemangi Cocok sekali buat anda yang sedang belajar memasak maupun juga bagi kamu yang telah pandai dalam memasak.

Apakah kamu ingin mulai mencoba membikin resep ayam woku / ayam kemangi nikmat tidak rumit ini? Kalau kamu tertarik, mending kamu segera buruan menyiapkan alat-alat dan bahannya, kemudian bikin deh Resep ayam woku / ayam kemangi yang nikmat dan sederhana ini. Betul-betul taidak sulit kan. 

Oleh karena itu, daripada anda berlama-lama, yuk kita langsung saja bikin resep ayam woku / ayam kemangi ini. Dijamin kalian tiidak akan nyesel sudah buat resep ayam woku / ayam kemangi enak tidak ribet ini! Selamat berkreasi dengan resep ayam woku / ayam kemangi nikmat simple ini di rumah masing-masing,oke!.

