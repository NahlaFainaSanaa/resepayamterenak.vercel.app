---
description: "Bahan-bahan Opor Ayam Pok Pok (Bumbu Opor Jawa Timuran) yang lezat Untuk Jualan"
title: "Bahan-bahan Opor Ayam Pok Pok (Bumbu Opor Jawa Timuran) yang lezat Untuk Jualan"
slug: 101-bahan-bahan-opor-ayam-pok-pok-bumbu-opor-jawa-timuran-yang-lezat-untuk-jualan
date: 2021-02-19T05:32:00.607Z
image: https://img-global.cpcdn.com/recipes/9ff038dd2936f1f9/680x482cq70/opor-ayam-pok-pok-bumbu-opor-jawa-timuran-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9ff038dd2936f1f9/680x482cq70/opor-ayam-pok-pok-bumbu-opor-jawa-timuran-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9ff038dd2936f1f9/680x482cq70/opor-ayam-pok-pok-bumbu-opor-jawa-timuran-foto-resep-utama.jpg
author: Mayme Vaughn
ratingvalue: 3.8
reviewcount: 11
recipeingredient:
- " Bahan Kuah Opor  Bumbu Cemplung"
- "1-2 liter air bersih"
- "30 gram santan kental"
- "2 batang sereh memarkan"
- "2 lembar daun salam"
- "1 ruas jari lengkuas memarkan"
- "1 butir kapulaga"
- "1 sdt garam"
- "1 sdm gula pasir atau bisa pakai gula aren"
- "1/2 sdt kaldu bubuk"
- " Bumbu Halus"
- "8 butir bawang merah"
- "4 siung bawang putih"
- "2 cm kunyit bakar"
- "2 butir kemiri sangrai"
- "1 ruas jari jahe"
- "1 lembar daun jeruk"
- "1/2 sdt ketumbar bubuk"
- " Bahan Ayam Pok Pok"
- "300 gram dada ayam potong dadu"
- "1 sdm air jeruk nipis"
- "1/2 sachet bumbu ayam goreng untuk marinasi"
- "2 butir telur kocok lepas"
- "250 gram tepung terigu"
- "3 sdm tepung beras"
- "secukupnya kaldu bubuk"
- "secukupnya minyak goreng"
- " Bahan Lainnya"
- "2 buah kentang potong panjang"
- "1 buah cabai merah besar iris serong"
- "secukupnya bawang goreng"
- "secukupnya daun bawang iris"
recipeinstructions:
- "Membuat Kuah Opor: Blender bumbu hingga halus. Lalu panaskan minyak goreng, masukkan bumbu halus beserta bumbu cemplungnya. Tumis hingga harum dan matang."
- "Selanjutnya tambahkan air, santan, gula, garam dan kaldu bubuk. Aduk rata masak hingga mendidih. Sesekali diaduk agar santan tidak pecah dan jangan lupa tes rasa. Jika sudah matang matikan apinya, sisihkan."
- "Untuk Kentangnya: kupas, potong panjang, lalu cuci bersih. Rendam sebentar dengan air garam ± 10 menit, lalu goreng hingga goldenbrown. Jika sudah tiriskan."
- "Untuk Ayam Pok2nya: Cuci bersih ayam yang sudah dipotong-potong lalu lumuri dengan air perasan jeruk nipis. Remas-remas agar jeruk nipis tercampur rata, kemudian bilas lagi dengan air bersih."
- "Selanjutnya masukkan bumbu marinasi, aduk rata dan diamkan selama satu jam, simpan dalam kulkas."
- "Sambil menunggu bumbu marinasi meresap, siapkan tepung pelapisnya. Campur jadi satu tepung terigu, tepung beras, garam, dan kaldu bubuk, aduk rata. Jika sudah 1 jan keluarkan ayam lalu lumuri tepung hingga merata."
- "Kemudian celupkan kedalam telur kocok, aduk rata dan pindahkan lagi ke tepung pelapisnya (2x tahapan)."
- "Selanjutnya goreng pada minyak panas yang cukup banyak agar matang merata dan krispi. Biarkan dulu jangan dibolak balik, tunggu sampai tepung agak kokoh supaya tepung tidak rontok."
- "Jika warna sudah matang kecoklatan, angkat dan tiriskan."
- "Penyajian 1: Panaskan kuah... Ambil beberapa ayam pok pok dan kentang goreng. Letakkan dan tata pada wadah saji kemudian siram kuah opornya. Beri taburan daun bawang dan cabai iris, sajikan."
- "Penyajian 2: Ambil secukupnya ayam pok pok dan letakkan di mangkuk saji. Siram kuah opornya, untuk kentang diletakkan terpisah, sajikan."
- "Penyajian 3: Campur jadi satu ayam pok pok, kentang goreng dan kuah opor. Beri taburan bawang goreng dan irisan cabai merah, sajikan."
- "Bisa juga kunjungi link resep asli https://cookpad.com/id/resep/13882229-opor-ayam-jawa-timur?invite_token=LVhMFkXahxJiA79iJExidLfQ&amp;shared_at=1620511106."
categories:
- Resep
tags:
- opor
- ayam
- pok

katakunci: opor ayam pok 
nutrition: 144 calories
recipecuisine: Indonesian
preptime: "PT32M"
cooktime: "PT36M"
recipeyield: "2"
recipecategory: Dessert

---


![Opor Ayam Pok Pok (Bumbu Opor Jawa Timuran)](https://img-global.cpcdn.com/recipes/9ff038dd2936f1f9/680x482cq70/opor-ayam-pok-pok-bumbu-opor-jawa-timuran-foto-resep-utama.jpg)

Selaku seorang orang tua, menyajikan hidangan sedap kepada orang tercinta merupakan suatu hal yang mengasyikan bagi kamu sendiri. Kewajiban seorang  wanita Tidak hanya mengerjakan pekerjaan rumah saja, tapi kamu juga harus memastikan kebutuhan gizi tercukupi dan panganan yang dimakan orang tercinta wajib mantab.

Di masa  sekarang, anda memang bisa memesan masakan instan meski tidak harus ribet membuatnya terlebih dahulu. Namun ada juga lho orang yang memang mau menyajikan yang terbaik bagi orang tercintanya. Pasalnya, memasak yang diolah sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan makanan tersebut sesuai dengan selera orang tercinta. 



Mungkinkah anda merupakan seorang penikmat opor ayam pok pok (bumbu opor jawa timuran)?. Asal kamu tahu, opor ayam pok pok (bumbu opor jawa timuran) adalah hidangan khas di Nusantara yang kini disukai oleh orang-orang dari hampir setiap daerah di Indonesia. Kalian bisa membuat opor ayam pok pok (bumbu opor jawa timuran) hasil sendiri di rumahmu dan pasti jadi santapan kesukaanmu di hari libur.

Kalian jangan bingung jika kamu ingin memakan opor ayam pok pok (bumbu opor jawa timuran), lantaran opor ayam pok pok (bumbu opor jawa timuran) mudah untuk dicari dan juga kita pun boleh membuatnya sendiri di tempatmu. opor ayam pok pok (bumbu opor jawa timuran) dapat diolah memalui beraneka cara. Saat ini telah banyak cara modern yang menjadikan opor ayam pok pok (bumbu opor jawa timuran) semakin mantap.

Resep opor ayam pok pok (bumbu opor jawa timuran) juga mudah dibikin, lho. Kamu tidak perlu ribet-ribet untuk membeli opor ayam pok pok (bumbu opor jawa timuran), karena Anda bisa menyiapkan sendiri di rumah. Bagi Kita yang mau menghidangkannya, berikut cara menyajikan opor ayam pok pok (bumbu opor jawa timuran) yang mantab yang bisa Anda hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Opor Ayam Pok Pok (Bumbu Opor Jawa Timuran):

1. Gunakan  Bahan Kuah Opor + Bumbu Cemplung:
1. Sediakan 1-2 liter air bersih
1. Sediakan 30 gram santan kental
1. Sediakan 2 batang sereh, memarkan
1. Sediakan 2 lembar daun salam
1. Siapkan 1 ruas jari lengkuas, memarkan
1. Ambil 1 butir kapulaga
1. Siapkan 1 sdt garam
1. Sediakan 1 sdm gula pasir, atau bisa pakai gula aren
1. Ambil 1/2 sdt kaldu bubuk
1. Sediakan  Bumbu Halus:
1. Gunakan 8 butir bawang merah
1. Siapkan 4 siung bawang putih
1. Sediakan 2 cm kunyit bakar
1. Sediakan 2 butir kemiri sangrai
1. Ambil 1 ruas jari jahe
1. Sediakan 1 lembar daun jeruk
1. Sediakan 1/2 sdt ketumbar bubuk
1. Ambil  Bahan Ayam Pok Pok:
1. Ambil 300 gram dada ayam, potong dadu
1. Ambil 1 sdm air jeruk nipis
1. Ambil 1/2 sachet bumbu ayam goreng, untuk marinasi
1. Gunakan 2 butir telur, kocok lepas
1. Sediakan 250 gram tepung terigu
1. Gunakan 3 sdm tepung beras
1. Gunakan secukupnya kaldu bubuk
1. Siapkan secukupnya minyak goreng
1. Siapkan  Bahan Lainnya:
1. Ambil 2 buah kentang, potong panjang
1. Siapkan 1 buah cabai merah besar, iris serong
1. Siapkan secukupnya bawang goreng
1. Sediakan secukupnya daun bawang, iris




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Opor Ayam Pok Pok (Bumbu Opor Jawa Timuran):

1. Membuat Kuah Opor: Blender bumbu hingga halus. Lalu panaskan minyak goreng, masukkan bumbu halus beserta bumbu cemplungnya. Tumis hingga harum dan matang.
1. Selanjutnya tambahkan air, santan, gula, garam dan kaldu bubuk. Aduk rata masak hingga mendidih. Sesekali diaduk agar santan tidak pecah dan jangan lupa tes rasa. Jika sudah matang matikan apinya, sisihkan.
1. Untuk Kentangnya: kupas, potong panjang, lalu cuci bersih. Rendam sebentar dengan air garam ± 10 menit, lalu goreng hingga goldenbrown. Jika sudah tiriskan.
1. Untuk Ayam Pok2nya: Cuci bersih ayam yang sudah dipotong-potong lalu lumuri dengan air perasan jeruk nipis. Remas-remas agar jeruk nipis tercampur rata, kemudian bilas lagi dengan air bersih.
1. Selanjutnya masukkan bumbu marinasi, aduk rata dan diamkan selama satu jam, simpan dalam kulkas.
1. Sambil menunggu bumbu marinasi meresap, siapkan tepung pelapisnya. Campur jadi satu tepung terigu, tepung beras, garam, dan kaldu bubuk, aduk rata. Jika sudah 1 jan keluarkan ayam lalu lumuri tepung hingga merata.
1. Kemudian celupkan kedalam telur kocok, aduk rata dan pindahkan lagi ke tepung pelapisnya (2x tahapan).
1. Selanjutnya goreng pada minyak panas yang cukup banyak agar matang merata dan krispi. Biarkan dulu jangan dibolak balik, tunggu sampai tepung agak kokoh supaya tepung tidak rontok.
1. Jika warna sudah matang kecoklatan, angkat dan tiriskan.
1. Penyajian 1: Panaskan kuah... Ambil beberapa ayam pok pok dan kentang goreng. Letakkan dan tata pada wadah saji kemudian siram kuah opornya. Beri taburan daun bawang dan cabai iris, sajikan.
1. Penyajian 2: Ambil secukupnya ayam pok pok dan letakkan di mangkuk saji. Siram kuah opornya, untuk kentang diletakkan terpisah, sajikan.
1. Penyajian 3: Campur jadi satu ayam pok pok, kentang goreng dan kuah opor. Beri taburan bawang goreng dan irisan cabai merah, sajikan.
1. Bisa juga kunjungi link resep asli https://cookpad.com/id/resep/13882229-opor-ayam-jawa-timur?invite_token=LVhMFkXahxJiA79iJExidLfQ&amp;shared_at=1620511106.




Ternyata cara buat opor ayam pok pok (bumbu opor jawa timuran) yang nikamt simple ini gampang banget ya! Anda Semua dapat menghidangkannya. Cara buat opor ayam pok pok (bumbu opor jawa timuran) Sesuai banget buat kita yang baru mau belajar memasak atau juga untuk kamu yang sudah ahli memasak.

Apakah kamu mau mulai mencoba membikin resep opor ayam pok pok (bumbu opor jawa timuran) enak sederhana ini? Kalau kamu tertarik, mending kamu segera menyiapkan alat dan bahan-bahannya, lantas buat deh Resep opor ayam pok pok (bumbu opor jawa timuran) yang mantab dan tidak rumit ini. Sungguh taidak sulit kan. 

Maka dari itu, ketimbang kalian berfikir lama-lama, hayo langsung aja bikin resep opor ayam pok pok (bumbu opor jawa timuran) ini. Pasti kalian tiidak akan nyesel sudah buat resep opor ayam pok pok (bumbu opor jawa timuran) lezat tidak ribet ini! Selamat mencoba dengan resep opor ayam pok pok (bumbu opor jawa timuran) mantab simple ini di tempat tinggal masing-masing,oke!.

