---
description: "Cara membuat Ayam Woku yang lezat dan Mudah Dibuat"
title: "Cara membuat Ayam Woku yang lezat dan Mudah Dibuat"
slug: 409-cara-membuat-ayam-woku-yang-lezat-dan-mudah-dibuat
date: 2021-04-12T19:04:56.336Z
image: https://img-global.cpcdn.com/recipes/0e4f46437b61525b/680x482cq70/ayam-woku-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0e4f46437b61525b/680x482cq70/ayam-woku-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0e4f46437b61525b/680x482cq70/ayam-woku-foto-resep-utama.jpg
author: Evan Campbell
ratingvalue: 3
reviewcount: 10
recipeingredient:
- "3 sayap ayam"
- "8 potong chicken tenderloin"
- "1 ruas serai geprek"
- "1 ikat kemangi"
- "1 lembar daun kunyit ukuran kecil"
- "3 lembar daun pandan ikat satu per satu"
- "2 ruas daun bawang potongpotong agak panjang"
- "2 lembar daun jeruk robek helainya"
- "2 buah tomat potong wedgess"
- "1/2 buah lemon ukuran sedang"
- "10 sdm minyak goreng"
- "300 ml air"
- " Seasoning"
- " Gula merah"
- " Garam"
- " Lada putih bubuk"
- " Kaldu ayam bubuk"
- " Bumbu Dasar Halus"
- "7 siung bawang putih"
- "14 siung bawang merah"
- "2 buah cabai merah besar"
- "3 ruas serai"
- "35 gr kunyit"
- "20 gr jahe"
- "2 buah kemiri"
recipeinstructions:
- "Haluskan bahan-bahan bumbu dasar menggunakan chopper. Jangan terlalu halus."
- "Panaskan minyak. Tumis bumbu halus bersama dengan serai geprek, daun kunyit, dan daun jeruk. Tumis sampai harum dan benar-benar matang."
- "Masukkan seasoning, disusul potongan tomat."
- "Masukkan sayap ayam. Aduk dengan hati-hati."
- "Setelah sayap setengah matang, masukkan potongan tenderloin. Aduk lagi perlahan."
- "Masukkan air, disusul daun pandan."
- "Setelah mendidih dan air agak menyusut (kuah bisa disesuaikan berdasarkan selera), masukkan perasan air lemon, koreksi rasa."
- "Kalau rasa sudah pas, masukkan daun kemangi dan daun bawang. Aduk rata."
- "Siap disajikan bersama nasi putih hangat."
categories:
- Resep
tags:
- ayam
- woku

katakunci: ayam woku 
nutrition: 188 calories
recipecuisine: Indonesian
preptime: "PT33M"
cooktime: "PT33M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam Woku](https://img-global.cpcdn.com/recipes/0e4f46437b61525b/680x482cq70/ayam-woku-foto-resep-utama.jpg)

Selaku seorang yang hobi memasak, menyajikan hidangan sedap untuk orang tercinta adalah hal yang memuaskan untuk anda sendiri. Tugas seorang ibu Tidak sekedar menjaga rumah saja, tapi kamu pun wajib memastikan keperluan gizi tercukupi dan juga panganan yang dikonsumsi orang tercinta mesti enak.

Di era  sekarang, anda memang bisa mengorder olahan praktis tidak harus ribet memasaknya lebih dulu. Namun ada juga mereka yang selalu mau memberikan yang terlezat bagi orang yang dicintainya. Lantaran, menyajikan masakan yang diolah sendiri akan jauh lebih bersih dan bisa menyesuaikan makanan tersebut sesuai dengan selera orang tercinta. 



Mungkinkah anda merupakan salah satu penyuka ayam woku?. Asal kamu tahu, ayam woku adalah makanan khas di Indonesia yang kini disukai oleh banyak orang dari hampir setiap wilayah di Nusantara. Anda dapat menghidangkan ayam woku olahan sendiri di rumahmu dan boleh jadi hidangan kegemaranmu di akhir pekanmu.

Anda tidak perlu bingung untuk menyantap ayam woku, karena ayam woku tidak sulit untuk didapatkan dan kalian pun bisa menghidangkannya sendiri di tempatmu. ayam woku dapat dibuat lewat bermacam cara. Saat ini sudah banyak banget resep kekinian yang menjadikan ayam woku semakin enak.

Resep ayam woku juga sangat gampang dihidangkan, lho. Kita tidak perlu capek-capek untuk memesan ayam woku, lantaran Kamu dapat menyiapkan di rumahmu. Bagi Kita yang mau menghidangkannya, berikut cara membuat ayam woku yang enak yang mampu Kita hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Ayam Woku:

1. Sediakan 3 sayap ayam
1. Siapkan 8 potong chicken tenderloin
1. Gunakan 1 ruas serai (geprek)
1. Sediakan 1 ikat kemangi
1. Sediakan 1 lembar daun kunyit ukuran kecil
1. Gunakan 3 lembar daun pandan (ikat satu per satu)
1. Ambil 2 ruas daun bawang (potong-potong agak panjang)
1. Sediakan 2 lembar daun jeruk (robek helainya)
1. Sediakan 2 buah tomat (potong wedgess)
1. Ambil 1/2 buah lemon ukuran sedang
1. Sediakan 10 sdm minyak goreng
1. Gunakan 300 ml air
1. Gunakan  Seasoning
1. Sediakan  Gula merah
1. Sediakan  Garam
1. Gunakan  Lada putih bubuk
1. Siapkan  Kaldu ayam bubuk
1. Sediakan  Bumbu Dasar Halus
1. Siapkan 7 siung bawang putih
1. Sediakan 14 siung bawang merah
1. Ambil 2 buah cabai merah besar
1. Ambil 3 ruas serai
1. Ambil 35 gr kunyit
1. Siapkan 20 gr jahe
1. Ambil 2 buah kemiri




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam Woku:

1. Haluskan bahan-bahan bumbu dasar menggunakan chopper. Jangan terlalu halus.
1. Panaskan minyak. Tumis bumbu halus bersama dengan serai geprek, daun kunyit, dan daun jeruk. Tumis sampai harum dan benar-benar matang.
1. Masukkan seasoning, disusul potongan tomat.
1. Masukkan sayap ayam. Aduk dengan hati-hati.
1. Setelah sayap setengah matang, masukkan potongan tenderloin. Aduk lagi perlahan.
1. Masukkan air, disusul daun pandan.
1. Setelah mendidih dan air agak menyusut (kuah bisa disesuaikan berdasarkan selera), masukkan perasan air lemon, koreksi rasa.
1. Kalau rasa sudah pas, masukkan daun kemangi dan daun bawang. Aduk rata.
1. Siap disajikan bersama nasi putih hangat.




Ternyata resep ayam woku yang lezat sederhana ini mudah sekali ya! Kita semua bisa memasaknya. Resep ayam woku Sangat sesuai banget untuk anda yang baru belajar memasak atau juga bagi kamu yang telah lihai dalam memasak.

Tertarik untuk mulai mencoba buat resep ayam woku mantab tidak ribet ini? Kalau mau, ayo kamu segera siapkan peralatan dan bahan-bahannya, lantas bikin deh Resep ayam woku yang mantab dan tidak ribet ini. Benar-benar gampang kan. 

Jadi, ketimbang anda diam saja, maka kita langsung saja bikin resep ayam woku ini. Dijamin kalian gak akan menyesal membuat resep ayam woku enak tidak ribet ini! Selamat berkreasi dengan resep ayam woku mantab sederhana ini di tempat tinggal kalian masing-masing,ya!.

