---
description: "Resep Ayam rica-rica kecap yang enak dan Mudah Dibuat"
title: "Resep Ayam rica-rica kecap yang enak dan Mudah Dibuat"
slug: 435-resep-ayam-rica-rica-kecap-yang-enak-dan-mudah-dibuat
date: 2021-03-01T11:08:17.760Z
image: https://img-global.cpcdn.com/recipes/933c1a988f8afca9/680x482cq70/ayam-rica-rica-kecap-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/933c1a988f8afca9/680x482cq70/ayam-rica-rica-kecap-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/933c1a988f8afca9/680x482cq70/ayam-rica-rica-kecap-foto-resep-utama.jpg
author: Lula Johnson
ratingvalue: 4.5
reviewcount: 3
recipeingredient:
- "1 kg ayam"
- " Jeruk nipis"
- " Kecap"
- "1 sdm Gula jawa"
- "3 batang Daun bawang iris 2 cm"
- "7 lembar Daun jeruk"
- " Kayu manis opsional"
- "1 batang sereh di geprek"
- " Penyedap"
- " Minyak goreng"
- " Bumbu halus"
- "8 siung Bawang merah"
- "6 siung Bawang putih"
- "2/3 sdm Ketumbar"
- "1 1/2 biji Kemiri"
- "1/2 sdt Merica"
- "1 ruas jahe"
- "1 ruas kunyit"
- "1 ruas lengkuas"
- "3 biji Kapulaga"
- "7 buah cabe keriting"
- "7 buah cabe rawit ini blm pedes bisa ditambah kl mau pedes"
recipeinstructions:
- "Siapkan bahan. Peras jeruk nipis diatas ayam untuk menghilangkan amis, lalu cuci ayamnya."
- "Bumbu halus semua diuleg sampe halus"
- "Tumis bumbu halus sampai agak matang. Lalu masukkan ayam aduk aduk sampe tercampur merata."
- "Masukan air, daun bawang, kayu manis, daun jeruk, gula jawa, kecap, penyedap. Aduk rata. Sesuaikan kecap dan penyedap agar rasanya passs. Bisa ditambahkan cabe rawit iris kalo kurang pedas yaa.  (difoto sebenernya aku kebanyakan air, kayanya lebih dari 100ml. Nah pas masukin air dikit demi dikit aja yaa, jgn kebanyakan, lama menguapnya. Kalo ayam lehor dia cepet empuk ayamnya, jadi diaduk2 aja. Kl ayam kampung agak lama, sesuai kan aja airnya)"
- "Tips biar bumbu meresap yaitu dimasak di api kecil ya guys. Aduk sesekali. Masak sampai tidak ada air tersisa. Selamat mencoba."
categories:
- Resep
tags:
- ayam
- ricarica
- kecap

katakunci: ayam ricarica kecap 
nutrition: 187 calories
recipecuisine: Indonesian
preptime: "PT10M"
cooktime: "PT52M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam rica-rica kecap](https://img-global.cpcdn.com/recipes/933c1a988f8afca9/680x482cq70/ayam-rica-rica-kecap-foto-resep-utama.jpg)

Sebagai seorang ibu, mempersiapkan masakan enak bagi keluarga tercinta merupakan suatu hal yang menggembirakan bagi anda sendiri. Kewajiban seorang ibu bukan hanya mengerjakan pekerjaan rumah saja, tapi anda juga harus menyediakan keperluan nutrisi tercukupi dan juga panganan yang disantap orang tercinta wajib enak.

Di era  sekarang, kamu sebenarnya dapat mengorder panganan siap saji meski tanpa harus ribet mengolahnya lebih dulu. Tapi ada juga lho orang yang selalu mau memberikan hidangan yang terenak untuk keluarganya. Karena, menyajikan masakan yang dibuat sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan sesuai dengan makanan kesukaan keluarga. 



Mungkinkah kamu seorang penyuka ayam rica-rica kecap?. Tahukah kamu, ayam rica-rica kecap adalah hidangan khas di Indonesia yang kini disenangi oleh banyak orang di berbagai wilayah di Nusantara. Kamu bisa membuat ayam rica-rica kecap kreasi sendiri di rumah dan boleh jadi santapan kesukaanmu di hari libur.

Kalian tidak perlu bingung untuk memakan ayam rica-rica kecap, sebab ayam rica-rica kecap tidak sukar untuk didapatkan dan juga kamu pun bisa membuatnya sendiri di tempatmu. ayam rica-rica kecap boleh diolah memalui berbagai cara. Kini pun ada banyak banget resep modern yang menjadikan ayam rica-rica kecap semakin lebih mantap.

Resep ayam rica-rica kecap pun sangat mudah dihidangkan, lho. Kita jangan capek-capek untuk memesan ayam rica-rica kecap, sebab Kita bisa menyajikan di rumah sendiri. Untuk Kita yang ingin mencobanya, dibawah ini merupakan resep untuk menyajikan ayam rica-rica kecap yang lezat yang bisa Kamu buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Ayam rica-rica kecap:

1. Ambil 1 kg ayam
1. Gunakan  Jeruk nipis
1. Sediakan  Kecap
1. Ambil 1 sdm Gula jawa
1. Gunakan 3 batang Daun bawang iris 2 cm
1. Ambil 7 lembar Daun jeruk
1. Gunakan  Kayu manis (opsional)
1. Gunakan 1 batang sereh di geprek
1. Sediakan  Penyedap
1. Sediakan  Minyak goreng
1. Ambil  Bumbu halus
1. Gunakan 8 siung Bawang merah
1. Gunakan 6 siung Bawang putih
1. Ambil 2/3 sdm Ketumbar
1. Ambil 1 1/2 biji Kemiri
1. Ambil 1/2 sdt Merica
1. Gunakan 1 ruas jahe
1. Siapkan 1 ruas kunyit
1. Sediakan 1 ruas lengkuas
1. Siapkan 3 biji Kapulaga
1. Siapkan 7 buah cabe keriting
1. Gunakan 7 buah cabe rawit (ini blm pedes, bisa ditambah kl mau pedes)




<!--inarticleads2-->

##### Cara menyiapkan Ayam rica-rica kecap:

1. Siapkan bahan. Peras jeruk nipis diatas ayam untuk menghilangkan amis, lalu cuci ayamnya.
1. Bumbu halus semua diuleg sampe halus
1. Tumis bumbu halus sampai agak matang. Lalu masukkan ayam aduk aduk sampe tercampur merata.
1. Masukan air, daun bawang, kayu manis, daun jeruk, gula jawa, kecap, penyedap. Aduk rata. Sesuaikan kecap dan penyedap agar rasanya passs. Bisa ditambahkan cabe rawit iris kalo kurang pedas yaa. -  (difoto sebenernya aku kebanyakan air, kayanya lebih dari 100ml. Nah pas masukin air dikit demi dikit aja yaa, jgn kebanyakan, lama menguapnya. Kalo ayam lehor dia cepet empuk ayamnya, jadi diaduk2 aja. Kl ayam kampung agak lama, sesuai kan aja airnya)
1. Tips biar bumbu meresap yaitu dimasak di api kecil ya guys. Aduk sesekali. Masak sampai tidak ada air tersisa. Selamat mencoba.




Wah ternyata resep ayam rica-rica kecap yang mantab sederhana ini gampang sekali ya! Kita semua dapat membuatnya. Resep ayam rica-rica kecap Sesuai banget buat kalian yang baru akan belajar memasak atau juga untuk kamu yang sudah ahli memasak.

Tertarik untuk mencoba membikin resep ayam rica-rica kecap nikmat tidak rumit ini? Kalau kamu tertarik, mending kamu segera menyiapkan alat dan bahan-bahannya, setelah itu buat deh Resep ayam rica-rica kecap yang mantab dan tidak ribet ini. Betul-betul gampang kan. 

Maka, ketimbang kita diam saja, yuk kita langsung saja hidangkan resep ayam rica-rica kecap ini. Pasti anda gak akan menyesal sudah membuat resep ayam rica-rica kecap mantab sederhana ini! Selamat berkreasi dengan resep ayam rica-rica kecap lezat tidak rumit ini di tempat tinggal kalian sendiri,ya!.

