---
description: "Resep Ayam + hati ayam masak cabe hijau Sederhana dan Mudah Dibuat"
title: "Resep Ayam + hati ayam masak cabe hijau Sederhana dan Mudah Dibuat"
slug: 280-resep-ayam-hati-ayam-masak-cabe-hijau-sederhana-dan-mudah-dibuat
date: 2021-02-25T21:43:02.945Z
image: https://img-global.cpcdn.com/recipes/89194f9b425716e4/680x482cq70/ayam-hati-ayam-masak-cabe-hijau-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/89194f9b425716e4/680x482cq70/ayam-hati-ayam-masak-cabe-hijau-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/89194f9b425716e4/680x482cq70/ayam-hati-ayam-masak-cabe-hijau-foto-resep-utama.jpg
author: Janie Parsons
ratingvalue: 4.2
reviewcount: 3
recipeingredient:
- "1/2 ekor ayam"
- "3 hati ayam  ampela"
- "8 siung bawang merah"
- "5 siung bawang putih"
- "8 cabe hijau besar bagusnya sih 15 cabe atau sesuai selera"
- "10 cabe rawit tergantung selera"
- "2 tomat merah ukuran sedang harus tomat hijau 34 buah"
- "2 batang serai geprek"
- "3 lembar daun salam"
- "5 lembar daun jeruk"
- "1 lembar daun kunyit"
- "1 cm kunyit"
- "1 cm jahe"
- "1 cm lengkuas"
- "3 biji kemiri"
- "1/2 sdm ketumbar"
- "1/2 sdm merica"
- "2 asam gandis boleh pake air asam jawa"
- " Penyedap"
- " Gula"
- " Minyak goreng"
- " Air bersih"
recipeinstructions:
- "Bersihkan ayam dan jeroannya, lalu potong sesuai selera, saya rebus jeroannya dulu yah biar gak bau amis, bisa direbus langsung atau ditambah garam dan daun jeruk"
- "Haluskan bawang, jahe, lengkuas, kunyit, kemiri, tomat dan cabe lalu tumis hingga wangi lalu masukan serai, daun jeruk, daun salam tumis hingga mateng"
- "Masukan ayam dan jeroan, dan asam aduk hingga bumbu tercampur rata, lalu tambah air secukupnya, masak hingga air berkurang setengah tambahakn penyedap, garam, gula, ketumbar, merica (atau ini ditambah pas lagi numis bumbu juga gpp)"
- "Koreksi rasa, masak hingga matang dan daging ayam empuk, angkat dan sajikan dengan nasi hangat"
categories:
- Resep
tags:
- ayam
- 
- hati

katakunci: ayam  hati 
nutrition: 144 calories
recipecuisine: Indonesian
preptime: "PT40M"
cooktime: "PT49M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam + hati ayam masak cabe hijau](https://img-global.cpcdn.com/recipes/89194f9b425716e4/680x482cq70/ayam-hati-ayam-masak-cabe-hijau-foto-resep-utama.jpg)

Sebagai seorang ibu, mempersiapkan olahan enak pada orang tercinta adalah hal yang membahagiakan bagi kita sendiri. Kewajiban seorang  wanita Tidak saja mengatur rumah saja, tetapi anda juga harus menyediakan keperluan gizi terpenuhi dan juga masakan yang dikonsumsi keluarga tercinta harus sedap.

Di waktu  saat ini, anda memang bisa memesan santapan instan meski tanpa harus ribet membuatnya terlebih dahulu. Tapi banyak juga orang yang selalu ingin memberikan hidangan yang terenak untuk orang yang dicintainya. Lantaran, menghidangkan masakan yang diolah sendiri akan jauh lebih higienis dan bisa menyesuaikan hidangan tersebut sesuai selera famili. 



Apakah anda salah satu penyuka ayam + hati ayam masak cabe hijau?. Asal kamu tahu, ayam + hati ayam masak cabe hijau adalah makanan khas di Nusantara yang sekarang disenangi oleh orang-orang dari hampir setiap daerah di Indonesia. Kalian dapat menyajikan ayam + hati ayam masak cabe hijau olahan sendiri di rumahmu dan boleh jadi santapan kegemaranmu di akhir pekan.

Kalian tidak usah bingung jika kamu ingin memakan ayam + hati ayam masak cabe hijau, karena ayam + hati ayam masak cabe hijau tidak sukar untuk didapatkan dan juga kalian pun bisa menghidangkannya sendiri di tempatmu. ayam + hati ayam masak cabe hijau dapat dibuat lewat berbagai cara. Sekarang sudah banyak sekali resep modern yang menjadikan ayam + hati ayam masak cabe hijau lebih lezat.

Resep ayam + hati ayam masak cabe hijau pun mudah untuk dibuat, lho. Kamu tidak usah repot-repot untuk memesan ayam + hati ayam masak cabe hijau, karena Kalian mampu menyajikan sendiri di rumah. Bagi Kita yang hendak membuatnya, berikut cara untuk menyajikan ayam + hati ayam masak cabe hijau yang mantab yang dapat Kita hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Ayam + hati ayam masak cabe hijau:

1. Siapkan 1/2 ekor ayam
1. Siapkan 3 hati ayam + ampela
1. Sediakan 8 siung bawang merah
1. Siapkan 5 siung bawang putih
1. Gunakan 8 cabe hijau besar (bagusnya sih 15 cabe atau sesuai selera)
1. Ambil 10 cabe rawit (tergantung selera)
1. Sediakan 2 tomat merah ukuran sedang (harus tomat hijau 3-4 buah)
1. Gunakan 2 batang serai (geprek)
1. Sediakan 3 lembar daun salam
1. Siapkan 5 lembar daun jeruk
1. Siapkan 1 lembar daun kunyit
1. Siapkan 1 cm kunyit
1. Siapkan 1 cm jahe
1. Siapkan 1 cm lengkuas
1. Sediakan 3 biji kemiri
1. Siapkan 1/2 sdm ketumbar
1. Gunakan 1/2 sdm merica
1. Ambil 2 asam gandis (boleh pake air asam jawa)
1. Siapkan  Penyedap
1. Ambil  Gula
1. Gunakan  Minyak goreng
1. Ambil  Air bersih




<!--inarticleads2-->

##### Cara membuat Ayam + hati ayam masak cabe hijau:

1. Bersihkan ayam dan jeroannya, lalu potong sesuai selera, saya rebus jeroannya dulu yah biar gak bau amis, bisa direbus langsung atau ditambah garam dan daun jeruk
1. Haluskan bawang, jahe, lengkuas, kunyit, kemiri, tomat dan cabe lalu tumis hingga wangi lalu masukan serai, daun jeruk, daun salam tumis hingga mateng
1. Masukan ayam dan jeroan, dan asam aduk hingga bumbu tercampur rata, lalu tambah air secukupnya, masak hingga air berkurang setengah tambahakn penyedap, garam, gula, ketumbar, merica (atau ini ditambah pas lagi numis bumbu juga gpp)
1. Koreksi rasa, masak hingga matang dan daging ayam empuk, angkat dan sajikan dengan nasi hangat




Wah ternyata cara membuat ayam + hati ayam masak cabe hijau yang nikamt tidak rumit ini gampang banget ya! Anda Semua bisa membuatnya. Cara Membuat ayam + hati ayam masak cabe hijau Sangat cocok banget untuk kalian yang baru mau belajar memasak maupun bagi kalian yang telah lihai memasak.

Apakah kamu mau mencoba membikin resep ayam + hati ayam masak cabe hijau nikmat tidak rumit ini? Kalau kamu mau, ayo kamu segera siapkan alat dan bahan-bahannya, maka buat deh Resep ayam + hati ayam masak cabe hijau yang mantab dan tidak ribet ini. Betul-betul gampang kan. 

Maka, ketimbang kalian berlama-lama, yuk langsung aja buat resep ayam + hati ayam masak cabe hijau ini. Dijamin kamu tak akan nyesel sudah membuat resep ayam + hati ayam masak cabe hijau nikmat tidak rumit ini! Selamat berkreasi dengan resep ayam + hati ayam masak cabe hijau enak tidak ribet ini di rumah sendiri,oke!.

