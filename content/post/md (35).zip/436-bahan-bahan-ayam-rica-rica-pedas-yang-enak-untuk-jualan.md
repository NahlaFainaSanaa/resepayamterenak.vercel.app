---
description: "Bahan-bahan Ayam rica-rica pedas yang enak Untuk Jualan"
title: "Bahan-bahan Ayam rica-rica pedas yang enak Untuk Jualan"
slug: 436-bahan-bahan-ayam-rica-rica-pedas-yang-enak-untuk-jualan
date: 2021-02-02T22:29:23.018Z
image: https://img-global.cpcdn.com/recipes/ffc710da4f3ad51f/680x482cq70/ayam-rica-rica-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ffc710da4f3ad51f/680x482cq70/ayam-rica-rica-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ffc710da4f3ad51f/680x482cq70/ayam-rica-rica-pedas-foto-resep-utama.jpg
author: Lizzie Alvarez
ratingvalue: 3.1
reviewcount: 9
recipeingredient:
- "2 ekor ayam"
- " Bumbu halus diblenderdiulek"
- "2 buah Tomat"
- "1 ruas Jahe"
- "2 ruas Kunyit"
- "6 butir Kemiri"
- "9 siung Bawang merah"
- "2 siung bawang putih"
- "1,5 ons cabe merah"
- "15 biji cabe rawit merah"
- " Bahan pelengkap"
- "15 biji Cabe rawit hijau"
- "1 batang daun bawang"
- "2 lembar daun salam"
- "1 lembar daun kunyit"
- "10 lembar daun jeruk"
- "1 batang sere"
- "1 ruas lengkuas"
- "1 ikat daun kemangi dimasukan saat ayam matang"
recipeinstructions:
- "Ayam yg sudah dipotong di marinasi dengan perasan jeruk selama 20menit. Sambilan buat bumbu halus ssesuai keterangan resep."
- "Langkah awal masukan minyak goreng secukupnya (sesuai byknya bumbu halus yg akan ditumis).. *Masukan cabe rawit dan daun bawang yg sudah di iris sedang (tdk tebal tdk tipis).  *Jika cabe sudah sedikit layu masukan bumbu halus yg sudah diblender/diulek. *setelah wangi masukan seluruh bahan2 pelengkap (dedaunan) kecuali kemangi dan masukan bumbu seperti garam 2 sdt-gula 1sdt-kaldu jamur 1/2sdt. Dirasa2, jika kurang bs tambahkan sesuai selera."
- "Aduk sebentar...  masukan ayam yg sudah dimarinasi. Tambahkan air 350-450ml. Disarankan 450ml jk menggunakan ayam kampung, dan 350ml jk menggunakan ayam negeri biasa.   Ungkep ayam selama 40menit-1 jam. Smpe kuah mengental dan ayam lembut. Masukan daun kemangi yg sdh dipetik daunnya. Ayam rica2 siap dihidangkan..."
categories:
- Resep
tags:
- ayam
- ricarica
- pedas

katakunci: ayam ricarica pedas 
nutrition: 144 calories
recipecuisine: Indonesian
preptime: "PT31M"
cooktime: "PT51M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam rica-rica pedas](https://img-global.cpcdn.com/recipes/ffc710da4f3ad51f/680x482cq70/ayam-rica-rica-pedas-foto-resep-utama.jpg)

Sebagai seorang orang tua, menyuguhkan santapan nikmat bagi orang tercinta merupakan suatu hal yang sangat menyenangkan untuk anda sendiri. Peran seorang  wanita bukan sekedar mengatur rumah saja, tapi anda pun wajib memastikan keperluan gizi terpenuhi dan juga hidangan yang dikonsumsi keluarga tercinta mesti enak.

Di zaman  saat ini, kita memang mampu membeli masakan jadi meski tidak harus ribet mengolahnya terlebih dahulu. Tapi banyak juga orang yang selalu ingin menyajikan yang terenak bagi orang yang dicintainya. Karena, memasak yang diolah sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan sesuai selera keluarga tercinta. 



Apakah anda adalah salah satu penggemar ayam rica-rica pedas?. Tahukah kamu, ayam rica-rica pedas adalah hidangan khas di Nusantara yang kini disenangi oleh orang-orang dari hampir setiap tempat di Nusantara. Anda bisa menghidangkan ayam rica-rica pedas hasil sendiri di rumahmu dan pasti jadi makanan favoritmu di akhir pekan.

Kalian tidak usah bingung jika kamu ingin memakan ayam rica-rica pedas, sebab ayam rica-rica pedas sangat mudah untuk ditemukan dan kamu pun bisa memasaknya sendiri di rumah. ayam rica-rica pedas bisa diolah memalui beraneka cara. Saat ini ada banyak resep modern yang membuat ayam rica-rica pedas semakin nikmat.

Resep ayam rica-rica pedas juga gampang untuk dibuat, lho. Anda tidak usah repot-repot untuk memesan ayam rica-rica pedas, karena Kamu mampu menghidangkan ditempatmu. Untuk Anda yang akan mencobanya, dibawah ini merupakan cara membuat ayam rica-rica pedas yang mantab yang bisa Kita buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Ayam rica-rica pedas:

1. Siapkan 2 ekor ayam
1. Sediakan  Bumbu halus diblender/diulek
1. Gunakan 2 buah Tomat
1. Gunakan 1 ruas Jahe
1. Sediakan 2 ruas Kunyit
1. Siapkan 6 butir Kemiri
1. Gunakan 9 siung Bawang merah
1. Ambil 2 siung bawang putih
1. Gunakan 1,5 ons cabe merah
1. Sediakan 15 biji cabe rawit merah
1. Siapkan  Bahan pelengkap
1. Gunakan 15 biji Cabe rawit hijau
1. Gunakan 1 batang daun bawang
1. Ambil 2 lembar daun salam
1. Ambil 1 lembar daun kunyit
1. Gunakan 10 lembar daun jeruk
1. Ambil 1 batang sere
1. Ambil 1 ruas lengkuas
1. Siapkan 1 ikat daun kemangi (dimasukan saat ayam matang)




<!--inarticleads2-->

##### Cara menyiapkan Ayam rica-rica pedas:

1. Ayam yg sudah dipotong di marinasi dengan perasan jeruk selama 20menit. Sambilan buat bumbu halus ssesuai keterangan resep.
1. Langkah awal masukan minyak goreng secukupnya (sesuai byknya bumbu halus yg akan ditumis).. - *Masukan cabe rawit dan daun bawang yg sudah di iris sedang (tdk tebal tdk tipis).  - *Jika cabe sudah sedikit layu masukan bumbu halus yg sudah diblender/diulek. - *setelah wangi masukan seluruh bahan2 pelengkap (dedaunan) kecuali kemangi dan masukan bumbu seperti garam 2 sdt-gula 1sdt-kaldu jamur 1/2sdt. Dirasa2, jika kurang bs tambahkan sesuai selera.
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Ayam rica-rica pedas">1. Aduk sebentar...  - masukan ayam yg sudah dimarinasi. Tambahkan air 350-450ml. Disarankan 450ml jk menggunakan ayam kampung, dan 350ml jk menggunakan ayam negeri biasa.  -  - Ungkep ayam selama 40menit-1 jam. Smpe kuah mengental dan ayam lembut. Masukan daun kemangi yg sdh dipetik daunnya. Ayam rica2 siap dihidangkan...




Ternyata cara buat ayam rica-rica pedas yang nikamt tidak ribet ini mudah sekali ya! Semua orang bisa membuatnya. Resep ayam rica-rica pedas Sangat sesuai banget untuk anda yang baru belajar memasak maupun juga bagi anda yang sudah pandai memasak.

Tertarik untuk mulai mencoba membuat resep ayam rica-rica pedas lezat sederhana ini? Kalau tertarik, ayo kalian segera menyiapkan alat-alat dan bahan-bahannya, kemudian buat deh Resep ayam rica-rica pedas yang nikmat dan tidak rumit ini. Sangat gampang kan. 

Maka dari itu, daripada kamu diam saja, yuk langsung aja sajikan resep ayam rica-rica pedas ini. Dijamin kamu tak akan nyesel sudah membuat resep ayam rica-rica pedas enak sederhana ini! Selamat mencoba dengan resep ayam rica-rica pedas lezat sederhana ini di rumah masing-masing,ya!.

