---
description: "Resep Ayam Woku Kemangi yang nikmat dan Mudah Dibuat"
title: "Resep Ayam Woku Kemangi yang nikmat dan Mudah Dibuat"
slug: 398-resep-ayam-woku-kemangi-yang-nikmat-dan-mudah-dibuat
date: 2021-06-15T17:30:19.376Z
image: https://img-global.cpcdn.com/recipes/db937e948b1d1597/680x482cq70/ayam-woku-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/db937e948b1d1597/680x482cq70/ayam-woku-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/db937e948b1d1597/680x482cq70/ayam-woku-kemangi-foto-resep-utama.jpg
author: Mark Maldonado
ratingvalue: 4.1
reviewcount: 12
recipeingredient:
- "  BAHAN "
- "1.000 ml Air Mineral"
- "1 Ekor Ayam Kampung potong jd beberapa bagian me Ayam Negri"
- "1/2 buah Jeruk lemon atau Nipis"
- "  BUMBU HALUS "
- "10 buah Cabe Merah Keriting sesuai selera"
- "8 buah Cabe Rawit Oren sesuai selera"
- "7 butir Bawang Merah"
- "4 siung Bawang Putih"
- "4 butir Kemiri disangrai dulu"
- "1 ruas jari Jahe"
- "1 ruas jari Kunyit"
- "  BUMBU LAINNYA "
- "5 lembar Daun Jeruk iris kasar me disobek"
- "3 lembar Daun Salam"
- "3 batang Sereh geprek"
- "3 ikat Daun Kemangi petikin daunnya"
- "2 sdm Kaldu Instant"
- "1 buah Tomat iris  iris"
- "1 batang Daun Bawang iris kasar"
- "1 sdt Lada bubuk"
- "1 sdm peres Gula pasir"
- "1/2 sdt Garam"
- "Secukupnya Minyak goreng untuk menumis"
recipeinstructions:
- "Siapkan semua bahan. Cuci bersih ayam lalu Lumuri ayam dengan jeruk lemon atau nipis. Diamkan sekitar 15 menit. Setelah itu bilas. Sisihkan. Kemudian iris-iris tomat dan daun bawang. Sisihkan."
- "Uleg atau Blender bahan bumbu halus."
- "Tumis bumbu halus tersebut sampai harum. Lalu masukkan sereh, daun salam dan daun jeruk."
- "Setelah itu masukkan ayam dan air mineral. Aduk rata."
- "Tambahkan Penyedap rasa / kaldu instant, Lada bubuk, gula pasir dan garam halus. Kemudian masukkan irisan tomat dan daun kemangi. Aduk rata."
- "Terakhir, masukkan irisan daun bawang. Masak sampai ayam matang. Jangan lupa tes rasa sampai bumbu dirasa sudah pas. Angkat."
- "Sajikan."
categories:
- Resep
tags:
- ayam
- woku
- kemangi

katakunci: ayam woku kemangi 
nutrition: 280 calories
recipecuisine: Indonesian
preptime: "PT17M"
cooktime: "PT52M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam Woku Kemangi](https://img-global.cpcdn.com/recipes/db937e948b1d1597/680x482cq70/ayam-woku-kemangi-foto-resep-utama.jpg)

Sebagai seorang istri, mempersiapkan hidangan nikmat kepada famili merupakan suatu hal yang memuaskan bagi kita sendiri. Tugas seorang  wanita Tidak hanya mengatur rumah saja, namun anda juga harus memastikan kebutuhan gizi terpenuhi dan juga santapan yang dikonsumsi keluarga tercinta mesti sedap.

Di era  saat ini, anda memang dapat mengorder hidangan jadi meski tidak harus ribet memasaknya dulu. Namun ada juga mereka yang selalu ingin memberikan yang terlezat untuk keluarganya. Pasalnya, memasak yang dibuat sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan berdasarkan selera orang tercinta. 



Apakah anda merupakan seorang penyuka ayam woku kemangi?. Tahukah kamu, ayam woku kemangi merupakan makanan khas di Nusantara yang saat ini digemari oleh banyak orang dari hampir setiap daerah di Indonesia. Kalian bisa membuat ayam woku kemangi olahan sendiri di rumah dan dapat dijadikan camilan kesenanganmu di akhir pekan.

Kamu jangan bingung untuk menyantap ayam woku kemangi, karena ayam woku kemangi sangat mudah untuk didapatkan dan kita pun dapat menghidangkannya sendiri di rumah. ayam woku kemangi boleh diolah dengan berbagai cara. Kini pun sudah banyak banget cara modern yang menjadikan ayam woku kemangi semakin lebih mantap.

Resep ayam woku kemangi pun mudah dibikin, lho. Anda tidak perlu repot-repot untuk membeli ayam woku kemangi, sebab Kita bisa menghidangkan di rumah sendiri. Bagi Kamu yang akan membuatnya, dibawah ini merupakan cara menyajikan ayam woku kemangi yang nikamat yang mampu Kita coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Ayam Woku Kemangi:

1. Siapkan  🌿 BAHAN 🌿
1. Sediakan 1.000 ml Air Mineral
1. Siapkan 1 Ekor Ayam Kampung, potong jd beberapa bagian (me: Ayam Negri)
1. Siapkan 1/2 buah Jeruk lemon atau Nipis
1. Siapkan  🌿 BUMBU HALUS 🌿
1. Sediakan 10 buah Cabe Merah Keriting (sesuai selera)
1. Sediakan 8 buah Cabe Rawit Oren (sesuai selera)
1. Gunakan 7 butir Bawang Merah
1. Siapkan 4 siung Bawang Putih
1. Ambil 4 butir Kemiri, disangrai dulu
1. Ambil 1 ruas jari Jahe
1. Ambil 1 ruas jari Kunyit
1. Gunakan  🌿 BUMBU LAINNYA 🌿
1. Gunakan 5 lembar Daun Jeruk, iris kasar (me: disobek)
1. Ambil 3 lembar Daun Salam
1. Ambil 3 batang Sereh, geprek
1. Siapkan 3 ikat Daun Kemangi, petikin daunnya
1. Ambil 2 sdm Kaldu Instant
1. Ambil 1 buah Tomat, iris - iris
1. Gunakan 1 batang Daun Bawang, iris kasar
1. Siapkan 1 sdt Lada bubuk
1. Gunakan 1 sdm peres Gula pasir
1. Sediakan 1/2 sdt Garam
1. Gunakan Secukupnya Minyak goreng untuk menumis




<!--inarticleads2-->

##### Cara membuat Ayam Woku Kemangi:

1. Siapkan semua bahan. Cuci bersih ayam lalu Lumuri ayam dengan jeruk lemon atau nipis. Diamkan sekitar 15 menit. Setelah itu bilas. Sisihkan. Kemudian iris-iris tomat dan daun bawang. Sisihkan.
1. Uleg atau Blender bahan bumbu halus.
1. Tumis bumbu halus tersebut sampai harum. Lalu masukkan sereh, daun salam dan daun jeruk.
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Ayam Woku Kemangi">1. Setelah itu masukkan ayam dan air mineral. Aduk rata.
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Ayam Woku Kemangi">1. Tambahkan Penyedap rasa / kaldu instant, Lada bubuk, gula pasir dan garam halus. Kemudian masukkan irisan tomat dan daun kemangi. Aduk rata.
1. Terakhir, masukkan irisan daun bawang. Masak sampai ayam matang. Jangan lupa tes rasa sampai bumbu dirasa sudah pas. Angkat.
1. Sajikan.




Wah ternyata resep ayam woku kemangi yang lezat tidak rumit ini mudah sekali ya! Anda Semua mampu menghidangkannya. Cara Membuat ayam woku kemangi Sesuai banget untuk kita yang sedang belajar memasak ataupun untuk kalian yang telah jago dalam memasak.

Apakah kamu mau mulai mencoba bikin resep ayam woku kemangi mantab sederhana ini? Kalau kamu tertarik, mending kamu segera siapkan peralatan dan bahannya, lantas buat deh Resep ayam woku kemangi yang nikmat dan tidak ribet ini. Benar-benar taidak sulit kan. 

Oleh karena itu, daripada anda diam saja, hayo langsung aja hidangkan resep ayam woku kemangi ini. Pasti anda tiidak akan menyesal membuat resep ayam woku kemangi enak tidak rumit ini! Selamat berkreasi dengan resep ayam woku kemangi mantab sederhana ini di tempat tinggal sendiri,ya!.

