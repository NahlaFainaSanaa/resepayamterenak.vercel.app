---
description: "Cara buat Woku Ayam khas Manado yang enak dan Mudah Dibuat"
title: "Cara buat Woku Ayam khas Manado yang enak dan Mudah Dibuat"
slug: 393-cara-buat-woku-ayam-khas-manado-yang-enak-dan-mudah-dibuat
date: 2021-04-30T16:55:32.453Z
image: https://img-global.cpcdn.com/recipes/d55c05341a59da20/680x482cq70/woku-ayam-khas-manado-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d55c05341a59da20/680x482cq70/woku-ayam-khas-manado-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d55c05341a59da20/680x482cq70/woku-ayam-khas-manado-foto-resep-utama.jpg
author: Ellen Frank
ratingvalue: 4.5
reviewcount: 14
recipeingredient:
- "1 kg ayampotong kecil"
- "3 buah kentangtambahan saya"
- "5 ikat kemangidipetiki"
- "1 buah jerukdiperas"
- "15 buah cabe rawit"
- "secukupnya Garam merica gularoyco"
- " Bumbu Halus "
- "9 siung bawang merah"
- "5 Siung bawang putih"
- "1 rj kunyit"
- "3 buah Kemiridigoreng dulu"
- "2 rj Jahe"
- "5 buah Cabe merah"
- " Bahan yang diiris "
- "7 lbr daun jeruk iris tipis halus"
- "2 buah Tomat belah empat"
- "2 lbr daun pandan disimpul saja"
- "2 lbr daun kunyitdisimpul saja"
- "2 btg sereh geprek"
- "1 jempol laos geprek"
- "2 lbr Daun salam"
- "2 lbr daun bawang iris tipis"
recipeinstructions:
- "Ayam dan kentang digoreng setengah matang."
- "Bumbu dihaluskan"
- "Panaskan minyak goreng, bumbu halus, tambahkan daun pandan,serai,daun kunyit,tumis sampai wangi."
- "Masukan ayam,gula garam,lada,royco dan air, masak sampai air sat dan bumbu meresap"
- "Tambahkan kentang,daun bawang dan kemangi"
- "Tes rasa dan sajikan"
categories:
- Resep
tags:
- woku
- ayam
- khas

katakunci: woku ayam khas 
nutrition: 229 calories
recipecuisine: Indonesian
preptime: "PT35M"
cooktime: "PT48M"
recipeyield: "3"
recipecategory: Dessert

---


![Woku Ayam khas Manado](https://img-global.cpcdn.com/recipes/d55c05341a59da20/680x482cq70/woku-ayam-khas-manado-foto-resep-utama.jpg)

Sebagai seorang wanita, menyuguhkan masakan menggugah selera bagi keluarga adalah hal yang membahagiakan untuk kita sendiri. Peran seorang ibu bukan sekedar menjaga rumah saja, namun kamu pun harus menyediakan kebutuhan gizi terpenuhi dan santapan yang disantap keluarga tercinta mesti mantab.

Di era  saat ini, anda sebenarnya dapat mengorder olahan instan meski tidak harus susah membuatnya dulu. Tapi ada juga orang yang selalu mau memberikan yang terbaik untuk keluarganya. Pasalnya, menyajikan masakan yang diolah sendiri jauh lebih higienis dan bisa menyesuaikan sesuai selera orang tercinta. 



Mungkinkah anda merupakan seorang penyuka woku ayam khas manado?. Tahukah kamu, woku ayam khas manado adalah sajian khas di Nusantara yang kini disukai oleh kebanyakan orang di hampir setiap wilayah di Nusantara. Kalian bisa menyajikan woku ayam khas manado sendiri di rumahmu dan pasti jadi camilan kesenanganmu di akhir pekan.

Kamu tak perlu bingung jika kamu ingin menyantap woku ayam khas manado, sebab woku ayam khas manado gampang untuk dicari dan kalian pun boleh mengolahnya sendiri di tempatmu. woku ayam khas manado dapat dimasak memalui bermacam cara. Saat ini ada banyak banget resep modern yang menjadikan woku ayam khas manado lebih nikmat.

Resep woku ayam khas manado pun gampang dibikin, lho. Anda tidak perlu repot-repot untuk memesan woku ayam khas manado, karena Kalian dapat menyajikan di rumahmu. Bagi Kalian yang ingin menyajikannya, di bawah ini adalah resep untuk menyajikan woku ayam khas manado yang mantab yang dapat Kita coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Woku Ayam khas Manado:

1. Gunakan 1 kg ayam(potong kecil)
1. Gunakan 3 buah kentang(tambahan saya)
1. Gunakan 5 ikat kemangi(dipetiki)
1. Siapkan 1 buah jeruk,(diperas)
1. Ambil 15 buah cabe rawit
1. Ambil secukupnya Garam, merica, gula,royco
1. Siapkan  Bumbu Halus :
1. Gunakan 9 siung bawang merah
1. Ambil 5 Siung bawang putih
1. Sediakan 1 rj kunyit
1. Gunakan 3 buah Kemiri(digoreng dulu)
1. Sediakan 2 rj Jahe
1. Ambil 5 buah Cabe merah
1. Ambil  Bahan yang diiris :
1. Gunakan 7 lbr daun jeruk (iris tipis halus)
1. Siapkan 2 buah Tomat (belah empat)
1. Siapkan 2 lbr daun pandan (disimpul saja)
1. Sediakan 2 lbr daun kunyit(disimpul saja)
1. Gunakan 2 btg sereh (geprek)
1. Siapkan 1 jempol laos (geprek)
1. Ambil 2 lbr Daun salam
1. Sediakan 2 lbr daun bawang (iris tipis)




<!--inarticleads2-->

##### Langkah-langkah membuat Woku Ayam khas Manado:

1. Ayam dan kentang digoreng setengah matang.
1. Bumbu dihaluskan
1. Panaskan minyak goreng, bumbu halus, tambahkan daun pandan,serai,daun kunyit,tumis sampai wangi.
1. Masukan ayam,gula garam,lada,royco dan air, masak sampai air sat dan bumbu meresap
1. Tambahkan kentang,daun bawang dan kemangi
1. Tes rasa dan sajikan




Ternyata cara buat woku ayam khas manado yang mantab tidak rumit ini enteng sekali ya! Anda Semua bisa menghidangkannya. Cara Membuat woku ayam khas manado Sesuai sekali untuk kalian yang sedang belajar memasak maupun bagi anda yang telah hebat dalam memasak.

Apakah kamu mau mulai mencoba membuat resep woku ayam khas manado enak tidak ribet ini? Kalau kalian mau, ayo kamu segera siapkan peralatan dan bahan-bahannya, lalu buat deh Resep woku ayam khas manado yang enak dan sederhana ini. Sangat mudah kan. 

Maka, ketimbang kalian diam saja, yuk langsung aja buat resep woku ayam khas manado ini. Dijamin kalian tiidak akan menyesal sudah buat resep woku ayam khas manado lezat tidak ribet ini! Selamat mencoba dengan resep woku ayam khas manado nikmat tidak rumit ini di tempat tinggal kalian masing-masing,oke!.

