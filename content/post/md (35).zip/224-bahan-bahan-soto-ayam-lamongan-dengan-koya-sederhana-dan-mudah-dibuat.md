---
description: "Bahan-bahan Soto Ayam Lamongan Dengan Koya Sederhana dan Mudah Dibuat"
title: "Bahan-bahan Soto Ayam Lamongan Dengan Koya Sederhana dan Mudah Dibuat"
slug: 224-bahan-bahan-soto-ayam-lamongan-dengan-koya-sederhana-dan-mudah-dibuat
date: 2021-05-06T20:03:10.954Z
image: https://img-global.cpcdn.com/recipes/b39f1f8f4c1121bf/680x482cq70/soto-ayam-lamongan-dengan-koya-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b39f1f8f4c1121bf/680x482cq70/soto-ayam-lamongan-dengan-koya-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b39f1f8f4c1121bf/680x482cq70/soto-ayam-lamongan-dengan-koya-foto-resep-utama.jpg
author: Nina Swanson
ratingvalue: 4.5
reviewcount: 13
recipeingredient:
- "1 ekor ayam kampung"
- "1 buah jeruk nipis"
- "2 batang sereh geprek"
- "2 cm lengkuas geprek"
- "5 lembar daun jeruk"
- "2 lembar daun salam"
- "2 barang daun bawang prei"
- "1 sdm garam"
- "1 sdt kaldu jamur"
- "2 sdt gula pasir"
- "1/2 sdt merica bubuk"
- "1 sdt bawang putih goreng remas"
- "secukupnya air kurang lebih 112 liter"
- "secukupnya minyak goreng untuk menumis"
- " Bumbu Halus "
- "6 siung bawang merah"
- "6 siung bawang putih"
- "4 butir kemiri sangrai"
- "3 cm jahe"
- "3 cm kunyit"
- "1 sdt ketumbar bubuk"
- "1/4 sdt jinten"
- " Pelengkap "
- " Soun"
- " Telur rebus"
- " Kol"
- " Koya 4 krupuk udang besar  1 sdm bawang putih goreng"
- " Jeruk nipis"
- " Seledri"
- " Sambal"
- " Bawang goreng"
- " Kecambah pendek"
recipeinstructions:
- "Ayam yang sudah di potong dan di cuci bersih di beri perasan air jeruk nipis, diamkan 15 menit lalu bilas....siapkan bumbu cemplungnya, sereh dan lengkuas di geprek, daun jeruk dibuang tulang daunnya."
- "Didihkan air dalam panci...bila sudah mendidih masukkan ayamnya....masukkan juga bumbu cemplungnya (sereh, daun salam, lengkuas dan daun jeruk), masak dengan api sedang cenderung kecil."
- "Siapkan semua bahan untuk membuat bumbu halusnya... haluskan bumbu bisa diulek atau blender...... jika di blender tambahkan minyak goreng agar mudah halusnya."
- "Tumis bumbu halus sampai wangi....lalu beri irisan daun bawang prei (1 batang), aduk rata....masukkan tumisan bumbu ke panci yang berisi ayam."
- "Lalu masukkan garam....masukkan gula pasir....masukkan merica bubuknya."
- "Masukkan juga kaldu jamurnya, aduk rata cek rasanya....bila ayam sudah empuk, sesaat sebelum dimatikan api kompornya masukkan irisan daun bawang prei (1 batang).... serta beri taburan bawang putih goreng yang di remas. Ayamnya bisa diangkat untuk disuwir dagingnya."
- "Koya : krupuk udang dipotong potong kecil, lalu masukkan ke tempat blender kecil....tambahkan bawang putih goreng, blender sampai halus."
- "Penyajian : pada mangkuk masukkan nasi, diatasnya letakkan soun....diatas soun letakkan irisan kol/ kubis....lalu siram kuah soto, beri suwiran daging ayam, irisan telur rebus serta pelengkap lainnya."
categories:
- Resep
tags:
- soto
- ayam
- lamongan

katakunci: soto ayam lamongan 
nutrition: 183 calories
recipecuisine: Indonesian
preptime: "PT20M"
cooktime: "PT35M"
recipeyield: "4"
recipecategory: Lunch

---


![Soto Ayam Lamongan Dengan Koya](https://img-global.cpcdn.com/recipes/b39f1f8f4c1121bf/680x482cq70/soto-ayam-lamongan-dengan-koya-foto-resep-utama.jpg)

Apabila kita seorang istri, menyajikan panganan sedap buat orang tercinta adalah suatu hal yang sangat menyenangkan untuk anda sendiri. Kewajiban seorang  wanita Tidak saja mengerjakan pekerjaan rumah saja, tetapi anda juga wajib memastikan kebutuhan gizi terpenuhi dan panganan yang dikonsumsi anak-anak mesti mantab.

Di masa  sekarang, anda sebenarnya bisa membeli santapan jadi meski tidak harus repot mengolahnya terlebih dahulu. Tapi ada juga lho mereka yang selalu mau menghidangkan yang terenak untuk orang tercintanya. Lantaran, menyajikan masakan yang dibuat sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan makanan tersebut sesuai masakan kesukaan keluarga. 



Mungkinkah anda adalah salah satu penggemar soto ayam lamongan dengan koya?. Asal kamu tahu, soto ayam lamongan dengan koya merupakan sajian khas di Nusantara yang kini disenangi oleh kebanyakan orang di berbagai wilayah di Indonesia. Kalian bisa menyajikan soto ayam lamongan dengan koya sendiri di rumah dan boleh jadi santapan favorit di hari liburmu.

Kalian jangan bingung untuk mendapatkan soto ayam lamongan dengan koya, sebab soto ayam lamongan dengan koya sangat mudah untuk dicari dan juga anda pun dapat memasaknya sendiri di rumah. soto ayam lamongan dengan koya bisa dibuat memalui berbagai cara. Kini pun telah banyak cara modern yang menjadikan soto ayam lamongan dengan koya lebih lezat.

Resep soto ayam lamongan dengan koya pun sangat gampang dihidangkan, lho. Kamu tidak usah ribet-ribet untuk membeli soto ayam lamongan dengan koya, tetapi Kamu bisa menghidangkan di rumahmu. Untuk Anda yang hendak mencobanya, dibawah ini merupakan resep untuk membuat soto ayam lamongan dengan koya yang mantab yang dapat Kamu buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Soto Ayam Lamongan Dengan Koya:

1. Siapkan 1 ekor ayam kampung
1. Ambil 1 buah jeruk nipis
1. Gunakan 2 batang sereh (geprek)
1. Sediakan 2 cm lengkuas (geprek)
1. Ambil 5 lembar daun jeruk
1. Sediakan 2 lembar daun salam
1. Gunakan 2 barang daun bawang prei
1. Gunakan 1 sdm garam
1. Gunakan 1 sdt kaldu jamur
1. Gunakan 2 sdt gula pasir
1. Gunakan 1/2 sdt merica bubuk
1. Siapkan 1 sdt bawang putih goreng (remas)
1. Gunakan secukupnya air (kurang lebih 11/2 liter)
1. Gunakan secukupnya minyak goreng untuk menumis
1. Siapkan  Bumbu Halus :
1. Gunakan 6 siung bawang merah
1. Gunakan 6 siung bawang putih
1. Siapkan 4 butir kemiri sangrai
1. Sediakan 3 cm jahe
1. Ambil 3 cm kunyit
1. Ambil 1 sdt ketumbar bubuk
1. Ambil 1/4 sdt jinten
1. Gunakan  Pelengkap :
1. Sediakan  Soun
1. Gunakan  Telur rebus
1. Sediakan  Kol
1. Siapkan  Koya (4 krupuk udang besar + 1 sdm bawang putih goreng)
1. Sediakan  Jeruk nipis
1. Ambil  Seledri
1. Sediakan  Sambal
1. Sediakan  Bawang goreng
1. Siapkan  Kecambah pendek




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Soto Ayam Lamongan Dengan Koya:

1. Ayam yang sudah di potong dan di cuci bersih di beri perasan air jeruk nipis, diamkan 15 menit lalu bilas....siapkan bumbu cemplungnya, sereh dan lengkuas di geprek, daun jeruk dibuang tulang daunnya.
1. Didihkan air dalam panci...bila sudah mendidih masukkan ayamnya....masukkan juga bumbu cemplungnya (sereh, daun salam, lengkuas dan daun jeruk), masak dengan api sedang cenderung kecil.
1. Siapkan semua bahan untuk membuat - bumbu halusnya... haluskan bumbu bisa diulek atau blender...... jika di blender tambahkan minyak goreng agar mudah halusnya.
1. Tumis bumbu halus sampai wangi....lalu beri irisan daun bawang prei (1 batang), aduk rata....masukkan tumisan bumbu ke panci yang berisi ayam.
1. Lalu masukkan garam....masukkan gula pasir....masukkan merica bubuknya.
1. Masukkan juga kaldu jamurnya, aduk rata cek rasanya....bila ayam sudah empuk, sesaat sebelum dimatikan api kompornya masukkan irisan daun bawang prei (1 batang).... serta beri taburan bawang putih goreng yang di remas. Ayamnya bisa diangkat untuk disuwir dagingnya.
1. Koya : krupuk udang dipotong potong kecil, lalu masukkan ke tempat blender kecil....tambahkan bawang putih goreng, blender sampai halus.
1. Penyajian : pada mangkuk masukkan nasi, diatasnya letakkan soun....diatas soun letakkan irisan kol/ kubis....lalu siram kuah soto, beri suwiran daging ayam, irisan telur rebus serta pelengkap lainnya.




Ternyata cara buat soto ayam lamongan dengan koya yang mantab simple ini mudah banget ya! Kamu semua bisa menghidangkannya. Cara buat soto ayam lamongan dengan koya Sesuai sekali untuk kamu yang baru belajar memasak atau juga untuk kamu yang telah hebat dalam memasak.

Tertarik untuk mencoba membikin resep soto ayam lamongan dengan koya nikmat tidak ribet ini? Kalau kalian mau, yuk kita segera buruan siapkan alat-alat dan bahannya, maka bikin deh Resep soto ayam lamongan dengan koya yang lezat dan sederhana ini. Benar-benar taidak sulit kan. 

Jadi, ketimbang kamu berfikir lama-lama, ayo kita langsung sajikan resep soto ayam lamongan dengan koya ini. Dijamin kamu gak akan nyesel bikin resep soto ayam lamongan dengan koya enak tidak ribet ini! Selamat mencoba dengan resep soto ayam lamongan dengan koya lezat sederhana ini di rumah kalian sendiri,oke!.

