---
description: "Resep Ayam Woku Khas Manado yang lezat dan Mudah Dibuat"
title: "Resep Ayam Woku Khas Manado yang lezat dan Mudah Dibuat"
slug: 402-resep-ayam-woku-khas-manado-yang-lezat-dan-mudah-dibuat
date: 2021-06-06T13:42:36.768Z
image: https://img-global.cpcdn.com/recipes/20fd3b08fada4c85/680x482cq70/ayam-woku-khas-manado-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/20fd3b08fada4c85/680x482cq70/ayam-woku-khas-manado-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/20fd3b08fada4c85/680x482cq70/ayam-woku-khas-manado-foto-resep-utama.jpg
author: Thomas Brady
ratingvalue: 3.7
reviewcount: 13
recipeingredient:
- "1/2 kg ayam kota boleh pake ayam kampung yaa"
- "2 genggam daun kemangi"
- "2 batang daun bawang potong"
- "1 bh tomat potong dadu"
- "2 lembar daun pandan simpul"
- "1 lembar daun kunyit optional"
- "5 bh cabe rawit utuh optional"
- "800 ml air boleh kurang klo mau dibikin agak nyemek"
- " Minyak utk menumis"
- " BUMBU HALUS "
- "5 siung bawang merah"
- "3 siung bawang putih"
- "10 bh cabe rawit"
- "1 ruas kunyit"
- "1 ruas jahe"
- "3 butir kemiri sangrai"
- "1/2 sdt lada bubuk"
- " BUMBU CEMPLUNG "
- "3 lembar daun salam"
- "5 lembar daun jeruk"
- "1 batang sereh geprek"
- "1 ruas lengkuas geprek"
recipeinstructions:
- "Panaskan minyak, lalu tumis bumbu halus, daun pandan, daun kunyit (bila ada), serta bumbu cemplung, jgn lupa garam &amp; kaldu ayam secukupnya."
- "Tumis hingga harum dan matang, kemudian masukkan ayam, tumis sebentar bersama bumbu, lalu tuangkan air."
- "Tunggu hingga ayam empuk, matang &amp; bumbu meresap."
- "Masukkan tomat, daun kemangi dan daun bawang. Koreksi rasa."
- "Sajikan bersama nasi hangat."
categories:
- Resep
tags:
- ayam
- woku
- khas

katakunci: ayam woku khas 
nutrition: 286 calories
recipecuisine: Indonesian
preptime: "PT28M"
cooktime: "PT31M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam Woku Khas Manado](https://img-global.cpcdn.com/recipes/20fd3b08fada4c85/680x482cq70/ayam-woku-khas-manado-foto-resep-utama.jpg)

Apabila kamu seorang ibu, mempersiapkan olahan nikmat kepada orang tercinta merupakan hal yang menyenangkan bagi anda sendiri. Kewajiban seorang ibu bukan sekadar mengurus rumah saja, tapi anda pun wajib menyediakan keperluan nutrisi terpenuhi dan juga masakan yang disantap anak-anak wajib enak.

Di waktu  saat ini, kalian memang mampu membeli olahan yang sudah jadi tanpa harus ribet memasaknya dulu. Namun banyak juga lho orang yang selalu mau memberikan yang terenak bagi keluarganya. Sebab, memasak yang dibuat sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan hidangan tersebut sesuai selera keluarga tercinta. 



Apakah anda adalah salah satu penggemar ayam woku khas manado?. Tahukah kamu, ayam woku khas manado adalah hidangan khas di Nusantara yang saat ini disenangi oleh banyak orang dari hampir setiap tempat di Indonesia. Kita dapat menghidangkan ayam woku khas manado sendiri di rumah dan pasti jadi santapan favoritmu di akhir pekanmu.

Kalian tidak perlu bingung untuk menyantap ayam woku khas manado, sebab ayam woku khas manado tidak sukar untuk dicari dan juga anda pun bisa membuatnya sendiri di rumah. ayam woku khas manado boleh dibuat dengan berbagai cara. Kini pun telah banyak sekali resep modern yang menjadikan ayam woku khas manado semakin lebih lezat.

Resep ayam woku khas manado pun sangat gampang dibikin, lho. Anda tidak perlu capek-capek untuk memesan ayam woku khas manado, karena Kita dapat menyiapkan di rumahmu. Bagi Kalian yang akan menyajikannya, dibawah ini merupakan cara untuk menyajikan ayam woku khas manado yang mantab yang bisa Anda buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Ayam Woku Khas Manado:

1. Siapkan 1/2 kg ayam kota (boleh pake ayam kampung yaa)
1. Siapkan 2 genggam daun kemangi
1. Siapkan 2 batang daun bawang, potong²
1. Siapkan 1 bh tomat, potong dadu
1. Siapkan 2 lembar daun pandan, simpul
1. Sediakan 1 lembar daun kunyit (optional)
1. Sediakan 5 bh cabe rawit utuh (optional)
1. Siapkan 800 ml air (boleh kurang klo mau dibikin agak nyemek)
1. Siapkan  Minyak utk menumis
1. Gunakan  BUMBU HALUS :
1. Siapkan 5 siung bawang merah
1. Ambil 3 siung bawang putih
1. Siapkan 10 bh cabe rawit
1. Siapkan 1 ruas kunyit
1. Siapkan 1 ruas jahe
1. Gunakan 3 butir kemiri sangrai
1. Siapkan 1/2 sdt lada bubuk
1. Gunakan  BUMBU CEMPLUNG :
1. Gunakan 3 lembar daun salam
1. Siapkan 5 lembar daun jeruk
1. Ambil 1 batang sereh, geprek
1. Gunakan 1 ruas lengkuas, geprek




<!--inarticleads2-->

##### Cara menyiapkan Ayam Woku Khas Manado:

1. Panaskan minyak, lalu tumis bumbu halus, daun pandan, daun kunyit (bila ada), serta bumbu cemplung, jgn lupa garam &amp; kaldu ayam secukupnya.
1. Tumis hingga harum dan matang, kemudian masukkan ayam, tumis sebentar bersama bumbu, lalu tuangkan air.
1. Tunggu hingga ayam empuk, matang &amp; bumbu meresap.
1. Masukkan tomat, daun kemangi dan daun bawang. Koreksi rasa.
1. Sajikan bersama nasi hangat.




Wah ternyata resep ayam woku khas manado yang lezat tidak rumit ini mudah banget ya! Anda Semua dapat menghidangkannya. Cara Membuat ayam woku khas manado Sangat cocok sekali buat kamu yang baru belajar memasak maupun untuk kalian yang telah pandai dalam memasak.

Apakah kamu tertarik mencoba membuat resep ayam woku khas manado enak tidak rumit ini? Kalau anda ingin, ayo kamu segera siapin alat-alat dan bahan-bahannya, maka bikin deh Resep ayam woku khas manado yang nikmat dan tidak ribet ini. Sangat mudah kan. 

Oleh karena itu, daripada anda diam saja, ayo kita langsung saja bikin resep ayam woku khas manado ini. Dijamin kalian tiidak akan nyesel bikin resep ayam woku khas manado enak tidak ribet ini! Selamat berkreasi dengan resep ayam woku khas manado enak simple ini di tempat tinggal masing-masing,ya!.

