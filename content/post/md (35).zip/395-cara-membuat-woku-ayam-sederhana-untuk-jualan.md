---
description: "Cara membuat Woku ayam Sederhana Untuk Jualan"
title: "Cara membuat Woku ayam Sederhana Untuk Jualan"
slug: 395-cara-membuat-woku-ayam-sederhana-untuk-jualan
date: 2021-01-22T00:22:38.545Z
image: https://img-global.cpcdn.com/recipes/868575464d733309/680x482cq70/woku-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/868575464d733309/680x482cq70/woku-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/868575464d733309/680x482cq70/woku-ayam-foto-resep-utama.jpg
author: Bernice Griffin
ratingvalue: 4.6
reviewcount: 13
recipeingredient:
- "1 ekor ayam potong agak kecil2"
- " Jeruk nipis"
- " Garam"
- " Bumbu halus"
- "10 btr bawang merah"
- "4 siung bawang putih"
- "2 ruas jahe"
- "1 ruas kunyit"
- "5 btr kemiri sangrai"
- "20 bh cabe rawit merah"
- "10 bh cabe merah keriting"
- " Bahan lainnya"
- "1 lbr daun kunyit simpulkan"
- "5 lbr daun jeruk"
- "2 btg serai memarkan"
- "1 bh tomat potong jadi 6 bagian"
- "2 btg daun bawang iris2"
- " I ikat kemangi petiki"
recipeinstructions:
- "Cuci bersih ayam lalu beri jeruk nipis dan sedikit ayam. Diamkan selama 30 menit"
- "Tumis bumbu halus sampai mengeluarkan bau wangi dan berminyak, masukkan serai, daun jeruk dan daun kunyit, aduk rata. Sesaat kemudian tambahkan daun bawang dan tomat..aduk kembali."
- "Masukkan ayam lalu aduk, tuang air secukupnya, beri garam dan penyedap..gunakan api sedang. Biarkan sampai ayam empuk dan bumbu meresap."
- "Sesaat sebelum diangkat tambahkan kemangi, aduk sebentar. Lalu angkat dan sajikan."
categories:
- Resep
tags:
- woku
- ayam

katakunci: woku ayam 
nutrition: 193 calories
recipecuisine: Indonesian
preptime: "PT35M"
cooktime: "PT47M"
recipeyield: "3"
recipecategory: Dinner

---


![Woku ayam](https://img-global.cpcdn.com/recipes/868575464d733309/680x482cq70/woku-ayam-foto-resep-utama.jpg)

Selaku seorang yang hobi masak, menyediakan panganan enak pada orang tercinta adalah suatu hal yang menggembirakan bagi kamu sendiri. Peran seorang ibu bukan sekedar menangani rumah saja, tetapi kamu juga harus memastikan keperluan gizi tercukupi dan santapan yang disantap orang tercinta wajib nikmat.

Di waktu  sekarang, kalian memang dapat memesan olahan instan tidak harus ribet mengolahnya dahulu. Tetapi banyak juga lho orang yang memang mau memberikan yang terbaik bagi orang yang dicintainya. Lantaran, memasak yang diolah sendiri akan jauh lebih higienis dan bisa menyesuaikan hidangan tersebut berdasarkan kesukaan famili. 

Ayam woku biasanya dimasak hingga kuahnya mengental dan sedikit menyusut. Sajian ini adalah lauk yang sangat cocok bersanding dengan nasi putih panas. Resep Ayam Woku - Ayam woku adalah salah satu makanan khas asal Indonesia.

Mungkinkah anda adalah seorang penikmat woku ayam?. Asal kamu tahu, woku ayam merupakan sajian khas di Nusantara yang kini digemari oleh kebanyakan orang dari berbagai tempat di Indonesia. Anda dapat menghidangkan woku ayam olahan sendiri di rumah dan pasti jadi makanan favoritmu di hari libur.

Kalian jangan bingung jika kamu ingin memakan woku ayam, karena woku ayam mudah untuk dicari dan anda pun boleh membuatnya sendiri di rumah. woku ayam bisa dibuat memalui beragam cara. Saat ini ada banyak sekali resep kekinian yang menjadikan woku ayam semakin lebih lezat.

Resep woku ayam juga gampang untuk dibikin, lho. Kita jangan ribet-ribet untuk memesan woku ayam, karena Kalian dapat menyiapkan ditempatmu. Bagi Kalian yang hendak menghidangkannya, berikut ini cara untuk membuat woku ayam yang enak yang mampu Kamu coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Woku ayam:

1. Gunakan 1 ekor ayam potong agak kecil2
1. Ambil  Jeruk nipis
1. Ambil  Garam
1. Sediakan  Bumbu halus:
1. Gunakan 10 btr bawang merah
1. Siapkan 4 siung bawang putih
1. Ambil 2 ruas jahe
1. Gunakan 1 ruas kunyit
1. Sediakan 5 btr kemiri sangrai
1. Ambil 20 bh cabe rawit merah
1. Sediakan 10 bh cabe merah keriting
1. Siapkan  Bahan lainnya:
1. Ambil 1 lbr daun kunyit simpulkan
1. Siapkan 5 lbr daun jeruk
1. Sediakan 2 btg serai memarkan
1. Ambil 1 bh tomat potong jadi 6 bagian
1. Ambil 2 btg daun bawang iris2
1. Sediakan  I ikat kemangi petiki


Resep Ayam Woku, Cita Rasa Pedas Aromatik Khas Sulawesi Utara. Simpan ke bagian favorit Tersimpan di bagian favorit. Lihat juga resep Ayam Woku Khas Manado enak lainnya. Ayam woku meruapakan salah satu makanan khas dari Manado. 

<!--inarticleads2-->

##### Cara menyiapkan Woku ayam:

1. Cuci bersih ayam lalu beri jeruk nipis dan sedikit ayam. Diamkan selama 30 menit
1. Tumis bumbu halus sampai mengeluarkan bau wangi dan berminyak, masukkan serai, daun jeruk dan daun kunyit, aduk rata. Sesaat kemudian tambahkan daun bawang dan tomat..aduk kembali.
1. Masukkan ayam lalu aduk, tuang air secukupnya, beri garam dan penyedap..gunakan api sedang. Biarkan sampai ayam empuk dan bumbu meresap.
1. Sesaat sebelum diangkat tambahkan kemangi, aduk sebentar. Lalu angkat dan sajikan.


Perbedaan dari cara penyajiannnya menjadi pembeda antara ayam woku daun dan ayam woku belanga. Resep Ayam Woku Manado - Woku merupakan salah satu bumbu makanan ala Manado, provinsi Sulawesi Utara Indonesia, yang terbuat dari berbagai macam bumbu dan umumnya digunakan untuk. Yap, Ayam woku adalah salah satu makanan khas asal Indonesia. Ayam woku berasal dari daerah Rasa rempah dan kelezatan ayam akan sangat cocok dinikmati dengan nasi sebagai salah satu. Ayam Woku Manado merupakan olahan ayam dengan beragam bumbu khas Manado yang kaya akan rasa. 

Wah ternyata cara membuat woku ayam yang mantab simple ini mudah banget ya! Anda Semua dapat membuatnya. Resep woku ayam Sangat sesuai sekali buat kita yang sedang belajar memasak ataupun untuk anda yang telah pandai dalam memasak.

Tertarik untuk mulai mencoba membuat resep woku ayam lezat simple ini? Kalau anda mau, ayo kalian segera siapin alat dan bahannya, maka bikin deh Resep woku ayam yang mantab dan sederhana ini. Benar-benar gampang kan. 

Oleh karena itu, ketimbang kalian berlama-lama, hayo kita langsung hidangkan resep woku ayam ini. Pasti kalian gak akan nyesel sudah buat resep woku ayam lezat simple ini! Selamat mencoba dengan resep woku ayam lezat sederhana ini di rumah masing-masing,oke!.

