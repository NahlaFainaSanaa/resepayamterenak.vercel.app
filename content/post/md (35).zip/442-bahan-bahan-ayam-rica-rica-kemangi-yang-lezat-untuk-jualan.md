---
description: "Bahan-bahan Ayam Rica Rica Kemangi yang lezat Untuk Jualan"
title: "Bahan-bahan Ayam Rica Rica Kemangi yang lezat Untuk Jualan"
slug: 442-bahan-bahan-ayam-rica-rica-kemangi-yang-lezat-untuk-jualan
date: 2021-03-01T13:31:56.284Z
image: https://img-global.cpcdn.com/recipes/1c40514f2ad2143f/680x482cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1c40514f2ad2143f/680x482cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1c40514f2ad2143f/680x482cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Earl Murphy
ratingvalue: 4.8
reviewcount: 3
recipeingredient:
- "1/2 ekor ayam ayam nya aku potong kecil2 supaya lbh ter caramelized bumbubiar lbh nyerep bumbu"
- "3 ikat kemangi"
- "8 daun jeruk"
- "1 btg seraimemarkan"
- "1 btg daun bawangpotong kasar"
- "1 ruas lengkuas memarkan"
- "1 jeruk nipisoptional"
- "1/2 sdm garam"
- "1 sdt kaldu jamur totole"
- " Bahan dihaluskan"
- "6 siung bawang merah"
- "2 siung bawang putih"
- "3 btr kemiri"
- "7 cabai keriting"
- "7 cabe rawit klo mau pedes bs di banyakin"
- "1/2 keping kecil gula merah"
- "1 ruas kunyit"
- "1 ruas jahe"
recipeinstructions:
- "Siapkan bahan dan cuci bersih"
- "Potong ayam jd kecil2 (cth:paha bs jd 8 bagian) biar nyerep bumbu,lbh sedep. Cuci ayam dan beri perasan jeruk nipis"
- "Tumis bumbu yg sudah di haluskan,begitu harum masukin lengkuas,daun jeruk dan serai"
- "Lalu masukan ayam,masak sampe stengah matang/ayam berubah warna. Lalu tambahkan air secukupnya (saya pake 300ml) Beri garam dan kaldu (saya pakai totole) untuk bumbu bs menyesuaikan ya,tgl d icip2 aja. Masak sampai bumbu mulai mengental"
- "Begitu bumbu sdh mengental dan ayam matang Masukan daun bawang dan kemangi aduk sebentar dan matikan api"
categories:
- Resep
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 237 calories
recipecuisine: Indonesian
preptime: "PT12M"
cooktime: "PT49M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam Rica Rica Kemangi](https://img-global.cpcdn.com/recipes/1c40514f2ad2143f/680x482cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Selaku seorang ibu, menyuguhkan santapan mantab kepada famili adalah hal yang menggembirakan bagi kamu sendiri. Tanggung jawab seorang ibu Tidak cuma menjaga rumah saja, tetapi kamu juga harus menyediakan kebutuhan nutrisi tercukupi dan juga panganan yang disantap keluarga tercinta wajib nikmat.

Di era  saat ini, kita memang bisa membeli hidangan yang sudah jadi meski tanpa harus susah memasaknya dahulu. Namun ada juga lho mereka yang memang ingin memberikan yang terbaik bagi orang tercintanya. Karena, menghidangkan masakan sendiri akan jauh lebih bersih dan bisa menyesuaikan makanan tersebut sesuai dengan masakan kesukaan keluarga. 



Mungkinkah anda adalah seorang penyuka ayam rica rica kemangi?. Asal kamu tahu, ayam rica rica kemangi adalah hidangan khas di Nusantara yang kini digemari oleh setiap orang di berbagai daerah di Indonesia. Anda bisa memasak ayam rica rica kemangi sendiri di rumahmu dan dapat dijadikan makanan favoritmu di hari libur.

Anda tak perlu bingung untuk mendapatkan ayam rica rica kemangi, sebab ayam rica rica kemangi tidak sukar untuk dicari dan juga kamu pun bisa membuatnya sendiri di rumah. ayam rica rica kemangi dapat dibuat lewat beragam cara. Sekarang telah banyak sekali resep modern yang membuat ayam rica rica kemangi semakin lebih lezat.

Resep ayam rica rica kemangi pun gampang sekali dibuat, lho. Kamu tidak usah capek-capek untuk memesan ayam rica rica kemangi, lantaran Kamu bisa membuatnya di rumah sendiri. Bagi Kamu yang akan menyajikannya, di bawah ini adalah resep untuk membuat ayam rica rica kemangi yang nikamat yang dapat Kamu coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Ayam Rica Rica Kemangi:

1. Siapkan 1/2 ekor ayam (ayam nya aku potong kecil2 supaya lbh ter caramelized bumbu,biar lbh nyerep bumbu)
1. Siapkan 3 ikat kemangi
1. Gunakan 8 daun jeruk
1. Sediakan 1 btg serai(memarkan)
1. Ambil 1 btg daun bawang(potong kasar)
1. Sediakan 1 ruas lengkuas (memarkan)
1. Siapkan 1 jeruk nipis(optional)
1. Ambil 1/2 sdm garam
1. Gunakan 1 sdt kaldu jamur totole
1. Ambil  Bahan dihaluskan
1. Sediakan 6 siung bawang merah
1. Siapkan 2 siung bawang putih
1. Ambil 3 btr kemiri
1. Siapkan 7 cabai keriting
1. Ambil 7 cabe rawit (klo mau pedes bs di banyakin)
1. Siapkan 1/2 keping kecil gula merah
1. Ambil 1 ruas kunyit
1. Sediakan 1 ruas jahe




<!--inarticleads2-->

##### Cara membuat Ayam Rica Rica Kemangi:

1. Siapkan bahan dan cuci bersih
1. Potong ayam jd kecil2 (cth:paha bs jd 8 bagian) biar nyerep bumbu,lbh sedep. - Cuci ayam dan beri perasan jeruk nipis
1. Tumis bumbu yg sudah di haluskan,begitu harum masukin lengkuas,daun jeruk dan serai
1. Lalu masukan ayam,masak sampe stengah matang/ayam berubah warna. - Lalu tambahkan air secukupnya (saya pake 300ml) - Beri garam dan kaldu (saya pakai totole) untuk bumbu bs menyesuaikan ya,tgl d icip2 aja. - Masak sampai bumbu mulai mengental
1. Begitu bumbu sdh mengental dan ayam matang - Masukan daun bawang dan kemangi aduk sebentar dan matikan api




Ternyata cara membuat ayam rica rica kemangi yang lezat tidak ribet ini mudah sekali ya! Kita semua bisa memasaknya. Cara Membuat ayam rica rica kemangi Sesuai banget buat kamu yang baru mau belajar memasak atau juga bagi anda yang sudah lihai memasak.

Apakah kamu ingin mulai mencoba bikin resep ayam rica rica kemangi enak tidak rumit ini? Kalau anda mau, mending kamu segera siapkan alat dan bahannya, maka bikin deh Resep ayam rica rica kemangi yang enak dan tidak ribet ini. Sangat mudah kan. 

Maka, daripada kita berfikir lama-lama, maka langsung aja buat resep ayam rica rica kemangi ini. Pasti anda gak akan menyesal sudah buat resep ayam rica rica kemangi nikmat tidak rumit ini! Selamat berkreasi dengan resep ayam rica rica kemangi nikmat tidak ribet ini di rumah sendiri,oke!.

