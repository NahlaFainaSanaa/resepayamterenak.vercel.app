---
description: "Cara buat Ayam Rica-Rica Kemangi Pedas yang enak Untuk Jualan"
title: "Cara buat Ayam Rica-Rica Kemangi Pedas yang enak Untuk Jualan"
slug: 449-cara-buat-ayam-rica-rica-kemangi-pedas-yang-enak-untuk-jualan
date: 2021-02-07T10:14:10.226Z
image: https://img-global.cpcdn.com/recipes/b5be1f485bd8bf63/680x482cq70/ayam-rica-rica-kemangi-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b5be1f485bd8bf63/680x482cq70/ayam-rica-rica-kemangi-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b5be1f485bd8bf63/680x482cq70/ayam-rica-rica-kemangi-pedas-foto-resep-utama.jpg
author: Beulah Rodriquez
ratingvalue: 3.5
reviewcount: 14
recipeingredient:
- "8 potong Ayam"
- "1/2 sdt Kunyit bahan marinasi ayam"
- "1 sdt Garam bahan marinasi ayam"
- "secukupnya Minyak Goreng"
- "3 lembar Daun Salam"
- "2 lembar Daun Jeruk"
- "1 ruas Lengkuas geprek"
- "1 batang Sereh geprek"
- "2 ikat Kemangi"
- "secukupnya Air"
- "secukupnya Garam"
- "secukupnya Masako"
- " Bumbu Halus "
- "15 buah Cabe Merah Keriting"
- "25 buah Cabe Rawit kalo suka lebih pedas bisa ditambahin ya"
- "3 butir Kemiri"
- "10 siung Bawang Merah"
- "6 siung Bawang Putih"
- "1 ruas Jahe"
- "1 sdt Kunyit Bubuk  sekelingking"
recipeinstructions:
- "Cuci bersih ayam. Marinasi dengan garam &amp; kunyit bubuk. Diamkan selama 1 jam."
- "Panaskan minyak goreng &amp; sedikit tepung (Bertujuan agar tidak meletup). Goreng ayam sebentar sampai berkulit saja. Angkat &amp; sisihkan."
- "Siapkan bahan bumbu halus. Kemudian blender."
- "Panaskan minyak. Masukkan bumbu halus, tumis sampai matang harum. Masukkan sereh, lengkuas, daun salam &amp; daun jeruk, tumis lagi sampai matang."
- "Masukkan air, aduk rata. Masak sampai mulai matang mendidih. Masukkan masako &amp; garam, aduk merata."
- "Masukkan ayam goreng, aduk rata. Masak dengan api kecil sampai bumbu meresap."
- "Masukkan daun kemangi, aduk rata. Matikan kompor, angkat &amp; sajikan."
- "Taraaa... Sudah matang, silahkan mencobaa~~ 😙😍"
categories:
- Resep
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 245 calories
recipecuisine: Indonesian
preptime: "PT40M"
cooktime: "PT46M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam Rica-Rica Kemangi Pedas](https://img-global.cpcdn.com/recipes/b5be1f485bd8bf63/680x482cq70/ayam-rica-rica-kemangi-pedas-foto-resep-utama.jpg)

Sebagai seorang orang tua, menyuguhkan panganan nikmat bagi keluarga tercinta merupakan suatu hal yang memuaskan bagi kamu sendiri. Peran seorang istri bukan cuman menangani rumah saja, namun anda juga harus memastikan kebutuhan nutrisi terpenuhi dan juga masakan yang dikonsumsi keluarga tercinta harus menggugah selera.

Di waktu  saat ini, kalian memang mampu membeli olahan instan tanpa harus capek mengolahnya dahulu. Tetapi banyak juga lho orang yang selalu ingin memberikan yang terbaik bagi orang tercintanya. Pasalnya, memasak yang dibuat sendiri jauh lebih higienis dan kita pun bisa menyesuaikan masakan tersebut sesuai kesukaan keluarga tercinta. 



Mungkinkah kamu seorang penggemar ayam rica-rica kemangi pedas?. Asal kamu tahu, ayam rica-rica kemangi pedas adalah sajian khas di Nusantara yang saat ini disenangi oleh banyak orang dari berbagai tempat di Nusantara. Kita bisa memasak ayam rica-rica kemangi pedas sendiri di rumah dan boleh jadi santapan favorit di akhir pekan.

Kalian tidak perlu bingung untuk mendapatkan ayam rica-rica kemangi pedas, sebab ayam rica-rica kemangi pedas tidak sukar untuk ditemukan dan anda pun boleh menghidangkannya sendiri di rumah. ayam rica-rica kemangi pedas boleh dibuat memalui berbagai cara. Kini pun telah banyak sekali resep modern yang membuat ayam rica-rica kemangi pedas lebih nikmat.

Resep ayam rica-rica kemangi pedas juga sangat mudah dibikin, lho. Kalian tidak perlu ribet-ribet untuk memesan ayam rica-rica kemangi pedas, tetapi Kamu bisa menghidangkan sendiri di rumah. Untuk Anda yang ingin membuatnya, inilah cara untuk membuat ayam rica-rica kemangi pedas yang nikamat yang mampu Kalian buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Ayam Rica-Rica Kemangi Pedas:

1. Siapkan 8 potong Ayam
1. Siapkan 1/2 sdt Kunyit, bahan marinasi ayam
1. Gunakan 1 sdt Garam, bahan marinasi ayam
1. Siapkan secukupnya Minyak Goreng
1. Gunakan 3 lembar Daun Salam
1. Gunakan 2 lembar Daun Jeruk
1. Ambil 1 ruas Lengkuas, geprek
1. Ambil 1 batang Sereh, geprek
1. Ambil 2 ikat Kemangi
1. Ambil secukupnya Air
1. Sediakan secukupnya Garam
1. Ambil secukupnya Masako
1. Gunakan  Bumbu Halus :
1. Siapkan 15 buah Cabe Merah Keriting
1. Siapkan 25 buah Cabe Rawit, kalo suka lebih pedas, bisa ditambahin ya
1. Ambil 3 butir Kemiri
1. Siapkan 10 siung Bawang Merah
1. Sediakan 6 siung Bawang Putih
1. Ambil 1 ruas Jahe
1. Siapkan 1 sdt Kunyit Bubuk / sekelingking




<!--inarticleads2-->

##### Cara menyiapkan Ayam Rica-Rica Kemangi Pedas:

1. Cuci bersih ayam. Marinasi dengan garam &amp; kunyit bubuk. Diamkan selama 1 jam.
1. Panaskan minyak goreng &amp; sedikit tepung (Bertujuan agar tidak meletup). Goreng ayam sebentar sampai berkulit saja. Angkat &amp; sisihkan.
1. Siapkan bahan bumbu halus. Kemudian blender.
1. Panaskan minyak. Masukkan bumbu halus, tumis sampai matang harum. Masukkan sereh, lengkuas, daun salam &amp; daun jeruk, tumis lagi sampai matang.
1. Masukkan air, aduk rata. Masak sampai mulai matang mendidih. Masukkan masako &amp; garam, aduk merata.
1. Masukkan ayam goreng, aduk rata. Masak dengan api kecil sampai bumbu meresap.
1. Masukkan daun kemangi, aduk rata. Matikan kompor, angkat &amp; sajikan.
1. Taraaa... Sudah matang, silahkan mencobaa~~ 😙😍




Ternyata cara buat ayam rica-rica kemangi pedas yang mantab tidak rumit ini mudah banget ya! Kalian semua bisa memasaknya. Cara buat ayam rica-rica kemangi pedas Sangat sesuai banget buat kamu yang baru akan belajar memasak atau juga untuk kamu yang sudah hebat dalam memasak.

Tertarik untuk mulai mencoba membuat resep ayam rica-rica kemangi pedas lezat tidak ribet ini? Kalau kalian ingin, mending kamu segera menyiapkan peralatan dan bahannya, maka bikin deh Resep ayam rica-rica kemangi pedas yang nikmat dan tidak rumit ini. Betul-betul gampang kan. 

Jadi, daripada kita berfikir lama-lama, ayo langsung aja hidangkan resep ayam rica-rica kemangi pedas ini. Pasti anda tiidak akan menyesal bikin resep ayam rica-rica kemangi pedas enak sederhana ini! Selamat mencoba dengan resep ayam rica-rica kemangi pedas mantab tidak ribet ini di tempat tinggal kalian sendiri,oke!.

