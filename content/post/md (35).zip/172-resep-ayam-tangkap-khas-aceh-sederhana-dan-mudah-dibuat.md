---
description: "Resep Ayam Tangkap Khas Aceh Sederhana dan Mudah Dibuat"
title: "Resep Ayam Tangkap Khas Aceh Sederhana dan Mudah Dibuat"
slug: 172-resep-ayam-tangkap-khas-aceh-sederhana-dan-mudah-dibuat
date: 2021-02-09T17:19:47.250Z
image: https://img-global.cpcdn.com/recipes/d8ca77ad0f7f07f0/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d8ca77ad0f7f07f0/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d8ca77ad0f7f07f0/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg
author: Roxie Lindsey
ratingvalue: 4.8
reviewcount: 14
recipeingredient:
- "1 ekor Ayam potong kecilkecil"
- "1 buah Jeruk nipis"
- " Garam secukup rasa"
- " Air kelapa saya gak pake"
- "secukupnya Daun kari"
- "3-4 lembar Daun pandan potong pendek"
- "5 buah Cabe ijo potongpotong"
- "Secukupnya Kaldu jamur atau kaldu ayam"
- " Minyak untuk menggoreng"
- " Bumbu halus "
- "10 buah Bawang merah"
- "4 siung Bawang putih"
- "3 butir Kemiri"
- "1 sdt Kunyit bubuk"
recipeinstructions:
- "Kalo ada air kelapa, rendam dulu sebentar sekitar 15-20 menit, lalu cuci bersih. Lumuri ayam dengan jeruk nipis dan garam."
- "Haluskan bahan bumbu halus dengan blender atau lebih bagus lagi menggunakan ulekan biar gak terlalu berair."
- "Marinasi ayam dengan bumbu halus, kaldu jamur atau kaldu ayam di dalam chiller selama 30 menit."
- "Panaskan minyak, goreng ayam, kalo sudah mulai matang, masukkan sedikit daun kari, daun pandan dan cabe ijo, goreng sampai daun-daun tersebut terlihat crispy, angkat ayam beserta daun-daunannya. Ulangi prosesnya sampai ayam habis."
- "Sajikan ayam tangkap dengan nasi putih panas."
categories:
- Resep
tags:
- ayam
- tangkap
- khas

katakunci: ayam tangkap khas 
nutrition: 241 calories
recipecuisine: Indonesian
preptime: "PT19M"
cooktime: "PT30M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam Tangkap Khas Aceh](https://img-global.cpcdn.com/recipes/d8ca77ad0f7f07f0/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg)

Sebagai seorang yang hobi memasak, menyajikan olahan nikmat pada famili merupakan suatu hal yang mengasyikan bagi kamu sendiri. Peran seorang  wanita Tidak cuman mengerjakan pekerjaan rumah saja, namun anda juga wajib memastikan kebutuhan nutrisi terpenuhi dan panganan yang dikonsumsi orang tercinta mesti mantab.

Di waktu  sekarang, kalian memang mampu memesan santapan jadi tanpa harus repot mengolahnya terlebih dahulu. Namun banyak juga orang yang memang mau memberikan makanan yang terbaik bagi keluarganya. Karena, memasak yang dibuat sendiri jauh lebih higienis dan bisa menyesuaikan hidangan tersebut sesuai selera orang tercinta. 



Mungkinkah kamu salah satu penyuka ayam tangkap khas aceh?. Tahukah kamu, ayam tangkap khas aceh merupakan hidangan khas di Nusantara yang sekarang disukai oleh banyak orang dari hampir setiap tempat di Indonesia. Kita dapat menghidangkan ayam tangkap khas aceh kreasi sendiri di rumahmu dan pasti jadi santapan favorit di akhir pekan.

Anda tak perlu bingung untuk menyantap ayam tangkap khas aceh, karena ayam tangkap khas aceh mudah untuk dicari dan juga kamu pun dapat memasaknya sendiri di tempatmu. ayam tangkap khas aceh dapat dimasak memalui bermacam cara. Kini pun ada banyak sekali cara kekinian yang membuat ayam tangkap khas aceh semakin lebih nikmat.

Resep ayam tangkap khas aceh pun gampang sekali dibuat, lho. Kita tidak perlu ribet-ribet untuk membeli ayam tangkap khas aceh, sebab Kalian dapat menyiapkan di rumahmu. Untuk Anda yang hendak membuatnya, berikut cara untuk membuat ayam tangkap khas aceh yang mantab yang dapat Kalian coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Ayam Tangkap Khas Aceh:

1. Siapkan 1 ekor Ayam, potong kecil-kecil
1. Sediakan 1 buah Jeruk nipis
1. Sediakan  Garam secukup rasa
1. Siapkan  Air kelapa (saya gak pake)
1. Siapkan secukupnya Daun kari
1. Sediakan 3-4 lembar Daun pandan, potong pendek
1. Sediakan 5 buah Cabe ijo, potong-potong
1. Sediakan Secukupnya Kaldu jamur atau kaldu ayam
1. Sediakan  Minyak untuk menggoreng
1. Sediakan  Bumbu halus :
1. Ambil 10 buah Bawang merah
1. Siapkan 4 siung Bawang putih
1. Siapkan 3 butir Kemiri
1. Sediakan 1 sdt Kunyit bubuk




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Tangkap Khas Aceh:

1. Kalo ada air kelapa, rendam dulu sebentar sekitar 15-20 menit, lalu cuci bersih. Lumuri ayam dengan jeruk nipis dan garam.
1. Haluskan bahan bumbu halus dengan blender atau lebih bagus lagi menggunakan ulekan biar gak terlalu berair.
1. Marinasi ayam dengan bumbu halus, kaldu jamur atau kaldu ayam di dalam chiller selama 30 menit.
1. Panaskan minyak, goreng ayam, kalo sudah mulai matang, masukkan sedikit daun kari, daun pandan dan cabe ijo, goreng sampai daun-daun tersebut terlihat crispy, angkat ayam beserta daun-daunannya. Ulangi prosesnya sampai ayam habis.
1. Sajikan ayam tangkap dengan nasi putih panas.




Wah ternyata resep ayam tangkap khas aceh yang enak tidak rumit ini enteng sekali ya! Anda Semua dapat membuatnya. Cara buat ayam tangkap khas aceh Sangat sesuai banget untuk kalian yang baru mau belajar memasak ataupun juga untuk kalian yang sudah hebat dalam memasak.

Apakah kamu ingin mencoba membikin resep ayam tangkap khas aceh lezat tidak ribet ini? Kalau kamu ingin, yuk kita segera buruan siapkan alat-alat dan bahan-bahannya, maka bikin deh Resep ayam tangkap khas aceh yang lezat dan sederhana ini. Sangat taidak sulit kan. 

Maka dari itu, ketimbang kamu berlama-lama, hayo kita langsung bikin resep ayam tangkap khas aceh ini. Dijamin kalian tiidak akan nyesel sudah buat resep ayam tangkap khas aceh enak tidak rumit ini! Selamat mencoba dengan resep ayam tangkap khas aceh lezat tidak rumit ini di tempat tinggal kalian sendiri,ya!.

