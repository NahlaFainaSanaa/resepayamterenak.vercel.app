---
description: "Bahan-bahan Soto Ayam Koya Lamongan yang nikmat Untuk Jualan"
title: "Bahan-bahan Soto Ayam Koya Lamongan yang nikmat Untuk Jualan"
slug: 235-bahan-bahan-soto-ayam-koya-lamongan-yang-nikmat-untuk-jualan
date: 2021-01-12T13:49:59.689Z
image: https://img-global.cpcdn.com/recipes/5a5562014a40a00a/680x482cq70/soto-ayam-koya-lamongan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5a5562014a40a00a/680x482cq70/soto-ayam-koya-lamongan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5a5562014a40a00a/680x482cq70/soto-ayam-koya-lamongan-foto-resep-utama.jpg
author: Olivia Nguyen
ratingvalue: 3.9
reviewcount: 13
recipeingredient:
- "300 gr Paha ayam"
- "4 buah ceker ayam"
- "2 butir telurrebus"
- "1 ikat daun seledrirajang halus"
- "1 batang bawang preipotong"
- "1 pack kecil soun RRTcuci bersih rendam air panas"
- "2 buah jeruk nipispotong jadi 8"
- " Kol secukupnyarajang halus"
- " Bumbu halus "
- "4 siung bawang putih"
- "6 buah bawang merah"
- "1 ruas sedang kunyit"
- "1 ruas sedang jahe"
- "1 sdm ketumbar"
- "1 sdt jinten"
- "2 buah kemiri"
- "1 batang seraimemarkan"
- "1 ruas sedang lengkuasmemarkan"
- "3 lembar daun jeruk"
- "1 sdt garam"
- "1/2 sdt gula"
- "1 sdt kaldu bubuk"
- " Bahan koya "
- "100 gr kerupuk udanggoreng hingga mengembang"
- "2 sdm bawang putih goreng"
- " Bahan sambal cabai rawit "
- "2 buah cabai merahbuang biji"
- "15 buah cabai rawit"
- " Pelengkap "
- " Bawang merah goreng"
recipeinstructions:
- "Rebus paha ayam dan ceker ayam lalu buang air rebusan pertama.untuk mengurangi lemak ayam boiler.kalau ayam kampung air rebusan tidak perlu dibuang."
- "Tumis bumbu yang sudah dihaluskan beserta daun jeruk,lengkuas geprek dan serai yang sudah digeprek hingga tanak dan wangi.lalu masukkan bumbu dalam air rebusan ayam.masak hingga bumbu meresap kedalam daging ayam.masukkan potongan bawang prei dalam rebusan kuah."
- "Lalu bumbui dengan gula,garam dan kaldu bubuk.test rasa jika sudah pas masak hingga kuah mendidih matikan."
- "Angkat paha ayam goreng sedikit berkulit agar tektur agak padat.sisihkan"
- "Cuci telur lalu rebus dengan cabai rawit hingga telur matang dan cabai rawit lunak.angkat sisihkan."
- "Cara membuat sambal soto : haluskan cabai rawit rebus dengan sedikit garam hingga halus.lalu sisihkan"
- "Cara membuat koya : campur krupuk udang dan bawang putih goreng lalu haluskan hingga menjadi bubuk,lalu sisihkan."
- "Cara penyajian : masukkan satu centong nasi dalam mangkuk beri soun RRT,suwiran ayam,potongan telur rebus,daun seledri dan rajangan kol.lalu siram dengan kuah soto yang masih panas,beri taburan bawang merah goreng dan bubuk koya.sebagai pelengkap tambahkan kucuran air jeruk nipis dan sambal cabai rawit rebus.cocok dinikmati selagi hangat.selamat mencoba😋"
categories:
- Resep
tags:
- soto
- ayam
- koya

katakunci: soto ayam koya 
nutrition: 260 calories
recipecuisine: Indonesian
preptime: "PT25M"
cooktime: "PT38M"
recipeyield: "3"
recipecategory: Lunch

---


![Soto Ayam Koya Lamongan](https://img-global.cpcdn.com/recipes/5a5562014a40a00a/680x482cq70/soto-ayam-koya-lamongan-foto-resep-utama.jpg)

Sebagai seorang istri, mempersiapkan olahan mantab buat keluarga tercinta adalah hal yang membahagiakan untuk kita sendiri. Tanggung jawab seorang istri Tidak hanya menjaga rumah saja, tapi kamu pun wajib menyediakan kebutuhan nutrisi terpenuhi dan juga panganan yang disantap anak-anak harus lezat.

Di waktu  saat ini, anda sebenarnya bisa memesan panganan jadi meski tidak harus ribet mengolahnya dulu. Tetapi banyak juga lho orang yang memang ingin memberikan hidangan yang terlezat bagi orang tercintanya. Sebab, menyajikan masakan yang diolah sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan hidangan tersebut sesuai makanan kesukaan famili. 



Mungkinkah anda merupakan seorang penyuka soto ayam koya lamongan?. Asal kamu tahu, soto ayam koya lamongan adalah sajian khas di Nusantara yang sekarang disenangi oleh banyak orang di berbagai tempat di Nusantara. Kita dapat menyajikan soto ayam koya lamongan sendiri di rumahmu dan boleh jadi santapan kegemaranmu di akhir pekan.

Kita tak perlu bingung jika kamu ingin memakan soto ayam koya lamongan, sebab soto ayam koya lamongan tidak sukar untuk ditemukan dan juga anda pun bisa menghidangkannya sendiri di tempatmu. soto ayam koya lamongan boleh dimasak dengan bermacam cara. Kini pun telah banyak sekali cara kekinian yang membuat soto ayam koya lamongan semakin nikmat.

Resep soto ayam koya lamongan juga mudah sekali dibikin, lho. Kalian tidak usah capek-capek untuk memesan soto ayam koya lamongan, sebab Anda bisa membuatnya di rumah sendiri. Untuk Kamu yang akan mencobanya, dibawah ini merupakan cara untuk menyajikan soto ayam koya lamongan yang lezat yang mampu Kalian hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Soto Ayam Koya Lamongan:

1. Ambil 300 gr Paha ayam
1. Siapkan 4 buah ceker ayam
1. Ambil 2 butir telur,rebus
1. Siapkan 1 ikat daun seledri,rajang halus
1. Siapkan 1 batang bawang prei,potong²
1. Siapkan 1 pack kecil soun RRT,cuci bersih rendam air panas
1. Siapkan 2 buah jeruk nipis,potong jadi 8
1. Gunakan  Kol secukupnya,rajang halus
1. Gunakan  Bumbu halus :
1. Gunakan 4 siung bawang putih
1. Ambil 6 buah bawang merah
1. Sediakan 1 ruas sedang kunyit
1. Sediakan 1 ruas sedang jahe
1. Gunakan 1 sdm ketumbar
1. Gunakan 1 sdt jinten
1. Gunakan 2 buah kemiri
1. Sediakan 1 batang serai,memarkan
1. Sediakan 1 ruas sedang lengkuas,memarkan
1. Siapkan 3 lembar daun jeruk
1. Gunakan 1 sdt garam
1. Gunakan 1/2 sdt gula
1. Siapkan 1 sdt kaldu bubuk
1. Siapkan  Bahan koya :
1. Sediakan 100 gr kerupuk udang,goreng hingga mengembang
1. Sediakan 2 sdm bawang putih goreng
1. Ambil  Bahan sambal cabai rawit :
1. Sediakan 2 buah cabai merah,buang biji
1. Siapkan 15 buah cabai rawit
1. Siapkan  Pelengkap :
1. Siapkan  Bawang merah goreng




<!--inarticleads2-->

##### Cara menyiapkan Soto Ayam Koya Lamongan:

1. Rebus paha ayam dan ceker ayam lalu buang air rebusan pertama.untuk mengurangi lemak ayam boiler.kalau ayam kampung air rebusan tidak perlu dibuang.
1. Tumis bumbu yang sudah dihaluskan beserta daun jeruk,lengkuas geprek dan serai yang sudah digeprek hingga tanak dan wangi.lalu masukkan bumbu dalam air rebusan ayam.masak hingga bumbu meresap kedalam daging ayam.masukkan potongan bawang prei dalam rebusan kuah.
1. Lalu bumbui dengan gula,garam dan kaldu bubuk.test rasa jika sudah pas masak hingga kuah mendidih matikan.
1. Angkat paha ayam goreng sedikit berkulit agar tektur agak padat.sisihkan
1. Cuci telur lalu rebus dengan cabai rawit hingga telur matang dan cabai rawit lunak.angkat sisihkan.
1. Cara membuat sambal soto : haluskan cabai rawit rebus dengan sedikit garam hingga halus.lalu sisihkan
1. Cara membuat koya : campur krupuk udang dan bawang putih goreng lalu haluskan hingga menjadi bubuk,lalu sisihkan.
1. Cara penyajian : masukkan satu centong nasi dalam mangkuk beri soun RRT,suwiran ayam,potongan telur rebus,daun seledri dan rajangan kol.lalu siram dengan kuah soto yang masih panas,beri taburan bawang merah goreng dan bubuk koya.sebagai pelengkap tambahkan kucuran air jeruk nipis dan sambal cabai rawit rebus.cocok dinikmati selagi hangat.selamat mencoba😋




Wah ternyata cara membuat soto ayam koya lamongan yang nikamt tidak ribet ini mudah banget ya! Anda Semua bisa membuatnya. Cara Membuat soto ayam koya lamongan Cocok banget buat kalian yang baru belajar memasak ataupun juga untuk kalian yang telah jago memasak.

Apakah kamu ingin mencoba bikin resep soto ayam koya lamongan lezat sederhana ini? Kalau kalian ingin, mending kamu segera siapkan peralatan dan bahannya, lantas bikin deh Resep soto ayam koya lamongan yang enak dan tidak ribet ini. Benar-benar mudah kan. 

Maka dari itu, ketimbang anda diam saja, maka kita langsung saja sajikan resep soto ayam koya lamongan ini. Dijamin anda tak akan menyesal sudah buat resep soto ayam koya lamongan nikmat simple ini! Selamat mencoba dengan resep soto ayam koya lamongan lezat tidak ribet ini di tempat tinggal kalian sendiri,oke!.

