---
description: "Cara membuat Ayam Kari Khas Aceh yang lezat Untuk Jualan"
title: "Cara membuat Ayam Kari Khas Aceh yang lezat Untuk Jualan"
slug: 167-cara-membuat-ayam-kari-khas-aceh-yang-lezat-untuk-jualan
date: 2021-06-13T12:21:29.978Z
image: https://img-global.cpcdn.com/recipes/cb4b927659bfdf30/680x482cq70/ayam-kari-khas-aceh-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/cb4b927659bfdf30/680x482cq70/ayam-kari-khas-aceh-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/cb4b927659bfdf30/680x482cq70/ayam-kari-khas-aceh-foto-resep-utama.jpg
author: Marc Ramirez
ratingvalue: 3
reviewcount: 6
recipeingredient:
- "1 ekor ayam pejantan"
- "3 sdm kelapa blondo"
- "2 santan instan"
- "700 ml air"
- " Minyak untuk menumis"
- " Bahan marinasi"
- "1 sdt garam"
- "1 sdt ketumbar bubuk"
- "1 sdt kunyit bubuk"
- "1 sdt lada bubuk"
- "1 sdt air jeruk nipis"
- " Bumbu halus"
- "7 bawang merah"
- "4 siung bawang putih"
- "1 sdt merica bulat"
- "1 sdt ketumbar bulat"
- "2 cabai lupa kefoto"
- "1/4 biji pala"
- " Bahan cemplung"
- "3 bawang merah iris"
- "2 lembar daun pandan"
- "1 batang daun kari"
- "2 kapulaga hijau"
- "3 cengkeh"
- "2 bunga lawang"
- " Seasoning"
- "1 1/2 sdt garam"
- "1 sdt kaldu bubuk"
- "1 sdt gula pasir"
- "1/4 keping gula aren"
recipeinstructions:
- "Cuci bersih ayam. Lalu masukkan ke wajan tambahkan bumbu marinasi uleni rata kemudian nyalakan api. Tidak perlu menggunakan air ya nnti ayamnya ngeluarin air. Ungkep selama 15 menit"
- "Uleg bumbu halus hingga lembut sisihkan."
- "Nah ayam yang sudah di ungkep tadi ditiriskan yaa pindahkan ke wajan lain kemudian tambahkan bumbu halus dan kelapa blondo serta tambahkan 100ml santan yang sudah diencerkan dengan air ungkep lagi selama 3 menit."
- "Siapkan bumbu cemplung. Iris bawang merah. Tumis semua bumbu cemplung hingga aromanya wangi kemudian masukkan ayam. Masukkan juga sisa santan yaa."
- "Tambahkan bumbu seasoningnya. Masak ayam hingga bumbu mengental dan mengeluarkan minyak (masak dengan api sedang wajan ditutup biar lebih cepat empuk) Ayam Kari Khas Aceh siap disajikan."
categories:
- Resep
tags:
- ayam
- kari
- khas

katakunci: ayam kari khas 
nutrition: 278 calories
recipecuisine: Indonesian
preptime: "PT17M"
cooktime: "PT44M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam Kari Khas Aceh](https://img-global.cpcdn.com/recipes/cb4b927659bfdf30/680x482cq70/ayam-kari-khas-aceh-foto-resep-utama.jpg)

Selaku seorang wanita, menyuguhkan masakan sedap pada orang tercinta adalah hal yang memuaskan bagi kita sendiri. Kewajiban seorang istri bukan cuma menjaga rumah saja, tetapi kamu pun wajib memastikan keperluan gizi terpenuhi dan juga masakan yang dikonsumsi keluarga tercinta mesti sedap.

Di era  saat ini, kamu sebenarnya dapat memesan olahan praktis meski tanpa harus ribet memasaknya terlebih dahulu. Namun banyak juga lho mereka yang memang ingin memberikan hidangan yang terbaik bagi keluarganya. Sebab, menyajikan masakan sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan makanan tersebut berdasarkan kesukaan keluarga tercinta. 



Apakah anda merupakan salah satu penggemar ayam kari khas aceh?. Asal kamu tahu, ayam kari khas aceh merupakan hidangan khas di Indonesia yang kini disenangi oleh banyak orang dari berbagai tempat di Indonesia. Anda bisa memasak ayam kari khas aceh hasil sendiri di rumahmu dan boleh jadi makanan kesenanganmu di akhir pekan.

Kalian tidak perlu bingung untuk memakan ayam kari khas aceh, lantaran ayam kari khas aceh mudah untuk didapatkan dan juga kalian pun boleh mengolahnya sendiri di tempatmu. ayam kari khas aceh dapat dibuat dengan beraneka cara. Saat ini telah banyak cara kekinian yang menjadikan ayam kari khas aceh lebih enak.

Resep ayam kari khas aceh pun gampang untuk dibuat, lho. Kalian jangan capek-capek untuk membeli ayam kari khas aceh, lantaran Kita dapat menyiapkan ditempatmu. Untuk Kita yang mau membuatnya, di bawah ini adalah resep untuk menyajikan ayam kari khas aceh yang mantab yang mampu Kamu hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Ayam Kari Khas Aceh:

1. Siapkan 1 ekor ayam pejantan
1. Siapkan 3 sdm kelapa blondo
1. Siapkan 2 santan instan
1. Gunakan 700 ml air
1. Sediakan  Minyak untuk menumis
1. Gunakan  Bahan marinasi
1. Ambil 1 sdt garam
1. Gunakan 1 sdt ketumbar bubuk
1. Siapkan 1 sdt kunyit bubuk
1. Ambil 1 sdt lada bubuk
1. Siapkan 1 sdt air jeruk nipis
1. Sediakan  Bumbu halus
1. Siapkan 7 bawang merah
1. Sediakan 4 siung bawang putih
1. Ambil 1 sdt merica bulat
1. Ambil 1 sdt ketumbar bulat
1. Siapkan 2 cabai (lupa kefoto)
1. Ambil 1/4 biji pala
1. Siapkan  Bahan cemplung
1. Ambil 3 bawang merah iris
1. Gunakan 2 lembar daun pandan
1. Gunakan 1 batang daun kari
1. Sediakan 2 kapulaga hijau
1. Siapkan 3 cengkeh
1. Siapkan 2 bunga lawang
1. Sediakan  Seasoning
1. Ambil 1 1/2 sdt garam
1. Siapkan 1 sdt kaldu bubuk
1. Gunakan 1 sdt gula pasir
1. Gunakan 1/4 keping gula aren




<!--inarticleads2-->

##### Cara membuat Ayam Kari Khas Aceh:

1. Cuci bersih ayam. Lalu masukkan ke wajan tambahkan bumbu marinasi uleni rata kemudian nyalakan api. Tidak perlu menggunakan air ya nnti ayamnya ngeluarin air. Ungkep selama 15 menit
1. Uleg bumbu halus hingga lembut sisihkan.
1. Nah ayam yang sudah di ungkep tadi ditiriskan yaa pindahkan ke wajan lain kemudian tambahkan bumbu halus dan kelapa blondo serta tambahkan 100ml santan yang sudah diencerkan dengan air ungkep lagi selama 3 menit.
1. Siapkan bumbu cemplung. Iris bawang merah. Tumis semua bumbu cemplung hingga aromanya wangi kemudian masukkan ayam. Masukkan juga sisa santan yaa.
1. Tambahkan bumbu seasoningnya. Masak ayam hingga bumbu mengental dan mengeluarkan minyak (masak dengan api sedang wajan ditutup biar lebih cepat empuk) Ayam Kari Khas Aceh siap disajikan.




Ternyata resep ayam kari khas aceh yang lezat tidak ribet ini gampang sekali ya! Kita semua mampu membuatnya. Cara buat ayam kari khas aceh Sangat cocok banget buat kamu yang sedang belajar memasak maupun juga bagi anda yang telah lihai dalam memasak.

Tertarik untuk mulai mencoba buat resep ayam kari khas aceh nikmat simple ini? Kalau ingin, mending kamu segera buruan siapkan peralatan dan bahan-bahannya, kemudian bikin deh Resep ayam kari khas aceh yang mantab dan tidak rumit ini. Sangat mudah kan. 

Jadi, daripada kalian berlama-lama, hayo langsung aja sajikan resep ayam kari khas aceh ini. Dijamin kalian gak akan nyesel sudah buat resep ayam kari khas aceh lezat tidak ribet ini! Selamat berkreasi dengan resep ayam kari khas aceh lezat tidak rumit ini di tempat tinggal masing-masing,ya!.

