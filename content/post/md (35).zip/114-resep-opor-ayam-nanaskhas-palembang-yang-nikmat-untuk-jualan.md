---
description: "Resep Opor ayam nanas(khas palembang) yang nikmat Untuk Jualan"
title: "Resep Opor ayam nanas(khas palembang) yang nikmat Untuk Jualan"
slug: 114-resep-opor-ayam-nanaskhas-palembang-yang-nikmat-untuk-jualan
date: 2021-01-25T12:29:22.794Z
image: https://img-global.cpcdn.com/recipes/e4c3de53e744f1d2/680x482cq70/opor-ayam-nanaskhas-palembang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e4c3de53e744f1d2/680x482cq70/opor-ayam-nanaskhas-palembang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e4c3de53e744f1d2/680x482cq70/opor-ayam-nanaskhas-palembang-foto-resep-utama.jpg
author: Gregory Newman
ratingvalue: 4.9
reviewcount: 4
recipeingredient:
- "1 ekor ayam potong sesuai selerah"
- "200 ml santan instant"
- "400 ml air"
- "1/2 buah nanascaca kasar"
- "2 buah kentangpotong dadu goreng sebentar"
- "1 batang seraimemarkan"
- "1 ruas lengkuasmemarkan"
- "2 lembar daun salam"
- "1/2 sdm gula pasir"
- "1/2 sdm garam"
- "Secukupnya kaldu jamur"
- " Bumbu halus"
- "10 siung bawang merah"
- "5 siung bawang putih"
- "1 ruas kunyit"
- "1 ruas jahe"
- "1 sdt ketumbar"
- "1/2 sdt merica butiran"
- "1 sdt bumbu opor kering siap pakai"
- "3 buah kemirisangrai"
- "Secukupnya minyak untuk menumis"
recipeinstructions:
- "Potong2 ayam sesuai selerah lalu cuci bersih dengan air mengalir tiriskan"
- "Panaskan secukupnya minyak,lalu tumis bumbu sampai harum tambahkan bumbu opor kering,serai lengkuas dan daun salam tumis sampai keluar minyak,lalu masukan daging ayam aduk rata"
- "Tambahkan cacahan nanas,kaldu jamur gula, garam santan dan juga air masak sampai mendidih dan air menyusut sambil terus di aduk agar santan tidak pecah"
- "Lalu masukan kentang,masak sebentar dan koreksi rasa jika sudah pas angkat dan siap di sajikan"
categories:
- Resep
tags:
- opor
- ayam
- nanaskhas

katakunci: opor ayam nanaskhas 
nutrition: 112 calories
recipecuisine: Indonesian
preptime: "PT17M"
cooktime: "PT52M"
recipeyield: "2"
recipecategory: Lunch

---


![Opor ayam nanas(khas palembang)](https://img-global.cpcdn.com/recipes/e4c3de53e744f1d2/680x482cq70/opor-ayam-nanaskhas-palembang-foto-resep-utama.jpg)

Sebagai seorang ibu, menyediakan santapan sedap pada orang tercinta merupakan suatu hal yang memuaskan bagi kamu sendiri. Peran seorang istri Tidak sekedar mengatur rumah saja, namun kamu juga harus menyediakan keperluan gizi tercukupi dan juga olahan yang dimakan keluarga tercinta wajib menggugah selera.

Di zaman  saat ini, kalian sebenarnya dapat memesan olahan praktis meski tanpa harus ribet memasaknya dahulu. Namun ada juga mereka yang memang ingin memberikan makanan yang terlezat bagi keluarganya. Sebab, menyajikan masakan yang diolah sendiri akan jauh lebih higienis dan bisa menyesuaikan masakan tersebut sesuai selera keluarga. 

Opor ayam pakai Nanas, tentu akan membuat hidangan Opor Ayam fruitaholic menjadi lebih Istimewa. Tidak hanya ayam yang bisa dimasak opor bebek, itik, sapi, kambing, terong Opor ayam nanas Palembang ini terbilang rasanya sangat enak campuran rasa gurih asin, manis dan pedas. Aneka resep opor ayam khas lebaran paling diburu oleh umat muslim karena makanan opor ayam ini menjadi favorit di hari raya Idul Fitri.

Mungkinkah anda adalah salah satu penyuka opor ayam nanas(khas palembang)?. Tahukah kamu, opor ayam nanas(khas palembang) adalah sajian khas di Indonesia yang saat ini disenangi oleh orang-orang di berbagai tempat di Nusantara. Kalian bisa menyajikan opor ayam nanas(khas palembang) kreasi sendiri di rumahmu dan pasti jadi hidangan kesenanganmu di akhir pekanmu.

Kalian jangan bingung untuk memakan opor ayam nanas(khas palembang), sebab opor ayam nanas(khas palembang) tidak sukar untuk ditemukan dan anda pun boleh membuatnya sendiri di tempatmu. opor ayam nanas(khas palembang) boleh diolah memalui beragam cara. Kini pun ada banyak cara modern yang menjadikan opor ayam nanas(khas palembang) semakin lebih lezat.

Resep opor ayam nanas(khas palembang) juga mudah untuk dibikin, lho. Kalian tidak usah ribet-ribet untuk membeli opor ayam nanas(khas palembang), lantaran Kalian dapat menyajikan ditempatmu. Bagi Anda yang ingin mencobanya, berikut cara membuat opor ayam nanas(khas palembang) yang nikamat yang bisa Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Opor ayam nanas(khas palembang):

1. Gunakan 1 ekor ayam potong sesuai selerah
1. Siapkan 200 ml santan instant
1. Siapkan 400 ml air
1. Sediakan 1/2 buah nanas,caca kasar
1. Sediakan 2 buah kentang,potong dadu goreng sebentar
1. Siapkan 1 batang serai,memarkan
1. Ambil 1 ruas lengkuas,memarkan
1. Sediakan 2 lembar daun salam
1. Sediakan 1/2 sdm gula pasir
1. Ambil 1/2 sdm garam
1. Siapkan Secukupnya kaldu jamur
1. Siapkan  Bumbu halus:
1. Gunakan 10 siung bawang merah
1. Gunakan 5 siung bawang putih
1. Siapkan 1 ruas kunyit
1. Gunakan 1 ruas jahe
1. Ambil 1 sdt ketumbar
1. Gunakan 1/2 sdt merica butiran
1. Ambil 1 sdt bumbu opor kering siap pakai
1. Ambil 3 buah kemiri,sangrai
1. Sediakan Secukupnya minyak untuk menumis


Selain ketupat, sebenarnya hidangan berkuah ini pun akan sangat nikmat ketika disantap dengan nasi putih hangat. Opor Ayam Nanas Khas Palembang Setelah kami publikasikan video cara memasak opor ayam tanpa nanas yang versi nasional. Opor ayam adalah salah satu makanan khas saat lebaran yang tidak pernah luput untuk disajikan oleh orang Indonesia. Meski opor biasa dibarengi dengan ayam, tapi sebenarnya terdapat menu pelengkap lain yang membuat opor makin spesial. 

<!--inarticleads2-->

##### Langkah-langkah menyiapkan Opor ayam nanas(khas palembang):

1. Potong2 ayam sesuai selerah lalu cuci bersih dengan air mengalir tiriskan
1. Panaskan secukupnya minyak,lalu tumis bumbu sampai harum tambahkan bumbu opor kering,serai lengkuas dan daun salam tumis sampai keluar minyak,lalu masukan daging ayam aduk rata
1. Tambahkan cacahan nanas,kaldu jamur gula, garam santan dan juga air masak sampai mendidih dan air menyusut sambil terus di aduk agar santan tidak pecah
1. Lalu masukan kentang,masak sebentar dan koreksi rasa jika sudah pas angkat dan siap di sajikan


Biasanya opor ini dimasak dengan kuah yang agak kental dan menggunakan santan kental dari satu buah kelapa Lihat juga resep Opor Anam khas Palembang enak lainnya. Resep Opor Ayam Spesial Resep Masakan Makanan Dan Minuman Resep Makanan. Siapa sih yang tidak kenal makanan khas palembang khususnya pempek dan tekwan. Dua makanan tersebut memang sangat diminati dan sangat Untuk memberi cita rasa yang nikmat, makanan khas adat Palembang ini akan disajikan bersama dengan kuah udang dengan rasa gurih dan udangnya. Opor Ayam sangat cocok disajikan dengan nasi hangat, tapi akan lebih cocok lagi jika dinikmat dengan ketupat. 

Wah ternyata cara membuat opor ayam nanas(khas palembang) yang lezat tidak rumit ini gampang sekali ya! Anda Semua bisa mencobanya. Resep opor ayam nanas(khas palembang) Sesuai banget buat kamu yang baru belajar memasak ataupun juga untuk kamu yang telah hebat memasak.

Apakah kamu ingin mencoba membuat resep opor ayam nanas(khas palembang) enak simple ini? Kalau kamu ingin, mending kamu segera menyiapkan alat dan bahan-bahannya, kemudian buat deh Resep opor ayam nanas(khas palembang) yang enak dan tidak ribet ini. Betul-betul gampang kan. 

Maka, daripada anda diam saja, ayo kita langsung buat resep opor ayam nanas(khas palembang) ini. Dijamin kamu tak akan nyesel sudah buat resep opor ayam nanas(khas palembang) enak tidak rumit ini! Selamat mencoba dengan resep opor ayam nanas(khas palembang) enak sederhana ini di tempat tinggal sendiri,oke!.

