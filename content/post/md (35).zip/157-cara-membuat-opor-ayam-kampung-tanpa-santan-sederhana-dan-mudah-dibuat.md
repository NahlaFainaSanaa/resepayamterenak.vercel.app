---
description: "Cara membuat Opor ayam kampung (tanpa santan) Sederhana dan Mudah Dibuat"
title: "Cara membuat Opor ayam kampung (tanpa santan) Sederhana dan Mudah Dibuat"
slug: 157-cara-membuat-opor-ayam-kampung-tanpa-santan-sederhana-dan-mudah-dibuat
date: 2021-05-07T06:44:25.820Z
image: https://img-global.cpcdn.com/recipes/0be090874722afbc/680x482cq70/opor-ayam-kampung-tanpa-santan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0be090874722afbc/680x482cq70/opor-ayam-kampung-tanpa-santan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0be090874722afbc/680x482cq70/opor-ayam-kampung-tanpa-santan-foto-resep-utama.jpg
author: Minerva Briggs
ratingvalue: 3.9
reviewcount: 9
recipeingredient:
- "500 gr ayam kampung"
- " Bumbu halus"
- "8 butir bawang merah"
- "5 siung bawang putih"
- "1/2 sdt ketumbar"
- "1/2 sdt ladamerica"
- "1/4 sdt jinten"
- "5 butir kemiri"
- "2 cm kunyit"
- " Tambahan"
- "2 cm lengkuas geprek"
- "3 lembar daun jeruk"
- "2 lembar daun salam"
- "1 ruas serai geprek"
- " Minyak untuk menumis"
- "2 gelas air"
- " Garam"
- " Gula"
- " Roykomasako"
- " Krimersusu pengganti santanbiasanya pakai fiber cream"
- " Bawang goreng untuk taburan"
- " Lontongketupat siap santap"
recipeinstructions:
- "Rebus potongan ayam kampung sampai setengah empuk/presto jika ayam kampung tua dengan sedikit garam,"
- "Tumis bumbu halus serta bumbu tambahan sampai harum y bun biar langunya ilang😄"
- "Masukkan potongan ayam kampung ke dalam bumbu oseng2 bentar kemudian tambahkan air"
- "Masukkan garam, gula, royko.. Icip2 untuk rasa yg pas y"
- "Kemudian encerkan krimer(pengganti santan) dengan sedikit air, masukkan lalu aduk2 tes rasa lagi y bun👍👍"
- "Biarkan hingga meresap kurleb 15mnt dengan api kecil lalu matikan"
- "Siap di hidangkan😄"
categories:
- Resep
tags:
- opor
- ayam
- kampung

katakunci: opor ayam kampung 
nutrition: 115 calories
recipecuisine: Indonesian
preptime: "PT36M"
cooktime: "PT38M"
recipeyield: "3"
recipecategory: Dessert

---


![Opor ayam kampung (tanpa santan)](https://img-global.cpcdn.com/recipes/0be090874722afbc/680x482cq70/opor-ayam-kampung-tanpa-santan-foto-resep-utama.jpg)

Andai kalian seorang wanita, menyediakan olahan nikmat untuk famili adalah suatu hal yang menggembirakan untuk anda sendiri. Kewajiban seorang istri bukan cuma mengerjakan pekerjaan rumah saja, namun anda juga harus menyediakan keperluan nutrisi tercukupi dan juga hidangan yang dikonsumsi orang tercinta wajib sedap.

Di masa  sekarang, kalian memang mampu membeli olahan jadi tanpa harus susah mengolahnya lebih dulu. Tapi banyak juga orang yang selalu mau memberikan hidangan yang terbaik bagi orang yang dicintainya. Sebab, menghidangkan masakan yang dibuat sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan masakan tersebut sesuai masakan kesukaan orang tercinta. 

Biarpun tanpa santan, resep opor ayam bisa tetap lezat untuk dinikmati kok teman-teman. Dengan paduan bumbu dan rempah yang tepat, rasa gurih dan berisi dari santan tetap bisa terimbangi bahkan oleh susu cair rendah lemak. Sajikan opor ayam tanpa santan dengan taburan bawang goreng.

Mungkinkah anda adalah seorang penggemar opor ayam kampung (tanpa santan)?. Asal kamu tahu, opor ayam kampung (tanpa santan) merupakan hidangan khas di Nusantara yang sekarang digemari oleh setiap orang di hampir setiap tempat di Indonesia. Kita dapat membuat opor ayam kampung (tanpa santan) hasil sendiri di rumahmu dan dapat dijadikan makanan favorit di akhir pekan.

Kamu tak perlu bingung jika kamu ingin menyantap opor ayam kampung (tanpa santan), karena opor ayam kampung (tanpa santan) mudah untuk didapatkan dan juga kita pun bisa membuatnya sendiri di tempatmu. opor ayam kampung (tanpa santan) dapat dimasak lewat beragam cara. Kini telah banyak sekali resep kekinian yang menjadikan opor ayam kampung (tanpa santan) lebih lezat.

Resep opor ayam kampung (tanpa santan) pun sangat mudah dibikin, lho. Kita jangan capek-capek untuk memesan opor ayam kampung (tanpa santan), karena Kamu mampu menyiapkan ditempatmu. Untuk Kamu yang akan menyajikannya, berikut ini cara membuat opor ayam kampung (tanpa santan) yang nikamat yang mampu Kita coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Opor ayam kampung (tanpa santan):

1. Ambil 500 gr ayam kampung
1. Gunakan  Bumbu halus:
1. Gunakan 8 butir bawang merah
1. Sediakan 5 siung bawang putih
1. Ambil 1/2 sdt ketumbar
1. Ambil 1/2 sdt lada/merica
1. Sediakan 1/4 sdt jinten
1. Ambil 5 butir kemiri
1. Siapkan 2 cm kunyit
1. Siapkan  Tambahan:
1. Siapkan 2 cm lengkuas geprek
1. Ambil 3 lembar daun jeruk
1. Ambil 2 lembar daun salam
1. Siapkan 1 ruas serai geprek
1. Siapkan  Minyak untuk menumis
1. Ambil 2 gelas air
1. Ambil  Garam
1. Gunakan  Gula
1. Gunakan  Royko/masako
1. Ambil  Krimer/susu pengganti santan(biasanya pakai fiber cream)
1. Gunakan  Bawang goreng untuk taburan
1. Ambil  Lontong/ketupat siap santap


Kuah santan dari opor ini jadi daya tarik utama yang biasa disajikan dengan nasi atau ketupat. opor ayam opor ayam bumbu kuning opor telur ayam kara masakan opor ayam menu buka puasa. Opor Ayam Tanpa Santan. daging ayam (sayap ayam, dada ayam, dan ceker ayam)•kunyit•lengkuas•jahe•bagian putih serai•bawang putih•bawang merah•kemiri (goreng). Opor ayam bisa dibuat dengan campuran ayam kampung agar hasil kuahnya gurih berkaldu. Cara memasak opor ayam tidak sulit. 

<!--inarticleads2-->

##### Langkah-langkah menyiapkan Opor ayam kampung (tanpa santan):

1. Rebus potongan ayam kampung sampai setengah empuk/presto jika ayam kampung tua dengan sedikit garam,
1. Tumis bumbu halus serta bumbu tambahan sampai harum y bun biar langunya ilang😄
1. Masukkan potongan ayam kampung ke dalam bumbu oseng2 bentar kemudian tambahkan air
1. Masukkan garam, gula, royko.. Icip2 untuk rasa yg pas y
1. Kemudian encerkan krimer(pengganti santan) dengan sedikit air, masukkan lalu aduk2 tes rasa lagi y bun👍👍
1. Biarkan hingga meresap kurleb 15mnt dengan api kecil lalu matikan
1. Siap di hidangkan😄


Untuk menghasilkan kuah yang kental, opor ayam tanpa santan ini menambahkan kemiri lebih banyak. Penasaran dengan resepnya? kamu bisa membuat opor ayam tanpa santan. Rasanya tetap gurih yang berasal dari kemiri. Kelezatan opor ayam terletak pada bahan santannya. Rasanya jadi makin gurih dan aromanya sedap. 

Ternyata cara buat opor ayam kampung (tanpa santan) yang mantab tidak rumit ini gampang banget ya! Kamu semua mampu memasaknya. Resep opor ayam kampung (tanpa santan) Sangat cocok banget untuk kamu yang sedang belajar memasak maupun bagi kamu yang telah pandai dalam memasak.

Apakah kamu mau mulai mencoba bikin resep opor ayam kampung (tanpa santan) enak simple ini? Kalau kalian ingin, mending kamu segera menyiapkan peralatan dan bahan-bahannya, setelah itu bikin deh Resep opor ayam kampung (tanpa santan) yang lezat dan tidak ribet ini. Benar-benar taidak sulit kan. 

Maka, daripada anda diam saja, hayo kita langsung buat resep opor ayam kampung (tanpa santan) ini. Dijamin kamu tiidak akan nyesel bikin resep opor ayam kampung (tanpa santan) mantab simple ini! Selamat mencoba dengan resep opor ayam kampung (tanpa santan) enak sederhana ini di tempat tinggal kalian sendiri,oke!.

