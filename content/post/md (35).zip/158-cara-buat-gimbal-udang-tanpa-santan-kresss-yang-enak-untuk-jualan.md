---
description: "Cara buat Gimbal udang tanpa santan (kresss) yang enak Untuk Jualan"
title: "Cara buat Gimbal udang tanpa santan (kresss) yang enak Untuk Jualan"
slug: 158-cara-buat-gimbal-udang-tanpa-santan-kresss-yang-enak-untuk-jualan
date: 2021-02-22T12:16:13.243Z
image: https://img-global.cpcdn.com/recipes/92a0c0d4296657c8/680x482cq70/gimbal-udang-tanpa-santan-kresss-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/92a0c0d4296657c8/680x482cq70/gimbal-udang-tanpa-santan-kresss-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/92a0c0d4296657c8/680x482cq70/gimbal-udang-tanpa-santan-kresss-foto-resep-utama.jpg
author: Sue Murray
ratingvalue: 4.2
reviewcount: 11
recipeingredient:
- " Bahan utama"
- "1/2 kg udang"
- "7 sdm tepung beras"
- "4 sdm tepung terigu"
- "4 sdm tepung tapioka"
- "1 butir telor kalo bisa ukuran besar"
- "1/2 santan kara aku gak pake"
- "Secukupnya air"
- "4 daun jeruk di iris tipis"
- " Bumbu halus"
- "4 siung bawang putih"
- "8 siung bawang merah karena punya saya bawang merah nya kecil"
- "5 butir kemiri"
- "1 sdm ketumbar"
- "1 1/2 ruas jari kunyit"
- "1/2 sdt garam bisa ditambah kalo mau"
- "1 sdm kaldu jamur bisa di ganti kaldu ayam"
recipeinstructions:
- "Haluskan semua bumbu²"
- "Campurkan semua bumbu beserta bahan² kemudia masukkan air hingga agak cair. Aduk rata"
- "Panaskan wajan dan goreng dengan minyak yg agak banyak. Saat menggoreng gunakan api kecil agar tidak cepat kecoklatan atau gosong. Tiriskan"
categories:
- Resep
tags:
- gimbal
- udang
- tanpa

katakunci: gimbal udang tanpa 
nutrition: 194 calories
recipecuisine: Indonesian
preptime: "PT19M"
cooktime: "PT57M"
recipeyield: "4"
recipecategory: Lunch

---


![Gimbal udang tanpa santan (kresss)](https://img-global.cpcdn.com/recipes/92a0c0d4296657c8/680x482cq70/gimbal-udang-tanpa-santan-kresss-foto-resep-utama.jpg)

Selaku seorang ibu, mempersiapkan hidangan nikmat untuk keluarga merupakan suatu hal yang memuaskan untuk kamu sendiri. Tugas seorang ibu Tidak cuma mengatur rumah saja, namun kamu juga wajib menyediakan keperluan nutrisi terpenuhi dan juga masakan yang disantap orang tercinta wajib nikmat.

Di waktu  saat ini, kita memang bisa mengorder hidangan siap saji tanpa harus susah mengolahnya dahulu. Tapi ada juga orang yang memang mau memberikan hidangan yang terbaik untuk orang tercintanya. Sebab, menyajikan masakan sendiri jauh lebih higienis dan kita pun bisa menyesuaikan hidangan tersebut berdasarkan makanan kesukaan famili. 

Gimbal udang tanpa santan (kresss). udang•tepung beras•tepung terigu•tepung tapioka•telor (kalo bisa ukuran besar)•santan kara (aku gak pake)•air•daun jeruk di iris tipis². Nama gimbal ternyata sebutan untuk udang digoreng pakai telur bagi orang Semarang. Nah, untuk mencobanya, mampir saja ke deretan lokasi Tahu gimbal di sini memiliki rasa yang khas.

Apakah kamu seorang penikmat gimbal udang tanpa santan (kresss)?. Tahukah kamu, gimbal udang tanpa santan (kresss) merupakan hidangan khas di Indonesia yang kini digemari oleh orang-orang dari hampir setiap wilayah di Indonesia. Kamu dapat membuat gimbal udang tanpa santan (kresss) olahan sendiri di rumahmu dan boleh jadi camilan kesenanganmu di hari libur.

Kita jangan bingung untuk mendapatkan gimbal udang tanpa santan (kresss), sebab gimbal udang tanpa santan (kresss) tidak sulit untuk dicari dan anda pun dapat menghidangkannya sendiri di rumah. gimbal udang tanpa santan (kresss) boleh diolah lewat berbagai cara. Kini telah banyak cara modern yang menjadikan gimbal udang tanpa santan (kresss) semakin enak.

Resep gimbal udang tanpa santan (kresss) pun mudah sekali untuk dibuat, lho. Kamu tidak usah ribet-ribet untuk memesan gimbal udang tanpa santan (kresss), karena Kalian bisa menyajikan di rumahmu. Untuk Kalian yang hendak menghidangkannya, di bawah ini adalah resep untuk membuat gimbal udang tanpa santan (kresss) yang lezat yang bisa Anda coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Gimbal udang tanpa santan (kresss):

1. Gunakan  Bahan utama
1. Gunakan 1/2 kg udang
1. Sediakan 7 sdm tepung beras
1. Siapkan 4 sdm tepung terigu
1. Siapkan 4 sdm tepung tapioka
1. Siapkan 1 butir telor (kalo bisa ukuran besar)
1. Gunakan 1/2 santan kara (aku gak pake)
1. Gunakan Secukupnya air
1. Gunakan 4 daun jeruk di iris tipis²
1. Ambil  Bumbu halus
1. Gunakan 4 siung bawang putih
1. Gunakan 8 siung bawang merah (karena punya saya bawang merah nya kecil²)
1. Siapkan 5 butir kemiri
1. Gunakan 1 sdm ketumbar
1. Ambil 1 1/2 ruas jari kunyit
1. Siapkan 1/2 sdt garam (bisa ditambah kalo mau)
1. Sediakan 1 sdm kaldu jamur (bisa di ganti kaldu ayam)


Masukkan tepung terigu, tepung beras, dan santan. Pada umumnya, Gimbal udang adalah salah satu bahan penting yang biasanya disajikan sebagai pelengkap tahu gimbal. Selanjutnya, Campurkan kocokan telur ayam degan tepung terigu, kemudian tambahkan sedikit air dan santan hingga kira-kira seperti adonan pisang. Resep gimbal udang ini sejenis olahan makanan goreng-gorengan, yang terbuat dari udang yang dipotong kecil-kecil lalu dicampur kedalam tepung terigu yang telah dicampur dengan santan. 

<!--inarticleads2-->

##### Langkah-langkah menyiapkan Gimbal udang tanpa santan (kresss):

1. Haluskan semua bumbu²
1. Campurkan semua bumbu beserta bahan² kemudia masukkan air hingga agak cair. Aduk rata
1. Panaskan wajan dan goreng dengan minyak yg agak banyak. Saat menggoreng gunakan api kecil agar tidak cepat kecoklatan atau gosong. Tiriskan


Rasanya unik karena memang berbeda tidak seperti bakwan ataupun rempeyek. Gimbal Udang dapat dijadikan menu tambahan atau cemilan keluarga. Berikut resep kacang ijo tanpa santan yang bisa kamu coba di rumah. Resep Membuat Bubur Kacang Ijo Tanpa Santan, Sedap dan Hangat di Tubuh. #RamadanDiRumah Cocok buat jadi menu takjil buka puasa. Nangka muda yang dilengkapi dengan udang serta memanfaatkan air kaldu akan mengasilkan cita rasa yang begitu lezat dan nikmat. 

Ternyata cara buat gimbal udang tanpa santan (kresss) yang nikamt tidak rumit ini gampang sekali ya! Kalian semua mampu menghidangkannya. Resep gimbal udang tanpa santan (kresss) Sangat sesuai sekali buat anda yang sedang belajar memasak maupun untuk anda yang telah pandai memasak.

Tertarik untuk mencoba buat resep gimbal udang tanpa santan (kresss) nikmat tidak ribet ini? Kalau kalian mau, ayo kalian segera siapkan peralatan dan bahannya, lantas bikin deh Resep gimbal udang tanpa santan (kresss) yang lezat dan sederhana ini. Sangat gampang kan. 

Oleh karena itu, daripada kamu berlama-lama, yuk kita langsung saja hidangkan resep gimbal udang tanpa santan (kresss) ini. Pasti kamu tak akan menyesal sudah buat resep gimbal udang tanpa santan (kresss) enak tidak rumit ini! Selamat mencoba dengan resep gimbal udang tanpa santan (kresss) lezat simple ini di tempat tinggal kalian masing-masing,ya!.

