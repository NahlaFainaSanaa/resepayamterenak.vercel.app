---
description: "Cara membuat Ayam Tangkap Khas Aceh yang nikmat Untuk Jualan"
title: "Cara membuat Ayam Tangkap Khas Aceh yang nikmat Untuk Jualan"
slug: 180-cara-membuat-ayam-tangkap-khas-aceh-yang-nikmat-untuk-jualan
date: 2021-04-12T00:21:18.069Z
image: https://img-global.cpcdn.com/recipes/1c8bac7cbf8c2cea/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1c8bac7cbf8c2cea/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1c8bac7cbf8c2cea/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg
author: Jason Moreno
ratingvalue: 4.9
reviewcount: 11
recipeingredient:
- "1 ekor ayam organik bagian dada dan paha potong 8"
- "750 ml Hydrococo"
- " Bumbu halus"
- "3 butir kemiri sangrai"
- "6 butir bawang merah"
- "4 siung bawang putih"
- "5 cm lengkuas"
- "5 cm kunyit"
- " Bumbu cemplung"
- "2 batang serai geprek"
- "5 lembar daun salam"
- "1/2 sdm garam sesuai selera"
- " Bahan cemplung saat menggoreng"
- "4 lembar daun pandan"
- "4 batang daun karisalam koja ambil daunnya"
- "5 lembar daun jeruk"
recipeinstructions:
- "Ayam dilumuri pakai air jeruk nipis kemudian bilas menggunakan air mengalir, tiriskan. Sementara itu bumbu halus dihaluskan."
- "Tumis bumbu halus sampai harum, kemudian masukan ayam, aduk ayam pelan pelan sampai bumbu rata. Selanjutnya tuang hydrococo, serai, daun salam dan garam. Ungkep ayam sampai bumbu meresap dan aii hydrococo menyusut."
- "Kalau sudah set airnya, ayam dapat disimpan di dalam kulkas jika tidak langsung digoreng."
- "Cara menggoreng ayam tangkap:  goreng menggunakan wajan anti lengket dengan minyak yang merendam setengah bagian ayam. Setelah ayam kecoklatan balik bagian sisi lainnya dan masukan daun pandan, daun salam koja, dan daun jeruk nipis."
- "Goreng ayam sampai kecoklatan. Cara penyajian: tuang daun salam koja dan daun pandan di atas piring kemudian letakan ayam di atasnya."
categories:
- Resep
tags:
- ayam
- tangkap
- khas

katakunci: ayam tangkap khas 
nutrition: 280 calories
recipecuisine: Indonesian
preptime: "PT34M"
cooktime: "PT32M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam Tangkap Khas Aceh](https://img-global.cpcdn.com/recipes/1c8bac7cbf8c2cea/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg)

Sebagai seorang istri, mempersiapkan olahan nikmat pada famili merupakan suatu hal yang mengasyikan untuk anda sendiri. Peran seorang  wanita bukan cuma mengurus rumah saja, namun anda pun harus menyediakan kebutuhan gizi terpenuhi dan santapan yang disantap anak-anak mesti menggugah selera.

Di zaman  saat ini, kita memang bisa memesan olahan jadi tanpa harus repot memasaknya terlebih dahulu. Tapi banyak juga lho mereka yang selalu mau memberikan hidangan yang terbaik untuk orang tercintanya. Karena, menyajikan masakan yang dibuat sendiri jauh lebih bersih dan bisa menyesuaikan berdasarkan kesukaan orang tercinta. 



Apakah kamu seorang penyuka ayam tangkap khas aceh?. Tahukah kamu, ayam tangkap khas aceh adalah sajian khas di Nusantara yang sekarang digemari oleh kebanyakan orang di hampir setiap tempat di Indonesia. Kalian dapat membuat ayam tangkap khas aceh hasil sendiri di rumahmu dan pasti jadi hidangan favoritmu di akhir pekanmu.

Anda tidak usah bingung untuk memakan ayam tangkap khas aceh, karena ayam tangkap khas aceh tidak sukar untuk ditemukan dan anda pun dapat menghidangkannya sendiri di tempatmu. ayam tangkap khas aceh bisa dimasak dengan beragam cara. Sekarang telah banyak sekali resep kekinian yang membuat ayam tangkap khas aceh lebih lezat.

Resep ayam tangkap khas aceh juga gampang dibikin, lho. Kalian tidak perlu repot-repot untuk membeli ayam tangkap khas aceh, karena Anda bisa menghidangkan ditempatmu. Bagi Kita yang mau menghidangkannya, dibawah ini merupakan cara menyajikan ayam tangkap khas aceh yang nikamat yang mampu Kalian buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Ayam Tangkap Khas Aceh:

1. Gunakan 1 ekor ayam organik bagian dada dan paha potong 8
1. Sediakan 750 ml Hydrococo
1. Gunakan  Bumbu halus
1. Gunakan 3 butir kemiri sangrai
1. Sediakan 6 butir bawang merah
1. Siapkan 4 siung bawang putih
1. Siapkan 5 cm lengkuas
1. Sediakan 5 cm kunyit
1. Gunakan  Bumbu cemplung
1. Siapkan 2 batang serai geprek
1. Sediakan 5 lembar daun salam
1. Gunakan 1/2 sdm garam (sesuai selera)
1. Siapkan  Bahan cemplung saat menggoreng
1. Sediakan 4 lembar daun pandan
1. Gunakan 4 batang daun kari/salam koja ambil daunnya
1. Sediakan 5 lembar daun jeruk




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam Tangkap Khas Aceh:

1. Ayam dilumuri pakai air jeruk nipis kemudian bilas menggunakan air mengalir, tiriskan. Sementara itu bumbu halus dihaluskan.
1. Tumis bumbu halus sampai harum, kemudian masukan ayam, aduk ayam pelan pelan sampai bumbu rata. Selanjutnya tuang hydrococo, serai, daun salam dan garam. Ungkep ayam sampai bumbu meresap dan aii hydrococo menyusut.
1. Kalau sudah set airnya, ayam dapat disimpan di dalam kulkas jika tidak langsung digoreng.
1. Cara menggoreng ayam tangkap:  - goreng menggunakan wajan anti lengket dengan minyak yang merendam setengah bagian ayam. Setelah ayam kecoklatan balik bagian sisi lainnya dan masukan daun pandan, daun salam koja, dan daun jeruk nipis.
1. Goreng ayam sampai kecoklatan. Cara penyajian: tuang daun salam koja dan daun pandan di atas piring kemudian letakan ayam di atasnya.




Wah ternyata cara buat ayam tangkap khas aceh yang lezat sederhana ini enteng sekali ya! Semua orang mampu menghidangkannya. Resep ayam tangkap khas aceh Cocok banget untuk kalian yang baru belajar memasak ataupun bagi kalian yang sudah ahli memasak.

Tertarik untuk mulai mencoba buat resep ayam tangkap khas aceh mantab sederhana ini? Kalau kamu ingin, ayo kamu segera buruan siapkan alat-alat dan bahannya, lalu bikin deh Resep ayam tangkap khas aceh yang mantab dan tidak rumit ini. Sangat mudah kan. 

Jadi, ketimbang kamu berlama-lama, ayo kita langsung buat resep ayam tangkap khas aceh ini. Dijamin anda tiidak akan menyesal sudah bikin resep ayam tangkap khas aceh mantab tidak rumit ini! Selamat mencoba dengan resep ayam tangkap khas aceh enak simple ini di rumah sendiri,oke!.

