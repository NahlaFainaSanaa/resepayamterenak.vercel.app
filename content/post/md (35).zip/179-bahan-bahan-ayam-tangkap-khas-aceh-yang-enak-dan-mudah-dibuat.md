---
description: "Bahan-bahan Ayam Tangkap khas Aceh yang enak dan Mudah Dibuat"
title: "Bahan-bahan Ayam Tangkap khas Aceh yang enak dan Mudah Dibuat"
slug: 179-bahan-bahan-ayam-tangkap-khas-aceh-yang-enak-dan-mudah-dibuat
date: 2021-04-16T03:01:50.380Z
image: https://img-global.cpcdn.com/recipes/2431780ff7597134/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2431780ff7597134/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2431780ff7597134/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg
author: Paul Norman
ratingvalue: 4.3
reviewcount: 8
recipeingredient:
- "1 ekor ayam saya pakai ayam kampung"
- "5 lbr daun pandan"
- "5 batang daun kari"
- "3 lbr daun jeruk"
- "5 bh cabe hijau optional"
- " Minyak"
- " Bumbu halus"
- "3 bh kemiri"
- "7 siung Bawang merah"
- "3 siung Bawang putih"
- "1 cm Kunyit"
- "1,5 cm lengkuas"
- "1 cm Jahe opsional"
- " Bumbu cemplung untuk rebus ayam"
- "1 bh air kelapa opsional"
- "1 btg sereh"
- "1 lbr daun pandan"
- "3 lbr daun salam"
- "1 lbr daun jeruk"
- "secukupnya Air asam jawa"
- "Secukupnya garam"
recipeinstructions:
- "Potong ayam menjadi beberapa bagian, cuci bersih, dan sisihkan"
- "Siapkan bumbu halus, sisihkan Lalu potong2 kecil daun aroma (pandan, daun kari dan daun jeruk), potong memanjang cabe hijau, sisihkan"
- "Rebus ayam yg sudah dibersihkan dengan air kelapa (optional), masukan bumbu cemplung dan bumbu halus (atau bisa ditumis terlebih dahulu), rebus hingga empuk dan airnya menyusut"
- "Siapkan minyak untuk menggoreng, goreng ayam yg sudah diungkep dengan daun aroma (daun pandan, daun kari dan daun jeruk) hingga kecoklatan, siap untuk dihidangkan"
- "Kalau tidak ingin digoreng semuanya, bisa disimpan utk stok dan digoreng nanti"
categories:
- Resep
tags:
- ayam
- tangkap
- khas

katakunci: ayam tangkap khas 
nutrition: 278 calories
recipecuisine: Indonesian
preptime: "PT20M"
cooktime: "PT54M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam Tangkap khas Aceh](https://img-global.cpcdn.com/recipes/2431780ff7597134/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg)

Sebagai seorang istri, menyajikan santapan mantab untuk famili adalah hal yang sangat menyenangkan bagi anda sendiri. Tugas seorang istri bukan sekadar mengerjakan pekerjaan rumah saja, tetapi anda pun harus memastikan kebutuhan nutrisi tercukupi dan olahan yang dimakan keluarga tercinta wajib sedap.

Di waktu  sekarang, kita memang bisa membeli santapan instan walaupun tanpa harus susah memasaknya dulu. Tapi banyak juga mereka yang selalu mau menghidangkan yang terenak untuk orang yang dicintainya. Karena, menyajikan masakan sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan hidangan tersebut sesuai masakan kesukaan orang tercinta. 



Apakah anda merupakan seorang penggemar ayam tangkap khas aceh?. Asal kamu tahu, ayam tangkap khas aceh merupakan makanan khas di Nusantara yang sekarang disukai oleh orang-orang di berbagai daerah di Indonesia. Kamu bisa menyajikan ayam tangkap khas aceh sendiri di rumahmu dan boleh dijadikan camilan kesukaanmu di akhir pekanmu.

Kalian tak perlu bingung untuk mendapatkan ayam tangkap khas aceh, karena ayam tangkap khas aceh tidak sulit untuk dicari dan juga kalian pun boleh memasaknya sendiri di rumah. ayam tangkap khas aceh dapat dimasak lewat beragam cara. Kini ada banyak banget resep kekinian yang menjadikan ayam tangkap khas aceh semakin mantap.

Resep ayam tangkap khas aceh juga gampang sekali dihidangkan, lho. Kita tidak usah ribet-ribet untuk membeli ayam tangkap khas aceh, sebab Kamu dapat menyajikan sendiri di rumah. Bagi Kamu yang hendak menyajikannya, berikut resep menyajikan ayam tangkap khas aceh yang enak yang mampu Kalian hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Ayam Tangkap khas Aceh:

1. Gunakan 1 ekor ayam (saya pakai ayam kampung)
1. Ambil 5 lbr daun pandan
1. Sediakan 5 batang daun kari
1. Ambil 3 lbr daun jeruk
1. Ambil 5 bh cabe hijau (optional)
1. Ambil  Minyak
1. Ambil  Bumbu halus
1. Sediakan 3 bh kemiri
1. Ambil 7 siung Bawang merah
1. Gunakan 3 siung Bawang putih
1. Ambil 1 cm Kunyit
1. Ambil 1,5 cm lengkuas
1. Gunakan 1 cm Jahe (opsional)
1. Ambil  Bumbu cemplung untuk rebus ayam
1. Siapkan 1 bh air kelapa (opsional)
1. Gunakan 1 btg sereh
1. Ambil 1 lbr daun pandan
1. Ambil 3 lbr daun salam
1. Gunakan 1 lbr daun jeruk
1. Siapkan secukupnya Air asam jawa
1. Sediakan Secukupnya garam




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam Tangkap khas Aceh:

1. Potong ayam menjadi beberapa bagian, cuci bersih, dan sisihkan
1. Siapkan bumbu halus, sisihkan - Lalu potong2 kecil daun aroma (pandan, daun kari dan daun jeruk), potong memanjang cabe hijau, sisihkan
1. Rebus ayam yg sudah dibersihkan dengan air kelapa (optional), masukan bumbu cemplung dan bumbu halus (atau bisa ditumis terlebih dahulu), rebus hingga empuk dan airnya menyusut
1. Siapkan minyak untuk menggoreng, goreng ayam yg sudah diungkep dengan daun aroma (daun pandan, daun kari dan daun jeruk) hingga kecoklatan, siap untuk dihidangkan
1. Kalau tidak ingin digoreng semuanya, bisa disimpan utk stok dan digoreng nanti




Wah ternyata cara membuat ayam tangkap khas aceh yang lezat simple ini enteng sekali ya! Kamu semua bisa mencobanya. Cara buat ayam tangkap khas aceh Sesuai banget buat kalian yang baru mau belajar memasak ataupun bagi kamu yang telah jago memasak.

Tertarik untuk mencoba membuat resep ayam tangkap khas aceh mantab simple ini? Kalau kamu mau, yuk kita segera buruan siapkan peralatan dan bahan-bahannya, lalu bikin deh Resep ayam tangkap khas aceh yang nikmat dan simple ini. Benar-benar mudah kan. 

Maka dari itu, daripada kamu berfikir lama-lama, maka kita langsung sajikan resep ayam tangkap khas aceh ini. Pasti anda gak akan menyesal bikin resep ayam tangkap khas aceh lezat simple ini! Selamat mencoba dengan resep ayam tangkap khas aceh mantab simple ini di tempat tinggal masing-masing,ya!.

