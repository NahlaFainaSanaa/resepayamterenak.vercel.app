---
description: "Cara membuat Rempelo Ati Ayam masak santan yang enak dan Mudah Dibuat"
title: "Cara membuat Rempelo Ati Ayam masak santan yang enak dan Mudah Dibuat"
slug: 279-cara-membuat-rempelo-ati-ayam-masak-santan-yang-enak-dan-mudah-dibuat
date: 2021-03-15T04:41:20.250Z
image: https://img-global.cpcdn.com/recipes/30d52a1bcc6aee39/680x482cq70/rempelo-ati-ayam-masak-santan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/30d52a1bcc6aee39/680x482cq70/rempelo-ati-ayam-masak-santan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/30d52a1bcc6aee39/680x482cq70/rempelo-ati-ayam-masak-santan-foto-resep-utama.jpg
author: Calvin McKenzie
ratingvalue: 4.2
reviewcount: 9
recipeingredient:
- "5 pasang rempelo ati ayam"
- "1 buah kentang besar"
- "2 potong tahu putih"
- "5 siung bawang merah"
- "5 siung bawang putih"
- "10 biji cabe rawit"
- "sepotong kunyit daun salam jeruk purut garam penyedap rasa"
- "1 bungkus santan kara"
recipeinstructions:
- "Rempelo ati di cuci bersih. lumuri jeruk nipis agar tidak bau amis. lalu bilas lagi sampai bersih."
- "Potong dadu rempelo ati. lalu rebus hingga rempelo lunak."
- "Potong dadu kentang dan tahu."
- "Haluskan bawang merah, bawang putih, kunyit dan cabe.."
- "Tumis bumbu halus hingga harum. masukkan kentang dan tahu, daun salam dan jeruk purut. beri air sedikit. biarkan bumbu meresap dan kentang lunak."
- "Lalu masukkan rempelo ati ayam serta santan kara. beri air sesuai selera. beri garam dan penyedap rasa."
- "Tunggu hingga mendidih. dan rempelo ati siap di sajikan💜💜"
categories:
- Resep
tags:
- rempelo
- ati
- ayam

katakunci: rempelo ati ayam 
nutrition: 216 calories
recipecuisine: Indonesian
preptime: "PT26M"
cooktime: "PT47M"
recipeyield: "2"
recipecategory: Dessert

---


![Rempelo Ati Ayam masak santan](https://img-global.cpcdn.com/recipes/30d52a1bcc6aee39/680x482cq70/rempelo-ati-ayam-masak-santan-foto-resep-utama.jpg)

Apabila kamu seorang orang tua, menyajikan masakan nikmat kepada keluarga merupakan hal yang membahagiakan untuk kamu sendiri. Peran seorang  wanita Tidak saja mengatur rumah saja, namun kamu pun wajib memastikan keperluan nutrisi terpenuhi dan masakan yang dikonsumsi orang tercinta harus menggugah selera.

Di zaman  sekarang, kita sebenarnya bisa membeli olahan siap saji tanpa harus capek membuatnya lebih dulu. Tapi ada juga lho mereka yang selalu ingin memberikan hidangan yang terlezat untuk keluarganya. Lantaran, menyajikan masakan yang diolah sendiri akan jauh lebih bersih dan bisa menyesuaikan masakan tersebut sesuai kesukaan famili. 



Apakah kamu salah satu penikmat rempelo ati ayam masak santan?. Tahukah kamu, rempelo ati ayam masak santan adalah hidangan khas di Nusantara yang sekarang disenangi oleh orang-orang dari hampir setiap wilayah di Indonesia. Kalian dapat memasak rempelo ati ayam masak santan sendiri di rumahmu dan boleh dijadikan santapan kesenanganmu di akhir pekanmu.

Anda tidak perlu bingung jika kamu ingin menyantap rempelo ati ayam masak santan, karena rempelo ati ayam masak santan tidak sukar untuk didapatkan dan juga kamu pun boleh memasaknya sendiri di rumah. rempelo ati ayam masak santan boleh dibuat memalui beraneka cara. Kini pun telah banyak sekali cara modern yang membuat rempelo ati ayam masak santan lebih enak.

Resep rempelo ati ayam masak santan pun sangat mudah untuk dibikin, lho. Kalian tidak perlu capek-capek untuk membeli rempelo ati ayam masak santan, sebab Anda bisa menyajikan sendiri di rumah. Untuk Kamu yang ingin membuatnya, inilah resep menyajikan rempelo ati ayam masak santan yang lezat yang mampu Kalian hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Rempelo Ati Ayam masak santan:

1. Ambil 5 pasang rempelo ati ayam
1. Siapkan 1 buah kentang besar
1. Siapkan 2 potong tahu putih
1. Sediakan 5 siung bawang merah
1. Sediakan 5 siung bawang putih
1. Siapkan 10 biji cabe rawit
1. Siapkan sepotong kunyit, daun salam, jeruk purut. garam, penyedap rasa
1. Gunakan 1 bungkus santan kara




<!--inarticleads2-->

##### Cara membuat Rempelo Ati Ayam masak santan:

1. Rempelo ati di cuci bersih. lumuri jeruk nipis agar tidak bau amis. lalu bilas lagi sampai bersih.
1. Potong dadu rempelo ati. lalu rebus hingga rempelo lunak.
1. Potong dadu kentang dan tahu.
<img src="https://img-global.cpcdn.com/steps/a453d35f01ebecb7/160x128cq70/rempelo-ati-ayam-masak-santan-langkah-memasak-3-foto.jpg" alt="Rempelo Ati Ayam masak santan">1. Haluskan bawang merah, bawang putih, kunyit dan cabe..
1. Tumis bumbu halus hingga harum. masukkan kentang dan tahu, daun salam dan jeruk purut. beri air sedikit. biarkan bumbu meresap dan kentang lunak.
1. Lalu masukkan rempelo ati ayam serta santan kara. beri air sesuai selera. beri garam dan penyedap rasa.
1. Tunggu hingga mendidih. dan rempelo ati siap di sajikan💜💜




Ternyata cara membuat rempelo ati ayam masak santan yang lezat simple ini mudah banget ya! Kamu semua bisa mencobanya. Cara buat rempelo ati ayam masak santan Sangat sesuai sekali buat kalian yang sedang belajar memasak maupun untuk kamu yang sudah ahli dalam memasak.

Apakah kamu ingin mencoba membikin resep rempelo ati ayam masak santan nikmat tidak ribet ini? Kalau kamu mau, mending kamu segera buruan menyiapkan alat-alat dan bahannya, lantas bikin deh Resep rempelo ati ayam masak santan yang lezat dan tidak ribet ini. Sungguh gampang kan. 

Maka, ketimbang kamu diam saja, hayo kita langsung hidangkan resep rempelo ati ayam masak santan ini. Dijamin kamu tiidak akan menyesal membuat resep rempelo ati ayam masak santan mantab sederhana ini! Selamat mencoba dengan resep rempelo ati ayam masak santan lezat simple ini di rumah sendiri,oke!.

