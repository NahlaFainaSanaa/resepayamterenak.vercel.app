---
description: "Resep Soto Ayam Koya Lamongan yang lezat dan Mudah Dibuat"
title: "Resep Soto Ayam Koya Lamongan yang lezat dan Mudah Dibuat"
slug: 229-resep-soto-ayam-koya-lamongan-yang-lezat-dan-mudah-dibuat
date: 2021-02-24T15:46:55.977Z
image: https://img-global.cpcdn.com/recipes/60206b96cb130108/680x482cq70/soto-ayam-koya-lamongan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/60206b96cb130108/680x482cq70/soto-ayam-koya-lamongan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/60206b96cb130108/680x482cq70/soto-ayam-koya-lamongan-foto-resep-utama.jpg
author: Steven Martinez
ratingvalue: 4.3
reviewcount: 5
recipeingredient:
- "1/2 kg kepalaleher ayam"
- "1 buah jeruk nipis sesuai selera"
- "1 ikat daun seledrirajang halus"
- "1 batang bawang pre potongpotong saya skip krn kosong"
- "3 lembar daun jeruk sobek"
- "1 ruas laos geprek"
- "1 batang serai geprek"
- "1/2 sdt gula"
- "1 sdt garam"
- "1 sdt kaldu bubuk"
- " Bumbu Halus"
- "6 buah bawang merah"
- "4 siung bawang putih"
- "1 ruas sedang kunyit"
- "1 ruas sedang jahe"
- "1 sdm ketumbar"
- "1 sdt jinten saya sejumput"
- "2 buah kemiri"
- " Bahkan Koya"
- " Kerupuk udang sesuai selera"
- " Bawang putih goreng sesuai selera"
- " Pelengkap"
- "Secukupnya bawang merah goreng saya skip"
- " Bihun saya skip"
- " Telur rebus saya skip"
recipeinstructions:
- "Cuci bersih ayam, rebus sebentar lalu tiriskan, ganti dengan air baru dan rebus kembali."
- "Tumis bumbu halus beserta daun jeruk, serai dan laos hingga tercium aromanya, tambahkan sedikit air lalu masukkan ke dalam rebusan ayam tadi."
- "Tambahkan garam, gula dan penyedap, masak hingga bumbu meresap ke dalam ayam."
- "Koreksi rasa, matikan api, ambil ayam, suir2 daging dan kulitnya, masukkan kembali ke dalam kuah."
- "Membuat koya: goreng kerupuk udang, lalu haluskan dengan bawang putih goreng."
- "Sajikan hangat 🌻"
categories:
- Resep
tags:
- soto
- ayam
- koya

katakunci: soto ayam koya 
nutrition: 176 calories
recipecuisine: Indonesian
preptime: "PT32M"
cooktime: "PT51M"
recipeyield: "4"
recipecategory: Dessert

---


![Soto Ayam Koya Lamongan](https://img-global.cpcdn.com/recipes/60206b96cb130108/680x482cq70/soto-ayam-koya-lamongan-foto-resep-utama.jpg)

Sebagai seorang wanita, menyediakan santapan lezat untuk famili merupakan suatu hal yang mengasyikan bagi anda sendiri. Peran seorang istri Tidak hanya menjaga rumah saja, tetapi anda pun harus memastikan keperluan nutrisi tercukupi dan olahan yang dikonsumsi anak-anak wajib lezat.

Di zaman  sekarang, kalian sebenarnya bisa mengorder masakan yang sudah jadi meski tidak harus repot membuatnya dulu. Namun banyak juga lho mereka yang memang ingin menyajikan yang terbaik untuk orang tercintanya. Sebab, memasak sendiri jauh lebih higienis dan bisa menyesuaikan hidangan tersebut sesuai selera keluarga. 



Apakah anda merupakan seorang penggemar soto ayam koya lamongan?. Asal kamu tahu, soto ayam koya lamongan adalah sajian khas di Indonesia yang saat ini disenangi oleh setiap orang dari berbagai tempat di Nusantara. Kamu bisa menghidangkan soto ayam koya lamongan sendiri di rumah dan dapat dijadikan santapan favoritmu di akhir pekanmu.

Kamu tidak perlu bingung jika kamu ingin mendapatkan soto ayam koya lamongan, sebab soto ayam koya lamongan gampang untuk dicari dan juga kita pun dapat memasaknya sendiri di rumah. soto ayam koya lamongan boleh dimasak dengan beragam cara. Sekarang telah banyak banget cara modern yang menjadikan soto ayam koya lamongan semakin lebih enak.

Resep soto ayam koya lamongan pun gampang sekali dibuat, lho. Anda tidak usah ribet-ribet untuk membeli soto ayam koya lamongan, lantaran Anda bisa menghidangkan di rumahmu. Bagi Kita yang hendak mencobanya, berikut resep untuk menyajikan soto ayam koya lamongan yang nikamat yang mampu Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Soto Ayam Koya Lamongan:

1. Siapkan 1/2 kg kepala+leher ayam
1. Siapkan 1 buah jeruk nipis (sesuai selera)
1. Ambil 1 ikat daun seledri,rajang halus
1. Gunakan 1 batang bawang pre, potong-potong (saya skip krn kosong)
1. Gunakan 3 lembar daun jeruk, sobek
1. Gunakan 1 ruas laos, geprek
1. Sediakan 1 batang serai, geprek
1. Sediakan 1/2 sdt gula
1. Sediakan 1 sdt garam
1. Siapkan 1 sdt kaldu bubuk
1. Ambil  Bumbu Halus:
1. Siapkan 6 buah bawang merah
1. Siapkan 4 siung bawang putih
1. Gunakan 1 ruas sedang kunyit
1. Sediakan 1 ruas sedang jahe
1. Siapkan 1 sdm ketumbar
1. Gunakan 1 sdt jinten (saya sejumput)
1. Ambil 2 buah kemiri
1. Ambil  Bahkan Koya:
1. Gunakan  Kerupuk udang (sesuai selera)
1. Gunakan  Bawang putih goreng (sesuai selera)
1. Gunakan  Pelengkap:
1. Sediakan Secukupnya bawang merah goreng (saya skip)
1. Siapkan  Bihun (saya skip)
1. Ambil  Telur rebus (saya skip)




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Soto Ayam Koya Lamongan:

1. Cuci bersih ayam, rebus sebentar lalu tiriskan, ganti dengan air baru dan rebus kembali.
1. Tumis bumbu halus beserta daun jeruk, serai dan laos hingga tercium aromanya, tambahkan sedikit air lalu masukkan ke dalam rebusan ayam tadi.
1. Tambahkan garam, gula dan penyedap, masak hingga bumbu meresap ke dalam ayam.
1. Koreksi rasa, matikan api, ambil ayam, suir2 daging dan kulitnya, masukkan kembali ke dalam kuah.
1. Membuat koya: goreng kerupuk udang, lalu haluskan dengan bawang putih goreng.
1. Sajikan hangat 🌻




Wah ternyata cara buat soto ayam koya lamongan yang mantab tidak ribet ini mudah sekali ya! Kamu semua bisa membuatnya. Cara Membuat soto ayam koya lamongan Sangat sesuai sekali buat kita yang baru belajar memasak maupun bagi kalian yang telah hebat dalam memasak.

Apakah kamu mau mulai mencoba buat resep soto ayam koya lamongan mantab sederhana ini? Kalau kamu mau, yuk kita segera buruan siapin peralatan dan bahannya, lantas buat deh Resep soto ayam koya lamongan yang lezat dan simple ini. Betul-betul taidak sulit kan. 

Maka dari itu, daripada kalian berfikir lama-lama, maka kita langsung saja buat resep soto ayam koya lamongan ini. Pasti kamu gak akan nyesel membuat resep soto ayam koya lamongan mantab simple ini! Selamat berkreasi dengan resep soto ayam koya lamongan mantab tidak ribet ini di rumah sendiri,oke!.

