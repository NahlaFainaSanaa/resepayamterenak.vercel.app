---
description: "Cara membuat *ayam tepung asam manis* yang enak dan Mudah Dibuat"
title: "Cara membuat *ayam tepung asam manis* yang enak dan Mudah Dibuat"
slug: 341-cara-membuat-ayam-tepung-asam-manis-yang-enak-dan-mudah-dibuat
date: 2021-02-13T01:26:43.822Z
image: https://img-global.cpcdn.com/recipes/13679c74786222e5/680x482cq70/ayam-tepung-asam-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/13679c74786222e5/680x482cq70/ayam-tepung-asam-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/13679c74786222e5/680x482cq70/ayam-tepung-asam-manis-foto-resep-utama.jpg
author: Ronnie Collier
ratingvalue: 4.9
reviewcount: 8
recipeingredient:
- "250 gr ayam fillet"
- "1 bgks tepung bumbu"
- "1/2 siung bawang bombay tambahan sy"
- "1 butir telur kocok"
- "3 siung bawang putihkeprek cincang"
- "1 cabe merah besarsesuai selera"
- "1 btg daun bawang iris"
- " Bumbu "
- "2 sdm saus sambal"
- "2 sdm saus tomat"
- "2 sdm kecap manis"
- "1 sdm saus tiram"
- "1/2 sdt lada bubuk"
- "1/2 sdt garam"
- "1/2 sdt gula pasir"
- "200 ml air sy air minum"
recipeinstructions:
- "Siapkan bahan. Keprek lalu cincang bawang putih, iris tipis bawang bombay, cabe dan daun bawang. Cuci bersih ayam lalu potong kotak-kotak agak kecil/sesuai selera"
- "Untuk ayamnya aku rebus hingga mendidih (tidak direbus tidak apa-apa sesuai resep aslinya), tiriskan. Siapkan telur yg dikocok dan tepung bumbu. Celupkan ayam kedalam kocokan telur lalu masukkan ke tepung bumbu, guling2 kan dan ketuk2an"
- "Goreng ayam hingga kering, angkat, tiriskan. Tumis bawang putih dan bombay hingga harum"
- "Lalu masukkan ayam tepung yg sudah digoreng, beri air dan bumbu lainnya"
- "Dan juga irisan cabe,aduk rata dan masak hingga air berkurang dan akan mengental dg sendirinya, cek rasa lalu masukkan irisan daun bawang"
- "Aduk sebentar lalu matikan kompor dan angkat. Sajikan dg nasi hangat."
categories:
- Resep
tags:
- ayam
- tepung
- asam

katakunci: ayam tepung asam 
nutrition: 270 calories
recipecuisine: Indonesian
preptime: "PT21M"
cooktime: "PT56M"
recipeyield: "2"
recipecategory: Dessert

---


![*ayam tepung asam manis*](https://img-global.cpcdn.com/recipes/13679c74786222e5/680x482cq70/ayam-tepung-asam-manis-foto-resep-utama.jpg)

Jika kamu seorang yang hobi memasak, mempersiapkan masakan sedap buat keluarga adalah suatu hal yang membahagiakan untuk anda sendiri. Peran seorang  wanita bukan sekadar menjaga rumah saja, tapi kamu pun harus memastikan keperluan gizi tercukupi dan juga olahan yang dimakan orang tercinta wajib lezat.

Di masa  saat ini, kamu sebenarnya dapat memesan santapan instan tidak harus ribet mengolahnya lebih dulu. Namun banyak juga orang yang selalu ingin memberikan makanan yang terlezat untuk orang tercintanya. Pasalnya, menghidangkan masakan yang dibuat sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan masakan tersebut sesuai makanan kesukaan keluarga. 



Mungkinkah anda seorang penikmat *ayam tepung asam manis*?. Asal kamu tahu, *ayam tepung asam manis* adalah hidangan khas di Nusantara yang sekarang disukai oleh orang-orang dari hampir setiap tempat di Indonesia. Kalian dapat memasak *ayam tepung asam manis* olahan sendiri di rumah dan boleh dijadikan makanan kesukaanmu di hari liburmu.

Kita jangan bingung untuk memakan *ayam tepung asam manis*, lantaran *ayam tepung asam manis* tidak sukar untuk didapatkan dan juga kita pun boleh memasaknya sendiri di tempatmu. *ayam tepung asam manis* boleh dibuat lewat bermacam cara. Sekarang telah banyak cara kekinian yang membuat *ayam tepung asam manis* semakin lezat.

Resep *ayam tepung asam manis* pun sangat gampang dibikin, lho. Kamu jangan repot-repot untuk membeli *ayam tepung asam manis*, karena Anda bisa menyajikan ditempatmu. Bagi Anda yang hendak menyajikannya, dibawah ini merupakan cara untuk membuat *ayam tepung asam manis* yang lezat yang bisa Anda coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan *ayam tepung asam manis*:

1. Sediakan 250 gr ayam fillet
1. Ambil 1 bgks tepung bumbu
1. Gunakan 1/2 siung bawang bombay (tambahan sy)
1. Gunakan 1 butir telur kocok
1. Sediakan 3 siung bawang putih,keprek, cincang
1. Sediakan 1 cabe merah besar/sesuai selera
1. Ambil 1 btg daun bawang, iris
1. Siapkan  Bumbu :
1. Siapkan 2 sdm saus sambal
1. Sediakan 2 sdm saus tomat
1. Ambil 2 sdm kecap manis
1. Sediakan 1 sdm saus tiram
1. Ambil 1/2 sdt lada bubuk
1. Ambil 1/2 sdt garam
1. Gunakan 1/2 sdt gula pasir
1. Sediakan 200 ml air (sy, air minum)




<!--inarticleads2-->

##### Cara menyiapkan *ayam tepung asam manis*:

1. Siapkan bahan. Keprek lalu cincang bawang putih, iris tipis bawang bombay, cabe dan daun bawang. Cuci bersih ayam lalu potong kotak-kotak agak kecil/sesuai selera
1. Untuk ayamnya aku rebus hingga mendidih (tidak direbus tidak apa-apa sesuai resep aslinya), tiriskan. Siapkan telur yg dikocok dan tepung bumbu. Celupkan ayam kedalam kocokan telur lalu masukkan ke tepung bumbu, guling2 kan dan ketuk2an
1. Goreng ayam hingga kering, angkat, tiriskan. Tumis bawang putih dan bombay hingga harum
1. Lalu masukkan ayam tepung yg sudah digoreng, beri air dan bumbu lainnya
1. Dan juga irisan cabe,aduk rata dan masak hingga air berkurang dan akan mengental dg sendirinya, cek rasa lalu masukkan irisan daun bawang
1. Aduk sebentar lalu matikan kompor dan angkat. Sajikan dg nasi hangat.




Ternyata resep *ayam tepung asam manis* yang enak tidak ribet ini mudah banget ya! Semua orang bisa menghidangkannya. Resep *ayam tepung asam manis* Cocok banget buat kita yang baru mau belajar memasak maupun juga bagi anda yang sudah jago memasak.

Tertarik untuk mencoba membuat resep *ayam tepung asam manis* nikmat sederhana ini? Kalau kamu ingin, ayo kalian segera buruan menyiapkan alat-alat dan bahan-bahannya, kemudian bikin deh Resep *ayam tepung asam manis* yang nikmat dan simple ini. Sangat gampang kan. 

Maka dari itu, ketimbang kita berlama-lama, ayo langsung aja buat resep *ayam tepung asam manis* ini. Pasti kalian tiidak akan nyesel membuat resep *ayam tepung asam manis* lezat tidak ribet ini! Selamat mencoba dengan resep *ayam tepung asam manis* nikmat sederhana ini di tempat tinggal sendiri,oke!.

