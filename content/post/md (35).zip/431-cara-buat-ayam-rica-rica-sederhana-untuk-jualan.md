---
description: "Cara buat Ayam rica - rica Sederhana Untuk Jualan"
title: "Cara buat Ayam rica - rica Sederhana Untuk Jualan"
slug: 431-cara-buat-ayam-rica-rica-sederhana-untuk-jualan
date: 2021-05-20T17:49:29.410Z
image: https://img-global.cpcdn.com/recipes/6291f1652a362f7b/680x482cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6291f1652a362f7b/680x482cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6291f1652a362f7b/680x482cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Dora Cross
ratingvalue: 4.2
reviewcount: 8
recipeingredient:
- "1/2 ayam yg sudah d potong  potong"
- "3 ikat daun kemangi"
- "3 bawang merah"
- "2 bawang putih"
- "7 cabai setan"
- "3 cabe merah"
- "1 ruas kunyit"
- "1/2 jahe"
- "1/2 lengkuas"
- "secukupnya Daun salam"
- "1 serai"
- "secukupnya Ladaku"
- "secukupnya Garam"
- "secukupnya Sasa"
- "secukupnya gula"
recipeinstructions:
- "Masukan ayam kedalam panci yg airnya sudah mendidih tunggu sekitar 10 menit"
- "Tumis bumbu yg sudah halus masukan air secukupnya lalu masukan ayam tunggu sampai air sudah mengering angkat dan sanjikan"
categories:
- Resep
tags:
- ayam
- rica
- 

katakunci: ayam rica  
nutrition: 141 calories
recipecuisine: Indonesian
preptime: "PT27M"
cooktime: "PT37M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam rica - rica](https://img-global.cpcdn.com/recipes/6291f1652a362f7b/680x482cq70/ayam-rica-rica-foto-resep-utama.jpg)

Selaku seorang istri, menyuguhkan masakan enak kepada keluarga merupakan suatu hal yang memuaskan bagi anda sendiri. Tugas seorang  wanita bukan cuma mengatur rumah saja, tetapi anda juga harus memastikan keperluan gizi tercukupi dan panganan yang disantap orang tercinta wajib enak.

Di zaman  sekarang, kamu sebenarnya bisa membeli panganan yang sudah jadi meski tanpa harus capek memasaknya dahulu. Namun ada juga lho mereka yang selalu mau menghidangkan yang terbaik untuk orang yang dicintainya. Karena, menghidangkan masakan yang dibuat sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan makanan tersebut sesuai kesukaan keluarga tercinta. 

Bahan bumbu ayam rica rica yang digunakan sebenarnya cukup simple dan sederhana, seperti : kunyit, jahe, serai, cabai merah, bawang putih, dan beberapa bumbu lainnya. Ayam rica-rica (Indonesian for chicken rica-rica) is an Indonesian hot and spicy chicken dish. It is made up of chicken that cooked in spicy red and green chili pepper.

Mungkinkah kamu seorang penyuka ayam rica - rica?. Tahukah kamu, ayam rica - rica adalah sajian khas di Nusantara yang kini disenangi oleh kebanyakan orang di berbagai wilayah di Indonesia. Kalian bisa membuat ayam rica - rica sendiri di rumahmu dan boleh dijadikan camilan favorit di hari liburmu.

Kita tidak usah bingung untuk mendapatkan ayam rica - rica, sebab ayam rica - rica gampang untuk dicari dan kalian pun boleh mengolahnya sendiri di tempatmu. ayam rica - rica bisa dibuat dengan berbagai cara. Kini pun telah banyak sekali cara modern yang menjadikan ayam rica - rica semakin lezat.

Resep ayam rica - rica pun sangat gampang dibuat, lho. Kita tidak perlu ribet-ribet untuk memesan ayam rica - rica, lantaran Anda dapat menyajikan di rumah sendiri. Bagi Anda yang mau menyajikannya, berikut ini cara membuat ayam rica - rica yang nikamat yang mampu Anda hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Ayam rica - rica:

1. Siapkan 1/2 ayam yg sudah d potong - potong
1. Siapkan 3 ikat daun kemangi
1. Gunakan 3 bawang merah
1. Siapkan 2 bawang putih
1. Gunakan 7 cabai setan
1. Gunakan 3 cabe merah
1. Ambil 1 ruas kunyit
1. Siapkan 1/2 jahe
1. Gunakan 1/2 lengkuas
1. Siapkan secukupnya Daun salam
1. Ambil 1 serai
1. Sediakan secukupnya Ladaku
1. Ambil secukupnya Garam
1. Gunakan secukupnya Sasa
1. Sediakan secukupnya gula


Cara pembuatan ayam rica rica sebenarnya tidaklah terlalu sulit. Seperti olahan ayam yang lainnya, bumbu ayam rica rica ini menggunakan bumbu rempah asli Indonesia, seperti kunyit, jahe. Ayam rica-rica is specialty chicken dish from the city of Manado in Indonesia North Sulawesi. Rica means chili in North Sulawesi language, so ayam rica-rica translates to chicken with chili sauce. 

<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam rica - rica:

1. Masukan ayam kedalam panci yg airnya sudah mendidih tunggu sekitar 10 menit
1. Tumis bumbu yg sudah halus masukan air secukupnya lalu masukan ayam tunggu sampai air sudah mengering angkat dan sanjikan


Cara pembuatan ayam rica-rica tidaklah sulit. Ayam rica-rica is specialty chicken dish from the city of Manado in Indonesia North Sulawesi. Rica means chili in North Sulawesi language, so ayam rica-rica translates to chicken with chili sauce. Ayam rica-rica atau rica-rica ayam bisa jadi pilihan lauk buat penyuka pedas. Makanan khas Manado ini memakai banyak bumbu dan cabe hingga rasanya pedas mantap. 

Ternyata resep ayam rica - rica yang enak simple ini gampang banget ya! Semua orang dapat memasaknya. Cara Membuat ayam rica - rica Sesuai banget untuk kita yang baru mau belajar memasak ataupun juga untuk anda yang sudah ahli dalam memasak.

Apakah kamu mau mulai mencoba buat resep ayam rica - rica lezat sederhana ini? Kalau anda mau, mending kamu segera menyiapkan alat-alat dan bahan-bahannya, setelah itu buat deh Resep ayam rica - rica yang mantab dan sederhana ini. Sungguh taidak sulit kan. 

Jadi, daripada kita diam saja, yuk kita langsung sajikan resep ayam rica - rica ini. Pasti anda gak akan nyesel bikin resep ayam rica - rica lezat sederhana ini! Selamat berkreasi dengan resep ayam rica - rica enak sederhana ini di tempat tinggal sendiri,oke!.

