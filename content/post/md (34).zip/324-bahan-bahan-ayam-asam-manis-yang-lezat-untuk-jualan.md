---
description: "Bahan-bahan Ayam asam manis yang lezat Untuk Jualan"
title: "Bahan-bahan Ayam asam manis yang lezat Untuk Jualan"
slug: 324-bahan-bahan-ayam-asam-manis-yang-lezat-untuk-jualan
date: 2021-04-20T04:25:37.636Z
image: https://img-global.cpcdn.com/recipes/0657f961a5bcdaf9/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0657f961a5bcdaf9/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0657f961a5bcdaf9/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
author: Jonathan Joseph
ratingvalue: 4.9
reviewcount: 14
recipeingredient:
- "1/2 kg ayam"
- "1 bungkus tepung sajiku"
- "Secukupnya saos tiram"
- "Secukupnya kecap manis"
- "Secukupnya Saos tomatsaos pedas"
- "secukupnya Minyak goreng"
- "secukupnya Garam"
- "secukupnya Gula pasir"
- "secukupnya Penyedap rasa"
- "1/2 bungkus Ladaku"
- " Bahan diiris"
- "1 buah bawang Bombay"
- "4 siung bawang putih"
- "Secukupnya daun bawang"
recipeinstructions:
- "Bersih kan ayam, lalu potong sesuai selera. Larutkan tepung sajiku dengan 5 sendok air biasa, lalu masukan ayam kedalam larutan tepung tadi, balur hingga rata. Lalu diamkan sebentar."
- "Panaskan minyak, lalu ayam yang sudah dibalur kedalam tepung basah di balurkan ke tepung sajiku yang kering. Goreng ayam dengan api sedang, goreng hingga berubah warna menjadi kecoklatan Angkat sisihkan."
- "Cuci semua bahan irisan, lalu iris bawang Bombay dan daun bawang. Bawang putih di geprek lalu dicincang halus."
- "Masukan sedikit minyak untuk menumis, masukan bawang bombay, lalu bawang putih cincang, tumis hingga layu lalu tambahkan saos tiram, soas pedas, kecap manis. Aduk dan tambahkan sesuai selera air, klo saya sekitar 250 ml air biasa. Aduk hingga mendidih koreksi rasa, tambahkan sedikit garam, ladaku, gula dan penyedap rasa. Kalau sudah sesuai selera masukan daun bawang diamkan sebentar biar daun bawang agak layu lalu angkat dan sajikan."
categories:
- Resep
tags:
- ayam
- asam
- manis

katakunci: ayam asam manis 
nutrition: 231 calories
recipecuisine: Indonesian
preptime: "PT10M"
cooktime: "PT40M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam asam manis](https://img-global.cpcdn.com/recipes/0657f961a5bcdaf9/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg)

Sebagai seorang ibu, mempersiapkan masakan enak kepada keluarga tercinta merupakan hal yang menggembirakan untuk kamu sendiri. Tugas seorang  wanita bukan cuman mengerjakan pekerjaan rumah saja, tetapi anda pun harus menyediakan kebutuhan gizi terpenuhi dan juga panganan yang dimakan orang tercinta harus sedap.

Di waktu  sekarang, kalian sebenarnya mampu memesan hidangan jadi walaupun tanpa harus susah memasaknya terlebih dahulu. Tapi ada juga orang yang selalu ingin menyajikan yang terlezat untuk orang yang dicintainya. Pasalnya, menyajikan masakan sendiri jauh lebih bersih dan bisa menyesuaikan hidangan tersebut sesuai kesukaan keluarga. 



Mungkinkah anda adalah seorang penikmat ayam asam manis?. Asal kamu tahu, ayam asam manis adalah hidangan khas di Indonesia yang saat ini disenangi oleh orang-orang dari hampir setiap daerah di Indonesia. Kalian bisa menghidangkan ayam asam manis sendiri di rumah dan boleh dijadikan camilan favoritmu di hari liburmu.

Kita tak perlu bingung untuk menyantap ayam asam manis, sebab ayam asam manis tidak sukar untuk ditemukan dan juga kalian pun dapat menghidangkannya sendiri di tempatmu. ayam asam manis bisa dibuat memalui bermacam cara. Kini ada banyak sekali resep modern yang menjadikan ayam asam manis semakin lebih mantap.

Resep ayam asam manis juga sangat gampang dibikin, lho. Kamu tidak perlu capek-capek untuk membeli ayam asam manis, lantaran Kalian dapat menyajikan sendiri di rumah. Bagi Kalian yang akan membuatnya, di bawah ini adalah resep menyajikan ayam asam manis yang enak yang dapat Kalian buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Ayam asam manis:

1. Ambil 1/2 kg ayam
1. Sediakan 1 bungkus tepung sajiku
1. Siapkan Secukupnya saos tiram
1. Sediakan Secukupnya kecap manis
1. Sediakan Secukupnya Saos tomat/saos pedas
1. Sediakan secukupnya Minyak goreng
1. Ambil secukupnya Garam
1. Gunakan secukupnya Gula pasir
1. Ambil secukupnya Penyedap rasa
1. Gunakan 1/2 bungkus Ladaku
1. Siapkan  Bahan diiris
1. Ambil 1 buah bawang Bombay
1. Ambil 4 siung bawang putih
1. Ambil Secukupnya daun bawang




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam asam manis:

1. Bersih kan ayam, lalu potong sesuai selera. Larutkan tepung sajiku dengan 5 sendok air biasa, lalu masukan ayam kedalam larutan tepung tadi, balur hingga rata. Lalu diamkan sebentar.
1. Panaskan minyak, lalu ayam yang sudah dibalur kedalam tepung basah di balurkan ke tepung sajiku yang kering. Goreng ayam dengan api sedang, goreng hingga berubah warna menjadi kecoklatan Angkat sisihkan.
1. Cuci semua bahan irisan, lalu iris bawang Bombay dan daun bawang. Bawang putih di geprek lalu dicincang halus.
1. Masukan sedikit minyak untuk menumis, masukan bawang bombay, lalu bawang putih cincang, tumis hingga layu lalu tambahkan saos tiram, soas pedas, kecap manis. Aduk dan tambahkan sesuai selera air, klo saya sekitar 250 ml air biasa. Aduk hingga mendidih koreksi rasa, tambahkan sedikit garam, ladaku, gula dan penyedap rasa. Kalau sudah sesuai selera masukan daun bawang diamkan sebentar biar daun bawang agak layu lalu angkat dan sajikan.




Ternyata resep ayam asam manis yang nikamt simple ini gampang sekali ya! Kalian semua dapat membuatnya. Cara Membuat ayam asam manis Sangat sesuai banget untuk kalian yang baru mau belajar memasak atau juga bagi anda yang telah ahli memasak.

Tertarik untuk mulai mencoba bikin resep ayam asam manis lezat simple ini? Kalau anda ingin, ayo kalian segera siapin alat-alat dan bahan-bahannya, setelah itu buat deh Resep ayam asam manis yang nikmat dan sederhana ini. Sungguh gampang kan. 

Maka dari itu, daripada anda diam saja, hayo kita langsung hidangkan resep ayam asam manis ini. Dijamin kamu gak akan menyesal sudah bikin resep ayam asam manis mantab simple ini! Selamat berkreasi dengan resep ayam asam manis mantab tidak rumit ini di rumah kalian sendiri,oke!.

