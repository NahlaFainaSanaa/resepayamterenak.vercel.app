---
description: "Cara membuat Ayam Penyet Cabe Ijo Sederhana Untuk Jualan"
title: "Cara membuat Ayam Penyet Cabe Ijo Sederhana Untuk Jualan"
slug: 302-cara-membuat-ayam-penyet-cabe-ijo-sederhana-untuk-jualan
date: 2021-03-18T03:01:14.219Z
image: https://img-global.cpcdn.com/recipes/1b0af39c8a9f7dc3/680x482cq70/ayam-penyet-cabe-ijo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1b0af39c8a9f7dc3/680x482cq70/ayam-penyet-cabe-ijo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1b0af39c8a9f7dc3/680x482cq70/ayam-penyet-cabe-ijo-foto-resep-utama.jpg
author: Stanley Ball
ratingvalue: 4.9
reviewcount: 3
recipeingredient:
- "1/2 kg daging ayam"
- "1 batang serai"
- "2 lembar daun jeruk"
- " Bumbu ukep ayam"
- "4 siung bawang merah"
- "3 siung bawang putih"
- "1 ruas jahe"
- "1 ruas kunyit"
- "1 sdt ketumbar"
- "Secukupnya garam"
- "Secukupnya kaldu jamur"
- "Secukupnya air untuk merebus ayam"
- " Bahan sambal ijo"
- "5 cabe hijau besar"
- "20 cabe rawit hijau"
- "2 tomat hijau kecil"
- "3 siung bawang putih"
- "4 siung bawang merah"
- "Secukupnya gula dan garam"
- "Secukupnya minyak goreng"
recipeinstructions:
- "Potong ayam kemudian cuci bersih ditiriskan. Rebus air hingga mendidih lalu masukkan ayam"
- "Siapkan bahan bumbu ukep, masukkan bumbu kedalam rebusan ayam tambahkan daun jeruk, serai garam dan kaldu jamur biarkan mendidih lalu koreksi rasa, masak hingga ayam empuk dan bumbu meresap"
- "Jika ayam sudah matang dan bumbu meresap, angkat dan tiriskan ayam lalu goreng dalam minyak panas hingga kecoklatan kemudian sisihkan"
- "Siapkan bahan untuk sambal ijo, goreng bumbu yg sudah dipotong-potong hingga bumbu matang dan layu"
- "Letakan bumbu di atas cobek tambahkan sedikit gula dan garam kemudian ulek dan koreksi rasa."
- "Letakkan ayam yg sudah digoreng tadi di atas cobek lalu penyet, ayam penyet siap disajikan"
- "Sajikan dengan nasi hangat, selamat sarapan 😅😉"
categories:
- Resep
tags:
- ayam
- penyet
- cabe

katakunci: ayam penyet cabe 
nutrition: 256 calories
recipecuisine: Indonesian
preptime: "PT13M"
cooktime: "PT35M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Penyet Cabe Ijo](https://img-global.cpcdn.com/recipes/1b0af39c8a9f7dc3/680x482cq70/ayam-penyet-cabe-ijo-foto-resep-utama.jpg)

Sebagai seorang orang tua, menyediakan olahan sedap kepada famili adalah suatu hal yang menyenangkan bagi kamu sendiri. Peran seorang istri bukan saja menangani rumah saja, tetapi anda pun wajib menyediakan keperluan nutrisi tercukupi dan masakan yang dikonsumsi keluarga tercinta wajib mantab.

Di masa  sekarang, kalian sebenarnya bisa memesan masakan jadi walaupun tanpa harus capek mengolahnya lebih dulu. Tetapi banyak juga mereka yang memang mau menghidangkan yang terenak untuk orang tercintanya. Sebab, menghidangkan masakan sendiri akan jauh lebih bersih dan bisa menyesuaikan sesuai selera famili. 



Mungkinkah anda merupakan salah satu penggemar ayam penyet cabe ijo?. Asal kamu tahu, ayam penyet cabe ijo merupakan hidangan khas di Indonesia yang sekarang disenangi oleh setiap orang di berbagai daerah di Indonesia. Kita bisa menyajikan ayam penyet cabe ijo hasil sendiri di rumahmu dan boleh jadi hidangan kesukaanmu di hari libur.

Kamu tidak usah bingung untuk menyantap ayam penyet cabe ijo, sebab ayam penyet cabe ijo gampang untuk didapatkan dan juga kamu pun dapat mengolahnya sendiri di tempatmu. ayam penyet cabe ijo dapat dibuat lewat beragam cara. Saat ini sudah banyak sekali resep modern yang membuat ayam penyet cabe ijo semakin nikmat.

Resep ayam penyet cabe ijo pun gampang sekali dibikin, lho. Kalian tidak usah repot-repot untuk memesan ayam penyet cabe ijo, lantaran Kalian bisa menyiapkan di rumahmu. Bagi Kamu yang akan menyajikannya, berikut ini cara menyajikan ayam penyet cabe ijo yang lezat yang bisa Kamu coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Ayam Penyet Cabe Ijo:

1. Sediakan 1/2 kg daging ayam
1. Gunakan 1 batang serai
1. Ambil 2 lembar daun jeruk
1. Gunakan  Bumbu ukep ayam
1. Sediakan 4 siung bawang merah
1. Sediakan 3 siung bawang putih
1. Sediakan 1 ruas jahe
1. Ambil 1 ruas kunyit
1. Gunakan 1 sdt ketumbar
1. Gunakan Secukupnya garam
1. Gunakan Secukupnya kaldu jamur
1. Ambil Secukupnya air untuk merebus ayam
1. Siapkan  Bahan sambal ijo
1. Gunakan 5 cabe hijau besar
1. Ambil 20 cabe rawit hijau
1. Gunakan 2 tomat hijau kecil
1. Gunakan 3 siung bawang putih
1. Sediakan 4 siung bawang merah
1. Gunakan Secukupnya gula dan garam
1. Ambil Secukupnya minyak goreng




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Penyet Cabe Ijo:

1. Potong ayam kemudian cuci bersih ditiriskan. Rebus air hingga mendidih lalu masukkan ayam
1. Siapkan bahan bumbu ukep, masukkan bumbu kedalam rebusan ayam tambahkan daun jeruk, serai garam dan kaldu jamur biarkan mendidih lalu koreksi rasa, masak hingga ayam empuk dan bumbu meresap
1. Jika ayam sudah matang dan bumbu meresap, angkat dan tiriskan ayam lalu goreng dalam minyak panas hingga kecoklatan kemudian sisihkan
1. Siapkan bahan untuk sambal ijo, goreng bumbu yg sudah dipotong-potong hingga bumbu matang dan layu
1. Letakan bumbu di atas cobek tambahkan sedikit gula dan garam kemudian ulek dan koreksi rasa.
1. Letakkan ayam yg sudah digoreng tadi di atas cobek lalu penyet, ayam penyet siap disajikan
1. Sajikan dengan nasi hangat, selamat sarapan 😅😉




Wah ternyata resep ayam penyet cabe ijo yang nikamt tidak rumit ini enteng sekali ya! Kita semua bisa membuatnya. Resep ayam penyet cabe ijo Cocok sekali untuk kamu yang baru belajar memasak ataupun bagi kamu yang sudah ahli memasak.

Apakah kamu mau mencoba bikin resep ayam penyet cabe ijo lezat sederhana ini? Kalau kamu mau, yuk kita segera siapkan alat dan bahan-bahannya, lalu bikin deh Resep ayam penyet cabe ijo yang lezat dan tidak rumit ini. Sungguh taidak sulit kan. 

Maka dari itu, ketimbang anda berfikir lama-lama, hayo kita langsung buat resep ayam penyet cabe ijo ini. Dijamin anda tiidak akan nyesel sudah bikin resep ayam penyet cabe ijo enak simple ini! Selamat mencoba dengan resep ayam penyet cabe ijo enak sederhana ini di rumah kalian masing-masing,ya!.

