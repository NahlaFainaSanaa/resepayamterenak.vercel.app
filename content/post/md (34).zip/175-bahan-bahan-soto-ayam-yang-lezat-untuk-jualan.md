---
description: "Bahan-bahan Soto Ayam yang lezat Untuk Jualan"
title: "Bahan-bahan Soto Ayam yang lezat Untuk Jualan"
slug: 175-bahan-bahan-soto-ayam-yang-lezat-untuk-jualan
date: 2021-04-26T19:45:10.326Z
image: https://img-global.cpcdn.com/recipes/f72d50f2556d9875/680x482cq70/soto-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f72d50f2556d9875/680x482cq70/soto-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f72d50f2556d9875/680x482cq70/soto-ayam-foto-resep-utama.jpg
author: Miguel Erickson
ratingvalue: 3.2
reviewcount: 13
recipeingredient:
- "1 ekor ayam potong 8 bagian"
- "1 sdt ketumbar"
- "2 cm jahe"
- "2 cm lengkuas"
- "2 cm kunyit"
- "15 bawang merah"
- "10 bawang putih"
- "1 sdt merica"
- "5 butir kemiri"
- "100 gr toge"
- "2 bungkus kecil soun"
- "2 batang daun bawang"
- "5 batang seledri"
- "3 daun jeruk 3 daun salam 3 batang sereh"
- " Sambal  15 cabe rawit  2 bawang putih"
- "2 lt air 5 sdm minyak untuk menumis"
- " Garam dan penyedap rasa opsional"
- " Jeruk nipis dipotong kecil2"
recipeinstructions:
- "Haluskan / blender : ketumbar, merica, bawang merah, bawang putih, jahe, lengkuas, kunyit, kemiri."
- "Panaskan minyak, tumis bumbu yang sudah di haluskan di dalam panci, tambahkan daun jeruk, sereh dan daun salam hingga harum aromanya.  Kemudian tambahkan air 1lt.  Tutup panci"
- "Setelah mendidih, masukkan ayam. Tambahkan garam dan penyedap rasa. Rebus hingga 30 menit."
- "Setelah bumbu meresap, keluarkan ayam dari panci.  Kemudian tambahkan air 1Lt lagi di panci, aduk sekali2."
- "Goreng ayam di minyak panas, tiriskan.  Lalu potong kecil2 / suwir.  Setelah itu masukkan lagi ke dalam panci rebusan kuah soto.  Kecilkan api dan tes rasa, bila diperlukan tambahkan garam dan penyedap rasa."
- "Bahan pelengkap : Potong/iris tipis kol.  Cuci kol dan toge. Lalu di panci lain, rebus air hingga mendidih.  Matikan api, celupkan kol, toge dan soun lalu segera tiriskan. Siapkan di mangkok."
- "Bahan tabur : Potong/iris daun bawang, seledri. Siapkan di piring kecil"
- "Sambal soto : Rebus cabe dan bawang putih. Setelah itu, uleg kasar saja.  Taruh di mangkuk kecil, lalu tuangkan 1 sendok sup kuah soto ke sambal."
- "Penyajian : taruh bahan tabur, soun, kol dan toge di mangkok. Siram dengan kuah soto. Tambahkan sambal dan jeruk nipis. Nikmati selagi hangat. Silahkan mencoba"
categories:
- Resep
tags:
- soto
- ayam

katakunci: soto ayam 
nutrition: 151 calories
recipecuisine: Indonesian
preptime: "PT34M"
cooktime: "PT56M"
recipeyield: "2"
recipecategory: Dessert

---


![Soto Ayam](https://img-global.cpcdn.com/recipes/f72d50f2556d9875/680x482cq70/soto-ayam-foto-resep-utama.jpg)

Selaku seorang orang tua, menyajikan masakan mantab untuk keluarga merupakan suatu hal yang memuaskan untuk kita sendiri. Tugas seorang ibu bukan cuma mengurus rumah saja, namun anda pun wajib memastikan keperluan nutrisi terpenuhi dan juga panganan yang dikonsumsi anak-anak harus sedap.

Di waktu  saat ini, kita sebenarnya dapat membeli santapan instan meski tidak harus susah mengolahnya dulu. Tetapi ada juga mereka yang memang ingin memberikan yang terlezat bagi keluarganya. Karena, menyajikan masakan sendiri akan jauh lebih higienis dan bisa menyesuaikan masakan tersebut sesuai dengan masakan kesukaan famili. 



Apakah anda merupakan seorang penggemar soto ayam?. Tahukah kamu, soto ayam merupakan makanan khas di Nusantara yang kini disenangi oleh orang-orang di hampir setiap wilayah di Indonesia. Anda bisa menghidangkan soto ayam kreasi sendiri di rumah dan pasti jadi santapan favoritmu di hari liburmu.

Anda tidak perlu bingung jika kamu ingin mendapatkan soto ayam, lantaran soto ayam tidak sulit untuk didapatkan dan juga kalian pun dapat menghidangkannya sendiri di rumah. soto ayam dapat dibuat lewat bermacam cara. Kini pun telah banyak resep modern yang membuat soto ayam lebih enak.

Resep soto ayam pun gampang sekali dibikin, lho. Kamu tidak perlu ribet-ribet untuk membeli soto ayam, karena Kamu bisa menyiapkan di rumahmu. Untuk Anda yang mau menghidangkannya, dibawah ini merupakan resep untuk membuat soto ayam yang lezat yang dapat Kita coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Soto Ayam:

1. Siapkan 1 ekor ayam potong 8 bagian
1. Sediakan 1 sdt ketumbar
1. Gunakan 2 cm jahe
1. Siapkan 2 cm lengkuas
1. Gunakan 2 cm kunyit
1. Gunakan 15 bawang merah
1. Ambil 10 bawang putih
1. Ambil 1 sdt merica
1. Gunakan 5 butir kemiri
1. Sediakan 100 gr toge
1. Gunakan 2 bungkus kecil soun
1. Gunakan 2 batang daun bawang
1. Ambil 5 batang seledri
1. Siapkan 3 daun jeruk, 3 daun salam, 3 batang sereh
1. Ambil  Sambal : 15 cabe rawit + 2 bawang putih
1. Ambil 2 lt air, 5 sdm minyak untuk menumis
1. Sediakan  Garam dan penyedap rasa (opsional)
1. Ambil  Jeruk nipis dipotong kecil2




<!--inarticleads2-->

##### Langkah-langkah membuat Soto Ayam:

1. Haluskan / blender : ketumbar, merica, bawang merah, bawang putih, jahe, lengkuas, kunyit, kemiri.
1. Panaskan minyak, tumis bumbu yang sudah di haluskan di dalam panci, tambahkan daun jeruk, sereh dan daun salam hingga harum aromanya.  - Kemudian tambahkan air 1lt.  - Tutup panci
1. Setelah mendidih, masukkan ayam. Tambahkan garam dan penyedap rasa. Rebus hingga 30 menit.
1. Setelah bumbu meresap, keluarkan ayam dari panci.  - Kemudian tambahkan air 1Lt lagi di panci, aduk sekali2.
1. Goreng ayam di minyak panas, tiriskan.  - Lalu potong kecil2 / suwir.  - Setelah itu masukkan lagi ke dalam panci rebusan kuah soto.  - Kecilkan api dan tes rasa, bila diperlukan tambahkan garam dan penyedap rasa.
1. Bahan pelengkap : - Potong/iris tipis kol.  - Cuci kol dan toge. - Lalu di panci lain, rebus air hingga mendidih.  - Matikan api, celupkan kol, toge dan soun lalu segera tiriskan. - Siapkan di mangkok.
1. Bahan tabur : - Potong/iris daun bawang, seledri. Siapkan di piring kecil
1. Sambal soto : - Rebus cabe dan bawang putih. Setelah itu, uleg kasar saja.  - Taruh di mangkuk kecil, lalu tuangkan 1 sendok sup kuah soto ke sambal.
1. Penyajian : taruh bahan tabur, soun, kol dan toge di mangkok. Siram dengan kuah soto. Tambahkan sambal dan jeruk nipis. Nikmati selagi hangat. - Silahkan mencoba




Wah ternyata resep soto ayam yang lezat tidak ribet ini mudah sekali ya! Semua orang mampu memasaknya. Cara Membuat soto ayam Cocok sekali untuk kita yang sedang belajar memasak ataupun juga bagi kamu yang telah pandai memasak.

Tertarik untuk mencoba membuat resep soto ayam enak simple ini? Kalau anda mau, mending kamu segera buruan menyiapkan peralatan dan bahan-bahannya, lantas buat deh Resep soto ayam yang lezat dan tidak ribet ini. Sangat mudah kan. 

Maka dari itu, ketimbang kamu diam saja, hayo langsung aja buat resep soto ayam ini. Dijamin kamu tak akan menyesal sudah bikin resep soto ayam enak sederhana ini! Selamat berkreasi dengan resep soto ayam nikmat simple ini di tempat tinggal kalian sendiri,ya!.

