---
description: "Bahan-bahan Paha Ayam Kodok (Payko) yang lezat dan Mudah Dibuat"
title: "Bahan-bahan Paha Ayam Kodok (Payko) yang lezat dan Mudah Dibuat"
slug: 259-bahan-bahan-paha-ayam-kodok-payko-yang-lezat-dan-mudah-dibuat
date: 2021-04-12T02:38:23.064Z
image: https://img-global.cpcdn.com/recipes/1f3e71fb2447ec85/680x482cq70/paha-ayam-kodok-payko-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1f3e71fb2447ec85/680x482cq70/paha-ayam-kodok-payko-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1f3e71fb2447ec85/680x482cq70/paha-ayam-kodok-payko-foto-resep-utama.jpg
author: Roxie Hampton
ratingvalue: 4.1
reviewcount: 14
recipeingredient:
- "6 pcs paha ayam bag bawah"
- "200 gr daging giling"
- "6 btr telur puyuh rebus kupas"
- "1/4 bawang bombay cincang"
- "2 siung bawang putih"
- "3 sdm tepung rotipanir"
- "1 butir telur ayam"
- "50 ml susu cair"
- "1 sdt garam"
- "1 sdm gula pasir"
- "1/2-1 sdt lada bubuk"
- "1/4 sdt pala bubuk"
- " Saus "
- "1/2 bawang bombay cincang"
- "200 ml air kaldu ayam"
- "1 sdm saus inggris"
- "2 sdm kecap manis"
- "1/2 sdt lada bubuk"
- "1/2 sdt garam"
- "2 sdm mentega utk menumis"
- "1 1/2 sdm maizena cairkan dengan sedikit air"
- " Bumbu Oles Panggang "
- "1 sdm margarin"
- "1 sdm kecap"
- "1 sdt madu"
- " Pelengkap "
- " Kentang gorengwedgesfrench fries"
- " Mixed vegetable yang ditumis dengan sedikit mentega  bawput"
recipeinstructions:
- "Kuliti paha, ambil daging dan tulangnya, sisakan di ujung untuk pegangan. Cincang lembut daging ayam/bisa dihaluskan di FP. Sisihkan. Sementara rebus tulang ayam dengan 300 ml air dengam api kecil hingga kuah bening, saring dan sisihkan. (Nanti yg dipakai hanya 200ml)"
- "Tumis bawang bombay dgn mentega hingga harum. Sisihkan. Campur semua bahan : ayam, daging, bumbu dsb. Uleni hingga rata. Jangan lupa tes icip dengan sedikit memggoreng adonan. Jika rasa sudahbpas, masukkan ke dalam plastik segitiga untuk memudahkan pengisian ke dalam kulit paha. Isikan sebagian, masukkan 1 telur puyuh dan iso lagi dengan adonan hingga penuh sambil dipadatkan. Kukus selama 30 menit atau hingga matang. Di menit 10 tusuki permukaan kulitnya dengan tusuk gigi agar air keluar."
- "Panaskan pan..dan panggang paha sambil dioles bahan olesan yang sudah diaduk rata. Panggang hingga kecoklatan. Angkat. Utk saus : tumis bombay hingga harum, tuang air kaldu dan didihkan. Bumbui. Tes icip. Dan kentalkan dengan memasukkan larutan maizena. Angkat.Sajikan Payko dengan kentang goreng, tumisan mix vegetable.dan disiram saus."
- "Note untuk yang dibikin Rolade : siapkan selembar alumunium foil, taruh adonan daging, tata telur/telur puyuh rebus di atasnya. Tutup lagi dengan adinan daging. Gulung dan padatkan dengan alumunium foul. Tusuk2 dengan tusuk gigi permukaan rol. Kukus selama 30-45 menit. Angkat di bisa disimpan jika sudah dingin"
categories:
- Resep
tags:
- paha
- ayam
- kodok

katakunci: paha ayam kodok 
nutrition: 134 calories
recipecuisine: Indonesian
preptime: "PT34M"
cooktime: "PT52M"
recipeyield: "3"
recipecategory: Dinner

---


![Paha Ayam Kodok (Payko)](https://img-global.cpcdn.com/recipes/1f3e71fb2447ec85/680x482cq70/paha-ayam-kodok-payko-foto-resep-utama.jpg)

Andai kalian seorang orang tua, menyajikan panganan mantab untuk orang tercinta adalah hal yang mengasyikan untuk kamu sendiri. Tanggung jawab seorang  wanita bukan cuman menjaga rumah saja, namun kamu pun wajib memastikan keperluan nutrisi terpenuhi dan juga masakan yang dikonsumsi anak-anak mesti lezat.

Di waktu  saat ini, anda memang mampu memesan masakan praktis tanpa harus repot mengolahnya dulu. Namun ada juga mereka yang selalu mau menyajikan yang terenak untuk orang tercintanya. Karena, memasak yang dibuat sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan berdasarkan kesukaan famili. 



Mungkinkah kamu salah satu penikmat paha ayam kodok (payko)?. Asal kamu tahu, paha ayam kodok (payko) adalah makanan khas di Nusantara yang sekarang digemari oleh kebanyakan orang dari hampir setiap daerah di Indonesia. Anda bisa membuat paha ayam kodok (payko) olahan sendiri di rumah dan boleh dijadikan hidangan kesukaanmu di hari libur.

Kamu jangan bingung jika kamu ingin mendapatkan paha ayam kodok (payko), lantaran paha ayam kodok (payko) tidak sukar untuk dicari dan kalian pun dapat memasaknya sendiri di rumah. paha ayam kodok (payko) boleh dimasak memalui berbagai cara. Sekarang sudah banyak sekali resep kekinian yang menjadikan paha ayam kodok (payko) semakin lebih mantap.

Resep paha ayam kodok (payko) pun mudah sekali untuk dibikin, lho. Kalian tidak usah ribet-ribet untuk membeli paha ayam kodok (payko), karena Kamu mampu menyajikan ditempatmu. Bagi Anda yang akan membuatnya, berikut resep untuk menyajikan paha ayam kodok (payko) yang lezat yang bisa Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Paha Ayam Kodok (Payko):

1. Siapkan 6 pcs paha ayam bag. bawah
1. Siapkan 200 gr daging giling
1. Sediakan 6 btr telur puyuh rebus, kupas
1. Gunakan 1/4 bawang bombay cincang
1. Siapkan 2 siung bawang putih
1. Siapkan 3 sdm tepung roti/panir
1. Sediakan 1 butir telur ayam
1. Ambil 50 ml susu cair
1. Ambil 1 sdt garam
1. Gunakan 1 sdm gula pasir
1. Gunakan 1/2-1 sdt lada bubuk
1. Sediakan 1/4 sdt pala bubuk
1. Sediakan  Saus :
1. Gunakan 1/2 bawang bombay cincang
1. Gunakan 200 ml air kaldu ayam
1. Gunakan 1 sdm saus inggris
1. Ambil 2 sdm kecap manis
1. Ambil 1/2 sdt lada bubuk
1. Gunakan 1/2 sdt garam
1. Ambil 2 sdm mentega utk menumis
1. Ambil 1 1/2 sdm maizena cairkan dengan sedikit air
1. Ambil  Bumbu Oles Panggang :
1. Ambil 1 sdm margarin
1. Ambil 1 sdm kecap
1. Sediakan 1 sdt madu
1. Ambil  Pelengkap :
1. Gunakan  Kentang goreng/wedges/french fries
1. Sediakan  Mixed vegetable yang ditumis dengan sedikit mentega + bawput




<!--inarticleads2-->

##### Langkah-langkah membuat Paha Ayam Kodok (Payko):

1. Kuliti paha, ambil daging dan tulangnya, sisakan di ujung untuk pegangan. Cincang lembut daging ayam/bisa dihaluskan di FP. Sisihkan. Sementara rebus tulang ayam dengan 300 ml air dengam api kecil hingga kuah bening, saring dan sisihkan. (Nanti yg dipakai hanya 200ml)
1. Tumis bawang bombay dgn mentega hingga harum. Sisihkan. Campur semua bahan : ayam, daging, bumbu dsb. Uleni hingga rata. Jangan lupa tes icip dengan sedikit memggoreng adonan. Jika rasa sudahbpas, masukkan ke dalam plastik segitiga untuk memudahkan pengisian ke dalam kulit paha. Isikan sebagian, masukkan 1 telur puyuh dan iso lagi dengan adonan hingga penuh sambil dipadatkan. Kukus selama 30 menit atau hingga matang. Di menit 10 tusuki permukaan kulitnya dengan tusuk gigi agar air keluar.
1. Panaskan pan..dan panggang paha sambil dioles bahan olesan yang sudah diaduk rata. Panggang hingga kecoklatan. Angkat. Utk saus : tumis bombay hingga harum, tuang air kaldu dan didihkan. Bumbui. Tes icip. Dan kentalkan dengan memasukkan larutan maizena. Angkat.Sajikan Payko dengan kentang goreng, tumisan mix vegetable.dan disiram saus.
1. Note untuk yang dibikin Rolade : siapkan selembar alumunium foil, taruh adonan daging, tata telur/telur puyuh rebus di atasnya. Tutup lagi dengan adinan daging. Gulung dan padatkan dengan alumunium foul. Tusuk2 dengan tusuk gigi permukaan rol. Kukus selama 30-45 menit. Angkat di bisa disimpan jika sudah dingin




Ternyata resep paha ayam kodok (payko) yang mantab tidak rumit ini enteng banget ya! Kita semua mampu membuatnya. Cara buat paha ayam kodok (payko) Sangat cocok banget buat kita yang baru akan belajar memasak ataupun juga bagi anda yang sudah jago memasak.

Apakah kamu ingin mulai mencoba bikin resep paha ayam kodok (payko) lezat sederhana ini? Kalau anda tertarik, ayo kamu segera buruan menyiapkan alat dan bahannya, lalu bikin deh Resep paha ayam kodok (payko) yang nikmat dan simple ini. Sangat mudah kan. 

Maka, daripada kamu diam saja, hayo langsung aja hidangkan resep paha ayam kodok (payko) ini. Dijamin kalian gak akan menyesal sudah membuat resep paha ayam kodok (payko) nikmat simple ini! Selamat mencoba dengan resep paha ayam kodok (payko) lezat tidak ribet ini di tempat tinggal kalian masing-masing,oke!.

