---
description: "Resep Soto Betawi Ayam (kuah santan susu) Sederhana Untuk Jualan"
title: "Resep Soto Betawi Ayam (kuah santan susu) Sederhana Untuk Jualan"
slug: 386-resep-soto-betawi-ayam-kuah-santan-susu-sederhana-untuk-jualan
date: 2021-02-20T13:02:39.088Z
image: https://img-global.cpcdn.com/recipes/bcb8d20881f23b0c/680x482cq70/soto-betawi-ayam-kuah-santan-susu-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/bcb8d20881f23b0c/680x482cq70/soto-betawi-ayam-kuah-santan-susu-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/bcb8d20881f23b0c/680x482cq70/soto-betawi-ayam-kuah-santan-susu-foto-resep-utama.jpg
author: Amanda Rhodes
ratingvalue: 4.5
reviewcount: 8
recipeingredient:
- " BAhan  bahan "
- "500 gr ayam bagian dada"
- "2000 ml santan"
- "500 ml susu cair full cream"
- "2 batang sereh geprek"
- "1 ruas lengkuas geprek"
- "3 lembar daun salam"
- "4 lembar daun jeruk"
- "Secukup nya garam gula dan kaldu bubuk"
- " Bumbu Halus "
- "6 bh bawang merah"
- "4 buah bawang putih"
- "Seruas kunyit"
- "Seruas jahe"
- "5 buah kemiri sangrai"
- "1 sdt lada butiran"
- " Bahan Pelengkap"
- " Emping goreng"
- "1/2 kg kentang iris tipis bulat goreng kering"
- " Daun bawang"
- " Tomat"
- " Jeruk limo"
- " Sambal"
- " Bawang goreng"
recipeinstructions:
- "Potong kecil2 ayam lalu cuci bersih dan beri kucuran air jeruk nipis diam kan sebentar lalu cuci bersih kembali tiriskan"
- "Tumis bumbu halus hingga harum lalu masukan salam, sereh, lengkuas dan daun jeruk aduk hingga bumbu matang"
- "Panaskan santan biarkan hingga mendidih lalu masukan bumbu halus dan masukan ayam aduk biar kan ayam matang. Masukan susu beri gula garam dan kaldu bubuk koreksi rasa matikan kompor"
- "Penyajian.. tuang soto di mangkuk lalu beri tambahan bahan pelengkap lain nya sajikam dengan nasi hangat.. mantaaappp 🤤"
categories:
- Resep
tags:
- soto
- betawi
- ayam

katakunci: soto betawi ayam 
nutrition: 203 calories
recipecuisine: Indonesian
preptime: "PT35M"
cooktime: "PT38M"
recipeyield: "2"
recipecategory: Dinner

---


![Soto Betawi Ayam (kuah santan susu)](https://img-global.cpcdn.com/recipes/bcb8d20881f23b0c/680x482cq70/soto-betawi-ayam-kuah-santan-susu-foto-resep-utama.jpg)

Sebagai seorang orang tua, mempersiapkan olahan sedap untuk famili merupakan hal yang memuaskan untuk kamu sendiri. Tanggung jawab seorang istri Tidak saja mengatur rumah saja, tetapi anda pun wajib memastikan keperluan nutrisi terpenuhi dan santapan yang disantap keluarga tercinta mesti nikmat.

Di zaman  sekarang, kamu memang dapat mengorder olahan yang sudah jadi meski tanpa harus capek mengolahnya lebih dulu. Namun banyak juga lho mereka yang selalu mau menyajikan yang terenak untuk orang tercintanya. Karena, menghidangkan masakan yang dibuat sendiri akan jauh lebih higienis dan bisa menyesuaikan makanan tersebut berdasarkan makanan kesukaan keluarga. 



Apakah anda merupakan seorang penikmat soto betawi ayam (kuah santan susu)?. Tahukah kamu, soto betawi ayam (kuah santan susu) adalah makanan khas di Nusantara yang kini digemari oleh setiap orang dari berbagai tempat di Nusantara. Kamu dapat menyajikan soto betawi ayam (kuah santan susu) sendiri di rumah dan dapat dijadikan hidangan kesukaanmu di hari liburmu.

Kalian jangan bingung untuk memakan soto betawi ayam (kuah santan susu), sebab soto betawi ayam (kuah santan susu) tidak sulit untuk ditemukan dan kita pun boleh membuatnya sendiri di rumah. soto betawi ayam (kuah santan susu) dapat dimasak memalui beragam cara. Kini pun telah banyak banget cara modern yang menjadikan soto betawi ayam (kuah santan susu) lebih mantap.

Resep soto betawi ayam (kuah santan susu) pun gampang dibuat, lho. Kamu jangan ribet-ribet untuk memesan soto betawi ayam (kuah santan susu), tetapi Kalian bisa membuatnya ditempatmu. Untuk Kalian yang mau membuatnya, berikut resep membuat soto betawi ayam (kuah santan susu) yang mantab yang bisa Kalian coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Soto Betawi Ayam (kuah santan susu):

1. Ambil  BAhan - bahan :
1. Gunakan 500 gr ayam bagian dada
1. Siapkan 2000 ml santan
1. Sediakan 500 ml susu cair full cream
1. Ambil 2 batang sereh geprek
1. Ambil 1 ruas lengkuas geprek
1. Sediakan 3 lembar daun salam
1. Ambil 4 lembar daun jeruk
1. Gunakan Secukup nya garam, gula dan kaldu bubuk
1. Gunakan  Bumbu Halus :
1. Sediakan 6 bh bawang merah
1. Sediakan 4 buah bawang putih
1. Sediakan Seruas kunyit
1. Ambil Seruas jahe
1. Siapkan 5 buah kemiri sangrai
1. Ambil 1 sdt lada butiran
1. Gunakan  Bahan Pelengkap
1. Sediakan  Emping goreng
1. Siapkan 1/2 kg kentang iris tipis bulat goreng kering
1. Sediakan  Daun bawang
1. Ambil  Tomat
1. Gunakan  Jeruk limo
1. Ambil  Sambal
1. Gunakan  Bawang goreng




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Soto Betawi Ayam (kuah santan susu):

1. Potong kecil2 ayam lalu cuci bersih dan beri kucuran air jeruk nipis diam kan sebentar lalu cuci bersih kembali tiriskan
1. Tumis bumbu halus hingga harum lalu masukan salam, sereh, lengkuas dan daun jeruk aduk hingga bumbu matang
1. Panaskan santan biarkan hingga mendidih lalu masukan bumbu halus dan masukan ayam aduk biar kan ayam matang. Masukan susu beri gula garam dan kaldu bubuk koreksi rasa matikan kompor
1. Penyajian.. tuang soto di mangkuk lalu beri tambahan bahan pelengkap lain nya sajikam dengan nasi hangat.. mantaaappp 🤤




Wah ternyata cara membuat soto betawi ayam (kuah santan susu) yang enak tidak ribet ini mudah sekali ya! Kamu semua mampu membuatnya. Cara Membuat soto betawi ayam (kuah santan susu) Sangat cocok sekali untuk kalian yang baru belajar memasak maupun untuk anda yang sudah jago dalam memasak.

Apakah kamu mau mulai mencoba membuat resep soto betawi ayam (kuah santan susu) nikmat tidak ribet ini? Kalau kamu ingin, ayo kalian segera siapin alat dan bahan-bahannya, kemudian bikin deh Resep soto betawi ayam (kuah santan susu) yang nikmat dan simple ini. Sangat mudah kan. 

Jadi, ketimbang kalian diam saja, yuk langsung aja hidangkan resep soto betawi ayam (kuah santan susu) ini. Pasti kamu tak akan menyesal bikin resep soto betawi ayam (kuah santan susu) enak tidak rumit ini! Selamat mencoba dengan resep soto betawi ayam (kuah santan susu) lezat tidak ribet ini di tempat tinggal masing-masing,ya!.

