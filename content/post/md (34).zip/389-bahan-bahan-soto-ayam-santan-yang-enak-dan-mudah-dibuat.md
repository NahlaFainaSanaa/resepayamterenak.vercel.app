---
description: "Bahan-bahan Soto Ayam Santan yang enak dan Mudah Dibuat"
title: "Bahan-bahan Soto Ayam Santan yang enak dan Mudah Dibuat"
slug: 389-bahan-bahan-soto-ayam-santan-yang-enak-dan-mudah-dibuat
date: 2021-05-27T03:46:59.089Z
image: https://img-global.cpcdn.com/recipes/813ddabd07de7a30/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/813ddabd07de7a30/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/813ddabd07de7a30/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
author: Angel Matthews
ratingvalue: 5
reviewcount: 12
recipeingredient:
- "1/2 kg ayam"
- "1 buah santan"
- "Secukupnya garam"
- "Secukupnya lada bubuk"
- "Secukupnya kaldu bubukpenyedap"
- " Bumbu Halus"
- "4 siung bawang putih"
- "4 siung bawang merah"
- "2 butir kemiri sangrai"
- "1 ruas jahe"
- "1 ruas kunyit"
- "1/2 ruas lengkuas"
- "1 sdt ketumbar"
- " Bumbu Cemplung"
- "1 batang sereh geprek"
- "2 lembar daun salam"
- "2 lembar daun jeruk"
- " Bahan Pelengkap"
- "1 buah tomat"
- " Kentang goreng potong dadu"
- " Bawang goreng optional"
- " Daun bawang iris optional"
- " Emping"
recipeinstructions:
- "Tumis bumbu halus dan bumbu cemplung sampai harum."
- "Tambahkan air secukupnya untuk kuah dan masak hingga mendidih. Masukkan garam, lada dan penyedap."
- "Masukkan ayam ke dalam air kuah mendidih tadi dan masak sampai ayam matang. Kemudian angkat dan tiriskan ayam, lalu goreng sebentar sampai kecoklatan, dan suwir-suwir ayam."
- "Sementara itu masukkan santan ke dalam air kuah dan aduk perlahan. Jangan lupa koreksi rasa."
- "Jangan lupa juga goreng kentang yang sudah dipotong dadu."
- "Tata bahan pelengkap di mangkuk, dan siram dengan kuah soto. Siap disajikan dengan nasi hangat ^^ p.s:Kalo mau pedes bisa bikin sambel simplenya. Caranya rebus cabe rawit merah, kemudian blender atau ulek, tambahkan air dan garam sedikit."
categories:
- Resep
tags:
- soto
- ayam
- santan

katakunci: soto ayam santan 
nutrition: 213 calories
recipecuisine: Indonesian
preptime: "PT10M"
cooktime: "PT53M"
recipeyield: "2"
recipecategory: Dessert

---


![Soto Ayam Santan](https://img-global.cpcdn.com/recipes/813ddabd07de7a30/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg)

Selaku seorang istri, menyediakan hidangan lezat bagi keluarga tercinta merupakan suatu hal yang menyenangkan bagi kita sendiri. Tugas seorang ibu Tidak saja mengerjakan pekerjaan rumah saja, tapi kamu juga harus memastikan kebutuhan gizi tercukupi dan juga santapan yang disantap keluarga tercinta wajib sedap.

Di waktu  saat ini, kita memang mampu memesan panganan jadi tanpa harus repot memasaknya terlebih dahulu. Tetapi banyak juga lho mereka yang selalu mau memberikan yang terlezat bagi keluarganya. Lantaran, menyajikan masakan sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan hidangan tersebut berdasarkan kesukaan keluarga tercinta. 



Mungkinkah anda adalah seorang penggemar soto ayam santan?. Tahukah kamu, soto ayam santan adalah makanan khas di Indonesia yang kini disukai oleh banyak orang dari hampir setiap daerah di Nusantara. Anda dapat membuat soto ayam santan buatan sendiri di rumah dan dapat dijadikan hidangan favorit di akhir pekan.

Anda tidak perlu bingung untuk memakan soto ayam santan, lantaran soto ayam santan sangat mudah untuk dicari dan kalian pun dapat mengolahnya sendiri di tempatmu. soto ayam santan dapat diolah memalui beragam cara. Kini pun sudah banyak sekali cara modern yang membuat soto ayam santan lebih lezat.

Resep soto ayam santan pun gampang dibuat, lho. Kalian tidak perlu repot-repot untuk membeli soto ayam santan, sebab Kamu dapat menghidangkan di rumah sendiri. Bagi Kita yang ingin membuatnya, dibawah ini merupakan resep untuk membuat soto ayam santan yang lezat yang mampu Kita coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Soto Ayam Santan:

1. Sediakan 1/2 kg ayam
1. Siapkan 1 buah santan
1. Sediakan Secukupnya garam
1. Gunakan Secukupnya lada bubuk
1. Ambil Secukupnya kaldu bubuk/penyedap
1. Ambil  Bumbu Halus
1. Ambil 4 siung bawang putih
1. Sediakan 4 siung bawang merah
1. Siapkan 2 butir kemiri (sangrai)
1. Siapkan 1 ruas jahe
1. Gunakan 1 ruas kunyit
1. Sediakan 1/2 ruas lengkuas
1. Sediakan 1 sdt ketumbar
1. Gunakan  Bumbu Cemplung
1. Sediakan 1 batang sereh (geprek)
1. Ambil 2 lembar daun salam
1. Ambil 2 lembar daun jeruk
1. Gunakan  Bahan Pelengkap
1. Siapkan 1 buah tomat
1. Sediakan  Kentang goreng (potong dadu)
1. Ambil  Bawang goreng (optional)
1. Siapkan  Daun bawang iris (optional)
1. Ambil  Emping




<!--inarticleads2-->

##### Cara menyiapkan Soto Ayam Santan:

1. Tumis bumbu halus dan bumbu cemplung sampai harum.
1. Tambahkan air secukupnya untuk kuah dan masak hingga mendidih. Masukkan garam, lada dan penyedap.
1. Masukkan ayam ke dalam air kuah mendidih tadi dan masak sampai ayam matang. Kemudian angkat dan tiriskan ayam, lalu goreng sebentar sampai kecoklatan, dan suwir-suwir ayam.
1. Sementara itu masukkan santan ke dalam air kuah dan aduk perlahan. Jangan lupa koreksi rasa.
1. Jangan lupa juga goreng kentang yang sudah dipotong dadu.
1. Tata bahan pelengkap di mangkuk, dan siram dengan kuah soto. Siap disajikan dengan nasi hangat ^^ p.s:Kalo mau pedes bisa bikin sambel simplenya. Caranya rebus cabe rawit merah, kemudian blender atau ulek, tambahkan air dan garam sedikit.




Wah ternyata resep soto ayam santan yang enak sederhana ini gampang sekali ya! Kamu semua bisa membuatnya. Resep soto ayam santan Sangat cocok banget buat kalian yang baru belajar memasak atau juga untuk kamu yang telah jago dalam memasak.

Apakah kamu mau mencoba membuat resep soto ayam santan lezat sederhana ini? Kalau anda tertarik, ayo kamu segera menyiapkan alat-alat dan bahannya, kemudian buat deh Resep soto ayam santan yang lezat dan sederhana ini. Sangat gampang kan. 

Maka, daripada kamu berlama-lama, ayo langsung aja bikin resep soto ayam santan ini. Pasti anda gak akan menyesal sudah bikin resep soto ayam santan lezat sederhana ini! Selamat berkreasi dengan resep soto ayam santan lezat tidak rumit ini di rumah kalian sendiri,ya!.

