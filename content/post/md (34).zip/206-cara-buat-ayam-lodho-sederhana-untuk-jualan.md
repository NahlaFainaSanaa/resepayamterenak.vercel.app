---
description: "Cara buat Ayam Lodho Sederhana Untuk Jualan"
title: "Cara buat Ayam Lodho Sederhana Untuk Jualan"
slug: 206-cara-buat-ayam-lodho-sederhana-untuk-jualan
date: 2021-05-19T00:01:59.925Z
image: https://img-global.cpcdn.com/recipes/3df7f3fef0fa6b16/680x482cq70/ayam-lodho-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/3df7f3fef0fa6b16/680x482cq70/ayam-lodho-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/3df7f3fef0fa6b16/680x482cq70/ayam-lodho-foto-resep-utama.jpg
author: Stephen Stephens
ratingvalue: 5
reviewcount: 6
recipeingredient:
- "300 gr ayam fillet potong2"
- " Air utk merebus ayam"
- "2 btr telur ayam pisahkan kuning dan putihnya"
- "65 santan kara"
- "1 ikat kemangi"
- " Takir daun pisang utk wadah membungkus"
- "6 bh cabe rawit"
- " Minyak utk menumis"
- " Bumbu halus"
- "10 siung bawang merah"
- "5 siung bawang putih"
- "1 batang sereh"
- "1/2 kelingking kencur"
- "1 jempol jahe"
- "1 jempol lengkuas"
- "1 telunjuk kunyit"
- "5 lbr daun jeruk buang tulangnya"
- "1 lbr daun salam buang tulangnya"
- "1 sdt ketumbar bubuk"
- "3/4 sdt jintan bubuk"
- "1/2 sdt merica bubuk"
- "1 sdt gula pasir"
- "1 sdt garam"
- "1 sdt kaldu jamur"
recipeinstructions:
- "Rebus air hingga mendidih lalu masukkan ayam, masak sampai matang. Setelah matang, angkat lalu panggang sebentar di teflon nonstick sampai kecoklatan (air rebusan jg dibuang)"
- "Blender semua bahan bumbu halus lalu tumis di minyak yg sdh dipanaskan hingga wangi dan matang"
- "Masukkan ayam, lalu tambahkan air rebusan ayam tadi. Dikira aja jgn terlalu byk yah karna akan lama menyusut nanti jadi secukupnya aja"
- "Masukkan santan, aduk rata dan koreksi rasa. Masak hingga kuah agak menyusut lalu matikan api"
- "Jika sdh menyusut pindahkan dalam wadah, lalu tambahkan kemangi, cabe rawit, dan putih telur. Aduk rata"
- "Masukkan adonan dalam takir bujur sangkar yg sdh disiapkan (kalo ga ada boleh ganti yg lain asal tahan panas). Utk yg 2 saya beri kuning telur diatasnya karena cmn pake 2 telur 😅"
- "Siapkan kukusan yg sdh panas, lalu kukus ayam lodho sampai matang sekitar 20-30 menit."
- "Siap disantap ☺️"
categories:
- Resep
tags:
- ayam
- lodho

katakunci: ayam lodho 
nutrition: 131 calories
recipecuisine: Indonesian
preptime: "PT21M"
cooktime: "PT38M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Lodho](https://img-global.cpcdn.com/recipes/3df7f3fef0fa6b16/680x482cq70/ayam-lodho-foto-resep-utama.jpg)

Selaku seorang yang hobi masak, menyuguhkan masakan lezat pada orang tercinta merupakan hal yang menggembirakan bagi kita sendiri. Tugas seorang istri bukan sekedar mengurus rumah saja, namun anda juga wajib memastikan kebutuhan gizi tercukupi dan juga masakan yang dimakan anak-anak mesti lezat.

Di zaman  sekarang, kamu sebenarnya dapat mengorder masakan siap saji walaupun tidak harus capek membuatnya dahulu. Namun ada juga mereka yang memang ingin memberikan makanan yang terlezat bagi orang tercintanya. Pasalnya, memasak yang diolah sendiri akan jauh lebih bersih dan bisa menyesuaikan masakan tersebut sesuai dengan kesukaan keluarga tercinta. 



Apakah kamu salah satu penggemar ayam lodho?. Tahukah kamu, ayam lodho merupakan sajian khas di Nusantara yang saat ini disukai oleh orang-orang dari hampir setiap daerah di Indonesia. Kita bisa menyajikan ayam lodho sendiri di rumah dan dapat dijadikan santapan favoritmu di akhir pekanmu.

Kita jangan bingung jika kamu ingin mendapatkan ayam lodho, sebab ayam lodho gampang untuk didapatkan dan kalian pun dapat memasaknya sendiri di tempatmu. ayam lodho dapat diolah lewat bermacam cara. Sekarang telah banyak cara kekinian yang membuat ayam lodho semakin mantap.

Resep ayam lodho pun gampang sekali untuk dibuat, lho. Kalian tidak usah repot-repot untuk membeli ayam lodho, lantaran Kalian bisa menyiapkan ditempatmu. Untuk Kamu yang hendak mencobanya, berikut ini cara membuat ayam lodho yang mantab yang bisa Anda buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Ayam Lodho:

1. Ambil 300 gr ayam fillet, potong2
1. Gunakan  Air utk merebus ayam
1. Sediakan 2 btr telur ayam (pisahkan kuning dan putihnya)
1. Ambil 65 santan kara
1. Gunakan 1 ikat kemangi
1. Siapkan  Takir daun pisang utk wadah membungkus
1. Gunakan 6 bh cabe rawit
1. Siapkan  Minyak utk menumis
1. Ambil  Bumbu halus:
1. Ambil 10 siung bawang merah
1. Gunakan 5 siung bawang putih
1. Ambil 1 batang sereh
1. Sediakan 1/2 kelingking kencur
1. Gunakan 1 jempol jahe
1. Siapkan 1 jempol lengkuas
1. Siapkan 1 telunjuk kunyit
1. Siapkan 5 lbr daun jeruk (buang tulangnya)
1. Sediakan 1 lbr daun salam (buang tulangnya)
1. Gunakan 1 sdt ketumbar bubuk
1. Siapkan 3/4 sdt jintan bubuk
1. Gunakan 1/2 sdt merica bubuk
1. Gunakan 1 sdt gula pasir
1. Sediakan 1 sdt garam
1. Gunakan 1 sdt kaldu jamur




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam Lodho:

1. Rebus air hingga mendidih lalu masukkan ayam, masak sampai matang. Setelah matang, angkat lalu panggang sebentar di teflon nonstick sampai kecoklatan (air rebusan jg dibuang)
1. Blender semua bahan bumbu halus lalu tumis di minyak yg sdh dipanaskan hingga wangi dan matang
1. Masukkan ayam, lalu tambahkan air rebusan ayam tadi. Dikira aja jgn terlalu byk yah karna akan lama menyusut nanti jadi secukupnya aja
1. Masukkan santan, aduk rata dan koreksi rasa. Masak hingga kuah agak menyusut lalu matikan api
1. Jika sdh menyusut pindahkan dalam wadah, lalu tambahkan kemangi, cabe rawit, dan putih telur. Aduk rata
1. Masukkan adonan dalam takir bujur sangkar yg sdh disiapkan (kalo ga ada boleh ganti yg lain asal tahan panas). Utk yg 2 saya beri kuning telur diatasnya karena cmn pake 2 telur 😅
1. Siapkan kukusan yg sdh panas, lalu kukus ayam lodho sampai matang sekitar 20-30 menit.
1. Siap disantap ☺️




Ternyata cara buat ayam lodho yang lezat simple ini enteng sekali ya! Semua orang dapat membuatnya. Cara buat ayam lodho Cocok banget untuk kita yang baru belajar memasak maupun juga untuk anda yang telah jago dalam memasak.

Tertarik untuk mulai mencoba membuat resep ayam lodho nikmat simple ini? Kalau kalian tertarik, yuk kita segera buruan menyiapkan peralatan dan bahan-bahannya, setelah itu buat deh Resep ayam lodho yang nikmat dan simple ini. Betul-betul gampang kan. 

Jadi, daripada kalian berfikir lama-lama, maka langsung aja buat resep ayam lodho ini. Dijamin kalian tiidak akan menyesal sudah bikin resep ayam lodho enak simple ini! Selamat mencoba dengan resep ayam lodho lezat tidak ribet ini di tempat tinggal sendiri,oke!.

