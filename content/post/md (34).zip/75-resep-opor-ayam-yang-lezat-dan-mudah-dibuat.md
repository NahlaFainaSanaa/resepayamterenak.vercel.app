---
description: "Resep Opor Ayam yang lezat dan Mudah Dibuat"
title: "Resep Opor Ayam yang lezat dan Mudah Dibuat"
slug: 75-resep-opor-ayam-yang-lezat-dan-mudah-dibuat
date: 2021-02-26T07:27:14.958Z
image: https://img-global.cpcdn.com/recipes/907306f98c237ad6/680x482cq70/opor-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/907306f98c237ad6/680x482cq70/opor-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/907306f98c237ad6/680x482cq70/opor-ayam-foto-resep-utama.jpg
author: Mabel Rodriquez
ratingvalue: 4.3
reviewcount: 12
recipeingredient:
- "1 ekor ayam sedang potong2 cuci bersih"
- "50 ml santan kara campur air hingga 100ml"
- "3 bh cabe keriting iris serong"
- "1 btg serai geprek"
- "3 daun salam"
- "3 daun jeruk buang tulang"
- "1 ruas jahe"
- "1 ruas lengkuas"
- "1/8 bj pala"
- "1/4 sdt jintan"
- "1/2 sdt ketumbar bubuk"
- "600 ml air minum"
- " Minyak unt menumis"
- "1 sdt garam batu himalayan"
- "secukupnya Lada"
- " Bawang goreng  telur rebus sbg pelengkap"
- " Bahan halus "
- "12 siung bawang merah"
- "6 siung bawang putih"
- "5 bh kemiri"
- "1 ruas kunyit"
recipeinstructions:
- "Tumis semua bahan kecuali santan."
- "Masukkan ayam, aduk rata. Tutup sbntr wajan. Biarkan bumbu meresap."
- "Beri air, didihkan dan masak hingga ayam empuk."
- "Beri garam. Koreksi rasa, matikan api. Masukkan santan &amp; aduk rata."
- "Angkat ayam, saring kuah agar ampas bumbu tdk ikt. Sajikan dgn bawang goreng &amp; telur rebus."
categories:
- Resep
tags:
- opor
- ayam

katakunci: opor ayam 
nutrition: 237 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT44M"
recipeyield: "4"
recipecategory: Dinner

---


![Opor Ayam](https://img-global.cpcdn.com/recipes/907306f98c237ad6/680x482cq70/opor-ayam-foto-resep-utama.jpg)

Sebagai seorang ibu, menyajikan santapan menggugah selera untuk orang tercinta adalah suatu hal yang memuaskan bagi kita sendiri. Tanggung jawab seorang istri bukan sekadar menjaga rumah saja, tetapi kamu pun harus menyediakan kebutuhan nutrisi tercukupi dan hidangan yang dikonsumsi keluarga tercinta mesti enak.

Di waktu  saat ini, kalian memang mampu memesan santapan instan meski tanpa harus repot memasaknya terlebih dahulu. Namun banyak juga lho mereka yang memang ingin memberikan hidangan yang terbaik bagi orang yang dicintainya. Sebab, menyajikan masakan yang diolah sendiri akan jauh lebih higienis dan bisa menyesuaikan masakan tersebut sesuai dengan masakan kesukaan famili. 



Apakah kamu seorang penikmat opor ayam?. Asal kamu tahu, opor ayam merupakan hidangan khas di Nusantara yang sekarang digemari oleh banyak orang dari berbagai daerah di Indonesia. Kamu dapat menghidangkan opor ayam kreasi sendiri di rumahmu dan boleh dijadikan santapan favoritmu di hari liburmu.

Kalian jangan bingung untuk menyantap opor ayam, lantaran opor ayam tidak sukar untuk didapatkan dan kalian pun boleh mengolahnya sendiri di tempatmu. opor ayam bisa dibuat dengan beragam cara. Saat ini ada banyak banget cara kekinian yang menjadikan opor ayam semakin lebih enak.

Resep opor ayam pun mudah sekali untuk dibuat, lho. Kita tidak usah ribet-ribet untuk membeli opor ayam, lantaran Kamu dapat menyiapkan ditempatmu. Untuk Anda yang hendak menyajikannya, inilah cara menyajikan opor ayam yang mantab yang bisa Anda buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Opor Ayam:

1. Gunakan 1 ekor ayam sedang, potong2, cuci bersih
1. Siapkan 50 ml santan kara, campur air hingga 100ml
1. Ambil 3 bh cabe keriting, iris serong
1. Ambil 1 btg serai, geprek
1. Gunakan 3 daun salam
1. Siapkan 3 daun jeruk, buang tulang
1. Ambil 1 ruas jahe
1. Ambil 1 ruas lengkuas
1. Gunakan 1/8 bj pala
1. Gunakan 1/4 sdt jintan
1. Sediakan 1/2 sdt ketumbar bubuk
1. Sediakan 600 ml air minum
1. Siapkan  Minyak unt menumis
1. Siapkan 1 sdt garam batu himalayan
1. Ambil secukupnya Lada
1. Sediakan  Bawang goreng &amp; telur rebus sbg pelengkap
1. Gunakan  Bahan halus :
1. Gunakan 12 siung bawang merah
1. Siapkan 6 siung bawang putih
1. Gunakan 5 bh kemiri
1. Sediakan 1 ruas kunyit




<!--inarticleads2-->

##### Cara menyiapkan Opor Ayam:

1. Tumis semua bahan kecuali santan.
1. Masukkan ayam, aduk rata. Tutup sbntr wajan. Biarkan bumbu meresap.
1. Beri air, didihkan dan masak hingga ayam empuk.
1. Beri garam. Koreksi rasa, matikan api. Masukkan santan &amp; aduk rata.
1. Angkat ayam, saring kuah agar ampas bumbu tdk ikt. Sajikan dgn bawang goreng &amp; telur rebus.




Wah ternyata resep opor ayam yang nikamt tidak rumit ini gampang banget ya! Semua orang mampu menghidangkannya. Cara buat opor ayam Sangat sesuai sekali untuk kamu yang baru mau belajar memasak maupun bagi kalian yang sudah pandai dalam memasak.

Apakah kamu mau mulai mencoba bikin resep opor ayam mantab tidak ribet ini? Kalau kamu tertarik, yuk kita segera buruan menyiapkan peralatan dan bahan-bahannya, setelah itu bikin deh Resep opor ayam yang lezat dan tidak rumit ini. Benar-benar mudah kan. 

Maka dari itu, daripada anda berfikir lama-lama, hayo kita langsung buat resep opor ayam ini. Dijamin kalian tiidak akan menyesal sudah buat resep opor ayam mantab tidak ribet ini! Selamat berkreasi dengan resep opor ayam nikmat tidak ribet ini di tempat tinggal kalian sendiri,oke!.

