---
description: "Resep Ayam Panggang Bumbu Rempah Sederhana Untuk Jualan"
title: "Resep Ayam Panggang Bumbu Rempah Sederhana Untuk Jualan"
slug: 310-resep-ayam-panggang-bumbu-rempah-sederhana-untuk-jualan
date: 2021-03-20T06:48:39.786Z
image: https://img-global.cpcdn.com/recipes/9d6b93e914dd53b2/680x482cq70/ayam-panggang-bumbu-rempah-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9d6b93e914dd53b2/680x482cq70/ayam-panggang-bumbu-rempah-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9d6b93e914dd53b2/680x482cq70/ayam-panggang-bumbu-rempah-foto-resep-utama.jpg
author: Eric Burns
ratingvalue: 4.5
reviewcount: 14
recipeingredient:
- "2 ekor ayam kampung ukuran sedang"
- "200 ml air kelapa"
- "10 siung bawang merah"
- "1 bonggol bawang putih"
- "1 sdm tipis terasi"
- "1 sdm ketumbar sangrai"
- "6 butir kemiri sangrai"
- "1 blok bulat gula jawa"
- "10 cm jahe"
- "3 bh cabai merah besar buang biji"
- "10 cm lengkuas"
- "2 bh tomat"
- "Secukupnya kecap"
- "1,5 sdt garam"
- "Secukupnya minyak untuk menumis"
- "Secukupnya daun salam"
- "Secukupnya daun jeruk"
recipeinstructions:
- "Haluskan bawang2, jahe, lengkuas, tomat, cabai, terasi, kemiri &amp; ketumbar."
- "Tumis bumbu halus beserta dengan daun jeruk &amp; daun salam hingga harum"
- "Siapkan wajan untuk mengungkep, masukan ayam &amp; air kelapa, tambahkan air jika perlu, dan masukan tumisan bumbu dan gula jawa."
- "Masak ayam hingga bumbu meresap &amp; asat. Sambil panaskan oven 160 derajat."
- "Siapkan loyang yang telah dilapisi alumunium foil. Masukan ayam kedalam loyang"
- "Panggang ayam dalam oven yang sudah dipanaskan selama 15-20 menit."
- "Jika sudah matang, sajikan bersama dengan lalap dan sambal terasi."
categories:
- Resep
tags:
- ayam
- panggang
- bumbu

katakunci: ayam panggang bumbu 
nutrition: 106 calories
recipecuisine: Indonesian
preptime: "PT33M"
cooktime: "PT54M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Panggang Bumbu Rempah](https://img-global.cpcdn.com/recipes/9d6b93e914dd53b2/680x482cq70/ayam-panggang-bumbu-rempah-foto-resep-utama.jpg)

Selaku seorang istri, menyajikan panganan lezat kepada orang tercinta merupakan hal yang sangat menyenangkan untuk kita sendiri. Tanggung jawab seorang istri Tidak saja menangani rumah saja, tetapi kamu pun wajib memastikan keperluan gizi tercukupi dan juga santapan yang dikonsumsi keluarga tercinta wajib menggugah selera.

Di masa  saat ini, kita sebenarnya dapat memesan olahan yang sudah jadi walaupun tidak harus capek memasaknya dahulu. Namun banyak juga lho mereka yang selalu ingin memberikan makanan yang terbaik untuk orang tercintanya. Sebab, memasak sendiri jauh lebih higienis dan kita juga bisa menyesuaikan hidangan tersebut berdasarkan selera keluarga. 



Mungkinkah kamu salah satu penggemar ayam panggang bumbu rempah?. Tahukah kamu, ayam panggang bumbu rempah adalah hidangan khas di Indonesia yang kini disukai oleh banyak orang dari berbagai daerah di Indonesia. Anda bisa menghidangkan ayam panggang bumbu rempah sendiri di rumahmu dan boleh dijadikan camilan favoritmu di hari libur.

Kalian tidak usah bingung untuk memakan ayam panggang bumbu rempah, karena ayam panggang bumbu rempah tidak sulit untuk dicari dan kita pun dapat mengolahnya sendiri di rumah. ayam panggang bumbu rempah dapat diolah lewat berbagai cara. Sekarang ada banyak cara kekinian yang membuat ayam panggang bumbu rempah semakin lezat.

Resep ayam panggang bumbu rempah juga mudah dihidangkan, lho. Kamu tidak perlu repot-repot untuk membeli ayam panggang bumbu rempah, lantaran Kita bisa menghidangkan di rumahmu. Bagi Kalian yang mau menyajikannya, dibawah ini merupakan cara untuk membuat ayam panggang bumbu rempah yang nikamat yang dapat Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Ayam Panggang Bumbu Rempah:

1. Gunakan 2 ekor ayam kampung ukuran sedang
1. Siapkan 200 ml air kelapa
1. Ambil 10 siung bawang merah
1. Sediakan 1 bonggol bawang putih
1. Sediakan 1 sdm tipis terasi
1. Siapkan 1 sdm ketumbar sangrai
1. Gunakan 6 butir kemiri sangrai
1. Siapkan 1 blok bulat gula jawa
1. Gunakan 10 cm jahe
1. Ambil 3 bh cabai merah besar, buang biji
1. Sediakan 10 cm lengkuas
1. Gunakan 2 bh tomat
1. Sediakan Secukupnya kecap
1. Sediakan 1,5 sdt garam
1. Sediakan Secukupnya minyak untuk menumis
1. Gunakan Secukupnya daun salam
1. Ambil Secukupnya daun jeruk




<!--inarticleads2-->

##### Cara menyiapkan Ayam Panggang Bumbu Rempah:

1. Haluskan bawang2, jahe, lengkuas, tomat, cabai, terasi, kemiri &amp; ketumbar.
1. Tumis bumbu halus beserta dengan daun jeruk &amp; daun salam hingga harum
1. Siapkan wajan untuk mengungkep, masukan ayam &amp; air kelapa, tambahkan air jika perlu, dan masukan tumisan bumbu dan gula jawa.
1. Masak ayam hingga bumbu meresap &amp; asat. Sambil panaskan oven 160 derajat.
1. Siapkan loyang yang telah dilapisi alumunium foil. Masukan ayam kedalam loyang
1. Panggang ayam dalam oven yang sudah dipanaskan selama 15-20 menit.
1. Jika sudah matang, sajikan bersama dengan lalap dan sambal terasi.




Ternyata cara membuat ayam panggang bumbu rempah yang enak tidak rumit ini gampang banget ya! Anda Semua mampu mencobanya. Resep ayam panggang bumbu rempah Sangat sesuai sekali untuk kalian yang baru belajar memasak maupun untuk kalian yang telah ahli dalam memasak.

Apakah kamu mau mencoba bikin resep ayam panggang bumbu rempah lezat tidak rumit ini? Kalau anda tertarik, mending kamu segera siapin peralatan dan bahan-bahannya, kemudian bikin deh Resep ayam panggang bumbu rempah yang nikmat dan tidak rumit ini. Sungguh mudah kan. 

Maka, daripada anda berfikir lama-lama, ayo kita langsung buat resep ayam panggang bumbu rempah ini. Dijamin kalian tiidak akan menyesal sudah buat resep ayam panggang bumbu rempah lezat simple ini! Selamat mencoba dengan resep ayam panggang bumbu rempah nikmat simple ini di rumah kalian masing-masing,oke!.

