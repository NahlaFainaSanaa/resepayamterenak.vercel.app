---
description: "Bahan-bahan Ayam Kentucky ala KFC yang enak dan Mudah Dibuat"
title: "Bahan-bahan Ayam Kentucky ala KFC yang enak dan Mudah Dibuat"
slug: 41-bahan-bahan-ayam-kentucky-ala-kfc-yang-enak-dan-mudah-dibuat
date: 2021-06-03T14:22:10.571Z
image: https://img-global.cpcdn.com/recipes/c984b5f6ef443d1e/680x482cq70/ayam-kentucky-ala-kfc-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c984b5f6ef443d1e/680x482cq70/ayam-kentucky-ala-kfc-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c984b5f6ef443d1e/680x482cq70/ayam-kentucky-ala-kfc-foto-resep-utama.jpg
author: Martin Nichols
ratingvalue: 4
reviewcount: 9
recipeingredient:
- "4 ekor ayam"
- " Bumbu marinasi"
- "1 sdt bawang putih bubuk sy 2 siung cincang halus"
- "1/2 sdt lada bubuk"
- "1/2 sdt ketumbar bubuk"
- "1/2 sdt kunyit bubuk"
- "1 sdt kaldu ayam"
- "1/2 sdt garam"
- " Bahan pelapis "
- "300 gr tepung terigu cakra"
- "2 sdt bawang putih bubuk sy skip krn kosong"
- "1/2 sdt baking powder"
- "1/2 sdt lada bubuk"
- "1/2 sdt garam"
- "1 sdt kaldu ayam"
- " Bahan pencelup "
- "3 sdm tepung diambil dr bahan pelapis"
- "400 ml air dingines"
recipeinstructions:
- "Cuci bersih ayam, beri bumbu marinasi aduk rata diamkan di kulkas selama 1 jam"
- "Campurkan semua bahan pelapis lalu ambil 3 adonan (utk adonan basah) beri air es perlahan aduk rata jgn sampai bergelindir adonan jgn terlalu encer"
- "Masukan ayam yg sudah dimarinasi kedalam adonan tepung kering lalu masukan keadonan basah lalu gulir lagi keadonan kering sambil di cubit2 dikit"
- "Panaskan dg minyak yg banyak goreng ayam hingga kecoklatan dan gurih angkat lalu tiriskan. Siap deh disajikan kfc ala ala nya. Ini favorite anak ku banget 😍😍"
categories:
- Resep
tags:
- ayam
- kentucky
- ala

katakunci: ayam kentucky ala 
nutrition: 178 calories
recipecuisine: Indonesian
preptime: "PT11M"
cooktime: "PT48M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Kentucky ala KFC](https://img-global.cpcdn.com/recipes/c984b5f6ef443d1e/680x482cq70/ayam-kentucky-ala-kfc-foto-resep-utama.jpg)

Sebagai seorang orang tua, menyediakan santapan enak untuk orang tercinta merupakan suatu hal yang menyenangkan bagi kita sendiri. Tugas seorang istri bukan saja menjaga rumah saja, tapi anda pun harus menyediakan keperluan gizi tercukupi dan juga masakan yang dimakan anak-anak wajib menggugah selera.

Di waktu  saat ini, kalian sebenarnya mampu memesan hidangan instan walaupun tidak harus capek memasaknya terlebih dahulu. Namun banyak juga orang yang memang ingin memberikan makanan yang terenak bagi orang tercintanya. Pasalnya, memasak yang diolah sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan makanan tersebut sesuai dengan kesukaan keluarga tercinta. 



Apakah anda salah satu penggemar ayam kentucky ala kfc?. Tahukah kamu, ayam kentucky ala kfc merupakan hidangan khas di Indonesia yang sekarang disenangi oleh banyak orang di hampir setiap tempat di Nusantara. Anda dapat menghidangkan ayam kentucky ala kfc hasil sendiri di rumah dan boleh jadi hidangan favoritmu di akhir pekanmu.

Anda tidak usah bingung untuk menyantap ayam kentucky ala kfc, karena ayam kentucky ala kfc mudah untuk didapatkan dan juga kamu pun dapat memasaknya sendiri di rumah. ayam kentucky ala kfc boleh diolah lewat beragam cara. Kini sudah banyak cara modern yang menjadikan ayam kentucky ala kfc semakin lebih enak.

Resep ayam kentucky ala kfc juga sangat gampang untuk dibuat, lho. Anda tidak usah capek-capek untuk memesan ayam kentucky ala kfc, tetapi Kalian bisa menyiapkan di rumah sendiri. Bagi Kita yang ingin menghidangkannya, berikut ini resep menyajikan ayam kentucky ala kfc yang nikamat yang bisa Anda coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Ayam Kentucky ala KFC:

1. Siapkan 4 ekor ayam
1. Gunakan  Bumbu marinasi
1. Siapkan 1 sdt bawang putih bubuk (sy 2 siung cincang halus)
1. Sediakan 1/2 sdt lada bubuk
1. Siapkan 1/2 sdt ketumbar bubuk
1. Sediakan 1/2 sdt kunyit bubuk
1. Gunakan 1 sdt kaldu ayam
1. Ambil 1/2 sdt garam
1. Siapkan  Bahan pelapis :
1. Siapkan 300 gr tepung terigu cakra
1. Sediakan 2 sdt bawang putih bubuk (sy skip krn kosong)
1. Siapkan 1/2 sdt baking powder
1. Siapkan 1/2 sdt lada bubuk
1. Siapkan 1/2 sdt garam
1. Sediakan 1 sdt kaldu ayam
1. Sediakan  Bahan pencelup :
1. Siapkan 3 sdm tepung (diambil dr bahan pelapis)
1. Gunakan 400 ml air dingin/es




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam Kentucky ala KFC:

1. Cuci bersih ayam, beri bumbu marinasi aduk rata diamkan di kulkas selama 1 jam
1. Campurkan semua bahan pelapis lalu ambil 3 adonan (utk adonan basah) beri air es perlahan aduk rata jgn sampai bergelindir adonan jgn terlalu encer
1. Masukan ayam yg sudah dimarinasi kedalam adonan tepung kering lalu masukan keadonan basah lalu gulir lagi keadonan kering sambil di cubit2 dikit
1. Panaskan dg minyak yg banyak goreng ayam hingga kecoklatan dan gurih angkat lalu tiriskan. Siap deh disajikan kfc ala ala nya. Ini favorite anak ku banget 😍😍




Ternyata cara buat ayam kentucky ala kfc yang enak simple ini mudah banget ya! Anda Semua dapat memasaknya. Resep ayam kentucky ala kfc Sangat sesuai banget untuk kamu yang baru belajar memasak atau juga bagi anda yang sudah lihai dalam memasak.

Apakah kamu ingin mencoba buat resep ayam kentucky ala kfc enak sederhana ini? Kalau anda mau, ayo kamu segera buruan siapin alat dan bahannya, lantas buat deh Resep ayam kentucky ala kfc yang nikmat dan simple ini. Sangat gampang kan. 

Jadi, daripada anda berfikir lama-lama, ayo kita langsung buat resep ayam kentucky ala kfc ini. Dijamin anda tiidak akan menyesal sudah buat resep ayam kentucky ala kfc mantab tidak rumit ini! Selamat mencoba dengan resep ayam kentucky ala kfc enak simple ini di rumah kalian sendiri,ya!.

