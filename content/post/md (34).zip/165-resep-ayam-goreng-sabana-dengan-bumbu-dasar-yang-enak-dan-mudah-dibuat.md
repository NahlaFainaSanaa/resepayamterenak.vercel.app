---
description: "Resep Ayam goreng Sabana dengan bumbu dasar yang enak dan Mudah Dibuat"
title: "Resep Ayam goreng Sabana dengan bumbu dasar yang enak dan Mudah Dibuat"
slug: 165-resep-ayam-goreng-sabana-dengan-bumbu-dasar-yang-enak-dan-mudah-dibuat
date: 2021-04-11T21:37:12.487Z
image: https://img-global.cpcdn.com/recipes/9534cae84d2c113b/680x482cq70/ayam-goreng-sabana-dengan-bumbu-dasar-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9534cae84d2c113b/680x482cq70/ayam-goreng-sabana-dengan-bumbu-dasar-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9534cae84d2c113b/680x482cq70/ayam-goreng-sabana-dengan-bumbu-dasar-foto-resep-utama.jpg
author: Lee Ford
ratingvalue: 4.6
reviewcount: 7
recipeingredient:
- "1/2 kg daging ayam"
- "1/2 butir Jeruk nipis peras"
- " Bumbu marinasi"
- "1/2 butir jeruk nipis peras"
- "1 sdm bumbu dasar kuning bisa lihat resep saya "
- "Secukupnya garam"
- "2 sdm susu cair"
- " Bumbu untuk mengolah ayam goreng Sabana dgn marinasi"
- "3 butir bawang merah iris"
- "2 siung bawang putih iris"
- " Serai lengkuas parut daun jeruk daun salam"
- "Secukupnya air untuk merebus"
- "bila perlu Tambahkan garam"
- "Secukupnya minyak"
recipeinstructions:
- "Cuci bersih daging ayam dengan jeruk nipis, dan tiriskan sampai benar2 tiris."
- "Langkah marinasi: setelah tiris, tambahkan air jeruk nipis lagi, dan 1 sdm bumbu praktis/ dasar kuning."
- "Aduk rata kemudian tambahkan 2 sdm susu cair, susu cair disini akan merubah rasa jadi tambah enak.. aduk2 istirahatkan 1 jam di almari es."
- "Untuk memasak ayam Sabana ini, praktis ya Karena sudah dimarinasi dengan bumbu, tumis saja 3bawang merah dan 2putih yg sudah di iris. Tumis hingga harum tambahkan air secukupnya, dan masukkan daging ayam sambil di tiriskan dr bumbu marinasi, tambahkan juga kelapa parut, daun salam, 1 sdm lengkuas parut, daun jeruk, daun serai geprek aduk2 hingga air surut."
- "Panaskan minyak  Goreng terpisah antara daging ayam dan kelapa, goreng bergantian. Setelah semua matang. Panggang ya dengan suhu 120°, supaya minyak turun. Selamat mencoba..  Bisa juga dengan resep ini.  https://cookpad.com/id/resep/14448135-ayam-goreng-sabana-padang?invite_token=48oATy99m8M5sAg1k2aTJEJR&amp;shared_at=1618526355"
categories:
- Resep
tags:
- ayam
- goreng
- sabana

katakunci: ayam goreng sabana 
nutrition: 267 calories
recipecuisine: Indonesian
preptime: "PT27M"
cooktime: "PT33M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam goreng Sabana dengan bumbu dasar](https://img-global.cpcdn.com/recipes/9534cae84d2c113b/680x482cq70/ayam-goreng-sabana-dengan-bumbu-dasar-foto-resep-utama.jpg)

Jika kamu seorang istri, menyajikan olahan menggugah selera pada orang tercinta merupakan hal yang membahagiakan bagi anda sendiri. Tanggung jawab seorang  wanita Tidak saja mengurus rumah saja, namun kamu juga wajib memastikan keperluan gizi tercukupi dan juga panganan yang dimakan keluarga tercinta wajib enak.

Di masa  sekarang, kamu sebenarnya mampu mengorder masakan siap saji meski tanpa harus ribet mengolahnya terlebih dahulu. Namun ada juga lho mereka yang memang ingin menghidangkan yang terenak untuk orang tercintanya. Lantaran, menghidangkan masakan sendiri jauh lebih bersih dan kita juga bisa menyesuaikan makanan tersebut sesuai selera keluarga. 



Apakah anda seorang penggemar ayam goreng sabana dengan bumbu dasar?. Tahukah kamu, ayam goreng sabana dengan bumbu dasar merupakan sajian khas di Nusantara yang saat ini disenangi oleh orang-orang dari berbagai daerah di Nusantara. Kalian bisa memasak ayam goreng sabana dengan bumbu dasar olahan sendiri di rumah dan pasti jadi hidangan kesenanganmu di hari libur.

Anda jangan bingung jika kamu ingin mendapatkan ayam goreng sabana dengan bumbu dasar, lantaran ayam goreng sabana dengan bumbu dasar tidak sukar untuk dicari dan kamu pun boleh membuatnya sendiri di rumah. ayam goreng sabana dengan bumbu dasar dapat dimasak lewat berbagai cara. Kini telah banyak resep kekinian yang membuat ayam goreng sabana dengan bumbu dasar semakin mantap.

Resep ayam goreng sabana dengan bumbu dasar juga mudah sekali dibikin, lho. Kalian jangan ribet-ribet untuk memesan ayam goreng sabana dengan bumbu dasar, lantaran Kita mampu menyiapkan sendiri di rumah. Untuk Kalian yang akan menyajikannya, berikut cara membuat ayam goreng sabana dengan bumbu dasar yang lezat yang mampu Anda hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Ayam goreng Sabana dengan bumbu dasar:

1. Ambil 1/2 kg daging ayam
1. Siapkan 1/2 butir Jeruk nipis, peras
1. Siapkan  Bumbu marinasi:
1. Siapkan 1/2 butir jeruk nipis, peras
1. Gunakan 1 sdm bumbu dasar kuning bisa lihat resep saya, ☝️
1. Sediakan Secukupnya garam
1. Sediakan 2 sdm susu cair
1. Ambil  Bumbu untuk mengolah ayam goreng Sabana dgn marinasi
1. Gunakan 3 butir bawang merah, iris
1. Sediakan 2 siung bawang putih, iris
1. Gunakan  Serai, lengkuas parut, daun jeruk, daun salam
1. Gunakan Secukupnya air untuk merebus
1. Gunakan bila perlu Tambahkan garam
1. Sediakan Secukupnya minyak




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam goreng Sabana dengan bumbu dasar:

1. Cuci bersih daging ayam dengan jeruk nipis, dan tiriskan sampai benar2 tiris.
1. Langkah marinasi: setelah tiris, tambahkan air jeruk nipis lagi, dan 1 sdm bumbu praktis/ dasar kuning.
1. Aduk rata kemudian tambahkan 2 sdm susu cair, susu cair disini akan merubah rasa jadi tambah enak.. aduk2 istirahatkan 1 jam di almari es.
1. Untuk memasak ayam Sabana ini, praktis ya Karena sudah dimarinasi dengan bumbu, tumis saja 3bawang merah dan 2putih yg sudah di iris. Tumis hingga harum tambahkan air secukupnya, dan masukkan daging ayam sambil di tiriskan dr bumbu marinasi, tambahkan juga kelapa parut, daun salam, 1 sdm lengkuas parut, daun jeruk, daun serai geprek aduk2 hingga air surut.
1. Panaskan minyak  - Goreng terpisah antara daging ayam dan kelapa, goreng bergantian. Setelah semua matang. Panggang ya dengan suhu 120°, supaya minyak turun. Selamat mencoba.. -  - Bisa juga dengan resep ini. -  - https://cookpad.com/id/resep/14448135-ayam-goreng-sabana-padang?invite_token=48oATy99m8M5sAg1k2aTJEJR&amp;shared_at=1618526355




Wah ternyata cara membuat ayam goreng sabana dengan bumbu dasar yang lezat sederhana ini gampang sekali ya! Kamu semua mampu membuatnya. Cara buat ayam goreng sabana dengan bumbu dasar Cocok sekali buat kamu yang baru mau belajar memasak ataupun untuk kalian yang telah pandai dalam memasak.

Apakah kamu mau mulai mencoba bikin resep ayam goreng sabana dengan bumbu dasar lezat tidak ribet ini? Kalau mau, yuk kita segera buruan siapkan alat dan bahannya, lantas bikin deh Resep ayam goreng sabana dengan bumbu dasar yang mantab dan tidak rumit ini. Betul-betul gampang kan. 

Maka dari itu, daripada kita diam saja, ayo langsung aja sajikan resep ayam goreng sabana dengan bumbu dasar ini. Pasti anda tiidak akan menyesal sudah membuat resep ayam goreng sabana dengan bumbu dasar nikmat simple ini! Selamat berkreasi dengan resep ayam goreng sabana dengan bumbu dasar nikmat sederhana ini di tempat tinggal sendiri,ya!.

