---
description: "Resep Soto Ayam Tasik kuah santan yang lezat dan Mudah Dibuat"
title: "Resep Soto Ayam Tasik kuah santan yang lezat dan Mudah Dibuat"
slug: 385-resep-soto-ayam-tasik-kuah-santan-yang-lezat-dan-mudah-dibuat
date: 2021-04-24T23:34:09.630Z
image: https://img-global.cpcdn.com/recipes/6f6ccb073e851e61/680x482cq70/soto-ayam-tasik-kuah-santan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6f6ccb073e851e61/680x482cq70/soto-ayam-tasik-kuah-santan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6f6ccb073e851e61/680x482cq70/soto-ayam-tasik-kuah-santan-foto-resep-utama.jpg
author: Rodney Coleman
ratingvalue: 3.7
reviewcount: 14
recipeingredient:
- "1/2 ekor ayam kampung"
- "1500 ml air"
- "500 ml santan"
- " Bumbu cemplung "
- "2 lbr daun salam"
- "2 btg sere"
- "3 cm lengkuas"
- "2 btg daun bawang simpulkan"
- " Bumbu perasa "
- "3 sdt garam"
- "1 sdt gula pasir"
- " Bumbu halus "
- "6 siung bawang merah"
- "2 siung bawang putih"
- "1/2 sdt merica"
- "2 butir kemiri sangrai"
- "2 sdm minyak sayur utk menumis"
- " Pelengkap "
- "1 bks kecil soun rendam"
- "1 btg saledri cincang halus"
- "2 sdm bawang goreng"
- " Kerupuk sambal"
recipeinstructions:
- "Didihkan air rebus ayam yg sdh di potong2 beri garam, masak hingga matang, angkat ayam dan suwir2, saring kuahnya"
- "Panaskan minyak lalu tumis bumbu halus hingga layu dan wangi + bumbu cemplung aduk rata masukkan dlm air kaldu rebusan ayam biarkan mendidih + sisa garam aduk hingga rata, tuang santan aduk terus perlahan jgn sampai santan pecah biarkan mendidih"
- "Cek rasa matang angkat Siapkan mangkok tata nasi, soun, ayam yg sdh di suwir2 + daun saledri dan siram kuah soto di atasnya beri taburan bawang goreng"
- "Siap disajikan dgn sambal, air jeruk nipis dan kerupuk"
categories:
- Resep
tags:
- soto
- ayam
- tasik

katakunci: soto ayam tasik 
nutrition: 261 calories
recipecuisine: Indonesian
preptime: "PT25M"
cooktime: "PT30M"
recipeyield: "4"
recipecategory: Dessert

---


![Soto Ayam Tasik kuah santan](https://img-global.cpcdn.com/recipes/6f6ccb073e851e61/680x482cq70/soto-ayam-tasik-kuah-santan-foto-resep-utama.jpg)

Selaku seorang istri, mempersiapkan hidangan lezat bagi keluarga merupakan suatu hal yang mengasyikan untuk kamu sendiri. Tugas seorang  wanita Tidak sekedar mengerjakan pekerjaan rumah saja, tetapi kamu pun wajib menyediakan keperluan nutrisi tercukupi dan olahan yang dikonsumsi anak-anak wajib enak.

Di zaman  sekarang, kita memang dapat memesan santapan instan tidak harus ribet memasaknya dahulu. Tetapi ada juga orang yang memang ingin memberikan makanan yang terlezat bagi orang yang dicintainya. Pasalnya, memasak sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan sesuai dengan kesukaan keluarga. 



Apakah anda adalah seorang penyuka soto ayam tasik kuah santan?. Asal kamu tahu, soto ayam tasik kuah santan merupakan sajian khas di Indonesia yang sekarang digemari oleh banyak orang dari berbagai tempat di Nusantara. Anda dapat memasak soto ayam tasik kuah santan kreasi sendiri di rumahmu dan pasti jadi camilan kegemaranmu di hari liburmu.

Kita tak perlu bingung jika kamu ingin memakan soto ayam tasik kuah santan, lantaran soto ayam tasik kuah santan sangat mudah untuk didapatkan dan anda pun bisa mengolahnya sendiri di rumah. soto ayam tasik kuah santan boleh diolah dengan berbagai cara. Saat ini ada banyak resep kekinian yang menjadikan soto ayam tasik kuah santan semakin lezat.

Resep soto ayam tasik kuah santan juga gampang untuk dibikin, lho. Kalian jangan capek-capek untuk memesan soto ayam tasik kuah santan, lantaran Anda mampu membuatnya di rumahmu. Bagi Kamu yang akan mencobanya, di bawah ini adalah resep membuat soto ayam tasik kuah santan yang enak yang bisa Anda hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Soto Ayam Tasik kuah santan:

1. Gunakan 1/2 ekor ayam kampung
1. Gunakan 1500 ml air
1. Ambil 500 ml santan
1. Sediakan  Bumbu cemplung :
1. Ambil 2 lbr daun salam
1. Siapkan 2 btg sere
1. Siapkan 3 cm lengkuas
1. Ambil 2 btg daun bawang simpulkan
1. Gunakan  Bumbu perasa :
1. Siapkan 3 sdt garam
1. Ambil 1 sdt gula pasir
1. Siapkan  Bumbu halus :
1. Siapkan 6 siung bawang merah
1. Sediakan 2 siung bawang putih
1. Siapkan 1/2 sdt merica
1. Siapkan 2 butir kemiri sangrai
1. Ambil 2 sdm minyak sayur utk menumis
1. Siapkan  Pelengkap :
1. Sediakan 1 bks kecil soun rendam
1. Ambil 1 btg saledri cincang halus
1. Ambil 2 sdm bawang goreng
1. Siapkan  Kerupuk, sambal




<!--inarticleads2-->

##### Cara membuat Soto Ayam Tasik kuah santan:

1. Didihkan air rebus ayam yg sdh di potong2 beri garam, masak hingga matang, angkat ayam dan suwir2, saring kuahnya
1. Panaskan minyak lalu tumis bumbu halus hingga layu dan wangi + bumbu cemplung aduk rata masukkan dlm air kaldu rebusan ayam biarkan mendidih + sisa garam aduk hingga rata, tuang santan aduk terus perlahan jgn sampai santan pecah biarkan mendidih
1. Cek rasa matang angkat - Siapkan mangkok tata nasi, soun, ayam yg sdh di suwir2 + daun saledri dan siram kuah soto di atasnya beri taburan bawang goreng
1. Siap disajikan dgn sambal, air jeruk nipis dan kerupuk




Ternyata cara membuat soto ayam tasik kuah santan yang lezat tidak rumit ini enteng sekali ya! Kita semua dapat membuatnya. Cara buat soto ayam tasik kuah santan Sangat sesuai banget buat kita yang sedang belajar memasak atau juga untuk kamu yang sudah pandai dalam memasak.

Apakah kamu tertarik mencoba buat resep soto ayam tasik kuah santan nikmat tidak ribet ini? Kalau ingin, ayo kamu segera siapin alat dan bahannya, lalu bikin deh Resep soto ayam tasik kuah santan yang nikmat dan simple ini. Betul-betul taidak sulit kan. 

Oleh karena itu, ketimbang kamu diam saja, ayo langsung aja buat resep soto ayam tasik kuah santan ini. Dijamin kamu gak akan menyesal sudah buat resep soto ayam tasik kuah santan enak simple ini! Selamat berkreasi dengan resep soto ayam tasik kuah santan mantab sederhana ini di rumah sendiri,ya!.

