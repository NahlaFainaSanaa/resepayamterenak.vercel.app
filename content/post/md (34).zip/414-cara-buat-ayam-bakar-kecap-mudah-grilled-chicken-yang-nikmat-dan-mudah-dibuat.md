---
description: "Cara buat Ayam Bakar Kecap Mudah (Grilled Chicken) yang nikmat dan Mudah Dibuat"
title: "Cara buat Ayam Bakar Kecap Mudah (Grilled Chicken) yang nikmat dan Mudah Dibuat"
slug: 414-cara-buat-ayam-bakar-kecap-mudah-grilled-chicken-yang-nikmat-dan-mudah-dibuat
date: 2021-02-04T10:17:19.494Z
image: https://img-global.cpcdn.com/recipes/ebba67b76f1684da/680x482cq70/ayam-bakar-kecap-mudah-grilled-chicken-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ebba67b76f1684da/680x482cq70/ayam-bakar-kecap-mudah-grilled-chicken-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ebba67b76f1684da/680x482cq70/ayam-bakar-kecap-mudah-grilled-chicken-foto-resep-utama.jpg
author: Jerry Wilkins
ratingvalue: 4.5
reviewcount: 15
recipeingredient:
- "1/2 ekor Ayam saya suka bagian paha"
- " Bumbu Ungkep"
- "1 batang Serai"
- "2 lembar Daun Salam"
- "1 ruas Lengkuas"
- "Secukupnya Garam Gula Merica Bubuk dan Kecap Manis"
- "2 bongkah kecil Gula Merah Sekitar 23 sendok makan bila di potongpotong"
- " Bumbu Halus BlenderUlek"
- "4 siung Bawang Putih"
- "7 siung Bawang Merah"
- "5 buah Cabai Merah Keriting"
- "2 buah Cabai Merah Besar"
- "2 butir Kemiri"
- "1 ruas Jahe"
- "1 sdm Kunyit Bubuk"
- "1 sdm Ketumbar Bubuk"
recipeinstructions:
- "Masukkan bumbu yang sudah dihaluskan kedalam wajan atau panci, lalu tambahkan ayam, serai, lengkuas, daun salam serta air (tambahkan air hingga semua bagian ayam tenggelam). Jangan lupa tambahkan garam, gula dan merica bubuk. Sisihkan gula merah dan kecap untuk nanti."
- "Ungkep ayam dengan api sedang atau kecil, biarkan hingga matang. Setelah ayam matang dan bumbu meresap tambahkan gula merah dan kecap. Lalu aduk rata dan biarkan hingga air ungkepan hampir kering (sambil dites rasa)."
- "Jika suka ayam bakar yang manis bisa tambahkan gula agak banyak dan kecap. Tapi harus sambil dites rasa, agar rasa gula dan kecap tidak terlalu berlebihan."
- "Setelah itu matikan kompor dan bakar ayam yang sudah diungkep dengan teflon (kalau saya, teflon saya lapisi sedikit minyak goreng, diusapkan merata menggunakan tissue). Bakar dengan api kecil."
- "Setelah matang bisa langsung disantap dengan nasi hangat. Selamat Mencoba 😊"
categories:
- Resep
tags:
- ayam
- bakar
- kecap

katakunci: ayam bakar kecap 
nutrition: 127 calories
recipecuisine: Indonesian
preptime: "PT11M"
cooktime: "PT47M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam Bakar Kecap Mudah (Grilled Chicken)](https://img-global.cpcdn.com/recipes/ebba67b76f1684da/680x482cq70/ayam-bakar-kecap-mudah-grilled-chicken-foto-resep-utama.jpg)

Sebagai seorang ibu, menyediakan panganan lezat bagi keluarga tercinta merupakan suatu hal yang sangat menyenangkan bagi anda sendiri. Kewajiban seorang istri bukan cuman mengurus rumah saja, tapi anda juga harus menyediakan kebutuhan gizi terpenuhi dan santapan yang dimakan anak-anak harus sedap.

Di waktu  sekarang, anda memang mampu memesan panganan instan meski tanpa harus ribet membuatnya lebih dulu. Tapi banyak juga lho orang yang selalu mau memberikan makanan yang terbaik untuk orang tercintanya. Karena, menghidangkan masakan sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan masakan tersebut sesuai dengan selera keluarga tercinta. 



Mungkinkah anda adalah seorang penggemar ayam bakar kecap mudah (grilled chicken)?. Tahukah kamu, ayam bakar kecap mudah (grilled chicken) merupakan sajian khas di Nusantara yang saat ini digemari oleh banyak orang di hampir setiap tempat di Nusantara. Kalian dapat menghidangkan ayam bakar kecap mudah (grilled chicken) sendiri di rumahmu dan boleh dijadikan camilan kesukaanmu di akhir pekan.

Anda jangan bingung untuk memakan ayam bakar kecap mudah (grilled chicken), sebab ayam bakar kecap mudah (grilled chicken) mudah untuk ditemukan dan juga kalian pun bisa memasaknya sendiri di tempatmu. ayam bakar kecap mudah (grilled chicken) bisa diolah memalui beraneka cara. Sekarang sudah banyak sekali cara kekinian yang menjadikan ayam bakar kecap mudah (grilled chicken) semakin lebih enak.

Resep ayam bakar kecap mudah (grilled chicken) pun mudah untuk dibuat, lho. Kalian tidak usah ribet-ribet untuk memesan ayam bakar kecap mudah (grilled chicken), lantaran Anda mampu menyiapkan sendiri di rumah. Bagi Kita yang mau membuatnya, berikut resep untuk menyajikan ayam bakar kecap mudah (grilled chicken) yang mantab yang bisa Kamu coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Ayam Bakar Kecap Mudah (Grilled Chicken):

1. Ambil 1/2 ekor Ayam (saya suka bagian paha)
1. Siapkan  Bumbu Ungkep
1. Sediakan 1 batang Serai
1. Ambil 2 lembar Daun Salam
1. Ambil 1 ruas Lengkuas
1. Siapkan Secukupnya Garam, Gula, Merica Bubuk dan Kecap Manis
1. Ambil 2 bongkah kecil Gula Merah (Sekitar 2-3 sendok makan bila di potong-potong)
1. Ambil  Bumbu Halus (Blender/Ulek)
1. Sediakan 4 siung Bawang Putih
1. Siapkan 7 siung Bawang Merah
1. Ambil 5 buah Cabai Merah Keriting
1. Sediakan 2 buah Cabai Merah Besar
1. Siapkan 2 butir Kemiri
1. Siapkan 1 ruas Jahe
1. Ambil 1 sdm Kunyit Bubuk
1. Sediakan 1 sdm Ketumbar Bubuk




<!--inarticleads2-->

##### Cara menyiapkan Ayam Bakar Kecap Mudah (Grilled Chicken):

1. Masukkan bumbu yang sudah dihaluskan kedalam wajan atau panci, lalu tambahkan ayam, serai, lengkuas, daun salam serta air (tambahkan air hingga semua bagian ayam tenggelam). Jangan lupa tambahkan garam, gula dan merica bubuk. Sisihkan gula merah dan kecap untuk nanti.
1. Ungkep ayam dengan api sedang atau kecil, biarkan hingga matang. Setelah ayam matang dan bumbu meresap tambahkan gula merah dan kecap. Lalu aduk rata dan biarkan hingga air ungkepan hampir kering (sambil dites rasa).
1. Jika suka ayam bakar yang manis bisa tambahkan gula agak banyak dan kecap. Tapi harus sambil dites rasa, agar rasa gula dan kecap tidak terlalu berlebihan.
1. Setelah itu matikan kompor dan bakar ayam yang sudah diungkep dengan teflon (kalau saya, teflon saya lapisi sedikit minyak goreng, diusapkan merata menggunakan tissue). Bakar dengan api kecil.
1. Setelah matang bisa langsung disantap dengan nasi hangat. Selamat Mencoba 😊




Wah ternyata resep ayam bakar kecap mudah (grilled chicken) yang mantab simple ini mudah sekali ya! Kalian semua bisa menghidangkannya. Resep ayam bakar kecap mudah (grilled chicken) Sangat cocok banget buat kalian yang baru mau belajar memasak atau juga untuk anda yang sudah ahli memasak.

Tertarik untuk mencoba bikin resep ayam bakar kecap mudah (grilled chicken) mantab sederhana ini? Kalau kalian mau, ayo kalian segera menyiapkan alat-alat dan bahannya, setelah itu buat deh Resep ayam bakar kecap mudah (grilled chicken) yang enak dan tidak ribet ini. Sungguh gampang kan. 

Jadi, daripada kamu berfikir lama-lama, maka langsung aja buat resep ayam bakar kecap mudah (grilled chicken) ini. Dijamin kamu gak akan nyesel sudah membuat resep ayam bakar kecap mudah (grilled chicken) nikmat sederhana ini! Selamat mencoba dengan resep ayam bakar kecap mudah (grilled chicken) nikmat simple ini di rumah masing-masing,ya!.

