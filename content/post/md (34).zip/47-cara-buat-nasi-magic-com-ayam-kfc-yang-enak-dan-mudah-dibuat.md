---
description: "Cara buat Nasi Magic Com Ayam KFC yang enak dan Mudah Dibuat"
title: "Cara buat Nasi Magic Com Ayam KFC yang enak dan Mudah Dibuat"
slug: 47-cara-buat-nasi-magic-com-ayam-kfc-yang-enak-dan-mudah-dibuat
date: 2021-03-06T09:54:28.561Z
image: https://img-global.cpcdn.com/recipes/ea22f47092289472/680x482cq70/nasi-magic-com-ayam-kfc-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ea22f47092289472/680x482cq70/nasi-magic-com-ayam-kfc-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ea22f47092289472/680x482cq70/nasi-magic-com-ayam-kfc-foto-resep-utama.jpg
author: Harry Clark
ratingvalue: 3.5
reviewcount: 5
recipeingredient:
- "2 cangkir beras"
- "4 cangkir air takaran cangkir beras"
- "2 buah ayam KFC Original"
- "3 sdm kecap asin"
- "1 buah wortel ukuran sedang parut halus"
recipeinstructions:
- "Cuci bersih beras"
- "Parut halus wortel"
- "Tuang air ke dalam wadah magic com yang berisi beras, tambahkan 1 buah ayamnutuh, 1 lagi disuwir suwir"
- "Tambahkan parutan wortel dan kecap asin, jangan diaduk, tutup magic comdan masak seperti masak nasi biasa hingga matang"
- "Setelah matang aduk hingga rata nasi dan bumbu, lalu tutup magic com kembali selama beberapa saat sebelum disajikan dengan sambal"
categories:
- Resep
tags:
- nasi
- magic
- com

katakunci: nasi magic com 
nutrition: 190 calories
recipecuisine: Indonesian
preptime: "PT23M"
cooktime: "PT30M"
recipeyield: "2"
recipecategory: Lunch

---


![Nasi Magic Com Ayam KFC](https://img-global.cpcdn.com/recipes/ea22f47092289472/680x482cq70/nasi-magic-com-ayam-kfc-foto-resep-utama.jpg)

Sebagai seorang wanita, menyuguhkan hidangan lezat pada keluarga adalah suatu hal yang memuaskan untuk kita sendiri. Tanggung jawab seorang istri bukan hanya mengatur rumah saja, namun anda pun harus memastikan kebutuhan gizi terpenuhi dan juga hidangan yang disantap keluarga tercinta wajib menggugah selera.

Di masa  saat ini, anda memang dapat memesan hidangan yang sudah jadi walaupun tidak harus susah membuatnya terlebih dahulu. Namun banyak juga lho orang yang memang mau memberikan hidangan yang terenak bagi keluarganya. Sebab, memasak sendiri akan jauh lebih bersih dan bisa menyesuaikan masakan tersebut sesuai makanan kesukaan orang tercinta. 



Apakah kamu salah satu penikmat nasi magic com ayam kfc?. Tahukah kamu, nasi magic com ayam kfc merupakan hidangan khas di Indonesia yang kini digemari oleh orang-orang dari berbagai daerah di Nusantara. Kita bisa memasak nasi magic com ayam kfc sendiri di rumahmu dan pasti jadi santapan kesenanganmu di akhir pekanmu.

Kita tidak usah bingung jika kamu ingin mendapatkan nasi magic com ayam kfc, lantaran nasi magic com ayam kfc tidak sulit untuk didapatkan dan anda pun dapat memasaknya sendiri di rumah. nasi magic com ayam kfc bisa dibuat dengan berbagai cara. Sekarang sudah banyak banget cara kekinian yang menjadikan nasi magic com ayam kfc semakin enak.

Resep nasi magic com ayam kfc pun gampang dihidangkan, lho. Kamu tidak usah ribet-ribet untuk membeli nasi magic com ayam kfc, karena Anda dapat menyiapkan sendiri di rumah. Untuk Kamu yang ingin membuatnya, berikut ini resep untuk menyajikan nasi magic com ayam kfc yang lezat yang mampu Kalian buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Nasi Magic Com Ayam KFC:

1. Siapkan 2 cangkir beras
1. Ambil 4 cangkir air takaran cangkir beras
1. Ambil 2 buah ayam KFC Original
1. Sediakan 3 sdm kecap asin
1. Siapkan 1 .buah wortel ukuran sedang, parut halus




<!--inarticleads2-->

##### Cara membuat Nasi Magic Com Ayam KFC:

1. Cuci bersih beras
1. Parut halus wortel
1. Tuang air ke dalam wadah magic com yang berisi beras, tambahkan 1 buah ayamnutuh, 1 lagi disuwir suwir
1. Tambahkan parutan wortel dan kecap asin, jangan diaduk, tutup magic comdan masak seperti masak nasi biasa hingga matang
1. Setelah matang aduk hingga rata nasi dan bumbu, lalu tutup magic com kembali selama beberapa saat sebelum disajikan dengan sambal




Ternyata cara membuat nasi magic com ayam kfc yang enak simple ini mudah banget ya! Kalian semua mampu menghidangkannya. Cara Membuat nasi magic com ayam kfc Sangat cocok banget untuk kalian yang baru belajar memasak ataupun bagi anda yang telah pandai dalam memasak.

Tertarik untuk mencoba bikin resep nasi magic com ayam kfc mantab sederhana ini? Kalau kalian ingin, ayo kalian segera siapkan alat-alat dan bahannya, setelah itu buat deh Resep nasi magic com ayam kfc yang nikmat dan simple ini. Betul-betul taidak sulit kan. 

Maka dari itu, daripada kamu berlama-lama, hayo langsung aja bikin resep nasi magic com ayam kfc ini. Dijamin kalian tiidak akan nyesel sudah membuat resep nasi magic com ayam kfc nikmat simple ini! Selamat mencoba dengan resep nasi magic com ayam kfc lezat simple ini di rumah masing-masing,oke!.

