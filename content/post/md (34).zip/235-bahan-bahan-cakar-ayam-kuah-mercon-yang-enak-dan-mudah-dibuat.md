---
description: "Bahan-bahan Cakar Ayam Kuah Mercon yang enak dan Mudah Dibuat"
title: "Bahan-bahan Cakar Ayam Kuah Mercon yang enak dan Mudah Dibuat"
slug: 235-bahan-bahan-cakar-ayam-kuah-mercon-yang-enak-dan-mudah-dibuat
date: 2021-02-08T02:16:26.735Z
image: https://img-global.cpcdn.com/recipes/1aadebaf5a3fffc0/680x482cq70/cakar-ayam-kuah-mercon-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1aadebaf5a3fffc0/680x482cq70/cakar-ayam-kuah-mercon-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1aadebaf5a3fffc0/680x482cq70/cakar-ayam-kuah-mercon-foto-resep-utama.jpg
author: Roxie Leonard
ratingvalue: 3.5
reviewcount: 15
recipeingredient:
- "15 ceker ayam cuci bersih"
- "7 siung bawang putih"
- "4 siung bawang putih"
- "2 cabai besar"
- "30 buah cabai rawit"
- "1 buah tomat ukuran kecil"
- "1 lembar daun salam"
- "4 lembar daun jeruk"
- "1 ruas jari lengkuas"
- "1 buah sereh"
- "1,5 sdt garam"
- "1/2 sdt gula"
- "1/2 sdt kunyit bubuk"
- "750 ml air"
- "3 sdm minyak goreng"
recipeinstructions:
- "Haluskan : bawang merah, bawang putih, cabai merah besar, cabai rawit dan tomat."
- "Cuci bersih cakar ayam, rebus dan tunggu hingga mendidih. Buang air rebusan pertama, kemudian rebus lagi cakar ayam dengan 750ml air sampai cakar empuk."
- "Panaskan minyak, tumis bumbu halus dan bumbu daun hingga wangi. Tambahkan garam, gula dan 1/2 sdt kunyit bubuk."
- "Setelah bumbu harum dan tanak, masukan cakar yang sudah direbus. Beri sedikit air sisa rebusan cakar. Koreksi rasa. Tunggu hingga air mendidih dan menyusut."
- "Cakar kuah mercon siap disajikan. Bisa dijadikan kuah untuk seblak mie ala-ala (tanpa kencur) seperti saya 😁"
categories:
- Resep
tags:
- cakar
- ayam
- kuah

katakunci: cakar ayam kuah 
nutrition: 181 calories
recipecuisine: Indonesian
preptime: "PT12M"
cooktime: "PT38M"
recipeyield: "2"
recipecategory: Dessert

---


![Cakar Ayam Kuah Mercon](https://img-global.cpcdn.com/recipes/1aadebaf5a3fffc0/680x482cq70/cakar-ayam-kuah-mercon-foto-resep-utama.jpg)

Selaku seorang ibu, mempersiapkan hidangan lezat kepada keluarga tercinta merupakan suatu hal yang membahagiakan bagi kamu sendiri. Kewajiban seorang istri Tidak sekedar mengatur rumah saja, tapi kamu juga wajib memastikan kebutuhan nutrisi terpenuhi dan panganan yang dikonsumsi keluarga tercinta mesti mantab.

Di waktu  sekarang, kamu sebenarnya dapat mengorder hidangan instan meski tanpa harus susah memasaknya dahulu. Namun banyak juga mereka yang selalu ingin memberikan makanan yang terlezat bagi orang yang dicintainya. Karena, memasak sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan masakan tersebut sesuai dengan kesukaan orang tercinta. 



Mungkinkah anda merupakan salah satu penikmat cakar ayam kuah mercon?. Tahukah kamu, cakar ayam kuah mercon merupakan makanan khas di Nusantara yang saat ini disenangi oleh kebanyakan orang di hampir setiap tempat di Nusantara. Kalian dapat membuat cakar ayam kuah mercon kreasi sendiri di rumah dan pasti jadi camilan kesenanganmu di akhir pekan.

Anda tak perlu bingung untuk mendapatkan cakar ayam kuah mercon, sebab cakar ayam kuah mercon sangat mudah untuk dicari dan kita pun boleh memasaknya sendiri di rumah. cakar ayam kuah mercon boleh diolah memalui beragam cara. Saat ini sudah banyak resep kekinian yang membuat cakar ayam kuah mercon semakin lebih mantap.

Resep cakar ayam kuah mercon pun sangat mudah dihidangkan, lho. Kita jangan ribet-ribet untuk memesan cakar ayam kuah mercon, lantaran Kamu mampu menyajikan ditempatmu. Untuk Kita yang ingin mencobanya, berikut ini resep membuat cakar ayam kuah mercon yang lezat yang mampu Kamu coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Cakar Ayam Kuah Mercon:

1. Siapkan 15 ceker ayam (cuci bersih)
1. Gunakan 7 siung bawang putih
1. Siapkan 4 siung bawang putih
1. Ambil 2 cabai besar
1. Sediakan 30 buah cabai rawit
1. Sediakan 1 buah tomat ukuran kecil
1. Sediakan 1 lembar daun salam
1. Siapkan 4 lembar daun jeruk
1. Sediakan 1 ruas jari lengkuas
1. Gunakan 1 buah sereh
1. Siapkan 1,5 sdt garam
1. Sediakan 1/2 sdt gula
1. Gunakan 1/2 sdt kunyit bubuk
1. Ambil 750 ml air
1. Siapkan 3 sdm minyak goreng




<!--inarticleads2-->

##### Cara menyiapkan Cakar Ayam Kuah Mercon:

1. Haluskan : bawang merah, bawang putih, cabai merah besar, cabai rawit dan tomat.
1. Cuci bersih cakar ayam, rebus dan tunggu hingga mendidih. Buang air rebusan pertama, kemudian rebus lagi cakar ayam dengan 750ml air sampai cakar empuk.
1. Panaskan minyak, tumis bumbu halus dan bumbu daun hingga wangi. Tambahkan garam, gula dan 1/2 sdt kunyit bubuk.
1. Setelah bumbu harum dan tanak, masukan cakar yang sudah direbus. Beri sedikit air sisa rebusan cakar. Koreksi rasa. Tunggu hingga air mendidih dan menyusut.
1. Cakar kuah mercon siap disajikan. Bisa dijadikan kuah untuk seblak mie ala-ala (tanpa kencur) seperti saya 😁




Ternyata resep cakar ayam kuah mercon yang nikamt tidak ribet ini enteng sekali ya! Kalian semua bisa mencobanya. Resep cakar ayam kuah mercon Sangat cocok sekali buat kita yang baru mau belajar memasak ataupun juga untuk anda yang telah ahli memasak.

Tertarik untuk mulai mencoba bikin resep cakar ayam kuah mercon mantab tidak rumit ini? Kalau anda mau, ayo kamu segera buruan siapkan alat dan bahannya, kemudian buat deh Resep cakar ayam kuah mercon yang mantab dan tidak rumit ini. Sangat mudah kan. 

Maka, daripada anda berlama-lama, ayo kita langsung buat resep cakar ayam kuah mercon ini. Dijamin kalian tak akan nyesel membuat resep cakar ayam kuah mercon nikmat tidak rumit ini! Selamat mencoba dengan resep cakar ayam kuah mercon nikmat simple ini di rumah kalian masing-masing,ya!.

