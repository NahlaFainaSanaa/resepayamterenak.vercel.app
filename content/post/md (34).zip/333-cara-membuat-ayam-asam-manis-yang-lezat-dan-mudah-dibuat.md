---
description: "Cara membuat Ayam asam manis yang lezat dan Mudah Dibuat"
title: "Cara membuat Ayam asam manis yang lezat dan Mudah Dibuat"
slug: 333-cara-membuat-ayam-asam-manis-yang-lezat-dan-mudah-dibuat
date: 2021-02-05T06:00:08.589Z
image: https://img-global.cpcdn.com/recipes/eb47500c82b48de5/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/eb47500c82b48de5/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/eb47500c82b48de5/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
author: Amanda Reynolds
ratingvalue: 4.2
reviewcount: 12
recipeingredient:
- "300 gr ayam fillet potong dadu"
- "100 gr tepung meizena"
- "Buah Nanas secukupnya"
- "secukupnya Cabe merah"
- "1 buah telur"
- " Paprika"
- "1 buah bawang bombay"
- "4 siung bawang putih cincang halus"
- " Gula"
- " Garam"
- " Bahan untuk marinasi "
- "1 sdm Minyak wijen"
- "1 sdm Gula"
- "2 sdm Kecap asin"
- " Bahan untuk membuat saos "
- "3 sdm Saos tomat sesuai selera"
- "1 sdm Cuka"
- "1 sdm Kecap manis"
- "secukupnya Gula pasir"
- "100 ml Air"
- "secukupnya Gula dan garam"
recipeinstructions:
- "Siapkan semua bahan kemudian, Ayam yang sudah di potong dadu masukkan ke dalam bumbu marinasi, kemudian diamkan selama 30 menit di dlm kulkas agar bumbu meresap."
- "Kemudian setelah 30 menit, tambahkan 1 butir telur kedalam ayam yg sdh di marinasi aduk rata, beri sedikit demi sedikit tepung maizena dan aduk rata"
- "Kemudian goreng ayam di minyak panas dengan api kecil, goreng hingga kecoklatan"
- "Buat saos : Tumis bawang putih dan bawang bombay, kemudian masukkan saos tomat, cabe, cuka, garam, gula, kecap manis, air secukupnya, paprika dan nanas"
- "Campurkan ayam dengan saos"
- "Siap disajikan"
categories:
- Resep
tags:
- ayam
- asam
- manis

katakunci: ayam asam manis 
nutrition: 101 calories
recipecuisine: Indonesian
preptime: "PT40M"
cooktime: "PT41M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam asam manis](https://img-global.cpcdn.com/recipes/eb47500c82b48de5/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg)

Selaku seorang istri, menyuguhkan olahan nikmat pada keluarga adalah hal yang sangat menyenangkan untuk kamu sendiri. Peran seorang ibu Tidak hanya mengerjakan pekerjaan rumah saja, tetapi kamu juga wajib menyediakan keperluan nutrisi tercukupi dan juga santapan yang dimakan anak-anak harus mantab.

Di zaman  saat ini, anda sebenarnya bisa membeli olahan instan meski tidak harus capek memasaknya terlebih dahulu. Tapi banyak juga orang yang memang ingin memberikan yang terbaik bagi orang tercintanya. Karena, menghidangkan masakan sendiri jauh lebih higienis dan bisa menyesuaikan masakan tersebut berdasarkan kesukaan keluarga tercinta. 



Mungkinkah kamu salah satu penikmat ayam asam manis?. Tahukah kamu, ayam asam manis merupakan makanan khas di Nusantara yang saat ini digemari oleh setiap orang di hampir setiap daerah di Indonesia. Kalian dapat memasak ayam asam manis kreasi sendiri di rumahmu dan dapat dijadikan camilan favorit di akhir pekan.

Anda tidak perlu bingung jika kamu ingin mendapatkan ayam asam manis, karena ayam asam manis sangat mudah untuk dicari dan anda pun bisa mengolahnya sendiri di tempatmu. ayam asam manis boleh dibuat memalui berbagai cara. Saat ini telah banyak cara kekinian yang menjadikan ayam asam manis semakin mantap.

Resep ayam asam manis pun gampang sekali dibuat, lho. Kalian tidak usah repot-repot untuk membeli ayam asam manis, lantaran Kita dapat menyiapkan ditempatmu. Bagi Kalian yang hendak menyajikannya, berikut resep membuat ayam asam manis yang lezat yang dapat Kita buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Ayam asam manis:

1. Gunakan 300 gr ayam fillet potong dadu
1. Siapkan 100 gr tepung meizena
1. Ambil Buah Nanas secukupnya
1. Siapkan secukupnya Cabe merah
1. Gunakan 1 buah telur
1. Ambil  Paprika
1. Siapkan 1 buah bawang bombay
1. Gunakan 4 siung bawang putih cincang halus
1. Siapkan  Gula
1. Sediakan  Garam
1. Ambil  Bahan untuk marinasi :
1. Ambil 1 sdm Minyak wijen
1. Gunakan 1 sdm Gula
1. Ambil 2 sdm Kecap asin
1. Ambil  Bahan untuk membuat saos :
1. Gunakan 3 sdm Saos tomat sesuai selera
1. Gunakan 1 sdm Cuka
1. Ambil 1 sdm Kecap manis
1. Siapkan secukupnya Gula pasir
1. Ambil 100 ml Air
1. Siapkan secukupnya Gula dan garam




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam asam manis:

1. Siapkan semua bahan kemudian, Ayam yang sudah di potong dadu masukkan ke dalam bumbu marinasi, kemudian diamkan selama 30 menit di dlm kulkas agar bumbu meresap.
1. Kemudian setelah 30 menit, tambahkan 1 butir telur kedalam ayam yg sdh di marinasi aduk rata, beri sedikit demi sedikit tepung maizena dan aduk rata
1. Kemudian goreng ayam di minyak panas dengan api kecil, goreng hingga kecoklatan
1. Buat saos : - Tumis bawang putih dan bawang bombay, kemudian masukkan saos tomat, cabe, cuka, garam, gula, kecap manis, air secukupnya, paprika dan nanas
1. Campurkan ayam dengan saos
1. Siap disajikan




Wah ternyata cara buat ayam asam manis yang lezat simple ini enteng banget ya! Kita semua bisa memasaknya. Resep ayam asam manis Sangat sesuai sekali buat anda yang baru mau belajar memasak maupun bagi kamu yang telah jago dalam memasak.

Apakah kamu ingin mencoba membikin resep ayam asam manis enak tidak rumit ini? Kalau tertarik, yuk kita segera buruan menyiapkan alat dan bahannya, kemudian buat deh Resep ayam asam manis yang mantab dan tidak rumit ini. Sungguh mudah kan. 

Oleh karena itu, ketimbang anda berfikir lama-lama, maka kita langsung bikin resep ayam asam manis ini. Dijamin kamu gak akan menyesal sudah membuat resep ayam asam manis nikmat tidak rumit ini! Selamat berkreasi dengan resep ayam asam manis nikmat sederhana ini di rumah kalian masing-masing,ya!.

