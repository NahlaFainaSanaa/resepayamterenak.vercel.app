---
description: "Cara buat Soto ayam santan kuning yang nikmat dan Mudah Dibuat"
title: "Cara buat Soto ayam santan kuning yang nikmat dan Mudah Dibuat"
slug: 394-cara-buat-soto-ayam-santan-kuning-yang-nikmat-dan-mudah-dibuat
date: 2021-07-02T03:26:19.331Z
image: https://img-global.cpcdn.com/recipes/ca4589d22a405c95/680x482cq70/soto-ayam-santan-kuning-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ca4589d22a405c95/680x482cq70/soto-ayam-santan-kuning-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ca4589d22a405c95/680x482cq70/soto-ayam-santan-kuning-foto-resep-utama.jpg
author: Julia Brock
ratingvalue: 4.3
reviewcount: 3
recipeingredient:
- "1 ekor ayam cuci bersih potong 8 atau sesuai selera"
- "1 btg seledri ikat simpul"
- "2 bks santan kara ukuran kecil"
- "2,5 lt air"
- "secukupnya Minyak"
- "  Bumbu dihaluskan"
- "4 siung bawang putih"
- "7 butir bawang merah"
- "1 ruas jahe"
- "1 ruas kunyit"
- "7 butir kemiri"
- "1 Sm ketumbar bubuk"
- "1/2 st lada bubuk"
- "  rempah daun"
- "1 ruas Laos geprek"
- "2 btg serai geprek"
- "7 lbr daun jeruk"
- "4 lbr daun salam"
- "  penyedap"
- "2 bks kaldu ayam"
- "1 Sm penyedap"
- "2 SM gula pasir"
- "1 St garam sesuai selera"
- " pelengkap"
- " Telor rebus"
- " Kentang goreng"
- " Tauge kol opsional"
- "4 btg daun bawang iris UK 1cm"
- " Kerupuk  emping opsional"
- " Jeruk nipis lemon limo"
- " Bawang goreng"
- " Sambal"
- " Kecap manis"
recipeinstructions:
- "Didihkan air dan tambahkan serai, dan daun salam, kemudian ambil 1/2 liter air yg sudah mendidih ke panci yg agak kecil dan rebus daging ayamnya sampai berbuih dan sisihkan, dan buang airnya."
- "Panaskan wajan dgn 5 SM minyak dan tumis semua bumbu halusnya sampai wangi dan tambahkan daun jeruk, Laos, lalu masukan daging ayamnya sambil terus diaduk rata biarkan bbrp saat sampai bumbu meresap di daging ayam, matikan api."
- "Tuang bumbu dan ayamnya kedalam panci kuah dan masak sampai ayam matang, dan angkat ayamnya lalu tambahkan semua bumbu penyedap, daun seledri dan terakhir tambahkan 2 bks santan kara, icip rasa aduk sesekali Sampai mendidih dan matikan api."
- "Ayamnya opsional ya, mau digoreng lagi atau tdk."
- "Soto ayam siap disajikan dgn pelengkapnya."
categories:
- Resep
tags:
- soto
- ayam
- santan

katakunci: soto ayam santan 
nutrition: 122 calories
recipecuisine: Indonesian
preptime: "PT25M"
cooktime: "PT32M"
recipeyield: "1"
recipecategory: Dessert

---


![Soto ayam santan kuning](https://img-global.cpcdn.com/recipes/ca4589d22a405c95/680x482cq70/soto-ayam-santan-kuning-foto-resep-utama.jpg)

Sebagai seorang yang hobi memasak, menyediakan olahan enak bagi keluarga adalah suatu hal yang mengasyikan untuk kamu sendiri. Peran seorang  wanita bukan hanya mengatur rumah saja, tapi kamu pun wajib menyediakan keperluan nutrisi tercukupi dan juga masakan yang dimakan orang tercinta mesti enak.

Di zaman  saat ini, kamu memang mampu membeli panganan praktis tidak harus capek mengolahnya dahulu. Tetapi banyak juga lho mereka yang memang ingin memberikan yang terenak bagi orang yang dicintainya. Karena, menyajikan masakan sendiri jauh lebih bersih dan bisa menyesuaikan makanan tersebut berdasarkan selera orang tercinta. 



Mungkinkah kamu seorang penggemar soto ayam santan kuning?. Tahukah kamu, soto ayam santan kuning merupakan makanan khas di Indonesia yang saat ini digemari oleh banyak orang dari hampir setiap wilayah di Indonesia. Anda dapat menghidangkan soto ayam santan kuning buatan sendiri di rumahmu dan dapat dijadikan hidangan kesukaanmu di hari libur.

Anda tidak perlu bingung jika kamu ingin mendapatkan soto ayam santan kuning, karena soto ayam santan kuning mudah untuk dicari dan kita pun boleh memasaknya sendiri di rumah. soto ayam santan kuning boleh dibuat lewat bermacam cara. Sekarang telah banyak banget resep kekinian yang menjadikan soto ayam santan kuning semakin lebih nikmat.

Resep soto ayam santan kuning pun sangat mudah untuk dibuat, lho. Kalian jangan ribet-ribet untuk membeli soto ayam santan kuning, sebab Anda dapat menghidangkan di rumah sendiri. Untuk Kita yang hendak mencobanya, dibawah ini merupakan resep untuk membuat soto ayam santan kuning yang enak yang bisa Kamu hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Soto ayam santan kuning:

1. Siapkan 1 ekor ayam cuci bersih potong 8 atau sesuai selera
1. Siapkan 1 btg seledri ikat simpul
1. Siapkan 2 bks santan kara ukuran kecil
1. Siapkan 2,5 lt air
1. Gunakan secukupnya Minyak
1. Ambil  ☘️☘️ Bumbu dihaluskan
1. Siapkan 4 siung bawang putih
1. Gunakan 7 butir bawang merah
1. Gunakan 1 ruas jahe
1. Gunakan 1 ruas kunyit
1. Gunakan 7 butir kemiri
1. Ambil 1 Sm ketumbar bubuk
1. Gunakan 1/2 st lada bubuk
1. Siapkan  🌸🌸 rempah daun
1. Ambil 1 ruas Laos geprek
1. Sediakan 2 btg serai geprek
1. Ambil 7 lbr daun jeruk
1. Gunakan 4 lbr daun salam
1. Ambil  🌺🌺 penyedap
1. Sediakan 2 bks kaldu ayam
1. Sediakan 1 Sm penyedap
1. Siapkan 2 SM gula pasir
1. Sediakan 1 St garam (sesuai selera)
1. Ambil  🍋🍋🍋pelengkap
1. Gunakan  Telor rebus
1. Siapkan  Kentang goreng
1. Siapkan  Tauge/ kol (opsional)
1. Sediakan 4 btg daun bawang iris UK 1cm
1. Gunakan  Kerupuk / emping (opsional)
1. Gunakan  Jeruk nipis/ lemon/ limo
1. Ambil  Bawang goreng
1. Sediakan  Sambal
1. Siapkan  Kecap manis




<!--inarticleads2-->

##### Cara membuat Soto ayam santan kuning:

1. Didihkan air dan tambahkan serai, dan daun salam, kemudian ambil 1/2 liter air yg sudah mendidih ke panci yg agak kecil dan rebus daging ayamnya sampai berbuih dan sisihkan, dan buang airnya.
1. Panaskan wajan dgn 5 SM minyak dan tumis semua bumbu halusnya sampai wangi dan tambahkan daun jeruk, Laos, lalu masukan daging ayamnya sambil terus diaduk rata biarkan bbrp saat sampai bumbu meresap di daging ayam, matikan api.
1. Tuang bumbu dan ayamnya kedalam panci kuah dan masak sampai ayam matang, dan angkat ayamnya lalu tambahkan semua bumbu penyedap, daun seledri dan terakhir tambahkan 2 bks santan kara, icip rasa aduk sesekali Sampai mendidih dan matikan api.
1. Ayamnya opsional ya, mau digoreng lagi atau tdk.
1. Soto ayam siap disajikan dgn pelengkapnya.




Ternyata cara membuat soto ayam santan kuning yang enak sederhana ini gampang sekali ya! Kita semua bisa mencobanya. Resep soto ayam santan kuning Cocok sekali buat kalian yang baru belajar memasak maupun juga bagi kamu yang sudah ahli memasak.

Apakah kamu ingin mulai mencoba bikin resep soto ayam santan kuning lezat tidak rumit ini? Kalau tertarik, ayo kalian segera siapin peralatan dan bahan-bahannya, lalu buat deh Resep soto ayam santan kuning yang mantab dan tidak rumit ini. Benar-benar taidak sulit kan. 

Maka dari itu, ketimbang kamu berlama-lama, yuk kita langsung bikin resep soto ayam santan kuning ini. Dijamin anda tiidak akan menyesal sudah buat resep soto ayam santan kuning mantab simple ini! Selamat mencoba dengan resep soto ayam santan kuning enak sederhana ini di rumah masing-masing,oke!.

