---
description: "Resep Ayam asam manis yang nikmat dan Mudah Dibuat"
title: "Resep Ayam asam manis yang nikmat dan Mudah Dibuat"
slug: 340-resep-ayam-asam-manis-yang-nikmat-dan-mudah-dibuat
date: 2021-03-30T08:31:45.789Z
image: https://img-global.cpcdn.com/recipes/063fe4d71b111a91/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/063fe4d71b111a91/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/063fe4d71b111a91/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
author: Ronald McCormick
ratingvalue: 4.9
reviewcount: 11
recipeingredient:
- "1/2 kg dada ayam fillet"
- "1 sct tepung bumbu serbaguna akoh pake merk Sasa uk225gr"
- "secukupnya Air es"
- " Minyak untuk menggoreng"
- " Saos asam manis"
- "2 Sdm Margarin"
- "1/4 buah bawang bombai"
- "3 Sdm saos tomat"
- "4 Sdm gula pasir"
- "500 ml air"
- "secukupnya Garam lada bubuk"
- "1 buah tomat"
- "1 sdm maizena"
recipeinstructions:
- "Potong kecil ayam,"
- "Siakan tepung bumbu Sasa. Ambil 4 Sdm lalu tambahkan air es sedikit. (Adonan kental). Lalu masukkan ayam. Aduk rata. Diamkan 15 menit"
- "Sambil menunggu marinasi ayam. Buat saos asam manisnya."
- "Panaskan teflon, masukkan margarin. Lalu tumis bawang bombai hingga harum"
- "Tambahkan saos tomat aduk rata. Lalu tambahkan air. Biarkan mendidih"
- "Tambahkan garam,gula, lada. Aduk rata."
- "Larutkan maizena dengan sedikit air. Tuang kedalam saos"
- "Terakhir tambahkan irisan tomat. Aduk, tes rasa dan Sisihkan"
- "Panaskan minyak untuk menggoreng"
- "Siapkan wadah, tuang tepung Sasa kering"
- "Ambil ayam, balurkan dengan tepung kering."
- "Cubit ayam. Lalu goreng dengan api kecil hingga kuning keemasan. (Minyak harus merendam ayam)"
- "Ayam goreng siap disajikan dengan saos asam manis. Klo akoh lebih suka saosnya dipisah aja kaya gini. Nanti kalo mau makan baru di ruang saos. Biar tetep ada sensasi kriuk dr ayam nya,. Selamat mencoba..."
categories:
- Resep
tags:
- ayam
- asam
- manis

katakunci: ayam asam manis 
nutrition: 133 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT45M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam asam manis](https://img-global.cpcdn.com/recipes/063fe4d71b111a91/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg)

Selaku seorang ibu, menyediakan panganan lezat pada keluarga merupakan suatu hal yang mengasyikan untuk anda sendiri. Kewajiban seorang istri Tidak sekedar mengurus rumah saja, namun kamu juga harus menyediakan keperluan gizi tercukupi dan juga santapan yang dimakan orang tercinta mesti lezat.

Di masa  saat ini, kamu sebenarnya dapat memesan hidangan yang sudah jadi walaupun tanpa harus ribet memasaknya dahulu. Tapi ada juga mereka yang memang ingin memberikan makanan yang terenak bagi orang tercintanya. Sebab, menyajikan masakan yang diolah sendiri akan jauh lebih bersih dan bisa menyesuaikan hidangan tersebut berdasarkan makanan kesukaan keluarga tercinta. 



Mungkinkah anda merupakan seorang penggemar ayam asam manis?. Asal kamu tahu, ayam asam manis merupakan sajian khas di Indonesia yang kini disenangi oleh setiap orang dari hampir setiap daerah di Indonesia. Anda dapat menyajikan ayam asam manis sendiri di rumah dan dapat dijadikan makanan favorit di hari libur.

Kalian tak perlu bingung untuk mendapatkan ayam asam manis, sebab ayam asam manis mudah untuk dicari dan kita pun boleh menghidangkannya sendiri di tempatmu. ayam asam manis bisa dibuat lewat bermacam cara. Saat ini sudah banyak resep modern yang membuat ayam asam manis semakin mantap.

Resep ayam asam manis pun gampang untuk dibikin, lho. Anda tidak usah capek-capek untuk memesan ayam asam manis, tetapi Anda bisa menghidangkan ditempatmu. Untuk Kalian yang akan membuatnya, berikut ini cara membuat ayam asam manis yang mantab yang dapat Kalian coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Ayam asam manis:

1. Sediakan 1/2 kg dada ayam fillet
1. Siapkan 1 sct tepung bumbu serbaguna (akoh pake merk Sasa uk.225gr)
1. Ambil secukupnya Air es
1. Ambil  Minyak untuk menggoreng
1. Ambil  Saos asam manis
1. Siapkan 2 Sdm Margarin
1. Ambil 1/4 buah bawang bombai
1. Gunakan 3 Sdm saos tomat
1. Gunakan 4 Sdm gula pasir
1. Ambil 500 ml air
1. Ambil secukupnya Garam, lada bubuk
1. Ambil 1 buah tomat
1. Siapkan 1 sdm maizena




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam asam manis:

1. Potong kecil ayam,
1. Siakan tepung bumbu Sasa. Ambil 4 Sdm lalu tambahkan air es sedikit. (Adonan kental). Lalu masukkan ayam. Aduk rata. Diamkan 15 menit
1. Sambil menunggu marinasi ayam. Buat saos asam manisnya.
1. Panaskan teflon, masukkan margarin. Lalu tumis bawang bombai hingga harum
1. Tambahkan saos tomat aduk rata. Lalu tambahkan air. Biarkan mendidih
1. Tambahkan garam,gula, lada. Aduk rata.
1. Larutkan maizena dengan sedikit air. Tuang kedalam saos
1. Terakhir tambahkan irisan tomat. Aduk, tes rasa dan Sisihkan
1. Panaskan minyak untuk menggoreng
1. Siapkan wadah, tuang tepung Sasa kering
1. Ambil ayam, balurkan dengan tepung kering.
1. Cubit ayam. Lalu goreng dengan api kecil hingga kuning keemasan. (Minyak harus merendam ayam)
1. Ayam goreng siap disajikan dengan saos asam manis. Klo akoh lebih suka saosnya dipisah aja kaya gini. Nanti kalo mau makan baru di ruang saos. Biar tetep ada sensasi kriuk dr ayam nya,. Selamat mencoba...




Ternyata cara buat ayam asam manis yang enak sederhana ini enteng sekali ya! Semua orang dapat mencobanya. Cara Membuat ayam asam manis Sangat sesuai sekali untuk kalian yang baru akan belajar memasak ataupun untuk anda yang telah lihai memasak.

Apakah kamu mau mencoba buat resep ayam asam manis enak tidak ribet ini? Kalau kamu tertarik, mending kamu segera buruan siapkan peralatan dan bahannya, lantas buat deh Resep ayam asam manis yang mantab dan sederhana ini. Sangat mudah kan. 

Maka dari itu, daripada kamu diam saja, maka langsung aja bikin resep ayam asam manis ini. Dijamin anda tak akan nyesel bikin resep ayam asam manis enak tidak rumit ini! Selamat berkreasi dengan resep ayam asam manis enak simple ini di tempat tinggal kalian masing-masing,oke!.

