---
description: "Bahan-bahan Soto Ayam Santan Kara yang nikmat Untuk Jualan"
title: "Bahan-bahan Soto Ayam Santan Kara yang nikmat Untuk Jualan"
slug: 381-bahan-bahan-soto-ayam-santan-kara-yang-nikmat-untuk-jualan
date: 2021-01-28T02:39:37.423Z
image: https://img-global.cpcdn.com/recipes/ce035c1b05f624ad/680x482cq70/soto-ayam-santan-kara-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ce035c1b05f624ad/680x482cq70/soto-ayam-santan-kara-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ce035c1b05f624ad/680x482cq70/soto-ayam-santan-kara-foto-resep-utama.jpg
author: Lola Pierce
ratingvalue: 3.3
reviewcount: 14
recipeingredient:
- "1/2 ekor ayam"
- " Isian soto kol tauge tomat kentang jeruk nipis emping"
- " Bumbu halus"
- "10 siung bawang merah"
- "5 siung bawang putih"
- "3 buah kemiri"
- "1 ruas kunyit"
- "1 ruas jahe"
- "1 sdt ketumbar"
- "1 sdt lada"
- "1 sdt jinten"
- "1 gelas kecil air"
- " Bumbu Cemplung"
- "1 liter air"
- "2 lembar daun salam"
- "3 lembar daun jeruk"
- "1 serai digeprek"
- "1 ruas lengkuas digeprek"
- "1/4 bulatan biji pala"
- "3 buah bunga"
- "secukupnya Daun bawang"
- "1 sachet santan kara kecil"
- "secukupnya Gula msg Royco"
recipeinstructions:
- "Blender semua bumbu halus, kemudian tumis sampai air menyusut dan bumbu keluar minyak dan benar2 matang"
- "Cuci bersih ayam, potong2. Panaskan panci masukkan semua bumbu Cemplung (kecuali santan dan daun bawang) beserta ayam, dan masukkan bumbu halus yg sudah ditumis tadi. Bila ayam sudah setengah matang angkat lalu goreng ayam. Sisihkan suwir2"
- "Masukkan santan ke dalam panci tunggu sampai mendidih sambil diaduk2. Koreksi rasa, masukkan daun bawang dan jadi deh."
- "Potong2 isian soto, rebus tauge, dan goreng kentang (empingnya lupa di foto)"
- "Cara buat sambal: 31 cabe rawit direbus, ulek dengan msg kasih beberapa tetes jeruk nipis. (Ga perlu dikasih garam)"
categories:
- Resep
tags:
- soto
- ayam
- santan

katakunci: soto ayam santan 
nutrition: 266 calories
recipecuisine: Indonesian
preptime: "PT33M"
cooktime: "PT52M"
recipeyield: "4"
recipecategory: Lunch

---


![Soto Ayam Santan Kara](https://img-global.cpcdn.com/recipes/ce035c1b05f624ad/680x482cq70/soto-ayam-santan-kara-foto-resep-utama.jpg)

Jika kalian seorang istri, mempersiapkan olahan lezat bagi keluarga merupakan hal yang sangat menyenangkan untuk anda sendiri. Kewajiban seorang istri Tidak cuman menjaga rumah saja, namun anda juga wajib memastikan keperluan nutrisi tercukupi dan juga olahan yang dimakan anak-anak harus menggugah selera.

Di masa  saat ini, anda memang bisa memesan santapan praktis tanpa harus capek mengolahnya dahulu. Namun ada juga orang yang memang ingin menghidangkan yang terenak bagi keluarganya. Pasalnya, menyajikan masakan yang dibuat sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan makanan tersebut sesuai dengan selera keluarga tercinta. 



Apakah anda seorang penyuka soto ayam santan kara?. Tahukah kamu, soto ayam santan kara merupakan sajian khas di Nusantara yang sekarang disenangi oleh orang-orang di hampir setiap tempat di Nusantara. Kalian bisa menyajikan soto ayam santan kara buatan sendiri di rumahmu dan boleh dijadikan hidangan kesukaanmu di akhir pekan.

Anda tak perlu bingung jika kamu ingin mendapatkan soto ayam santan kara, sebab soto ayam santan kara gampang untuk didapatkan dan juga kamu pun dapat memasaknya sendiri di tempatmu. soto ayam santan kara dapat dimasak dengan bermacam cara. Kini sudah banyak sekali resep kekinian yang membuat soto ayam santan kara semakin lebih enak.

Resep soto ayam santan kara pun mudah sekali untuk dibuat, lho. Kalian tidak usah capek-capek untuk memesan soto ayam santan kara, sebab Anda bisa membuatnya di rumah sendiri. Untuk Anda yang ingin menyajikannya, berikut ini cara menyajikan soto ayam santan kara yang enak yang mampu Kalian coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Soto Ayam Santan Kara:

1. Gunakan 1/2 ekor ayam
1. Gunakan  Isian soto: kol, tauge, tomat, kentang, jeruk nipis, emping
1. Siapkan  Bumbu halus:
1. Sediakan 10 siung bawang merah
1. Gunakan 5 siung bawang putih
1. Sediakan 3 buah kemiri
1. Sediakan 1 ruas kunyit
1. Siapkan 1 ruas jahe
1. Siapkan 1 sdt ketumbar
1. Sediakan 1 sdt lada
1. Gunakan 1 sdt jinten
1. Sediakan 1 gelas kecil air
1. Gunakan  Bumbu Cemplung:
1. Siapkan 1 liter air
1. Sediakan 2 lembar daun salam
1. Ambil 3 lembar daun jeruk
1. Ambil 1 serai digeprek
1. Siapkan 1 ruas lengkuas digeprek
1. Ambil 1/4 bulatan biji pala
1. Sediakan 3 buah bunga
1. Gunakan secukupnya Daun bawang
1. Ambil 1 sachet santan kara kecil
1. Gunakan secukupnya Gula, msg, Royco




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Soto Ayam Santan Kara:

1. Blender semua bumbu halus, kemudian tumis sampai air menyusut dan bumbu keluar minyak dan benar2 matang
1. Cuci bersih ayam, potong2. Panaskan panci masukkan semua bumbu Cemplung (kecuali santan dan daun bawang) beserta ayam, dan masukkan bumbu halus yg sudah ditumis tadi. Bila ayam sudah setengah matang angkat lalu goreng ayam. Sisihkan suwir2
1. Masukkan santan ke dalam panci tunggu sampai mendidih sambil diaduk2. Koreksi rasa, masukkan daun bawang dan jadi deh.
1. Potong2 isian soto, rebus tauge, dan goreng kentang (empingnya lupa di foto)
1. Cara buat sambal: 31 cabe rawit direbus, ulek dengan msg kasih beberapa tetes jeruk nipis. (Ga perlu dikasih garam)




Wah ternyata resep soto ayam santan kara yang lezat tidak rumit ini gampang banget ya! Anda Semua mampu memasaknya. Cara Membuat soto ayam santan kara Sesuai banget untuk kamu yang baru akan belajar memasak maupun juga untuk anda yang sudah hebat dalam memasak.

Tertarik untuk mulai mencoba bikin resep soto ayam santan kara lezat tidak rumit ini? Kalau ingin, yuk kita segera menyiapkan peralatan dan bahannya, setelah itu buat deh Resep soto ayam santan kara yang nikmat dan sederhana ini. Sangat mudah kan. 

Oleh karena itu, ketimbang kalian diam saja, hayo kita langsung sajikan resep soto ayam santan kara ini. Dijamin kamu gak akan menyesal bikin resep soto ayam santan kara nikmat tidak rumit ini! Selamat berkreasi dengan resep soto ayam santan kara nikmat simple ini di tempat tinggal kalian masing-masing,oke!.

