---
description: "Resep Ayam Lodho khas Tulungagung yang enak Untuk Jualan"
title: "Resep Ayam Lodho khas Tulungagung yang enak Untuk Jualan"
slug: 220-resep-ayam-lodho-khas-tulungagung-yang-enak-untuk-jualan
date: 2021-03-23T12:13:32.086Z
image: https://img-global.cpcdn.com/recipes/9828fef0f34576fb/680x482cq70/ayam-lodho-khas-tulungagung-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9828fef0f34576fb/680x482cq70/ayam-lodho-khas-tulungagung-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9828fef0f34576fb/680x482cq70/ayam-lodho-khas-tulungagung-foto-resep-utama.jpg
author: Gregory Lewis
ratingvalue: 4.1
reviewcount: 7
recipeingredient:
- "1 ekor bakaran ayam potongayam kampung skitar berat 15kg"
- "7 lembar daun jeruk"
- "10 lembar daun salam"
- "4 cm lengkuas di geprek"
- "400 mL santan kanilkental dri 6plastik kelapa parut"
- "800 mL santan cair sisan perasan santan kanil"
- " Bumbu Halus"
- "25 bawang merah pakai bnyak biar enak"
- "10 bawah putih"
- "1 sdt merica"
- "1 sdm ketumbar"
- "2 sdm garam bsa lebih"
- "1 sdm gula bsa lebih"
- "2 ruas jahe skitar 23 cm"
- "4 ruas kunyit skitar 45cm"
- "15 cabe rawit bsa lebih"
recipeinstructions:
- "Potong ayam bakaran menjadi beberapa bagian lalu cuci bersih dan sisihkan. Jika tidak ada ayam bakaran maka bsa bakar sndiri sbelum dimasak. Karena yg bkin beda adalah ayam yg sudah dibakar asap ini"
- "Siapkan bumbu halus (selain garam, gula, merica, ketumbar) lalu goreng hingga matang. Kemudian haluskan dgn uleg/bsa blender bersama dgn garam, gula, merica dan ketumbar. Sisihkan"
- "Peras parutan kelapa dgn membedakan santan kanil dan santan encer, aku pakai 5 plastik kelapa jdi gak perlu marut sndiri atau setara 1 buah kelapa klo pngen marut sndiri."
- "Masukkan ayam dalam kompor. Lalu masukkan santan cair, daun jeruk dan salam. Masak hingga mendidih dlu. Kmudian msukkan bumbu halus dan aduk2. Masak hingga mendidih lgi smbil sesekali diaduk, sampai ayam mulai empuk dan bumbu meresap (skitar 30menitan)."
- "Lalu masukkan santan kanil sedikit, aduk2 dan tunggu mendidih, masukkan santan kanil sedikit lgi, aduk lagi dan terus ulangi smpai smua santan kanil masuk smua. Tujuannya supaya bumbu meresap sempurna."
- "Tutup wajan dan masak sambil diaduk2 sesekali hingga santan kanil dan bumbu menyatu, jangan lupa koreksi rasa jika kurang bsa tambahkan gula dan garam ya."
- "Jika bumbu sudah meresap ke ayam, matikan dan siap disajikaann dgn nasi hangat atau nasi guriihhh😍❤ wuenaakk tenannn"
- "Ket: Bisa jga pakai santan kara tpi kalo pakai santan kara brarti ayam bakarannya direbus pakai air, daun salam dan daun jeruk, lalu masukkan bumbu lalu, aduk rata, baru 4 plastik santan karanya dimasukkan."
categories:
- Resep
tags:
- ayam
- lodho
- khas

katakunci: ayam lodho khas 
nutrition: 188 calories
recipecuisine: Indonesian
preptime: "PT23M"
cooktime: "PT43M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam Lodho khas Tulungagung](https://img-global.cpcdn.com/recipes/9828fef0f34576fb/680x482cq70/ayam-lodho-khas-tulungagung-foto-resep-utama.jpg)

Selaku seorang orang tua, mempersiapkan hidangan lezat buat keluarga adalah hal yang sangat menyenangkan untuk anda sendiri. Tugas seorang istri bukan sekadar mengurus rumah saja, tapi kamu pun harus memastikan keperluan gizi terpenuhi dan juga hidangan yang dikonsumsi keluarga tercinta wajib nikmat.

Di era  sekarang, anda sebenarnya mampu memesan panganan jadi tidak harus repot mengolahnya lebih dulu. Namun banyak juga lho mereka yang selalu ingin memberikan hidangan yang terbaik untuk keluarganya. Sebab, menyajikan masakan yang diolah sendiri akan jauh lebih bersih dan bisa menyesuaikan makanan tersebut sesuai kesukaan keluarga tercinta. 



Apakah anda merupakan seorang penyuka ayam lodho khas tulungagung?. Asal kamu tahu, ayam lodho khas tulungagung adalah hidangan khas di Indonesia yang kini disukai oleh kebanyakan orang dari hampir setiap wilayah di Nusantara. Kalian dapat menyajikan ayam lodho khas tulungagung buatan sendiri di rumahmu dan boleh dijadikan makanan kesukaanmu di akhir pekanmu.

Kamu tak perlu bingung jika kamu ingin memakan ayam lodho khas tulungagung, sebab ayam lodho khas tulungagung sangat mudah untuk didapatkan dan kalian pun boleh membuatnya sendiri di rumah. ayam lodho khas tulungagung dapat diolah lewat bermacam cara. Sekarang ada banyak banget cara modern yang membuat ayam lodho khas tulungagung semakin lebih enak.

Resep ayam lodho khas tulungagung pun mudah untuk dibikin, lho. Anda tidak usah ribet-ribet untuk memesan ayam lodho khas tulungagung, karena Kita bisa menyiapkan di rumah sendiri. Bagi Kita yang hendak menyajikannya, berikut ini resep untuk menyajikan ayam lodho khas tulungagung yang lezat yang bisa Kalian coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Ayam Lodho khas Tulungagung:

1. Ambil 1 ekor bakaran ayam potong/ayam kampung (skitar berat 1,5kg)
1. Gunakan 7 lembar daun jeruk
1. Siapkan 10 lembar daun salam
1. Siapkan 4 cm lengkuas di geprek
1. Sediakan 400 mL santan kanil/kental (dri 6plastik kelapa parut)
1. Sediakan 800 mL santan cair (sisan perasan santan kanil)
1. Sediakan  Bumbu Halus:
1. Ambil 25 bawang merah (pakai bnyak biar enak)
1. Siapkan 10 bawah putih
1. Sediakan 1 sdt merica
1. Ambil 1 sdm ketumbar
1. Gunakan 2 sdm garam bsa lebih
1. Ambil 1 sdm gula bsa lebih
1. Ambil 2 ruas jahe (skitar 2-3 cm)
1. Ambil 4 ruas kunyit (skitar 4-5cm)
1. Sediakan 15 cabe rawit bsa lebih




<!--inarticleads2-->

##### Cara membuat Ayam Lodho khas Tulungagung:

1. Potong ayam bakaran menjadi beberapa bagian lalu cuci bersih dan sisihkan. Jika tidak ada ayam bakaran maka bsa bakar sndiri sbelum dimasak. Karena yg bkin beda adalah ayam yg sudah dibakar asap ini
1. Siapkan bumbu halus (selain garam, gula, merica, ketumbar) lalu goreng hingga matang. Kemudian haluskan dgn uleg/bsa blender bersama dgn garam, gula, merica dan ketumbar. Sisihkan
1. Peras parutan kelapa dgn membedakan santan kanil dan santan encer, aku pakai 5 plastik kelapa jdi gak perlu marut sndiri atau setara 1 buah kelapa klo pngen marut sndiri.
1. Masukkan ayam dalam kompor. Lalu masukkan santan cair, daun jeruk dan salam. Masak hingga mendidih dlu. Kmudian msukkan bumbu halus dan aduk2. Masak hingga mendidih lgi smbil sesekali diaduk, sampai ayam mulai empuk dan bumbu meresap (skitar 30menitan).
1. Lalu masukkan santan kanil sedikit, aduk2 dan tunggu mendidih, masukkan santan kanil sedikit lgi, aduk lagi dan terus ulangi smpai smua santan kanil masuk smua. Tujuannya supaya bumbu meresap sempurna.
1. Tutup wajan dan masak sambil diaduk2 sesekali hingga santan kanil dan bumbu menyatu, jangan lupa koreksi rasa jika kurang bsa tambahkan gula dan garam ya.
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Ayam Lodho khas Tulungagung">1. Jika bumbu sudah meresap ke ayam, matikan dan siap disajikaann dgn nasi hangat atau nasi guriihhh😍❤ wuenaakk tenannn
1. Ket: Bisa jga pakai santan kara tpi kalo pakai santan kara brarti ayam bakarannya direbus pakai air, daun salam dan daun jeruk, lalu masukkan bumbu lalu, aduk rata, baru 4 plastik santan karanya dimasukkan.




Ternyata resep ayam lodho khas tulungagung yang lezat simple ini enteng sekali ya! Kita semua mampu mencobanya. Resep ayam lodho khas tulungagung Sangat sesuai banget untuk kamu yang baru akan belajar memasak ataupun juga bagi kamu yang telah ahli dalam memasak.

Apakah kamu ingin mulai mencoba membikin resep ayam lodho khas tulungagung nikmat sederhana ini? Kalau anda mau, yuk kita segera buruan siapkan alat dan bahan-bahannya, lantas buat deh Resep ayam lodho khas tulungagung yang lezat dan sederhana ini. Benar-benar gampang kan. 

Oleh karena itu, daripada kamu berlama-lama, hayo kita langsung sajikan resep ayam lodho khas tulungagung ini. Dijamin kamu tak akan menyesal bikin resep ayam lodho khas tulungagung enak simple ini! Selamat mencoba dengan resep ayam lodho khas tulungagung lezat tidak ribet ini di rumah kalian masing-masing,ya!.

