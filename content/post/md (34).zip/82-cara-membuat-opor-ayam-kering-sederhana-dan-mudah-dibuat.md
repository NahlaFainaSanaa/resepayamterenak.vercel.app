---
description: "Cara membuat Opor Ayam Kering Sederhana dan Mudah Dibuat"
title: "Cara membuat Opor Ayam Kering Sederhana dan Mudah Dibuat"
slug: 82-cara-membuat-opor-ayam-kering-sederhana-dan-mudah-dibuat
date: 2021-06-21T01:04:59.355Z
image: https://img-global.cpcdn.com/recipes/215d9202f76fecf5/680x482cq70/opor-ayam-kering-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/215d9202f76fecf5/680x482cq70/opor-ayam-kering-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/215d9202f76fecf5/680x482cq70/opor-ayam-kering-foto-resep-utama.jpg
author: Myrtle Bell
ratingvalue: 4.8
reviewcount: 7
recipeingredient:
- "1 ekor ayam saya potong 8           lihat tips"
- "3 sdm bumbu dasar kuning           lihat resep"
- "300 ml air"
- "1 sachet santan kental 65ml"
- "2 lembar daun salam"
- "2 lembar daun jeruk           lihat tips"
- "1 batang sereh"
- "2 cm lengkuas"
- "7 buah cabe rawit utuh           lihat tips"
- "secukupnya Garam kaldu dan gula"
recipeinstructions:
- "Rebus ayam, 7-8 menit. Lalu matikan kompor. Tutup panci 30 jangan dibuka. Bair ayam empuk.  Lalu goreng ayam, tidak usah sampai garing."
- "Tumis bumbu dasar kuning bersama daun dalam, daun jeruk, sereh dan lengkuas. Masak hingga harum, masukkan ayam dan air. Aduk rata"
- "Biarkan air agak menyusut,  Jika sudah menyusut, masukkan santan kental dan cabe. Aduk rata, tambahkan garam, gula dan kaldu. Koreksi rasa Sajikan selagi hangat dengan nasi hangat"
categories:
- Resep
tags:
- opor
- ayam
- kering

katakunci: opor ayam kering 
nutrition: 163 calories
recipecuisine: Indonesian
preptime: "PT34M"
cooktime: "PT57M"
recipeyield: "4"
recipecategory: Lunch

---


![Opor Ayam Kering](https://img-global.cpcdn.com/recipes/215d9202f76fecf5/680x482cq70/opor-ayam-kering-foto-resep-utama.jpg)

Sebagai seorang wanita, menyuguhkan santapan menggugah selera bagi keluarga tercinta merupakan hal yang memuaskan untuk kita sendiri. Peran seorang ibu bukan hanya menjaga rumah saja, tetapi kamu pun wajib menyediakan kebutuhan nutrisi terpenuhi dan olahan yang dikonsumsi anak-anak wajib sedap.

Di era  saat ini, kita sebenarnya mampu mengorder panganan praktis tanpa harus susah memasaknya terlebih dahulu. Tapi ada juga lho mereka yang memang ingin menghidangkan yang terbaik bagi orang tercintanya. Karena, menyajikan masakan sendiri jauh lebih higienis dan kita pun bisa menyesuaikan hidangan tersebut sesuai dengan selera keluarga. 



Apakah anda adalah salah satu penyuka opor ayam kering?. Asal kamu tahu, opor ayam kering merupakan sajian khas di Nusantara yang kini disukai oleh setiap orang dari hampir setiap tempat di Nusantara. Kamu dapat memasak opor ayam kering sendiri di rumah dan pasti jadi makanan favoritmu di akhir pekan.

Kamu tidak perlu bingung untuk memakan opor ayam kering, karena opor ayam kering mudah untuk didapatkan dan anda pun boleh menghidangkannya sendiri di tempatmu. opor ayam kering bisa dibuat memalui berbagai cara. Saat ini sudah banyak resep modern yang membuat opor ayam kering semakin mantap.

Resep opor ayam kering juga mudah sekali untuk dibikin, lho. Kamu jangan repot-repot untuk memesan opor ayam kering, lantaran Anda dapat membuatnya sendiri di rumah. Bagi Anda yang mau menghidangkannya, berikut ini cara untuk menyajikan opor ayam kering yang enak yang dapat Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Opor Ayam Kering:

1. Ambil 1 ekor ayam, saya potong 8           (lihat tips)
1. Sediakan 3 sdm bumbu dasar kuning           (lihat resep)
1. Ambil 300 ml air
1. Gunakan 1 sachet santan kental 65ml
1. Sediakan 2 lembar daun salam
1. Siapkan 2 lembar daun jeruk           (lihat tips)
1. Sediakan 1 batang sereh
1. Siapkan 2 cm lengkuas
1. Sediakan 7 buah cabe rawit utuh           (lihat tips)
1. Gunakan secukupnya Garam, kaldu dan gula




<!--inarticleads2-->

##### Cara membuat Opor Ayam Kering:

1. Rebus ayam, 7-8 menit. Lalu matikan kompor. Tutup panci 30 jangan dibuka. Bair ayam empuk.  - Lalu goreng ayam, tidak usah sampai garing.
1. Tumis bumbu dasar kuning bersama daun dalam, daun jeruk, sereh dan lengkuas. Masak hingga harum, masukkan ayam dan air. Aduk rata
1. Biarkan air agak menyusut,  - Jika sudah menyusut, masukkan santan kental dan cabe. Aduk rata, tambahkan garam, gula dan kaldu. Koreksi rasa - Sajikan selagi hangat dengan nasi hangat




Ternyata cara buat opor ayam kering yang mantab tidak ribet ini enteng sekali ya! Kita semua bisa membuatnya. Resep opor ayam kering Sesuai banget buat kita yang sedang belajar memasak ataupun juga untuk anda yang sudah pandai dalam memasak.

Tertarik untuk mencoba membuat resep opor ayam kering nikmat tidak rumit ini? Kalau mau, mending kamu segera menyiapkan alat-alat dan bahannya, maka bikin deh Resep opor ayam kering yang lezat dan tidak rumit ini. Sangat mudah kan. 

Maka dari itu, ketimbang kamu berfikir lama-lama, maka kita langsung bikin resep opor ayam kering ini. Dijamin anda tiidak akan menyesal bikin resep opor ayam kering lezat tidak ribet ini! Selamat mencoba dengan resep opor ayam kering mantab sederhana ini di tempat tinggal kalian masing-masing,oke!.

