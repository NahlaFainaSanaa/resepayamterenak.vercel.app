---
description: "Cara buat Ayam Asam Manis yang nikmat Untuk Jualan"
title: "Cara buat Ayam Asam Manis yang nikmat Untuk Jualan"
slug: 325-cara-buat-ayam-asam-manis-yang-nikmat-untuk-jualan
date: 2021-05-29T20:26:07.188Z
image: https://img-global.cpcdn.com/recipes/c92e66cb9c65e854/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c92e66cb9c65e854/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c92e66cb9c65e854/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
author: Mittie Ramsey
ratingvalue: 4.8
reviewcount: 5
recipeingredient:
- "1/2 dada ayam fillet"
- "2 buah wortel"
- "1 buah kembang kol"
- "500 gr tepung kobe me"
- " Bahan untuk saos "
- "1 sdm teriyaki"
- "3 siung bawang putih"
- "1 sdt garam"
- "5 sdt gula"
- "1 sdm penyedap rasa larutkan dengan air 250ml"
- "1/2 sdt merica"
- "1/2 sdt maizena"
- "1/2 buah bombay"
- "Secukupnya saos tomat"
- "3 sdm margarin"
recipeinstructions:
- "Potong dan cuci dada ayam menjadi dadu, kemudian marinasi dengan garam terlebih dulu +/- 10 menit"
- "Potong dan cuci semua sayuran"
- "Baluri ayam dengan tepung hingga berselimut"
- "Panaskan minyak dan goreng ayam tepung hingga matang golden brown (deep fry)"
- "Jika ayam sudah matang sisihkan terlebih dulu"
- "Untuk saosnya : geprek dan cincang bawang putih dan potong tipis bawang bombay lalu tumis dengan margarin sampai harum"
- "Masukkan larutan penyedap rasa, aduk dan tunggu hingga mendidih"
- "Masukkan : teriyaki, garam, gula, dan merica"
- "Tambahkan sayuran, masak hingga matang"
- "Masukkan saos tomat sesuai selera, cek rasa"
- "Masukkan ayam tepung lalu aduk merata"
- "Tuang dan aduk larutan maizena"
- "Ready to serve✨"
categories:
- Resep
tags:
- ayam
- asam
- manis

katakunci: ayam asam manis 
nutrition: 227 calories
recipecuisine: Indonesian
preptime: "PT27M"
cooktime: "PT48M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam Asam Manis](https://img-global.cpcdn.com/recipes/c92e66cb9c65e854/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg)

Jika kamu seorang orang tua, menyajikan hidangan sedap untuk keluarga tercinta adalah hal yang mengasyikan untuk kamu sendiri. Kewajiban seorang istri Tidak sekedar mengatur rumah saja, tapi kamu pun wajib menyediakan kebutuhan gizi terpenuhi dan juga santapan yang dikonsumsi orang tercinta harus nikmat.

Di era  saat ini, kamu memang dapat memesan olahan siap saji walaupun tidak harus capek membuatnya lebih dulu. Tetapi ada juga lho orang yang memang mau memberikan makanan yang terenak untuk orang yang dicintainya. Sebab, memasak yang dibuat sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan makanan tersebut sesuai dengan masakan kesukaan orang tercinta. 



Mungkinkah anda seorang penyuka ayam asam manis?. Asal kamu tahu, ayam asam manis merupakan makanan khas di Indonesia yang kini disukai oleh banyak orang dari hampir setiap tempat di Nusantara. Kamu dapat memasak ayam asam manis sendiri di rumah dan pasti jadi camilan favorit di akhir pekan.

Kalian tidak usah bingung jika kamu ingin memakan ayam asam manis, lantaran ayam asam manis gampang untuk didapatkan dan kalian pun dapat mengolahnya sendiri di tempatmu. ayam asam manis dapat diolah dengan beragam cara. Kini ada banyak cara modern yang menjadikan ayam asam manis semakin nikmat.

Resep ayam asam manis pun sangat gampang dibuat, lho. Kita tidak usah capek-capek untuk membeli ayam asam manis, lantaran Anda mampu membuatnya di rumah sendiri. Untuk Anda yang akan menyajikannya, berikut ini cara menyajikan ayam asam manis yang enak yang mampu Anda buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Ayam Asam Manis:

1. Gunakan 1/2 dada ayam fillet
1. Ambil 2 buah wortel
1. Ambil 1 buah kembang kol
1. Ambil 500 gr tepung kobe (me)
1. Siapkan  Bahan untuk saos :
1. Ambil 1 sdm teriyaki
1. Sediakan 3 siung bawang putih
1. Gunakan 1 sdt garam
1. Gunakan 5 sdt gula
1. Ambil 1 sdm penyedap rasa (larutkan dengan air 250ml)
1. Sediakan 1/2 sdt merica
1. Sediakan 1/2 sdt maizena
1. Gunakan 1/2 buah bombay
1. Gunakan Secukupnya saos tomat
1. Siapkan 3 sdm margarin




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam Asam Manis:

1. Potong dan cuci dada ayam menjadi dadu, kemudian marinasi dengan garam terlebih dulu +/- 10 menit
1. Potong dan cuci semua sayuran
1. Baluri ayam dengan tepung hingga berselimut
1. Panaskan minyak dan goreng ayam tepung hingga matang golden brown (deep fry)
1. Jika ayam sudah matang sisihkan terlebih dulu
1. Untuk saosnya : geprek dan cincang bawang putih dan potong tipis bawang bombay lalu tumis dengan margarin sampai harum
1. Masukkan larutan penyedap rasa, aduk dan tunggu hingga mendidih
1. Masukkan : teriyaki, garam, gula, dan merica
1. Tambahkan sayuran, masak hingga matang
1. Masukkan saos tomat sesuai selera, cek rasa
1. Masukkan ayam tepung lalu aduk merata
1. Tuang dan aduk larutan maizena
1. Ready to serve✨




Wah ternyata cara membuat ayam asam manis yang mantab tidak rumit ini enteng sekali ya! Kalian semua bisa membuatnya. Cara buat ayam asam manis Cocok sekali buat kalian yang sedang belajar memasak ataupun bagi kalian yang sudah pandai dalam memasak.

Apakah kamu tertarik mulai mencoba buat resep ayam asam manis lezat sederhana ini? Kalau kamu mau, ayo kalian segera buruan menyiapkan peralatan dan bahannya, setelah itu bikin deh Resep ayam asam manis yang lezat dan tidak ribet ini. Sangat gampang kan. 

Oleh karena itu, daripada anda berlama-lama, maka kita langsung saja bikin resep ayam asam manis ini. Dijamin kalian tiidak akan menyesal sudah bikin resep ayam asam manis mantab sederhana ini! Selamat berkreasi dengan resep ayam asam manis mantab sederhana ini di rumah kalian sendiri,ya!.

