---
description: "Cara buat Ayam Kentucky yang enak dan Mudah Dibuat"
title: "Cara buat Ayam Kentucky yang enak dan Mudah Dibuat"
slug: 42-cara-buat-ayam-kentucky-yang-enak-dan-mudah-dibuat
date: 2021-01-21T00:01:05.346Z
image: https://img-global.cpcdn.com/recipes/75b2f79782012857/680x482cq70/ayam-kentucky-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/75b2f79782012857/680x482cq70/ayam-kentucky-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/75b2f79782012857/680x482cq70/ayam-kentucky-foto-resep-utama.jpg
author: Essie Andrews
ratingvalue: 3.7
reviewcount: 6
recipeingredient:
- " Marinasi"
- "1 Ekor Ayam"
- "1 Biji Jeruk Nipis"
- "1/2 Sachet Ketumbar Bubuk Saya pakai Desaku"
- "1/2 Sachet Kunyit Bubuk Saya pakai Desaku"
- "1/2 Sachet Merica Bubuk Saya pakai Ladaku"
- "1 1/2 Sachet Penyedap Rasa Saya pakai Masako"
- " Bahan Kering"
- "1 kg Tepung Terigu Cakra"
- "1 Bungkus Tepung Serba Guna Saya pakai Sajiku"
- "1 Sachet Penyedap Rasa"
- "1/2 Sachet Ketumbar Bubuk"
- "1/2 Sachet Merica Bubuk"
- " Bahan Basah"
- "Secukupnya Air"
- "Secukupnya Minyak Goreng"
recipeinstructions:
- "Campur perasan jeruk nipis ke Ayam yang sudah di potong²"
- "Diamkan 1/2 jam lalu cuci kembali ayam"
- "Campur semua bahan marinasi, diamkan di kulkas selama 1 jam."
- "Campur semua bahan kering."
- "Kemudian masukan ayam yang sudah di marinasi ke dalam bahan kering aduk pelan"
- "Lalu masukan ke dalam bahan Basah sebentar saja asal basah"
- "Kemudian masukan lagi ke bahan kering, aduk² hingga keriting ayamnya"
- "Goreng di minyak panas dan menggunakan api sedang"
- "Gunakan minyak banyak dan panas agar keritingnya membentuk."
- "Goreng hingga kecoklatan. Angkat. Dan Sajikan."
categories:
- Resep
tags:
- ayam
- kentucky

katakunci: ayam kentucky 
nutrition: 123 calories
recipecuisine: Indonesian
preptime: "PT24M"
cooktime: "PT40M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Kentucky](https://img-global.cpcdn.com/recipes/75b2f79782012857/680x482cq70/ayam-kentucky-foto-resep-utama.jpg)

Selaku seorang yang hobi memasak, mempersiapkan olahan lezat kepada orang tercinta merupakan hal yang memuaskan bagi kamu sendiri. Tanggung jawab seorang  wanita Tidak saja mengatur rumah saja, tapi kamu juga wajib menyediakan keperluan nutrisi tercukupi dan olahan yang dikonsumsi keluarga tercinta harus lezat.

Di masa  sekarang, kamu memang mampu memesan olahan yang sudah jadi walaupun tanpa harus repot memasaknya dulu. Tetapi banyak juga mereka yang selalu ingin menghidangkan yang terenak untuk orang tercintanya. Sebab, menyajikan masakan sendiri jauh lebih bersih dan kita pun bisa menyesuaikan berdasarkan kesukaan keluarga. 



Apakah anda adalah salah satu penikmat ayam kentucky?. Tahukah kamu, ayam kentucky adalah hidangan khas di Nusantara yang saat ini digemari oleh banyak orang di berbagai tempat di Indonesia. Kamu bisa menyajikan ayam kentucky sendiri di rumahmu dan boleh dijadikan santapan kegemaranmu di hari liburmu.

Kita jangan bingung untuk mendapatkan ayam kentucky, sebab ayam kentucky gampang untuk didapatkan dan juga anda pun bisa mengolahnya sendiri di tempatmu. ayam kentucky dapat diolah dengan beragam cara. Sekarang telah banyak resep modern yang membuat ayam kentucky semakin lebih lezat.

Resep ayam kentucky pun sangat gampang dibikin, lho. Kamu jangan capek-capek untuk memesan ayam kentucky, tetapi Kamu dapat menyajikan sendiri di rumah. Untuk Kalian yang mau menghidangkannya, berikut ini cara untuk menyajikan ayam kentucky yang mantab yang dapat Kalian hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Ayam Kentucky:

1. Sediakan  Marinasi
1. Siapkan 1 Ekor Ayam
1. Siapkan 1 Biji Jeruk Nipis
1. Ambil 1/2 Sachet Ketumbar Bubuk (Saya pakai Desaku)
1. Siapkan 1/2 Sachet Kunyit Bubuk (Saya pakai Desaku)
1. Gunakan 1/2 Sachet Merica Bubuk (Saya pakai Ladaku)
1. Siapkan 1 1/2 Sachet Penyedap Rasa (Saya pakai Masako)
1. Ambil  Bahan Kering
1. Sediakan 1 kg Tepung Terigu Cakra
1. Sediakan 1 Bungkus Tepung Serba Guna (Saya pakai Sajiku)
1. Gunakan 1 Sachet Penyedap Rasa
1. Siapkan 1/2 Sachet Ketumbar Bubuk
1. Siapkan 1/2 Sachet Merica Bubuk
1. Siapkan  Bahan Basah
1. Gunakan Secukupnya Air
1. Sediakan Secukupnya Minyak Goreng




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam Kentucky:

1. Campur perasan jeruk nipis ke Ayam yang sudah di potong²
1. Diamkan 1/2 jam lalu cuci kembali ayam
1. Campur semua bahan marinasi, diamkan di kulkas selama 1 jam.
1. Campur semua bahan kering.
1. Kemudian masukan ayam yang sudah di marinasi ke dalam bahan kering aduk pelan
1. Lalu masukan ke dalam bahan Basah sebentar saja asal basah
1. Kemudian masukan lagi ke bahan kering, aduk² hingga keriting ayamnya
1. Goreng di minyak panas dan menggunakan api sedang
1. Gunakan minyak banyak dan panas agar keritingnya membentuk.
1. Goreng hingga kecoklatan. Angkat. Dan Sajikan.




Ternyata cara buat ayam kentucky yang mantab sederhana ini mudah sekali ya! Semua orang dapat menghidangkannya. Cara buat ayam kentucky Sesuai banget buat kalian yang sedang belajar memasak ataupun juga bagi anda yang telah ahli dalam memasak.

Tertarik untuk mencoba buat resep ayam kentucky mantab tidak rumit ini? Kalau kamu tertarik, ayo kalian segera buruan siapin alat dan bahannya, lantas bikin deh Resep ayam kentucky yang nikmat dan sederhana ini. Sungguh mudah kan. 

Maka, ketimbang kalian berlama-lama, maka kita langsung saja sajikan resep ayam kentucky ini. Pasti kamu tiidak akan menyesal sudah buat resep ayam kentucky lezat tidak ribet ini! Selamat berkreasi dengan resep ayam kentucky lezat simple ini di tempat tinggal sendiri,oke!.

