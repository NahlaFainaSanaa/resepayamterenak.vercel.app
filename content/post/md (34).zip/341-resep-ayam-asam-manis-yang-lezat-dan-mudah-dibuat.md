---
description: "Resep Ayam Asam Manis yang lezat dan Mudah Dibuat"
title: "Resep Ayam Asam Manis yang lezat dan Mudah Dibuat"
slug: 341-resep-ayam-asam-manis-yang-lezat-dan-mudah-dibuat
date: 2021-05-07T00:16:55.168Z
image: https://img-global.cpcdn.com/recipes/24e3aedb6a6d4701/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/24e3aedb6a6d4701/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/24e3aedb6a6d4701/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
author: Nell Holloway
ratingvalue: 3.3
reviewcount: 9
recipeingredient:
- " Ayam Goreng"
- "400-600 gr dada ayam"
- "Secukupnya garam"
- "Secukupnya lada"
- "60-100 gr maizena cornstarch"
- "2 buah telur"
- "Secukupnya minyak untuk menggoreng"
- " Saus Asam Manis"
- "1 sdm minyak"
- "1/2 sdm bawang putih cincang"
- "1 buah paprika potong dadu"
- "180 ml cuka apel aku pakai 23sdm lemon karena ga punya cuka apel"
- "1 sdm soy sauce"
- "55 gr saus aku pakai tomato paste karena ga punya saos di rumah"
- "100 gr gula"
- "Secukupnya chili flakes optional ku tambah biar ada rasa pedas sedikit"
- "Secukupnya nanas potong dadu optional kalau mau ada rasa manis asam yang segar bisa ditambah nanas"
recipeinstructions:
- "Panaskan minyak goreng. Pastikan minyak untuk menggoreng bisa menutupi seluruh ayam ya"
- "Potong2 ayam (aku pakai paha atas disini yang masih ada kulitnya) bumbui dengan garam dan lada lalu masukkan maizena. Aduk yang rata"
- "Kocok telur lalu celupkan ayam yang sudah dibumbui ke adukan telur. Masukkan ayam ke minyak untuk digoreng"
- "Sisihkan ayam yang sudah digoreng ke wadah terpisah"
- "Masukkan semua bahan untuk membuat saus. Aduk hingga saus agak mengental. Ketika sudah mengental masukkan ayam yang sudah digoreng dan aduk hingga rata"
- "Sajikan masakan dan selamat menikmati! :D"
categories:
- Resep
tags:
- ayam
- asam
- manis

katakunci: ayam asam manis 
nutrition: 271 calories
recipecuisine: Indonesian
preptime: "PT31M"
cooktime: "PT56M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam Asam Manis](https://img-global.cpcdn.com/recipes/24e3aedb6a6d4701/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg)

Sebagai seorang wanita, menyediakan santapan nikmat untuk keluarga merupakan hal yang menggembirakan bagi kita sendiri. Peran seorang  wanita Tidak cuman menjaga rumah saja, namun anda juga harus memastikan keperluan nutrisi tercukupi dan santapan yang dikonsumsi anak-anak harus menggugah selera.

Di masa  sekarang, kita sebenarnya bisa memesan masakan jadi tidak harus repot membuatnya lebih dulu. Tapi ada juga orang yang memang ingin memberikan yang terenak bagi orang yang dicintainya. Karena, menyajikan masakan yang diolah sendiri jauh lebih higienis dan kita juga bisa menyesuaikan berdasarkan makanan kesukaan orang tercinta. 



Mungkinkah anda adalah seorang penyuka ayam asam manis?. Asal kamu tahu, ayam asam manis merupakan makanan khas di Indonesia yang kini digemari oleh orang-orang di hampir setiap wilayah di Indonesia. Kamu dapat membuat ayam asam manis olahan sendiri di rumah dan pasti jadi makanan kesukaanmu di akhir pekanmu.

Kamu jangan bingung jika kamu ingin memakan ayam asam manis, sebab ayam asam manis tidak sulit untuk ditemukan dan kalian pun dapat membuatnya sendiri di tempatmu. ayam asam manis bisa diolah memalui berbagai cara. Kini pun telah banyak banget cara modern yang membuat ayam asam manis lebih enak.

Resep ayam asam manis pun sangat mudah untuk dibuat, lho. Kita jangan repot-repot untuk memesan ayam asam manis, tetapi Anda bisa menyiapkan di rumah sendiri. Untuk Kalian yang akan mencobanya, di bawah ini adalah resep menyajikan ayam asam manis yang mantab yang bisa Kita hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Ayam Asam Manis:

1. Sediakan  Ayam Goreng
1. Sediakan 400-600 gr dada ayam
1. Sediakan Secukupnya garam
1. Ambil Secukupnya lada
1. Sediakan 60-100 gr maizena (cornstarch)
1. Ambil 2 buah telur
1. Ambil Secukupnya minyak untuk menggoreng
1. Gunakan  Saus Asam Manis
1. Sediakan 1 sdm minyak
1. Gunakan 1/2 sdm bawang putih cincang
1. Siapkan 1 buah paprika potong dadu
1. Gunakan 180 ml cuka apel (aku pakai 2-3sdm lemon karena ga punya cuka apel)
1. Sediakan 1 sdm soy sauce
1. Sediakan 55 gr saus (aku pakai tomato paste karena ga punya saos di rumah)
1. Gunakan 100 gr gula
1. Siapkan Secukupnya chili flakes (optional; ku tambah biar ada rasa pedas sedikit)
1. Sediakan Secukupnya nanas potong dadu (optional; kalau mau ada rasa manis asam yang segar bisa ditambah nanas)




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam Asam Manis:

1. Panaskan minyak goreng. Pastikan minyak untuk menggoreng bisa menutupi seluruh ayam ya
1. Potong2 ayam (aku pakai paha atas disini yang masih ada kulitnya) bumbui dengan garam dan lada lalu masukkan maizena. Aduk yang rata
1. Kocok telur lalu celupkan ayam yang sudah dibumbui ke adukan telur. Masukkan ayam ke minyak untuk digoreng
1. Sisihkan ayam yang sudah digoreng ke wadah terpisah
1. Masukkan semua bahan untuk membuat saus. Aduk hingga saus agak mengental. Ketika sudah mengental masukkan ayam yang sudah digoreng dan aduk hingga rata
1. Sajikan masakan dan selamat menikmati! :D




Wah ternyata cara membuat ayam asam manis yang mantab simple ini gampang sekali ya! Semua orang dapat membuatnya. Cara buat ayam asam manis Sesuai sekali buat kamu yang baru mau belajar memasak atau juga untuk anda yang sudah pandai memasak.

Apakah kamu ingin mencoba membuat resep ayam asam manis nikmat simple ini? Kalau kamu mau, ayo kamu segera siapkan alat dan bahan-bahannya, maka buat deh Resep ayam asam manis yang lezat dan simple ini. Sangat mudah kan. 

Maka, ketimbang kamu berfikir lama-lama, hayo kita langsung saja hidangkan resep ayam asam manis ini. Dijamin kamu tak akan nyesel bikin resep ayam asam manis enak simple ini! Selamat berkreasi dengan resep ayam asam manis enak tidak ribet ini di rumah sendiri,ya!.

