---
description: "Cara buat Ayam Bakar Kecap Bumbu Ungkep yang lezat dan Mudah Dibuat"
title: "Cara buat Ayam Bakar Kecap Bumbu Ungkep yang lezat dan Mudah Dibuat"
slug: 420-cara-buat-ayam-bakar-kecap-bumbu-ungkep-yang-lezat-dan-mudah-dibuat
date: 2021-04-29T19:45:32.666Z
image: https://img-global.cpcdn.com/recipes/32b64a992c759631/680x482cq70/ayam-bakar-kecap-bumbu-ungkep-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/32b64a992c759631/680x482cq70/ayam-bakar-kecap-bumbu-ungkep-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/32b64a992c759631/680x482cq70/ayam-bakar-kecap-bumbu-ungkep-foto-resep-utama.jpg
author: Tony Wagner
ratingvalue: 3.5
reviewcount: 12
recipeingredient:
- "1 kg Ayam Dadasayappaha"
- " Bumbu Halus"
- "7 Siung Bawang Merah"
- "5 Siung Bawang Putih"
- "3 butir kemiri"
- "1 sdt ketumbar"
- "1 ruas kunyit"
- "2 cm jahe memarkan"
- "1 batang serai memarkan"
- "2 lembar daun salamjeruk"
- "1 sdt Lada bubuk"
- " Garam"
- " Gula merah Sisir"
- "Secukupnya Air"
- " Bumbu Oles"
- "1 bawang merah iris"
- "3 sdm kecap"
- "1 sdm minyak"
- " Sambal ayam bakar"
- "1 bh tomat"
- " Cabe rawit sesuai selera"
- " Cabe merah kriting sesuai selera"
- "3 siung bawang Putih"
- "5 siung bawang merah"
recipeinstructions:
- "Cuci bersih Ayam terlebih dahulu, kemudian baluri dengan bumbu halus,serai,daun salam/jeruk tambahkan garam,lada bubuk,gula merah, kasih air secukupnya dan ungkep sampai air menyusut dan bumbunya meresap."
- "Setelah air menyusut dan bumbu sudah meresap kemudian bakar ayam olesi dengan bumbu oles."
- "Sambil menunggu ayam dibakar kita bisa membuat sambal nya ya. Rebus semua bahan untuk sambal lalu uleg hingga halus dan setelah halus tumis dengan sedikit minyak sampai matang dan sajikan bersama dengan Ayam Bakar kecap nya. Selamat Mencoba."
categories:
- Resep
tags:
- ayam
- bakar
- kecap

katakunci: ayam bakar kecap 
nutrition: 202 calories
recipecuisine: Indonesian
preptime: "PT16M"
cooktime: "PT46M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Bakar Kecap Bumbu Ungkep](https://img-global.cpcdn.com/recipes/32b64a992c759631/680x482cq70/ayam-bakar-kecap-bumbu-ungkep-foto-resep-utama.jpg)

Selaku seorang istri, menyediakan olahan enak buat orang tercinta adalah hal yang membahagiakan bagi kita sendiri. Kewajiban seorang ibu bukan sekedar menangani rumah saja, tetapi kamu pun harus menyediakan keperluan gizi terpenuhi dan olahan yang dikonsumsi orang tercinta wajib sedap.

Di zaman  saat ini, kita memang bisa membeli santapan jadi tanpa harus capek membuatnya terlebih dahulu. Tetapi ada juga orang yang selalu ingin memberikan yang terbaik bagi orang tercintanya. Sebab, menyajikan masakan sendiri jauh lebih higienis dan kita juga bisa menyesuaikan sesuai kesukaan keluarga tercinta. 



Apakah anda merupakan salah satu penyuka ayam bakar kecap bumbu ungkep?. Asal kamu tahu, ayam bakar kecap bumbu ungkep merupakan hidangan khas di Nusantara yang kini disenangi oleh banyak orang di berbagai daerah di Indonesia. Kalian dapat memasak ayam bakar kecap bumbu ungkep sendiri di rumah dan boleh dijadikan hidangan favorit di hari libur.

Kita tak perlu bingung untuk memakan ayam bakar kecap bumbu ungkep, lantaran ayam bakar kecap bumbu ungkep gampang untuk dicari dan kamu pun boleh membuatnya sendiri di rumah. ayam bakar kecap bumbu ungkep dapat dimasak dengan beraneka cara. Kini pun ada banyak resep kekinian yang membuat ayam bakar kecap bumbu ungkep semakin lezat.

Resep ayam bakar kecap bumbu ungkep juga sangat gampang dihidangkan, lho. Kalian jangan ribet-ribet untuk membeli ayam bakar kecap bumbu ungkep, sebab Kita mampu membuatnya di rumah sendiri. Untuk Anda yang akan menghidangkannya, inilah cara untuk membuat ayam bakar kecap bumbu ungkep yang lezat yang dapat Kita coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Ayam Bakar Kecap Bumbu Ungkep:

1. Ambil 1 kg Ayam (Dada,sayap,paha)
1. Gunakan  Bumbu Halus
1. Siapkan 7 Siung Bawang Merah
1. Sediakan 5 Siung Bawang Putih
1. Ambil 3 butir kemiri
1. Ambil 1 sdt ketumbar
1. Sediakan 1 ruas kunyit
1. Sediakan 2 cm jahe (memarkan)
1. Ambil 1 batang serai (memarkan)
1. Ambil 2 lembar daun salam/jeruk
1. Siapkan 1 sdt Lada bubuk
1. Ambil  Garam
1. Gunakan  Gula merah (Sisir)
1. Ambil Secukupnya Air
1. Ambil  Bumbu Oles
1. Siapkan 1 bawang merah (iris)
1. Ambil 3 sdm kecap
1. Gunakan 1 sdm minyak
1. Siapkan  Sambal ayam bakar
1. Sediakan 1 bh tomat
1. Gunakan  Cabe rawit (sesuai selera)
1. Siapkan  Cabe merah kriting (sesuai selera)
1. Sediakan 3 siung bawang Putih
1. Gunakan 5 siung bawang merah




<!--inarticleads2-->

##### Cara membuat Ayam Bakar Kecap Bumbu Ungkep:

1. Cuci bersih Ayam terlebih dahulu, kemudian baluri dengan bumbu halus,serai,daun salam/jeruk tambahkan garam,lada bubuk,gula merah, kasih air secukupnya dan ungkep sampai air menyusut dan bumbunya meresap.
1. Setelah air menyusut dan bumbu sudah meresap kemudian bakar ayam olesi dengan bumbu oles.
1. Sambil menunggu ayam dibakar kita bisa membuat sambal nya ya. Rebus semua bahan untuk sambal lalu uleg hingga halus dan setelah halus tumis dengan sedikit minyak sampai matang dan sajikan bersama dengan Ayam Bakar kecap nya. Selamat Mencoba.




Wah ternyata cara buat ayam bakar kecap bumbu ungkep yang enak tidak rumit ini mudah banget ya! Anda Semua mampu menghidangkannya. Cara buat ayam bakar kecap bumbu ungkep Cocok sekali buat anda yang baru belajar memasak maupun juga untuk kamu yang sudah lihai memasak.

Tertarik untuk mencoba buat resep ayam bakar kecap bumbu ungkep lezat tidak rumit ini? Kalau kamu tertarik, yuk kita segera buruan siapin alat dan bahannya, maka bikin deh Resep ayam bakar kecap bumbu ungkep yang lezat dan tidak rumit ini. Benar-benar mudah kan. 

Oleh karena itu, ketimbang kita diam saja, hayo kita langsung saja bikin resep ayam bakar kecap bumbu ungkep ini. Pasti kamu tak akan menyesal bikin resep ayam bakar kecap bumbu ungkep enak tidak rumit ini! Selamat berkreasi dengan resep ayam bakar kecap bumbu ungkep enak simple ini di rumah kalian masing-masing,ya!.

