---
description: "Bahan-bahan Ayam Asam Manis yang lezat Untuk Jualan"
title: "Bahan-bahan Ayam Asam Manis yang lezat Untuk Jualan"
slug: 331-bahan-bahan-ayam-asam-manis-yang-lezat-untuk-jualan
date: 2021-01-12T15:33:32.679Z
image: https://img-global.cpcdn.com/recipes/9c7e0871fe15cb29/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9c7e0871fe15cb29/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9c7e0871fe15cb29/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
author: Micheal Morales
ratingvalue: 3.9
reviewcount: 4
recipeingredient:
- "500 gr paha ayam fillet potong dadu"
- "1/2 sdm bawang putih bubuk"
- "1 sdm kecap asin"
- "4 sdm maizena"
- "1 bh wortel ukuran kecil iris korek api"
- "1/2 bh ketimun buang biji iris memanjang"
- "1/4 bh nenas iris kecil2"
- "1/4 bh paprika merah iris memanjang"
- "200 ml air"
- " Minyak goreng secukupnya untuk menggoreng dan menumis"
- " Bumbu Tumis "
- "3 sg bawang putih cincang"
- "1/2 bh bawang bombay iris2"
- " Bahan Saus "
- "5 ssm saus tomat"
- "2 sdm saus cabe"
- "1 sdm cuka apel"
- "1/2 sdt merica bubuk"
- " Bahan Pengental  larutkan"
- "2 sdt maizena"
- "20 ml air"
recipeinstructions:
- "Lumuri ayam dengan bawang putih bubuk, kecap asin dan maizena"
- "Panaskan minyak agak banyak. Goreng ayam sampai matang dan berwarna kekuningan. Angkat. Sisihkan"
- "Panaskan 3 sdm minyak goreng. Masukkan bumbu tumis. Aduk sampai harum."
- "Maaukkan wortel. Aduk sebentar. Masukkan paprika dan ketimun. Aduk kembali. Lalu maaukkan nenas."
- "Tuang bahan saus dan air. Masak sampai bahan agak layu. Berikan garam, gula pasir, kaldu bubuk."
- "Maaukkan bahan pengental. Aduk rata. Masukkan ayam. Aduk kembali sampai rata. Angkat"
categories:
- Resep
tags:
- ayam
- asam
- manis

katakunci: ayam asam manis 
nutrition: 157 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT35M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Asam Manis](https://img-global.cpcdn.com/recipes/9c7e0871fe15cb29/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg)

Apabila anda seorang istri, menyuguhkan santapan enak pada keluarga tercinta adalah hal yang sangat menyenangkan untuk kita sendiri. Tanggung jawab seorang ibu Tidak saja mengerjakan pekerjaan rumah saja, namun kamu juga harus menyediakan keperluan gizi tercukupi dan panganan yang disantap anak-anak mesti menggugah selera.

Di waktu  saat ini, anda sebenarnya mampu mengorder hidangan yang sudah jadi tidak harus susah memasaknya lebih dulu. Tetapi banyak juga orang yang selalu mau memberikan hidangan yang terlezat bagi orang yang dicintainya. Pasalnya, memasak yang dibuat sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan makanan tersebut sesuai dengan kesukaan famili. 



Apakah anda seorang penikmat ayam asam manis?. Tahukah kamu, ayam asam manis adalah makanan khas di Indonesia yang kini digemari oleh banyak orang di hampir setiap tempat di Indonesia. Kita bisa membuat ayam asam manis sendiri di rumah dan dapat dijadikan camilan favorit di akhir pekan.

Kamu jangan bingung untuk menyantap ayam asam manis, lantaran ayam asam manis tidak sukar untuk didapatkan dan juga anda pun boleh memasaknya sendiri di tempatmu. ayam asam manis dapat dimasak memalui beragam cara. Sekarang telah banyak sekali cara modern yang menjadikan ayam asam manis semakin lebih mantap.

Resep ayam asam manis pun mudah sekali dibuat, lho. Kita jangan repot-repot untuk membeli ayam asam manis, sebab Anda bisa menghidangkan ditempatmu. Bagi Anda yang ingin menghidangkannya, berikut ini resep untuk membuat ayam asam manis yang lezat yang bisa Anda buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Ayam Asam Manis:

1. Siapkan 500 gr paha ayam fillet, potong dadu
1. Sediakan 1/2 sdm bawang putih bubuk
1. Siapkan 1 sdm kecap asin
1. Ambil 4 sdm maizena
1. Gunakan 1 bh wortel ukuran kecil, iris korek api
1. Sediakan 1/2 bh ketimun, buang biji, iris memanjang
1. Ambil 1/4 bh nenas, iris kecil2
1. Siapkan 1/4 bh paprika merah, iris memanjang
1. Ambil 200 ml air
1. Siapkan  Minyak goreng secukupnya untuk menggoreng dan menumis
1. Gunakan  Bumbu Tumis :
1. Ambil 3 sg bawang putih, cincang
1. Siapkan 1/2 bh bawang bombay, iris2
1. Siapkan  Bahan Saus :
1. Siapkan 5 ssm saus tomat
1. Sediakan 2 sdm saus cabe
1. Gunakan 1 sdm cuka apel
1. Sediakan 1/2 sdt merica bubuk
1. Sediakan  Bahan Pengental : (larutkan)
1. Sediakan 2 sdt maizena
1. Ambil 20 ml air




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam Asam Manis:

1. Lumuri ayam dengan bawang putih bubuk, kecap asin dan maizena
1. Panaskan minyak agak banyak. Goreng ayam sampai matang dan berwarna kekuningan. Angkat. Sisihkan
1. Panaskan 3 sdm minyak goreng. Masukkan bumbu tumis. Aduk sampai harum.
1. Maaukkan wortel. Aduk sebentar. Masukkan paprika dan ketimun. Aduk kembali. Lalu maaukkan nenas.
1. Tuang bahan saus dan air. Masak sampai bahan agak layu. Berikan garam, gula pasir, kaldu bubuk.
1. Maaukkan bahan pengental. Aduk rata. Masukkan ayam. Aduk kembali sampai rata. Angkat




Ternyata cara buat ayam asam manis yang nikamt tidak ribet ini enteng banget ya! Kamu semua mampu mencobanya. Cara buat ayam asam manis Sangat sesuai sekali buat anda yang baru akan belajar memasak ataupun juga untuk anda yang telah lihai dalam memasak.

Tertarik untuk mencoba membuat resep ayam asam manis enak tidak rumit ini? Kalau mau, ayo kalian segera siapkan peralatan dan bahannya, maka bikin deh Resep ayam asam manis yang nikmat dan tidak ribet ini. Betul-betul mudah kan. 

Jadi, ketimbang kamu berlama-lama, yuk langsung aja buat resep ayam asam manis ini. Dijamin anda tiidak akan menyesal sudah bikin resep ayam asam manis enak sederhana ini! Selamat berkreasi dengan resep ayam asam manis lezat tidak ribet ini di rumah kalian sendiri,ya!.

