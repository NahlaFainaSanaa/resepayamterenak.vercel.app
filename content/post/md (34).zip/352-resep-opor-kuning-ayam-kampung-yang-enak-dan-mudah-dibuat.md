---
description: "Resep Opor Kuning Ayam Kampung yang enak dan Mudah Dibuat"
title: "Resep Opor Kuning Ayam Kampung yang enak dan Mudah Dibuat"
slug: 352-resep-opor-kuning-ayam-kampung-yang-enak-dan-mudah-dibuat
date: 2021-06-06T23:58:35.719Z
image: https://img-global.cpcdn.com/recipes/223536e38da844bf/680x482cq70/opor-kuning-ayam-kampung-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/223536e38da844bf/680x482cq70/opor-kuning-ayam-kampung-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/223536e38da844bf/680x482cq70/opor-kuning-ayam-kampung-foto-resep-utama.jpg
author: Lilly Norris
ratingvalue: 3.3
reviewcount: 14
recipeingredient:
- "1 ekor ayam kampung"
- "250 ml santan kental"
- "750 ml santan sedang"
- " Bumbu"
- "5 siung bawang merah"
- "3 siung bawang putih"
- "4 butir kemiri"
- "1 sdt ketumbar"
- "1/2 sdt jintan"
- "1 ruas kunyit"
- "1 ruas jahe"
- "1 ruas lengkuas"
- "2 batang serei"
- "2 lbr daun salam"
- "3 lbr daun jeruk"
- "Secukupnya garam"
- "Secukupnya gula pasir"
- "Secukupnya lada bubuk"
- "1 genggam kelapa parut Sangrai hingga kecokelatan lalu ulek halus optional"
- " Pelengkap optional"
- " Telur rebus"
- " Tahu goreng"
recipeinstructions:
- "Potong ayam sesuai selera. Rendam dalam air, beri cuka dan garam. Diamkan selama 15 menit lalu cuci bersih."
- "Haluskan duo bawang, kemiri, ketumbar, dan jinten. Tumis hingga matang lalu masukkan daun salam, serei, daun jeruk, jahe, dan lengkuas."
- "Masukkan ayam. Aduk-aduk hingga terbaluri bumbu. Masukkan santan sedang. Saya pindahkan dulu ke panci yang tutupnya rapat agar ayam empuk. Masak di atas api kecil dengan panci tertutup selama 1 jam atau hingga benar-benar empuk. Atau bisa juga dipresto selama 30 menit."
- "Saya pindahkan lagi ke wajan setelah empuk. Masukkan santan kental dan kelapa parut sangrai. Masak hingga mendidih. Jangan lupa diaduk biar santan tidak pecah. Beri garam, gula, dan lada bubuk. Koreksi rasa."
- "Tambahkan telur rebus dan bawang goreng sebagai pelengkap. Taburi bawang goreng. Siap disajikan."
categories:
- Resep
tags:
- opor
- kuning
- ayam

katakunci: opor kuning ayam 
nutrition: 112 calories
recipecuisine: Indonesian
preptime: "PT35M"
cooktime: "PT58M"
recipeyield: "3"
recipecategory: Dinner

---


![Opor Kuning Ayam Kampung](https://img-global.cpcdn.com/recipes/223536e38da844bf/680x482cq70/opor-kuning-ayam-kampung-foto-resep-utama.jpg)

Jika kamu seorang wanita, menyajikan masakan nikmat buat orang tercinta merupakan suatu hal yang sangat menyenangkan bagi anda sendiri. Tugas seorang istri bukan sekedar mengatur rumah saja, tapi anda juga harus menyediakan keperluan nutrisi terpenuhi dan panganan yang dikonsumsi anak-anak mesti lezat.

Di zaman  saat ini, anda memang bisa memesan masakan yang sudah jadi tanpa harus ribet memasaknya lebih dulu. Tapi banyak juga orang yang memang ingin menghidangkan yang terbaik untuk keluarganya. Pasalnya, menghidangkan masakan sendiri jauh lebih bersih dan bisa menyesuaikan hidangan tersebut sesuai kesukaan orang tercinta. 



Apakah anda salah satu penggemar opor kuning ayam kampung?. Tahukah kamu, opor kuning ayam kampung merupakan hidangan khas di Nusantara yang kini digemari oleh setiap orang dari hampir setiap tempat di Indonesia. Kalian bisa menghidangkan opor kuning ayam kampung sendiri di rumahmu dan boleh jadi camilan kesukaanmu di akhir pekan.

Kalian jangan bingung untuk mendapatkan opor kuning ayam kampung, lantaran opor kuning ayam kampung mudah untuk didapatkan dan kalian pun bisa memasaknya sendiri di tempatmu. opor kuning ayam kampung boleh dibuat memalui berbagai cara. Kini sudah banyak cara modern yang membuat opor kuning ayam kampung semakin lebih mantap.

Resep opor kuning ayam kampung pun mudah dihidangkan, lho. Kita tidak usah capek-capek untuk memesan opor kuning ayam kampung, lantaran Anda dapat menyiapkan sendiri di rumah. Untuk Kita yang mau menghidangkannya, di bawah ini adalah resep untuk membuat opor kuning ayam kampung yang enak yang bisa Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Opor Kuning Ayam Kampung:

1. Siapkan 1 ekor ayam kampung
1. Gunakan 250 ml santan kental
1. Sediakan 750 ml santan sedang
1. Gunakan  Bumbu:
1. Ambil 5 siung bawang merah
1. Ambil 3 siung bawang putih
1. Siapkan 4 butir kemiri
1. Gunakan 1 sdt ketumbar
1. Sediakan 1/2 sdt jintan
1. Ambil 1 ruas kunyit
1. Siapkan 1 ruas jahe
1. Sediakan 1 ruas lengkuas
1. Ambil 2 batang serei
1. Ambil 2 lbr daun salam
1. Siapkan 3 lbr daun jeruk
1. Gunakan Secukupnya garam
1. Siapkan Secukupnya gula pasir
1. Sediakan Secukupnya lada bubuk
1. Sediakan 1 genggam kelapa parut. Sangrai hingga kecokelatan lalu ulek halus (optional)
1. Sediakan  Pelengkap (optional):
1. Sediakan  Telur rebus
1. Ambil  Tahu goreng




<!--inarticleads2-->

##### Cara membuat Opor Kuning Ayam Kampung:

1. Potong ayam sesuai selera. Rendam dalam air, beri cuka dan garam. Diamkan selama 15 menit lalu cuci bersih.
1. Haluskan duo bawang, kemiri, ketumbar, dan jinten. Tumis hingga matang lalu masukkan daun salam, serei, daun jeruk, jahe, dan lengkuas.
1. Masukkan ayam. Aduk-aduk hingga terbaluri bumbu. Masukkan santan sedang. Saya pindahkan dulu ke panci yang tutupnya rapat agar ayam empuk. Masak di atas api kecil dengan panci tertutup selama 1 jam atau hingga benar-benar empuk. Atau bisa juga dipresto selama 30 menit.
1. Saya pindahkan lagi ke wajan setelah empuk. Masukkan santan kental dan kelapa parut sangrai. Masak hingga mendidih. Jangan lupa diaduk biar santan tidak pecah. Beri garam, gula, dan lada bubuk. Koreksi rasa.
1. Tambahkan telur rebus dan bawang goreng sebagai pelengkap. Taburi bawang goreng. Siap disajikan.




Ternyata cara membuat opor kuning ayam kampung yang mantab sederhana ini gampang banget ya! Kita semua bisa memasaknya. Cara buat opor kuning ayam kampung Sesuai banget untuk kalian yang baru belajar memasak ataupun juga untuk kamu yang sudah lihai memasak.

Tertarik untuk mulai mencoba buat resep opor kuning ayam kampung enak sederhana ini? Kalau kalian ingin, yuk kita segera menyiapkan alat dan bahan-bahannya, lalu buat deh Resep opor kuning ayam kampung yang lezat dan sederhana ini. Sangat mudah kan. 

Oleh karena itu, daripada kamu berlama-lama, hayo kita langsung buat resep opor kuning ayam kampung ini. Dijamin kalian tak akan nyesel sudah buat resep opor kuning ayam kampung lezat tidak rumit ini! Selamat berkreasi dengan resep opor kuning ayam kampung mantab sederhana ini di tempat tinggal kalian sendiri,oke!.

