---
description: "Cara membuat Tsukune Ayam dengan Akar Lotus (Bakso Ayam ala Jepang) 蓮根入り鶏つくね yang enak dan Mudah Dibuat"
title: "Cara membuat Tsukune Ayam dengan Akar Lotus (Bakso Ayam ala Jepang) 蓮根入り鶏つくね yang enak dan Mudah Dibuat"
slug: 200-cara-membuat-tsukune-ayam-dengan-akar-lotus-bakso-ayam-ala-jepang-yang-enak-dan-mudah-dibuat
date: 2021-06-10T21:48:16.539Z
image: https://img-global.cpcdn.com/recipes/416d403bcb3d0483/680x482cq70/tsukune-ayam-dengan-akar-lotus-bakso-ayam-ala-jepang-蓮根入り鶏つくね-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/416d403bcb3d0483/680x482cq70/tsukune-ayam-dengan-akar-lotus-bakso-ayam-ala-jepang-蓮根入り鶏つくね-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/416d403bcb3d0483/680x482cq70/tsukune-ayam-dengan-akar-lotus-bakso-ayam-ala-jepang-蓮根入り鶏つくね-foto-resep-utama.jpg
author: Genevieve Moreno
ratingvalue: 3
reviewcount: 15
recipeingredient:
- " Bahan Utama  Main Ingredients"
- "250 g Paha Ayam    Chicken thigh"
- "50 G Akar lotus    Lotus root"
- "15 g Daun Bawang    Green onion"
- "5 g Jahe    Ginger"
- "3 g Kaldu Ayam bubuk    Chicken stock powder"
- "Sejumput Garam dan lada    a pinch of salt and pepper"
- "15 g Tepung maizena    Corn starch"
- " Bahan Saus  Sauce Ingredients"
- "30 g Shoyu  "
- "10 g Gula    Sugar"
- "20 g Mirin  "
- "10 g Gochujang  "
recipeinstructions:
- "Potong ayam dan akar lotus, kemudian cincang dengan food processor 鶏肉は小さく切り、チョッパーでミンチ状にします。 Cut the chicken into small pieces and mince it with a chopper."
- "Kemudian tambahkan semua bahan utama lainnya ke dalam food processor. Cincang hingga semua bahan tercampur rata チョッパーに蓮根と調味料を入れて更に混ぜ合わせます。 Add all remaining main ingredients to the chopper and mix further"
- "Buat bola-bola bakso ayam dengan ukuran 40g 混ぜた鶏肉はボール状に分けます（大体40g） Divide the mixed chicken into balls, about 40g."
- "Tumis ayam dengan sedikit minyak dan api kecil sambil sedikit ditekan agar permukaan bakso rata/flat コンロの火を弱火にして、鶏肉を押さえつけながら焼きます（弱火） Bake slowly while holding down the chicken to make the surface flat (cook with low heat）"
- "Apabila bakso sudah matang angkat dan tiriskan, kemudian masukkan bahan-bahan saus ke panci masak hingga mendidih aduk-aduk hingga merata.  Sajikan bakso dengan saus.  両面が良く焼けたらソースの材料を入れて仕上げます。 When both sides are well baked,add the sauce and finish."
categories:
- Resep
tags:
- tsukune
- ayam
- dengan

katakunci: tsukune ayam dengan 
nutrition: 218 calories
recipecuisine: Indonesian
preptime: "PT38M"
cooktime: "PT39M"
recipeyield: "3"
recipecategory: Lunch

---


![Tsukune Ayam dengan Akar Lotus (Bakso Ayam ala Jepang) 蓮根入り鶏つくね](https://img-global.cpcdn.com/recipes/416d403bcb3d0483/680x482cq70/tsukune-ayam-dengan-akar-lotus-bakso-ayam-ala-jepang-蓮根入り鶏つくね-foto-resep-utama.jpg)

Andai anda seorang ibu, menyuguhkan hidangan enak bagi famili adalah suatu hal yang menyenangkan untuk kamu sendiri. Tanggung jawab seorang ibu bukan hanya mengatur rumah saja, tetapi anda juga harus memastikan keperluan gizi tercukupi dan masakan yang dimakan orang tercinta mesti sedap.

Di era  sekarang, kalian memang mampu memesan panganan instan tanpa harus susah mengolahnya lebih dulu. Tapi banyak juga mereka yang memang ingin menghidangkan yang terlezat bagi orang tercintanya. Pasalnya, menyajikan masakan sendiri akan jauh lebih bersih dan bisa menyesuaikan masakan tersebut berdasarkan masakan kesukaan keluarga tercinta. 



Mungkinkah anda merupakan seorang penikmat tsukune ayam dengan akar lotus (bakso ayam ala jepang) 蓮根入り鶏つくね?. Asal kamu tahu, tsukune ayam dengan akar lotus (bakso ayam ala jepang) 蓮根入り鶏つくね adalah sajian khas di Indonesia yang sekarang disukai oleh orang-orang dari berbagai tempat di Nusantara. Kalian bisa memasak tsukune ayam dengan akar lotus (bakso ayam ala jepang) 蓮根入り鶏つくね kreasi sendiri di rumah dan boleh dijadikan makanan kesenanganmu di akhir pekanmu.

Kita jangan bingung jika kamu ingin menyantap tsukune ayam dengan akar lotus (bakso ayam ala jepang) 蓮根入り鶏つくね, lantaran tsukune ayam dengan akar lotus (bakso ayam ala jepang) 蓮根入り鶏つくね sangat mudah untuk dicari dan juga kalian pun boleh membuatnya sendiri di rumah. tsukune ayam dengan akar lotus (bakso ayam ala jepang) 蓮根入り鶏つくね boleh dibuat memalui beraneka cara. Kini ada banyak cara kekinian yang membuat tsukune ayam dengan akar lotus (bakso ayam ala jepang) 蓮根入り鶏つくね lebih nikmat.

Resep tsukune ayam dengan akar lotus (bakso ayam ala jepang) 蓮根入り鶏つくね juga sangat mudah untuk dibikin, lho. Kamu jangan repot-repot untuk membeli tsukune ayam dengan akar lotus (bakso ayam ala jepang) 蓮根入り鶏つくね, tetapi Kalian dapat menghidangkan di rumah sendiri. Bagi Kamu yang mau menyajikannya, di bawah ini adalah cara menyajikan tsukune ayam dengan akar lotus (bakso ayam ala jepang) 蓮根入り鶏つくね yang enak yang dapat Anda buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Tsukune Ayam dengan Akar Lotus (Bakso Ayam ala Jepang) 蓮根入り鶏つくね:

1. Gunakan  Bahan Utama // Main Ingredients
1. Gunakan 250 g Paha Ayam / 鶏もも肉 / Chicken thigh
1. Sediakan 50 G Akar lotus / 蓮根 / Lotus root
1. Gunakan 15 g Daun Bawang / 青ネギ / Green onion
1. Ambil 5 g Jahe / 生姜 / Ginger
1. Sediakan 3 g Kaldu Ayam bubuk / ガラスープの素 / Chicken stock powder
1. Sediakan Sejumput Garam dan lada / 塩コショウ / a pinch of salt and pepper
1. Sediakan 15 g Tepung maizena / 片栗粉 / Corn starch
1. Gunakan  Bahan Saus // Sauce Ingredients
1. Sediakan 30 g Shoyu / 醤油
1. Ambil 10 g Gula / 砂糖 / Sugar
1. Ambil 20 g Mirin / みりん
1. Siapkan 10 g Gochujang / コチュジャン




<!--inarticleads2-->

##### Cara membuat Tsukune Ayam dengan Akar Lotus (Bakso Ayam ala Jepang) 蓮根入り鶏つくね:

1. Potong ayam dan akar lotus, kemudian cincang dengan food processor - 鶏肉は小さく切り、チョッパーでミンチ状にします。 - Cut the chicken into small pieces and mince it with a chopper.
1. Kemudian tambahkan semua bahan utama lainnya ke dalam food processor. Cincang hingga semua bahan tercampur rata - チョッパーに蓮根と調味料を入れて更に混ぜ合わせます。 - Add all remaining main ingredients to the chopper and mix further
1. Buat bola-bola bakso ayam dengan ukuran 40g - 混ぜた鶏肉はボール状に分けます（大体40g） - Divide the mixed chicken into balls, about 40g.
1. Tumis ayam dengan sedikit minyak dan api kecil sambil sedikit ditekan agar permukaan bakso rata/flat - コンロの火を弱火にして、鶏肉を押さえつけながら焼きます（弱火） - Bake slowly while holding down the chicken to make the surface flat (cook with low heat）
1. Apabila bakso sudah matang angkat dan tiriskan, kemudian masukkan bahan-bahan saus ke panci masak hingga mendidih aduk-aduk hingga merata. -  - Sajikan bakso dengan saus. -  - 両面が良く焼けたらソースの材料を入れて仕上げます。 - When both sides are well baked,add the sauce and finish.




Wah ternyata cara membuat tsukune ayam dengan akar lotus (bakso ayam ala jepang) 蓮根入り鶏つくね yang nikamt tidak rumit ini mudah sekali ya! Anda Semua mampu menghidangkannya. Cara Membuat tsukune ayam dengan akar lotus (bakso ayam ala jepang) 蓮根入り鶏つくね Sangat sesuai banget buat kalian yang baru mau belajar memasak ataupun bagi anda yang telah lihai dalam memasak.

Apakah kamu tertarik mencoba membikin resep tsukune ayam dengan akar lotus (bakso ayam ala jepang) 蓮根入り鶏つくね enak simple ini? Kalau kalian tertarik, yuk kita segera buruan siapin alat dan bahan-bahannya, lantas bikin deh Resep tsukune ayam dengan akar lotus (bakso ayam ala jepang) 蓮根入り鶏つくね yang mantab dan tidak rumit ini. Benar-benar gampang kan. 

Jadi, daripada kita diam saja, hayo kita langsung bikin resep tsukune ayam dengan akar lotus (bakso ayam ala jepang) 蓮根入り鶏つくね ini. Dijamin kamu tak akan menyesal sudah buat resep tsukune ayam dengan akar lotus (bakso ayam ala jepang) 蓮根入り鶏つくね nikmat simple ini! Selamat mencoba dengan resep tsukune ayam dengan akar lotus (bakso ayam ala jepang) 蓮根入り鶏つくね enak tidak ribet ini di rumah kalian sendiri,oke!.

