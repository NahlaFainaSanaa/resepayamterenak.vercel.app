---
description: "Cara buat Opor ayam kampung (masak ala ingkung) yang enak dan Mudah Dibuat"
title: "Cara buat Opor ayam kampung (masak ala ingkung) yang enak dan Mudah Dibuat"
slug: 71-cara-buat-opor-ayam-kampung-masak-ala-ingkung-yang-enak-dan-mudah-dibuat
date: 2021-01-24T11:30:12.201Z
image: https://img-global.cpcdn.com/recipes/e4b2551d1bb077c1/680x482cq70/opor-ayam-kampung-masak-ala-ingkung-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e4b2551d1bb077c1/680x482cq70/opor-ayam-kampung-masak-ala-ingkung-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e4b2551d1bb077c1/680x482cq70/opor-ayam-kampung-masak-ala-ingkung-foto-resep-utama.jpg
author: Albert Phillips
ratingvalue: 4.2
reviewcount: 11
recipeingredient:
- "1 ekor ayam kampung"
- " Bahan rendam"
- "2 sdm garam"
- "1 sdm asam jawa kering cairkan dengan air"
- " Bahan dihaluskan"
- "10 siung bawang merah"
- "8 siung bawang putih"
- "1 sendok makan ketumbar"
- "5 kemiri yang sudah di goreng"
- "1 jempol kunyit"
- " Bumbu tambahan"
- "5 lembar daun jeruk"
- "2 batang sereh"
- "3 batang daun bawang ukuran sedang potong besar2"
- "1 jempol laos keprek saja"
- "3 lembar daun salam"
- "1 sdm gula merah"
- "secukupnya Garam"
- " Gula putih sedikit saja saat koreksi rasa"
- "jika diinginkan Kaldu bubuk"
- " Santan dari 12 kelapa uk besar pisahkan kental dan encer"
- " Taburan"
- " Bawang goreng"
recipeinstructions:
- "Ayam bisa diutuhkan bila untuk ayam ingkung. Tetapi saya dipotong karena mau dimakan sebagai opor ayam."
- "Cuci bersih ayam kemudian gosok dengan garam cuci hingga bersih dan kemudian rendam dengan air asam jawa selama 15 menit. Cuci ayam hingga bersih."
- "Haluskan semua bumbu halus. Masukkan bumbu ke dalam wajan atau panci untuk memasak dan remas-remas ayam dengan bumbu halus tersebut."
- "Tambahkan air sekitar 2 liter, masukkan semua bumbu tambahan (kecuali daun bawang) dan juga masukkan santan. Sisakan santan kental sekitar 200ml."
- "Masak dengan api kecil dan tutup wajan/panci. Bila dimasak menggunakan wajan lebih enak ditutup dengan daun pisang."
- "Bila ayam sudah empuk tambahkan santan kental dan daun bawang. Masak hingga mengental dan air tinggal sedikit. Jangan lupa di cicipin dan koreksi rasa."
- "Siap dihidangkan dan taburkan bawang goreng."
categories:
- Resep
tags:
- opor
- ayam
- kampung

katakunci: opor ayam kampung 
nutrition: 284 calories
recipecuisine: Indonesian
preptime: "PT27M"
cooktime: "PT32M"
recipeyield: "2"
recipecategory: Dinner

---


![Opor ayam kampung (masak ala ingkung)](https://img-global.cpcdn.com/recipes/e4b2551d1bb077c1/680x482cq70/opor-ayam-kampung-masak-ala-ingkung-foto-resep-utama.jpg)

Selaku seorang yang hobi masak, mempersiapkan masakan sedap pada orang tercinta adalah hal yang mengasyikan untuk anda sendiri. Tanggung jawab seorang ibu Tidak sekadar mengurus rumah saja, tapi kamu pun wajib memastikan kebutuhan gizi tercukupi dan masakan yang disantap anak-anak harus menggugah selera.

Di waktu  saat ini, kamu memang dapat mengorder santapan yang sudah jadi meski tanpa harus capek membuatnya dulu. Tapi ada juga orang yang selalu ingin memberikan makanan yang terlezat untuk keluarganya. Sebab, menyajikan masakan yang dibuat sendiri jauh lebih higienis dan bisa menyesuaikan sesuai selera famili. 

Kunci masakan Opor Ayam, tentu saja selain ayamnya sendiri, adalah santannya! Nah untuk masak opor kali ini saya pakai Santan Sasa! Resep dan cara memasak opor ayam kampung ala Ida Nur Aida.

Mungkinkah kamu salah satu penggemar opor ayam kampung (masak ala ingkung)?. Tahukah kamu, opor ayam kampung (masak ala ingkung) adalah sajian khas di Indonesia yang saat ini disenangi oleh setiap orang dari berbagai daerah di Indonesia. Kita bisa memasak opor ayam kampung (masak ala ingkung) kreasi sendiri di rumah dan boleh dijadikan santapan kesukaanmu di hari libur.

Kita tidak perlu bingung untuk menyantap opor ayam kampung (masak ala ingkung), sebab opor ayam kampung (masak ala ingkung) gampang untuk didapatkan dan juga kita pun dapat mengolahnya sendiri di tempatmu. opor ayam kampung (masak ala ingkung) dapat dimasak dengan beraneka cara. Kini telah banyak resep modern yang menjadikan opor ayam kampung (masak ala ingkung) semakin nikmat.

Resep opor ayam kampung (masak ala ingkung) juga sangat gampang dihidangkan, lho. Anda tidak perlu repot-repot untuk memesan opor ayam kampung (masak ala ingkung), lantaran Kita mampu menghidangkan ditempatmu. Untuk Kita yang akan membuatnya, dibawah ini merupakan resep menyajikan opor ayam kampung (masak ala ingkung) yang mantab yang bisa Kamu hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Opor ayam kampung (masak ala ingkung):

1. Ambil 1 ekor ayam kampung
1. Gunakan  Bahan rendam:
1. Gunakan 2 sdm garam
1. Sediakan 1 sdm asam jawa kering cairkan dengan air
1. Siapkan  Bahan dihaluskan:
1. Gunakan 10 siung bawang merah
1. Sediakan 8 siung bawang putih
1. Ambil 1 sendok makan ketumbar
1. Sediakan 5 kemiri yang sudah di goreng
1. Ambil 1 jempol kunyit
1. Ambil  Bumbu tambahan:
1. Siapkan 5 lembar daun jeruk
1. Gunakan 2 batang sereh
1. Ambil 3 batang daun bawang ukuran sedang potong besar2
1. Siapkan 1 jempol laos keprek saja
1. Sediakan 3 lembar daun salam
1. Gunakan 1 sdm gula merah
1. Gunakan secukupnya Garam
1. Gunakan  Gula putih sedikit saja saat koreksi rasa
1. Gunakan jika diinginkan Kaldu bubuk
1. Ambil  Santan dari 1/2 kelapa uk besar, pisahkan kental dan encer
1. Sediakan  Taburan
1. Sediakan  Bawang goreng


Namun tekstur dan rasa ayam kampung memiliki aroma tersendiri yang tentu Untuk mengakali meningkat pesatnya harga ayam kampung. Afrid punya tips trik sederhana bagaimana kita bisa menyantap opor ayam. Opor ayam tidak hanya disajikan untuk Lebaran. Setelah bumbu harum, masukkan ayam dan masak hingga tercampur rata dan ayam menjadi kaku. 

<!--inarticleads2-->

##### Langkah-langkah membuat Opor ayam kampung (masak ala ingkung):

1. Ayam bisa diutuhkan bila untuk ayam ingkung. Tetapi saya dipotong karena mau dimakan sebagai opor ayam.
1. Cuci bersih ayam kemudian gosok dengan garam cuci hingga bersih dan kemudian rendam dengan air asam jawa selama 15 menit. Cuci ayam hingga bersih.
1. Haluskan semua bumbu halus. Masukkan bumbu ke dalam wajan atau panci untuk memasak dan remas-remas ayam dengan bumbu halus tersebut.
1. Tambahkan air sekitar 2 liter, masukkan semua bumbu tambahan (kecuali daun bawang) dan juga masukkan santan. Sisakan santan kental sekitar 200ml.
1. Masak dengan api kecil dan tutup wajan/panci. Bila dimasak menggunakan wajan lebih enak ditutup dengan daun pisang.
1. Bila ayam sudah empuk tambahkan santan kental dan daun bawang. Masak hingga mengental dan air tinggal sedikit. Jangan lupa di cicipin dan koreksi rasa.
1. Siap dihidangkan dan taburkan bawang goreng.


Rekomendasi kami ayam kampung karena rasa dagingnya lebih enak dari pada ayam potong. Masukkan kembali santan kental dan tambahkan gula, garam dan lada bubuk. Sajikan opor ayam buatan kamu sendiri bersamaan dengan nasi, lontong atau ketupat. Lama enggak masak Opor Ayam, kangen deh. Banyak banget yang pasti punya resep Opor Ayam andalan yah. 

Ternyata cara buat opor ayam kampung (masak ala ingkung) yang mantab tidak ribet ini gampang banget ya! Kamu semua mampu memasaknya. Cara buat opor ayam kampung (masak ala ingkung) Sesuai banget buat kita yang sedang belajar memasak maupun juga bagi kalian yang sudah pandai memasak.

Tertarik untuk mencoba buat resep opor ayam kampung (masak ala ingkung) mantab tidak ribet ini? Kalau kamu ingin, mending kamu segera buruan menyiapkan peralatan dan bahan-bahannya, maka bikin deh Resep opor ayam kampung (masak ala ingkung) yang mantab dan tidak ribet ini. Betul-betul mudah kan. 

Maka dari itu, ketimbang kita diam saja, hayo langsung aja hidangkan resep opor ayam kampung (masak ala ingkung) ini. Pasti kamu tiidak akan menyesal bikin resep opor ayam kampung (masak ala ingkung) enak tidak ribet ini! Selamat berkreasi dengan resep opor ayam kampung (masak ala ingkung) lezat sederhana ini di tempat tinggal kalian masing-masing,ya!.

