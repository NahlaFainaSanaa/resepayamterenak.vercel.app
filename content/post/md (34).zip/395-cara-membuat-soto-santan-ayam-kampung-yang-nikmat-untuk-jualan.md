---
description: "Cara membuat Soto santan ayam kampung yang nikmat Untuk Jualan"
title: "Cara membuat Soto santan ayam kampung yang nikmat Untuk Jualan"
slug: 395-cara-membuat-soto-santan-ayam-kampung-yang-nikmat-untuk-jualan
date: 2021-01-14T22:00:24.363Z
image: https://img-global.cpcdn.com/recipes/021e39922f7ad3fe/680x482cq70/soto-santan-ayam-kampung-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/021e39922f7ad3fe/680x482cq70/soto-santan-ayam-kampung-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/021e39922f7ad3fe/680x482cq70/soto-santan-ayam-kampung-foto-resep-utama.jpg
author: Mildred Flowers
ratingvalue: 4.6
reviewcount: 7
recipeingredient:
- "1/2 kg ayam kampung"
- "1 bks santan cair"
- " Bahan tambahan"
- "1/2 ons soun rebus"
- "1 rb toge rebus sbntr"
- "2 rb kol rebus sebentar"
- "4 btr telor ayam rebus 20 menit"
- "1 batang sledri iris kecil"
- "2 buah jeruk limo"
- "1 buah tomat iris kasar"
- "3 batang daun bawangb iris"
- " Bawang goreng untuk taburan"
- " Bumbu halus"
- "7 siung bawang merah"
- "6 siung bawang putih"
- "4 butir kemiri"
- "1 ruas jahe"
- "1/2 ruas kunyit"
- "1/2 sdt kunyit bubuk"
- "1/2 sdt merica biji"
- "1/2 bks ketumbar biji 500 rupiah"
- "1/2 bks jinten 500 rupiah"
- "1/2 sdt pala biji"
- "3 butir cengkeh"
- "2 butir kapulaga"
- " Bumbu cemplung"
- "1 lmbr daun salam"
- "5 lmbr daun jeruk"
- "1 buah bunga lawang"
- "1/2 potong kayu manis"
- "1/2 ruas lengkuas"
- " Sambal nya"
- "10 biji cabe rawit merah"
- " Gulagaram"
- " Dibikin goang aja"
recipeinstructions:
- "Cuci bersih ayam nya potong2 sesuai keinginan"
- "Didihkan air dan klau sdh bersih ayam ny tinggal masukan ke rebusan air tadi geplek diapi sedang slma 20 menit lalu matikan kompor ny"
- "Haluskan bumbunya boleh pkai blender atau manual aja pke coet biar wanginya nampol klo diulek sendiri mah."
- "Kalo sudah halus semua siapkan minyak di ketel tumis2 hingga harum dan klo dah setengah mateng masukan bumbu cemplung nya dan aduk2 sampe mateng dan kalo sudah mateng kasih air sedikit aja segelas misal ny"
- "Lalu hidup kan lg kompor yg ayam tdi lalu masukan si bumbu ke ayam ny bila kurang air nya boleh tambah lg sesuai selera aja dan koreksi rasa ya bun"
- "Kalo sudah siap siapkan mangkok dan masukan soto nya tata semua bahan tambahan nya.maaf aku juga pke suwiran ayam lgi biar enak aj😁"
- "Siap dihidangkan deh bunda2"
categories:
- Resep
tags:
- soto
- santan
- ayam

katakunci: soto santan ayam 
nutrition: 221 calories
recipecuisine: Indonesian
preptime: "PT19M"
cooktime: "PT53M"
recipeyield: "3"
recipecategory: Dinner

---


![Soto santan ayam kampung](https://img-global.cpcdn.com/recipes/021e39922f7ad3fe/680x482cq70/soto-santan-ayam-kampung-foto-resep-utama.jpg)

Selaku seorang orang tua, menyediakan panganan lezat bagi keluarga merupakan hal yang menyenangkan untuk anda sendiri. Kewajiban seorang ibu bukan cuma menjaga rumah saja, tapi kamu pun harus memastikan kebutuhan gizi tercukupi dan panganan yang dikonsumsi orang tercinta mesti mantab.

Di era  saat ini, kamu sebenarnya bisa mengorder panganan siap saji walaupun tanpa harus ribet memasaknya terlebih dahulu. Tetapi banyak juga mereka yang selalu mau menyajikan yang terlezat untuk keluarganya. Sebab, menghidangkan masakan yang diolah sendiri jauh lebih higienis dan kita pun bisa menyesuaikan makanan tersebut sesuai dengan kesukaan keluarga tercinta. 



Apakah anda merupakan seorang penggemar soto santan ayam kampung?. Tahukah kamu, soto santan ayam kampung merupakan hidangan khas di Indonesia yang kini digemari oleh orang-orang di hampir setiap wilayah di Nusantara. Kamu dapat memasak soto santan ayam kampung kreasi sendiri di rumah dan boleh dijadikan makanan kesenanganmu di hari libur.

Kalian tidak usah bingung jika kamu ingin mendapatkan soto santan ayam kampung, karena soto santan ayam kampung gampang untuk ditemukan dan anda pun boleh membuatnya sendiri di rumah. soto santan ayam kampung bisa diolah memalui bermacam cara. Kini sudah banyak banget resep modern yang membuat soto santan ayam kampung semakin lebih mantap.

Resep soto santan ayam kampung pun mudah sekali dihidangkan, lho. Kamu jangan ribet-ribet untuk memesan soto santan ayam kampung, sebab Anda bisa membuatnya ditempatmu. Untuk Kita yang akan menghidangkannya, berikut cara untuk membuat soto santan ayam kampung yang nikamat yang dapat Kalian buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Soto santan ayam kampung:

1. Siapkan 1/2 kg ayam kampung
1. Gunakan 1 bks santan cair
1. Siapkan  Bahan tambahan
1. Gunakan 1/2 ons soun rebus
1. Gunakan 1 rb toge rebus sbntr
1. Gunakan 2 rb kol rebus sebentar
1. Siapkan 4 btr telor ayam rebus 20 menit
1. Gunakan 1 batang sledri iris kecil
1. Ambil 2 buah jeruk limo
1. Gunakan 1 buah tomat iris kasar
1. Siapkan 3 batang daun bawangb iris
1. Ambil  Bawang goreng untuk taburan
1. Sediakan  Bumbu halus
1. Gunakan 7 siung bawang merah
1. Siapkan 6 siung bawang putih
1. Ambil 4 butir kemiri
1. Gunakan 1 ruas jahe
1. Sediakan 1/2 ruas kunyit
1. Sediakan 1/2 sdt kunyit bubuk
1. Sediakan 1/2 sdt merica biji
1. Ambil 1/2 bks ketumbar biji 500 rupiah
1. Siapkan 1/2 bks jinten 500 rupiah
1. Siapkan 1/2 sdt pala biji
1. Siapkan 3 butir cengkeh
1. Siapkan 2 butir kapulaga
1. Siapkan  Bumbu cemplung
1. Siapkan 1 lmbr daun salam
1. Sediakan 5 lmbr daun jeruk
1. Ambil 1 buah bunga lawang
1. Ambil 1/2 potong kayu manis
1. Siapkan 1/2 ruas lengkuas
1. Sediakan  Sambal nya
1. Sediakan 10 biji cabe rawit merah
1. Siapkan  Gula+garam
1. Gunakan  Dibikin goang aja👍🏻




<!--inarticleads2-->

##### Cara menyiapkan Soto santan ayam kampung:

1. Cuci bersih ayam nya potong2 sesuai keinginan
1. Didihkan air dan klau sdh bersih ayam ny tinggal masukan ke rebusan air tadi geplek diapi sedang slma 20 menit lalu matikan kompor ny
1. Haluskan bumbunya boleh pkai blender atau manual aja pke coet biar wanginya nampol klo diulek sendiri mah.
1. Kalo sudah halus semua siapkan minyak di ketel tumis2 hingga harum dan klo dah setengah mateng masukan bumbu cemplung nya dan aduk2 sampe mateng dan kalo sudah mateng kasih air sedikit aja segelas misal ny
1. Lalu hidup kan lg kompor yg ayam tdi lalu masukan si bumbu ke ayam ny bila kurang air nya boleh tambah lg sesuai selera aja dan koreksi rasa ya bun
1. Kalo sudah siap siapkan mangkok dan masukan soto nya tata semua bahan tambahan nya.maaf aku juga pke suwiran ayam lgi biar enak aj😁
1. Siap dihidangkan deh bunda2




Wah ternyata cara buat soto santan ayam kampung yang mantab tidak rumit ini gampang sekali ya! Anda Semua dapat memasaknya. Cara Membuat soto santan ayam kampung Sangat sesuai banget untuk kita yang baru belajar memasak atau juga untuk anda yang telah hebat memasak.

Apakah kamu mau mulai mencoba membikin resep soto santan ayam kampung enak tidak rumit ini? Kalau kamu mau, mending kamu segera buruan menyiapkan peralatan dan bahan-bahannya, lantas bikin deh Resep soto santan ayam kampung yang mantab dan simple ini. Benar-benar mudah kan. 

Jadi, daripada kalian berlama-lama, maka langsung aja bikin resep soto santan ayam kampung ini. Dijamin kamu gak akan nyesel sudah buat resep soto santan ayam kampung nikmat simple ini! Selamat mencoba dengan resep soto santan ayam kampung lezat sederhana ini di rumah sendiri,oke!.

