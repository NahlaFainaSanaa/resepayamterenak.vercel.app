---
description: "Cara buat *Ayam Penyet Sambel Ijo* Sederhana dan Mudah Dibuat"
title: "Cara buat *Ayam Penyet Sambel Ijo* Sederhana dan Mudah Dibuat"
slug: 297-cara-buat-ayam-penyet-sambel-ijo-sederhana-dan-mudah-dibuat
date: 2021-06-24T18:27:32.061Z
image: https://img-global.cpcdn.com/recipes/4993dab0ad5c2e06/680x482cq70/ayam-penyet-sambel-ijo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4993dab0ad5c2e06/680x482cq70/ayam-penyet-sambel-ijo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4993dab0ad5c2e06/680x482cq70/ayam-penyet-sambel-ijo-foto-resep-utama.jpg
author: Minerva Moreno
ratingvalue: 3.5
reviewcount: 4
recipeingredient:
- "1/2 ekor ayam"
- "1 btg sereh"
- "2 lbr daun jeruk"
- " Bumbu ungkep ayam "
- "4 siung bwg merah Sy skip"
- "3 siung bwg putih"
- "1 ruas jahe"
- "1 ruas kunyit"
- "1 sdt ketumbar"
- "Secukupnya garam"
- "Secukupnya gula"
- "Secukupnya kaldu jamur sy skip"
- "Secukupnya air"
- " Bumbu sambel ijo "
- "8 cabe ijo keriting"
- "2 cabe ijo besar"
- "10 cabe rawit ijo"
- "1 buah tomat ijo"
- "3 siung bwg merah"
- "3 siung bwg putih"
- "2 sdm bumbu dasar cabe ijo tambahan sy           lihat resep"
recipeinstructions:
- "Cuci bersih ayam rebus hingga mendidih, angkat lalu rebus lagi bersama bumbu lainnya hingga bumbu meyerap dan airnya mengering. Lalu goreng hingga matang (sy, tidak terlalu kering), angkat sisihkan."
- "Cuci bahan sambal, potong2 lalu goreng hingga matang. Kemudian ulek kasar saja"
- "Tambahkan bumbu dasar cabe ijo, beri garam dan gula. Ulek hingga tercampur rata"
- "Taruh ayam goreng diatas.sambal lalu penyet dengan ulekan dan pindahkan dalam wadah saji"
- "Daan ayam penyet sambal ijo siap disajikan, ditambah perasan air jeruk nipis lebih enak"
categories:
- Resep
tags:
- ayam
- penyet
- sambel

katakunci: ayam penyet sambel 
nutrition: 285 calories
recipecuisine: Indonesian
preptime: "PT36M"
cooktime: "PT38M"
recipeyield: "2"
recipecategory: Lunch

---


![*Ayam Penyet Sambel Ijo*](https://img-global.cpcdn.com/recipes/4993dab0ad5c2e06/680x482cq70/ayam-penyet-sambel-ijo-foto-resep-utama.jpg)

Selaku seorang yang hobi masak, menyajikan santapan menggugah selera bagi famili adalah suatu hal yang sangat menyenangkan untuk anda sendiri. Peran seorang  wanita Tidak cuman menangani rumah saja, tapi anda juga harus memastikan keperluan gizi terpenuhi dan masakan yang disantap orang tercinta wajib sedap.

Di era  saat ini, kamu memang bisa memesan panganan siap saji walaupun tidak harus capek mengolahnya terlebih dahulu. Namun ada juga lho mereka yang memang mau memberikan makanan yang terenak bagi orang yang dicintainya. Lantaran, memasak yang diolah sendiri jauh lebih bersih dan kita pun bisa menyesuaikan hidangan tersebut berdasarkan makanan kesukaan keluarga. 



Mungkinkah kamu seorang penikmat *ayam penyet sambel ijo*?. Asal kamu tahu, *ayam penyet sambel ijo* adalah sajian khas di Indonesia yang kini disenangi oleh kebanyakan orang di berbagai tempat di Indonesia. Anda dapat membuat *ayam penyet sambel ijo* olahan sendiri di rumah dan dapat dijadikan camilan kesenanganmu di hari libur.

Kamu tidak perlu bingung jika kamu ingin memakan *ayam penyet sambel ijo*, sebab *ayam penyet sambel ijo* tidak sulit untuk dicari dan juga kita pun boleh menghidangkannya sendiri di tempatmu. *ayam penyet sambel ijo* boleh dimasak dengan bermacam cara. Kini pun ada banyak cara modern yang menjadikan *ayam penyet sambel ijo* lebih nikmat.

Resep *ayam penyet sambel ijo* pun sangat mudah dibuat, lho. Anda tidak perlu capek-capek untuk memesan *ayam penyet sambel ijo*, lantaran Kita bisa menyiapkan di rumah sendiri. Bagi Kalian yang hendak menghidangkannya, berikut cara menyajikan *ayam penyet sambel ijo* yang nikamat yang bisa Kalian hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan *Ayam Penyet Sambel Ijo*:

1. Ambil 1/2 ekor ayam
1. Ambil 1 btg sereh
1. Gunakan 2 lbr daun jeruk
1. Gunakan  Bumbu ungkep ayam :
1. Gunakan 4 siung bwg merah (Sy, skip)
1. Siapkan 3 siung bwg putih
1. Siapkan 1 ruas jahe
1. Ambil 1 ruas kunyit
1. Ambil 1 sdt ketumbar
1. Siapkan Secukupnya garam
1. Sediakan Secukupnya gula
1. Sediakan Secukupnya kaldu jamur (sy, skip)
1. Sediakan Secukupnya air
1. Ambil  Bumbu sambel ijo :
1. Gunakan 8 cabe ijo keriting
1. Siapkan 2 cabe ijo besar
1. Ambil 10 cabe rawit ijo
1. Siapkan 1 buah tomat ijo
1. Siapkan 3 siung bwg merah
1. Siapkan 3 siung bwg putih
1. Siapkan 2 sdm bumbu dasar cabe ijo (tambahan sy)           (lihat resep)




<!--inarticleads2-->

##### Langkah-langkah membuat *Ayam Penyet Sambel Ijo*:

1. Cuci bersih ayam rebus hingga mendidih, angkat lalu rebus lagi bersama bumbu lainnya hingga bumbu meyerap dan airnya mengering. Lalu goreng hingga matang (sy, tidak terlalu kering), angkat sisihkan.
1. Cuci bahan sambal, potong2 lalu goreng hingga matang. Kemudian ulek kasar saja
1. Tambahkan bumbu dasar cabe ijo, beri garam dan gula. Ulek hingga tercampur rata
1. Taruh ayam goreng diatas.sambal lalu penyet dengan ulekan dan pindahkan dalam wadah saji
1. Daan ayam penyet sambal ijo siap disajikan, ditambah perasan air jeruk nipis lebih enak




Wah ternyata resep *ayam penyet sambel ijo* yang lezat sederhana ini gampang banget ya! Anda Semua bisa memasaknya. Cara Membuat *ayam penyet sambel ijo* Sangat cocok sekali buat kamu yang baru akan belajar memasak atau juga untuk kalian yang sudah jago memasak.

Tertarik untuk mencoba bikin resep *ayam penyet sambel ijo* nikmat simple ini? Kalau kalian tertarik, mending kamu segera siapkan alat-alat dan bahannya, kemudian buat deh Resep *ayam penyet sambel ijo* yang lezat dan sederhana ini. Sangat gampang kan. 

Maka, daripada kamu berfikir lama-lama, maka langsung aja buat resep *ayam penyet sambel ijo* ini. Pasti kamu tak akan menyesal sudah bikin resep *ayam penyet sambel ijo* enak tidak ribet ini! Selamat berkreasi dengan resep *ayam penyet sambel ijo* mantab tidak rumit ini di rumah kalian masing-masing,oke!.

