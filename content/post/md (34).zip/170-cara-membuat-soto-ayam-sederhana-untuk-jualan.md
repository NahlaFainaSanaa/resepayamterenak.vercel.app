---
description: "Cara membuat Soto Ayam Sederhana Untuk Jualan"
title: "Cara membuat Soto Ayam Sederhana Untuk Jualan"
slug: 170-cara-membuat-soto-ayam-sederhana-untuk-jualan
date: 2021-06-09T23:55:42.423Z
image: https://img-global.cpcdn.com/recipes/a17fae7401ff89c3/680x482cq70/soto-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a17fae7401ff89c3/680x482cq70/soto-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a17fae7401ff89c3/680x482cq70/soto-ayam-foto-resep-utama.jpg
author: Henrietta Evans
ratingvalue: 3
reviewcount: 12
recipeingredient:
- "1 ekor Ayam belah jadi 4"
- "1500 ml Air"
- "2 batang Serai memarkan"
- "4 lembar Daun Jeruk"
- "2 cm Lengkuas memarkan"
- "1/4 sdt Lada bubuk"
- "Secukupnya Gula garam dan kaldu bubuk"
- " Bumbu Halus"
- "10 siung Bawang putih"
- "5 siung Bawang merah"
- "2 cm Jahe"
- "2 cm Kunyit"
- "4 butir Kemiri"
- " Pelengkap"
- "3 butir Telur rebu potong  potong"
- "4 lembar Kol iris halus"
- "100 gr Tauge"
- "2 bh Tomat potongpotong"
- "Beberapa lembar daun seledri rajang halus"
- "Secukupnya Bawang Merah goreng untuk taburan"
- "Secukupnya jeruk nipis untuk kecuran"
- " Sambal rebus cabai rawit haluskan dan beri tambahan gula dan garam secukupnya"
recipeinstructions:
- "Bersihkan ayam lalu rebus ayam sampai keluar kaldu dan ayam agak empuk. Haluskan bumbu dan tumis sampai harum, masukkan serai, daun jeruk, lengkuas dan lada bubuk, aduk-aduk sebentar. Masukkan bumbu tumis ke dalam rebusan ayam. Tambahkan gula, garam dan kaldu bubuk. Kecilkan api masak kira-kira 15 menit sampai bumbu meresap. Cicipi dan koreksi rasa."
- "Setelah ayam empuk, angkat dan goreng sebentar dengan sedikit minyak sampai ayam agak kecoklatan lalu suwir-suwir atau iris tipi sesuai selera. Siapkan pelengkap soto."
- "Hidangkan soto ayam dengan taburan kol rebus, irisan tomat, tauge, bawang goreng, telur rebus dan terakhir beri perasan jeruk nipis."
categories:
- Resep
tags:
- soto
- ayam

katakunci: soto ayam 
nutrition: 224 calories
recipecuisine: Indonesian
preptime: "PT17M"
cooktime: "PT49M"
recipeyield: "2"
recipecategory: Dessert

---


![Soto Ayam](https://img-global.cpcdn.com/recipes/a17fae7401ff89c3/680x482cq70/soto-ayam-foto-resep-utama.jpg)

Selaku seorang orang tua, menyuguhkan santapan mantab kepada famili adalah hal yang memuaskan bagi kamu sendiri. Kewajiban seorang istri bukan sekadar menjaga rumah saja, tapi anda pun harus memastikan kebutuhan nutrisi tercukupi dan juga panganan yang dikonsumsi keluarga tercinta mesti nikmat.

Di masa  sekarang, kamu sebenarnya dapat memesan hidangan jadi tidak harus ribet membuatnya terlebih dahulu. Tetapi ada juga mereka yang memang mau memberikan yang terbaik untuk orang yang dicintainya. Sebab, menyajikan masakan yang dibuat sendiri jauh lebih higienis dan kita juga bisa menyesuaikan masakan tersebut berdasarkan kesukaan keluarga tercinta. 



Apakah anda merupakan salah satu penggemar soto ayam?. Asal kamu tahu, soto ayam adalah hidangan khas di Nusantara yang sekarang disukai oleh kebanyakan orang di hampir setiap wilayah di Indonesia. Anda dapat menyajikan soto ayam sendiri di rumahmu dan pasti jadi camilan favoritmu di akhir pekanmu.

Anda tak perlu bingung jika kamu ingin mendapatkan soto ayam, lantaran soto ayam sangat mudah untuk dicari dan juga kita pun dapat memasaknya sendiri di rumah. soto ayam bisa dibuat lewat beragam cara. Kini pun ada banyak banget resep modern yang menjadikan soto ayam semakin mantap.

Resep soto ayam pun gampang sekali untuk dibikin, lho. Anda tidak perlu repot-repot untuk memesan soto ayam, sebab Kamu mampu menghidangkan di rumah sendiri. Untuk Anda yang mau menyajikannya, berikut resep untuk membuat soto ayam yang mantab yang bisa Kita hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Soto Ayam:

1. Ambil 1 ekor Ayam belah jadi 4
1. Ambil 1500 ml Air
1. Ambil 2 batang Serai, memarkan
1. Sediakan 4 lembar Daun Jeruk
1. Gunakan 2 cm Lengkuas, memarkan
1. Siapkan 1/4 sdt Lada bubuk
1. Sediakan Secukupnya Gula, garam dan kaldu bubuk
1. Ambil  Bumbu Halus:
1. Siapkan 10 siung Bawang putih
1. Sediakan 5 siung Bawang merah
1. Sediakan 2 cm Jahe
1. Siapkan 2 cm Kunyit
1. Sediakan 4 butir Kemiri
1. Siapkan  Pelengkap:
1. Siapkan 3 butir Telur rebu, potong - potong
1. Siapkan 4 lembar Kol, iris halus
1. Ambil 100 gr Tauge
1. Gunakan 2 bh Tomat, potong-potong
1. Gunakan Beberapa lembar daun seledri, rajang halus
1. Sediakan Secukupnya Bawang Merah goreng untuk taburan
1. Ambil Secukupnya jeruk nipis untuk kecuran
1. Ambil  Sambal: (rebus cabai rawit, haluskan dan beri tambahan gula dan garam secukupnya)




<!--inarticleads2-->

##### Cara membuat Soto Ayam:

1. Bersihkan ayam lalu rebus ayam sampai keluar kaldu dan ayam agak empuk. Haluskan bumbu dan tumis sampai harum, masukkan serai, daun jeruk, lengkuas dan lada bubuk, aduk-aduk sebentar. Masukkan bumbu tumis ke dalam rebusan ayam. Tambahkan gula, garam dan kaldu bubuk. Kecilkan api masak kira-kira 15 menit sampai bumbu meresap. Cicipi dan koreksi rasa.
1. Setelah ayam empuk, angkat dan goreng sebentar dengan sedikit minyak sampai ayam agak kecoklatan lalu suwir-suwir atau iris tipi sesuai selera. Siapkan pelengkap soto.
1. Hidangkan soto ayam dengan taburan kol rebus, irisan tomat, tauge, bawang goreng, telur rebus dan terakhir beri perasan jeruk nipis.




Ternyata cara buat soto ayam yang mantab simple ini gampang sekali ya! Semua orang mampu mencobanya. Cara Membuat soto ayam Sangat sesuai banget buat kita yang baru belajar memasak maupun bagi kamu yang telah lihai dalam memasak.

Apakah kamu mau mulai mencoba membikin resep soto ayam enak tidak ribet ini? Kalau mau, ayo kalian segera buruan menyiapkan alat-alat dan bahannya, kemudian bikin deh Resep soto ayam yang nikmat dan tidak ribet ini. Betul-betul gampang kan. 

Maka dari itu, daripada kalian diam saja, hayo kita langsung hidangkan resep soto ayam ini. Pasti kamu tak akan nyesel sudah bikin resep soto ayam nikmat simple ini! Selamat berkreasi dengan resep soto ayam mantab tidak ribet ini di tempat tinggal kalian sendiri,ya!.

