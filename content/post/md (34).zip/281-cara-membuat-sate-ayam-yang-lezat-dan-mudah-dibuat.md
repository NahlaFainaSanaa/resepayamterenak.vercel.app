---
description: "Cara membuat Sate Ayam yang lezat dan Mudah Dibuat"
title: "Cara membuat Sate Ayam yang lezat dan Mudah Dibuat"
slug: 281-cara-membuat-sate-ayam-yang-lezat-dan-mudah-dibuat
date: 2021-01-20T19:44:08.399Z
image: https://img-global.cpcdn.com/recipes/768e51f151560b19/680x482cq70/sate-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/768e51f151560b19/680x482cq70/sate-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/768e51f151560b19/680x482cq70/sate-ayam-foto-resep-utama.jpg
author: Bill Barnett
ratingvalue: 4.9
reviewcount: 10
recipeingredient:
- " Sate ayam"
- "1 ekor ayam ambil dagingnya saja dan potong dadu"
- "3 sdm kecap manis"
- "2 sdm mentega"
- "1 batang sereh memarkan lalu iris"
- "4 siung bawang merah iris"
- "1/4 sdt garam halus"
- "1/2 sdt gula pasir"
- "Sedikit lada saya skip"
- " Kuah kacang"
- "200 gr kacang tanah"
- "5 siung bawang putih"
- "5 siung bawang merah"
- "3 lembar daun jeruk"
- "2 butir kemiri"
- "5 buah cabe merah keriting"
- "2 buah limau kasturi"
- "1/2 sdt garam halus"
- "500 ml air"
- " Minyak goreng"
recipeinstructions:
- "Cuci daging ayam, baluri dengan sedikit cuka untuk menghilangkan bau amis, bilas"
- "Campurkan semua bahan kecap, mentega, bawang merah iris, sereh, garam, gula dan lada. Campur rata."
- "Masukkan daging ayam ke dalam bahan kecap, diamkan 30 menit agar bumbu meresap."
- "Tusuk ayam dengan tusukan sate, lalu bakar sampai matang, sisihkan"
- "Goreng kacang, bawang putih, bawang merah, cabe, kemiri sampai matang. Angkat, tunggu dingin, lalu blender sampai kehalusan yang diinginkan. Tambahkan sedikit air agar mudah blendernya."
- "Tumis kacang di atas api kecil. Tambahkan air, daun jeruk, garam, kecap. Masak sampai mengeluarkan minyak dan kental. Beri air perasan limau. Angkat"
- "Sajikan sate dengan kuah kacangnya. Tambahkan ketupat atau lontong sesuai selera. Taburi bawang goreng agar lebih nikmat."
- "Selamat menikmati"
categories:
- Resep
tags:
- sate
- ayam

katakunci: sate ayam 
nutrition: 256 calories
recipecuisine: Indonesian
preptime: "PT26M"
cooktime: "PT54M"
recipeyield: "1"
recipecategory: Lunch

---


![Sate Ayam](https://img-global.cpcdn.com/recipes/768e51f151560b19/680x482cq70/sate-ayam-foto-resep-utama.jpg)

Andai kamu seorang orang tua, menyuguhkan olahan sedap bagi keluarga adalah hal yang menggembirakan bagi anda sendiri. Kewajiban seorang  wanita bukan cuman mengatur rumah saja, tapi anda juga harus memastikan keperluan gizi tercukupi dan juga panganan yang disantap anak-anak harus sedap.

Di era  sekarang, anda sebenarnya dapat memesan olahan instan walaupun tidak harus ribet mengolahnya terlebih dahulu. Namun ada juga mereka yang memang mau memberikan hidangan yang terbaik untuk keluarganya. Lantaran, menyajikan masakan yang dibuat sendiri jauh lebih bersih dan bisa menyesuaikan makanan tersebut sesuai selera orang tercinta. 



Apakah anda salah satu penyuka sate ayam?. Tahukah kamu, sate ayam adalah hidangan khas di Nusantara yang saat ini digemari oleh banyak orang di berbagai daerah di Nusantara. Kita dapat membuat sate ayam kreasi sendiri di rumahmu dan boleh dijadikan santapan kegemaranmu di hari libur.

Kalian jangan bingung untuk mendapatkan sate ayam, sebab sate ayam tidak sulit untuk ditemukan dan kalian pun dapat menghidangkannya sendiri di rumah. sate ayam dapat diolah lewat berbagai cara. Kini sudah banyak cara modern yang membuat sate ayam semakin lebih lezat.

Resep sate ayam pun gampang untuk dibikin, lho. Kamu jangan ribet-ribet untuk memesan sate ayam, karena Kalian dapat membuatnya sendiri di rumah. Untuk Anda yang akan menghidangkannya, di bawah ini adalah resep untuk membuat sate ayam yang mantab yang bisa Kamu coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Sate Ayam:

1. Gunakan  Sate ayam
1. Ambil 1 ekor ayam, ambil dagingnya saja dan potong dadu
1. Sediakan 3 sdm kecap manis
1. Sediakan 2 sdm mentega
1. Gunakan 1 batang sereh, memarkan, lalu iris
1. Siapkan 4 siung bawang merah, iris
1. Gunakan 1/4 sdt garam halus
1. Ambil 1/2 sdt gula pasir
1. Siapkan Sedikit lada (saya skip)
1. Gunakan  Kuah kacang
1. Sediakan 200 gr kacang tanah
1. Sediakan 5 siung bawang putih
1. Sediakan 5 siung bawang merah
1. Gunakan 3 lembar daun jeruk
1. Ambil 2 butir kemiri
1. Siapkan 5 buah cabe merah keriting
1. Sediakan 2 buah limau kasturi
1. Ambil 1/2 sdt garam halus
1. Gunakan 500 ml air
1. Ambil  Minyak goreng




<!--inarticleads2-->

##### Langkah-langkah membuat Sate Ayam:

1. Cuci daging ayam, baluri dengan sedikit cuka untuk menghilangkan bau amis, bilas
1. Campurkan semua bahan kecap, mentega, bawang merah iris, sereh, garam, gula dan lada. Campur rata.
1. Masukkan daging ayam ke dalam bahan kecap, diamkan 30 menit agar bumbu meresap.
1. Tusuk ayam dengan tusukan sate, lalu bakar sampai matang, sisihkan
1. Goreng kacang, bawang putih, bawang merah, cabe, kemiri sampai matang. Angkat, tunggu dingin, lalu blender sampai kehalusan yang diinginkan. Tambahkan sedikit air agar mudah blendernya.
1. Tumis kacang di atas api kecil. Tambahkan air, daun jeruk, garam, kecap. Masak sampai mengeluarkan minyak dan kental. Beri air perasan limau. Angkat
1. Sajikan sate dengan kuah kacangnya. Tambahkan ketupat atau lontong sesuai selera. Taburi bawang goreng agar lebih nikmat.
1. Selamat menikmati




Ternyata cara membuat sate ayam yang mantab tidak rumit ini mudah banget ya! Anda Semua dapat membuatnya. Cara Membuat sate ayam Sesuai sekali buat kita yang sedang belajar memasak ataupun juga bagi anda yang telah pandai dalam memasak.

Tertarik untuk mulai mencoba membuat resep sate ayam enak tidak ribet ini? Kalau anda mau, ayo kamu segera buruan menyiapkan peralatan dan bahannya, kemudian buat deh Resep sate ayam yang mantab dan simple ini. Sungguh gampang kan. 

Maka dari itu, ketimbang anda berfikir lama-lama, yuk kita langsung sajikan resep sate ayam ini. Dijamin kalian tak akan menyesal bikin resep sate ayam lezat simple ini! Selamat berkreasi dengan resep sate ayam lezat tidak rumit ini di tempat tinggal kalian sendiri,ya!.

