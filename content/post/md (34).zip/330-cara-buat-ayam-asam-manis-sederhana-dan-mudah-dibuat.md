---
description: "Cara buat Ayam Asam Manis Sederhana dan Mudah Dibuat"
title: "Cara buat Ayam Asam Manis Sederhana dan Mudah Dibuat"
slug: 330-cara-buat-ayam-asam-manis-sederhana-dan-mudah-dibuat
date: 2021-04-11T22:20:05.314Z
image: https://img-global.cpcdn.com/recipes/80e6ad2114afe65c/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/80e6ad2114afe65c/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/80e6ad2114afe65c/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
author: Louisa Brooks
ratingvalue: 4.8
reviewcount: 3
recipeingredient:
- "1 Kg Ayam potong 10 bagian"
- "1 Buah Bawang Bombay iris tipis"
- "4 Siung Bawang Putih cincang kasar"
- "6 Buah Tomat Kecil belah 2"
- "2 Ruas Jahe geprek"
- "135 Ml Saus Tomat"
- "2 Sdm Kecap Manis"
- "1 Sdm Saus Tiram"
- "1 Sdt Kaldu Ayam Bubuk"
- "1/2 Sdt Garam"
- "1 Sdt Gula Pasir"
- "secukupnya Minyak goreng"
recipeinstructions:
- "Goreng ayam hingga kecoklatan, lalu angkat dan tiriskan."
- "Tumis bawang putih dan jahe hingga harum lalu masukkan bawang bombay masak hingga layu. Lalu, masukkan ayam yang sudah digoreng dan tambahkan air. Masak sampai ayam matang sempurna dan kuah agak menyusut."
- "Lalu masukkan saus tomat, saus tiram, kecap, kaldu ayam, potongan tomat, garam dan gula pasir. Masak hingga mengental. Cek rasa."
- "Jika dirasa sudah pas, tata dalam piring saji. Selamat mencoba."
categories:
- Resep
tags:
- ayam
- asam
- manis

katakunci: ayam asam manis 
nutrition: 236 calories
recipecuisine: Indonesian
preptime: "PT10M"
cooktime: "PT42M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam Asam Manis](https://img-global.cpcdn.com/recipes/80e6ad2114afe65c/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg)

Sebagai seorang orang tua, menyediakan santapan nikmat bagi keluarga tercinta adalah suatu hal yang memuaskan bagi kita sendiri. Kewajiban seorang ibu Tidak sekadar mengurus rumah saja, tapi anda juga wajib menyediakan kebutuhan gizi tercukupi dan juga masakan yang dimakan anak-anak harus sedap.

Di waktu  sekarang, kita sebenarnya mampu mengorder panganan yang sudah jadi walaupun tanpa harus ribet memasaknya terlebih dahulu. Namun banyak juga lho orang yang selalu ingin memberikan hidangan yang terenak untuk orang yang dicintainya. Sebab, memasak yang diolah sendiri akan jauh lebih higienis dan bisa menyesuaikan masakan tersebut sesuai makanan kesukaan keluarga. 



Mungkinkah anda salah satu penikmat ayam asam manis?. Asal kamu tahu, ayam asam manis adalah hidangan khas di Indonesia yang kini disukai oleh orang-orang di berbagai daerah di Nusantara. Anda bisa membuat ayam asam manis buatan sendiri di rumahmu dan dapat dijadikan camilan kegemaranmu di akhir pekanmu.

Kalian tak perlu bingung untuk memakan ayam asam manis, lantaran ayam asam manis tidak sukar untuk ditemukan dan juga kamu pun bisa menghidangkannya sendiri di rumah. ayam asam manis bisa dimasak memalui berbagai cara. Sekarang telah banyak resep kekinian yang membuat ayam asam manis semakin lebih nikmat.

Resep ayam asam manis pun mudah sekali untuk dibuat, lho. Kamu tidak perlu ribet-ribet untuk memesan ayam asam manis, lantaran Kamu dapat menyajikan di rumah sendiri. Untuk Anda yang hendak mencobanya, berikut resep untuk membuat ayam asam manis yang enak yang bisa Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Ayam Asam Manis:

1. Gunakan 1 Kg Ayam, potong 10 bagian
1. Sediakan 1 Buah Bawang Bombay, iris tipis
1. Siapkan 4 Siung Bawang Putih, cincang kasar
1. Siapkan 6 Buah Tomat Kecil, belah 2
1. Ambil 2 Ruas Jahe, geprek
1. Ambil 135 Ml Saus Tomat
1. Sediakan 2 Sdm Kecap Manis
1. Siapkan 1 Sdm Saus Tiram
1. Siapkan 1 Sdt Kaldu Ayam Bubuk
1. Sediakan 1/2 Sdt Garam
1. Gunakan 1 Sdt Gula Pasir
1. Ambil secukupnya Minyak goreng




<!--inarticleads2-->

##### Cara menyiapkan Ayam Asam Manis:

1. Goreng ayam hingga kecoklatan, lalu angkat dan tiriskan.
1. Tumis bawang putih dan jahe hingga harum lalu masukkan bawang bombay masak hingga layu. Lalu, masukkan ayam yang sudah digoreng dan tambahkan air. Masak sampai ayam matang sempurna dan kuah agak menyusut.
1. Lalu masukkan saus tomat, saus tiram, kecap, kaldu ayam, potongan tomat, garam dan gula pasir. Masak hingga mengental. Cek rasa.
1. Jika dirasa sudah pas, tata dalam piring saji. Selamat mencoba.




Wah ternyata resep ayam asam manis yang mantab tidak rumit ini mudah sekali ya! Kalian semua dapat mencobanya. Cara buat ayam asam manis Cocok sekali untuk kamu yang baru mau belajar memasak maupun juga bagi kalian yang sudah lihai dalam memasak.

Apakah kamu ingin mencoba buat resep ayam asam manis nikmat tidak ribet ini? Kalau kalian ingin, yuk kita segera buruan menyiapkan peralatan dan bahannya, kemudian bikin deh Resep ayam asam manis yang enak dan sederhana ini. Sungguh taidak sulit kan. 

Maka, daripada anda diam saja, hayo langsung aja buat resep ayam asam manis ini. Dijamin kamu tak akan nyesel membuat resep ayam asam manis lezat simple ini! Selamat berkreasi dengan resep ayam asam manis lezat simple ini di tempat tinggal sendiri,ya!.

