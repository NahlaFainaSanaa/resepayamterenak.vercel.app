---
description: "Cara buat Ayam lodho yang enak dan Mudah Dibuat"
title: "Cara buat Ayam lodho yang enak dan Mudah Dibuat"
slug: 208-cara-buat-ayam-lodho-yang-enak-dan-mudah-dibuat
date: 2021-05-18T15:07:01.068Z
image: https://img-global.cpcdn.com/recipes/485d75d573110fec/680x482cq70/ayam-lodho-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/485d75d573110fec/680x482cq70/ayam-lodho-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/485d75d573110fec/680x482cq70/ayam-lodho-foto-resep-utama.jpg
author: Ellen Flores
ratingvalue: 3.7
reviewcount: 8
recipeingredient:
- "1 kg ayam kampung potong sesuai selerame kecil2"
- "500 ml Air kl mau byk kuah tambahkan air sesuai selera"
- "1-2 bungkus santan instan"
- " Bahan yg di haluskan"
- "8 siung bawang merah"
- "7 siung bawang putih"
- "2 ruas jari jahe"
- "2 bh kencur"
- "1 ruas jari kunyitme bubuk"
- "1 sdm ketumbar me bubuk"
- "1 sdt merica bubukme bubuk"
- "1 sdt jinten bubukme bubuk"
- "4 buah Kemiri"
- "2 buah cabe merah besar"
- "10 buah cabe rawitsesuai selera"
- " Bahan yg d blender kasardi tumbuk"
- "1 btg sere"
- "1 ruas jari laos"
- "2 lembar daun jeruk"
- "1 lembar daun salam"
- " Bahan tambahan"
- "1 sdm garam"
- "50 gr gula merah"
- "Secukupnya penyedap rasa"
- "1 sdm air asam jawa"
recipeinstructions:
- "Bersihkan ayam lumuri dengan garam kemudian panggang ayam sampe setengah matang"
- "Tumis bumbu yg sdh d haluskan tambahkan bahan yg sdh d blender kasar masak sampe harum"
- "Masukan ayam aduk sebentar sampe ayam tercampur semua ke bumbu kemudian masukan air dan bahan tambahan(takaran bisa d tambahkan menurut selera)"
- "Masak dengan api kecil sampe ayam empuk setelah empuk masukan santan didihkan,setelah mendidih matikan api.ayam lodho siap d hidangkan"
categories:
- Resep
tags:
- ayam
- lodho

katakunci: ayam lodho 
nutrition: 104 calories
recipecuisine: Indonesian
preptime: "PT35M"
cooktime: "PT34M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam lodho](https://img-global.cpcdn.com/recipes/485d75d573110fec/680x482cq70/ayam-lodho-foto-resep-utama.jpg)

Selaku seorang ibu, mempersiapkan hidangan sedap bagi keluarga tercinta adalah hal yang mengasyikan untuk anda sendiri. Tugas seorang ibu bukan sekadar menangani rumah saja, namun anda juga harus memastikan keperluan gizi tercukupi dan juga masakan yang dikonsumsi keluarga tercinta wajib sedap.

Di waktu  sekarang, kamu sebenarnya dapat membeli panganan praktis tidak harus repot membuatnya dulu. Tapi ada juga lho mereka yang memang ingin menyajikan yang terenak untuk orang yang dicintainya. Sebab, menghidangkan masakan yang dibuat sendiri jauh lebih bersih dan kita pun bisa menyesuaikan masakan tersebut sesuai makanan kesukaan keluarga. 



Apakah anda salah satu penggemar ayam lodho?. Tahukah kamu, ayam lodho merupakan sajian khas di Indonesia yang sekarang disenangi oleh kebanyakan orang di berbagai daerah di Nusantara. Kalian bisa menyajikan ayam lodho buatan sendiri di rumah dan dapat dijadikan santapan kegemaranmu di hari liburmu.

Kamu tidak perlu bingung untuk mendapatkan ayam lodho, lantaran ayam lodho tidak sulit untuk ditemukan dan kalian pun dapat mengolahnya sendiri di rumah. ayam lodho bisa diolah lewat beragam cara. Sekarang telah banyak sekali resep modern yang membuat ayam lodho semakin lezat.

Resep ayam lodho pun sangat mudah dihidangkan, lho. Anda jangan ribet-ribet untuk membeli ayam lodho, lantaran Kita bisa menyajikan sendiri di rumah. Untuk Kalian yang hendak menyajikannya, dibawah ini merupakan resep untuk membuat ayam lodho yang mantab yang bisa Anda buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Ayam lodho:

1. Sediakan 1 kg ayam kampung potong sesuai selera(me kecil2)
1. Gunakan 500 ml Air kl mau byk kuah tambahkan air sesuai selera
1. Gunakan 1-2 bungkus santan instan
1. Sediakan  Bahan yg di haluskan
1. Siapkan 8 siung bawang merah
1. Gunakan 7 siung bawang putih
1. Gunakan 2 ruas jari jahe
1. Siapkan 2 bh kencur
1. Gunakan 1 ruas jari kunyit(me bubuk)
1. Gunakan 1 sdm ketumbar (me bubuk)
1. Sediakan 1 sdt merica bubuk(me bubuk)
1. Siapkan 1 sdt jinten bubuk(me bubuk)
1. Sediakan 4 buah Kemiri
1. Siapkan 2 buah cabe merah besar
1. Siapkan 10 buah cabe rawit(sesuai selera)
1. Sediakan  Bahan yg d blender kasar/di tumbuk
1. Gunakan 1 btg sere,
1. Sediakan 1 ruas jari laos
1. Ambil 2 lembar daun jeruk
1. Ambil 1 lembar daun salam
1. Siapkan  Bahan tambahan
1. Gunakan 1 sdm garam
1. Ambil 50 gr gula merah
1. Sediakan Secukupnya penyedap rasa
1. Ambil 1 sdm air asam jawa




<!--inarticleads2-->

##### Cara menyiapkan Ayam lodho:

1. Bersihkan ayam lumuri dengan garam kemudian panggang ayam sampe setengah matang
1. Tumis bumbu yg sdh d haluskan tambahkan bahan yg sdh d blender kasar masak sampe harum
1. Masukan ayam aduk sebentar sampe ayam tercampur semua ke bumbu kemudian masukan air dan bahan tambahan(takaran bisa d tambahkan menurut selera)
1. Masak dengan api kecil sampe ayam empuk setelah empuk masukan santan didihkan,setelah mendidih matikan api.ayam lodho siap d hidangkan




Ternyata cara buat ayam lodho yang mantab tidak rumit ini mudah banget ya! Kita semua dapat membuatnya. Cara Membuat ayam lodho Sesuai sekali untuk anda yang baru mau belajar memasak atau juga bagi kamu yang telah pandai dalam memasak.

Tertarik untuk mulai mencoba bikin resep ayam lodho enak tidak ribet ini? Kalau kamu ingin, ayo kamu segera menyiapkan peralatan dan bahan-bahannya, maka buat deh Resep ayam lodho yang enak dan simple ini. Sungguh taidak sulit kan. 

Oleh karena itu, ketimbang kita berlama-lama, maka kita langsung saja buat resep ayam lodho ini. Pasti anda tak akan menyesal bikin resep ayam lodho mantab tidak ribet ini! Selamat berkreasi dengan resep ayam lodho lezat tidak rumit ini di tempat tinggal sendiri,oke!.

