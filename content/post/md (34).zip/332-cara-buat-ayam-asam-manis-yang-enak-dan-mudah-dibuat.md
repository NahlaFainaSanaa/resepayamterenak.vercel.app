---
description: "Cara buat Ayam Asam Manis yang enak dan Mudah Dibuat"
title: "Cara buat Ayam Asam Manis yang enak dan Mudah Dibuat"
slug: 332-cara-buat-ayam-asam-manis-yang-enak-dan-mudah-dibuat
date: 2021-05-27T10:00:47.305Z
image: https://img-global.cpcdn.com/recipes/85990fdeca0520b5/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/85990fdeca0520b5/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/85990fdeca0520b5/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
author: Evan Lee
ratingvalue: 4.8
reviewcount: 10
recipeingredient:
- "250 gr ayam"
- "1 sdt garam"
- "2 sdm saus tiram"
- "2 sdm kecap"
- "2 sdt gula"
- "1 buah jeruk nipis peras"
- "1 sendok tepung maizena cairkan dengan air 100 ml"
- "1/2 buah bawang bombai"
- "3 siung bawang putih cincang halus"
- "2 buah cabe besar hijau cincang halus"
- "2 buah cabe besar merah cincang halus"
- "3 buah cabe rawit cincang halus"
- "1 buah tomat cincang halus"
- "1 cm jahe cincang halus"
- "1 daun daun bawang potong serong"
recipeinstructions:
- "Tumis semua bahan (cabe, bawang, tomat, jahe) sampai matang dan harum."
- "Masukkan air jeruk, garam, kecap, gula, dan saus tiram, aduk sampai rata."
- "Masukkan tepung maizena yang sudah di cairkan dengan air 100 ml."
- "Lalu masukkan ayam, masak hingga matang."
- "Masukkan daun bawang yg sudah di potong. Aduk lalu angkat dan sajikan."
categories:
- Resep
tags:
- ayam
- asam
- manis

katakunci: ayam asam manis 
nutrition: 109 calories
recipecuisine: Indonesian
preptime: "PT31M"
cooktime: "PT39M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Asam Manis](https://img-global.cpcdn.com/recipes/85990fdeca0520b5/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg)

Sebagai seorang orang tua, menyuguhkan masakan menggugah selera pada keluarga tercinta adalah hal yang sangat menyenangkan untuk kamu sendiri. Tugas seorang  wanita bukan hanya mengurus rumah saja, tetapi kamu juga wajib menyediakan keperluan gizi tercukupi dan juga panganan yang dikonsumsi orang tercinta mesti menggugah selera.

Di waktu  saat ini, anda memang dapat memesan panganan praktis meski tanpa harus capek membuatnya dulu. Namun ada juga orang yang memang mau memberikan hidangan yang terlezat untuk orang yang dicintainya. Karena, menghidangkan masakan yang dibuat sendiri jauh lebih higienis dan kita pun bisa menyesuaikan masakan tersebut berdasarkan makanan kesukaan keluarga. 



Apakah anda adalah salah satu penikmat ayam asam manis?. Asal kamu tahu, ayam asam manis merupakan hidangan khas di Indonesia yang sekarang disenangi oleh kebanyakan orang di berbagai daerah di Indonesia. Kalian dapat menyajikan ayam asam manis buatan sendiri di rumahmu dan pasti jadi makanan favoritmu di hari liburmu.

Anda jangan bingung jika kamu ingin mendapatkan ayam asam manis, karena ayam asam manis tidak sulit untuk ditemukan dan anda pun dapat memasaknya sendiri di rumah. ayam asam manis boleh dimasak memalui berbagai cara. Kini pun sudah banyak resep kekinian yang menjadikan ayam asam manis lebih enak.

Resep ayam asam manis pun mudah sekali untuk dibuat, lho. Kalian tidak perlu repot-repot untuk membeli ayam asam manis, lantaran Kita bisa menyiapkan di rumahmu. Untuk Kamu yang ingin mencobanya, berikut ini cara menyajikan ayam asam manis yang mantab yang mampu Anda hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Ayam Asam Manis:

1. Siapkan 250 gr ayam
1. Gunakan 1 sdt garam
1. Sediakan 2 sdm saus tiram
1. Ambil 2 sdm kecap
1. Sediakan 2 sdt gula
1. Sediakan 1 buah jeruk nipis, peras
1. Sediakan 1 sendok tepung maizena, cairkan dengan air 100 ml
1. Siapkan 1/2 buah bawang bombai
1. Siapkan 3 siung bawang putih, cincang halus
1. Ambil 2 buah cabe besar hijau, cincang halus
1. Sediakan 2 buah cabe besar merah, cincang halus
1. Siapkan 3 buah cabe rawit, cincang halus
1. Ambil 1 buah tomat, cincang halus
1. Sediakan 1 cm jahe, cincang halus
1. Ambil 1 daun daun bawang, potong serong




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam Asam Manis:

1. Tumis semua bahan (cabe, bawang, tomat, jahe) sampai matang dan harum.
1. Masukkan air jeruk, garam, kecap, gula, dan saus tiram, aduk sampai rata.
1. Masukkan tepung maizena yang sudah di cairkan dengan air 100 ml.
1. Lalu masukkan ayam, masak hingga matang.
1. Masukkan daun bawang yg sudah di potong. Aduk lalu angkat dan sajikan.




Ternyata cara membuat ayam asam manis yang enak tidak ribet ini mudah banget ya! Kamu semua mampu membuatnya. Cara Membuat ayam asam manis Sangat cocok sekali untuk kita yang baru mau belajar memasak maupun juga untuk kamu yang sudah jago memasak.

Tertarik untuk mulai mencoba membikin resep ayam asam manis mantab tidak rumit ini? Kalau kalian mau, ayo kamu segera buruan siapkan alat dan bahannya, maka bikin deh Resep ayam asam manis yang enak dan sederhana ini. Benar-benar gampang kan. 

Jadi, daripada kalian berlama-lama, maka kita langsung saja bikin resep ayam asam manis ini. Dijamin anda tak akan menyesal membuat resep ayam asam manis mantab simple ini! Selamat mencoba dengan resep ayam asam manis mantab tidak ribet ini di rumah sendiri,oke!.

