---
description: "Bahan-bahan Soto Ayam Kuah Santan yang enak dan Mudah Dibuat"
title: "Bahan-bahan Soto Ayam Kuah Santan yang enak dan Mudah Dibuat"
slug: 400-bahan-bahan-soto-ayam-kuah-santan-yang-enak-dan-mudah-dibuat
date: 2021-06-02T17:34:19.563Z
image: https://img-global.cpcdn.com/recipes/5c8e172e544fb9d4/680x482cq70/soto-ayam-kuah-santan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5c8e172e544fb9d4/680x482cq70/soto-ayam-kuah-santan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5c8e172e544fb9d4/680x482cq70/soto-ayam-kuah-santan-foto-resep-utama.jpg
author: Roy Pope
ratingvalue: 3.5
reviewcount: 15
recipeingredient:
- "1/2 kg ayam"
- "1 bks kara santan"
- "1,5 liter air"
- "1 batang sereh"
- "1 ruas lengkuas"
- "2 lembar daun salam"
- "5 lembar daun jeruk"
- "1 tomat"
- "2 daun bawang"
- "Secukupnya bawang goreng"
- "2 jeruk limau"
- "1/2 sdt garam"
- "1 sdm gula"
- " Bumbu halus "
- "5 bawang putih"
- "10 bawang merah"
- "2 ruas kunyit"
- "3 kemiri"
- "1/2 sdt lada"
recipeinstructions:
- "Tumis bumbu halus hingga harum, tambahkan sereh, lengkuas, daun salam, daun jeruk."
- "Masukkan ayam yang telah dicuci bersih dan dipotong*.Tambahkan air, biarkan meresap dan ayam lunak."
- "Masukkan santan, garam, kaldu, gula. Aduk rata, jangan lupa koreksi rasa."
- "Jika sudah, siapkan mangkuk, masukkan kuah, beri potongan tomat, daun bawang, bawang goreng, perasan jeruk limau dan sajikan."
categories:
- Resep
tags:
- soto
- ayam
- kuah

katakunci: soto ayam kuah 
nutrition: 293 calories
recipecuisine: Indonesian
preptime: "PT33M"
cooktime: "PT33M"
recipeyield: "4"
recipecategory: Lunch

---


![Soto Ayam Kuah Santan](https://img-global.cpcdn.com/recipes/5c8e172e544fb9d4/680x482cq70/soto-ayam-kuah-santan-foto-resep-utama.jpg)

Sebagai seorang istri, mempersiapkan olahan lezat bagi famili adalah hal yang menyenangkan bagi kamu sendiri. Kewajiban seorang ibu Tidak sekadar mengatur rumah saja, namun kamu pun wajib memastikan keperluan gizi tercukupi dan juga hidangan yang disantap keluarga tercinta harus menggugah selera.

Di waktu  sekarang, kamu memang dapat memesan masakan praktis meski tidak harus capek memasaknya lebih dulu. Namun banyak juga mereka yang selalu ingin memberikan hidangan yang terenak untuk orang yang dicintainya. Karena, menghidangkan masakan yang diolah sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan hidangan tersebut sesuai makanan kesukaan keluarga. 



Mungkinkah anda merupakan salah satu penikmat soto ayam kuah santan?. Asal kamu tahu, soto ayam kuah santan merupakan makanan khas di Indonesia yang saat ini disenangi oleh orang-orang di hampir setiap daerah di Nusantara. Anda dapat memasak soto ayam kuah santan sendiri di rumah dan dapat dijadikan santapan favorit di akhir pekan.

Kamu tak perlu bingung jika kamu ingin memakan soto ayam kuah santan, lantaran soto ayam kuah santan mudah untuk didapatkan dan kita pun boleh mengolahnya sendiri di rumah. soto ayam kuah santan bisa diolah lewat beragam cara. Kini telah banyak sekali cara kekinian yang menjadikan soto ayam kuah santan semakin mantap.

Resep soto ayam kuah santan pun mudah sekali untuk dibikin, lho. Kalian jangan capek-capek untuk membeli soto ayam kuah santan, sebab Kamu dapat menghidangkan sendiri di rumah. Untuk Anda yang mau menyajikannya, dibawah ini merupakan cara menyajikan soto ayam kuah santan yang enak yang dapat Kamu hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Soto Ayam Kuah Santan:

1. Gunakan 1/2 kg ayam
1. Ambil 1 bks kara santan
1. Gunakan 1,5 liter air
1. Gunakan 1 batang sereh
1. Siapkan 1 ruas lengkuas
1. Ambil 2 lembar daun salam
1. Ambil 5 lembar daun jeruk
1. Sediakan 1 tomat
1. Siapkan 2 daun bawang
1. Sediakan Secukupnya bawang goreng
1. Siapkan 2 jeruk limau
1. Sediakan 1/2 sdt garam
1. Siapkan 1 sdm gula
1. Gunakan  Bumbu halus :
1. Gunakan 5 bawang putih
1. Siapkan 10 bawang merah
1. Sediakan 2 ruas kunyit
1. Sediakan 3 kemiri
1. Siapkan 1/2 sdt lada




<!--inarticleads2-->

##### Langkah-langkah membuat Soto Ayam Kuah Santan:

1. Tumis bumbu halus hingga harum, tambahkan sereh, lengkuas, daun salam, daun jeruk.
1. Masukkan ayam yang telah dicuci bersih dan dipotong*.Tambahkan air, biarkan meresap dan ayam lunak.
1. Masukkan santan, garam, kaldu, gula. Aduk rata, jangan lupa koreksi rasa.
1. Jika sudah, siapkan mangkuk, masukkan kuah, beri potongan tomat, daun bawang, bawang goreng, perasan jeruk limau dan sajikan.




Wah ternyata resep soto ayam kuah santan yang mantab tidak rumit ini gampang sekali ya! Kalian semua mampu mencobanya. Resep soto ayam kuah santan Sesuai banget buat anda yang baru belajar memasak ataupun juga bagi kalian yang sudah jago dalam memasak.

Apakah kamu tertarik mencoba membikin resep soto ayam kuah santan mantab tidak ribet ini? Kalau kamu ingin, yuk kita segera buruan menyiapkan alat dan bahan-bahannya, maka buat deh Resep soto ayam kuah santan yang nikmat dan simple ini. Benar-benar gampang kan. 

Maka, daripada anda berfikir lama-lama, yuk kita langsung saja bikin resep soto ayam kuah santan ini. Dijamin kalian gak akan menyesal membuat resep soto ayam kuah santan mantab simple ini! Selamat mencoba dengan resep soto ayam kuah santan lezat tidak rumit ini di rumah masing-masing,ya!.

