---
description: "Cara membuat Ayam Goreng Saus Asam Pedas Manis Sederhana Untuk Jualan"
title: "Cara membuat Ayam Goreng Saus Asam Pedas Manis Sederhana Untuk Jualan"
slug: 128-cara-membuat-ayam-goreng-saus-asam-pedas-manis-sederhana-untuk-jualan
date: 2021-03-07T15:50:34.951Z
image: https://img-global.cpcdn.com/recipes/8bd57cc2d6b25f39/680x482cq70/ayam-goreng-saus-asam-pedas-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8bd57cc2d6b25f39/680x482cq70/ayam-goreng-saus-asam-pedas-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8bd57cc2d6b25f39/680x482cq70/ayam-goreng-saus-asam-pedas-manis-foto-resep-utama.jpg
author: Bettie Goodwin
ratingvalue: 3.5
reviewcount: 14
recipeingredient:
- " Bahanbahan utama"
- "1 bungkus ayam paha atau dada fillet 10 potong"
- " BahanBahan Bumbu Ayam"
- "1 butir telurputih  kuning"
- "1/1/4 sendok tepung terigu"
- "2 sendok makan tepung maizena"
- "1/1/2 sendok teh garam"
- " BahanBahan Bumbu Ayam"
- "2 sendok makan Thai Tom Yam Paste lihat gambar di bagian step"
- "3 siung bawang putih cincang kecilkecil"
- "3 sendok makan saus tiram"
- "2 sendok makan cuka putih"
- "3 sendok makan cabe murah bubuk"
- "1 sendok makan fish sauce kecap ikan"
- "1 gelas kecil teh air"
- " BahanBahan Pelengkap Bumbu"
- "4 helai daun jeruk purut cincang kecilkecil"
- "1 buah jeruk lemon hijau lime ambil jusnya"
- "1/2 kulit jeruk lemon hijau kupas kulitnya"
- "3/4 gelas tepung terigu"
- "1/4 gelas tepung maizena"
recipeinstructions:
- "Cuci ayam hingga bersih lalu lumuri dua permukaan ayam dengan bahan-bahan sebagai berikiut lalu kocok dan diamkan selama 15 menit : tepung maizena, garam dan 1 butir telur kocok (putih dan kuning telur)."
- "Inilah gambar &#34;Thai Tom Yam Paste&#34; yang saya buat setahun yang lalu."
- "Masukan lalu campurkan bahan-bahan untuk bumbu ayam goreng ini ke dalam panci lalu rebus hingga mendidih dan sausnya mengental : Tom Yam Paste, bawang putih cincang, garam, gula pasir putih, cuka putih, saus tiram dan air. Matikan kompor api setelah saus sudah mengental dan biarkan sejenak; tambahkan jus jeruk lemon hijau lalu aduk hingga rata."
- "Selimuti dan tenggelamkan potongan-potongan ayam ke dalam tepung maizena dan tepung terigu. Panaskan minyak dalam wajan hingga mendidih lalu goreng ayam selama 3 menit atau hingga ayam berawarna memesan."
- "Tuang saus bumbu ayam ke dalam mangkok lalu selimuti ayam dengan saus tersebut; tambahkan potongan-potongandaun jeruk purut."
categories:
- Resep
tags:
- ayam
- goreng
- saus

katakunci: ayam goreng saus 
nutrition: 262 calories
recipecuisine: Indonesian
preptime: "PT33M"
cooktime: "PT44M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Goreng Saus Asam Pedas Manis](https://img-global.cpcdn.com/recipes/8bd57cc2d6b25f39/680x482cq70/ayam-goreng-saus-asam-pedas-manis-foto-resep-utama.jpg)

Sebagai seorang wanita, menyajikan masakan mantab pada keluarga tercinta merupakan hal yang mengasyikan untuk kamu sendiri. Tanggung jawab seorang  wanita bukan cuman mengatur rumah saja, namun kamu juga harus menyediakan keperluan gizi terpenuhi dan juga hidangan yang dikonsumsi orang tercinta wajib lezat.

Di waktu  saat ini, kita sebenarnya mampu memesan panganan instan walaupun tanpa harus ribet membuatnya terlebih dahulu. Namun banyak juga orang yang selalu mau menghidangkan yang terenak bagi orang yang dicintainya. Sebab, memasak yang diolah sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan hidangan tersebut sesuai kesukaan keluarga tercinta. 

Taburkan tepung terigu, tepung sagu, air, merica bubuk &amp; bumbu penyedap kedalam wadah yang berisi ayam tadi. Lihat juga resep Yangnyeom Tongdak (Ayam Goreng Asam Manis Pedas Korea) enak lainnya. Jika ayam goreng tepung terasa terlalu biasa untuk terus menerus disajikan di rumah bersama keluarga, resep ayam saus asam manis ini mungkin bisa menambah variasi makan Anda.

Mungkinkah anda seorang penikmat ayam goreng saus asam pedas manis?. Tahukah kamu, ayam goreng saus asam pedas manis adalah sajian khas di Indonesia yang kini digemari oleh kebanyakan orang di berbagai wilayah di Indonesia. Kita dapat menyajikan ayam goreng saus asam pedas manis sendiri di rumah dan boleh jadi camilan favoritmu di akhir pekan.

Kalian tak perlu bingung jika kamu ingin mendapatkan ayam goreng saus asam pedas manis, karena ayam goreng saus asam pedas manis sangat mudah untuk dicari dan juga kalian pun dapat menghidangkannya sendiri di rumah. ayam goreng saus asam pedas manis bisa diolah memalui berbagai cara. Kini ada banyak sekali resep kekinian yang menjadikan ayam goreng saus asam pedas manis semakin lebih lezat.

Resep ayam goreng saus asam pedas manis pun mudah sekali untuk dibikin, lho. Anda jangan repot-repot untuk membeli ayam goreng saus asam pedas manis, sebab Anda dapat menghidangkan ditempatmu. Bagi Anda yang hendak membuatnya, dibawah ini merupakan cara untuk membuat ayam goreng saus asam pedas manis yang mantab yang mampu Kalian buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Ayam Goreng Saus Asam Pedas Manis:

1. Sediakan  Bahan-bahan utama:
1. Ambil 1 bungkus ayam paha atau dada fillet (10 potong)
1. Siapkan  Bahan-Bahan Bumbu Ayam:
1. Sediakan 1 butir telur(putih &amp; kuning)
1. Siapkan 1/1/4 sendok tepung terigu
1. Ambil 2 sendok makan tepung maizena
1. Siapkan 1/1/2 sendok teh garam
1. Sediakan  Bahan-Bahan Bumbu Ayam:
1. Sediakan 2 sendok makan &#34;Thai Tom Yam Paste&#34; (lihat gambar di bagian step)
1. Sediakan 3 siung bawang putih (cincang kecil-kecil)
1. Gunakan 3 sendok makan saus tiram
1. Sediakan 2 sendok makan cuka putih
1. Siapkan 3 sendok makan cabe murah bubuk
1. Sediakan 1 sendok makan fish sauce (kecap ikan)
1. Siapkan 1 gelas kecil teh air
1. Gunakan  Bahan-Bahan Pelengkap Bumbu:
1. Siapkan 4 helai daun jeruk purut (cincang kecil-kecil)
1. Sediakan 1 buah jeruk lemon hijau (lime) ambil jusnya
1. Siapkan 1/2 kulit jeruk lemon hijau (kupas kulitnya)
1. Ambil 3/4 gelas tepung terigu
1. Siapkan 1/4 gelas tepung maizena


Pada mulanya, saus tersebut bukanlah disajikan dengan ayam goreng, tetapi digunakan dalam masakan Tiongkok sebagai saus daging babi yang biasa disebut gulouyuk dalam bahasa Kantonis. Ayam Bumbu Pedas Manis Foto: Dok. Daging ayam untuk ayam bumbu pedas manis ini bisa pakai ayam kampung atau ayam jantan yang dipotong-potong. Baik menu seafood, ayam maupun daging akan terasa sangat enak bila dimasak dengan saus asam manis. 

<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Goreng Saus Asam Pedas Manis:

1. Cuci ayam hingga bersih lalu lumuri dua permukaan ayam dengan bahan-bahan sebagai berikiut lalu kocok dan diamkan selama 15 menit : tepung maizena, garam dan 1 butir telur kocok (putih dan kuning telur).
1. Inilah gambar &#34;Thai Tom Yam Paste&#34; yang saya buat setahun yang lalu.
1. Masukan lalu campurkan bahan-bahan untuk bumbu ayam goreng ini ke dalam panci lalu rebus hingga mendidih dan sausnya mengental : Tom Yam Paste, bawang putih cincang, garam, gula pasir putih, cuka putih, saus tiram dan air. Matikan kompor api setelah saus sudah mengental dan biarkan sejenak; tambahkan jus jeruk lemon hijau lalu aduk hingga rata.
1. Selimuti dan tenggelamkan potongan-potongan ayam ke dalam tepung maizena dan tepung terigu. Panaskan minyak dalam wajan hingga mendidih lalu goreng ayam selama 3 menit atau hingga ayam berawarna memesan.
1. Tuang saus bumbu ayam ke dalam mangkok lalu selimuti ayam dengan saus tersebut; tambahkan potongan-potongandaun jeruk purut.


Terlebih bagi kamu yang tidak begitu menyukai masakan pedas dengan rasa menyengat. Saus asam manis memang mudah ditemukan di pasar, supermarket bahkan toko kelontongan sekalipun dalam bentuk kemasan praktis. Mau hidangan ayam goreng saus pedas manis ala restoran nongkrong di meja makannya bunda,,, bunda gak perlu harus pergi ke restoran kok. karena ternyata ayam goreng pakai saus pedas manis sangat mudah di masak di dapur bunda sendiri. Ayam menjadi makanan favorit semua orang. Ragam masakan nikmat olahan ayam bisa Anda temukan di berbagai restoran. 

Wah ternyata cara membuat ayam goreng saus asam pedas manis yang lezat tidak rumit ini gampang banget ya! Anda Semua mampu memasaknya. Resep ayam goreng saus asam pedas manis Sangat cocok banget buat kamu yang baru akan belajar memasak ataupun juga bagi kalian yang telah pandai memasak.

Apakah kamu tertarik mulai mencoba bikin resep ayam goreng saus asam pedas manis enak tidak ribet ini? Kalau anda ingin, ayo kalian segera menyiapkan alat-alat dan bahannya, lantas bikin deh Resep ayam goreng saus asam pedas manis yang nikmat dan tidak ribet ini. Betul-betul mudah kan. 

Jadi, ketimbang anda berlama-lama, ayo kita langsung saja buat resep ayam goreng saus asam pedas manis ini. Dijamin anda tiidak akan nyesel sudah bikin resep ayam goreng saus asam pedas manis lezat tidak ribet ini! Selamat mencoba dengan resep ayam goreng saus asam pedas manis nikmat tidak ribet ini di rumah kalian masing-masing,oke!.

