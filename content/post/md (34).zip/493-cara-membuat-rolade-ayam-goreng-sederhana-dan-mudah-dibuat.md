---
description: "Cara membuat Rolade Ayam Goreng Sederhana dan Mudah Dibuat"
title: "Cara membuat Rolade Ayam Goreng Sederhana dan Mudah Dibuat"
slug: 493-cara-membuat-rolade-ayam-goreng-sederhana-dan-mudah-dibuat
date: 2021-06-18T12:33:28.637Z
image: https://img-global.cpcdn.com/recipes/a53eb8496494b685/680x482cq70/rolade-ayam-goreng-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a53eb8496494b685/680x482cq70/rolade-ayam-goreng-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a53eb8496494b685/680x482cq70/rolade-ayam-goreng-foto-resep-utama.jpg
author: Martha Castro
ratingvalue: 4.3
reviewcount: 15
recipeingredient:
- " Bahan Isi"
- "200 gr ayam giling"
- "100 gr udang giling"
- "2 siung bawang putih dihaluskan"
- "1 batang daun bawang diiris halus"
- "1 buah wortel parut kasar"
- "1 sdt kecap ikan"
- "1/2 sdt minyak wijen"
- "1/2 sdt garam"
- "1/4 sdt merica bubuk"
- "3 sdm tepung sagutapioka"
- "2 butir telur dikocok lepas"
- " Bahan Kulit"
- "2 butir telur dikocok lepas"
- "1 sdm air"
- "1/8 sdt garam"
- " Bahan Pencelup aduk rata"
- "50 gr tepung terigu protein sedang"
- "1/2 sdm tepung sagu"
- "100 ml air"
- "1/4 sdt garam"
- "1/8 sdt merica bubuk"
- " Bahan bumbu saus"
- "2 siung bawang putih dicincang halus"
- "4 sdm saus tomat"
- "1 sdm kecap inggris"
- "1 1/2 sdt kecap manis"
- "300 ml air"
- "1 sdt gula pasir"
- "1/2 sdt garam"
- "1/4 sdt merica bubuk"
- "1/4 sdt pala bubuk"
- "2 sdt maizena larutkan dengan 2 sdt air untuk pengental"
- " Bahan Pelengkap"
- "100 gr kentang kupas rebus goreng"
- "50 gr buncis potong 2 ruas jari rebus"
- "50 gr wortel potong korek api sepanjang 2 ruas jari rebus"
recipeinstructions:
- "Bahan Isi. Aduk rata daging ayam giling, udang giling, bawang putih, daun bawang, wortel parut, kecap ikan, minyak wijen, garam, dan merica bubuk. Masukkan telur yang telah dikocok lepas sedikit-sedikit sambil diaduk. Disini aku mengaduknya menggunakan tangan. Awalnya tekstur adonan terpisah, namun terus saja aduk maka lama kelamaan adonan akan kalis. Masukkan Tepung sagu/tapioka. Aduk rata menggunakan spatula. Masukkan kedalam kulkas."
- "Bahan Kulit. Kocok lepas semua bahan kulit, lalu saring. Tuang tipis telur kedalam wajan anti lengket diameter bawah 18cm diatas api cenderung kecil. Kulit tidak perlu dibolak balik ya, krn adonan kulit tipis maka begitu bagian bawah matang, bagian atasnya pun matang. Angkat. Sisihkan. Disini akan dapat 3 lembar kulit."
- "Ambil 1 lembar kulit. Letakkan diatas plastik food grade. Berikan bahan isian, lalu ratakan. Gulung adonan, lalu padatkan dgn cara menekan ujung adonan dgn scrapper atau penggaris. Ikat ujung kanan dan kiri plastik dgn karet."
- "Tusuk-tusuk plastik dengan tusuk gigi supaya nanti pada saat dikukus, uap masuk kedalam adonan. Kukus adonan kedalam dandang yang telah panas diatas api sedang."
- "Kukus selama 30-40 mnt. Disini bisa dilihat adonan mengembang sedikit ya. Angkat. Biarkan dingin. Buka bungkus plastik. Lalu guling kan keatas bahan pencelup."
- "Goreng rolade kedalam minyak yang cukup panas diatas api sedang. Goreng sampai kesemua sisinya kuning kecoklatan. Angkat dan tiriskan. Sisihkan."
- "Bahan Saus. Panaskan secukupnya minyak diatas api sedang. Tumis bawang putih. Masukkan saus tomat, kecap inggris dan kecap manis. Aduk rata. Tuangkan air. Aduk rata. Biarkan mendidih dan sedikit menyusut. Lalu beri gula pasir, garam, merica dan pala bubuk. Aduk rata."
- "Masukkan larutan tepung maizena (masukkan separuh dulu, nanti cek konsistensinya). Aduk rata, biarkan mengental. Cicip dan koreksi rasa. Angkat.   Penyelesaian: Potong-potong Rolade. Tuangkan saus. Sajikan beserta kentang goreng, buncis dan wortel rebus."
categories:
- Resep
tags:
- rolade
- ayam
- goreng

katakunci: rolade ayam goreng 
nutrition: 271 calories
recipecuisine: Indonesian
preptime: "PT28M"
cooktime: "PT56M"
recipeyield: "1"
recipecategory: Lunch

---


![Rolade Ayam Goreng](https://img-global.cpcdn.com/recipes/a53eb8496494b685/680x482cq70/rolade-ayam-goreng-foto-resep-utama.jpg)

Sebagai seorang istri, mempersiapkan masakan mantab buat famili adalah suatu hal yang sangat menyenangkan untuk anda sendiri. Peran seorang istri bukan cuma mengerjakan pekerjaan rumah saja, namun kamu juga wajib memastikan kebutuhan nutrisi tercukupi dan olahan yang dimakan orang tercinta harus mantab.

Di era  sekarang, kalian sebenarnya bisa memesan santapan jadi tanpa harus repot memasaknya dahulu. Tetapi ada juga orang yang selalu mau memberikan makanan yang terenak untuk keluarganya. Sebab, menyajikan masakan sendiri akan jauh lebih higienis dan bisa menyesuaikan hidangan tersebut sesuai kesukaan keluarga. 



Mungkinkah anda salah satu penyuka rolade ayam goreng?. Asal kamu tahu, rolade ayam goreng adalah sajian khas di Nusantara yang kini disenangi oleh banyak orang dari hampir setiap daerah di Nusantara. Kalian dapat menyajikan rolade ayam goreng sendiri di rumah dan boleh dijadikan santapan kesukaanmu di akhir pekanmu.

Anda tidak perlu bingung jika kamu ingin memakan rolade ayam goreng, karena rolade ayam goreng gampang untuk dicari dan kamu pun boleh membuatnya sendiri di rumah. rolade ayam goreng bisa diolah memalui beraneka cara. Sekarang sudah banyak banget resep modern yang menjadikan rolade ayam goreng semakin lebih mantap.

Resep rolade ayam goreng pun gampang dibuat, lho. Kalian tidak perlu repot-repot untuk memesan rolade ayam goreng, karena Kalian bisa menyajikan ditempatmu. Untuk Kita yang ingin menyajikannya, inilah resep menyajikan rolade ayam goreng yang mantab yang mampu Kita coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Rolade Ayam Goreng:

1. Siapkan  Bahan Isi
1. Ambil 200 gr ayam giling
1. Sediakan 100 gr udang giling
1. Sediakan 2 siung bawang putih, dihaluskan
1. Sediakan 1 batang daun bawang, diiris halus
1. Gunakan 1 buah wortel, parut kasar
1. Sediakan 1 sdt kecap ikan
1. Sediakan 1/2 sdt minyak wijen
1. Gunakan 1/2 sdt garam
1. Sediakan 1/4 sdt merica bubuk
1. Siapkan 3 sdm tepung sagu/tapioka
1. Siapkan 2 butir telur, dikocok lepas
1. Sediakan  Bahan Kulit
1. Sediakan 2 butir telur, dikocok lepas
1. Sediakan 1 sdm air
1. Ambil 1/8 sdt garam
1. Gunakan  Bahan Pencelup (aduk rata)
1. Gunakan 50 gr tepung terigu protein sedang
1. Gunakan 1/2 sdm tepung sagu
1. Sediakan 100 ml air
1. Ambil 1/4 sdt garam
1. Siapkan 1/8 sdt merica bubuk
1. Ambil  Bahan bumbu saus
1. Ambil 2 siung bawang putih, dicincang halus
1. Ambil 4 sdm saus tomat
1. Ambil 1 sdm kecap inggris
1. Sediakan 1 1/2 sdt kecap manis
1. Ambil 300 ml air
1. Siapkan 1 sdt gula pasir
1. Siapkan 1/2 sdt garam
1. Siapkan 1/4 sdt merica bubuk
1. Ambil 1/4 sdt pala bubuk
1. Ambil 2 sdt maizena larutkan dengan 2 sdt air, untuk pengental
1. Ambil  Bahan Pelengkap
1. Siapkan 100 gr kentang, kupas, rebus, goreng
1. Sediakan 50 gr buncis, potong 2 ruas jari, rebus
1. Siapkan 50 gr wortel, potong korek api sepanjang 2 ruas jari, rebus




<!--inarticleads2-->

##### Cara menyiapkan Rolade Ayam Goreng:

1. Bahan Isi. Aduk rata daging ayam giling, udang giling, bawang putih, daun bawang, wortel parut, kecap ikan, minyak wijen, garam, dan merica bubuk. Masukkan telur yang telah dikocok lepas sedikit-sedikit sambil diaduk. Disini aku mengaduknya menggunakan tangan. Awalnya tekstur adonan terpisah, namun terus saja aduk maka lama kelamaan adonan akan kalis. Masukkan Tepung sagu/tapioka. Aduk rata menggunakan spatula. Masukkan kedalam kulkas.
1. Bahan Kulit. Kocok lepas semua bahan kulit, lalu saring. Tuang tipis telur kedalam wajan anti lengket diameter bawah 18cm diatas api cenderung kecil. Kulit tidak perlu dibolak balik ya, krn adonan kulit tipis maka begitu bagian bawah matang, bagian atasnya pun matang. Angkat. Sisihkan. Disini akan dapat 3 lembar kulit.
1. Ambil 1 lembar kulit. Letakkan diatas plastik food grade. Berikan bahan isian, lalu ratakan. Gulung adonan, lalu padatkan dgn cara menekan ujung adonan dgn scrapper atau penggaris. Ikat ujung kanan dan kiri plastik dgn karet.
1. Tusuk-tusuk plastik dengan tusuk gigi supaya nanti pada saat dikukus, uap masuk kedalam adonan. Kukus adonan kedalam dandang yang telah panas diatas api sedang.
1. Kukus selama 30-40 mnt. Disini bisa dilihat adonan mengembang sedikit ya. Angkat. Biarkan dingin. Buka bungkus plastik. Lalu guling kan keatas bahan pencelup.
1. Goreng rolade kedalam minyak yang cukup panas diatas api sedang. Goreng sampai kesemua sisinya kuning kecoklatan. Angkat dan tiriskan. Sisihkan.
1. Bahan Saus. Panaskan secukupnya minyak diatas api sedang. Tumis bawang putih. Masukkan saus tomat, kecap inggris dan kecap manis. Aduk rata. Tuangkan air. Aduk rata. Biarkan mendidih dan sedikit menyusut. Lalu beri gula pasir, garam, merica dan pala bubuk. Aduk rata.
1. Masukkan larutan tepung maizena (masukkan separuh dulu, nanti cek konsistensinya). Aduk rata, biarkan mengental. Cicip dan koreksi rasa. Angkat.  -  - Penyelesaian: Potong-potong Rolade. Tuangkan saus. Sajikan beserta kentang goreng, buncis dan wortel rebus.




Wah ternyata resep rolade ayam goreng yang enak tidak rumit ini mudah banget ya! Kamu semua dapat memasaknya. Resep rolade ayam goreng Sangat sesuai banget untuk kalian yang sedang belajar memasak atau juga bagi kamu yang sudah pandai memasak.

Apakah kamu tertarik mencoba membikin resep rolade ayam goreng enak simple ini? Kalau ingin, yuk kita segera menyiapkan alat dan bahan-bahannya, maka buat deh Resep rolade ayam goreng yang lezat dan tidak ribet ini. Sungguh gampang kan. 

Oleh karena itu, ketimbang anda berfikir lama-lama, yuk kita langsung saja bikin resep rolade ayam goreng ini. Pasti kamu tak akan menyesal sudah bikin resep rolade ayam goreng mantab sederhana ini! Selamat mencoba dengan resep rolade ayam goreng nikmat tidak ribet ini di tempat tinggal kalian sendiri,oke!.

