---
description: "Resep Soto Ayam Santan yang enak dan Mudah Dibuat"
title: "Resep Soto Ayam Santan yang enak dan Mudah Dibuat"
slug: 382-resep-soto-ayam-santan-yang-enak-dan-mudah-dibuat
date: 2021-04-22T22:36:56.898Z
image: https://img-global.cpcdn.com/recipes/12463687c7067911/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/12463687c7067911/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/12463687c7067911/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
author: Herman Torres
ratingvalue: 4.7
reviewcount: 13
recipeingredient:
- "1 kg dada ayam bagusnya yg fillet"
- "250 ml Santan kara ukuran"
- " Garam kaldu jamur"
- " Air untuk merebus"
- " Pelengkap"
- " Kentang potong dadu goreng"
- " Toge rebus"
- " Kol optional"
- "iris Daun bawang dan seledri"
- " Telur rebus"
- " Bawang goreng untuk taburan"
- "potong dadu Tomat"
- " Bumbu halus"
- "4 siung bawang putih"
- "7 siung bawang merah"
- "8 buah kemiri"
- "1 ruas jahe"
- "1 ruas kunyit"
- "1 sdm ketumbar"
- "Secukupnya lada"
- " Bumbu cemplung"
- "5 lembar daun salam"
- "5 lembar daun jeruk"
- "2 buah serai"
- "1 ruas Laos geprek"
recipeinstructions:
- "Bersihkan ayam. Sisihkan"
- "Didihkan air, beserta daun salam dan serai. Masukan ayam."
- "Sambil merebus ayam. Tumis bumbu halus sampai wangi, tambahkan daun jeruk. Setelah bumbu matang, masukan bumbu kedalam rebusan air yang berisi ayam. Biarkan bumbu meresap dan ayam empuk"
- "Angkat ayam, goreng sebentar lalu suwir kasar (optional..kalo ga mau di goreng bisa langsung di suwir)"
- "Dalam air rebusan ayam tadi, masukan santan kara. Biarkan mendidih. Masukan garam dan kaldu jamur. Test rasa"
- "Sajikan soto bersama pelengkapnya."
categories:
- Resep
tags:
- soto
- ayam
- santan

katakunci: soto ayam santan 
nutrition: 174 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT51M"
recipeyield: "4"
recipecategory: Lunch

---


![Soto Ayam Santan](https://img-global.cpcdn.com/recipes/12463687c7067911/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg)

Sebagai seorang orang tua, menyediakan santapan mantab bagi keluarga merupakan suatu hal yang mengasyikan untuk anda sendiri. Tugas seorang ibu Tidak cuma menjaga rumah saja, tetapi anda juga harus memastikan kebutuhan nutrisi tercukupi dan juga olahan yang dikonsumsi keluarga tercinta harus sedap.

Di waktu  sekarang, kamu memang mampu memesan hidangan praktis walaupun tidak harus capek membuatnya dahulu. Tetapi ada juga orang yang selalu mau menghidangkan yang terenak bagi keluarganya. Sebab, memasak sendiri jauh lebih higienis dan kita juga bisa menyesuaikan masakan tersebut sesuai dengan masakan kesukaan famili. 



Apakah anda adalah salah satu penggemar soto ayam santan?. Tahukah kamu, soto ayam santan merupakan makanan khas di Indonesia yang sekarang disenangi oleh setiap orang dari hampir setiap daerah di Nusantara. Anda dapat menghidangkan soto ayam santan sendiri di rumahmu dan boleh dijadikan makanan kesukaanmu di akhir pekanmu.

Anda tak perlu bingung untuk menyantap soto ayam santan, karena soto ayam santan mudah untuk ditemukan dan kamu pun boleh mengolahnya sendiri di tempatmu. soto ayam santan dapat dibuat memalui beragam cara. Kini telah banyak banget resep kekinian yang menjadikan soto ayam santan semakin lebih lezat.

Resep soto ayam santan juga sangat mudah dibuat, lho. Kalian jangan repot-repot untuk memesan soto ayam santan, karena Kita bisa menyiapkan ditempatmu. Bagi Kita yang akan menyajikannya, inilah resep menyajikan soto ayam santan yang nikamat yang dapat Kalian hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Soto Ayam Santan:

1. Siapkan 1 kg dada ayam (bagusnya yg fillet)
1. Sediakan 250 ml Santan kara ukuran
1. Sediakan  Garam, kaldu jamur
1. Gunakan  Air untuk merebus
1. Gunakan  Pelengkap
1. Ambil  Kentang potong dadu, goreng
1. Siapkan  Toge rebus
1. Gunakan  Kol (optional)
1. Ambil iris Daun bawang dan seledri
1. Sediakan  Telur rebus
1. Gunakan  Bawang goreng untuk taburan
1. Siapkan potong dadu Tomat
1. Ambil  Bumbu halus
1. Siapkan 4 siung bawang putih
1. Gunakan 7 siung bawang merah
1. Ambil 8 buah kemiri
1. Sediakan 1 ruas jahe
1. Sediakan 1 ruas kunyit
1. Gunakan 1 sdm ketumbar
1. Sediakan Secukupnya lada
1. Siapkan  Bumbu cemplung
1. Siapkan 5 lembar daun salam
1. Siapkan 5 lembar daun jeruk
1. Gunakan 2 buah serai
1. Gunakan 1 ruas Laos geprek




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Soto Ayam Santan:

1. Bersihkan ayam. Sisihkan
1. Didihkan air, beserta daun salam dan serai. Masukan ayam.
1. Sambil merebus ayam. Tumis bumbu halus sampai wangi, tambahkan daun jeruk. Setelah bumbu matang, masukan bumbu kedalam rebusan air yang berisi ayam. Biarkan bumbu meresap dan ayam empuk
1. Angkat ayam, goreng sebentar lalu suwir kasar (optional..kalo ga mau di goreng bisa langsung di suwir)
1. Dalam air rebusan ayam tadi, masukan santan kara. Biarkan mendidih. Masukan garam dan kaldu jamur. Test rasa
1. Sajikan soto bersama pelengkapnya.




Wah ternyata cara buat soto ayam santan yang nikamt tidak ribet ini gampang sekali ya! Kamu semua bisa membuatnya. Cara Membuat soto ayam santan Sesuai sekali buat kamu yang sedang belajar memasak atau juga bagi kalian yang telah lihai dalam memasak.

Tertarik untuk mulai mencoba membikin resep soto ayam santan mantab simple ini? Kalau mau, ayo kalian segera buruan siapkan alat-alat dan bahannya, lantas bikin deh Resep soto ayam santan yang lezat dan tidak rumit ini. Benar-benar taidak sulit kan. 

Maka, daripada kamu berlama-lama, ayo langsung aja buat resep soto ayam santan ini. Dijamin kalian tiidak akan nyesel sudah buat resep soto ayam santan enak sederhana ini! Selamat berkreasi dengan resep soto ayam santan lezat sederhana ini di rumah kalian masing-masing,ya!.

