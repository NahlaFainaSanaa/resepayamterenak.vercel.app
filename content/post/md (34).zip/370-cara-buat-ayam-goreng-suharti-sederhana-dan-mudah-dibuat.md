---
description: "Cara buat Ayam goreng suharti Sederhana dan Mudah Dibuat"
title: "Cara buat Ayam goreng suharti Sederhana dan Mudah Dibuat"
slug: 370-cara-buat-ayam-goreng-suharti-sederhana-dan-mudah-dibuat
date: 2021-03-02T01:22:08.647Z
image: https://img-global.cpcdn.com/recipes/269ff18c0494807d/680x482cq70/ayam-goreng-suharti-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/269ff18c0494807d/680x482cq70/ayam-goreng-suharti-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/269ff18c0494807d/680x482cq70/ayam-goreng-suharti-foto-resep-utama.jpg
author: Gussie Boone
ratingvalue: 3.7
reviewcount: 3
recipeingredient:
- "2 ekor ayam kampung"
- " Air kelapa"
- " Bumbu yg dihaluskan"
- "40 gr bawang putih"
- "20 gr kemiri"
- "15 gr kunyit"
- "8 gr ketumbar"
- "2 gr lada"
- "1 gr jinten"
- "16 gr garam"
- "6 gr vetsin"
- " Adonan pencelup"
- "100 gr tepung sagu tani"
- "20 gr maizena"
- "1 sdt garam"
- "1 sdt vetsin"
- "2 btr telor"
- "150 ml santan kara11air"
- " Bahan kremesan"
- "50 gr kemiri haluskan"
- "40 gr bawang putih haluskan"
- "65 gr tepung sagu tani"
- "10 gr maizena"
- "1 sdm gula pasir"
- "1 sdt vetsin"
- "2 gr lada"
- "2 gr ketumbar haluskan"
- "1 sdt garam"
- "1 btr telur"
- "200 ml santan kental murni"
- "425 ml air"
- " Bahan sambal"
- "50 gr cabe rawit merah"
- "100 gr cabe keriting"
- "150 gr cabe merah besar"
- "30 gr bawang putih"
- "60 gr bawang merah"
- "200 gr tomat"
- "75 vgr gula merah"
- "5 gr asam jawa"
- "25 gr terasi goreng"
- "20 gr garam"
- "4 gr vetsin"
recipeinstructions:
- "Masak air kelapa dan bumbu yg dihaluskan hingga panas. masukan ayam. Didihkan. Masak terus hingga lebih kurang 1 jam"
- "Matikan api kompor. Biarkan ayam dalam panci hingga 1 jam. Kemudian angkat tiriskan"
- "Campur semua bahan pencelup. Hingga rata. Celupkan ayam yg sdh di masak. Lalu goreng dalam minyak panas yg banyak dg api sedang"
- "Langkah membuat kremesan:"
- "Campur semua adonan kremesan aduk rata."
- "Panaskan minyak banyak. Kucurkan adonan kremesan dari tengah2 hingga bolongan mengecil divtengahbpenggorengan. Goreng sambil di bentuk mengumpul hingga mengapung. Angkat dan sajikan."
- "Sambal suharti:"
- "Goreng semua cabe bawang merah bawang putih setengah matang"
- "Masukan ke Blender dan blender semua bahan. Kemudian masak dg api kecil"
- "Video Cara menggoreng kremesan bisa dilihat di youtube jangan lupa klik subscribe ya judulnya : ayam goreng suharti by rsw"
categories:
- Resep
tags:
- ayam
- goreng
- suharti

katakunci: ayam goreng suharti 
nutrition: 150 calories
recipecuisine: Indonesian
preptime: "PT36M"
cooktime: "PT57M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam goreng suharti](https://img-global.cpcdn.com/recipes/269ff18c0494807d/680x482cq70/ayam-goreng-suharti-foto-resep-utama.jpg)

Jika kamu seorang ibu, menyediakan masakan lezat untuk keluarga merupakan suatu hal yang membahagiakan untuk kamu sendiri. Kewajiban seorang istri Tidak cuma mengurus rumah saja, tetapi anda juga wajib memastikan kebutuhan gizi tercukupi dan juga panganan yang dimakan anak-anak harus mantab.

Di zaman  sekarang, kalian memang bisa mengorder olahan instan tanpa harus repot memasaknya dahulu. Tetapi ada juga lho mereka yang memang mau memberikan yang terenak bagi orang yang dicintainya. Sebab, menghidangkan masakan sendiri jauh lebih higienis dan kita pun bisa menyesuaikan makanan tersebut berdasarkan masakan kesukaan famili. 



Apakah kamu seorang penggemar ayam goreng suharti?. Tahukah kamu, ayam goreng suharti merupakan makanan khas di Indonesia yang saat ini disukai oleh orang-orang dari berbagai tempat di Indonesia. Kita bisa menyajikan ayam goreng suharti sendiri di rumah dan pasti jadi santapan kesukaanmu di akhir pekan.

Kamu tak perlu bingung untuk mendapatkan ayam goreng suharti, lantaran ayam goreng suharti sangat mudah untuk dicari dan juga kita pun dapat membuatnya sendiri di tempatmu. ayam goreng suharti dapat dimasak lewat bermacam cara. Sekarang sudah banyak sekali resep kekinian yang menjadikan ayam goreng suharti semakin nikmat.

Resep ayam goreng suharti juga sangat mudah untuk dibuat, lho. Kita jangan ribet-ribet untuk membeli ayam goreng suharti, tetapi Kita dapat menghidangkan ditempatmu. Bagi Kamu yang ingin menghidangkannya, di bawah ini adalah resep menyajikan ayam goreng suharti yang enak yang dapat Kalian coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Ayam goreng suharti:

1. Siapkan 2 ekor ayam kampung
1. Siapkan  Air kelapa
1. Ambil  Bumbu yg dihaluskan:
1. Siapkan 40 gr bawang putih
1. Siapkan 20 gr kemiri
1. Siapkan 15 gr kunyit
1. Gunakan 8 gr ketumbar
1. Ambil 2 gr lada
1. Ambil 1 gr jinten
1. Siapkan 16 gr garam
1. Ambil 6 gr vetsin
1. Sediakan  Adonan pencelup:
1. Ambil 100 gr tepung sagu tani
1. Sediakan 20 gr maizena
1. Ambil 1 sdt garam
1. Siapkan 1 sdt vetsin
1. Siapkan 2 btr telor
1. Gunakan 150 ml santan (kara1÷1air)
1. Gunakan  Bahan kremesan:
1. Siapkan 50 gr kemiri haluskan
1. Ambil 40 gr bawang putih haluskan
1. Ambil 65 gr tepung sagu tani
1. Sediakan 10 gr maizena
1. Ambil 1 sdm gula pasir
1. Gunakan 1 sdt vetsin
1. Ambil 2 gr lada
1. Sediakan 2 gr ketumbar haluskan
1. Siapkan 1 sdt garam
1. Ambil 1 btr telur
1. Gunakan 200 ml santan kental murni
1. Gunakan 425 ml air
1. Siapkan  Bahan sambal:
1. Gunakan 50 gr cabe rawit merah
1. Siapkan 100 gr cabe keriting
1. Gunakan 150 gr cabe merah besar
1. Sediakan 30 gr bawang putih
1. Gunakan 60 gr bawang merah
1. Gunakan 200 gr tomat
1. Ambil 75 vgr gula merah
1. Siapkan 5 gr asam jawa
1. Sediakan 25 gr terasi goreng
1. Ambil 20 gr garam
1. Siapkan 4 gr vetsin




<!--inarticleads2-->

##### Cara membuat Ayam goreng suharti:

1. Masak air kelapa dan bumbu yg dihaluskan hingga panas. masukan ayam. Didihkan. Masak terus hingga lebih kurang 1 jam
1. Matikan api kompor. Biarkan ayam dalam panci hingga 1 jam. Kemudian angkat tiriskan
1. Campur semua bahan pencelup. Hingga rata. Celupkan ayam yg sdh di masak. Lalu goreng dalam minyak panas yg banyak dg api sedang
1. Langkah membuat kremesan:
1. Campur semua adonan kremesan aduk rata.
1. Panaskan minyak banyak. Kucurkan adonan kremesan dari tengah2 hingga bolongan mengecil divtengahbpenggorengan. Goreng sambil di bentuk mengumpul hingga mengapung. Angkat dan sajikan.
1. Sambal suharti:
1. Goreng semua cabe bawang merah bawang putih setengah matang
1. Masukan ke Blender dan blender semua bahan. Kemudian masak dg api kecil
1. Video Cara menggoreng kremesan bisa dilihat di youtube jangan lupa klik subscribe ya judulnya : ayam goreng suharti by rsw




Wah ternyata resep ayam goreng suharti yang enak tidak ribet ini enteng banget ya! Kamu semua dapat mencobanya. Cara buat ayam goreng suharti Cocok sekali untuk anda yang baru belajar memasak ataupun juga bagi kalian yang sudah hebat dalam memasak.

Apakah kamu mau mulai mencoba membuat resep ayam goreng suharti enak tidak rumit ini? Kalau mau, ayo kamu segera buruan siapin peralatan dan bahan-bahannya, lalu buat deh Resep ayam goreng suharti yang nikmat dan simple ini. Benar-benar mudah kan. 

Maka, daripada anda berlama-lama, hayo kita langsung saja sajikan resep ayam goreng suharti ini. Pasti kalian tiidak akan menyesal sudah bikin resep ayam goreng suharti nikmat simple ini! Selamat berkreasi dengan resep ayam goreng suharti mantab simple ini di tempat tinggal masing-masing,oke!.

