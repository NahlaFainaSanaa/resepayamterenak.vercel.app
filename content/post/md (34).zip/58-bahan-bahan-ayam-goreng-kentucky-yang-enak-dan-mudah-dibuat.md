---
description: "Bahan-bahan Ayam Goreng Kentucky yang enak dan Mudah Dibuat"
title: "Bahan-bahan Ayam Goreng Kentucky yang enak dan Mudah Dibuat"
slug: 58-bahan-bahan-ayam-goreng-kentucky-yang-enak-dan-mudah-dibuat
date: 2021-04-03T16:18:02.696Z
image: https://img-global.cpcdn.com/recipes/7b818b9e010c4ad8/680x482cq70/ayam-goreng-kentucky-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7b818b9e010c4ad8/680x482cq70/ayam-goreng-kentucky-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7b818b9e010c4ad8/680x482cq70/ayam-goreng-kentucky-foto-resep-utama.jpg
author: Lucile Clarke
ratingvalue: 4.4
reviewcount: 5
recipeingredient:
- "6 potong ayam cuci bersih"
- "1 butir telur Uk kecil"
- "125 ml air es"
- "1/2 sdt soda kue"
- " Bambu Halus"
- "4 siung bawang putih"
- "1 ruas kunyit"
- "1/2 ruas jahe"
- "1/2 sdt kaldu bubuk"
- "1/2 sdt kaldu jamur"
- "1/2 sdt garam"
- "1/2 sdt ketumbar bubuk"
- " Tepung pelapis"
- "225 gr tepung terigu"
- "75 gr tepung maizena"
- "1/2 sdt kaldu jamur"
recipeinstructions:
- "Haluskan bawang putih, jahe dan kunyit, lalu masukan bumbu ke dalam wadah beirisi ayam, beri bumbu halus lainnya,Aduk rata, Marinasi ayam selama 2 jam di kulkas.   Keluarkan ayam dari kulkas, beri kocokan telur"
- "Aduk rata ayam dengan kocokan telur, ambil 2.5 sdm bahan tepung pelapis kemudian beri soda kue dan air es. Aduk hingga tidak ada yang menggumpal. Masukan 2 potong ayam ke dalam adonan nasah"
- "Kemudian masukkan ke adonan kering. Lalu celupkan lagi ke adonan basah sebentar. Kemudian masukkan ke adonan kering lagim tutupi seluruh permukaan ayam dengan tepung sambil dicubit - cubit. Lakukan pada kedua sisinya. Kibas kibaskan tepung sebelum masuk penggorengan"
- "Panaskan minyak agak banyak dan goreng ayam hingga matang keemasan"
- "Goreng dengan api kecil, jika sudah matang angkat dan tiriskan"
- "Ayam Goreng Kentucky siap disajikan"
categories:
- Resep
tags:
- ayam
- goreng
- kentucky

katakunci: ayam goreng kentucky 
nutrition: 170 calories
recipecuisine: Indonesian
preptime: "PT34M"
cooktime: "PT32M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Goreng Kentucky](https://img-global.cpcdn.com/recipes/7b818b9e010c4ad8/680x482cq70/ayam-goreng-kentucky-foto-resep-utama.jpg)

Selaku seorang istri, menyuguhkan hidangan nikmat untuk keluarga tercinta merupakan hal yang memuaskan bagi kamu sendiri. Tanggung jawab seorang istri Tidak sekadar menjaga rumah saja, namun anda juga wajib memastikan kebutuhan gizi tercukupi dan juga santapan yang dimakan keluarga tercinta mesti nikmat.

Di era  saat ini, anda memang dapat mengorder santapan praktis meski tidak harus ribet mengolahnya lebih dulu. Tetapi banyak juga mereka yang memang mau memberikan hidangan yang terbaik bagi keluarganya. Sebab, menyajikan masakan yang dibuat sendiri jauh lebih higienis dan kita pun bisa menyesuaikan makanan tersebut sesuai dengan selera orang tercinta. 



Apakah kamu salah satu penikmat ayam goreng kentucky?. Tahukah kamu, ayam goreng kentucky merupakan hidangan khas di Nusantara yang kini disukai oleh setiap orang dari berbagai daerah di Nusantara. Kalian dapat memasak ayam goreng kentucky sendiri di rumah dan boleh jadi camilan kegemaranmu di hari libur.

Anda tidak perlu bingung untuk menyantap ayam goreng kentucky, karena ayam goreng kentucky tidak sulit untuk ditemukan dan kamu pun boleh memasaknya sendiri di rumah. ayam goreng kentucky dapat diolah dengan berbagai cara. Kini ada banyak banget resep kekinian yang membuat ayam goreng kentucky semakin nikmat.

Resep ayam goreng kentucky juga sangat gampang untuk dibuat, lho. Kalian jangan capek-capek untuk membeli ayam goreng kentucky, tetapi Kalian dapat menghidangkan di rumahmu. Bagi Anda yang mau membuatnya, inilah cara untuk membuat ayam goreng kentucky yang lezat yang dapat Kita coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Ayam Goreng Kentucky:

1. Gunakan 6 potong ayam (cuci bersih)
1. Ambil 1 butir telur Uk kecil
1. Siapkan 125 ml air es
1. Ambil 1/2 sdt soda kue
1. Gunakan  Bambu Halus
1. Siapkan 4 siung bawang putih
1. Gunakan 1 ruas kunyit
1. Gunakan 1/2 ruas jahe
1. Gunakan 1/2 sdt kaldu bubuk
1. Ambil 1/2 sdt kaldu jamur
1. Sediakan 1/2 sdt garam
1. Gunakan 1/2 sdt ketumbar bubuk
1. Gunakan  Tepung pelapis
1. Sediakan 225 gr tepung terigu
1. Sediakan 75 gr tepung maizena
1. Sediakan 1/2 sdt kaldu jamur




<!--inarticleads2-->

##### Cara membuat Ayam Goreng Kentucky:

1. Haluskan bawang putih, jahe dan kunyit, lalu masukan bumbu ke dalam wadah beirisi ayam, beri bumbu halus lainnya,Aduk rata, Marinasi ayam selama 2 jam di kulkas.  -  - Keluarkan ayam dari kulkas, beri kocokan telur
1. Aduk rata ayam dengan kocokan telur, ambil 2.5 sdm bahan tepung pelapis kemudian beri soda kue dan air es. Aduk hingga tidak ada yang menggumpal. Masukan 2 potong ayam ke dalam adonan nasah
1. Kemudian masukkan ke adonan kering. Lalu celupkan lagi ke adonan basah sebentar. Kemudian masukkan ke adonan kering lagim tutupi seluruh permukaan ayam dengan tepung sambil dicubit - cubit. Lakukan pada kedua sisinya. Kibas kibaskan tepung sebelum masuk penggorengan
1. Panaskan minyak agak banyak dan goreng ayam hingga matang keemasan
1. Goreng dengan api kecil, jika sudah matang angkat dan tiriskan
1. Ayam Goreng Kentucky siap disajikan




Ternyata cara membuat ayam goreng kentucky yang nikamt sederhana ini enteng banget ya! Kalian semua mampu membuatnya. Resep ayam goreng kentucky Sangat cocok sekali buat anda yang baru belajar memasak atau juga untuk kamu yang telah lihai memasak.

Tertarik untuk mencoba bikin resep ayam goreng kentucky lezat tidak ribet ini? Kalau tertarik, yuk kita segera buruan siapin peralatan dan bahan-bahannya, kemudian buat deh Resep ayam goreng kentucky yang enak dan simple ini. Sungguh gampang kan. 

Maka dari itu, daripada anda berlama-lama, ayo kita langsung saja bikin resep ayam goreng kentucky ini. Pasti kalian tiidak akan nyesel sudah bikin resep ayam goreng kentucky mantab sederhana ini! Selamat mencoba dengan resep ayam goreng kentucky nikmat sederhana ini di tempat tinggal masing-masing,ya!.

