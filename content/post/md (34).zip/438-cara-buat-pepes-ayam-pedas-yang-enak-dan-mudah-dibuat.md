---
description: "Cara buat Pepes Ayam Pedas yang enak dan Mudah Dibuat"
title: "Cara buat Pepes Ayam Pedas yang enak dan Mudah Dibuat"
slug: 438-cara-buat-pepes-ayam-pedas-yang-enak-dan-mudah-dibuat
date: 2021-03-30T13:11:36.395Z
image: https://img-global.cpcdn.com/recipes/5aa4696fe1d726dd/680x482cq70/pepes-ayam-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5aa4696fe1d726dd/680x482cq70/pepes-ayam-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5aa4696fe1d726dd/680x482cq70/pepes-ayam-pedas-foto-resep-utama.jpg
author: Gabriel Paul
ratingvalue: 3.2
reviewcount: 14
recipeingredient:
- "500 gr ayam"
- "1/2 buah jeruk nipis"
- "3 sdm santan kental"
- "8 lembar daun salam"
- "4 lembar daun jeruk sobek"
- "2 buah tomat potong kecil"
- "20 buah cabe rawit merah utuh"
- " Bumbu Halus"
- "8 siung bawang merah"
- "6 siung bawang putih"
- "10 buah cabe merah keriting"
- "8 buah cabe rawit merah"
- "1 ruas jahe"
- "1 ruas kunyit bakar"
- "6 buah kemiri sangrai"
- "1 batang serai"
recipeinstructions:
- "Potong kecil&#34; ayam lalu lumuri dengan jeruk nipis, diamkan selama 15 menit lalu cuci bersih lagi"
- "Panaskan sedikit minyak lalu tumis bumbu halus hingga harum, setelah itu masukkan ayam, daun salam dan santan, aduk&#34; hingga ayam berubah warna, angkat"
- "Siapkan 2 lembar daun pisang, lalu masukkan 2-3 potong ayam bersama bumbu, daun salam, cabe rawit dan tomat potong, kemudian bungkus dan semat tusuk gigi"
- "Panaskan kukusan, lalu kukus pepes selama 20 menit, kemudian angkat dan panggang hingga daun kering"
categories:
- Resep
tags:
- pepes
- ayam
- pedas

katakunci: pepes ayam pedas 
nutrition: 241 calories
recipecuisine: Indonesian
preptime: "PT26M"
cooktime: "PT50M"
recipeyield: "3"
recipecategory: Dessert

---


![Pepes Ayam Pedas](https://img-global.cpcdn.com/recipes/5aa4696fe1d726dd/680x482cq70/pepes-ayam-pedas-foto-resep-utama.jpg)

Sebagai seorang ibu, mempersiapkan panganan nikmat kepada keluarga merupakan suatu hal yang membahagiakan bagi kamu sendiri. Peran seorang ibu bukan sekedar menangani rumah saja, tetapi anda pun harus menyediakan kebutuhan nutrisi tercukupi dan panganan yang dikonsumsi anak-anak wajib lezat.

Di waktu  sekarang, kalian sebenarnya dapat membeli santapan siap saji tidak harus capek memasaknya lebih dulu. Namun ada juga orang yang selalu mau menyajikan yang terlezat untuk keluarganya. Lantaran, memasak yang diolah sendiri jauh lebih bersih dan kita juga bisa menyesuaikan berdasarkan masakan kesukaan orang tercinta. 



Mungkinkah anda seorang penikmat pepes ayam pedas?. Asal kamu tahu, pepes ayam pedas adalah makanan khas di Nusantara yang kini disenangi oleh kebanyakan orang di hampir setiap tempat di Indonesia. Anda dapat memasak pepes ayam pedas sendiri di rumahmu dan boleh jadi hidangan kesukaanmu di hari libur.

Anda jangan bingung jika kamu ingin menyantap pepes ayam pedas, lantaran pepes ayam pedas sangat mudah untuk didapatkan dan kamu pun dapat memasaknya sendiri di tempatmu. pepes ayam pedas bisa dimasak dengan beragam cara. Saat ini sudah banyak cara kekinian yang menjadikan pepes ayam pedas semakin nikmat.

Resep pepes ayam pedas juga sangat gampang dihidangkan, lho. Kamu jangan capek-capek untuk membeli pepes ayam pedas, karena Kalian bisa menyiapkan sendiri di rumah. Untuk Kita yang ingin mencobanya, berikut cara membuat pepes ayam pedas yang mantab yang bisa Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Pepes Ayam Pedas:

1. Sediakan 500 gr ayam
1. Gunakan 1/2 buah jeruk nipis
1. Sediakan 3 sdm santan kental
1. Siapkan 8 lembar daun salam
1. Ambil 4 lembar daun jeruk sobek&#34;
1. Siapkan 2 buah tomat potong kecil&#34;
1. Ambil 20 buah cabe rawit merah utuh
1. Siapkan  Bumbu Halus
1. Sediakan 8 siung bawang merah
1. Ambil 6 siung bawang putih
1. Gunakan 10 buah cabe merah keriting
1. Ambil 8 buah cabe rawit merah
1. Ambil 1 ruas jahe
1. Gunakan 1 ruas kunyit bakar
1. Sediakan 6 buah kemiri sangrai
1. Gunakan 1 batang serai




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Pepes Ayam Pedas:

1. Potong kecil&#34; ayam lalu lumuri dengan jeruk nipis, diamkan selama 15 menit lalu cuci bersih lagi
1. Panaskan sedikit minyak lalu tumis bumbu halus hingga harum, setelah itu masukkan ayam, daun salam dan santan, aduk&#34; hingga ayam berubah warna, angkat
1. Siapkan 2 lembar daun pisang, lalu masukkan 2-3 potong ayam bersama bumbu, daun salam, cabe rawit dan tomat potong, kemudian bungkus dan semat tusuk gigi
1. Panaskan kukusan, lalu kukus pepes selama 20 menit, kemudian angkat dan panggang hingga daun kering




Ternyata cara buat pepes ayam pedas yang mantab sederhana ini gampang sekali ya! Kita semua dapat membuatnya. Cara buat pepes ayam pedas Sangat cocok sekali buat kalian yang baru belajar memasak maupun juga bagi kalian yang telah hebat dalam memasak.

Apakah kamu mau mulai mencoba membikin resep pepes ayam pedas mantab simple ini? Kalau kamu mau, ayo kamu segera buruan siapkan alat dan bahannya, kemudian bikin deh Resep pepes ayam pedas yang mantab dan sederhana ini. Betul-betul gampang kan. 

Maka, ketimbang kita berlama-lama, ayo kita langsung saja hidangkan resep pepes ayam pedas ini. Pasti anda gak akan menyesal sudah membuat resep pepes ayam pedas nikmat sederhana ini! Selamat berkreasi dengan resep pepes ayam pedas nikmat simple ini di tempat tinggal sendiri,ya!.

