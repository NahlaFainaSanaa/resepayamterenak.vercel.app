---
description: "Bahan-bahan Soto Ayam Santan Sederhana dan Mudah Dibuat"
title: "Bahan-bahan Soto Ayam Santan Sederhana dan Mudah Dibuat"
slug: 393-bahan-bahan-soto-ayam-santan-sederhana-dan-mudah-dibuat
date: 2021-01-27T18:55:30.441Z
image: https://img-global.cpcdn.com/recipes/946a572b200d97e8/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/946a572b200d97e8/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/946a572b200d97e8/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
author: Augusta Sanchez
ratingvalue: 3.9
reviewcount: 10
recipeingredient:
- "500 gr dada ayam"
- "1500 ml santan"
- "3 lbr daun salam"
- "3 lbr daub jeruk"
- "2 batang seraimemarkan"
- "2 ruas jari lengkuasmemarkan"
- "2 batang daun bawang potong 2 cm bagian putih kuskip"
- "Sesuai selera gulagaram dan kaldu bubuk"
- " Bumbu halus"
- "6 buah bawang merah"
- "3 siung bawang putih"
- "3 btr kemiri sangarai"
- "1 ruas jari jahe"
- "1/2 sdt ketumba"
- "1/2 sdt merica butir"
- " Pelengkap"
- "1 buah tomat besarpotong kotak kecil"
- "Sesuai selera irisan daun bawang kuskip seledri"
- "200 gr kol iris"
- "1 buah jeruk nipis"
- "Sesuai selera pelngkap lainya sambalbawang goreng dan emping"
recipeinstructions:
- "Potong dada ayam,cuci bersih lumuri dengan air jeruk nipis.Diamkan beberapa saat dan bilas.Goreng hingga agak kecoklatan saja.Kemudian suir suir."
- ""
- "Haluskan bahan bumbu halus.Tumis bumbu halus,daun salam,daun jeruk,serai dan lengkuas.Tumis hingga bumbu matang,beri sedikit air.Matikan api."
- "Masak santan hingga mendidih.Masukkan tumisan bumbu.Aduk selalu agar santan tidak pecah."
- "Masukkan ayam suir,beri bumbu gula,garam dan kaldu bubuk sesuai selera.Masak hingga bumbu pas dilidah."
- "Seduh irisan kol dengan air panas,tiriskan.Tata kol dimangkuk siram dengan kuah soto dan ayam.Beri pelengkap sesuai selera."
categories:
- Resep
tags:
- soto
- ayam
- santan

katakunci: soto ayam santan 
nutrition: 183 calories
recipecuisine: Indonesian
preptime: "PT16M"
cooktime: "PT38M"
recipeyield: "3"
recipecategory: Dinner

---


![Soto Ayam Santan](https://img-global.cpcdn.com/recipes/946a572b200d97e8/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg)

Selaku seorang orang tua, menyuguhkan hidangan lezat untuk keluarga tercinta adalah suatu hal yang menyenangkan untuk anda sendiri. Tanggung jawab seorang  wanita bukan sekedar mengurus rumah saja, namun anda juga harus memastikan keperluan gizi terpenuhi dan hidangan yang disantap anak-anak wajib mantab.

Di era  sekarang, kamu memang mampu mengorder hidangan instan meski tanpa harus capek mengolahnya terlebih dahulu. Tetapi ada juga mereka yang memang mau menyajikan yang terenak untuk orang yang dicintainya. Karena, menghidangkan masakan yang dibuat sendiri jauh lebih bersih dan kita juga bisa menyesuaikan masakan tersebut berdasarkan kesukaan keluarga. 



Mungkinkah kamu seorang penikmat soto ayam santan?. Tahukah kamu, soto ayam santan adalah makanan khas di Nusantara yang sekarang disukai oleh setiap orang di berbagai tempat di Nusantara. Kamu bisa membuat soto ayam santan kreasi sendiri di rumahmu dan boleh jadi camilan kesenanganmu di hari liburmu.

Kalian tidak usah bingung jika kamu ingin memakan soto ayam santan, lantaran soto ayam santan sangat mudah untuk dicari dan juga kalian pun boleh menghidangkannya sendiri di tempatmu. soto ayam santan boleh diolah memalui berbagai cara. Kini telah banyak sekali resep modern yang menjadikan soto ayam santan semakin lebih lezat.

Resep soto ayam santan pun sangat mudah untuk dibuat, lho. Kalian jangan repot-repot untuk membeli soto ayam santan, karena Anda mampu menyajikan ditempatmu. Bagi Anda yang mau menghidangkannya, berikut resep menyajikan soto ayam santan yang enak yang mampu Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Soto Ayam Santan:

1. Ambil 500 gr dada ayam
1. Ambil 1500 ml santan
1. Siapkan 3 lbr daun salam
1. Gunakan 3 lbr daub jeruk
1. Siapkan 2 batang serai,memarkan
1. Siapkan 2 ruas jari lengkuas,memarkan
1. Ambil 2 batang daun bawang potong 2 cm bagian putih (kuskip)
1. Ambil Sesuai selera gula,garam dan kaldu bubuk
1. Ambil  Bumbu halus
1. Sediakan 6 buah bawang merah
1. Ambil 3 siung bawang putih
1. Siapkan 3 btr kemiri sangarai
1. Gunakan 1 ruas jari jahe
1. Sediakan 1/2 sdt ketumba
1. Gunakan 1/2 sdt merica butir
1. Gunakan  Pelengkap
1. Sediakan 1 buah tomat besar,potong kotak kecil
1. Siapkan Sesuai selera irisan daun bawang (kuskip) seledri
1. Sediakan 200 gr kol iris
1. Ambil 1 buah jeruk nipis
1. Sediakan Sesuai selera pelngkap lainya sambal,bawang goreng dan emping




<!--inarticleads2-->

##### Cara membuat Soto Ayam Santan:

1. Potong dada ayam,cuci bersih lumuri dengan air jeruk nipis.Diamkan beberapa saat dan bilas.Goreng hingga agak kecoklatan saja.Kemudian suir suir.
1. 
1. Haluskan bahan bumbu halus.Tumis bumbu halus,daun salam,daun jeruk,serai dan lengkuas.Tumis hingga bumbu matang,beri sedikit air.Matikan api.
1. Masak santan hingga mendidih.Masukkan tumisan bumbu.Aduk selalu agar santan tidak pecah.
1. Masukkan ayam suir,beri bumbu gula,garam dan kaldu bubuk sesuai selera.Masak hingga bumbu pas dilidah.
1. Seduh irisan kol dengan air panas,tiriskan.Tata kol dimangkuk siram dengan kuah soto dan ayam.Beri pelengkap sesuai selera.




Wah ternyata cara buat soto ayam santan yang nikamt sederhana ini mudah sekali ya! Kalian semua dapat menghidangkannya. Resep soto ayam santan Cocok sekali untuk kamu yang sedang belajar memasak maupun bagi kamu yang telah ahli memasak.

Tertarik untuk mencoba bikin resep soto ayam santan lezat sederhana ini? Kalau tertarik, ayo kalian segera menyiapkan peralatan dan bahan-bahannya, maka bikin deh Resep soto ayam santan yang nikmat dan simple ini. Betul-betul taidak sulit kan. 

Maka, ketimbang kita diam saja, maka kita langsung buat resep soto ayam santan ini. Dijamin kalian tak akan menyesal sudah membuat resep soto ayam santan lezat tidak rumit ini! Selamat berkreasi dengan resep soto ayam santan lezat sederhana ini di rumah kalian sendiri,oke!.

