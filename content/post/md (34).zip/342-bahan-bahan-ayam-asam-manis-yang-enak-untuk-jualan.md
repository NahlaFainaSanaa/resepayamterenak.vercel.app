---
description: "Bahan-bahan Ayam asam manis yang enak Untuk Jualan"
title: "Bahan-bahan Ayam asam manis yang enak Untuk Jualan"
slug: 342-bahan-bahan-ayam-asam-manis-yang-enak-untuk-jualan
date: 2021-05-20T15:32:02.151Z
image: https://img-global.cpcdn.com/recipes/894cf634c830c2e3/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/894cf634c830c2e3/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/894cf634c830c2e3/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
author: Sean Lucas
ratingvalue: 3.1
reviewcount: 8
recipeingredient:
- " Marinasi"
- "500 g Ayam boneless and skinless"
- "1 sdt garam"
- "3 sdt gula"
- "3 sdt maizena"
- "2 sdt kecap asin"
- "2 sdt kaldu bubuk totole ayam atau jamur"
- "1 sdt saos tiram"
- " Tepung balur"
- "5 sdm terigu"
- "3 sdm maizena"
- " Bahan saos asam manis"
- "5 sdm saos tomat Indofood"
- "2 sdm saos sambal Indofood"
- "400 ml air"
- "1 sdm sagu aduh dengan sedikit air sekitar 12 tetes saja"
- "1 sdm kecap asin"
- "1 sdm saus tiram"
- "1 sdt garam"
- "2-3 sdm gula sesuai selera"
- "100 gr nanas potong2 dadu kotak"
- "1 sdt kaldu bubuk totole ayam atau jamur"
recipeinstructions:
- "Marinasi seluruh bahan. Diamkan selama 1-2 jam. Sisihkan"
- "Balurkan ayam ke dalam campuran terigu dan maizena. Goreng dengan minyak panas dan banyak hingga kecoklatan. Sisihkan"
- "Tuang air, saos tomat, saos sambal dan masak dengan api kecil. Aduk2, lalu masukkan garam gula totole dan saus tiram serta kecap asin. Aduk rata dan koreksi rasa. Terakhir masukkan sagu yg sdh dilarutkan"
- "Masukkan nanas. Masak sebentar lalu masukkan ayam. Aduk2 dan masak sebentar. Sajikan ❤❤❤"
categories:
- Resep
tags:
- ayam
- asam
- manis

katakunci: ayam asam manis 
nutrition: 242 calories
recipecuisine: Indonesian
preptime: "PT28M"
cooktime: "PT46M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam asam manis](https://img-global.cpcdn.com/recipes/894cf634c830c2e3/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg)

Andai kita seorang orang tua, menyediakan olahan sedap kepada keluarga adalah hal yang membahagiakan bagi anda sendiri. Peran seorang ibu Tidak cuman mengerjakan pekerjaan rumah saja, tapi anda juga harus memastikan kebutuhan nutrisi tercukupi dan juga hidangan yang disantap orang tercinta mesti mantab.

Di era  saat ini, kalian memang bisa mengorder masakan yang sudah jadi tidak harus repot mengolahnya dulu. Namun ada juga lho mereka yang selalu ingin menghidangkan yang terbaik untuk keluarganya. Pasalnya, menghidangkan masakan sendiri jauh lebih higienis dan kita pun bisa menyesuaikan sesuai makanan kesukaan keluarga tercinta. 



Mungkinkah anda seorang penyuka ayam asam manis?. Tahukah kamu, ayam asam manis adalah sajian khas di Indonesia yang saat ini disukai oleh banyak orang di berbagai daerah di Indonesia. Kalian dapat menyajikan ayam asam manis hasil sendiri di rumahmu dan boleh dijadikan makanan kesenanganmu di hari liburmu.

Kalian jangan bingung untuk mendapatkan ayam asam manis, sebab ayam asam manis mudah untuk ditemukan dan juga kalian pun bisa menghidangkannya sendiri di rumah. ayam asam manis dapat dibuat memalui bermacam cara. Saat ini ada banyak banget cara kekinian yang menjadikan ayam asam manis semakin lebih mantap.

Resep ayam asam manis pun sangat gampang untuk dibuat, lho. Kamu tidak usah repot-repot untuk membeli ayam asam manis, lantaran Anda bisa menghidangkan ditempatmu. Bagi Anda yang hendak menyajikannya, dibawah ini merupakan resep untuk membuat ayam asam manis yang enak yang mampu Anda coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Ayam asam manis:

1. Ambil  Marinasi
1. Sediakan 500 g Ayam boneless and skinless
1. Gunakan 1 sdt garam
1. Ambil 3 sdt gula
1. Siapkan 3 sdt maizena
1. Ambil 2 sdt kecap asin
1. Siapkan 2 sdt kaldu bubuk totole (ayam atau jamur)
1. Gunakan 1 sdt saos tiram
1. Sediakan  Tepung balur
1. Ambil 5 sdm terigu
1. Gunakan 3 sdm maizena
1. Siapkan  Bahan saos asam manis
1. Siapkan 5 sdm saos tomat Indofood
1. Ambil 2 sdm saos sambal Indofood
1. Ambil 400 ml air
1. Sediakan 1 sdm sagu (aduh dengan sedikit air, sekitar 1-2 tetes saja)
1. Ambil 1 sdm kecap asin
1. Sediakan 1 sdm saus tiram
1. Ambil 1 sdt garam
1. Ambil 2-3 sdm gula (sesuai selera)
1. Sediakan 100 gr nanas potong2 dadu kotak
1. Ambil 1 sdt kaldu bubuk totole (ayam atau jamur)




<!--inarticleads2-->

##### Cara menyiapkan Ayam asam manis:

1. Marinasi seluruh bahan. Diamkan selama 1-2 jam. Sisihkan
1. Balurkan ayam ke dalam campuran terigu dan maizena. Goreng dengan minyak panas dan banyak hingga kecoklatan. Sisihkan
1. Tuang air, saos tomat, saos sambal dan masak dengan api kecil. Aduk2, lalu masukkan garam gula totole dan saus tiram serta kecap asin. Aduk rata dan koreksi rasa. Terakhir masukkan sagu yg sdh dilarutkan
1. Masukkan nanas. Masak sebentar lalu masukkan ayam. Aduk2 dan masak sebentar. Sajikan ❤❤❤




Ternyata cara membuat ayam asam manis yang mantab sederhana ini mudah banget ya! Semua orang dapat membuatnya. Resep ayam asam manis Sesuai banget untuk kalian yang baru belajar memasak atau juga untuk anda yang sudah ahli memasak.

Apakah kamu ingin mulai mencoba membikin resep ayam asam manis mantab tidak rumit ini? Kalau anda tertarik, yuk kita segera siapin alat dan bahan-bahannya, lantas bikin deh Resep ayam asam manis yang enak dan tidak ribet ini. Sangat taidak sulit kan. 

Maka dari itu, ketimbang kita diam saja, yuk langsung aja bikin resep ayam asam manis ini. Dijamin anda gak akan menyesal membuat resep ayam asam manis mantab tidak ribet ini! Selamat mencoba dengan resep ayam asam manis enak tidak rumit ini di rumah masing-masing,oke!.

