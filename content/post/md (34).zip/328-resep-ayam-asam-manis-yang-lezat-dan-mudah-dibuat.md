---
description: "Resep Ayam Asam Manis yang lezat dan Mudah Dibuat"
title: "Resep Ayam Asam Manis yang lezat dan Mudah Dibuat"
slug: 328-resep-ayam-asam-manis-yang-lezat-dan-mudah-dibuat
date: 2021-04-22T22:15:46.621Z
image: https://img-global.cpcdn.com/recipes/be421ad8904051db/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/be421ad8904051db/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/be421ad8904051db/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
author: Jonathan Watkins
ratingvalue: 3
reviewcount: 15
recipeingredient:
- "500 gram kakap merah potong fillet aku ganti ayam dada fillet"
- "1 butir telur"
- "1 bungkus Kobe Tepung Bumbu Putih 210 gr"
- "secukupnya minyak goreng"
- "  Bahan Saus Asam Manis "
- "1 buah bawang bombay"
- "100 ml air"
- "5 sendok makan saus tomat"
- "secukupnya gula"
- "secukupnya garam"
- "50 gram wortel dipotong lidi"
- "1 sendok makan Kobe Tepung Bumbu Putih"
- "secukupnya air"
- "50 gram nanas potong sesuai ruas aku skip"
- "2 batang daun bawang"
recipeinstructions:
- "Cuci bersih ayam fillet, tiriskan."
- "Kocok lepas 1 butir telur."
- "Masukan ayam fillet kakap ke dalam kocokan telur dan balur dengan Kobe Tepung Bumbu Putih hingga semua bagian tertutup."
- "Goreng di dalam minyak panas dengan api sedang hingga berwarna kuning kecoklatan dan matang."
- "&gt;&gt; Cara membuat Saus Asam Manis : Tumis bawang bombay hingga layu."
- "Masukan air, saus tomat, gula dan garam."
- "Tambahkan wortel kemudian aduk hingga rata."
- "Tambahkan larutan 1 sendok makan Kobe Tepung Bumbu Putih dengan sedikit air sebagai pengental."
- "Matikan api kemudian masukan daun bawang. Sajikan"
categories:
- Resep
tags:
- ayam
- asam
- manis

katakunci: ayam asam manis 
nutrition: 195 calories
recipecuisine: Indonesian
preptime: "PT23M"
cooktime: "PT55M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam Asam Manis](https://img-global.cpcdn.com/recipes/be421ad8904051db/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg)

Sebagai seorang wanita, menyediakan panganan lezat untuk orang tercinta adalah hal yang sangat menyenangkan bagi kita sendiri. Tugas seorang ibu bukan sekadar mengatur rumah saja, tapi kamu pun wajib memastikan keperluan nutrisi terpenuhi dan juga panganan yang dimakan anak-anak wajib menggugah selera.

Di era  saat ini, kamu memang bisa mengorder hidangan siap saji tidak harus capek membuatnya dulu. Tapi ada juga lho mereka yang selalu mau memberikan hidangan yang terlezat untuk orang tercintanya. Karena, memasak yang diolah sendiri jauh lebih bersih dan kita juga bisa menyesuaikan sesuai makanan kesukaan keluarga. 



Apakah kamu salah satu penikmat ayam asam manis?. Tahukah kamu, ayam asam manis merupakan makanan khas di Nusantara yang kini disukai oleh kebanyakan orang di hampir setiap daerah di Nusantara. Kalian dapat menghidangkan ayam asam manis sendiri di rumah dan dapat dijadikan santapan favorit di akhir pekanmu.

Kamu tak perlu bingung jika kamu ingin mendapatkan ayam asam manis, sebab ayam asam manis mudah untuk ditemukan dan juga anda pun boleh memasaknya sendiri di rumah. ayam asam manis dapat diolah dengan beraneka cara. Sekarang sudah banyak sekali cara kekinian yang membuat ayam asam manis lebih lezat.

Resep ayam asam manis pun mudah sekali dihidangkan, lho. Anda tidak perlu ribet-ribet untuk memesan ayam asam manis, lantaran Kalian dapat membuatnya di rumahmu. Untuk Anda yang ingin mencobanya, berikut resep untuk menyajikan ayam asam manis yang lezat yang mampu Anda hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Ayam Asam Manis:

1. Gunakan 500 gram kakap merah, potong fillet (aku ganti ayam dada fillet)
1. Sediakan 1 butir telur
1. Gunakan 1 bungkus Kobe Tepung Bumbu Putih (210 gr)
1. Sediakan secukupnya minyak goreng
1. Gunakan  &gt;&gt; Bahan Saus Asam Manis :
1. Sediakan 1 buah bawang bombay
1. Gunakan 100 ml air
1. Sediakan 5 sendok makan saus tomat
1. Siapkan secukupnya gula
1. Gunakan secukupnya garam
1. Gunakan 50 gram wortel (dipotong lidi)
1. Siapkan 1 sendok makan Kobe Tepung Bumbu Putih
1. Gunakan secukupnya air
1. Siapkan 50 gram nanas, potong sesuai ruas (aku skip)
1. Ambil 2 batang daun bawang




<!--inarticleads2-->

##### Cara membuat Ayam Asam Manis:

1. Cuci bersih ayam fillet, tiriskan.
1. Kocok lepas 1 butir telur.
1. Masukan ayam fillet kakap ke dalam kocokan telur dan balur dengan Kobe Tepung Bumbu Putih hingga semua bagian tertutup.
1. Goreng di dalam minyak panas dengan api sedang hingga berwarna kuning kecoklatan dan matang.
1. &gt;&gt; Cara membuat Saus Asam Manis : Tumis bawang bombay hingga layu.
1. Masukan air, saus tomat, gula dan garam.
1. Tambahkan wortel kemudian aduk hingga rata.
1. Tambahkan larutan 1 sendok makan Kobe Tepung Bumbu Putih dengan sedikit air sebagai pengental.
1. Matikan api kemudian masukan daun bawang. Sajikan




Ternyata cara membuat ayam asam manis yang lezat simple ini gampang banget ya! Kalian semua dapat mencobanya. Cara Membuat ayam asam manis Sangat cocok sekali buat kita yang baru akan belajar memasak ataupun juga bagi kamu yang sudah jago memasak.

Apakah kamu tertarik mencoba buat resep ayam asam manis lezat tidak rumit ini? Kalau tertarik, yuk kita segera buruan menyiapkan alat dan bahan-bahannya, maka bikin deh Resep ayam asam manis yang lezat dan sederhana ini. Benar-benar taidak sulit kan. 

Jadi, ketimbang kita berlama-lama, yuk langsung aja buat resep ayam asam manis ini. Pasti kamu tak akan nyesel sudah membuat resep ayam asam manis mantab tidak ribet ini! Selamat mencoba dengan resep ayam asam manis mantab tidak rumit ini di tempat tinggal sendiri,oke!.

