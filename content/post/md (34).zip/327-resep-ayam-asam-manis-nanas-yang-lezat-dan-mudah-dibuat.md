---
description: "Resep Ayam Asam Manis Nanas yang lezat dan Mudah Dibuat"
title: "Resep Ayam Asam Manis Nanas yang lezat dan Mudah Dibuat"
slug: 327-resep-ayam-asam-manis-nanas-yang-lezat-dan-mudah-dibuat
date: 2021-06-03T13:33:51.100Z
image: https://img-global.cpcdn.com/recipes/d8d9b6a948afa933/680x482cq70/ayam-asam-manis-nanas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d8d9b6a948afa933/680x482cq70/ayam-asam-manis-nanas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d8d9b6a948afa933/680x482cq70/ayam-asam-manis-nanas-foto-resep-utama.jpg
author: Derrick Burke
ratingvalue: 4.6
reviewcount: 3
recipeingredient:
- "300 gr dada ayam fillet potong dadu"
- "5 sdm tepung serbaguna"
- "4 sdm tepung maizena"
- "2 sdm tepung serbaguna dilarutkan dalam 150200 ml air"
- "1 bh wortel potong korek api"
- "1 bh bawang bombay ukuran kecil potong"
- "2 siung bawang putih cincang"
- "potong Nanas kupas secukupnya"
- " Bahan saus "
- "3 sdm saus tomat"
- "1 sdm saus sambal"
- "1 sdm kecap asin"
- "1 sdm kecap manis"
- "1/2 sdt lada bubuk"
- "1/2 sdt garam"
- "1 sdt kaldu ayam bubukkaldu jamur"
- "300 ml air"
- "1/2 sdm tepung maizena dilarutkan dlm 2 sdm air"
recipeinstructions:
- "Campur tepung serbaguna dan maizena, sisihkan. Masukkan potongan daging ayam dalam adonan tepung, biarkan 5-10 menit. Panaskan minyak, celupkan ayam dari adonan basah ke adonan tepung kering, lalu goreng hingga matang/kuning kecoklatan, dengan api sedang cenderung kecil."
- "Tumis bawang bombay hingga layu, masukkan bawang putih, tumis hingga harum. Masukkan wortel, nanas, saus dan bumbu lainnya, tambahkan air, koreksi rasanya."
- "Masukkan ayam, aduk rata, masukkan larutan maizena, lalu aduk rata kembali. Siap disajikan."
categories:
- Resep
tags:
- ayam
- asam
- manis

katakunci: ayam asam manis 
nutrition: 292 calories
recipecuisine: Indonesian
preptime: "PT15M"
cooktime: "PT34M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam Asam Manis Nanas](https://img-global.cpcdn.com/recipes/d8d9b6a948afa933/680x482cq70/ayam-asam-manis-nanas-foto-resep-utama.jpg)

Sebagai seorang wanita, mempersiapkan olahan mantab pada keluarga tercinta merupakan hal yang memuaskan bagi kita sendiri. Tugas seorang istri bukan sekedar menjaga rumah saja, tapi kamu juga wajib memastikan keperluan gizi terpenuhi dan hidangan yang disantap keluarga tercinta mesti enak.

Di zaman  sekarang, kita sebenarnya dapat memesan olahan yang sudah jadi meski tanpa harus capek membuatnya dulu. Tetapi ada juga mereka yang selalu ingin memberikan yang terbaik untuk keluarganya. Karena, menyajikan masakan sendiri jauh lebih bersih dan kita juga bisa menyesuaikan makanan tersebut sesuai dengan makanan kesukaan orang tercinta. 



Apakah anda adalah salah satu penikmat ayam asam manis nanas?. Asal kamu tahu, ayam asam manis nanas adalah makanan khas di Nusantara yang kini disukai oleh banyak orang di berbagai daerah di Nusantara. Anda dapat menyajikan ayam asam manis nanas sendiri di rumah dan pasti jadi camilan kegemaranmu di akhir pekan.

Kita tak perlu bingung jika kamu ingin mendapatkan ayam asam manis nanas, sebab ayam asam manis nanas sangat mudah untuk ditemukan dan kamu pun bisa membuatnya sendiri di rumah. ayam asam manis nanas dapat diolah lewat beragam cara. Kini sudah banyak banget resep modern yang menjadikan ayam asam manis nanas lebih lezat.

Resep ayam asam manis nanas juga sangat gampang dibuat, lho. Kalian jangan ribet-ribet untuk memesan ayam asam manis nanas, tetapi Kalian dapat menyiapkan di rumah sendiri. Untuk Kamu yang hendak menghidangkannya, berikut resep untuk menyajikan ayam asam manis nanas yang mantab yang dapat Kamu buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Ayam Asam Manis Nanas:

1. Siapkan 300 gr dada ayam fillet, potong dadu
1. Gunakan 5 sdm tepung serbaguna
1. Ambil 4 sdm tepung maizena
1. Siapkan 2 sdm tepung serbaguna, dilarutkan dalam 150-200 ml air
1. Siapkan 1 bh wortel, potong korek api
1. Sediakan 1 bh bawang bombay ukuran kecil, potong
1. Sediakan 2 siung bawang putih, cincang
1. Ambil potong Nanas kupas secukupnya,
1. Gunakan  Bahan saus :
1. Siapkan 3 sdm saus tomat
1. Gunakan 1 sdm saus sambal
1. Siapkan 1 sdm kecap asin
1. Gunakan 1 sdm kecap manis
1. Ambil 1/2 sdt lada bubuk
1. Gunakan 1/2 sdt garam
1. Ambil 1 sdt kaldu ayam bubuk/kaldu jamur
1. Gunakan 300 ml air
1. Ambil 1/2 sdm tepung maizena, dilarutkan dlm 2 sdm air




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Asam Manis Nanas:

1. Campur tepung serbaguna dan maizena, sisihkan. Masukkan potongan daging ayam dalam adonan tepung, biarkan 5-10 menit. Panaskan minyak, celupkan ayam dari adonan basah ke adonan tepung kering, lalu goreng hingga matang/kuning kecoklatan, dengan api sedang cenderung kecil.
1. Tumis bawang bombay hingga layu, masukkan bawang putih, tumis hingga harum. Masukkan wortel, nanas, saus dan bumbu lainnya, tambahkan air, koreksi rasanya.
1. Masukkan ayam, aduk rata, masukkan larutan maizena, lalu aduk rata kembali. Siap disajikan.




Ternyata cara buat ayam asam manis nanas yang enak sederhana ini gampang sekali ya! Kita semua bisa membuatnya. Cara Membuat ayam asam manis nanas Sangat cocok banget buat anda yang baru akan belajar memasak ataupun juga bagi kamu yang telah pandai dalam memasak.

Apakah kamu tertarik mulai mencoba buat resep ayam asam manis nanas nikmat simple ini? Kalau kalian ingin, ayo kamu segera siapkan alat-alat dan bahannya, maka buat deh Resep ayam asam manis nanas yang mantab dan simple ini. Benar-benar taidak sulit kan. 

Maka dari itu, ketimbang kita berfikir lama-lama, yuk kita langsung hidangkan resep ayam asam manis nanas ini. Dijamin kalian gak akan menyesal membuat resep ayam asam manis nanas nikmat sederhana ini! Selamat berkreasi dengan resep ayam asam manis nanas nikmat simple ini di rumah sendiri,ya!.

