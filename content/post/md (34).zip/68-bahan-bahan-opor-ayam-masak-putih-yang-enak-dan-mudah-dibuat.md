---
description: "Bahan-bahan Opor Ayam Masak Putih yang enak dan Mudah Dibuat"
title: "Bahan-bahan Opor Ayam Masak Putih yang enak dan Mudah Dibuat"
slug: 68-bahan-bahan-opor-ayam-masak-putih-yang-enak-dan-mudah-dibuat
date: 2021-01-25T03:16:05.563Z
image: https://img-global.cpcdn.com/recipes/1fd3590f43122e26/680x482cq70/opor-ayam-masak-putih-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1fd3590f43122e26/680x482cq70/opor-ayam-masak-putih-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1fd3590f43122e26/680x482cq70/opor-ayam-masak-putih-foto-resep-utama.jpg
author: Walter Scott
ratingvalue: 3.3
reviewcount: 11
recipeingredient:
- "1 kg ayampotong jadi 10 bagian"
- "300 ml santan kental dari 1 butir kelapa"
- "700 ml santan encer dari sisa perasan kelapa tadi"
- "5 lembar daun jerukbuang tulang daunnya"
- "3 lembar daun salam"
- "2 batang seraimemarkan"
- "3 cm lengkuasmemarkan"
- "2 1/2 sdt garam"
- "1/4 sdt merica bubuk"
- "1/2 sdt gula pasir"
- "2 sdm minyak goreng"
- " Jeruk nipis"
- " Bawang goreng untuk taburan"
- " Bumbu yang dihaluskan "
- "10 siung bawang merah"
- "4 siung bawang putih"
- "2 sdt ketumbarsangrai"
- "1/4 sdt jintensangrai"
- "2 cm jahe"
recipeinstructions:
- "Ayam dicuci bersih,lalu lumuri air perasan jeruk nipis,diamkan sebentar,lalu dicuci lagi sampai bersih,sisihkan."
- "Panaskan minyak,tumis bumbu halus,daun jeruk,daun salam,lengkuas dan serai sampai harum,masukkan ayam,aduk rata sampai berubah warna."
- "Tambahkan garam,merica dan gula pasir,aduk rata,tuang santan encer,masak sampai mendidih dan ayam matang,masukkan santan kental,aduk2 sampai santan mendidih,koreksi rasa."
- "Masak sampai matang dan mengental,angkat dan siap dihidangkan dengan taburan bawang goreng."
categories:
- Resep
tags:
- opor
- ayam
- masak

katakunci: opor ayam masak 
nutrition: 195 calories
recipecuisine: Indonesian
preptime: "PT11M"
cooktime: "PT35M"
recipeyield: "2"
recipecategory: Dessert

---


![Opor Ayam Masak Putih](https://img-global.cpcdn.com/recipes/1fd3590f43122e26/680x482cq70/opor-ayam-masak-putih-foto-resep-utama.jpg)

Selaku seorang istri, menyuguhkan masakan nikmat buat orang tercinta merupakan suatu hal yang sangat menyenangkan untuk kamu sendiri. Tanggung jawab seorang  wanita Tidak sekadar mengatur rumah saja, tetapi kamu pun harus menyediakan kebutuhan gizi tercukupi dan santapan yang dimakan keluarga tercinta wajib menggugah selera.

Di masa  saat ini, kita sebenarnya mampu memesan hidangan siap saji tidak harus repot membuatnya terlebih dahulu. Namun ada juga lho mereka yang selalu ingin menyajikan yang terbaik untuk orang yang dicintainya. Lantaran, memasak yang diolah sendiri jauh lebih higienis dan kita juga bisa menyesuaikan masakan tersebut sesuai dengan makanan kesukaan famili. 



Apakah anda seorang penyuka opor ayam masak putih?. Asal kamu tahu, opor ayam masak putih merupakan hidangan khas di Indonesia yang sekarang disukai oleh kebanyakan orang di berbagai tempat di Indonesia. Kalian dapat membuat opor ayam masak putih hasil sendiri di rumah dan boleh jadi makanan favorit di akhir pekan.

Anda tidak perlu bingung untuk memakan opor ayam masak putih, sebab opor ayam masak putih tidak sulit untuk dicari dan kita pun boleh menghidangkannya sendiri di rumah. opor ayam masak putih boleh dibuat dengan beragam cara. Kini telah banyak sekali resep kekinian yang menjadikan opor ayam masak putih semakin mantap.

Resep opor ayam masak putih juga mudah sekali dihidangkan, lho. Anda tidak usah capek-capek untuk membeli opor ayam masak putih, sebab Kalian bisa membuatnya di rumahmu. Untuk Anda yang mau menyajikannya, inilah cara untuk menyajikan opor ayam masak putih yang lezat yang bisa Kalian coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Opor Ayam Masak Putih:

1. Ambil 1 kg ayam,potong jadi 10 bagian
1. Ambil 300 ml santan kental dari 1 butir kelapa
1. Ambil 700 ml santan encer dari sisa perasan kelapa tadi
1. Siapkan 5 lembar daun jeruk,buang tulang daunnya
1. Ambil 3 lembar daun salam
1. Ambil 2 batang serai,memarkan
1. Gunakan 3 cm lengkuas,memarkan
1. Siapkan 2 1/2 sdt garam
1. Gunakan 1/4 sdt merica bubuk
1. Sediakan 1/2 sdt gula pasir
1. Siapkan 2 sdm minyak goreng
1. Ambil  Jeruk nipis
1. Gunakan  Bawang goreng untuk taburan
1. Gunakan  Bumbu yang dihaluskan :
1. Gunakan 10 siung bawang merah
1. Gunakan 4 siung bawang putih
1. Ambil 2 sdt ketumbar,sangrai
1. Sediakan 1/4 sdt jinten,sangrai
1. Siapkan 2 cm jahe




<!--inarticleads2-->

##### Cara menyiapkan Opor Ayam Masak Putih:

1. Ayam dicuci bersih,lalu lumuri air perasan jeruk nipis,diamkan sebentar,lalu dicuci lagi sampai bersih,sisihkan.
1. Panaskan minyak,tumis bumbu halus,daun jeruk,daun salam,lengkuas dan serai sampai harum,masukkan ayam,aduk rata sampai berubah warna.
1. Tambahkan garam,merica dan gula pasir,aduk rata,tuang santan encer,masak sampai mendidih dan ayam matang,masukkan santan kental,aduk2 sampai santan mendidih,koreksi rasa.
1. Masak sampai matang dan mengental,angkat dan siap dihidangkan dengan taburan bawang goreng.




Ternyata resep opor ayam masak putih yang enak sederhana ini gampang banget ya! Kalian semua dapat menghidangkannya. Cara buat opor ayam masak putih Cocok sekali buat kita yang sedang belajar memasak maupun juga bagi kamu yang telah lihai memasak.

Tertarik untuk mencoba membuat resep opor ayam masak putih enak tidak ribet ini? Kalau kamu ingin, ayo kamu segera siapin alat-alat dan bahan-bahannya, maka buat deh Resep opor ayam masak putih yang lezat dan tidak rumit ini. Benar-benar mudah kan. 

Oleh karena itu, daripada kalian berfikir lama-lama, hayo kita langsung saja buat resep opor ayam masak putih ini. Pasti kalian tiidak akan nyesel sudah bikin resep opor ayam masak putih nikmat tidak ribet ini! Selamat berkreasi dengan resep opor ayam masak putih nikmat simple ini di tempat tinggal kalian sendiri,ya!.

