---
description: "Cara buat Soto Ayam Santan ala Violet Azalea yang nikmat dan Mudah Dibuat"
title: "Cara buat Soto Ayam Santan ala Violet Azalea yang nikmat dan Mudah Dibuat"
slug: 390-cara-buat-soto-ayam-santan-ala-violet-azalea-yang-nikmat-dan-mudah-dibuat
date: 2021-06-28T09:16:41.031Z
image: https://img-global.cpcdn.com/recipes/caf88f91f56c7237/680x482cq70/soto-ayam-santan-ala-violet-azalea-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/caf88f91f56c7237/680x482cq70/soto-ayam-santan-ala-violet-azalea-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/caf88f91f56c7237/680x482cq70/soto-ayam-santan-ala-violet-azalea-foto-resep-utama.jpg
author: Myra McCoy
ratingvalue: 4
reviewcount: 14
recipeingredient:
- "1 ekor ayam 15 kg"
- "1 1/2 liter air"
- "2 liter santan kekentalan sedang"
- "4 buah tomat ukuran besar potong"
- "2 batang serai geprek"
- "2 ruas jari lengkuas geprek"
- "5 lembar daun jeruk"
- "4 lembar daun salam"
- "secukupnya garam"
- "1 sachet kaldu bubuk rasa ayam"
- "secukupnya vetsin"
- "1 sdm gula pasir"
- " Bumbu Halus "
- "8 siung bawang merah"
- "5 siung bawang putih"
- "2 1/2 ruas jari kunyit bakar kupas kulit arinya"
- "1 1/2 ruas jahe"
- "4 buah kemiri sangrai"
- "1 sdm ketumbar butiran sangrai"
- " Pelengkap "
- " Perkedel Singkong           lihat resep"
- " Sambal           lihat resep"
- " Bawang goreng"
- "iris Daun bawang"
recipeinstructions:
- "Tumis bumbu halus, daun jeruk, daun salam, lengkuas dan serai hingga harum dan matang. Sisihkan."
- "Di dalam sebuah panci rebus ayam dan air. Masak hingga ayam lunak dan daging terlihat agak terlepas dari tulang. Beri santan dan tumisan bumbu."
- "Bumbui dengan kaldu bubuk rasa ayam, garam, vetsin dan gula. Aduk terus ya agar santan tak terpecah. Sesaat sebelum diangkat masukkan tomat iris. Angkat."
- "Angkat ayam. Tiriskan. Goreng sejenak saja di api besar cukup hingga agak nyoklat sedikit. Tidak usah sampai kering. Suwir-suwir daging ayam. Sisihkan."
- "Di dalam piring sendok nasi hangat. Sendokkan kuah ke dalam piring berisi nasi. Sajikan dengan pelengkap."
categories:
- Resep
tags:
- soto
- ayam
- santan

katakunci: soto ayam santan 
nutrition: 102 calories
recipecuisine: Indonesian
preptime: "PT33M"
cooktime: "PT38M"
recipeyield: "3"
recipecategory: Dinner

---


![Soto Ayam Santan ala Violet Azalea](https://img-global.cpcdn.com/recipes/caf88f91f56c7237/680x482cq70/soto-ayam-santan-ala-violet-azalea-foto-resep-utama.jpg)

Selaku seorang orang tua, menyediakan hidangan mantab pada famili merupakan suatu hal yang membahagiakan untuk anda sendiri. Tanggung jawab seorang ibu bukan saja mengatur rumah saja, namun anda pun wajib memastikan kebutuhan nutrisi tercukupi dan panganan yang dikonsumsi keluarga tercinta harus nikmat.

Di masa  saat ini, kita memang bisa memesan panganan siap saji meski tidak harus susah mengolahnya terlebih dahulu. Tetapi ada juga mereka yang selalu ingin menyajikan yang terenak bagi orang yang dicintainya. Pasalnya, menghidangkan masakan yang diolah sendiri jauh lebih bersih dan bisa menyesuaikan makanan tersebut sesuai kesukaan keluarga. 



Mungkinkah kamu salah satu penyuka soto ayam santan ala violet azalea?. Tahukah kamu, soto ayam santan ala violet azalea adalah makanan khas di Indonesia yang sekarang disukai oleh setiap orang dari berbagai daerah di Nusantara. Kamu dapat menghidangkan soto ayam santan ala violet azalea sendiri di rumahmu dan boleh dijadikan makanan kesukaanmu di akhir pekanmu.

Anda jangan bingung jika kamu ingin menyantap soto ayam santan ala violet azalea, sebab soto ayam santan ala violet azalea gampang untuk dicari dan juga anda pun dapat mengolahnya sendiri di tempatmu. soto ayam santan ala violet azalea boleh diolah lewat berbagai cara. Saat ini ada banyak sekali resep modern yang membuat soto ayam santan ala violet azalea lebih mantap.

Resep soto ayam santan ala violet azalea juga gampang dibikin, lho. Kamu jangan capek-capek untuk membeli soto ayam santan ala violet azalea, lantaran Kamu mampu membuatnya di rumah sendiri. Bagi Kalian yang ingin menghidangkannya, berikut ini resep untuk menyajikan soto ayam santan ala violet azalea yang nikamat yang bisa Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Soto Ayam Santan ala Violet Azalea:

1. Siapkan 1 ekor ayam (1,5 kg)
1. Sediakan 1 1/2 liter air
1. Siapkan 2 liter santan kekentalan sedang
1. Sediakan 4 buah tomat ukuran besar, potong
1. Ambil 2 batang serai, geprek
1. Siapkan 2 ruas jari lengkuas, geprek
1. Gunakan 5 lembar daun jeruk
1. Siapkan 4 lembar daun salam
1. Ambil secukupnya garam
1. Siapkan 1 sachet kaldu bubuk rasa ayam
1. Ambil secukupnya vetsin
1. Gunakan 1 sdm gula pasir
1. Ambil  Bumbu Halus :
1. Sediakan 8 siung bawang merah
1. Ambil 5 siung bawang putih
1. Siapkan 2 1/2 ruas jari kunyit, bakar, kupas kulit arinya
1. Sediakan 1 1/2 ruas jahe
1. Sediakan 4 buah kemiri, sangrai
1. Siapkan 1 sdm ketumbar butiran, sangrai
1. Ambil  Pelengkap :
1. Sediakan  Perkedel Singkong           (lihat resep)
1. Ambil  Sambal           (lihat resep)
1. Sediakan  Bawang goreng
1. Ambil iris Daun bawang




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Soto Ayam Santan ala Violet Azalea:

1. Tumis bumbu halus, daun jeruk, daun salam, lengkuas dan serai hingga harum dan matang. Sisihkan.
1. Di dalam sebuah panci rebus ayam dan air. Masak hingga ayam lunak dan daging terlihat agak terlepas dari tulang. Beri santan dan tumisan bumbu.
1. Bumbui dengan kaldu bubuk rasa ayam, garam, vetsin dan gula. Aduk terus ya agar santan tak terpecah. Sesaat sebelum diangkat masukkan tomat iris. Angkat.
1. Angkat ayam. Tiriskan. Goreng sejenak saja di api besar cukup hingga agak nyoklat sedikit. Tidak usah sampai kering. Suwir-suwir daging ayam. Sisihkan.
1. Di dalam piring sendok nasi hangat. Sendokkan kuah ke dalam piring berisi nasi. Sajikan dengan pelengkap.




Ternyata cara buat soto ayam santan ala violet azalea yang mantab tidak rumit ini mudah sekali ya! Semua orang bisa mencobanya. Resep soto ayam santan ala violet azalea Sangat cocok sekali buat kita yang baru belajar memasak maupun untuk kamu yang telah jago memasak.

Tertarik untuk mulai mencoba membuat resep soto ayam santan ala violet azalea enak sederhana ini? Kalau anda tertarik, mending kamu segera siapin peralatan dan bahan-bahannya, setelah itu buat deh Resep soto ayam santan ala violet azalea yang mantab dan tidak rumit ini. Betul-betul mudah kan. 

Jadi, daripada kamu diam saja, hayo kita langsung hidangkan resep soto ayam santan ala violet azalea ini. Pasti kamu tak akan nyesel sudah membuat resep soto ayam santan ala violet azalea nikmat tidak ribet ini! Selamat berkreasi dengan resep soto ayam santan ala violet azalea nikmat tidak rumit ini di tempat tinggal sendiri,ya!.

