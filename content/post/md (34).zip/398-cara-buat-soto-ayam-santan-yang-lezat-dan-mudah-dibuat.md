---
description: "Cara buat Soto ayam Santan yang lezat dan Mudah Dibuat"
title: "Cara buat Soto ayam Santan yang lezat dan Mudah Dibuat"
slug: 398-cara-buat-soto-ayam-santan-yang-lezat-dan-mudah-dibuat
date: 2021-01-24T06:23:52.018Z
image: https://img-global.cpcdn.com/recipes/8083989092a49298/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8083989092a49298/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8083989092a49298/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
author: Harold Hart
ratingvalue: 4.2
reviewcount: 10
recipeingredient:
- "2 potong ayam"
- "500 ml air"
- "50 gr tauge siangi"
- "1/2 buah kol iris"
- "1 batang daun bawang iris"
- "4 lembar daun salam"
- "3 lembar daun jeruk"
- "1 batang serai geprek"
- "500 ml santan"
- "1 buah telur rebus potong 4bagian"
- "2 sdm bawang goreng"
- "1 buah kentang ukuran besarsedang goreng"
- " Bumbu halus "
- "5 siung bawang merah"
- "4 siung bawang putih"
- "2 buah kemiri"
- "2 cm jahe"
- "2 cm kunyit"
- "Secukupnya lada dan merica bubuk"
- "Secukupnya gula"
- "Secukupnya garam"
- "Secukupnya minyak goreng"
recipeinstructions:
- "Siapkan panci dan didihkan air bersama ayam atau tulang ayam untuk membuat kuah kaldu. Tunggu ayam hingga empuk dan kaldu mendidih. Sementara menunggu ayam matang, haluskan bumbu halus kemudian tumis hingga harum dan matang."
- "Angkat ayam dari dalam rebusan jika sudah matang, lalu sisihkan. Kemudian, masukkan bumbu yang sudah di tumis kedalam kaldu aduk-aduk hingga tercampur rata. Masukkan juga gula, garam, lada, serai, daun salam, daun jeruk, dan daun bawang."
- "Aduk lagi hingga tercampur rata, dan terakhir masukkan santan dan aduk-aduk agar santan tidak pecah selama di masak. Kemudian cek rasa. Jika di rasa sudah pas, sisihkan dahulu."
- "Goreng ayam(suwir2) dan kentang bergantian hingga benar-benar matang dan kecoklatan. Terakhir, sajikan soto bersama tauge, kol, kentang goreng, lalu tuangkan kuah soto dan tambahkan telur rebus serta bawang goreng."
categories:
- Resep
tags:
- soto
- ayam
- santan

katakunci: soto ayam santan 
nutrition: 289 calories
recipecuisine: Indonesian
preptime: "PT31M"
cooktime: "PT38M"
recipeyield: "4"
recipecategory: Lunch

---


![Soto ayam Santan](https://img-global.cpcdn.com/recipes/8083989092a49298/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg)

Sebagai seorang istri, menyediakan olahan enak bagi keluarga tercinta adalah hal yang memuaskan untuk kita sendiri. Tugas seorang ibu bukan hanya mengatur rumah saja, namun anda juga harus memastikan keperluan nutrisi terpenuhi dan juga masakan yang disantap keluarga tercinta wajib enak.

Di era  sekarang, kalian sebenarnya mampu membeli santapan yang sudah jadi meski tidak harus repot memasaknya dahulu. Tetapi ada juga mereka yang selalu mau memberikan makanan yang terlezat untuk orang tercintanya. Sebab, menyajikan masakan yang dibuat sendiri jauh lebih higienis dan kita juga bisa menyesuaikan berdasarkan makanan kesukaan keluarga tercinta. 

Resep Soto Ayam Santan Gurih Pedas Sederhana Spesial Asli Enak. Soto ayam berkuah santan dengan warna kuning dikenal di daerah Bogor dan Medan. Soto ini memakai bumbu kuning dan santan sehingga rasanya gurih berempah.

Mungkinkah anda seorang penikmat soto ayam santan?. Asal kamu tahu, soto ayam santan merupakan sajian khas di Nusantara yang kini disukai oleh orang-orang dari berbagai tempat di Indonesia. Anda dapat memasak soto ayam santan sendiri di rumahmu dan pasti jadi camilan kesenanganmu di akhir pekan.

Anda jangan bingung untuk memakan soto ayam santan, karena soto ayam santan tidak sulit untuk dicari dan juga kalian pun bisa memasaknya sendiri di tempatmu. soto ayam santan boleh dimasak dengan beraneka cara. Kini pun sudah banyak resep modern yang membuat soto ayam santan lebih nikmat.

Resep soto ayam santan pun mudah untuk dibuat, lho. Kalian tidak perlu capek-capek untuk membeli soto ayam santan, lantaran Kalian mampu menyajikan ditempatmu. Bagi Anda yang akan menghidangkannya, berikut resep untuk membuat soto ayam santan yang enak yang mampu Anda hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Soto ayam Santan:

1. Siapkan 2 potong ayam
1. Ambil 500 ml air
1. Sediakan 50 gr tauge, siangi
1. Ambil 1/2 buah kol, iris
1. Sediakan 1 batang daun bawang, iris
1. Siapkan 4 lembar daun salam
1. Siapkan 3 lembar daun jeruk
1. Ambil 1 batang serai, geprek
1. Sediakan 500 ml santan
1. Gunakan 1 buah telur rebus, potong 4bagian
1. Sediakan 2 sdm bawang goreng
1. Siapkan 1 buah kentang ukuran besar/sedang, goreng
1. Gunakan  Bumbu halus :
1. Gunakan 5 siung bawang merah
1. Sediakan 4 siung bawang putih
1. Siapkan 2 buah kemiri
1. Ambil 2 cm jahe
1. Ambil 2 cm kunyit
1. Ambil Secukupnya lada dan merica bubuk
1. Ambil Secukupnya gula
1. Sediakan Secukupnya garam
1. Sediakan Secukupnya minyak goreng


Rasanya tidak kalah sedap dan segar, lho! Resep soto ayam santan, variasi soto ayam. Soto ayam cocok disantap untuk sarapan maupun makan siang. Soto ayam santan ala resto. foto: Instagram/@hennysgalley. 

<!--inarticleads2-->

##### Cara menyiapkan Soto ayam Santan:

1. Siapkan panci dan didihkan air bersama ayam atau tulang ayam untuk membuat kuah kaldu. Tunggu ayam hingga empuk dan kaldu mendidih. Sementara menunggu ayam matang, haluskan bumbu halus kemudian tumis hingga harum dan matang.
1. Angkat ayam dari dalam rebusan jika sudah matang, lalu sisihkan. Kemudian, masukkan bumbu yang sudah di tumis kedalam kaldu aduk-aduk hingga tercampur rata. Masukkan juga gula, garam, lada, serai, daun salam, daun jeruk, dan daun bawang.
1. Aduk lagi hingga tercampur rata, dan terakhir masukkan santan dan aduk-aduk agar santan tidak pecah selama di masak. Kemudian cek rasa. Jika di rasa sudah pas, sisihkan dahulu.
1. Goreng ayam(suwir2) dan kentang bergantian hingga benar-benar matang dan kecoklatan. Terakhir, sajikan soto bersama tauge, kol, kentang goreng, lalu tuangkan kuah soto dan tambahkan telur rebus serta bawang goreng.


Soto Ayam Bening, Lamongan, Madura, Santan, Kuning. Resep Soto Ayam - Soto ayam merupakan salah satu dari ratusan ribu kuliner yang ada di Indonesia. Resep soto ayam santan merupakan salah satu dari sekian banyak resep soto yang ada di Nusantara. Soto ayam yang dipadu dengan kuah santan yang segar ini semakin menambah gurih. Seperti soto yang terdapat di Jawa, soto Medan juga menggunakan daging ayam sebagai bahan Bedanya, soto Medan menggunakan santan sehingga tekstur kuahnya lebih kental dan berwarna. 

Wah ternyata cara buat soto ayam santan yang enak tidak rumit ini mudah banget ya! Kalian semua dapat membuatnya. Resep soto ayam santan Cocok banget untuk kamu yang sedang belajar memasak maupun juga bagi anda yang telah lihai memasak.

Tertarik untuk mulai mencoba buat resep soto ayam santan enak simple ini? Kalau anda ingin, mending kamu segera menyiapkan alat dan bahannya, setelah itu buat deh Resep soto ayam santan yang nikmat dan simple ini. Sungguh mudah kan. 

Maka, ketimbang kalian berfikir lama-lama, ayo langsung aja sajikan resep soto ayam santan ini. Pasti kamu tak akan nyesel bikin resep soto ayam santan nikmat tidak ribet ini! Selamat mencoba dengan resep soto ayam santan mantab tidak rumit ini di rumah sendiri,oke!.

