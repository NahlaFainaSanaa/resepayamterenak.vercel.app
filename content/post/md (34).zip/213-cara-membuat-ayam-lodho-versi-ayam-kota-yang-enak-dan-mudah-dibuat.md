---
description: "Cara membuat Ayam Lodho versi ayam kota 😄 yang enak dan Mudah Dibuat"
title: "Cara membuat Ayam Lodho versi ayam kota 😄 yang enak dan Mudah Dibuat"
slug: 213-cara-membuat-ayam-lodho-versi-ayam-kota-yang-enak-dan-mudah-dibuat
date: 2021-06-15T21:51:47.211Z
image: https://img-global.cpcdn.com/recipes/b6fb7f5e6e7dbaee/680x482cq70/ayam-lodho-versi-ayam-kota-😄-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b6fb7f5e6e7dbaee/680x482cq70/ayam-lodho-versi-ayam-kota-😄-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b6fb7f5e6e7dbaee/680x482cq70/ayam-lodho-versi-ayam-kota-😄-foto-resep-utama.jpg
author: Mayme Guzman
ratingvalue: 3.5
reviewcount: 5
recipeingredient:
- "1 kg ayam potong1 ekor ayam kampung"
- "4 siung bawang putih"
- "5 siung bawang merah"
- "10 cabe rawit"
- "5 butir kemiri"
- "1 sdt merica"
- "1 sdt ketumbar"
- "1 iris jahe"
- "1 iris kunyit"
- "3 lembar daun salam"
- "3 lembar daun jeruk"
- " Santan"
- "secukupnya Air"
recipeinstructions:
- "Bersihkan ayam cuci bersih potong2 sesuai selera, idealnya pake ayam kampung tp kalau gak ada pake ayam potong biasa gpp yg terpenting adalah bumbunya"
- "Bakar ayam sampe matang dan sedikit.gosong"
- "Goreng semua bumbu sampe layu dan Uleg semua bumbu yg sudah disediakan, dan sisihkan 5 cabe rawit wutuh"
- "Oseng2 bumbu dan tambahkan gula garam"
- "Masukkan ayam yg sudah dibakar dan kasih air sedikit aduk dan tutup agar bumbu meresap, dan masukkan 5 cabe rawit wutuh, lengkuas, daun salam"
- "Tuang santan dan sedikit royco ayam, aduk sampai rata serta koreksi rasa. Gunakan api sedang agar santan tidak pecah agar enak"
- "Sajikan dengan nasi hangat serta urap2. Selamat mencoba 😊"
categories:
- Resep
tags:
- ayam
- lodho
- versi

katakunci: ayam lodho versi 
nutrition: 216 calories
recipecuisine: Indonesian
preptime: "PT25M"
cooktime: "PT40M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam Lodho versi ayam kota 😄](https://img-global.cpcdn.com/recipes/b6fb7f5e6e7dbaee/680x482cq70/ayam-lodho-versi-ayam-kota-😄-foto-resep-utama.jpg)

Selaku seorang ibu, mempersiapkan olahan sedap untuk keluarga adalah suatu hal yang sangat menyenangkan bagi kita sendiri. Kewajiban seorang ibu bukan saja menangani rumah saja, tetapi kamu pun harus menyediakan keperluan gizi terpenuhi dan panganan yang dimakan anak-anak mesti enak.

Di era  saat ini, kita memang mampu membeli masakan jadi walaupun tanpa harus capek membuatnya dahulu. Tetapi ada juga lho mereka yang memang mau menyajikan yang terbaik untuk orang yang dicintainya. Pasalnya, memasak yang diolah sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan makanan tersebut sesuai kesukaan keluarga. 



Mungkinkah anda adalah seorang penggemar ayam lodho versi ayam kota 😄?. Tahukah kamu, ayam lodho versi ayam kota 😄 adalah sajian khas di Nusantara yang saat ini disukai oleh kebanyakan orang di hampir setiap tempat di Indonesia. Kalian bisa menghidangkan ayam lodho versi ayam kota 😄 kreasi sendiri di rumah dan dapat dijadikan camilan kesukaanmu di akhir pekan.

Kamu jangan bingung untuk memakan ayam lodho versi ayam kota 😄, lantaran ayam lodho versi ayam kota 😄 mudah untuk ditemukan dan juga kita pun boleh memasaknya sendiri di tempatmu. ayam lodho versi ayam kota 😄 dapat diolah dengan beraneka cara. Sekarang ada banyak resep modern yang membuat ayam lodho versi ayam kota 😄 lebih mantap.

Resep ayam lodho versi ayam kota 😄 pun mudah untuk dibuat, lho. Kita tidak perlu ribet-ribet untuk membeli ayam lodho versi ayam kota 😄, sebab Kita dapat menyajikan sendiri di rumah. Bagi Anda yang mau mencobanya, dibawah ini merupakan cara membuat ayam lodho versi ayam kota 😄 yang mantab yang bisa Anda hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Ayam Lodho versi ayam kota 😄:

1. Gunakan 1 kg ayam potong/1 ekor ayam kampung
1. Sediakan 4 siung bawang putih
1. Ambil 5 siung bawang merah
1. Ambil 10 cabe rawit
1. Ambil 5 butir kemiri
1. Sediakan 1 sdt merica
1. Gunakan 1 sdt ketumbar
1. Ambil 1 iris jahe
1. Ambil 1 iris kunyit
1. Siapkan 3 lembar daun salam
1. Siapkan 3 lembar daun jeruk
1. Siapkan  Santan
1. Gunakan secukupnya Air




<!--inarticleads2-->

##### Cara menyiapkan Ayam Lodho versi ayam kota 😄:

1. Bersihkan ayam cuci bersih potong2 sesuai selera, idealnya pake ayam kampung tp kalau gak ada pake ayam potong biasa gpp yg terpenting adalah bumbunya
1. Bakar ayam sampe matang dan sedikit.gosong
1. Goreng semua bumbu sampe layu dan Uleg semua bumbu yg sudah disediakan, dan sisihkan 5 cabe rawit wutuh
1. Oseng2 bumbu dan tambahkan gula garam
1. Masukkan ayam yg sudah dibakar dan kasih air sedikit aduk dan tutup agar bumbu meresap, dan masukkan 5 cabe rawit wutuh, lengkuas, daun salam
1. Tuang santan dan sedikit royco ayam, aduk sampai rata serta koreksi rasa. Gunakan api sedang agar santan tidak pecah agar enak
1. Sajikan dengan nasi hangat serta urap2. Selamat mencoba 😊




Ternyata cara buat ayam lodho versi ayam kota 😄 yang mantab tidak rumit ini enteng sekali ya! Kita semua bisa menghidangkannya. Resep ayam lodho versi ayam kota 😄 Cocok sekali buat kamu yang baru mau belajar memasak atau juga untuk anda yang telah ahli memasak.

Apakah kamu mau mencoba buat resep ayam lodho versi ayam kota 😄 lezat simple ini? Kalau ingin, ayo kamu segera buruan siapin alat dan bahan-bahannya, setelah itu buat deh Resep ayam lodho versi ayam kota 😄 yang mantab dan sederhana ini. Sungguh mudah kan. 

Maka, ketimbang kalian berlama-lama, ayo kita langsung hidangkan resep ayam lodho versi ayam kota 😄 ini. Dijamin anda tiidak akan nyesel bikin resep ayam lodho versi ayam kota 😄 mantab tidak rumit ini! Selamat berkreasi dengan resep ayam lodho versi ayam kota 😄 lezat tidak ribet ini di tempat tinggal kalian masing-masing,ya!.

