---
description: "Cara buat Soto Ayam Santan Sederhana dan Mudah Dibuat"
title: "Cara buat Soto Ayam Santan Sederhana dan Mudah Dibuat"
slug: 392-cara-buat-soto-ayam-santan-sederhana-dan-mudah-dibuat
date: 2021-04-24T07:38:33.625Z
image: https://img-global.cpcdn.com/recipes/75f5d38e3c277d60/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/75f5d38e3c277d60/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/75f5d38e3c277d60/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
author: Tony Tate
ratingvalue: 4.8
reviewcount: 12
recipeingredient:
- "1/2 ekor ayam bagian dada cuci bersih sy pakai bagian paha"
- "250 ml santan dr 12 buah kelapa"
- "1 liter air"
- "4 lembar daun jeruk sobek2"
- "2 lembar daun salam"
- "2 batang sereh geprek"
- "1 ruas jari lengkuas geprek"
- "Secukupnya gulagaram"
- "Secukupnya kaldu ayam bubuk"
- " Bumbu halus "
- "6 siung bawang merah"
- "3 Siung bawang putih"
- "3 butir kemiri"
- "1/2 sdt ketumbar"
- "Secukupnya lada"
- " Pelengkap "
- " Sambal"
- " Daun bawang"
- " Jeruk nipis"
- " Bawang goreng"
- " Kentang goreng"
- " Tomat"
recipeinstructions:
- "Didihkan 1 liter air di panci lalu masukan ayam,rebus ayam dgn api kecil"
- "Tumis bumbu halus,daun jeruk,daun salam,lengkuas,sereh sampai harum,masukan tumisan bumbu ke dlm rebusan ayam,masukan royco,garam dan gula,masak hingga ayam empuk dan bumbu meresap. Masukan santan aduk2 agar tdk pecah,klu kira2 krg kental kuahnya bs di tambah santan instan,aduk hingga mendidih"
- "Setelah mendidih lalu angkat ayam dan tiriskan"
- "Tes rasa lalu matikan"
- "Pansakan minyak goreng lalu goreng ayam,tdk ush terlalu kering,lalu siapkan mangkuk saji,suir2 ayam"
- "Siapkan mangkuk dan tata di magkuk saji dgn pelengkapnya .. Yuumyyy"
categories:
- Resep
tags:
- soto
- ayam
- santan

katakunci: soto ayam santan 
nutrition: 108 calories
recipecuisine: Indonesian
preptime: "PT30M"
cooktime: "PT33M"
recipeyield: "2"
recipecategory: Dinner

---


![Soto Ayam Santan](https://img-global.cpcdn.com/recipes/75f5d38e3c277d60/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg)

Andai anda seorang istri, menyajikan panganan lezat buat famili merupakan hal yang memuaskan bagi anda sendiri. Kewajiban seorang istri bukan sekadar menjaga rumah saja, tapi kamu pun harus memastikan kebutuhan nutrisi tercukupi dan panganan yang dikonsumsi keluarga tercinta harus enak.

Di masa  sekarang, anda sebenarnya bisa memesan olahan praktis tanpa harus ribet mengolahnya terlebih dahulu. Tetapi ada juga lho orang yang memang mau memberikan makanan yang terbaik untuk keluarganya. Pasalnya, menghidangkan masakan sendiri jauh lebih bersih dan kita juga bisa menyesuaikan sesuai dengan makanan kesukaan keluarga. 



Mungkinkah anda adalah salah satu penyuka soto ayam santan?. Tahukah kamu, soto ayam santan merupakan sajian khas di Indonesia yang sekarang disenangi oleh setiap orang dari hampir setiap wilayah di Nusantara. Kita bisa menyajikan soto ayam santan buatan sendiri di rumah dan boleh dijadikan makanan kesukaanmu di hari libur.

Kita tidak perlu bingung untuk mendapatkan soto ayam santan, karena soto ayam santan gampang untuk dicari dan kalian pun dapat memasaknya sendiri di tempatmu. soto ayam santan dapat diolah dengan berbagai cara. Sekarang telah banyak banget resep modern yang membuat soto ayam santan lebih enak.

Resep soto ayam santan juga mudah sekali dibuat, lho. Anda tidak perlu ribet-ribet untuk membeli soto ayam santan, sebab Kamu mampu membuatnya di rumah sendiri. Untuk Anda yang akan menyajikannya, di bawah ini adalah resep menyajikan soto ayam santan yang nikamat yang bisa Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Soto Ayam Santan:

1. Siapkan 1/2 ekor ayam bagian dada cuci bersih, sy pakai bagian paha
1. Gunakan 250 ml santan dr 1/2 buah kelapa
1. Sediakan 1 liter air
1. Sediakan 4 lembar daun jeruk sobek2
1. Siapkan 2 lembar daun salam
1. Ambil 2 batang sereh geprek
1. Gunakan 1 ruas jari lengkuas geprek
1. Gunakan Secukupnya gula,garam
1. Gunakan Secukupnya kaldu ayam bubuk
1. Ambil  Bumbu halus :
1. Sediakan 6 siung bawang merah
1. Gunakan 3 Siung bawang putih
1. Gunakan 3 butir kemiri
1. Gunakan 1/2 sdt ketumbar
1. Ambil Secukupnya lada
1. Gunakan  Pelengkap :
1. Ambil  Sambal
1. Sediakan  Daun bawang
1. Gunakan  Jeruk nipis
1. Gunakan  Bawang goreng
1. Siapkan  Kentang goreng
1. Sediakan  Tomat




<!--inarticleads2-->

##### Langkah-langkah membuat Soto Ayam Santan:

1. Didihkan 1 liter air di panci lalu masukan ayam,rebus ayam dgn api kecil
1. Tumis bumbu halus,daun jeruk,daun salam,lengkuas,sereh sampai harum,masukan tumisan bumbu ke dlm rebusan ayam,masukan royco,garam dan gula,masak hingga ayam empuk dan bumbu meresap. Masukan santan aduk2 agar tdk pecah,klu kira2 krg kental kuahnya bs di tambah santan instan,aduk hingga mendidih
1. Setelah mendidih lalu angkat ayam dan tiriskan
1. Tes rasa lalu matikan
1. Pansakan minyak goreng lalu goreng ayam,tdk ush terlalu kering,lalu siapkan mangkuk saji,suir2 ayam
1. Siapkan mangkuk dan tata di magkuk saji dgn pelengkapnya .. Yuumyyy




Wah ternyata resep soto ayam santan yang mantab simple ini enteng sekali ya! Kita semua dapat mencobanya. Cara Membuat soto ayam santan Sesuai banget untuk kalian yang baru akan belajar memasak maupun untuk kalian yang sudah jago memasak.

Tertarik untuk mencoba membuat resep soto ayam santan lezat sederhana ini? Kalau anda tertarik, mending kamu segera siapin alat-alat dan bahannya, kemudian buat deh Resep soto ayam santan yang nikmat dan tidak rumit ini. Sungguh gampang kan. 

Maka, daripada kalian berlama-lama, hayo langsung aja sajikan resep soto ayam santan ini. Dijamin kamu gak akan nyesel bikin resep soto ayam santan mantab tidak rumit ini! Selamat berkreasi dengan resep soto ayam santan mantab simple ini di rumah kalian masing-masing,ya!.

