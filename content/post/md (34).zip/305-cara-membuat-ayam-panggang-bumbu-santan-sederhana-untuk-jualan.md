---
description: "Cara membuat Ayam Panggang Bumbu Santan Sederhana Untuk Jualan"
title: "Cara membuat Ayam Panggang Bumbu Santan Sederhana Untuk Jualan"
slug: 305-cara-membuat-ayam-panggang-bumbu-santan-sederhana-untuk-jualan
date: 2021-06-07T09:28:52.455Z
image: https://img-global.cpcdn.com/recipes/21bee21c6c267815/680x482cq70/ayam-panggang-bumbu-santan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/21bee21c6c267815/680x482cq70/ayam-panggang-bumbu-santan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/21bee21c6c267815/680x482cq70/ayam-panggang-bumbu-santan-foto-resep-utama.jpg
author: Cameron Blair
ratingvalue: 3.8
reviewcount: 5
recipeingredient:
- "500 gr ayam bagian paha cuci bersih lalu marinasi dengan secukupnya garam dan air jeruk nipis selama 15 menit lalu bilas kembali"
- "130 ml santan instan me 2 pack santan instan isi 65mlpack"
- "2 lembar daun jeruk"
- "1 batang serai digeprek"
- "350 ml air"
- "1/2 sdm garam"
- "1/4 sdt gula pasir"
- " Bumbu Halus"
- "4 siung bawang merah"
- "3 siung bawang putih"
- "5 cm kunyit"
- "1 ruas lengkuas"
- "1 sdt ketumbar"
recipeinstructions:
- "Siapkan bahan yang digunakan"
- "Siapkan wajan, masukkan air, santan, bumbu halus, daun jeruk, serai, gula pasir dan garam. Aduk rata"
- "Kemudian masukkan ayam, lalu masak ayam hingga matang dan bumbunya meresap serta kuahnya menyusut dan terlihat sedikit mengental, sesekali diaduk-aduk dalam proses memasaknya."
- "Setelah ayam matang, pisahkan potongan ayam dari bumbunya. Sisihkan sisa bumbu santan (note: sisa bumbu santan jangan dibuang, karena nanti akan disajikan bersama ayam panggang)"
- "Oles tipis teflon dengan minyak goreng, lalu pangang ayam hingga kulit luarnya kering dan berwarna agak kecoklatan"
- "Tata ayam panggang di piring saji, lalu balurkan secukupnya sisa bumbu santan diatas ayam panggang. Sajikan Ayam Panggang Bumbu Santan bersama lalapan dan sambal sesuai selera 😊"
categories:
- Resep
tags:
- ayam
- panggang
- bumbu

katakunci: ayam panggang bumbu 
nutrition: 222 calories
recipecuisine: Indonesian
preptime: "PT28M"
cooktime: "PT30M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam Panggang Bumbu Santan](https://img-global.cpcdn.com/recipes/21bee21c6c267815/680x482cq70/ayam-panggang-bumbu-santan-foto-resep-utama.jpg)

Selaku seorang wanita, menyajikan santapan menggugah selera pada keluarga adalah suatu hal yang sangat menyenangkan untuk kita sendiri. Peran seorang istri bukan cuman menjaga rumah saja, namun kamu pun wajib memastikan kebutuhan gizi tercukupi dan juga hidangan yang dikonsumsi orang tercinta mesti lezat.

Di masa  saat ini, kalian memang bisa membeli olahan yang sudah jadi walaupun tidak harus ribet membuatnya lebih dulu. Tetapi ada juga lho mereka yang selalu ingin memberikan yang terenak untuk keluarganya. Lantaran, memasak sendiri akan jauh lebih bersih dan bisa menyesuaikan makanan tersebut sesuai masakan kesukaan keluarga tercinta. 



Apakah kamu salah satu penggemar ayam panggang bumbu santan?. Asal kamu tahu, ayam panggang bumbu santan merupakan makanan khas di Nusantara yang kini digemari oleh setiap orang di hampir setiap daerah di Indonesia. Kalian dapat menyajikan ayam panggang bumbu santan sendiri di rumah dan boleh jadi hidangan kegemaranmu di hari libur.

Kamu tidak perlu bingung jika kamu ingin memakan ayam panggang bumbu santan, lantaran ayam panggang bumbu santan mudah untuk ditemukan dan juga kalian pun bisa membuatnya sendiri di tempatmu. ayam panggang bumbu santan boleh dimasak memalui berbagai cara. Kini telah banyak cara kekinian yang menjadikan ayam panggang bumbu santan semakin enak.

Resep ayam panggang bumbu santan pun mudah sekali dihidangkan, lho. Kita tidak perlu repot-repot untuk membeli ayam panggang bumbu santan, lantaran Kita bisa menghidangkan di rumahmu. Bagi Kamu yang akan membuatnya, inilah resep membuat ayam panggang bumbu santan yang mantab yang dapat Kamu hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Ayam Panggang Bumbu Santan:

1. Siapkan 500 gr ayam bagian paha, cuci bersih, lalu marinasi dengan secukupnya garam dan air jeruk nipis selama 15 menit, lalu bilas kembali
1. Sediakan 130 ml santan instan (me. 2 pack santan instan isi @65ml/pack)
1. Sediakan 2 lembar daun jeruk
1. Gunakan 1 batang serai, digeprek
1. Ambil 350 ml air
1. Ambil 1/2 sdm garam
1. Gunakan 1/4 sdt gula pasir
1. Ambil  Bumbu Halus:
1. Siapkan 4 siung bawang merah
1. Gunakan 3 siung bawang putih
1. Ambil 5 cm kunyit
1. Ambil 1 ruas lengkuas
1. Siapkan 1 sdt ketumbar




<!--inarticleads2-->

##### Cara menyiapkan Ayam Panggang Bumbu Santan:

1. Siapkan bahan yang digunakan
1. Siapkan wajan, masukkan air, santan, bumbu halus, daun jeruk, serai, gula pasir dan garam. Aduk rata
1. Kemudian masukkan ayam, lalu masak ayam hingga matang dan bumbunya meresap serta kuahnya menyusut dan terlihat sedikit mengental, sesekali diaduk-aduk dalam proses memasaknya.
1. Setelah ayam matang, pisahkan potongan ayam dari bumbunya. Sisihkan sisa bumbu santan (note: sisa bumbu santan jangan dibuang, karena nanti akan disajikan bersama ayam panggang)
1. Oles tipis teflon dengan minyak goreng, lalu pangang ayam hingga kulit luarnya kering dan berwarna agak kecoklatan
1. Tata ayam panggang di piring saji, lalu balurkan secukupnya sisa bumbu santan diatas ayam panggang. Sajikan Ayam Panggang Bumbu Santan bersama lalapan dan sambal sesuai selera 😊




Wah ternyata resep ayam panggang bumbu santan yang lezat sederhana ini enteng banget ya! Kalian semua dapat mencobanya. Resep ayam panggang bumbu santan Sesuai sekali buat anda yang baru belajar memasak atau juga untuk kalian yang telah pandai dalam memasak.

Tertarik untuk mencoba bikin resep ayam panggang bumbu santan lezat tidak ribet ini? Kalau tertarik, mending kamu segera siapin peralatan dan bahan-bahannya, setelah itu bikin deh Resep ayam panggang bumbu santan yang mantab dan sederhana ini. Sangat taidak sulit kan. 

Oleh karena itu, daripada kalian berlama-lama, yuk kita langsung bikin resep ayam panggang bumbu santan ini. Dijamin anda tak akan menyesal sudah membuat resep ayam panggang bumbu santan lezat tidak rumit ini! Selamat berkreasi dengan resep ayam panggang bumbu santan lezat simple ini di tempat tinggal kalian masing-masing,ya!.

