---
description: "Cara membuat Ayam Bakar Bumbu Ungkep yang nikmat dan Mudah Dibuat"
title: "Cara membuat Ayam Bakar Bumbu Ungkep yang nikmat dan Mudah Dibuat"
slug: 453-cara-membuat-ayam-bakar-bumbu-ungkep-yang-nikmat-dan-mudah-dibuat
date: 2021-01-30T18:28:58.553Z
image: https://img-global.cpcdn.com/recipes/8001f3bd90014e2f/680x482cq70/ayam-bakar-bumbu-ungkep-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8001f3bd90014e2f/680x482cq70/ayam-bakar-bumbu-ungkep-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8001f3bd90014e2f/680x482cq70/ayam-bakar-bumbu-ungkep-foto-resep-utama.jpg
author: Steven Ferguson
ratingvalue: 4.1
reviewcount: 13
recipeingredient:
- "1 ekor ayam kampung potong2"
- " Bumbu halus"
- "4 siung bawang putih"
- "6 siung bawang merah"
- "3 cm kunyit"
- " Minyak untuk menumis"
- " Bumbu cemplung"
- "4 lbr daun salam"
- "2 btg serai geprek"
- "5 cm lengkuas"
- "5 sdm gula aren gula Jawagula merah"
- "2 sdm air asam jawa"
- "secukupnya Air air kelapa"
- "secukupnya Kecap"
- "1 sdm garam"
- "1 sdm kaldu ayam"
recipeinstructions:
- "Siapkan bumbu halus. Saya menggunakan blender dengan minyak. Cuci bersih ayam, potong2. Siapkan bumbu cemplung."
- "Haluskan bumbu, kemudian tumis (saya tidak lagi menggunakan minyak ya..) tambahkan lengkuas, daun salam, serai. Tumis hingga berubah warna, harum dan masak. Cirinya mengeluarkan minyak. Gunakan api kecil, agar tidak gosong"
- "Masukan ayam, aduk2 hingga bumbu tercampur rata. Tambahkan air (atau air kelapa) tambahkan gula aren, garam, kaldu, kecap. Masak hingga air menyusut. Koreksi rasa. Sisakan air sedikit ya"
- "Bakar dengan sisaan air baceman, bolak balik sampai berwarna kecoklatan. Kemudian sajikan dengan nasi hangat, lalaban, dan sambal"
categories:
- Resep
tags:
- ayam
- bakar
- bumbu

katakunci: ayam bakar bumbu 
nutrition: 286 calories
recipecuisine: Indonesian
preptime: "PT26M"
cooktime: "PT55M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Bakar Bumbu Ungkep](https://img-global.cpcdn.com/recipes/8001f3bd90014e2f/680x482cq70/ayam-bakar-bumbu-ungkep-foto-resep-utama.jpg)

Jika kita seorang wanita, menyajikan hidangan lezat bagi famili adalah hal yang memuaskan bagi anda sendiri. Tugas seorang ibu Tidak sekadar mengurus rumah saja, tapi anda pun wajib menyediakan kebutuhan nutrisi tercukupi dan juga panganan yang dikonsumsi keluarga tercinta harus enak.

Di zaman  sekarang, kita sebenarnya dapat memesan panganan instan meski tanpa harus capek membuatnya dahulu. Namun ada juga mereka yang selalu mau menghidangkan yang terlezat bagi orang tercintanya. Karena, menyajikan masakan yang dibuat sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan sesuai kesukaan keluarga. 



Mungkinkah anda merupakan seorang penikmat ayam bakar bumbu ungkep?. Tahukah kamu, ayam bakar bumbu ungkep adalah sajian khas di Nusantara yang sekarang disukai oleh orang-orang di hampir setiap tempat di Indonesia. Kamu dapat menyajikan ayam bakar bumbu ungkep sendiri di rumah dan boleh jadi santapan kesenanganmu di hari libur.

Kita tidak usah bingung jika kamu ingin menyantap ayam bakar bumbu ungkep, lantaran ayam bakar bumbu ungkep tidak sukar untuk dicari dan juga kamu pun dapat memasaknya sendiri di tempatmu. ayam bakar bumbu ungkep bisa dibuat lewat beraneka cara. Saat ini sudah banyak cara modern yang membuat ayam bakar bumbu ungkep semakin lezat.

Resep ayam bakar bumbu ungkep pun mudah untuk dibikin, lho. Kita tidak perlu capek-capek untuk memesan ayam bakar bumbu ungkep, lantaran Kalian dapat membuatnya di rumahmu. Bagi Kita yang hendak menghidangkannya, inilah cara untuk membuat ayam bakar bumbu ungkep yang nikamat yang dapat Anda coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Ayam Bakar Bumbu Ungkep:

1. Ambil 1 ekor ayam kampung, potong2
1. Siapkan  Bumbu halus:
1. Siapkan 4 siung bawang putih
1. Ambil 6 siung bawang merah
1. Sediakan 3 cm kunyit
1. Ambil  Minyak untuk menumis
1. Ambil  Bumbu cemplung:
1. Gunakan 4 lbr daun salam
1. Sediakan 2 btg serai, geprek
1. Sediakan 5 cm lengkuas
1. Sediakan 5 sdm gula aren (gula Jawa/gula merah)
1. Gunakan 2 sdm air asam jawa
1. Gunakan secukupnya Air (air kelapa)
1. Gunakan secukupnya Kecap
1. Sediakan 1 sdm garam
1. Siapkan 1 sdm kaldu ayam




<!--inarticleads2-->

##### Cara membuat Ayam Bakar Bumbu Ungkep:

1. Siapkan bumbu halus. Saya menggunakan blender dengan minyak. Cuci bersih ayam, potong2. Siapkan bumbu cemplung.
1. Haluskan bumbu, kemudian tumis (saya tidak lagi menggunakan minyak ya..) tambahkan lengkuas, daun salam, serai. Tumis hingga berubah warna, harum dan masak. Cirinya mengeluarkan minyak. Gunakan api kecil, agar tidak gosong
1. Masukan ayam, aduk2 hingga bumbu tercampur rata. Tambahkan air (atau air kelapa) tambahkan gula aren, garam, kaldu, kecap. Masak hingga air menyusut. Koreksi rasa. Sisakan air sedikit ya
1. Bakar dengan sisaan air baceman, bolak balik sampai berwarna kecoklatan. Kemudian sajikan dengan nasi hangat, lalaban, dan sambal




Wah ternyata cara membuat ayam bakar bumbu ungkep yang nikamt tidak rumit ini enteng banget ya! Kalian semua bisa memasaknya. Cara buat ayam bakar bumbu ungkep Sesuai sekali untuk kita yang sedang belajar memasak maupun juga untuk anda yang sudah ahli memasak.

Apakah kamu ingin mencoba membuat resep ayam bakar bumbu ungkep mantab tidak ribet ini? Kalau ingin, yuk kita segera buruan menyiapkan peralatan dan bahannya, maka bikin deh Resep ayam bakar bumbu ungkep yang nikmat dan simple ini. Benar-benar taidak sulit kan. 

Jadi, ketimbang kalian berfikir lama-lama, maka langsung aja hidangkan resep ayam bakar bumbu ungkep ini. Pasti kamu gak akan menyesal sudah membuat resep ayam bakar bumbu ungkep mantab tidak rumit ini! Selamat mencoba dengan resep ayam bakar bumbu ungkep mantab tidak rumit ini di tempat tinggal kalian masing-masing,oke!.

