---
description: "Cara membuat Opor ayam kampung (kuning) yang enak dan Mudah Dibuat"
title: "Cara membuat Opor ayam kampung (kuning) yang enak dan Mudah Dibuat"
slug: 358-cara-membuat-opor-ayam-kampung-kuning-yang-enak-dan-mudah-dibuat
date: 2021-07-04T21:18:25.705Z
image: https://img-global.cpcdn.com/recipes/fccd17d918e9ec70/680x482cq70/opor-ayam-kampung-kuning-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/fccd17d918e9ec70/680x482cq70/opor-ayam-kampung-kuning-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/fccd17d918e9ec70/680x482cq70/opor-ayam-kampung-kuning-foto-resep-utama.jpg
author: Frances Cummings
ratingvalue: 4.7
reviewcount: 6
recipeingredient:
- "1 ekor ayam kampung muda"
- "1 buah jeruk lemonnipis"
- " Bumbu halus"
- "8 siung bawang merah"
- "4 siung bawang putih"
- "3 butir kemiri"
- "1 ruas kecil kunyit"
- "1 ruas jahe"
- "1 ruas lengkuas"
- "1 sdt jintan"
- "1 sdt lada"
- "1 sdt ketumbar"
- "4 lembar daun salam"
- "4 lembar daun jeruk"
- "2 batang serai"
- "1 sdt asam kandis"
- "1 sdt garam"
- "1 sdt gula"
- "1 sdt kaldu bubuk penyedap"
- "1 butir kelapa 1 gelas santan kental4 gelas santan cair"
- " Minyak untuk menumis"
recipeinstructions:
- "Cuci bersih ayam lalu lumuri dengan jeruk lemon tunggu selama 30 menit lalu bilas kembali"
- "Haluskan bumbu,lalu panaskan minyak dalam wajan masukkan bumbu beserta daun salam,daun jeruk dan serai hingga bumbu harum dan matang"
- "Setelah itu masukkan potongan ayam kedalam bumbu aduk rata masak hingga ayam berubah warna putih pucat lalu masukkan santan cair,aduk sesekali agar santan tidak pecah masak dengan api kecil.setelah kuah menyusut ayam mulai empuk masukkan santan kental,garam,gula,kaldu bubuk tes rasa masak kembali hingga ayam matang dan kuah mengental."
- "Setelah ayam matang pindahkan kedalam mangkuk saji lalu taburi dengan bawang goreng.opor ayam siap disajikan dengan pelengkap ketupat dan sambal goreng kentang."
categories:
- Resep
tags:
- opor
- ayam
- kampung

katakunci: opor ayam kampung 
nutrition: 278 calories
recipecuisine: Indonesian
preptime: "PT40M"
cooktime: "PT37M"
recipeyield: "4"
recipecategory: Dinner

---


![Opor ayam kampung (kuning)](https://img-global.cpcdn.com/recipes/fccd17d918e9ec70/680x482cq70/opor-ayam-kampung-kuning-foto-resep-utama.jpg)

Jika kalian seorang istri, menyajikan olahan nikmat untuk famili merupakan hal yang membahagiakan untuk kita sendiri. Kewajiban seorang istri bukan sekadar mengurus rumah saja, namun anda pun harus menyediakan kebutuhan gizi tercukupi dan juga santapan yang dikonsumsi anak-anak wajib lezat.

Di masa  saat ini, kamu memang dapat mengorder santapan yang sudah jadi meski tidak harus ribet memasaknya lebih dulu. Tapi banyak juga lho orang yang selalu ingin menghidangkan yang terbaik bagi orang yang dicintainya. Lantaran, memasak yang dibuat sendiri akan jauh lebih higienis dan bisa menyesuaikan makanan tersebut berdasarkan selera orang tercinta. 



Mungkinkah anda merupakan seorang penggemar opor ayam kampung (kuning)?. Asal kamu tahu, opor ayam kampung (kuning) merupakan hidangan khas di Nusantara yang kini digemari oleh setiap orang di berbagai tempat di Nusantara. Kamu bisa memasak opor ayam kampung (kuning) buatan sendiri di rumahmu dan boleh jadi hidangan kegemaranmu di akhir pekan.

Anda tidak perlu bingung untuk mendapatkan opor ayam kampung (kuning), karena opor ayam kampung (kuning) mudah untuk didapatkan dan kalian pun boleh membuatnya sendiri di tempatmu. opor ayam kampung (kuning) boleh dimasak lewat berbagai cara. Kini telah banyak resep modern yang menjadikan opor ayam kampung (kuning) lebih mantap.

Resep opor ayam kampung (kuning) juga gampang dihidangkan, lho. Kita tidak perlu repot-repot untuk membeli opor ayam kampung (kuning), lantaran Anda mampu membuatnya di rumah sendiri. Bagi Kalian yang ingin menyajikannya, di bawah ini adalah resep menyajikan opor ayam kampung (kuning) yang lezat yang bisa Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Opor ayam kampung (kuning):

1. Gunakan 1 ekor ayam kampung muda
1. Ambil 1 buah jeruk lemon/nipis
1. Sediakan  Bumbu halus:
1. Gunakan 8 siung bawang merah
1. Siapkan 4 siung bawang putih
1. Siapkan 3 butir kemiri
1. Siapkan 1 ruas kecil kunyit
1. Siapkan 1 ruas jahe
1. Gunakan 1 ruas lengkuas
1. Gunakan 1 sdt jintan
1. Gunakan 1 sdt lada
1. Gunakan 1 sdt ketumbar
1. Gunakan 4 lembar daun salam
1. Siapkan 4 lembar daun jeruk
1. Sediakan 2 batang serai
1. Gunakan 1 sdt asam kandis
1. Siapkan 1 sdt garam
1. Gunakan 1 sdt gula
1. Gunakan 1 sdt kaldu bubuk/ penyedap
1. Sediakan 1 butir kelapa (1 gelas santan kental+4 gelas santan cair)
1. Gunakan  Minyak untuk menumis




<!--inarticleads2-->

##### Cara membuat Opor ayam kampung (kuning):

1. Cuci bersih ayam lalu lumuri dengan jeruk lemon tunggu selama 30 menit lalu bilas kembali
1. Haluskan bumbu,lalu panaskan minyak dalam wajan masukkan bumbu beserta daun salam,daun jeruk dan serai hingga bumbu harum dan matang
1. Setelah itu masukkan potongan ayam kedalam bumbu aduk rata masak hingga ayam berubah warna putih pucat lalu masukkan santan cair,aduk sesekali agar santan tidak pecah masak dengan api kecil.setelah kuah menyusut ayam mulai empuk masukkan santan kental,garam,gula,kaldu bubuk tes rasa masak kembali hingga ayam matang dan kuah mengental.
1. Setelah ayam matang pindahkan kedalam mangkuk saji lalu taburi dengan bawang goreng.opor ayam siap disajikan dengan pelengkap ketupat dan sambal goreng kentang.




Wah ternyata resep opor ayam kampung (kuning) yang enak sederhana ini gampang banget ya! Kita semua bisa menghidangkannya. Cara Membuat opor ayam kampung (kuning) Cocok banget buat kalian yang baru belajar memasak ataupun bagi kalian yang telah ahli memasak.

Apakah kamu tertarik mulai mencoba membuat resep opor ayam kampung (kuning) mantab simple ini? Kalau kalian mau, ayo kamu segera menyiapkan alat-alat dan bahan-bahannya, lantas buat deh Resep opor ayam kampung (kuning) yang mantab dan sederhana ini. Sangat mudah kan. 

Maka, ketimbang anda berfikir lama-lama, hayo kita langsung sajikan resep opor ayam kampung (kuning) ini. Pasti kamu gak akan menyesal membuat resep opor ayam kampung (kuning) nikmat simple ini! Selamat berkreasi dengan resep opor ayam kampung (kuning) nikmat simple ini di tempat tinggal kalian masing-masing,ya!.

