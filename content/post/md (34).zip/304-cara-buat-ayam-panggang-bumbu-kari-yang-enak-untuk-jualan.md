---
description: "Cara buat Ayam Panggang Bumbu Kari yang enak Untuk Jualan"
title: "Cara buat Ayam Panggang Bumbu Kari yang enak Untuk Jualan"
slug: 304-cara-buat-ayam-panggang-bumbu-kari-yang-enak-untuk-jualan
date: 2021-04-13T16:06:42.469Z
image: https://img-global.cpcdn.com/recipes/55733f385b15bfce/680x482cq70/ayam-panggang-bumbu-kari-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/55733f385b15bfce/680x482cq70/ayam-panggang-bumbu-kari-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/55733f385b15bfce/680x482cq70/ayam-panggang-bumbu-kari-foto-resep-utama.jpg
author: Maria Herrera
ratingvalue: 3.4
reviewcount: 10
recipeingredient:
- "1/2 kg ayam bag paha"
- "1 buah jeruk nipis"
- "350 ml air"
- "1 sdt bumbu kari instan"
- "1 sdm santan instan"
- "1/4 sdt mujung asam jawa"
- "2 siung bawang putih geprek iris"
- "4 siung bawang merah"
- "2 ruas kunyit"
- "1 ruas jahe dan lengkuas"
- "2 lembar daun salam"
- "2 lembar daun jeruk"
- "1 sdt kaldu jamur"
- "1/2 sdt garam"
- "1 sdt gula pasir"
- "1/8 sdt lada bubuk"
recipeinstructions:
- "Cuci ayam sampai bersih, lumuri jeruk nipis diamkan 15 menit, kemudian bilas dan tiriskan"
- "Siapakan bahan bumbu ungkep, iris semua bahan bumbu ungkep ya"
- "Didihkan air, masukan Bahan bumbu ungkep, masak 5 menit, masukan ayam, masukan bumbu kari instan, asam jawa dan semua bumbu penyedap juga santan, aduk rata"
- "Ungkep ayam sampai kandungan air kering, Matikan kompor, aduk ayam ungkep, diamkan 15 menit."
- "Panggang ayam di grill pan, sampai matang kecoklatan, sajikan ❤️"
categories:
- Resep
tags:
- ayam
- panggang
- bumbu

katakunci: ayam panggang bumbu 
nutrition: 249 calories
recipecuisine: Indonesian
preptime: "PT33M"
cooktime: "PT54M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam Panggang Bumbu Kari](https://img-global.cpcdn.com/recipes/55733f385b15bfce/680x482cq70/ayam-panggang-bumbu-kari-foto-resep-utama.jpg)

Selaku seorang wanita, menyuguhkan masakan mantab pada keluarga tercinta merupakan suatu hal yang memuaskan untuk kamu sendiri. Peran seorang  wanita Tidak saja mengerjakan pekerjaan rumah saja, namun anda juga wajib menyediakan kebutuhan gizi tercukupi dan juga hidangan yang disantap orang tercinta mesti sedap.

Di waktu  saat ini, kalian memang mampu mengorder santapan yang sudah jadi tanpa harus repot membuatnya dulu. Tapi banyak juga orang yang memang mau menyajikan yang terenak untuk orang tercintanya. Pasalnya, menghidangkan masakan sendiri jauh lebih bersih dan kita juga bisa menyesuaikan makanan tersebut sesuai makanan kesukaan keluarga tercinta. 



Mungkinkah anda salah satu penyuka ayam panggang bumbu kari?. Tahukah kamu, ayam panggang bumbu kari adalah hidangan khas di Nusantara yang sekarang disenangi oleh setiap orang dari hampir setiap tempat di Indonesia. Kita bisa membuat ayam panggang bumbu kari kreasi sendiri di rumahmu dan boleh dijadikan camilan favoritmu di hari libur.

Kalian tak perlu bingung jika kamu ingin menyantap ayam panggang bumbu kari, sebab ayam panggang bumbu kari sangat mudah untuk didapatkan dan juga kalian pun bisa memasaknya sendiri di tempatmu. ayam panggang bumbu kari dapat diolah memalui bermacam cara. Kini telah banyak banget cara kekinian yang menjadikan ayam panggang bumbu kari semakin lezat.

Resep ayam panggang bumbu kari juga mudah sekali untuk dibikin, lho. Kita jangan capek-capek untuk membeli ayam panggang bumbu kari, lantaran Kamu dapat menyiapkan ditempatmu. Bagi Anda yang akan membuatnya, inilah cara membuat ayam panggang bumbu kari yang enak yang bisa Kita buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Ayam Panggang Bumbu Kari:

1. Ambil 1/2 kg ayam bag paha
1. Ambil 1 buah jeruk nipis
1. Gunakan 350 ml air
1. Gunakan 1 sdt bumbu kari instan
1. Gunakan 1 sdm santan instan
1. Gunakan 1/4 sdt mujung asam jawa
1. Siapkan 2 siung bawang putih (geprek iris)
1. Sediakan 4 siung bawang merah
1. Ambil 2 ruas kunyit
1. Siapkan 1 ruas jahe dan lengkuas
1. Siapkan 2 lembar daun salam
1. Ambil 2 lembar daun jeruk
1. Ambil 1 sdt kaldu jamur
1. Ambil 1/2 sdt garam
1. Siapkan 1 sdt gula pasir
1. Sediakan 1/8 sdt lada bubuk




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam Panggang Bumbu Kari:

1. Cuci ayam sampai bersih, lumuri jeruk nipis diamkan 15 menit, kemudian bilas dan tiriskan
1. Siapakan bahan bumbu ungkep, iris semua bahan bumbu ungkep ya
1. Didihkan air, masukan Bahan bumbu ungkep, masak 5 menit, masukan ayam, masukan bumbu kari instan, asam jawa dan semua bumbu penyedap juga santan, aduk rata
1. Ungkep ayam sampai kandungan air kering, Matikan kompor, aduk ayam ungkep, diamkan 15 menit.
1. Panggang ayam di grill pan, sampai matang kecoklatan, sajikan ❤️




Wah ternyata resep ayam panggang bumbu kari yang nikamt simple ini mudah sekali ya! Kamu semua bisa mencobanya. Cara Membuat ayam panggang bumbu kari Sangat cocok banget buat kita yang baru akan belajar memasak atau juga untuk kamu yang telah lihai memasak.

Tertarik untuk mulai mencoba bikin resep ayam panggang bumbu kari lezat sederhana ini? Kalau anda ingin, ayo kalian segera siapin alat-alat dan bahannya, setelah itu buat deh Resep ayam panggang bumbu kari yang enak dan tidak ribet ini. Betul-betul gampang kan. 

Maka, ketimbang kita berlama-lama, ayo kita langsung hidangkan resep ayam panggang bumbu kari ini. Dijamin anda tiidak akan menyesal sudah bikin resep ayam panggang bumbu kari nikmat tidak rumit ini! Selamat mencoba dengan resep ayam panggang bumbu kari lezat sederhana ini di rumah kalian masing-masing,ya!.

