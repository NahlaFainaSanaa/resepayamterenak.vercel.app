---
description: "Cara membuat Soto Ayam Santan Depok yang nikmat dan Mudah Dibuat"
title: "Cara membuat Soto Ayam Santan Depok yang nikmat dan Mudah Dibuat"
slug: 396-cara-membuat-soto-ayam-santan-depok-yang-nikmat-dan-mudah-dibuat
date: 2021-04-22T05:11:58.365Z
image: https://img-global.cpcdn.com/recipes/260f71d8cc5a77c9/680x482cq70/soto-ayam-santan-depok-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/260f71d8cc5a77c9/680x482cq70/soto-ayam-santan-depok-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/260f71d8cc5a77c9/680x482cq70/soto-ayam-santan-depok-foto-resep-utama.jpg
author: Ida Holloway
ratingvalue: 3.4
reviewcount: 13
recipeingredient:
- "300 gr ayam filet"
- "300 gr kentang"
- "1 buah Belimbing Dewa manis"
- "800 ml air matang"
- "200 ml santan kental  instan"
- "  bumbu halus"
- "7 buah bawang merah"
- "5 siung bawang putih"
- "1 sdt ketumbar"
- "1/2 sdt jinten"
- "2 cm kencur"
- "  bumbu cemplung"
- "2 batang sere geprek"
- "2 lembar daun salam"
- "2 lembar daun jeruk"
- "2 cm lengkuas"
- "1 sdm peres garam"
- "  pelengkap"
- " Bawang merah goreng"
- " Sambel dari cabe rawit"
- " Emping"
- " Daun bawang"
recipeinstructions:
- "Siapkan bahan. Blender bumbu halus. Potong ayam dan kentang."
- "Tumis bumbu cemplung hingga harum. Kemudian masukan bumbu halus tumis hingga matang.           (lihat tips)"
- "Masukkan ayam aduk hingga ayam berubah warna."
- "Masukkan kentang, air dan garam."
- "Bila kentang sudah empuk maka masukkan santan. Setelah mendidih masukkan belimbing. Tes rasa dan tunggu mendidih matikan kompor."
- "Soto Ayam Santan Depok siap disajikan."
categories:
- Resep
tags:
- soto
- ayam
- santan

katakunci: soto ayam santan 
nutrition: 265 calories
recipecuisine: Indonesian
preptime: "PT13M"
cooktime: "PT57M"
recipeyield: "4"
recipecategory: Dinner

---


![Soto Ayam Santan Depok](https://img-global.cpcdn.com/recipes/260f71d8cc5a77c9/680x482cq70/soto-ayam-santan-depok-foto-resep-utama.jpg)

Selaku seorang wanita, mempersiapkan santapan sedap untuk famili merupakan hal yang menyenangkan bagi anda sendiri. Tanggung jawab seorang  wanita bukan cuma menangani rumah saja, namun kamu juga harus menyediakan kebutuhan gizi tercukupi dan juga hidangan yang disantap keluarga tercinta wajib lezat.

Di zaman  sekarang, kamu memang bisa mengorder masakan praktis tanpa harus capek membuatnya dulu. Tetapi banyak juga mereka yang selalu ingin menyajikan yang terbaik bagi keluarganya. Lantaran, menyajikan masakan yang dibuat sendiri jauh lebih higienis dan bisa menyesuaikan sesuai kesukaan famili. 



Mungkinkah anda adalah salah satu penggemar soto ayam santan depok?. Tahukah kamu, soto ayam santan depok merupakan sajian khas di Nusantara yang saat ini digemari oleh kebanyakan orang di hampir setiap wilayah di Nusantara. Kita dapat memasak soto ayam santan depok sendiri di rumah dan pasti jadi santapan kesukaanmu di hari libur.

Kamu jangan bingung jika kamu ingin memakan soto ayam santan depok, sebab soto ayam santan depok sangat mudah untuk didapatkan dan juga kalian pun boleh membuatnya sendiri di tempatmu. soto ayam santan depok dapat dibuat memalui berbagai cara. Kini telah banyak banget resep kekinian yang menjadikan soto ayam santan depok semakin lebih enak.

Resep soto ayam santan depok pun gampang untuk dibikin, lho. Kita tidak perlu repot-repot untuk memesan soto ayam santan depok, lantaran Kamu dapat membuatnya ditempatmu. Bagi Kamu yang mau menyajikannya, berikut ini cara untuk menyajikan soto ayam santan depok yang lezat yang bisa Kita coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Soto Ayam Santan Depok:

1. Ambil 300 gr ayam filet
1. Sediakan 300 gr kentang
1. Siapkan 1 buah Belimbing Dewa (manis)
1. Gunakan 800 ml air matang
1. Ambil 200 ml santan kental / instan
1. Ambil  🧄🧄 bumbu halus
1. Gunakan 7 buah bawang merah
1. Gunakan 5 siung bawang putih
1. Siapkan 1 sdt ketumbar
1. Siapkan 1/2 sdt jinten
1. Gunakan 2 cm kencur
1. Siapkan  🧄🧄 bumbu cemplung
1. Sediakan 2 batang sere geprek
1. Siapkan 2 lembar daun salam
1. Gunakan 2 lembar daun jeruk
1. Siapkan 2 cm lengkuas
1. Ambil 1 sdm peres garam
1. Ambil  🧄🧄 pelengkap
1. Gunakan  Bawang merah goreng
1. Sediakan  Sambel dari cabe rawit
1. Ambil  Emping
1. Ambil  Daun bawang




<!--inarticleads2-->

##### Cara menyiapkan Soto Ayam Santan Depok:

1. Siapkan bahan. Blender bumbu halus. Potong ayam dan kentang.
1. Tumis bumbu cemplung hingga harum. Kemudian masukan bumbu halus tumis hingga matang. -           (lihat tips)
1. Masukkan ayam aduk hingga ayam berubah warna.
1. Masukkan kentang, air dan garam.
1. Bila kentang sudah empuk maka masukkan santan. Setelah mendidih masukkan belimbing. - Tes rasa dan tunggu mendidih matikan kompor.
1. Soto Ayam Santan Depok siap disajikan.




Ternyata cara buat soto ayam santan depok yang enak simple ini enteng sekali ya! Kita semua mampu memasaknya. Resep soto ayam santan depok Sesuai sekali untuk kamu yang baru belajar memasak maupun untuk kamu yang telah jago dalam memasak.

Apakah kamu ingin mencoba membikin resep soto ayam santan depok nikmat tidak ribet ini? Kalau kamu tertarik, ayo kalian segera siapin alat dan bahannya, kemudian buat deh Resep soto ayam santan depok yang mantab dan tidak rumit ini. Benar-benar mudah kan. 

Jadi, daripada kamu berlama-lama, ayo kita langsung saja hidangkan resep soto ayam santan depok ini. Dijamin kamu tak akan nyesel membuat resep soto ayam santan depok nikmat simple ini! Selamat berkreasi dengan resep soto ayam santan depok enak simple ini di tempat tinggal kalian sendiri,ya!.

