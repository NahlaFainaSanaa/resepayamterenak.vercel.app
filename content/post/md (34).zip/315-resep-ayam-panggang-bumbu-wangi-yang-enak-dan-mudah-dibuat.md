---
description: "Resep Ayam panggang bumbu wangi yang enak dan Mudah Dibuat"
title: "Resep Ayam panggang bumbu wangi yang enak dan Mudah Dibuat"
slug: 315-resep-ayam-panggang-bumbu-wangi-yang-enak-dan-mudah-dibuat
date: 2021-01-12T08:06:11.098Z
image: https://img-global.cpcdn.com/recipes/f1b9b457ca48dd24/680x482cq70/ayam-panggang-bumbu-wangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f1b9b457ca48dd24/680x482cq70/ayam-panggang-bumbu-wangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f1b9b457ca48dd24/680x482cq70/ayam-panggang-bumbu-wangi-foto-resep-utama.jpg
author: Corey Torres
ratingvalue: 3.1
reviewcount: 8
recipeingredient:
- "500 gr paha ayam tanpa tulang dengan kulit"
- "3 siung bawang putih"
- "2 batang seledri potongpotong"
- "2 batang rosemary"
- "2 batang thyme"
- "4 lembar daun oregano"
- "secukupnya Garam dan lada bubuk"
- "1 sdt minyak zaitun"
- " Daun bawang secukupnya irisiris"
recipeinstructions:
- "Ulek bawang putih dan seledri sampai setengah hancur, lalu masukkan rosemary, thyme, dan oregano, ulek sampai halus lalu campurkan minyak zaitun dan aduk sampai tercampur rata."
- "Panaskan oven."
- "Cuci ayam, tiriskan. Lalu lumuri bumbu ke ayam secara merata, dipastikan juga bumbu dilumuri ke lapisan dalam kulit."
- "Setelah dilumuri dengan rata, lumuri dengan garam dan lada bubuk secukupnya."
- "Taburkan irisan daun bawang ke atas ayam di atas loyang"
- "Masukkan ayam ke dalam oven, dan panggan selama kurang lebih 30 menit atau sampai matang. Angkat dan sajikan."
categories:
- Resep
tags:
- ayam
- panggang
- bumbu

katakunci: ayam panggang bumbu 
nutrition: 175 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT54M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam panggang bumbu wangi](https://img-global.cpcdn.com/recipes/f1b9b457ca48dd24/680x482cq70/ayam-panggang-bumbu-wangi-foto-resep-utama.jpg)

Sebagai seorang wanita, menyuguhkan panganan enak untuk keluarga adalah suatu hal yang memuaskan untuk anda sendiri. Tugas seorang ibu bukan sekadar menjaga rumah saja, tetapi anda pun harus menyediakan kebutuhan gizi terpenuhi dan juga panganan yang dimakan orang tercinta wajib mantab.

Di masa  sekarang, anda sebenarnya mampu membeli panganan instan tidak harus repot mengolahnya terlebih dahulu. Tetapi banyak juga lho mereka yang selalu mau memberikan hidangan yang terenak bagi keluarganya. Karena, memasak yang dibuat sendiri akan jauh lebih higienis dan bisa menyesuaikan masakan tersebut berdasarkan makanan kesukaan keluarga. 

Hal ini dimaksudkan agar bumbu bisa meresap pada ayam secara merata. Panggang daging ayam sambil sesekali diolesi kecap dan bumbu sisa ungkep. Pastikan ayam matang sesuai tingkat kematangan yang diinginkan.

Mungkinkah anda seorang penggemar ayam panggang bumbu wangi?. Asal kamu tahu, ayam panggang bumbu wangi adalah sajian khas di Indonesia yang kini disukai oleh setiap orang di hampir setiap wilayah di Indonesia. Kamu dapat membuat ayam panggang bumbu wangi kreasi sendiri di rumah dan dapat dijadikan hidangan kesukaanmu di hari libur.

Anda tidak usah bingung untuk memakan ayam panggang bumbu wangi, sebab ayam panggang bumbu wangi sangat mudah untuk ditemukan dan juga kita pun bisa mengolahnya sendiri di rumah. ayam panggang bumbu wangi dapat dibuat memalui beraneka cara. Sekarang ada banyak sekali resep modern yang menjadikan ayam panggang bumbu wangi semakin lebih enak.

Resep ayam panggang bumbu wangi juga sangat mudah dihidangkan, lho. Kita jangan repot-repot untuk memesan ayam panggang bumbu wangi, karena Kita dapat menyajikan ditempatmu. Bagi Anda yang ingin menghidangkannya, berikut cara menyajikan ayam panggang bumbu wangi yang mantab yang mampu Kita coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Ayam panggang bumbu wangi:

1. Siapkan 500 gr paha ayam tanpa tulang (dengan kulit)
1. Gunakan 3 siung bawang putih
1. Siapkan 2 batang seledri, potong-potong
1. Ambil 2 batang rosemary
1. Gunakan 2 batang thyme
1. Siapkan 4 lembar daun oregano
1. Ambil secukupnya Garam dan lada bubuk
1. Gunakan 1 sdt minyak zaitun
1. Gunakan  Daun bawang secukupnya, iris-iris


Aduk merata, masak hingga matang dan bumbu meresap. Bakar ayam sambil dibolak balik dan sesekali diolesi bumbu hingga terasa harum. Cara membuat ayam panggang: Cuci bersih bahan untuk bumbu ungkepnya lalu iris-iris. Siapkan air di wajan lalu masukkan ayamnya dan bumbu ungkep tadi. 

<!--inarticleads2-->

##### Langkah-langkah membuat Ayam panggang bumbu wangi:

1. Ulek bawang putih dan seledri sampai setengah hancur, lalu masukkan rosemary, thyme, dan oregano, ulek sampai halus lalu campurkan minyak zaitun dan aduk sampai tercampur rata.
1. Panaskan oven.
1. Cuci ayam, tiriskan. Lalu lumuri bumbu ke ayam secara merata, dipastikan juga bumbu dilumuri ke lapisan dalam kulit.
1. Setelah dilumuri dengan rata, lumuri dengan garam dan lada bubuk secukupnya.
1. Taburkan irisan daun bawang ke atas ayam di atas loyang
1. Masukkan ayam ke dalam oven, dan panggan selama kurang lebih 30 menit atau sampai matang. Angkat dan sajikan.


Masak sampai ayam berwarna kuning dan air tinggal sedikit. Selagi menunggu ayam di ungkep,buat sambal tomat untuk marinasi. Membuat ayam panggang yang utuh sebenarnya susah-susah gampang. Tumis bumbu halus hingga wangi, tambahkan serai, daun salam, jahe, dan lengkuas. Resep ayam bumbu rujak - Ayam adalah salah satu menu favorit semua orang, dan sekarang sudah ada berbagai macam masakan variasi dari ayam. 

Ternyata resep ayam panggang bumbu wangi yang lezat sederhana ini mudah banget ya! Kalian semua dapat mencobanya. Cara Membuat ayam panggang bumbu wangi Sangat sesuai banget untuk kalian yang baru akan belajar memasak ataupun juga bagi kamu yang sudah ahli dalam memasak.

Apakah kamu tertarik mencoba buat resep ayam panggang bumbu wangi lezat sederhana ini? Kalau tertarik, ayo kamu segera siapkan alat dan bahannya, kemudian bikin deh Resep ayam panggang bumbu wangi yang enak dan tidak ribet ini. Sungguh gampang kan. 

Maka dari itu, daripada kalian berfikir lama-lama, yuk langsung aja bikin resep ayam panggang bumbu wangi ini. Dijamin kamu tak akan menyesal membuat resep ayam panggang bumbu wangi mantab tidak rumit ini! Selamat berkreasi dengan resep ayam panggang bumbu wangi lezat tidak rumit ini di tempat tinggal masing-masing,ya!.

