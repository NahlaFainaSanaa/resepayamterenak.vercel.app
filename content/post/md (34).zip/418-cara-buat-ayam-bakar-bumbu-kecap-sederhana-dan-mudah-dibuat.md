---
description: "Cara buat Ayam bakar bumbu kecap Sederhana dan Mudah Dibuat"
title: "Cara buat Ayam bakar bumbu kecap Sederhana dan Mudah Dibuat"
slug: 418-cara-buat-ayam-bakar-bumbu-kecap-sederhana-dan-mudah-dibuat
date: 2021-02-09T13:59:46.705Z
image: https://img-global.cpcdn.com/recipes/b65e32e9934c9cd3/680x482cq70/ayam-bakar-bumbu-kecap-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b65e32e9934c9cd3/680x482cq70/ayam-bakar-bumbu-kecap-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b65e32e9934c9cd3/680x482cq70/ayam-bakar-bumbu-kecap-foto-resep-utama.jpg
author: Jordan Santiago
ratingvalue: 3.6
reviewcount: 7
recipeingredient:
- "1/2 kg sayap ayam"
- "1 buah jeruk nipis"
- "1 sdm gula merah sisir"
- "2 sdm kecap manis"
- "4 lembar daun jeruk"
- "2 lembar daun salam"
- "1 batang sereh"
- "300 ml air matang"
- " bumbu halus "
- "8 siung bawang merah"
- "4 siung bawang putih"
- "4 buah cabe rawit merah"
- "2 cm jahe"
- "3 cm lengkuas"
- "2 butir kemiri"
- "2 buah asam kandis"
- " Garam merica dan gula"
recipeinstructions:
- "Cuci bersih ayam. Kemudian marinasi dgn jeruk nipis dan garam. Diamkan 15 menit, kemudian cuci bersih kembali"
- "Tumis bumbu halus + duo daun dan sereh. Masukkan ayam dan tambahkan air. Koreksi rasa. Masak hingga air menyusut"
- "Panggang di happy call/ teflon dgn sisa bumbu sambil dibolak balik."
categories:
- Resep
tags:
- ayam
- bakar
- bumbu

katakunci: ayam bakar bumbu 
nutrition: 126 calories
recipecuisine: Indonesian
preptime: "PT30M"
cooktime: "PT36M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam bakar bumbu kecap](https://img-global.cpcdn.com/recipes/b65e32e9934c9cd3/680x482cq70/ayam-bakar-bumbu-kecap-foto-resep-utama.jpg)

Andai kita seorang orang tua, menyediakan panganan lezat pada keluarga tercinta adalah suatu hal yang memuaskan untuk kita sendiri. Tanggung jawab seorang  wanita Tidak sekedar menjaga rumah saja, tapi kamu juga wajib memastikan kebutuhan nutrisi terpenuhi dan juga santapan yang disantap keluarga tercinta harus enak.

Di waktu  saat ini, anda memang mampu membeli hidangan siap saji tidak harus capek mengolahnya terlebih dahulu. Namun banyak juga lho orang yang selalu mau memberikan yang terenak bagi keluarganya. Karena, menyajikan masakan sendiri jauh lebih higienis dan kita juga bisa menyesuaikan hidangan tersebut sesuai kesukaan keluarga tercinta. 



Apakah anda seorang penyuka ayam bakar bumbu kecap?. Asal kamu tahu, ayam bakar bumbu kecap adalah hidangan khas di Indonesia yang sekarang disenangi oleh orang-orang dari hampir setiap wilayah di Nusantara. Kita bisa memasak ayam bakar bumbu kecap hasil sendiri di rumahmu dan boleh dijadikan camilan favoritmu di hari libur.

Anda tak perlu bingung untuk memakan ayam bakar bumbu kecap, karena ayam bakar bumbu kecap mudah untuk ditemukan dan anda pun dapat membuatnya sendiri di rumah. ayam bakar bumbu kecap dapat diolah dengan beragam cara. Kini sudah banyak banget resep modern yang membuat ayam bakar bumbu kecap lebih enak.

Resep ayam bakar bumbu kecap juga mudah dibuat, lho. Kita jangan repot-repot untuk membeli ayam bakar bumbu kecap, lantaran Kita dapat menyajikan sendiri di rumah. Untuk Kalian yang ingin menyajikannya, di bawah ini adalah resep untuk menyajikan ayam bakar bumbu kecap yang enak yang mampu Kamu buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Ayam bakar bumbu kecap:

1. Sediakan 1/2 kg sayap ayam
1. Sediakan 1 buah jeruk nipis
1. Gunakan 1 sdm gula merah (sisir)
1. Siapkan 2 sdm kecap manis
1. Ambil 4 lembar daun jeruk
1. Gunakan 2 lembar daun salam
1. Gunakan 1 batang sereh
1. Sediakan 300 ml air matang
1. Ambil  🌻bumbu halus :
1. Sediakan 8 siung bawang merah
1. Gunakan 4 siung bawang putih
1. Siapkan 4 buah cabe rawit merah
1. Siapkan 2 cm jahe
1. Gunakan 3 cm lengkuas
1. Sediakan 2 butir kemiri
1. Siapkan 2 buah asam kandis
1. Ambil  Garam, merica dan gula




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam bakar bumbu kecap:

1. Cuci bersih ayam. Kemudian marinasi dgn jeruk nipis dan garam. Diamkan 15 menit, kemudian cuci bersih kembali
1. Tumis bumbu halus + duo daun dan sereh. Masukkan ayam dan tambahkan air. Koreksi rasa. Masak hingga air menyusut
1. Panggang di happy call/ teflon dgn sisa bumbu sambil dibolak balik.




Wah ternyata cara buat ayam bakar bumbu kecap yang enak simple ini enteng sekali ya! Anda Semua dapat membuatnya. Resep ayam bakar bumbu kecap Sangat sesuai banget untuk kalian yang baru belajar memasak maupun juga untuk anda yang telah jago memasak.

Apakah kamu tertarik mencoba membuat resep ayam bakar bumbu kecap enak tidak rumit ini? Kalau ingin, ayo kalian segera siapin peralatan dan bahan-bahannya, lantas bikin deh Resep ayam bakar bumbu kecap yang mantab dan simple ini. Sangat gampang kan. 

Maka dari itu, ketimbang kamu diam saja, yuk langsung aja hidangkan resep ayam bakar bumbu kecap ini. Dijamin kalian tiidak akan menyesal membuat resep ayam bakar bumbu kecap enak sederhana ini! Selamat berkreasi dengan resep ayam bakar bumbu kecap lezat tidak rumit ini di rumah kalian masing-masing,ya!.

