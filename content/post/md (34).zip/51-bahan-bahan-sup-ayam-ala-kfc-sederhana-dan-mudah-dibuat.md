---
description: "Bahan-bahan Sup Ayam Ala KFC Sederhana dan Mudah Dibuat"
title: "Bahan-bahan Sup Ayam Ala KFC Sederhana dan Mudah Dibuat"
slug: 51-bahan-bahan-sup-ayam-ala-kfc-sederhana-dan-mudah-dibuat
date: 2021-06-03T11:26:12.272Z
image: https://img-global.cpcdn.com/recipes/40b365988ad87ee8/680x482cq70/sup-ayam-ala-kfc-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/40b365988ad87ee8/680x482cq70/sup-ayam-ala-kfc-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/40b365988ad87ee8/680x482cq70/sup-ayam-ala-kfc-foto-resep-utama.jpg
author: Carl Brewer
ratingvalue: 3.6
reviewcount: 5
recipeingredient:
- "1/2 kg ayam potong kecilkecil"
- "2 buah jagung manis dipipil"
- "3 buah wortel dipotong dadu"
- "Secukupnya buncis potong 2cm"
- "Secukupnya daun seledri"
- "Secukupnya daun bawang"
- "1 sdm margarin"
- "Secukupnya merica bubuk"
- "Secukupnya kaldu ayam boleh diskip"
- "Secukupnya kaldu jamur"
- "Secukupnya garam"
- "1 sdt gula pasir"
recipeinstructions:
- "Seperti biasa, cuci bersih ayam, rebus sampai mendidih saja airnya, tdk perlu lama2. Matikan kompor, buang air rebusan ayam, bilas dgn air bersih, sisihkan. Cuci bersih semua bahan sayurannya setelah dikupas, baru dipotong2."
- "Masukkan ayam yg sdh direbus &amp; dicuci tadi ke dalam panci, beri air &amp; rebus kembali. Kalau pake ayam kampung tdk usah begini ya moms. Langsung rebus saja, tdk perlu dibuang airnya."
- "Setelah ayam mendidih, masukan wortel yg sdh di iris dadu tadi."
- "Setelah wortelnya setengah matang, masukkan potongan buncisnya."
- "Setelah itu masukkan pipilan jagung manisnya."
- "Kemudian masukkan trio penyedapnya, yaitu merica bubuk, kaldu ayam &amp; kaldu jamurnya."
- "Sebelum dimatikan kompornya, masukkan 1 sendok makan margarin, gula pasir &amp; garam. Aduk2 &amp; koreksi rasanya."
- "Terakhir masukkan daun seledri &amp; daun bawangnya. Aduk2 &amp; kemudian matikan kompornya."
- "Sup ayam ala2 kaefsi siap disajikan mom... ❤️"
- "Mudah &amp; cepat moms...solusi praktis kalo lagi ga punya bawang putih atau males ngeprek bawang putih 🤭"
categories:
- Resep
tags:
- sup
- ayam
- ala

katakunci: sup ayam ala 
nutrition: 161 calories
recipecuisine: Indonesian
preptime: "PT26M"
cooktime: "PT51M"
recipeyield: "1"
recipecategory: Dinner

---


![Sup Ayam Ala KFC](https://img-global.cpcdn.com/recipes/40b365988ad87ee8/680x482cq70/sup-ayam-ala-kfc-foto-resep-utama.jpg)

Selaku seorang orang tua, menyuguhkan masakan menggugah selera pada keluarga tercinta merupakan hal yang mengasyikan bagi anda sendiri. Tugas seorang  wanita bukan sekadar mengatur rumah saja, tapi anda pun wajib menyediakan keperluan gizi tercukupi dan juga masakan yang dimakan anak-anak mesti menggugah selera.

Di era  sekarang, kita memang mampu mengorder panganan jadi meski tidak harus repot membuatnya lebih dulu. Namun banyak juga lho orang yang selalu mau menghidangkan yang terlezat bagi orang tercintanya. Lantaran, menghidangkan masakan yang diolah sendiri jauh lebih bersih dan kita juga bisa menyesuaikan hidangan tersebut sesuai dengan kesukaan famili. 

Beli mahal 🤭, buat sendiri lebih puas makannya 😅😅. Recook : @happy_endahsa #GenkPejuangDapur #ArisanRecook_HappyEnd #RememberGenkPeDa_HappyEnd #GenkPeDa_HappyEnd #GenkPeDa_Eksis #MasakItuSaya #BagikanIspirasimu #cookpadcommunity_jakarta #cookpadindonesia. Sup Ayam ala kfc dada ayam fillet,potong dadu • sayap ayam,potong kecil (optional) • wortel,potong kecil dadu • kentang,potong kecil dadu • jagung,pipil (optional) • bawang putih,cincang kasar • daun seledri,iris tipis • garam Anda bisa mengatasi hal ini dengan mencoba sendiri resep sup ala KFC ini di rumah yang pastinya anda bisa mengontrol jumlah daging, jumlah porsi, dan bahan lainnya yang ingin anda tambahkan.

Apakah anda seorang penggemar sup ayam ala kfc?. Asal kamu tahu, sup ayam ala kfc adalah makanan khas di Indonesia yang kini disukai oleh kebanyakan orang di hampir setiap wilayah di Nusantara. Kamu bisa menyajikan sup ayam ala kfc buatan sendiri di rumahmu dan pasti jadi camilan favorit di hari liburmu.

Anda tak perlu bingung jika kamu ingin menyantap sup ayam ala kfc, lantaran sup ayam ala kfc sangat mudah untuk didapatkan dan juga anda pun dapat membuatnya sendiri di rumah. sup ayam ala kfc boleh dibuat dengan beraneka cara. Sekarang sudah banyak resep kekinian yang menjadikan sup ayam ala kfc semakin lebih nikmat.

Resep sup ayam ala kfc pun sangat gampang untuk dibuat, lho. Anda tidak perlu capek-capek untuk memesan sup ayam ala kfc, sebab Anda bisa menyajikan ditempatmu. Untuk Kamu yang akan menyajikannya, berikut ini cara untuk membuat sup ayam ala kfc yang mantab yang mampu Kamu coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Sup Ayam Ala KFC:

1. Sediakan 1/2 kg ayam potong kecil-kecil
1. Ambil 2 buah jagung manis dipipil
1. Ambil 3 buah wortel dipotong dadu
1. Siapkan Secukupnya buncis potong 2cm
1. Siapkan Secukupnya daun seledri
1. Siapkan Secukupnya daun bawang
1. Sediakan 1 sdm margarin
1. Sediakan Secukupnya merica bubuk
1. Ambil Secukupnya kaldu ayam (boleh diskip)
1. Gunakan Secukupnya kaldu jamur
1. Siapkan Secukupnya garam
1. Sediakan 1 sdt gula pasir


Jika kaldu ayam sudah hampir mendidih, masukkan ayam suwir, potongan wortel, jagung, dan kacang polong. Masukkan bumbu sup dengan lada dan garam. Cream soup ala KFC siap dihidangkan. Cream soup ayam ala KFC bawang Bombay, iris memanjang • bawang putih, geprek, cincang halus • jagung manis, pipil • wortel, potong dadu kecil • kentang, potong dadu kecil • daging ayam, potong dadu kecil • susu cair (saya pakai diamond) • kaldu bubuk Bahkan cara membuat krim sup ala KFC tak sulit loh. 

<!--inarticleads2-->

##### Langkah-langkah menyiapkan Sup Ayam Ala KFC:

1. Seperti biasa, cuci bersih ayam, rebus sampai mendidih saja airnya, tdk perlu lama2. Matikan kompor, buang air rebusan ayam, bilas dgn air bersih, sisihkan. Cuci bersih semua bahan sayurannya setelah dikupas, baru dipotong2.
1. Masukkan ayam yg sdh direbus &amp; dicuci tadi ke dalam panci, beri air &amp; rebus kembali. Kalau pake ayam kampung tdk usah begini ya moms. Langsung rebus saja, tdk perlu dibuang airnya.
1. Setelah ayam mendidih, masukan wortel yg sdh di iris dadu tadi.
1. Setelah wortelnya setengah matang, masukkan potongan buncisnya.
1. Setelah itu masukkan pipilan jagung manisnya.
1. Kemudian masukkan trio penyedapnya, yaitu merica bubuk, kaldu ayam &amp; kaldu jamurnya.
1. Sebelum dimatikan kompornya, masukkan 1 sendok makan margarin, gula pasir &amp; garam. Aduk2 &amp; koreksi rasanya.
1. Terakhir masukkan daun seledri &amp; daun bawangnya. Aduk2 &amp; kemudian matikan kompornya.
1. Sup ayam ala2 kaefsi siap disajikan mom... ❤️
1. Mudah &amp; cepat moms...solusi praktis kalo lagi ga punya bawang putih atau males ngeprek bawang putih 🤭


Dengan Anda mengetahui bagaimana cara membuat krim sup ala KFC Anda tak perlu lagi jajan di luar. Krim sup memang jadi menu favorit semua orang. Baca Juga: Engga Perlu Beli Mahal-mahal, Begini Cara Membuat Kaldu yang Enak Di Rumah, Dijamin Antigagal! Panaskan minyak, tumis bawang putih, halia, bawang merah, bawang besar, serai dan cili. Tambahkan air dan perasakan dengan kiub ayam, sup bunjut, garam, gula, serbuk perasa dan sedikit sos ikan. 

Wah ternyata cara membuat sup ayam ala kfc yang lezat simple ini enteng banget ya! Kamu semua bisa menghidangkannya. Resep sup ayam ala kfc Cocok banget buat kamu yang baru akan belajar memasak atau juga untuk anda yang sudah lihai memasak.

Apakah kamu ingin mencoba bikin resep sup ayam ala kfc lezat sederhana ini? Kalau anda tertarik, mending kamu segera siapin peralatan dan bahan-bahannya, lalu bikin deh Resep sup ayam ala kfc yang nikmat dan simple ini. Benar-benar taidak sulit kan. 

Jadi, ketimbang kita diam saja, yuk kita langsung sajikan resep sup ayam ala kfc ini. Dijamin kalian gak akan nyesel membuat resep sup ayam ala kfc mantab tidak ribet ini! Selamat berkreasi dengan resep sup ayam ala kfc nikmat tidak ribet ini di tempat tinggal masing-masing,ya!.

