---
description: "Resep Ayam Asam Manis Sederhana Untuk Jualan"
title: "Resep Ayam Asam Manis Sederhana Untuk Jualan"
slug: 339-resep-ayam-asam-manis-sederhana-untuk-jualan
date: 2021-05-17T20:31:43.937Z
image: https://img-global.cpcdn.com/recipes/504d29795bc2cfd1/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/504d29795bc2cfd1/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/504d29795bc2cfd1/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
author: Oscar Bennett
ratingvalue: 3.4
reviewcount: 14
recipeingredient:
- " Dada ayam fillet bisa dipotong dadu atau sedikit memanjang"
- " Bahan marinasi ayam"
- "1 sdm saos tiram"
- "1/2 sdt lada bulat yg sudah diulek"
- "1 sdt kecap asin"
- "1/2 potong jeruk nipis"
- " Bahan tepung krispi ayam"
- "1 sdm tepung kobe krispi"
- "3 sdm terigu"
- "1/2 sdt baking powder"
- " Bahan saus asam manis"
- "1 buah paprika merah bisa dipakai semua atau setengahnya"
- "1 buah paprika hijau"
- "1 buah bawang bombay bisa dipakai separuh balik ke selera"
- "1 siung bawang putih cincang"
- "4 cm jahe bisa cincang atau geprek atau parut"
- "1 sdm kecap inggris"
- "4 sdm saus tomat"
- "1 sdm saus cabe botolan"
- "100 ml air"
- "1 sdm maizena larutkan dengan air"
- "Secukupnya garam"
- "Secukupnya gula"
- "Secukupnya minyak"
recipeinstructions:
- "Siapkan semua bahan dan peralatan."
- "Saya selalu marinasi ayam kalau mau ditepungin. Beri waktu sekitar 20menitan untuk marinasinya."
- "Siapkan tepung krispinya. Bisa dibuat 1 adonan basah agak kental. Atau 2 adonan yaitu basah dan kering. Kalau saya pakai 2 adonan."
- "Panaskan minyak yg cukup utk goreng ayam. Masukkan potongan ayam ke adonan kering - basah - kering lalu goreng sampai semua potongan habis."
- "Pastikan ayam mateng luar dalam ya hingga warna golden brown. Lalu angkat dan tiriskan"
- "Mari membuat saus. Beri sedikit minyak panas. Tumis bawangputih terlebih dahulu. Lalu masukkan jahe. Aduk"
- "Api jangan besar supaya tidak gosong. Kemudian masukkan bombay dan semua paprika."
- "Setelah agak layu, masukkan saus tomat dan sambal. Lanjut dengan kecap inggris dan air."
- "Setelah itu masukkan maizena yg sudah dilarutkan tadi. Aduk"
- "Tambahkan garam dan gula secukupnya. Tes rasa. Jika sudah pas bisa disajikan langsung disiram ke ayam atau terpisah sebagai cocolan."
categories:
- Resep
tags:
- ayam
- asam
- manis

katakunci: ayam asam manis 
nutrition: 299 calories
recipecuisine: Indonesian
preptime: "PT13M"
cooktime: "PT59M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam Asam Manis](https://img-global.cpcdn.com/recipes/504d29795bc2cfd1/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg)

Sebagai seorang yang hobi masak, menyuguhkan panganan lezat pada orang tercinta merupakan suatu hal yang membahagiakan bagi kita sendiri. Tanggung jawab seorang istri bukan saja mengurus rumah saja, tetapi anda pun wajib menyediakan keperluan nutrisi tercukupi dan juga hidangan yang disantap orang tercinta wajib lezat.

Di waktu  sekarang, kamu sebenarnya bisa memesan masakan praktis meski tanpa harus capek membuatnya lebih dulu. Namun ada juga lho orang yang selalu mau memberikan hidangan yang terlezat untuk orang yang dicintainya. Karena, menyajikan masakan sendiri jauh lebih bersih dan bisa menyesuaikan masakan tersebut sesuai dengan kesukaan orang tercinta. 



Apakah anda merupakan salah satu penikmat ayam asam manis?. Tahukah kamu, ayam asam manis merupakan hidangan khas di Indonesia yang sekarang disenangi oleh setiap orang di berbagai wilayah di Indonesia. Kita bisa menyajikan ayam asam manis hasil sendiri di rumah dan pasti jadi camilan favorit di hari libur.

Kamu tak perlu bingung jika kamu ingin menyantap ayam asam manis, karena ayam asam manis tidak sulit untuk dicari dan juga kamu pun boleh memasaknya sendiri di rumah. ayam asam manis bisa dimasak memalui berbagai cara. Sekarang telah banyak resep modern yang membuat ayam asam manis lebih enak.

Resep ayam asam manis juga mudah dibikin, lho. Kita tidak perlu ribet-ribet untuk memesan ayam asam manis, karena Kita mampu membuatnya sendiri di rumah. Untuk Kita yang hendak membuatnya, di bawah ini adalah resep untuk membuat ayam asam manis yang mantab yang mampu Kalian coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Ayam Asam Manis:

1. Ambil  Dada ayam fillet, (bisa dipotong dadu atau sedikit memanjang)
1. Sediakan  Bahan marinasi ayam:
1. Gunakan 1 sdm saos tiram
1. Siapkan 1/2 sdt lada bulat yg sudah diulek
1. Gunakan 1 sdt kecap asin
1. Ambil 1/2 potong jeruk nipis
1. Sediakan  Bahan tepung krispi ayam:
1. Siapkan 1 sdm tepung kobe krispi
1. Sediakan 3 sdm terigu
1. Siapkan 1/2 sdt baking powder
1. Siapkan  Bahan saus asam manis:
1. Sediakan 1 buah paprika merah, bisa dipakai semua atau setengahnya
1. Ambil 1 buah paprika hijau
1. Gunakan 1 buah bawang bombay, bisa dipakai separuh balik ke selera
1. Ambil 1 siung bawang putih, cincang
1. Gunakan 4 cm jahe, bisa cincang atau geprek atau parut
1. Gunakan 1 sdm kecap inggris
1. Siapkan 4 sdm saus tomat
1. Gunakan 1 sdm saus cabe botolan
1. Sediakan 100 ml air
1. Gunakan 1 sdm maizena, larutkan dengan air
1. Sediakan Secukupnya garam
1. Sediakan Secukupnya gula
1. Siapkan Secukupnya minyak




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Asam Manis:

1. Siapkan semua bahan dan peralatan.
1. Saya selalu marinasi ayam kalau mau ditepungin. Beri waktu sekitar 20menitan untuk marinasinya.
1. Siapkan tepung krispinya. Bisa dibuat 1 adonan basah agak kental. Atau 2 adonan yaitu basah dan kering. Kalau saya pakai 2 adonan.
1. Panaskan minyak yg cukup utk goreng ayam. Masukkan potongan ayam ke adonan kering - basah - kering lalu goreng sampai semua potongan habis.
1. Pastikan ayam mateng luar dalam ya hingga warna golden brown. Lalu angkat dan tiriskan
1. Mari membuat saus. Beri sedikit minyak panas. Tumis bawangputih terlebih dahulu. Lalu masukkan jahe. Aduk
1. Api jangan besar supaya tidak gosong. Kemudian masukkan bombay dan semua paprika.
1. Setelah agak layu, masukkan saus tomat dan sambal. Lanjut dengan kecap inggris dan air.
1. Setelah itu masukkan maizena yg sudah dilarutkan tadi. Aduk
1. Tambahkan garam dan gula secukupnya. Tes rasa. Jika sudah pas bisa disajikan langsung disiram ke ayam atau terpisah sebagai cocolan.




Wah ternyata resep ayam asam manis yang mantab tidak ribet ini mudah sekali ya! Kamu semua mampu menghidangkannya. Cara buat ayam asam manis Cocok banget untuk anda yang sedang belajar memasak atau juga untuk kalian yang telah lihai memasak.

Tertarik untuk mulai mencoba membuat resep ayam asam manis nikmat sederhana ini? Kalau kamu ingin, yuk kita segera siapkan alat dan bahannya, maka buat deh Resep ayam asam manis yang nikmat dan sederhana ini. Betul-betul taidak sulit kan. 

Jadi, daripada kalian berlama-lama, yuk kita langsung sajikan resep ayam asam manis ini. Dijamin kamu gak akan menyesal sudah membuat resep ayam asam manis lezat sederhana ini! Selamat berkreasi dengan resep ayam asam manis nikmat tidak rumit ini di tempat tinggal kalian masing-masing,oke!.

