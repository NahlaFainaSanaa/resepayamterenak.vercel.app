---
description: "Cara membuat Ayam bakar bumbu kecap yang enak Untuk Jualan"
title: "Cara membuat Ayam bakar bumbu kecap yang enak Untuk Jualan"
slug: 419-cara-membuat-ayam-bakar-bumbu-kecap-yang-enak-untuk-jualan
date: 2021-05-16T07:38:15.975Z
image: https://img-global.cpcdn.com/recipes/a011c21f0f8a792d/680x482cq70/ayam-bakar-bumbu-kecap-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a011c21f0f8a792d/680x482cq70/ayam-bakar-bumbu-kecap-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a011c21f0f8a792d/680x482cq70/ayam-bakar-bumbu-kecap-foto-resep-utama.jpg
author: Marc Lyons
ratingvalue: 4.5
reviewcount: 13
recipeingredient:
- "1 ekor ayam potong sesuai selera"
- "1 bh jeruk nipis"
- "2 lbr daun jeruk"
- "2 lbr daun salam"
- "1 batang sereh geprek"
- "1 ruas lengkuas geprek"
- "Secukupnya garam gula dan kaldu bubuk"
- " Bumbu Halus "
- "6 bawang merah"
- "3 bawang putih"
- "1 ruas jahe"
- "1 sdt ketumbar"
- "1/2 sdt lada butiran"
- "3 butir kemiri"
- "1 ruas kunyit"
- "Secukupnya kecap manis me Bango"
recipeinstructions:
- "Cuci bersih ayam lalu lumuri dengan jeruk nipis, diamkan 10 menit lalu cuci bersih kembali"
- "Siapkan bumbu halus, uleg hingga halus"
- "Tumis bumbu halus dengan sedikit minyak goreng hingga harum, sekaligus masukkan daun salam, daun jeruk, sereh dan lengkuas geprek. Tumis hingga matang, lalu masukkan garam gula dan kaldu bubuk"
- "Beri ayam secukupnya, aduk rata, masukkan ayam dan ungkep sampai ayam empuk dan airnya habis"
- "Siapkan panggangan, saya menggunakan batu granit utk memanggang, ambil sisa bumbu dr ayam ungkep td beri kecap manis secukupnya, aduk rata. Panggang ayam sambil diolesi bumbu kecap tadi smp rata, dan panggang bolak balik."
- "Pada step ini jika menginginkan ayam goreng, tggl ambil ayam ungkep td dan goreng dengan minyak agak banyak."
- "Ayam panggang sudah siap tggl dinikmati dengan lalapan / urap sayur"
categories:
- Resep
tags:
- ayam
- bakar
- bumbu

katakunci: ayam bakar bumbu 
nutrition: 154 calories
recipecuisine: Indonesian
preptime: "PT18M"
cooktime: "PT30M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam bakar bumbu kecap](https://img-global.cpcdn.com/recipes/a011c21f0f8a792d/680x482cq70/ayam-bakar-bumbu-kecap-foto-resep-utama.jpg)

Jika kalian seorang wanita, menyediakan masakan lezat buat orang tercinta adalah suatu hal yang mengasyikan bagi kamu sendiri. Tugas seorang  wanita bukan hanya mengurus rumah saja, namun kamu juga wajib menyediakan keperluan nutrisi tercukupi dan santapan yang disantap orang tercinta wajib nikmat.

Di waktu  sekarang, kita sebenarnya dapat mengorder masakan siap saji walaupun tidak harus susah mengolahnya lebih dulu. Tapi ada juga mereka yang selalu mau memberikan makanan yang terlezat untuk orang yang dicintainya. Karena, memasak sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan berdasarkan selera keluarga. 



Apakah anda adalah seorang penyuka ayam bakar bumbu kecap?. Tahukah kamu, ayam bakar bumbu kecap merupakan sajian khas di Nusantara yang saat ini disenangi oleh orang-orang dari berbagai daerah di Nusantara. Kita bisa menyajikan ayam bakar bumbu kecap sendiri di rumah dan pasti jadi camilan kesenanganmu di akhir pekanmu.

Kamu jangan bingung untuk memakan ayam bakar bumbu kecap, sebab ayam bakar bumbu kecap sangat mudah untuk ditemukan dan juga anda pun dapat membuatnya sendiri di rumah. ayam bakar bumbu kecap bisa dibuat lewat beragam cara. Saat ini sudah banyak sekali cara modern yang menjadikan ayam bakar bumbu kecap semakin lebih lezat.

Resep ayam bakar bumbu kecap juga sangat gampang untuk dibikin, lho. Kamu jangan ribet-ribet untuk membeli ayam bakar bumbu kecap, tetapi Kalian mampu menghidangkan di rumahmu. Bagi Kamu yang hendak menghidangkannya, dibawah ini merupakan resep menyajikan ayam bakar bumbu kecap yang mantab yang mampu Kita hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Ayam bakar bumbu kecap:

1. Ambil 1 ekor ayam potong sesuai selera
1. Siapkan 1 bh jeruk nipis
1. Siapkan 2 lbr daun jeruk
1. Siapkan 2 lbr daun salam
1. Ambil 1 batang sereh geprek
1. Ambil 1 ruas lengkuas geprek
1. Gunakan Secukupnya garam gula dan kaldu bubuk
1. Ambil  Bumbu Halus :
1. Gunakan 6 bawang merah
1. Siapkan 3 bawang putih
1. Sediakan 1 ruas jahe
1. Sediakan 1 sdt ketumbar
1. Sediakan 1/2 sdt lada butiran
1. Siapkan 3 butir kemiri
1. Ambil 1 ruas kunyit
1. Siapkan Secukupnya kecap manis (me: Bango)




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam bakar bumbu kecap:

1. Cuci bersih ayam lalu lumuri dengan jeruk nipis, diamkan 10 menit lalu cuci bersih kembali
1. Siapkan bumbu halus, uleg hingga halus
1. Tumis bumbu halus dengan sedikit minyak goreng hingga harum, sekaligus masukkan daun salam, daun jeruk, sereh dan lengkuas geprek. Tumis hingga matang, lalu masukkan garam gula dan kaldu bubuk
1. Beri ayam secukupnya, aduk rata, masukkan ayam dan ungkep sampai ayam empuk dan airnya habis
1. Siapkan panggangan, saya menggunakan batu granit utk memanggang, ambil sisa bumbu dr ayam ungkep td beri kecap manis secukupnya, aduk rata. Panggang ayam sambil diolesi bumbu kecap tadi smp rata, dan panggang bolak balik.
1. Pada step ini jika menginginkan ayam goreng, tggl ambil ayam ungkep td dan goreng dengan minyak agak banyak.
1. Ayam panggang sudah siap tggl dinikmati dengan lalapan / urap sayur




Wah ternyata resep ayam bakar bumbu kecap yang enak simple ini enteng sekali ya! Kita semua dapat memasaknya. Cara buat ayam bakar bumbu kecap Sangat sesuai banget untuk anda yang sedang belajar memasak ataupun bagi kamu yang telah pandai dalam memasak.

Tertarik untuk mulai mencoba bikin resep ayam bakar bumbu kecap lezat tidak ribet ini? Kalau ingin, ayo kamu segera buruan menyiapkan alat-alat dan bahannya, maka buat deh Resep ayam bakar bumbu kecap yang nikmat dan tidak rumit ini. Sungguh taidak sulit kan. 

Maka dari itu, ketimbang anda diam saja, hayo kita langsung saja buat resep ayam bakar bumbu kecap ini. Pasti kamu tak akan menyesal sudah buat resep ayam bakar bumbu kecap enak tidak rumit ini! Selamat mencoba dengan resep ayam bakar bumbu kecap lezat simple ini di tempat tinggal masing-masing,oke!.

