---
description: "Cara buat Soto ayam Sederhana Untuk Jualan"
title: "Cara buat Soto ayam Sederhana Untuk Jualan"
slug: 178-cara-buat-soto-ayam-sederhana-untuk-jualan
date: 2021-03-20T20:29:32.351Z
image: https://img-global.cpcdn.com/recipes/6da8f8ea7600d860/680x482cq70/soto-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6da8f8ea7600d860/680x482cq70/soto-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6da8f8ea7600d860/680x482cq70/soto-ayam-foto-resep-utama.jpg
author: Rosetta Harrison
ratingvalue: 3.5
reviewcount: 4
recipeingredient:
- "1/2 kg ayam"
- "100 gr toge rebus sebentar"
- "100 gr kol iris lebut rebus sebentar"
- "1 keping bihun jagung rebus"
- "3 butir telur rebus potong belah dua"
- "1 buah tomat"
- "1 buah jeruk nipis"
- "Secukupnya bawang goreng"
- "1 batang sledri iris lembut"
- "1 batang daun bawang potong 2 satu ruas jari"
- "Secukupnya kecap"
- "Secukupnya sambal"
- "1500 ml air"
- "Secukupnya garam dan kaldu bubuk"
- " Bumbu halus "
- "6 buah bawang merah"
- "3 buah bawang putih"
- "2 cm jahe"
- "1/2 sdt kunyit bubuk"
- "1/4 sdt lada bubuk"
- " Rempah2 "
- "3 lembar daun salam"
- "5 lembar daun jeruk"
- "1 batang sereh agak besar geprek"
recipeinstructions:
- "Rebus ayam, buang air rebusan air pertama, didihkan air rebus ayam kembali"
- "Tumis bumbu halus bersama rempah2 masak hingga matang, tuang kedalam panci rebusan ayam aduk rata"
- "Masukan garam dan kaldu bubuk aduk rata, terakhir masukan potongan daun bawang aduk rata. Ambil ayamnya biarkan tiris dan dingin lalu suwir2 ayam."
- "Penyajian, ambil secukupnya bihun, kol, toge, ayam suwir, potongan tomat, dan telur lalu siram dengan kuah kaldu panas, taburi atasnya dengan irisan daun sledri, perasan jeruk nipis, bawang goreng dan kecap, aduk rata."
categories:
- Resep
tags:
- soto
- ayam

katakunci: soto ayam 
nutrition: 149 calories
recipecuisine: Indonesian
preptime: "PT37M"
cooktime: "PT41M"
recipeyield: "4"
recipecategory: Dessert

---


![Soto ayam](https://img-global.cpcdn.com/recipes/6da8f8ea7600d860/680x482cq70/soto-ayam-foto-resep-utama.jpg)

Sebagai seorang ibu, menyediakan panganan nikmat pada keluarga tercinta adalah hal yang sangat menyenangkan untuk kamu sendiri. Tanggung jawab seorang  wanita bukan saja mengerjakan pekerjaan rumah saja, tapi kamu juga harus memastikan kebutuhan gizi tercukupi dan hidangan yang dikonsumsi anak-anak harus enak.

Di masa  sekarang, kamu memang mampu membeli masakan praktis walaupun tidak harus ribet memasaknya terlebih dahulu. Tetapi ada juga lho orang yang selalu ingin menghidangkan yang terbaik bagi orang tercintanya. Karena, menyajikan masakan sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan makanan tersebut berdasarkan kesukaan keluarga tercinta. 



Mungkinkah anda seorang penikmat soto ayam?. Tahukah kamu, soto ayam merupakan hidangan khas di Nusantara yang saat ini digemari oleh orang-orang di berbagai daerah di Nusantara. Kita dapat membuat soto ayam sendiri di rumahmu dan pasti jadi hidangan favoritmu di akhir pekanmu.

Kita tak perlu bingung untuk memakan soto ayam, lantaran soto ayam sangat mudah untuk didapatkan dan kalian pun boleh memasaknya sendiri di rumah. soto ayam dapat dimasak memalui beragam cara. Kini sudah banyak resep kekinian yang membuat soto ayam lebih enak.

Resep soto ayam juga gampang dibuat, lho. Kalian tidak usah ribet-ribet untuk memesan soto ayam, tetapi Kita bisa menyajikan sendiri di rumah. Bagi Kita yang ingin membuatnya, di bawah ini adalah resep membuat soto ayam yang lezat yang bisa Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Soto ayam:

1. Sediakan 1/2 kg ayam
1. Ambil 100 gr toge (rebus sebentar)
1. Sediakan 100 gr kol (iris lebut rebus sebentar)
1. Sediakan 1 keping bihun jagung (rebus)
1. Gunakan 3 butir telur (rebus, potong belah dua)
1. Siapkan 1 buah tomat
1. Siapkan 1 buah jeruk nipis
1. Siapkan Secukupnya bawang goreng
1. Sediakan 1 batang sledri (iris lembut)
1. Siapkan 1 batang daun bawang (potong 2 satu ruas jari)
1. Gunakan Secukupnya kecap
1. Gunakan Secukupnya sambal
1. Sediakan 1500 ml air
1. Gunakan Secukupnya garam dan kaldu bubuk
1. Ambil  Bumbu halus :
1. Gunakan 6 buah bawang merah
1. Siapkan 3 buah bawang putih
1. Siapkan 2 cm jahe
1. Ambil 1/2 sdt kunyit bubuk
1. Sediakan 1/4 sdt lada bubuk
1. Siapkan  Rempah2 :
1. Siapkan 3 lembar daun salam
1. Ambil 5 lembar daun jeruk
1. Siapkan 1 batang sereh agak besar geprek




<!--inarticleads2-->

##### Cara menyiapkan Soto ayam:

1. Rebus ayam, buang air rebusan air pertama, didihkan air rebus ayam kembali
1. Tumis bumbu halus bersama rempah2 masak hingga matang, tuang kedalam panci rebusan ayam aduk rata
1. Masukan garam dan kaldu bubuk aduk rata, terakhir masukan potongan daun bawang aduk rata. - Ambil ayamnya biarkan tiris dan dingin lalu suwir2 ayam.
1. Penyajian, ambil secukupnya bihun, kol, toge, ayam suwir, potongan tomat, dan telur lalu siram dengan kuah kaldu panas, taburi atasnya dengan irisan daun sledri, perasan jeruk nipis, bawang goreng dan kecap, aduk rata.




Ternyata cara buat soto ayam yang nikamt simple ini mudah sekali ya! Kita semua bisa memasaknya. Resep soto ayam Sangat cocok banget untuk kamu yang sedang belajar memasak maupun bagi kalian yang telah pandai memasak.

Tertarik untuk mencoba membikin resep soto ayam enak sederhana ini? Kalau anda tertarik, mending kamu segera menyiapkan alat-alat dan bahan-bahannya, maka bikin deh Resep soto ayam yang enak dan sederhana ini. Sangat mudah kan. 

Oleh karena itu, ketimbang anda berlama-lama, yuk langsung aja buat resep soto ayam ini. Pasti anda tak akan nyesel membuat resep soto ayam mantab tidak ribet ini! Selamat mencoba dengan resep soto ayam nikmat sederhana ini di tempat tinggal sendiri,ya!.

