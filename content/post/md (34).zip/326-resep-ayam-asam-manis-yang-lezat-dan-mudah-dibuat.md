---
description: "Resep Ayam Asam Manis yang lezat dan Mudah Dibuat"
title: "Resep Ayam Asam Manis yang lezat dan Mudah Dibuat"
slug: 326-resep-ayam-asam-manis-yang-lezat-dan-mudah-dibuat
date: 2021-01-19T07:59:14.372Z
image: https://img-global.cpcdn.com/recipes/9925cdc48f64aca3/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9925cdc48f64aca3/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9925cdc48f64aca3/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
author: Augusta Long
ratingvalue: 4.8
reviewcount: 9
recipeingredient:
- "400 gr Dada Ayam tanpa tulang"
- "1 butir telur"
- " Tepung Bumbu Serbaguna"
- "1/2 Bawang Bombay"
- "2 siung Bawang Putih"
- "1 siung Bawang Merah"
- "1 Sdm Saus Tiram"
- "3 Sdm Saus Tomat"
- "1/2 sdm kecap manis"
- " Gula"
- " Garam"
- " Penyedap Rasa"
- " Lada bubuk"
- "1 Gelas Air"
- " Daun Bawang"
recipeinstructions:
- "Cuci bersih dada ayam, lalu potong-potong sesuai selera"
- "Marinasi Dada Ayam dengan garam, lada bubuk dan telur. Diamkan sekitar 15 menit"
- "Balurkan dada ayam dengan tepung bumbu serbaguna, lalu goreng hingga matang. Sisihkan."
- "Tumis bawang putih, bawang merah dan bawang bombay hingga harum"
- "Masukkan saus tiram, saus tomat, kecap manis dan air. Tambahkan gula, garam, penyedap rasa dan lada bubuk."
- "Masak hingga agak mengental. Matikan api, masukan dada ayam yang sudah di goreng. Aduk rata dan taburi dengan daun bawang."
- "Siap disajikan dengan nasi hangat"
categories:
- Resep
tags:
- ayam
- asam
- manis

katakunci: ayam asam manis 
nutrition: 235 calories
recipecuisine: Indonesian
preptime: "PT10M"
cooktime: "PT59M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Asam Manis](https://img-global.cpcdn.com/recipes/9925cdc48f64aca3/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg)

Sebagai seorang ibu, mempersiapkan masakan menggugah selera buat keluarga adalah hal yang menyenangkan untuk kita sendiri. Tanggung jawab seorang ibu Tidak cuman menjaga rumah saja, tapi kamu pun harus memastikan kebutuhan nutrisi tercukupi dan santapan yang dimakan anak-anak harus sedap.

Di era  saat ini, kalian memang bisa memesan panganan yang sudah jadi meski tidak harus repot mengolahnya lebih dulu. Tetapi banyak juga mereka yang memang mau memberikan hidangan yang terlezat bagi orang tercintanya. Pasalnya, menghidangkan masakan yang diolah sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan hidangan tersebut berdasarkan masakan kesukaan famili. 



Mungkinkah anda salah satu penikmat ayam asam manis?. Asal kamu tahu, ayam asam manis merupakan sajian khas di Nusantara yang saat ini disukai oleh setiap orang dari berbagai daerah di Indonesia. Kita dapat menghidangkan ayam asam manis sendiri di rumahmu dan boleh jadi camilan kegemaranmu di hari libur.

Kalian tak perlu bingung jika kamu ingin mendapatkan ayam asam manis, sebab ayam asam manis gampang untuk ditemukan dan juga anda pun bisa mengolahnya sendiri di tempatmu. ayam asam manis boleh diolah lewat beragam cara. Kini pun telah banyak resep modern yang menjadikan ayam asam manis lebih mantap.

Resep ayam asam manis juga sangat mudah dihidangkan, lho. Kalian tidak perlu repot-repot untuk membeli ayam asam manis, lantaran Anda bisa menyiapkan di rumahmu. Bagi Anda yang akan membuatnya, berikut cara membuat ayam asam manis yang lezat yang dapat Kamu coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Ayam Asam Manis:

1. Gunakan 400 gr Dada Ayam tanpa tulang
1. Sediakan 1 butir telur
1. Ambil  Tepung Bumbu Serbaguna
1. Ambil 1/2 Bawang Bombay
1. Ambil 2 siung Bawang Putih
1. Siapkan 1 siung Bawang Merah
1. Sediakan 1 Sdm Saus Tiram
1. Siapkan 3 Sdm Saus Tomat
1. Gunakan 1/2 sdm kecap manis
1. Siapkan  Gula
1. Sediakan  Garam
1. Ambil  Penyedap Rasa
1. Ambil  Lada bubuk
1. Gunakan 1 Gelas Air
1. Ambil  Daun Bawang




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam Asam Manis:

1. Cuci bersih dada ayam, lalu potong-potong sesuai selera
1. Marinasi Dada Ayam dengan garam, lada bubuk dan telur. Diamkan sekitar 15 menit
1. Balurkan dada ayam dengan tepung bumbu serbaguna, lalu goreng hingga matang. Sisihkan.
1. Tumis bawang putih, bawang merah dan bawang bombay hingga harum
1. Masukkan saus tiram, saus tomat, kecap manis dan air. Tambahkan gula, garam, penyedap rasa dan lada bubuk.
1. Masak hingga agak mengental. Matikan api, masukan dada ayam yang sudah di goreng. Aduk rata dan taburi dengan daun bawang.
1. Siap disajikan dengan nasi hangat




Ternyata cara buat ayam asam manis yang lezat sederhana ini gampang banget ya! Kamu semua bisa membuatnya. Cara Membuat ayam asam manis Cocok sekali untuk kamu yang baru belajar memasak maupun untuk kamu yang sudah pandai dalam memasak.

Apakah kamu mau mencoba bikin resep ayam asam manis mantab sederhana ini? Kalau kamu mau, ayo kalian segera buruan siapkan alat-alat dan bahannya, lalu bikin deh Resep ayam asam manis yang nikmat dan sederhana ini. Benar-benar gampang kan. 

Jadi, daripada anda diam saja, hayo kita langsung saja bikin resep ayam asam manis ini. Dijamin kamu tiidak akan nyesel sudah bikin resep ayam asam manis nikmat sederhana ini! Selamat mencoba dengan resep ayam asam manis enak sederhana ini di rumah sendiri,oke!.

