---
description: "Cara membuat Ayam Kentucky yang nikmat dan Mudah Dibuat"
title: "Cara membuat Ayam Kentucky yang nikmat dan Mudah Dibuat"
slug: 55-cara-membuat-ayam-kentucky-yang-nikmat-dan-mudah-dibuat
date: 2021-04-09T12:23:55.946Z
image: https://img-global.cpcdn.com/recipes/15c2f58f3eec49a9/680x482cq70/ayam-kentucky-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/15c2f58f3eec49a9/680x482cq70/ayam-kentucky-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/15c2f58f3eec49a9/680x482cq70/ayam-kentucky-foto-resep-utama.jpg
author: Cory Greer
ratingvalue: 3.6
reviewcount: 6
recipeingredient:
- "6 potong ayam"
- " Bumbu ayam"
- " Ketumbar lada garam sedikit bawang putih semua dihaluskan"
- " Bahan kering "
- "7 sdm Tepung terigu"
- "1/2 bungkus Tepung bumbu ayam kentucky"
- "1/2 sdt Baking soda"
- "1/2 sdt Penyedap"
- " Bahan basah"
- " Tepung bumbu ayam kentucky sisa untuk yg kering td"
- "secukupnya Air"
- " Minyak untuk menggoreng"
recipeinstructions:
- "Cuci ayam, lalu masukkan ayam ke bumbu halus tadi diamkan 7-8 jam"
- "Masuk kan ayam ke dalam adonan basah, lalu masukkan ke adonan kering nya. Diulang 2x"
- "Goreng ayam dengan api paling kecil. Goreng dengan posisi ayam terendam minyak"
- "Tunggu hingga kecoklatan.. Ayam siap untuk disajikan"
categories:
- Resep
tags:
- ayam
- kentucky

katakunci: ayam kentucky 
nutrition: 209 calories
recipecuisine: Indonesian
preptime: "PT32M"
cooktime: "PT41M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Kentucky](https://img-global.cpcdn.com/recipes/15c2f58f3eec49a9/680x482cq70/ayam-kentucky-foto-resep-utama.jpg)

Apabila kamu seorang ibu, menyediakan olahan enak untuk keluarga merupakan suatu hal yang menggembirakan bagi kamu sendiri. Peran seorang istri bukan sekadar mengurus rumah saja, namun kamu pun harus menyediakan kebutuhan nutrisi terpenuhi dan juga hidangan yang disantap orang tercinta wajib nikmat.

Di waktu  sekarang, anda sebenarnya dapat mengorder masakan jadi meski tanpa harus capek memasaknya dahulu. Namun banyak juga lho mereka yang selalu ingin memberikan yang terbaik untuk orang yang dicintainya. Karena, menyajikan masakan yang dibuat sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan makanan tersebut sesuai dengan makanan kesukaan keluarga. 



Mungkinkah anda adalah seorang penikmat ayam kentucky?. Tahukah kamu, ayam kentucky adalah sajian khas di Nusantara yang sekarang disenangi oleh orang-orang di hampir setiap wilayah di Indonesia. Kalian bisa memasak ayam kentucky sendiri di rumah dan dapat dijadikan camilan kesukaanmu di hari liburmu.

Kamu tidak perlu bingung untuk menyantap ayam kentucky, sebab ayam kentucky tidak sukar untuk ditemukan dan juga anda pun bisa mengolahnya sendiri di rumah. ayam kentucky bisa diolah lewat berbagai cara. Kini pun sudah banyak banget resep kekinian yang membuat ayam kentucky semakin lezat.

Resep ayam kentucky juga mudah dihidangkan, lho. Anda tidak usah capek-capek untuk membeli ayam kentucky, sebab Kamu mampu menyiapkan di rumahmu. Untuk Kamu yang ingin menyajikannya, berikut ini cara untuk membuat ayam kentucky yang mantab yang bisa Anda hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Ayam Kentucky:

1. Gunakan 6 potong ayam
1. Gunakan  Bumbu ayam:
1. Ambil  Ketumbar, lada, garam sedikit, bawang putih semua dihaluskan
1. Sediakan  Bahan kering :
1. Gunakan 7 sdm Tepung terigu
1. Siapkan 1/2 bungkus Tepung bumbu ayam kentucky
1. Sediakan 1/2 sdt Baking soda
1. Siapkan 1/2 sdt Penyedap
1. Gunakan  Bahan basah:
1. Ambil  Tepung bumbu ayam kentucky sisa untuk yg kering td
1. Sediakan secukupnya Air
1. Sediakan  Minyak untuk menggoreng




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Kentucky:

1. Cuci ayam, lalu masukkan ayam ke bumbu halus tadi diamkan 7-8 jam
1. Masuk kan ayam ke dalam adonan basah, lalu masukkan ke adonan kering nya. Diulang 2x
1. Goreng ayam dengan api paling kecil. Goreng dengan posisi ayam terendam minyak
1. Tunggu hingga kecoklatan.. Ayam siap untuk disajikan




Wah ternyata cara buat ayam kentucky yang mantab simple ini mudah banget ya! Kita semua dapat membuatnya. Cara Membuat ayam kentucky Sangat cocok banget untuk kita yang baru akan belajar memasak maupun untuk anda yang sudah ahli memasak.

Tertarik untuk mencoba buat resep ayam kentucky enak tidak rumit ini? Kalau kalian mau, mending kamu segera buruan menyiapkan alat dan bahan-bahannya, lantas buat deh Resep ayam kentucky yang mantab dan tidak ribet ini. Benar-benar taidak sulit kan. 

Maka dari itu, daripada anda diam saja, maka kita langsung saja hidangkan resep ayam kentucky ini. Pasti kalian tak akan menyesal sudah bikin resep ayam kentucky lezat tidak ribet ini! Selamat mencoba dengan resep ayam kentucky mantab tidak ribet ini di rumah kalian masing-masing,oke!.

