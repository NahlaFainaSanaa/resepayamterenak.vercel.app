---
description: "Bahan-bahan Soto ayam betawi | soto ayam santan Sederhana Untuk Jualan"
title: "Bahan-bahan Soto ayam betawi | soto ayam santan Sederhana Untuk Jualan"
slug: 387-bahan-bahan-soto-ayam-betawi-soto-ayam-santan-sederhana-untuk-jualan
date: 2021-05-29T23:24:20.499Z
image: https://img-global.cpcdn.com/recipes/ac15ef5cca44d8fd/680x482cq70/soto-ayam-betawi-soto-ayam-santan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ac15ef5cca44d8fd/680x482cq70/soto-ayam-betawi-soto-ayam-santan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ac15ef5cca44d8fd/680x482cq70/soto-ayam-betawi-soto-ayam-santan-foto-resep-utama.jpg
author: Shane Page
ratingvalue: 3.5
reviewcount: 3
recipeingredient:
- "1/2 kg dada ayam"
- "4 buah kentang potong dadu"
- "4 buah tomat merah iris asal"
- " Beberapa batang daun seledri iris tipis"
- " Jeruk limau tambahan"
- " Bawang goreng tambahan"
- " Kerupuk melinjoemping tambahan"
- " Kecap manis tambahan"
- " Bumbu halus "
- "8 buah bawang merah"
- "5 buah bawang putih"
- "Seruas kunyit"
- "1 sendok teh lada"
- "Sedikit pala"
- "1 sendok teh ketumbar"
- "Seruas jahe"
- "5 buah kemiri"
- " Bumbu utuh "
- "1 batang serai geprek"
- "3 lembar daun salam"
- "5 lembar daun jeruk"
- "1 batang kayu manis"
- "Seruas lengkuas geprek"
- "1 buah santan instan"
recipeinstructions:
- "Goreng potongan kentang, lalu sisihkan."
- "Tumis bumbu halus beserta serai, lengkuas, daun salam, daun jeruk. Tumis hingga harum."
- "Masukan air takaran 5 porsi, masukan ayam kedalam kuah dan masak hingga mendidih. Jika sudah mendidih, cemplungkan kayu manis lalu masak hingga ayam empuk."
- "Jika ayam sudah matang dan empuk, angkat lalu goreng ayam sebentar sampai kulit ayam kecoklatan."
- "Tambahkan santan, garam, kaldu bubuk, dan penyedap rasa kedalam kuah. Aduk hingga santan tercampur kuah dan masak hingga matang, lalu matikan kompor (cicip rasa terlebih dahulu)"
- "Siapkan mangkuk, sajikan ayam yg telah di suwir², kentang goreng, tomat, dan daun seledri kedalam mangkuk. Siram kuah kedalam mangkuk, lalu tambahkan perasan jeruk limau, bawang goreng dan kerupuk melinjo dan beri sedikit kecap manis. Soto ayam betawi siap disantap. (sambal bisa dibuat terpisah)"
categories:
- Resep
tags:
- soto
- ayam
- betawi

katakunci: soto ayam betawi 
nutrition: 105 calories
recipecuisine: Indonesian
preptime: "PT37M"
cooktime: "PT59M"
recipeyield: "1"
recipecategory: Dessert

---


![Soto ayam betawi | soto ayam santan](https://img-global.cpcdn.com/recipes/ac15ef5cca44d8fd/680x482cq70/soto-ayam-betawi-soto-ayam-santan-foto-resep-utama.jpg)

Andai kamu seorang ibu, menyediakan hidangan menggugah selera untuk famili merupakan suatu hal yang menggembirakan bagi kamu sendiri. Peran seorang  wanita Tidak hanya menangani rumah saja, namun kamu juga wajib memastikan keperluan nutrisi tercukupi dan juga olahan yang dikonsumsi orang tercinta wajib sedap.

Di zaman  saat ini, kita sebenarnya dapat mengorder panganan praktis tanpa harus repot mengolahnya terlebih dahulu. Namun ada juga lho mereka yang memang ingin menyajikan yang terbaik bagi orang tercintanya. Pasalnya, memasak yang dibuat sendiri akan jauh lebih bersih dan bisa menyesuaikan makanan tersebut berdasarkan kesukaan famili. 



Mungkinkah anda seorang penikmat soto ayam betawi | soto ayam santan?. Tahukah kamu, soto ayam betawi | soto ayam santan merupakan sajian khas di Indonesia yang saat ini digemari oleh orang-orang dari berbagai wilayah di Nusantara. Kalian bisa menghidangkan soto ayam betawi | soto ayam santan sendiri di rumahmu dan boleh jadi makanan kesenanganmu di akhir pekan.

Kalian tidak perlu bingung untuk memakan soto ayam betawi | soto ayam santan, lantaran soto ayam betawi | soto ayam santan mudah untuk ditemukan dan anda pun dapat memasaknya sendiri di tempatmu. soto ayam betawi | soto ayam santan boleh dibuat lewat berbagai cara. Kini pun telah banyak cara kekinian yang menjadikan soto ayam betawi | soto ayam santan lebih enak.

Resep soto ayam betawi | soto ayam santan pun mudah untuk dibuat, lho. Anda tidak usah repot-repot untuk membeli soto ayam betawi | soto ayam santan, tetapi Anda bisa menyiapkan di rumah sendiri. Bagi Kamu yang akan menyajikannya, di bawah ini adalah cara membuat soto ayam betawi | soto ayam santan yang nikamat yang bisa Kita coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Soto ayam betawi | soto ayam santan:

1. Siapkan 1/2 kg dada ayam
1. Gunakan 4 buah kentang (potong dadu)
1. Ambil 4 buah tomat merah (iris asal)
1. Ambil  Beberapa batang daun seledri (iris tipis²)
1. Siapkan  Jeruk limau (tambahan)
1. Siapkan  Bawang goreng (tambahan)
1. Ambil  Kerupuk melinjo/emping (tambahan)
1. Ambil  Kecap manis (tambahan)
1. Gunakan  Bumbu halus :
1. Ambil 8 buah bawang merah
1. Gunakan 5 buah bawang putih
1. Sediakan Seruas kunyit
1. Siapkan 1 sendok teh lada
1. Ambil Sedikit pala
1. Gunakan 1 sendok teh ketumbar
1. Ambil Seruas jahe
1. Sediakan 5 buah kemiri
1. Siapkan  Bumbu utuh :
1. Gunakan 1 batang serai (geprek)
1. Siapkan 3 lembar daun salam
1. Siapkan 5 lembar daun jeruk
1. Siapkan 1 batang kayu manis
1. Gunakan Seruas lengkuas (geprek)
1. Sediakan 1 buah santan instan




<!--inarticleads2-->

##### Langkah-langkah membuat Soto ayam betawi | soto ayam santan:

1. Goreng potongan kentang, lalu sisihkan.
1. Tumis bumbu halus beserta serai, lengkuas, daun salam, daun jeruk. Tumis hingga harum.
1. Masukan air takaran 5 porsi, masukan ayam kedalam kuah dan masak hingga mendidih. Jika sudah mendidih, cemplungkan kayu manis lalu masak hingga ayam empuk.
1. Jika ayam sudah matang dan empuk, angkat lalu goreng ayam sebentar sampai kulit ayam kecoklatan.
1. Tambahkan santan, garam, kaldu bubuk, dan penyedap rasa kedalam kuah. Aduk hingga santan tercampur kuah dan masak hingga matang, lalu matikan kompor (cicip rasa terlebih dahulu)
1. Siapkan mangkuk, sajikan ayam yg telah di suwir², kentang goreng, tomat, dan daun seledri kedalam mangkuk. Siram kuah kedalam mangkuk, lalu tambahkan perasan jeruk limau, bawang goreng dan kerupuk melinjo dan beri sedikit kecap manis. Soto ayam betawi siap disantap. (sambal bisa dibuat terpisah)




Ternyata resep soto ayam betawi | soto ayam santan yang mantab tidak rumit ini mudah banget ya! Kamu semua mampu membuatnya. Cara buat soto ayam betawi | soto ayam santan Sangat cocok sekali untuk anda yang baru akan belajar memasak ataupun bagi anda yang sudah hebat dalam memasak.

Apakah kamu ingin mencoba bikin resep soto ayam betawi | soto ayam santan lezat sederhana ini? Kalau kamu mau, yuk kita segera buruan menyiapkan peralatan dan bahannya, lantas bikin deh Resep soto ayam betawi | soto ayam santan yang mantab dan tidak ribet ini. Sangat gampang kan. 

Maka, ketimbang kalian diam saja, yuk langsung aja buat resep soto ayam betawi | soto ayam santan ini. Pasti kalian tiidak akan menyesal bikin resep soto ayam betawi | soto ayam santan enak tidak ribet ini! Selamat mencoba dengan resep soto ayam betawi | soto ayam santan nikmat sederhana ini di rumah masing-masing,oke!.

