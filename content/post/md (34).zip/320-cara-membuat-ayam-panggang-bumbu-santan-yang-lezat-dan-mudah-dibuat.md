---
description: "Cara membuat Ayam Panggang Bumbu Santan yang lezat dan Mudah Dibuat"
title: "Cara membuat Ayam Panggang Bumbu Santan yang lezat dan Mudah Dibuat"
slug: 320-cara-membuat-ayam-panggang-bumbu-santan-yang-lezat-dan-mudah-dibuat
date: 2021-05-10T03:21:19.388Z
image: https://img-global.cpcdn.com/recipes/51461bafa3306089/680x482cq70/ayam-panggang-bumbu-santan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/51461bafa3306089/680x482cq70/ayam-panggang-bumbu-santan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/51461bafa3306089/680x482cq70/ayam-panggang-bumbu-santan-foto-resep-utama.jpg
author: Kate Burgess
ratingvalue: 3.1
reviewcount: 3
recipeingredient:
- "1/2 ekor ayam bagian paha"
- "1 buah jeruk nipis"
- " Bumbu halus "
- "4 butir bawang merah"
- "3 siung bawang putih"
- "5 cm kunyit"
- "1 ruas lengkuas"
- "1 sdt ketumbar"
- " Bumbu aromatik "
- "2 lembar daun jeruk purut"
- "1 batang serai geprek"
- " Bumbu lainnya "
- "2 sachet santan instan 65 ml"
- "400 ml air"
- "3/4 sdm garam"
- "1/4 sdt gula"
recipeinstructions:
- "Potong ayam menjadi dua bagian, kemudian bersihkan dan kucuri air perasan jeruk nipis. Marinasi selama 15 menit. Bilas."
- "Kemudian haluskan bumbu halus hingga benar-benar halus."
- "Dalam wajan masukkan bumbu halus, bumbu lainnya dan bumbu aromatik. Aduk rata. Masukkan potongan ayam."
- "Masak ayam dengan cara diungkep (dengan menggunakan api kecil hingga bumbu meresap dan kuah menyusut)."
- "Angkat potongan ayam, sisihkan bumbu santannya, kemudian panggang hingga permukaannya kering."
- "Angkat ayam yang sudah dipanggang ke atas piring, kemudian baluri dengan bumbu santan. Sajikan."
categories:
- Resep
tags:
- ayam
- panggang
- bumbu

katakunci: ayam panggang bumbu 
nutrition: 143 calories
recipecuisine: Indonesian
preptime: "PT37M"
cooktime: "PT47M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Panggang Bumbu Santan](https://img-global.cpcdn.com/recipes/51461bafa3306089/680x482cq70/ayam-panggang-bumbu-santan-foto-resep-utama.jpg)

Selaku seorang istri, menyajikan masakan lezat bagi keluarga tercinta merupakan hal yang menggembirakan untuk kita sendiri. Tugas seorang ibu bukan cuman mengurus rumah saja, tapi anda juga wajib memastikan keperluan nutrisi terpenuhi dan juga panganan yang disantap anak-anak mesti nikmat.

Di era  saat ini, kita sebenarnya mampu memesan panganan yang sudah jadi meski tidak harus repot membuatnya lebih dulu. Tetapi banyak juga lho mereka yang selalu mau memberikan hidangan yang terbaik untuk orang yang dicintainya. Pasalnya, menghidangkan masakan yang diolah sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan makanan tersebut sesuai dengan masakan kesukaan famili. 



Apakah anda adalah salah satu penggemar ayam panggang bumbu santan?. Tahukah kamu, ayam panggang bumbu santan merupakan hidangan khas di Nusantara yang saat ini disenangi oleh orang-orang dari hampir setiap wilayah di Indonesia. Kita dapat memasak ayam panggang bumbu santan sendiri di rumahmu dan boleh jadi hidangan kegemaranmu di akhir pekan.

Anda tidak perlu bingung untuk mendapatkan ayam panggang bumbu santan, karena ayam panggang bumbu santan mudah untuk ditemukan dan juga kalian pun bisa mengolahnya sendiri di rumah. ayam panggang bumbu santan dapat diolah lewat beragam cara. Kini pun sudah banyak banget resep kekinian yang menjadikan ayam panggang bumbu santan lebih nikmat.

Resep ayam panggang bumbu santan pun gampang dibikin, lho. Kita tidak usah capek-capek untuk memesan ayam panggang bumbu santan, sebab Kita dapat membuatnya di rumahmu. Untuk Kita yang hendak membuatnya, berikut resep untuk membuat ayam panggang bumbu santan yang enak yang bisa Anda buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Ayam Panggang Bumbu Santan:

1. Gunakan 1/2 ekor ayam bagian paha
1. Siapkan 1 buah jeruk nipis
1. Siapkan  Bumbu halus :
1. Ambil 4 butir bawang merah
1. Ambil 3 siung bawang putih
1. Ambil 5 cm kunyit
1. Gunakan 1 ruas lengkuas
1. Siapkan 1 sdt ketumbar
1. Siapkan  Bumbu aromatik :
1. Gunakan 2 lembar daun jeruk purut
1. Sediakan 1 batang serai, geprek
1. Gunakan  Bumbu lainnya :
1. Gunakan 2 sachet santan instan 65 ml
1. Ambil 400 ml air
1. Sediakan 3/4 sdm garam
1. Sediakan 1/4 sdt gula




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Panggang Bumbu Santan:

1. Potong ayam menjadi dua bagian, kemudian bersihkan dan kucuri air perasan jeruk nipis. Marinasi selama 15 menit. Bilas.
1. Kemudian haluskan bumbu halus hingga benar-benar halus.
1. Dalam wajan masukkan bumbu halus, bumbu lainnya dan bumbu aromatik. Aduk rata. Masukkan potongan ayam.
1. Masak ayam dengan cara diungkep (dengan menggunakan api kecil hingga bumbu meresap dan kuah menyusut).
1. Angkat potongan ayam, sisihkan bumbu santannya, kemudian panggang hingga permukaannya kering.
1. Angkat ayam yang sudah dipanggang ke atas piring, kemudian baluri dengan bumbu santan. Sajikan.




Ternyata cara membuat ayam panggang bumbu santan yang lezat tidak rumit ini enteng sekali ya! Kita semua bisa membuatnya. Cara buat ayam panggang bumbu santan Sangat cocok banget untuk kita yang baru belajar memasak ataupun juga untuk kamu yang telah ahli dalam memasak.

Apakah kamu tertarik mencoba buat resep ayam panggang bumbu santan mantab tidak ribet ini? Kalau kamu tertarik, mending kamu segera buruan siapkan alat-alat dan bahannya, kemudian bikin deh Resep ayam panggang bumbu santan yang enak dan simple ini. Sangat mudah kan. 

Maka, daripada kalian berfikir lama-lama, hayo langsung aja hidangkan resep ayam panggang bumbu santan ini. Dijamin kamu tiidak akan nyesel membuat resep ayam panggang bumbu santan lezat simple ini! Selamat berkreasi dengan resep ayam panggang bumbu santan enak simple ini di tempat tinggal masing-masing,oke!.

