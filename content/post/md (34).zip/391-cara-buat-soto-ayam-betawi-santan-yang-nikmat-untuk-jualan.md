---
description: "Cara buat Soto Ayam Betawi (Santan) yang nikmat Untuk Jualan"
title: "Cara buat Soto Ayam Betawi (Santan) yang nikmat Untuk Jualan"
slug: 391-cara-buat-soto-ayam-betawi-santan-yang-nikmat-untuk-jualan
date: 2021-01-14T16:14:00.652Z
image: https://img-global.cpcdn.com/recipes/454a7dfb7ea035fa/680x482cq70/soto-ayam-betawi-santan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/454a7dfb7ea035fa/680x482cq70/soto-ayam-betawi-santan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/454a7dfb7ea035fa/680x482cq70/soto-ayam-betawi-santan-foto-resep-utama.jpg
author: Lucile Guerrero
ratingvalue: 4.7
reviewcount: 15
recipeingredient:
- "500 gram dada ayam potong"
- "3 buah kentang potong dadu"
- "3 buah tomat merah potong sedang"
- "3-4 jeruk limau"
- " Bawang goreng optional"
- " Emping optional"
- "secukupnya Kecap manis"
- "secukupnya Bihun"
- " Bumbu Halus"
- "9 siung bawang merah"
- "5 siung bawang putih"
- "1 ruas kunyit"
- "1/2 sdt pala"
- "1 sdt ketumbar"
- "1 sdt lada"
- "1 ruas jahe"
- "5 butir kemiri"
- " Bumbu tambahan"
- "1 kotak santan instan"
- "1 batang sereh digeprek"
- "2 lembar daun salam"
- "3 lembar daun jeruk"
- "1 ruas lengkuas digeprek"
- "secukupnya Garam"
- "secukupnya Penyedap rasa"
- " Air"
- "2 batang daun bawang iris"
- " Minyak secukupnya untuk tumis bumbu"
recipeinstructions:
- "Potong ayam dan cuci bersih lalu sisihkan."
- "3 buah kentang potong dadu, cuci bersih lalu sisihkan."
- "Potong bahan lainnya seperti tomat dan daun bawang. Geprek sereh dan lengkuas, sisihkan."
- "Goreng ayam hingga kecoklatan. Jika sudah matang tiriskan, lalu suwir."
- "Goreng kentang hingga matang. Sisihkan."
- "(Disarankan langsung di panci) Ulek bumbu halus. Lalu tumis bumbu dengan minyak secukupnya hingga harum. Masukkan sereh, lengkuas, daun salam, daun jeruk, daun bawang. Jika sudah harum, masukkan air aduk sampai mendidih. Lalu masukkan santan, garam dan penyedap, aduk rata, cek rasa. Jika sudah matang, matikan kompor dan sisihkan."
- "Rebus bihun. Siapkan mangkuk, sajikan ayam yg telah di suwir, bihun, kentang goreng, tomat, bawang goreng, dan emping ke dalam mangkuk. Siram dengan kuah soto lalu tambahkan perasan jeruk limau, dan beri sedikit kecap manis. Selamat menikmati!"
categories:
- Resep
tags:
- soto
- ayam
- betawi

katakunci: soto ayam betawi 
nutrition: 186 calories
recipecuisine: Indonesian
preptime: "PT14M"
cooktime: "PT30M"
recipeyield: "2"
recipecategory: Lunch

---


![Soto Ayam Betawi (Santan)](https://img-global.cpcdn.com/recipes/454a7dfb7ea035fa/680x482cq70/soto-ayam-betawi-santan-foto-resep-utama.jpg)

Sebagai seorang yang hobi masak, mempersiapkan olahan enak bagi orang tercinta merupakan suatu hal yang menyenangkan bagi kita sendiri. Tugas seorang ibu bukan hanya menangani rumah saja, tetapi kamu juga harus memastikan kebutuhan gizi tercukupi dan panganan yang disantap orang tercinta mesti lezat.

Di zaman  saat ini, kalian sebenarnya bisa memesan masakan yang sudah jadi meski tanpa harus ribet memasaknya terlebih dahulu. Tetapi ada juga mereka yang selalu ingin memberikan yang terlezat bagi orang tercintanya. Lantaran, menyajikan masakan yang dibuat sendiri akan jauh lebih bersih dan bisa menyesuaikan masakan tersebut berdasarkan selera keluarga tercinta. 



Apakah anda merupakan salah satu penikmat soto ayam betawi (santan)?. Asal kamu tahu, soto ayam betawi (santan) adalah sajian khas di Indonesia yang kini disenangi oleh orang-orang di berbagai tempat di Nusantara. Kita bisa menyajikan soto ayam betawi (santan) olahan sendiri di rumah dan dapat dijadikan hidangan kesukaanmu di hari libur.

Anda jangan bingung jika kamu ingin menyantap soto ayam betawi (santan), lantaran soto ayam betawi (santan) tidak sukar untuk didapatkan dan juga kita pun bisa memasaknya sendiri di tempatmu. soto ayam betawi (santan) bisa dibuat lewat beragam cara. Kini pun telah banyak resep kekinian yang membuat soto ayam betawi (santan) lebih lezat.

Resep soto ayam betawi (santan) pun sangat mudah dibuat, lho. Anda tidak perlu capek-capek untuk membeli soto ayam betawi (santan), tetapi Kalian bisa membuatnya di rumah sendiri. Untuk Kalian yang hendak mencobanya, dibawah ini merupakan resep menyajikan soto ayam betawi (santan) yang lezat yang bisa Kita coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Soto Ayam Betawi (Santan):

1. Ambil 500 gram dada ayam, potong
1. Ambil 3 buah kentang, potong dadu
1. Siapkan 3 buah tomat merah, potong sedang
1. Ambil 3-4 jeruk limau
1. Ambil  Bawang goreng (optional)
1. Sediakan  Emping (optional)
1. Ambil secukupnya Kecap manis,
1. Sediakan secukupnya Bihun
1. Gunakan  Bumbu Halus
1. Gunakan 9 siung bawang merah
1. Siapkan 5 siung bawang putih
1. Sediakan 1 ruas kunyit
1. Siapkan 1/2 sdt pala
1. Siapkan 1 sdt ketumbar
1. Gunakan 1 sdt lada
1. Siapkan 1 ruas jahe
1. Sediakan 5 butir kemiri
1. Sediakan  Bumbu tambahan
1. Sediakan 1 kotak santan instan
1. Ambil 1 batang sereh (digeprek)
1. Gunakan 2 lembar daun salam
1. Ambil 3 lembar daun jeruk
1. Gunakan 1 ruas lengkuas (digeprek)
1. Ambil secukupnya Garam
1. Ambil secukupnya Penyedap rasa
1. Sediakan  Air
1. Gunakan 2 batang daun bawang, iris
1. Ambil  Minyak secukupnya (untuk tumis bumbu)




<!--inarticleads2-->

##### Cara menyiapkan Soto Ayam Betawi (Santan):

1. Potong ayam dan cuci bersih lalu sisihkan.
1. 3 buah kentang potong dadu, cuci bersih lalu sisihkan.
1. Potong bahan lainnya seperti tomat dan daun bawang. Geprek sereh dan lengkuas, sisihkan.
1. Goreng ayam hingga kecoklatan. Jika sudah matang tiriskan, lalu suwir.
1. Goreng kentang hingga matang. Sisihkan.
1. (Disarankan langsung di panci) Ulek bumbu halus. Lalu tumis bumbu dengan minyak secukupnya hingga harum. Masukkan sereh, lengkuas, daun salam, daun jeruk, daun bawang. Jika sudah harum, masukkan air aduk sampai mendidih. Lalu masukkan santan, garam dan penyedap, aduk rata, cek rasa. Jika sudah matang, matikan kompor dan sisihkan.
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Soto Ayam Betawi (Santan)">1. Rebus bihun. Siapkan mangkuk, sajikan ayam yg telah di suwir, bihun, kentang goreng, tomat, bawang goreng, dan emping ke dalam mangkuk. Siram dengan kuah soto lalu tambahkan perasan jeruk limau, dan beri sedikit kecap manis. Selamat menikmati!




Ternyata resep soto ayam betawi (santan) yang nikamt tidak rumit ini mudah sekali ya! Kamu semua bisa mencobanya. Resep soto ayam betawi (santan) Cocok banget untuk kita yang baru akan belajar memasak maupun juga untuk anda yang sudah pandai memasak.

Apakah kamu mau mulai mencoba buat resep soto ayam betawi (santan) mantab simple ini? Kalau tertarik, ayo kamu segera buruan siapin alat-alat dan bahan-bahannya, kemudian buat deh Resep soto ayam betawi (santan) yang lezat dan simple ini. Betul-betul gampang kan. 

Oleh karena itu, daripada kamu diam saja, hayo kita langsung buat resep soto ayam betawi (santan) ini. Dijamin kamu tak akan menyesal bikin resep soto ayam betawi (santan) lezat sederhana ini! Selamat berkreasi dengan resep soto ayam betawi (santan) nikmat sederhana ini di tempat tinggal sendiri,oke!.

