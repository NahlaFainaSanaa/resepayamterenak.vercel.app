---
description: "Bahan-bahan Ayam Bakar Kecap Bumbu Ungkep yang lezat dan Mudah Dibuat"
title: "Bahan-bahan Ayam Bakar Kecap Bumbu Ungkep yang lezat dan Mudah Dibuat"
slug: 404-bahan-bahan-ayam-bakar-kecap-bumbu-ungkep-yang-lezat-dan-mudah-dibuat
date: 2021-02-06T06:37:51.989Z
image: https://img-global.cpcdn.com/recipes/a8ab73bde100c3b0/680x482cq70/ayam-bakar-kecap-bumbu-ungkep-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a8ab73bde100c3b0/680x482cq70/ayam-bakar-kecap-bumbu-ungkep-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a8ab73bde100c3b0/680x482cq70/ayam-bakar-kecap-bumbu-ungkep-foto-resep-utama.jpg
author: Alma Harris
ratingvalue: 3.1
reviewcount: 13
recipeingredient:
- "1 ekor ayam broiler potong 8"
- "2 sdm cuka apel pengganti jeruk nipis"
- "1 sdt garam"
- "1 sdm margarin"
- "750 ml air sesuaikan hibgga ayam terendam"
- "2 sdm cuka apel boleh diganti air jeniper"
- "2 sdm gula semut aren bisa gula merah iris"
- "1 sdt gatam"
- "1/2 sdt kaldu bubuk ayam"
- " Bumbu Rempah"
- "3 sdm bumbu dasar kuning           lihat resep"
- "2 sdm bumbu dasar merah"
- "1 btg sereh geprek"
- "3 daun salam"
- "4-5 daun jeruk"
- "5-6 kecap manis"
recipeinstructions:
- "Panaskan margarin, masukkan bahan bumbu rempah gula aren dan cuka apel, aduk rata, masak hingga harum"
- "Masukkan sereh, daun salam daun jeruk, kecap manis lalu tambahkan ayam yang sudah di Marinasi dengan garam dan cuka apel selama 15 menit (cuci bersih setelah dimarinasi). Aduk hingga ayam berubah warna."
- "Setelah berubah warna masukkan air, tutup wajan lalu ungkep hingga air menyusut, kalau saya sekalian dipanggang di wajan nya karna pakai teflon. sajikan hangat dengan sambal goreng bawang.           (lihat resep)"
categories:
- Resep
tags:
- ayam
- bakar
- kecap

katakunci: ayam bakar kecap 
nutrition: 235 calories
recipecuisine: Indonesian
preptime: "PT23M"
cooktime: "PT42M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam Bakar Kecap Bumbu Ungkep](https://img-global.cpcdn.com/recipes/a8ab73bde100c3b0/680x482cq70/ayam-bakar-kecap-bumbu-ungkep-foto-resep-utama.jpg)

Andai anda seorang orang tua, mempersiapkan hidangan enak bagi keluarga merupakan suatu hal yang menggembirakan bagi anda sendiri. Kewajiban seorang ibu Tidak sekadar menjaga rumah saja, tetapi kamu juga wajib memastikan kebutuhan nutrisi terpenuhi dan hidangan yang disantap anak-anak harus sedap.

Di zaman  saat ini, anda memang mampu membeli santapan jadi tanpa harus repot mengolahnya terlebih dahulu. Namun banyak juga lho orang yang selalu mau menghidangkan yang terenak untuk keluarganya. Pasalnya, memasak sendiri jauh lebih higienis dan kita pun bisa menyesuaikan hidangan tersebut sesuai masakan kesukaan keluarga tercinta. 



Mungkinkah anda adalah salah satu penyuka ayam bakar kecap bumbu ungkep?. Asal kamu tahu, ayam bakar kecap bumbu ungkep merupakan sajian khas di Indonesia yang saat ini disukai oleh kebanyakan orang di hampir setiap daerah di Indonesia. Kita bisa memasak ayam bakar kecap bumbu ungkep kreasi sendiri di rumah dan boleh jadi makanan kesenanganmu di akhir pekanmu.

Anda tidak usah bingung jika kamu ingin menyantap ayam bakar kecap bumbu ungkep, karena ayam bakar kecap bumbu ungkep sangat mudah untuk ditemukan dan juga kamu pun bisa mengolahnya sendiri di tempatmu. ayam bakar kecap bumbu ungkep bisa dimasak dengan bermacam cara. Kini pun sudah banyak sekali cara kekinian yang menjadikan ayam bakar kecap bumbu ungkep semakin lebih nikmat.

Resep ayam bakar kecap bumbu ungkep juga sangat gampang dibuat, lho. Kamu tidak perlu repot-repot untuk memesan ayam bakar kecap bumbu ungkep, tetapi Anda mampu membuatnya di rumahmu. Untuk Kita yang akan membuatnya, berikut cara membuat ayam bakar kecap bumbu ungkep yang mantab yang mampu Kita buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Ayam Bakar Kecap Bumbu Ungkep:

1. Gunakan 1 ekor ayam broiler, potong 8
1. Siapkan 2 sdm cuka apel (pengganti jeruk nipis)
1. Sediakan 1 sdt garam
1. Sediakan 1 sdm margarin
1. Ambil 750 ml air (sesuaikan hibgga ayam terendam)
1. Siapkan 2 sdm cuka apel (boleh diganti air jeniper)
1. Siapkan 2 sdm gula semut aren (bisa gula merah iris)
1. Ambil 1 sdt gatam
1. Siapkan 1/2 sdt kaldu bubuk ayam
1. Ambil  Bumbu Rempah
1. Ambil 3 sdm bumbu dasar kuning           (lihat resep)
1. Sediakan 2 sdm bumbu dasar merah
1. Ambil 1 btg sereh, geprek
1. Ambil 3 daun salam
1. Siapkan 4-5 daun jeruk
1. Siapkan 5-6 kecap manis




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam Bakar Kecap Bumbu Ungkep:

1. Panaskan margarin, masukkan bahan bumbu rempah gula aren dan cuka apel, aduk rata, masak hingga harum
1. Masukkan sereh, daun salam daun jeruk, kecap manis lalu tambahkan ayam yang sudah di Marinasi dengan garam dan cuka apel selama 15 menit (cuci bersih setelah dimarinasi). Aduk hingga ayam berubah warna.
1. Setelah berubah warna masukkan air, tutup wajan lalu ungkep hingga air menyusut, kalau saya sekalian dipanggang di wajan nya karna pakai teflon. sajikan hangat dengan sambal goreng bawang. -           (lihat resep)




Wah ternyata resep ayam bakar kecap bumbu ungkep yang nikamt tidak rumit ini mudah sekali ya! Kita semua dapat mencobanya. Cara Membuat ayam bakar kecap bumbu ungkep Sangat sesuai banget untuk kamu yang baru akan belajar memasak atau juga untuk kamu yang sudah jago dalam memasak.

Tertarik untuk mencoba bikin resep ayam bakar kecap bumbu ungkep nikmat sederhana ini? Kalau kamu mau, ayo kamu segera siapin alat dan bahan-bahannya, setelah itu bikin deh Resep ayam bakar kecap bumbu ungkep yang lezat dan sederhana ini. Betul-betul mudah kan. 

Jadi, ketimbang kita berfikir lama-lama, ayo kita langsung buat resep ayam bakar kecap bumbu ungkep ini. Pasti anda gak akan nyesel membuat resep ayam bakar kecap bumbu ungkep nikmat tidak rumit ini! Selamat berkreasi dengan resep ayam bakar kecap bumbu ungkep mantab sederhana ini di tempat tinggal masing-masing,ya!.

