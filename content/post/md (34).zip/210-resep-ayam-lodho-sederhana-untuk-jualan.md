---
description: "Resep Ayam Lodho Sederhana Untuk Jualan"
title: "Resep Ayam Lodho Sederhana Untuk Jualan"
slug: 210-resep-ayam-lodho-sederhana-untuk-jualan
date: 2021-06-21T17:02:13.501Z
image: https://img-global.cpcdn.com/recipes/f3919801146d6f71/680x482cq70/ayam-lodho-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f3919801146d6f71/680x482cq70/ayam-lodho-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f3919801146d6f71/680x482cq70/ayam-lodho-foto-resep-utama.jpg
author: Grace Conner
ratingvalue: 5
reviewcount: 10
recipeingredient:
- "1 ekor ayam kampung"
- "2 bks santan instan"
- "Secukupnya air"
- " Bumbu halus"
- "10 siung bawang merah"
- "5 siung bawang putih"
- "1 ruas kunyit"
- "1 ruas jahe"
- "1/2 ruas kencur"
- "1 sdm ketumbar"
- "1 sdt merica"
- "1/2 sdt jintan"
- "6 cabe rawit"
- " Bumbu Cemplung"
- "3 lembar daun salam"
- "3 lembar daun jeruk"
- "2 batang serai"
- "1 ruas lengkuas geprek"
- "15 cabe rawit"
recipeinstructions:
- "Potong ayam kemudian cuci bersih kemudian rebus ayam sampai mendidih atau setengah matang lalu angkat dan tiriskan (jgn buah air kaldu rebusan nya)"
- "Setelah ayam ditiskan, panaskan telfon anti lengket kemudian panggan ayam hingga sedikit berubah warna kecoklatan kemudian angkat dan sisihkan"
- "Siapkan bahan bumbu halus, kemudian tumis dengan sedikit minyak tambahkan daun salam, daun jeruk, serai dan juga lengkuas. Masak hingga bumbu harum dan matang"
- "Masukkan ayam yg sudah dipanggang tadi kedalam panci kaldu ayam, masukkan bumbu yg sudah ditumis tadi kemudian masak hingga air surut dan ayam empuk (jika air surut ayam belum empuk boleh ditambahkan air lagi)"
- "Setelah ayam empuk dan air surut masukkan santan, gula, garam, dan juga kaldu jamur aduk rata kemudian koreksi rasa. Terakhir masukkan cabe rawit danasak hinggae mendidih (aku masak hingga kuahnya tinggal dikit)"
- "Ayam lodho siap dinikmati 😉 untuk yg suka pedas cabe boleh ditambah ya 🤭"
categories:
- Resep
tags:
- ayam
- lodho

katakunci: ayam lodho 
nutrition: 145 calories
recipecuisine: Indonesian
preptime: "PT29M"
cooktime: "PT43M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Lodho](https://img-global.cpcdn.com/recipes/f3919801146d6f71/680x482cq70/ayam-lodho-foto-resep-utama.jpg)

Apabila kamu seorang wanita, menyajikan masakan mantab buat famili merupakan suatu hal yang memuaskan bagi kamu sendiri. Kewajiban seorang  wanita Tidak sekedar menangani rumah saja, namun anda juga wajib menyediakan kebutuhan nutrisi terpenuhi dan juga panganan yang dimakan anak-anak wajib lezat.

Di zaman  saat ini, kalian sebenarnya mampu mengorder santapan siap saji meski tanpa harus repot memasaknya lebih dulu. Tapi banyak juga lho mereka yang memang ingin menyajikan yang terlezat bagi keluarganya. Pasalnya, memasak sendiri jauh lebih bersih dan kita juga bisa menyesuaikan masakan tersebut sesuai masakan kesukaan keluarga. 



Mungkinkah anda salah satu penggemar ayam lodho?. Tahukah kamu, ayam lodho merupakan sajian khas di Nusantara yang saat ini disukai oleh banyak orang di hampir setiap tempat di Indonesia. Anda bisa menghidangkan ayam lodho hasil sendiri di rumah dan pasti jadi santapan kesenanganmu di hari liburmu.

Kalian tidak perlu bingung jika kamu ingin menyantap ayam lodho, sebab ayam lodho mudah untuk dicari dan juga kalian pun bisa membuatnya sendiri di rumah. ayam lodho boleh dimasak dengan bermacam cara. Kini pun sudah banyak sekali cara kekinian yang membuat ayam lodho semakin lebih lezat.

Resep ayam lodho juga mudah sekali dibuat, lho. Kalian tidak usah ribet-ribet untuk memesan ayam lodho, lantaran Kamu dapat menghidangkan ditempatmu. Untuk Kita yang mau membuatnya, di bawah ini adalah cara untuk menyajikan ayam lodho yang nikamat yang dapat Kalian hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Ayam Lodho:

1. Siapkan 1 ekor ayam kampung
1. Sediakan 2 bks santan instan
1. Gunakan Secukupnya air
1. Ambil  Bumbu halus
1. Siapkan 10 siung bawang merah
1. Sediakan 5 siung bawang putih
1. Sediakan 1 ruas kunyit
1. Siapkan 1 ruas jahe
1. Siapkan 1/2 ruas kencur
1. Sediakan 1 sdm ketumbar
1. Siapkan 1 sdt merica
1. Sediakan 1/2 sdt jintan
1. Sediakan 6 cabe rawit
1. Gunakan  Bumbu Cemplung
1. Ambil 3 lembar daun salam
1. Sediakan 3 lembar daun jeruk
1. Sediakan 2 batang serai
1. Siapkan 1 ruas lengkuas geprek
1. Siapkan 15 cabe rawit




<!--inarticleads2-->

##### Cara menyiapkan Ayam Lodho:

1. Potong ayam kemudian cuci bersih kemudian rebus ayam sampai mendidih atau setengah matang lalu angkat dan tiriskan (jgn buah air kaldu rebusan nya)
1. Setelah ayam ditiskan, panaskan telfon anti lengket kemudian panggan ayam hingga sedikit berubah warna kecoklatan kemudian angkat dan sisihkan
1. Siapkan bahan bumbu halus, kemudian tumis dengan sedikit minyak tambahkan daun salam, daun jeruk, serai dan juga lengkuas. Masak hingga bumbu harum dan matang
1. Masukkan ayam yg sudah dipanggang tadi kedalam panci kaldu ayam, masukkan bumbu yg sudah ditumis tadi kemudian masak hingga air surut dan ayam empuk (jika air surut ayam belum empuk boleh ditambahkan air lagi)
1. Setelah ayam empuk dan air surut masukkan santan, gula, garam, dan juga kaldu jamur aduk rata kemudian koreksi rasa. Terakhir masukkan cabe rawit danasak hinggae mendidih (aku masak hingga kuahnya tinggal dikit)
1. Ayam lodho siap dinikmati 😉 untuk yg suka pedas cabe boleh ditambah ya 🤭
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Ayam Lodho">



Wah ternyata cara buat ayam lodho yang enak sederhana ini gampang sekali ya! Semua orang dapat mencobanya. Resep ayam lodho Sesuai banget untuk kamu yang baru belajar memasak ataupun bagi kamu yang telah pandai dalam memasak.

Apakah kamu ingin mulai mencoba membikin resep ayam lodho enak simple ini? Kalau anda tertarik, ayo kalian segera buruan siapkan alat-alat dan bahannya, kemudian bikin deh Resep ayam lodho yang nikmat dan tidak rumit ini. Sungguh taidak sulit kan. 

Jadi, ketimbang kita berlama-lama, yuk kita langsung sajikan resep ayam lodho ini. Dijamin kalian tiidak akan nyesel sudah membuat resep ayam lodho lezat tidak rumit ini! Selamat berkreasi dengan resep ayam lodho enak tidak ribet ini di rumah masing-masing,ya!.

