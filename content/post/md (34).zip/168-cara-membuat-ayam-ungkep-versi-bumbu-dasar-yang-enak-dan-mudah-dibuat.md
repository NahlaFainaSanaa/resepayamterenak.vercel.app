---
description: "Cara membuat Ayam Ungkep Versi Bumbu Dasar yang enak dan Mudah Dibuat"
title: "Cara membuat Ayam Ungkep Versi Bumbu Dasar yang enak dan Mudah Dibuat"
slug: 168-cara-membuat-ayam-ungkep-versi-bumbu-dasar-yang-enak-dan-mudah-dibuat
date: 2021-03-22T00:06:08.134Z
image: https://img-global.cpcdn.com/recipes/b8152492e31346b6/680x482cq70/ayam-ungkep-versi-bumbu-dasar-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b8152492e31346b6/680x482cq70/ayam-ungkep-versi-bumbu-dasar-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b8152492e31346b6/680x482cq70/ayam-ungkep-versi-bumbu-dasar-foto-resep-utama.jpg
author: Bobby Moore
ratingvalue: 3.6
reviewcount: 4
recipeingredient:
- "600 g ayam 7 potong ayam"
- "1/2 buah jeruk nipis utk marinasi ayam"
- " Bumbu ayam ungkep "
- "2 sdm bumbu dasar kuning kurleb 50 g           lihat resep"
- "2 lembar daun jeruk"
- "2 lembar daun salam"
- "1 tangkai serai geprek simpul"
- "1 ruas lengkuas geprek"
- "1 sdt garam"
- "1 sdt kaldu bubuk"
- "300 ml air"
recipeinstructions:
- "Cuci bersih ayam, dan marinasi dg air perasan jeruk nipis selama 10 menit. Setelah luruh lendir2nya, cuci dan tiriskan kembali ayam."
- "Masukkan bumbu dasar kuning dan rempah2/bumbu tambahan lainnya. Tambahkan air. Adukrata dulu."
- "Masukkan ayam, tutup wajan. Ungkep ayam dg api sedang cenderung kecil, selama 30 menit. Di pertengahan memasak, dibolak- balik ayam. Masak hingga bumbu meresap dan ayam empuk. Matikan kompor"
- "Biarkan ayam dingin dulu. Tiriskan dan kemas dlm wadah kedap udara. Simpan dlm kulkas. Sewaktu2 tinggal kita goreng sesuai kebutuhan. Bisa digoreng lalu dibumbu balado merah pake bumbu dasar juga.           (lihat resep)"
categories:
- Resep
tags:
- ayam
- ungkep
- versi

katakunci: ayam ungkep versi 
nutrition: 146 calories
recipecuisine: Indonesian
preptime: "PT40M"
cooktime: "PT37M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam Ungkep Versi Bumbu Dasar](https://img-global.cpcdn.com/recipes/b8152492e31346b6/680x482cq70/ayam-ungkep-versi-bumbu-dasar-foto-resep-utama.jpg)

Andai anda seorang ibu, menyediakan panganan sedap buat famili merupakan suatu hal yang menggembirakan bagi kamu sendiri. Tanggung jawab seorang ibu bukan cuma mengerjakan pekerjaan rumah saja, tapi anda juga harus menyediakan keperluan nutrisi terpenuhi dan juga santapan yang dimakan anak-anak mesti nikmat.

Di zaman  saat ini, kita memang bisa membeli olahan yang sudah jadi meski tidak harus susah mengolahnya lebih dulu. Tetapi banyak juga mereka yang memang ingin memberikan makanan yang terlezat bagi orang tercintanya. Pasalnya, menyajikan masakan yang diolah sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan masakan tersebut sesuai makanan kesukaan keluarga. 



Apakah kamu salah satu penikmat ayam ungkep versi bumbu dasar?. Tahukah kamu, ayam ungkep versi bumbu dasar adalah makanan khas di Nusantara yang sekarang disukai oleh banyak orang di hampir setiap daerah di Nusantara. Kalian bisa menyajikan ayam ungkep versi bumbu dasar kreasi sendiri di rumah dan pasti jadi santapan kesenanganmu di akhir pekan.

Anda tidak perlu bingung untuk menyantap ayam ungkep versi bumbu dasar, sebab ayam ungkep versi bumbu dasar sangat mudah untuk dicari dan kita pun bisa membuatnya sendiri di tempatmu. ayam ungkep versi bumbu dasar bisa diolah dengan bermacam cara. Kini ada banyak cara kekinian yang menjadikan ayam ungkep versi bumbu dasar semakin lebih lezat.

Resep ayam ungkep versi bumbu dasar juga gampang sekali dihidangkan, lho. Kita jangan capek-capek untuk membeli ayam ungkep versi bumbu dasar, lantaran Kalian mampu menghidangkan sendiri di rumah. Untuk Kita yang mau membuatnya, inilah cara untuk menyajikan ayam ungkep versi bumbu dasar yang enak yang dapat Kita hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Ayam Ungkep Versi Bumbu Dasar:

1. Siapkan 600 g ayam (7 potong ayam)
1. Gunakan 1/2 buah jeruk nipis utk marinasi ayam
1. Ambil  ⏩Bumbu ayam ungkep :
1. Sediakan 2 sdm bumbu dasar kuning (=kurleb 50 g)           (lihat resep)
1. Siapkan 2 lembar daun jeruk
1. Gunakan 2 lembar daun salam
1. Gunakan 1 tangkai serai (geprek, simpul)
1. Gunakan 1 ruas lengkuas, geprek
1. Sediakan 1 sdt garam
1. Sediakan 1 sdt kaldu bubuk
1. Gunakan 300 ml air




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam Ungkep Versi Bumbu Dasar:

1. Cuci bersih ayam, dan marinasi dg air perasan jeruk nipis selama 10 menit. Setelah luruh lendir2nya, cuci dan tiriskan kembali ayam.
1. Masukkan bumbu dasar kuning dan rempah2/bumbu tambahan lainnya. Tambahkan air. Adukrata dulu.
1. Masukkan ayam, tutup wajan. Ungkep ayam dg api sedang cenderung kecil, selama 30 menit. Di pertengahan memasak, dibolak- balik ayam. Masak hingga bumbu meresap dan ayam empuk. Matikan kompor
1. Biarkan ayam dingin dulu. Tiriskan dan kemas dlm wadah kedap udara. Simpan dlm kulkas. Sewaktu2 tinggal kita goreng sesuai kebutuhan. Bisa digoreng lalu dibumbu balado merah pake bumbu dasar juga. -           (lihat resep)




Ternyata cara buat ayam ungkep versi bumbu dasar yang nikamt sederhana ini enteng banget ya! Anda Semua mampu mencobanya. Resep ayam ungkep versi bumbu dasar Cocok banget untuk anda yang baru mau belajar memasak maupun juga untuk anda yang sudah jago dalam memasak.

Apakah kamu ingin mulai mencoba bikin resep ayam ungkep versi bumbu dasar lezat tidak ribet ini? Kalau ingin, mending kamu segera siapin alat dan bahannya, kemudian buat deh Resep ayam ungkep versi bumbu dasar yang nikmat dan tidak ribet ini. Sungguh gampang kan. 

Maka, daripada kita berlama-lama, hayo kita langsung buat resep ayam ungkep versi bumbu dasar ini. Pasti kamu tak akan menyesal sudah buat resep ayam ungkep versi bumbu dasar lezat sederhana ini! Selamat berkreasi dengan resep ayam ungkep versi bumbu dasar enak sederhana ini di rumah masing-masing,ya!.

