---
description: "Resep Ceker Mercon / Ceker Setan Sederhana dan Mudah Dibuat"
title: "Resep Ceker Mercon / Ceker Setan Sederhana dan Mudah Dibuat"
slug: 243-resep-ceker-mercon-ceker-setan-sederhana-dan-mudah-dibuat
date: 2021-02-23T15:51:14.334Z
image: https://img-global.cpcdn.com/recipes/04b8639c083549ed/680x482cq70/ceker-mercon-ceker-setan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/04b8639c083549ed/680x482cq70/ceker-mercon-ceker-setan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/04b8639c083549ed/680x482cq70/ceker-mercon-ceker-setan-foto-resep-utama.jpg
author: Ricardo Elliott
ratingvalue: 3.8
reviewcount: 14
recipeingredient:
- "1/2 kg ceker ayam"
- "1 batang sereh geprek"
- "1 ruas lengkuas geprek"
- "2 lembar daun salam"
- "2 lembar daun jeruk purut"
- "1 sdm kecap manis"
- "1 buah tomat potong 4 bagian"
- "1/2 batang bawang prei"
- "Secukupnya gula pasir"
- "Secukupnya garam"
- "Secukupnya kaldu jamur bubuk"
- "Secukupnya lada putih bubuk"
- " Bahan Bumbu Halus "
- "20 buah cabe rawit"
- "5 buah cabe merah besar"
- "3 siung bawang putih"
- "5 siung bawang merah"
- "1 ruas jahe"
recipeinstructions:
- "Cuci bersih ceker ayam lalu rebus di air mendidih sebanyak 2x. Di rebusan kedua, airnya jangan dibuang (jadikan sebagai air kaldu di step terakhir nanti). Tiris dan sisihkan."
- "Tumis bumbu halus, lalu masukkan sereh, lengkuas, daun salam dan daun jeruk purut. Tunggu hingga harum."
- "Kemudian, masukkan ceker ayam dan tuang sisa air rebusan tadi secukupnya saja. Lalu, beri garam, gula pasir, lada putih bubuk, kaldu jamur bubuk, kecap manis, tomat dan bawang prei. Aduk rata, koreksi rasa dan tunggu hingga air kaldunya menyusut."
- "Masakan siap dihidangkan ❤️"
categories:
- Resep
tags:
- ceker
- mercon
- 

katakunci: ceker mercon  
nutrition: 242 calories
recipecuisine: Indonesian
preptime: "PT13M"
cooktime: "PT40M"
recipeyield: "2"
recipecategory: Dessert

---


![Ceker Mercon / Ceker Setan](https://img-global.cpcdn.com/recipes/04b8639c083549ed/680x482cq70/ceker-mercon-ceker-setan-foto-resep-utama.jpg)

Selaku seorang istri, mempersiapkan hidangan menggugah selera kepada keluarga tercinta merupakan suatu hal yang memuaskan bagi anda sendiri. Tugas seorang  wanita Tidak cuman mengerjakan pekerjaan rumah saja, namun anda juga harus menyediakan kebutuhan gizi tercukupi dan masakan yang disantap keluarga tercinta harus mantab.

Di zaman  sekarang, kalian sebenarnya dapat mengorder santapan instan meski tidak harus capek mengolahnya dulu. Tetapi banyak juga lho mereka yang selalu mau menyajikan yang terenak bagi orang yang dicintainya. Karena, memasak sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan masakan tersebut sesuai dengan masakan kesukaan famili. 



Apakah anda seorang penyuka ceker mercon / ceker setan?. Asal kamu tahu, ceker mercon / ceker setan adalah hidangan khas di Indonesia yang sekarang disenangi oleh setiap orang di hampir setiap daerah di Nusantara. Kamu dapat menghidangkan ceker mercon / ceker setan olahan sendiri di rumah dan pasti jadi makanan kesenanganmu di akhir pekan.

Kamu tak perlu bingung jika kamu ingin memakan ceker mercon / ceker setan, lantaran ceker mercon / ceker setan tidak sulit untuk didapatkan dan juga kita pun dapat mengolahnya sendiri di tempatmu. ceker mercon / ceker setan dapat dibuat memalui berbagai cara. Kini pun telah banyak banget resep kekinian yang menjadikan ceker mercon / ceker setan semakin lebih nikmat.

Resep ceker mercon / ceker setan juga mudah sekali untuk dibuat, lho. Kamu tidak perlu repot-repot untuk memesan ceker mercon / ceker setan, tetapi Kamu mampu membuatnya ditempatmu. Untuk Kalian yang hendak menghidangkannya, berikut ini cara untuk membuat ceker mercon / ceker setan yang nikamat yang dapat Kalian coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Ceker Mercon / Ceker Setan:

1. Ambil 1/2 kg ceker ayam
1. Ambil 1 batang sereh, geprek
1. Sediakan 1 ruas lengkuas, geprek
1. Siapkan 2 lembar daun salam
1. Sediakan 2 lembar daun jeruk purut
1. Siapkan 1 sdm kecap manis
1. Ambil 1 buah tomat, potong 4 bagian
1. Siapkan 1/2 batang bawang prei
1. Gunakan Secukupnya gula pasir
1. Sediakan Secukupnya garam
1. Sediakan Secukupnya kaldu jamur bubuk
1. Siapkan Secukupnya lada putih bubuk
1. Ambil  Bahan Bumbu Halus :
1. Gunakan 20 buah cabe rawit
1. Gunakan 5 buah cabe merah besar
1. Siapkan 3 siung bawang putih
1. Gunakan 5 siung bawang merah
1. Siapkan 1 ruas jahe




<!--inarticleads2-->

##### Cara membuat Ceker Mercon / Ceker Setan:

1. Cuci bersih ceker ayam lalu rebus di air mendidih sebanyak 2x. Di rebusan kedua, airnya jangan dibuang (jadikan sebagai air kaldu di step terakhir nanti). Tiris dan sisihkan.
1. Tumis bumbu halus, lalu masukkan sereh, lengkuas, daun salam dan daun jeruk purut. Tunggu hingga harum.
1. Kemudian, masukkan ceker ayam dan tuang sisa air rebusan tadi secukupnya saja. Lalu, beri garam, gula pasir, lada putih bubuk, kaldu jamur bubuk, kecap manis, tomat dan bawang prei. Aduk rata, koreksi rasa dan tunggu hingga air kaldunya menyusut.
1. Masakan siap dihidangkan ❤️




Ternyata cara membuat ceker mercon / ceker setan yang lezat sederhana ini enteng sekali ya! Kalian semua dapat memasaknya. Cara Membuat ceker mercon / ceker setan Cocok banget buat kamu yang baru belajar memasak ataupun juga bagi kamu yang telah hebat dalam memasak.

Tertarik untuk mulai mencoba bikin resep ceker mercon / ceker setan nikmat tidak ribet ini? Kalau ingin, ayo kalian segera siapkan alat-alat dan bahan-bahannya, kemudian bikin deh Resep ceker mercon / ceker setan yang enak dan tidak rumit ini. Betul-betul taidak sulit kan. 

Maka dari itu, ketimbang kalian diam saja, maka langsung aja bikin resep ceker mercon / ceker setan ini. Dijamin kalian tak akan nyesel sudah membuat resep ceker mercon / ceker setan lezat tidak ribet ini! Selamat berkreasi dengan resep ceker mercon / ceker setan enak sederhana ini di rumah kalian sendiri,oke!.

