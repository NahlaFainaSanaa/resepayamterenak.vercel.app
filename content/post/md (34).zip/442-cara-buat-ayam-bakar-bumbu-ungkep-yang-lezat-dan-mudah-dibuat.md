---
description: "Cara buat Ayam Bakar Bumbu Ungkep yang lezat dan Mudah Dibuat"
title: "Cara buat Ayam Bakar Bumbu Ungkep yang lezat dan Mudah Dibuat"
slug: 442-cara-buat-ayam-bakar-bumbu-ungkep-yang-lezat-dan-mudah-dibuat
date: 2021-05-30T00:30:28.681Z
image: https://img-global.cpcdn.com/recipes/b39a063840f04b3c/680x482cq70/ayam-bakar-bumbu-ungkep-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b39a063840f04b3c/680x482cq70/ayam-bakar-bumbu-ungkep-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b39a063840f04b3c/680x482cq70/ayam-bakar-bumbu-ungkep-foto-resep-utama.jpg
author: Josephine Cannon
ratingvalue: 5
reviewcount: 15
recipeingredient:
- "7 potong ayam"
- " Bumbu Ungkep Ayam"
- "2 sdt garam"
- "3 sdt gula"
- "1 sdt merica"
- "3 sdt kaldu jamur bubuk"
- "1 sdt bubuk bawang putih"
- "2 sdt ketumbar bubuk"
- "2 sdt kunyit bubuk"
- "1 sdt jintan bubuk"
- "260 ml air"
- " Bahan Sambal Porsi Besar"
- "13 siung bawang merah"
- "9 siung bawang putih"
- "2 buah tomat"
- "1 buah cabe merah besar"
- "2 buah cabe merah keriting"
- "1 1/2 gengam cabe rawit"
- "2 buah terasi udang"
- "5 buah kemiri"
- "Secukupnya minyak untuk menggoreng"
- " Bumbu Oles Ayam"
- "2 sdm saus sambal"
- "3 sdm kecap manis"
- "3 sdm sambal yg sudah dibuat"
recipeinstructions:
- "Beri bumbu pada ayam, kemudia aduk hingga merata. Masukan air lalu ungkep minimal 30 menit hingga air menyusut."
- "Sambil menunggu ayam, cuci bersih bahan2 sambal, kemudia goreng hingga sedikit lalu. Lalu ulek atau blender hingga halus."
- "Ambil sebagian sambal yg sudah dibuat untuk bahan olesan ayam. Campurkan dengan saus sambal dan kecap manis. Lalu bakar ayam di teflon (bila ada bakaran lebih baik) sambil diolesi dengan saus olesan. Balik hingga bumbu membaluri ayam dan matang. Kemudia angkat dan sajikan."
categories:
- Resep
tags:
- ayam
- bakar
- bumbu

katakunci: ayam bakar bumbu 
nutrition: 163 calories
recipecuisine: Indonesian
preptime: "PT33M"
cooktime: "PT50M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam Bakar Bumbu Ungkep](https://img-global.cpcdn.com/recipes/b39a063840f04b3c/680x482cq70/ayam-bakar-bumbu-ungkep-foto-resep-utama.jpg)

Selaku seorang orang tua, menyediakan masakan mantab kepada orang tercinta merupakan hal yang menggembirakan untuk kamu sendiri. Tugas seorang istri Tidak cuma mengerjakan pekerjaan rumah saja, tapi kamu juga wajib menyediakan keperluan gizi tercukupi dan juga santapan yang disantap orang tercinta wajib menggugah selera.

Di masa  saat ini, kalian sebenarnya mampu mengorder santapan yang sudah jadi tanpa harus capek membuatnya lebih dulu. Tetapi ada juga lho orang yang memang mau menyajikan yang terenak bagi keluarganya. Lantaran, menyajikan masakan yang dibuat sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan makanan tersebut sesuai makanan kesukaan keluarga tercinta. 



Mungkinkah kamu seorang penggemar ayam bakar bumbu ungkep?. Asal kamu tahu, ayam bakar bumbu ungkep adalah hidangan khas di Nusantara yang saat ini digemari oleh kebanyakan orang dari berbagai daerah di Indonesia. Kalian dapat menghidangkan ayam bakar bumbu ungkep sendiri di rumah dan boleh dijadikan camilan kesenanganmu di hari liburmu.

Anda tidak perlu bingung untuk menyantap ayam bakar bumbu ungkep, sebab ayam bakar bumbu ungkep mudah untuk ditemukan dan kita pun bisa membuatnya sendiri di rumah. ayam bakar bumbu ungkep bisa dimasak lewat berbagai cara. Saat ini sudah banyak sekali cara modern yang menjadikan ayam bakar bumbu ungkep lebih mantap.

Resep ayam bakar bumbu ungkep pun mudah sekali dibikin, lho. Kalian tidak usah ribet-ribet untuk memesan ayam bakar bumbu ungkep, sebab Kalian mampu membuatnya di rumah sendiri. Bagi Kamu yang ingin membuatnya, berikut ini cara membuat ayam bakar bumbu ungkep yang lezat yang mampu Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Ayam Bakar Bumbu Ungkep:

1. Sediakan 7 potong ayam
1. Siapkan  Bumbu Ungkep Ayam
1. Sediakan 2 sdt garam
1. Sediakan 3 sdt gula
1. Gunakan 1 sdt merica
1. Siapkan 3 sdt kaldu jamur bubuk
1. Siapkan 1 sdt bubuk bawang putih
1. Siapkan 2 sdt ketumbar bubuk
1. Siapkan 2 sdt kunyit bubuk
1. Sediakan 1 sdt jintan bubuk
1. Sediakan 260 ml air
1. Sediakan  Bahan Sambal (Porsi Besar)
1. Ambil 13 siung bawang merah
1. Ambil 9 siung bawang putih
1. Siapkan 2 buah tomat
1. Gunakan 1 buah cabe merah besar
1. Gunakan 2 buah cabe merah keriting
1. Sediakan 1 1/2 gengam cabe rawit
1. Siapkan 2 buah terasi udang
1. Siapkan 5 buah kemiri
1. Gunakan Secukupnya minyak untuk menggoreng
1. Sediakan  Bumbu Oles Ayam
1. Gunakan 2 sdm saus sambal
1. Gunakan 3 sdm kecap manis
1. Siapkan 3 sdm sambal yg sudah dibuat




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam Bakar Bumbu Ungkep:

1. Beri bumbu pada ayam, kemudia aduk hingga merata. Masukan air lalu ungkep minimal 30 menit hingga air menyusut.
1. Sambil menunggu ayam, cuci bersih bahan2 sambal, kemudia goreng hingga sedikit lalu. Lalu ulek atau blender hingga halus.
1. Ambil sebagian sambal yg sudah dibuat untuk bahan olesan ayam. Campurkan dengan saus sambal dan kecap manis. Lalu bakar ayam di teflon (bila ada bakaran lebih baik) sambil diolesi dengan saus olesan. Balik hingga bumbu membaluri ayam dan matang. Kemudia angkat dan sajikan.




Wah ternyata cara membuat ayam bakar bumbu ungkep yang nikamt simple ini mudah sekali ya! Kamu semua bisa mencobanya. Cara buat ayam bakar bumbu ungkep Sangat cocok sekali buat kalian yang sedang belajar memasak ataupun juga untuk kalian yang telah jago memasak.

Tertarik untuk mulai mencoba membikin resep ayam bakar bumbu ungkep lezat tidak ribet ini? Kalau kalian mau, ayo kamu segera buruan siapkan alat dan bahannya, kemudian buat deh Resep ayam bakar bumbu ungkep yang lezat dan simple ini. Betul-betul mudah kan. 

Jadi, daripada kita berfikir lama-lama, yuk kita langsung sajikan resep ayam bakar bumbu ungkep ini. Pasti kalian tak akan nyesel sudah membuat resep ayam bakar bumbu ungkep mantab sederhana ini! Selamat berkreasi dengan resep ayam bakar bumbu ungkep nikmat simple ini di rumah sendiri,oke!.

