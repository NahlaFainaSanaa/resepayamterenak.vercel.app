---
description: "Resep Soto Ayam yang lezat dan Mudah Dibuat"
title: "Resep Soto Ayam yang lezat dan Mudah Dibuat"
slug: 181-resep-soto-ayam-yang-lezat-dan-mudah-dibuat
date: 2021-04-03T21:29:47.388Z
image: https://img-global.cpcdn.com/recipes/c057821a450601b0/680x482cq70/soto-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c057821a450601b0/680x482cq70/soto-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c057821a450601b0/680x482cq70/soto-ayam-foto-resep-utama.jpg
author: Marguerite Watkins
ratingvalue: 3.7
reviewcount: 3
recipeingredient:
- "1 kg dada ayam"
- "2 liter air"
- "3 sdm minyak goreng untuk tumis"
- "secukupnya garam  lada"
- "sedikit gula"
- "secukupnya kaldu ayam optional"
- " Bumbu A"
- "3 batang serai putihny saja memarkan"
- "6 lembar daun jeruk purut buang tulangnya iris tipis daunnya"
- "1-1,5 sdm kunyit bubuk"
- " Bumbu halus"
- "10 bj bawang merah"
- "5 bj bawang putih"
- "4 bj kemiri Sangrai"
- "3 cm jahe"
- " Pelengkap"
- "1 buah kentang size sedang iris tipis goreng"
- "1/4 buah kembang kol iris tipis"
- "2 genggam mie bihun rendam di air panas hingga lemas"
- "Sedikit irisan bawang merah goreng"
- "Sedikit perasan jeruk nipis"
- "iris Telur rebus"
recipeinstructions:
- "Rebus 5 buah telur hingga matang. Sisihkan."
- "Cuci ayam hingga bersih. Sisihkan."
- "Rebusan ayam: Didihkan air, masukkan ayam. Masak dengan api kecil hingga keluar kaldunya, buang busanya."
- "Tumisan bumbu: Panaskan minyak goreng, tumis bumbu halus + bumbu A hingga harum. Matikan kompor."
- "Masukkan tumisan bumbu ke dalam rebusan ayam, tambahkan sesuai selera garam, lada, gula, kaldu bubuk. Masak hingga ayam empuk."
- "Jika ayam sudah empuk, panaskan minyak goreng, goreng ayam hingga kecoklatan, angkat, lalu suir."
- "Tata soto dalam mangkuk: Bihun + kol + telur rebus + ayam suir + kentang, lalu siram dengan kuah yg panas (hati-hati), beri bawang merah goreng + sedikit perasan jeruk nipis🤤🤤. Sajikan."
- "Photo hanya saran penyajian, ditambah sedikit irisan tomat dan daun bawang (warnanya tambah cakep)🤩"
categories:
- Resep
tags:
- soto
- ayam

katakunci: soto ayam 
nutrition: 194 calories
recipecuisine: Indonesian
preptime: "PT37M"
cooktime: "PT54M"
recipeyield: "4"
recipecategory: Dinner

---


![Soto Ayam](https://img-global.cpcdn.com/recipes/c057821a450601b0/680x482cq70/soto-ayam-foto-resep-utama.jpg)

Selaku seorang ibu, menyajikan masakan enak kepada keluarga merupakan hal yang mengasyikan bagi kamu sendiri. Tugas seorang ibu Tidak saja menangani rumah saja, tetapi kamu pun wajib menyediakan kebutuhan nutrisi terpenuhi dan masakan yang dimakan keluarga tercinta wajib lezat.

Di era  sekarang, kamu memang dapat memesan hidangan yang sudah jadi tidak harus ribet mengolahnya lebih dulu. Tetapi banyak juga orang yang memang mau memberikan hidangan yang terbaik untuk orang tercintanya. Pasalnya, menghidangkan masakan sendiri jauh lebih bersih dan kita juga bisa menyesuaikan makanan tersebut berdasarkan makanan kesukaan famili. 



Apakah kamu salah satu penyuka soto ayam?. Asal kamu tahu, soto ayam merupakan hidangan khas di Indonesia yang kini disenangi oleh orang-orang dari berbagai tempat di Indonesia. Kalian bisa memasak soto ayam hasil sendiri di rumah dan boleh dijadikan hidangan favorit di hari liburmu.

Kamu tidak usah bingung jika kamu ingin mendapatkan soto ayam, sebab soto ayam tidak sulit untuk didapatkan dan juga kalian pun dapat membuatnya sendiri di rumah. soto ayam bisa dibuat dengan beragam cara. Sekarang ada banyak banget cara modern yang menjadikan soto ayam semakin lebih enak.

Resep soto ayam pun mudah sekali dihidangkan, lho. Kalian tidak perlu capek-capek untuk membeli soto ayam, lantaran Kamu bisa menyajikan di rumah sendiri. Untuk Kita yang mau menghidangkannya, dibawah ini merupakan resep membuat soto ayam yang nikamat yang mampu Kita coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Soto Ayam:

1. Siapkan 1 kg dada ayam
1. Gunakan 2 liter air
1. Sediakan 3 sdm minyak goreng untuk tumis
1. Ambil secukupnya garam &amp; lada
1. Ambil sedikit gula
1. Siapkan secukupnya kaldu ayam (optional)
1. Ambil  Bumbu A:
1. Gunakan 3 batang serai, putihny saja, memarkan
1. Sediakan 6 lembar daun jeruk purut, buang tulangnya, iris tipis daunnya
1. Gunakan 1-1,5 sdm kunyit bubuk
1. Ambil  Bumbu halus:
1. Ambil 10 bj bawang merah
1. Ambil 5 bj bawang putih
1. Ambil 4 bj kemiri Sangrai
1. Gunakan 3 cm jahe
1. Ambil  Pelengkap:
1. Siapkan 1 buah kentang size sedang, iris tipis, goreng
1. Gunakan 1/4 buah kembang kol, iris tipis
1. Sediakan 2 genggam mie bihun, rendam di air panas hingga lemas
1. Sediakan Sedikit irisan bawang merah goreng
1. Gunakan Sedikit perasan jeruk nipis
1. Ambil iris Telur rebus,




<!--inarticleads2-->

##### Langkah-langkah membuat Soto Ayam:

1. Rebus 5 buah telur hingga matang. Sisihkan.
1. Cuci ayam hingga bersih. Sisihkan.
1. Rebusan ayam: - Didihkan air, masukkan ayam. Masak dengan api kecil hingga keluar kaldunya, buang busanya.
1. Tumisan bumbu: - Panaskan minyak goreng, tumis bumbu halus + bumbu A hingga harum. Matikan kompor.
1. Masukkan tumisan bumbu ke dalam rebusan ayam, tambahkan sesuai selera garam, lada, gula, kaldu bubuk. Masak hingga ayam empuk.
1. Jika ayam sudah empuk, panaskan minyak goreng, goreng ayam hingga kecoklatan, angkat, lalu suir.
1. Tata soto dalam mangkuk: - Bihun + kol + telur rebus + ayam suir + kentang, lalu siram dengan kuah yg panas (hati-hati), beri bawang merah goreng + sedikit perasan jeruk nipis🤤🤤. Sajikan.
1. Photo hanya saran penyajian, ditambah sedikit irisan tomat dan daun bawang (warnanya tambah cakep)🤩




Wah ternyata resep soto ayam yang mantab tidak rumit ini enteng banget ya! Semua orang dapat membuatnya. Cara buat soto ayam Cocok sekali buat kalian yang baru belajar memasak maupun juga bagi kalian yang telah lihai memasak.

Tertarik untuk mencoba buat resep soto ayam nikmat simple ini? Kalau kalian mau, yuk kita segera menyiapkan alat-alat dan bahan-bahannya, setelah itu buat deh Resep soto ayam yang mantab dan simple ini. Sangat taidak sulit kan. 

Jadi, daripada kalian diam saja, yuk kita langsung saja bikin resep soto ayam ini. Pasti kalian tak akan nyesel sudah bikin resep soto ayam mantab tidak rumit ini! Selamat mencoba dengan resep soto ayam enak simple ini di tempat tinggal kalian masing-masing,ya!.

