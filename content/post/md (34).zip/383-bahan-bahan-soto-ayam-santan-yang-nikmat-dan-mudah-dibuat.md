---
description: "Bahan-bahan Soto Ayam Santan yang nikmat dan Mudah Dibuat"
title: "Bahan-bahan Soto Ayam Santan yang nikmat dan Mudah Dibuat"
slug: 383-bahan-bahan-soto-ayam-santan-yang-nikmat-dan-mudah-dibuat
date: 2021-06-08T19:48:59.860Z
image: https://img-global.cpcdn.com/recipes/f89c1bb7e2b851b3/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f89c1bb7e2b851b3/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f89c1bb7e2b851b3/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg
author: Mayme Santiago
ratingvalue: 3.5
reviewcount: 3
recipeingredient:
- "1/4 kg Dada Ayam"
- "1500 ml Air"
- "1 btg Serai memarkan"
- "2 cm Lengkuas memarkan"
- "3 lbr Daun Jeruk"
- "1 bks Santan Instan"
- "1/4 sdt Lada bubuk"
- "Secukupnya Bawang Goreng"
- "Secukupnya Garam Gula dan Kaldu Bubuk"
- " Cengkeh Kapulaga Bunga Lawang untuk wewangian bisa di skip"
- " bumbu halus"
- "7 bh Bawang merah"
- "5 bh Bawang Putih"
- "4 btr Kemiri"
- "2 cm Kunyit"
- "2 cm Jahe"
- "Secukupnya Minyak Goreng"
recipeinstructions:
- "Cuci bersih semua bahan"
- "Rebus ayam hingga empuk dan keluar kaldunya"
- "Tumis bumbu halus hingga wangi. Tambahkan serai, lengkuas, daun jeruk dan lada bubuk, aduk hingga rata kemudian sisihkan"
- "Masukkan bumbu yang sudah ditumis kedalam rebusan ayam, kemudian tambahkan garam, gula dan kaldu bubuk. Aduk hingga rata"
- "Koreksi rasa dan masak sekitar 15 menit dengan api kecil hingga bumbu meresap"
- "Angkat daging ayam, kemudian masukkan santan, aduk hingga rata dan tambahkan cengkeh, kapulaga dan bunga lawang (bisa di skip)"
- "Goreng ayam yang sudah di tiriskan, jangan terlalu kering, kemudian di suwir suwir"
- "Taburkan bawang goreng kedalam kuah soto yang telah matang. Soto ayam santan, siap dihidangkan!"
categories:
- Resep
tags:
- soto
- ayam
- santan

katakunci: soto ayam santan 
nutrition: 243 calories
recipecuisine: Indonesian
preptime: "PT17M"
cooktime: "PT45M"
recipeyield: "3"
recipecategory: Dessert

---


![Soto Ayam Santan](https://img-global.cpcdn.com/recipes/f89c1bb7e2b851b3/680x482cq70/soto-ayam-santan-foto-resep-utama.jpg)

Sebagai seorang wanita, menyuguhkan olahan menggugah selera untuk orang tercinta merupakan suatu hal yang sangat menyenangkan bagi kamu sendiri. Tanggung jawab seorang  wanita Tidak saja menjaga rumah saja, tetapi kamu juga harus menyediakan kebutuhan nutrisi terpenuhi dan hidangan yang dikonsumsi orang tercinta mesti enak.

Di waktu  sekarang, anda sebenarnya dapat mengorder panganan jadi meski tidak harus ribet mengolahnya lebih dulu. Tapi ada juga lho mereka yang selalu ingin memberikan hidangan yang terlezat bagi keluarganya. Lantaran, menyajikan masakan yang dibuat sendiri jauh lebih higienis dan kita pun bisa menyesuaikan hidangan tersebut sesuai makanan kesukaan famili. 



Mungkinkah anda merupakan seorang penikmat soto ayam santan?. Tahukah kamu, soto ayam santan adalah sajian khas di Indonesia yang kini disenangi oleh banyak orang di hampir setiap tempat di Nusantara. Kalian bisa membuat soto ayam santan olahan sendiri di rumah dan boleh dijadikan hidangan favorit di akhir pekan.

Kamu tidak usah bingung untuk memakan soto ayam santan, sebab soto ayam santan sangat mudah untuk ditemukan dan anda pun bisa membuatnya sendiri di tempatmu. soto ayam santan boleh diolah memalui berbagai cara. Kini pun telah banyak sekali cara kekinian yang menjadikan soto ayam santan semakin lebih mantap.

Resep soto ayam santan juga gampang sekali dihidangkan, lho. Kita tidak perlu capek-capek untuk membeli soto ayam santan, sebab Kita bisa membuatnya ditempatmu. Bagi Kalian yang ingin membuatnya, di bawah ini adalah resep membuat soto ayam santan yang enak yang mampu Kita buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Soto Ayam Santan:

1. Siapkan 1/4 kg Dada Ayam
1. Sediakan 1500 ml Air
1. Gunakan 1 btg Serai (memarkan)
1. Ambil 2 cm Lengkuas (memarkan)
1. Ambil 3 lbr Daun Jeruk
1. Sediakan 1 bks Santan Instan
1. Gunakan 1/4 sdt Lada bubuk
1. Gunakan Secukupnya Bawang Goreng
1. Ambil Secukupnya Garam, Gula dan Kaldu Bubuk
1. Siapkan  Cengkeh, Kapulaga, Bunga Lawang (untuk wewangian, bisa di skip)
1. Gunakan  bumbu halus
1. Siapkan 7 bh Bawang merah
1. Gunakan 5 bh Bawang Putih
1. Siapkan 4 btr Kemiri
1. Siapkan 2 cm Kunyit
1. Ambil 2 cm Jahe
1. Sediakan Secukupnya Minyak Goreng




<!--inarticleads2-->

##### Cara membuat Soto Ayam Santan:

1. Cuci bersih semua bahan
1. Rebus ayam hingga empuk dan keluar kaldunya
1. Tumis bumbu halus hingga wangi. Tambahkan serai, lengkuas, daun jeruk dan lada bubuk, aduk hingga rata kemudian sisihkan
1. Masukkan bumbu yang sudah ditumis kedalam rebusan ayam, kemudian tambahkan garam, gula dan kaldu bubuk. Aduk hingga rata
1. Koreksi rasa dan masak sekitar 15 menit dengan api kecil hingga bumbu meresap
1. Angkat daging ayam, kemudian masukkan santan, aduk hingga rata dan tambahkan cengkeh, kapulaga dan bunga lawang (bisa di skip)
1. Goreng ayam yang sudah di tiriskan, jangan terlalu kering, kemudian di suwir suwir
1. Taburkan bawang goreng kedalam kuah soto yang telah matang. - Soto ayam santan, siap dihidangkan!




Wah ternyata resep soto ayam santan yang mantab tidak rumit ini mudah banget ya! Anda Semua dapat membuatnya. Cara Membuat soto ayam santan Sangat cocok sekali buat kita yang baru akan belajar memasak atau juga untuk anda yang telah hebat memasak.

Tertarik untuk mencoba membuat resep soto ayam santan lezat simple ini? Kalau anda tertarik, yuk kita segera buruan menyiapkan alat-alat dan bahan-bahannya, kemudian buat deh Resep soto ayam santan yang mantab dan tidak ribet ini. Sangat mudah kan. 

Oleh karena itu, ketimbang anda diam saja, hayo kita langsung hidangkan resep soto ayam santan ini. Pasti kamu gak akan nyesel sudah buat resep soto ayam santan mantab tidak ribet ini! Selamat mencoba dengan resep soto ayam santan mantab tidak rumit ini di rumah kalian sendiri,ya!.

