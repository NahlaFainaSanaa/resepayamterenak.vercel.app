---
description: "Cara membuat Ayam Goreng Kremes yang enak Untuk Jualan"
title: "Cara membuat Ayam Goreng Kremes yang enak Untuk Jualan"
slug: 39-cara-membuat-ayam-goreng-kremes-yang-enak-untuk-jualan
date: 2021-03-19T10:26:15.721Z
image: https://img-global.cpcdn.com/recipes/4fb81f11ba22ac2d/680x482cq70/ayam-goreng-kremes-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4fb81f11ba22ac2d/680x482cq70/ayam-goreng-kremes-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4fb81f11ba22ac2d/680x482cq70/ayam-goreng-kremes-foto-resep-utama.jpg
author: Louis Peterson
ratingvalue: 3.5
reviewcount: 5
recipeingredient:
- "500 gr ayam bagian paha potong jadi beberapa bagian marinasi dengan air jeruk nipis dan secukupnya garam Diamkan 15 menit Bilas kembali"
- "250 gr kelapa parut yang tua"
- "350 ml air"
- "2 lembar daun salam"
- "1 batang serai digeprek"
- "Secukupnya garam dan royco ayam"
- "Secukupnya minyak goreng"
- " Bumbu Halus"
- "6 siung bawang merah"
- "3 siung bawang putih"
- "3 buah kemiri"
- "1 ruas kunyit"
- "1/2 sdm ketumbar"
- " Bahan Kremes"
- "300 ml air rebusan ayam"
- "125 gr tepung tapioka boleh pakai tepung sagu tani"
- "40 gr tepung beras"
- "1 butir telur"
- "1/2 sdt baking powder"
recipeinstructions:
- "Siapkan bahan yang akan digunakan"
- "Tuangkan semua air ke kelapa parut, lalu remas-remas agar santan kelapa keluar, lalu saring dan peras. Hasil santan yang diperoleh kurang lebih 450 ml. Kemudian haluskan bumbu menggunakan blender dengan menambahkan sedikit air."
- "Siapkan wajan, masukkan bumbu halus, daun salam, serai dan santan. Lalu tambahkan secukupnya garam dan royco, masak hingga mendidih sambil terus diaduk agar santan tidak pecah. Koreksi rasa."
- "Masukkan ayam, masak hingga ayam matang dan bumbu meresap dengan api kecil. Sisakan air rebusan ayam kira-kira 300 ml. Sesekali diaduk-aduk dalam proses memasaknya"
- "Angkat/keluarkan ayam, lalu saring air sisa rebusan ayam tadi."
- "Siapkan bahan yang akan dilakukan untuk membuat kremes. Lalu campurkan semua bahan kecuali Baking Powder. Aduk-aduk sebentar lalu saring adonan kremes agar tidak ada lagi tepung yang menggerindil/bulat-bulat kecil"
- "Panaskan secukupnya minyak goreng. Celupkan ayam ke dalam adonan kremes, balurkan hingga mereta. Kemudian goreng ayam hingga berwarna golden brown. Angkat dan tiriskan"
- "Cara membuat kremes: Tambahkan baking powder pada sisa adonan kremes. Aduk hingga tercampur rata. (Note: Baking Powder dimasukkan sesaat sebelum adonan kremes digoreng)"
- "Panaskan minyak goreng (pastikan minyak goreng sudah benar-benar panas). Lalu ambil adonan dengan tangan, kucurkan adonan dengan bantuan jari tangan dengan gerakan berputar di atas wajan. Ketika mulai kokoh balik adonan, terus goreng sampai kecokelatan, angkat dan tiriskan."
- "Sajikan ayam goreng dengan kremesan dan sambal. Enjoy... 😊"
categories:
- Resep
tags:
- ayam
- goreng
- kremes

katakunci: ayam goreng kremes 
nutrition: 299 calories
recipecuisine: Indonesian
preptime: "PT26M"
cooktime: "PT32M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Goreng Kremes](https://img-global.cpcdn.com/recipes/4fb81f11ba22ac2d/680x482cq70/ayam-goreng-kremes-foto-resep-utama.jpg)

Sebagai seorang orang tua, menyediakan hidangan nikmat buat orang tercinta adalah suatu hal yang sangat menyenangkan bagi kamu sendiri. Tanggung jawab seorang istri bukan hanya menangani rumah saja, tetapi kamu juga harus menyediakan keperluan gizi terpenuhi dan juga masakan yang dimakan keluarga tercinta wajib sedap.

Di era  saat ini, kamu sebenarnya bisa mengorder olahan instan walaupun tanpa harus susah membuatnya dulu. Namun banyak juga mereka yang selalu ingin memberikan hidangan yang terbaik untuk orang yang dicintainya. Karena, menyajikan masakan yang diolah sendiri akan jauh lebih bersih dan bisa menyesuaikan masakan tersebut sesuai kesukaan keluarga tercinta. 



Apakah anda salah satu penikmat ayam goreng kremes?. Asal kamu tahu, ayam goreng kremes merupakan hidangan khas di Nusantara yang saat ini disenangi oleh setiap orang dari hampir setiap daerah di Nusantara. Kita dapat memasak ayam goreng kremes sendiri di rumahmu dan boleh dijadikan santapan kegemaranmu di hari libur.

Kamu tak perlu bingung jika kamu ingin memakan ayam goreng kremes, lantaran ayam goreng kremes tidak sukar untuk didapatkan dan kamu pun bisa menghidangkannya sendiri di rumah. ayam goreng kremes boleh dibuat dengan bermacam cara. Kini sudah banyak banget resep modern yang menjadikan ayam goreng kremes lebih lezat.

Resep ayam goreng kremes pun mudah sekali dibuat, lho. Anda tidak perlu capek-capek untuk membeli ayam goreng kremes, lantaran Kalian bisa menyajikan ditempatmu. Untuk Kamu yang akan menyajikannya, berikut resep untuk membuat ayam goreng kremes yang nikamat yang dapat Kalian coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Ayam Goreng Kremes:

1. Gunakan 500 gr ayam bagian paha, potong jadi beberapa bagian, marinasi dengan air jeruk nipis dan secukupnya garam. Diamkan 15 menit. Bilas kembali
1. Sediakan 250 gr kelapa parut yang tua
1. Sediakan 350 ml air
1. Siapkan 2 lembar daun salam
1. Ambil 1 batang serai, digeprek
1. Ambil Secukupnya garam dan royco ayam
1. Siapkan Secukupnya minyak goreng
1. Ambil  Bumbu Halus:
1. Siapkan 6 siung bawang merah
1. Siapkan 3 siung bawang putih
1. Sediakan 3 buah kemiri
1. Gunakan 1 ruas kunyit
1. Siapkan 1/2 sdm ketumbar
1. Sediakan  Bahan Kremes:
1. Ambil 300 ml air rebusan ayam
1. Sediakan 125 gr tepung tapioka (boleh pakai tepung sagu tani)
1. Siapkan 40 gr tepung beras
1. Siapkan 1 butir telur
1. Ambil 1/2 sdt baking powder




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam Goreng Kremes:

1. Siapkan bahan yang akan digunakan
1. Tuangkan semua air ke kelapa parut, lalu remas-remas agar santan kelapa keluar, lalu saring dan peras. Hasil santan yang diperoleh kurang lebih 450 ml. Kemudian haluskan bumbu menggunakan blender dengan menambahkan sedikit air.
1. Siapkan wajan, masukkan bumbu halus, daun salam, serai dan santan. Lalu tambahkan secukupnya garam dan royco, masak hingga mendidih sambil terus diaduk agar santan tidak pecah. Koreksi rasa.
1. Masukkan ayam, masak hingga ayam matang dan bumbu meresap dengan api kecil. Sisakan air rebusan ayam kira-kira 300 ml. Sesekali diaduk-aduk dalam proses memasaknya
1. Angkat/keluarkan ayam, lalu saring air sisa rebusan ayam tadi.
1. Siapkan bahan yang akan dilakukan untuk membuat kremes. Lalu campurkan semua bahan kecuali Baking Powder. Aduk-aduk sebentar lalu saring adonan kremes agar tidak ada lagi tepung yang menggerindil/bulat-bulat kecil
1. Panaskan secukupnya minyak goreng. Celupkan ayam ke dalam adonan kremes, balurkan hingga mereta. Kemudian goreng ayam hingga berwarna golden brown. Angkat dan tiriskan
1. Cara membuat kremes: - Tambahkan baking powder pada sisa adonan kremes. Aduk hingga tercampur rata. (Note: Baking Powder dimasukkan sesaat sebelum adonan kremes digoreng)
1. Panaskan minyak goreng (pastikan minyak goreng sudah benar-benar panas). Lalu ambil adonan dengan tangan, kucurkan adonan dengan bantuan jari tangan dengan gerakan berputar di atas wajan. Ketika mulai kokoh balik adonan, terus goreng sampai kecokelatan, angkat dan tiriskan.
1. Sajikan ayam goreng dengan kremesan dan sambal. Enjoy... 😊




Wah ternyata cara membuat ayam goreng kremes yang mantab tidak rumit ini mudah banget ya! Kita semua mampu membuatnya. Resep ayam goreng kremes Sangat cocok banget untuk kita yang sedang belajar memasak maupun untuk kamu yang telah lihai memasak.

Apakah kamu tertarik mulai mencoba bikin resep ayam goreng kremes lezat simple ini? Kalau tertarik, yuk kita segera menyiapkan alat-alat dan bahan-bahannya, setelah itu buat deh Resep ayam goreng kremes yang enak dan tidak ribet ini. Benar-benar gampang kan. 

Jadi, daripada kalian berlama-lama, hayo langsung aja bikin resep ayam goreng kremes ini. Pasti kalian tak akan menyesal sudah membuat resep ayam goreng kremes mantab simple ini! Selamat mencoba dengan resep ayam goreng kremes nikmat tidak rumit ini di tempat tinggal kalian sendiri,oke!.

