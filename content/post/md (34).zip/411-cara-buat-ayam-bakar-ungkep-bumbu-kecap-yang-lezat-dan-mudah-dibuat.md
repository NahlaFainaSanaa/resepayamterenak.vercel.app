---
description: "Cara buat Ayam bakar ungkep bumbu kecap yang lezat dan Mudah Dibuat"
title: "Cara buat Ayam bakar ungkep bumbu kecap yang lezat dan Mudah Dibuat"
slug: 411-cara-buat-ayam-bakar-ungkep-bumbu-kecap-yang-lezat-dan-mudah-dibuat
date: 2021-02-23T04:26:24.398Z
image: https://img-global.cpcdn.com/recipes/79c14e55fb99134c/680x482cq70/ayam-bakar-ungkep-bumbu-kecap-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/79c14e55fb99134c/680x482cq70/ayam-bakar-ungkep-bumbu-kecap-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/79c14e55fb99134c/680x482cq70/ayam-bakar-ungkep-bumbu-kecap-foto-resep-utama.jpg
author: Clarence Reyes
ratingvalue: 3.4
reviewcount: 8
recipeingredient:
- " Bahan utama"
- "1/2 kg ayam"
- " Bumbu halus"
- "5 siung bawang putih"
- "3 siung bawang merah"
- "2 cm jahe"
- "2 cm kunyit"
- " Bumbu lain"
- "2 batang sereh"
- "1 ruas lengkuas digeprek"
- "3 sdm gula merah"
- "3 lembar daun salam"
- "2 lembar daun jeruk"
- "1 sdm kaldu bubuk"
- "5 sdm kecap manis"
- "2 sdm air asam jawa"
- "500 ml air"
- "2 sdm minyak untuk menumis"
recipeinstructions:
- "Haluskan bawang putih, bawang merah, jahe dan kunyit, lalu panaskan minyak dan tumis bumbu halus sampai harum."
- "Setelah harum masukkan lengkuas, sereh, daun jeruk, gula merah, kecap manis dan air asam jawa lalu masukkan ayam dan aduk sampai rata."
- "Masukkan air lalu didihkan sampai menyusut dan mengental."
- "Panaskan teflon beri sedikit minyak ambil ayam dan bakar di atas teflon sebentar saja untuk memperoleh aroma bakarannya. Angkat dan sajikan. Ayam ungkep bumbu kecap siap dihidangkan dengan sambel kecap juga lebih yummi."
categories:
- Resep
tags:
- ayam
- bakar
- ungkep

katakunci: ayam bakar ungkep 
nutrition: 163 calories
recipecuisine: Indonesian
preptime: "PT11M"
cooktime: "PT58M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam bakar ungkep bumbu kecap](https://img-global.cpcdn.com/recipes/79c14e55fb99134c/680x482cq70/ayam-bakar-ungkep-bumbu-kecap-foto-resep-utama.jpg)

Selaku seorang yang hobi memasak, menyediakan panganan nikmat kepada orang tercinta adalah suatu hal yang membahagiakan bagi kita sendiri. Tanggung jawab seorang istri Tidak hanya menjaga rumah saja, tapi anda juga harus menyediakan kebutuhan nutrisi tercukupi dan olahan yang disantap orang tercinta harus lezat.

Di waktu  sekarang, anda sebenarnya bisa mengorder santapan siap saji tanpa harus susah mengolahnya lebih dulu. Namun banyak juga mereka yang memang mau memberikan makanan yang terbaik untuk keluarganya. Karena, memasak yang dibuat sendiri jauh lebih higienis dan bisa menyesuaikan berdasarkan makanan kesukaan keluarga. 



Mungkinkah anda salah satu penikmat ayam bakar ungkep bumbu kecap?. Asal kamu tahu, ayam bakar ungkep bumbu kecap adalah sajian khas di Nusantara yang kini digemari oleh orang-orang di hampir setiap wilayah di Nusantara. Kita dapat membuat ayam bakar ungkep bumbu kecap sendiri di rumahmu dan boleh jadi makanan kegemaranmu di hari liburmu.

Kamu tidak perlu bingung jika kamu ingin memakan ayam bakar ungkep bumbu kecap, sebab ayam bakar ungkep bumbu kecap tidak sukar untuk didapatkan dan juga kalian pun dapat menghidangkannya sendiri di rumah. ayam bakar ungkep bumbu kecap boleh dibuat memalui beraneka cara. Sekarang ada banyak sekali resep kekinian yang menjadikan ayam bakar ungkep bumbu kecap semakin enak.

Resep ayam bakar ungkep bumbu kecap juga mudah untuk dibuat, lho. Kalian tidak perlu repot-repot untuk memesan ayam bakar ungkep bumbu kecap, karena Kita dapat menyajikan di rumahmu. Untuk Kita yang akan menyajikannya, berikut ini resep untuk membuat ayam bakar ungkep bumbu kecap yang enak yang mampu Anda buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Ayam bakar ungkep bumbu kecap:

1. Siapkan  Bahan utama
1. Siapkan 1/2 kg ayam
1. Siapkan  Bumbu halus
1. Gunakan 5 siung bawang putih
1. Gunakan 3 siung bawang merah
1. Siapkan 2 cm jahe
1. Gunakan 2 cm kunyit
1. Sediakan  Bumbu lain
1. Siapkan 2 batang sereh
1. Sediakan 1 ruas lengkuas (digeprek)
1. Ambil 3 sdm gula merah
1. Ambil 3 lembar daun salam
1. Sediakan 2 lembar daun jeruk
1. Gunakan 1 sdm kaldu bubuk
1. Sediakan 5 sdm kecap manis
1. Ambil 2 sdm air asam jawa
1. Sediakan 500 ml air
1. Ambil 2 sdm minyak untuk menumis




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam bakar ungkep bumbu kecap:

1. Haluskan bawang putih, bawang merah, jahe dan kunyit, lalu panaskan minyak dan tumis bumbu halus sampai harum.
1. Setelah harum masukkan lengkuas, sereh, daun jeruk, gula merah, kecap manis dan air asam jawa lalu masukkan ayam dan aduk sampai rata.
1. Masukkan air lalu didihkan sampai menyusut dan mengental.
1. Panaskan teflon beri sedikit minyak ambil ayam dan bakar di atas teflon sebentar saja untuk memperoleh aroma bakarannya. Angkat dan sajikan. Ayam ungkep bumbu kecap siap dihidangkan dengan sambel kecap juga lebih yummi.




Wah ternyata cara buat ayam bakar ungkep bumbu kecap yang enak simple ini enteng banget ya! Kalian semua bisa menghidangkannya. Resep ayam bakar ungkep bumbu kecap Sangat cocok banget buat kamu yang baru belajar memasak ataupun juga bagi kamu yang telah ahli dalam memasak.

Tertarik untuk mencoba buat resep ayam bakar ungkep bumbu kecap enak sederhana ini? Kalau kamu ingin, yuk kita segera siapin alat dan bahan-bahannya, lalu buat deh Resep ayam bakar ungkep bumbu kecap yang enak dan sederhana ini. Benar-benar taidak sulit kan. 

Oleh karena itu, ketimbang kita berlama-lama, hayo kita langsung saja hidangkan resep ayam bakar ungkep bumbu kecap ini. Dijamin kalian gak akan menyesal sudah membuat resep ayam bakar ungkep bumbu kecap lezat tidak ribet ini! Selamat mencoba dengan resep ayam bakar ungkep bumbu kecap lezat tidak ribet ini di rumah kalian masing-masing,ya!.

