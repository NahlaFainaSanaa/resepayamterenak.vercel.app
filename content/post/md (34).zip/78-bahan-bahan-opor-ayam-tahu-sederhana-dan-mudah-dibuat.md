---
description: "Bahan-bahan Opor ayam tahu Sederhana dan Mudah Dibuat"
title: "Bahan-bahan Opor ayam tahu Sederhana dan Mudah Dibuat"
slug: 78-bahan-bahan-opor-ayam-tahu-sederhana-dan-mudah-dibuat
date: 2021-02-16T03:58:50.200Z
image: https://img-global.cpcdn.com/recipes/800ca4a59bcba6eb/680x482cq70/opor-ayam-tahu-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/800ca4a59bcba6eb/680x482cq70/opor-ayam-tahu-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/800ca4a59bcba6eb/680x482cq70/opor-ayam-tahu-foto-resep-utama.jpg
author: Ernest Hudson
ratingvalue: 4.6
reviewcount: 3
recipeingredient:
- "1/2 kg ayam potong kecil2 17k"
- "1 plastik tahu putih 3k"
- " Kelapa parut 2k"
- " Gula merah kira2 seruas jari"
- " Garam dan kaldu bubuk"
- "1 ruas jahe 1 batang serai 2 lb daun jeruk dan 2 lb daun salam"
- " Bumbu halus"
- "7 bawang merah"
- "3 siung bawang putih"
- "2 butir Kemiri"
- "1 ruas kunyit"
- "1/2 sendok makan ketumbar"
- "1/2 sendok teh merica"
- "1 ruas jahe"
recipeinstructions:
- "Siapkan bumbu halus.  Bersihkan ayam (kl aq tdk perlu diberi perasan jeruk krn nanti ayam direbus dg bumbu halus. Jd ga amis).  Juga Potong2 tahu sesuai selera"
- "Siapkan santan dr kelapa parut yg sudah dibeli. Awalnya santan diberi cukup air kemudian diremas2 supaya sarinya keluar. Kl udah baru sedikit demi sedikit ditambah air sambil diremas2 juga sampai ukuran bisa buat kuah banyak. Jd nanti santannya intensitas tidak terlalu kental juga tdk terlalu cair"
- "Siapkan penggorengan dan beri minyak. Kemudian tumis bumbu halus hingga harum, masukkan daun salam, daun jeruk, sereh, gula merah, secukupnya garam dan kaldu bubuk. (Aq pakai kaldu bubuk merk royco stgh sachet yg 500an)."
- "Kemudian masukkan ayam dan aduk hingga rata. Masak hingga mendidih atau bumbu mulai asat. dg sesekali diaduk. Api sedang saja supaya ayam empuk dan bumbu meresap."
- "Setelah kiranya bumbu sudah sedikit asat dan ayam sudah berubah warna kuning, masukkan santan dan tahu. Kemudian diaduk supaya rata. Agar santan tidak pecah, selama masak lerlu diaduk sampai kuah mendidih (cukup buat gerakan gelombang dr spatula yg dimasukan di bawah masakan). Kl kuah sudah mendidih, boleh berhenti diaduk sambil nunggu tanak betul masakannya."
- "Monggo dites rasa, kl ada yg kurang bisa ditambah2 sambil menunggu matang sempurna. Kl sudah, siap disajikan"
categories:
- Resep
tags:
- opor
- ayam
- tahu

katakunci: opor ayam tahu 
nutrition: 265 calories
recipecuisine: Indonesian
preptime: "PT18M"
cooktime: "PT54M"
recipeyield: "2"
recipecategory: Dessert

---


![Opor ayam tahu](https://img-global.cpcdn.com/recipes/800ca4a59bcba6eb/680x482cq70/opor-ayam-tahu-foto-resep-utama.jpg)

Sebagai seorang yang hobi memasak, menyediakan santapan mantab untuk keluarga merupakan hal yang menggembirakan bagi kamu sendiri. Tanggung jawab seorang istri bukan hanya menjaga rumah saja, namun anda pun wajib memastikan kebutuhan nutrisi terpenuhi dan juga masakan yang dimakan anak-anak mesti lezat.

Di masa  sekarang, anda memang dapat mengorder olahan praktis tanpa harus repot mengolahnya terlebih dahulu. Namun banyak juga mereka yang memang mau memberikan yang terbaik untuk orang yang dicintainya. Sebab, menyajikan masakan yang dibuat sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan hidangan tersebut berdasarkan selera keluarga tercinta. 



Mungkinkah kamu salah satu penikmat opor ayam tahu?. Asal kamu tahu, opor ayam tahu adalah makanan khas di Nusantara yang kini disenangi oleh orang-orang di berbagai daerah di Nusantara. Kamu dapat memasak opor ayam tahu sendiri di rumahmu dan boleh dijadikan makanan favoritmu di akhir pekanmu.

Kita tidak usah bingung untuk mendapatkan opor ayam tahu, karena opor ayam tahu mudah untuk dicari dan anda pun boleh memasaknya sendiri di rumah. opor ayam tahu dapat dimasak dengan beraneka cara. Kini pun ada banyak banget cara modern yang membuat opor ayam tahu semakin enak.

Resep opor ayam tahu pun gampang dihidangkan, lho. Kita tidak usah ribet-ribet untuk memesan opor ayam tahu, lantaran Kamu mampu menghidangkan di rumah sendiri. Untuk Anda yang hendak menghidangkannya, inilah cara membuat opor ayam tahu yang mantab yang bisa Kita coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Opor ayam tahu:

1. Ambil 1/2 kg ayam potong kecil2 17k
1. Siapkan 1 plastik tahu putih 3k
1. Ambil  Kelapa parut 2k
1. Gunakan  Gula merah kira2 seruas jari
1. Sediakan  Garam dan kaldu bubuk
1. Ambil 1 ruas jahe, 1 batang serai, 2 lb daun jeruk dan 2 lb daun salam
1. Ambil  Bumbu halus
1. Siapkan 7 bawang merah
1. Sediakan 3 siung bawang putih
1. Ambil 2 butir Kemiri
1. Ambil 1 ruas kunyit
1. Ambil 1/2 sendok makan ketumbar
1. Gunakan 1/2 sendok teh merica
1. Ambil 1 ruas jahe




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Opor ayam tahu:

1. Siapkan bumbu halus.  - Bersihkan ayam (kl aq tdk perlu diberi perasan jeruk krn nanti ayam direbus dg bumbu halus. Jd ga amis).  - Juga Potong2 tahu sesuai selera
1. Siapkan santan dr kelapa parut yg sudah dibeli. Awalnya santan diberi cukup air kemudian diremas2 supaya sarinya keluar. Kl udah baru sedikit demi sedikit ditambah air sambil diremas2 juga sampai ukuran bisa buat kuah banyak. Jd nanti santannya intensitas tidak terlalu kental juga tdk terlalu cair
1. Siapkan penggorengan dan beri minyak. Kemudian tumis bumbu halus hingga harum, masukkan daun salam, daun jeruk, sereh, gula merah, secukupnya garam dan kaldu bubuk. (Aq pakai kaldu bubuk merk royco stgh sachet yg 500an).
1. Kemudian masukkan ayam dan aduk hingga rata. Masak hingga mendidih atau bumbu mulai asat. dg sesekali diaduk. Api sedang saja supaya ayam empuk dan bumbu meresap.
1. Setelah kiranya bumbu sudah sedikit asat dan ayam sudah berubah warna kuning, masukkan santan dan tahu. Kemudian diaduk supaya rata. Agar santan tidak pecah, selama masak lerlu diaduk sampai kuah mendidih (cukup buat gerakan gelombang dr spatula yg dimasukan di bawah masakan). Kl kuah sudah mendidih, boleh berhenti diaduk sambil nunggu tanak betul masakannya.
1. Monggo dites rasa, kl ada yg kurang bisa ditambah2 sambil menunggu matang sempurna. Kl sudah, siap disajikan




Ternyata resep opor ayam tahu yang lezat tidak ribet ini enteng sekali ya! Kamu semua dapat membuatnya. Cara buat opor ayam tahu Sangat cocok banget buat anda yang baru mau belajar memasak maupun bagi kalian yang telah lihai dalam memasak.

Tertarik untuk mulai mencoba membuat resep opor ayam tahu mantab simple ini? Kalau kamu tertarik, yuk kita segera siapin alat-alat dan bahannya, maka bikin deh Resep opor ayam tahu yang lezat dan tidak ribet ini. Betul-betul taidak sulit kan. 

Jadi, daripada anda diam saja, ayo kita langsung saja hidangkan resep opor ayam tahu ini. Dijamin kamu tak akan nyesel bikin resep opor ayam tahu mantab tidak ribet ini! Selamat berkreasi dengan resep opor ayam tahu enak tidak ribet ini di tempat tinggal sendiri,oke!.

