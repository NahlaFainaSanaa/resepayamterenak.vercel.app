---
description: "Cara membuat Ayam Asam Manis Khas Banjar yang lezat Untuk Jualan"
title: "Cara membuat Ayam Asam Manis Khas Banjar yang lezat Untuk Jualan"
slug: 334-cara-membuat-ayam-asam-manis-khas-banjar-yang-lezat-untuk-jualan
date: 2021-05-25T19:35:00.900Z
image: https://img-global.cpcdn.com/recipes/cf47e801e99db32b/680x482cq70/ayam-asam-manis-khas-banjar-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/cf47e801e99db32b/680x482cq70/ayam-asam-manis-khas-banjar-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/cf47e801e99db32b/680x482cq70/ayam-asam-manis-khas-banjar-foto-resep-utama.jpg
author: Milton Diaz
ratingvalue: 4.3
reviewcount: 4
recipeingredient:
- "500 gr ayam bagian paha potongpotong jadi beberapa bagian"
- "1/2 buah jeruk nipis ambil airnya saja"
- "3 buah cabe merah besar iris serong"
- "3 buah cabe hijau besar iris serong"
- "2 sdm kecap manis"
- "2 sdm saos tomat"
- "2 sdm air asam Jawa pekat"
- "150 ml air"
- "Secukupnya garam dan kaldu bubuk me Royco"
- "Secukupnya minyak goreng untuk menumis"
- " Bumbu Marinasi Ayam"
- "1 sdt garam"
- "2 sdm saos tomat"
- " Bumbu Tumis"
- "6 siung bawang merah iris tipis"
- "5 siung bawang putih iris tipis"
- "1/2 buah bawang bombai irisiris"
- " Bumbu Halus"
- "4 buah tomat"
- "125 gr gula merah"
recipeinstructions:
- "Siapkan bahan yang akan digunakan"
- "Cuci baju ayam, berikan perasan air jeruk nipis, diamkan 10-15 menit agar tidak bau amis, lalu bilas kembali."
- "Tambahkan bumbu marinasi (garam dan saos tomat), aduk rata, diamkan selama 15 menit."
- "Sambil menunggu ayamnya di marinasi, rajang/iris-iris bumbu yang akan digunakan, dan blender bumbu halus, sisihkan"
- "Setelah 15 menit kemudian, goreng ayam setengah matang, angkat dan tiriskan, sisihkan"
- "Panaskan secukupnya minyak goreng, tumis bawang merah, bawang putih, bawang bombai hingga wangi"
- "Kemudian masukkan bumbu halus, aduk rata. Tambahkan air, saos tomat, kecap, secukupnya garam dan kaldu bubuk (me. royco ayam), aduk rata. Koreksi rasa. (Note. Garam dan kaldu bubuk dimasukkan dikit aja dulu ya, nanti bisa ditambahkan lagi sebelum diangkat, agar tidak asin)"
- "Lalu masukkan ayam yang telah di goreng setengah matang, irisan cabe merah dan cabe hijau. Aduk rata. Masak hingga ayam matang, bumbunya meresap dan kuahnya menyusut tinggal sedikit dan agak kental. Sesekali diaduk-aduk dalam proses memasaknya. Sebelum diangkat, koreksi rasa terlebih dahulu. (Jika masih ada yang kuran boleh ditambahkan lagi secukupnya garam dan kaldu bubuk), jika sudah rasanya pas, angkat dan sajikan"
- "Ayam Asam Manis Khas Banjar siap disajikan 😊"
categories:
- Resep
tags:
- ayam
- asam
- manis

katakunci: ayam asam manis 
nutrition: 173 calories
recipecuisine: Indonesian
preptime: "PT24M"
cooktime: "PT40M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam Asam Manis Khas Banjar](https://img-global.cpcdn.com/recipes/cf47e801e99db32b/680x482cq70/ayam-asam-manis-khas-banjar-foto-resep-utama.jpg)

Selaku seorang yang hobi memasak, mempersiapkan olahan sedap bagi orang tercinta merupakan suatu hal yang menggembirakan bagi kamu sendiri. Tanggung jawab seorang ibu bukan hanya menangani rumah saja, tapi anda juga wajib menyediakan kebutuhan gizi tercukupi dan juga masakan yang dikonsumsi orang tercinta wajib menggugah selera.

Di waktu  saat ini, kalian sebenarnya mampu memesan santapan yang sudah jadi walaupun tanpa harus repot memasaknya dahulu. Tetapi banyak juga lho mereka yang selalu ingin memberikan makanan yang terbaik bagi orang tercintanya. Sebab, memasak yang dibuat sendiri akan jauh lebih bersih dan bisa menyesuaikan masakan tersebut berdasarkan masakan kesukaan orang tercinta. 



Apakah anda salah satu penggemar ayam asam manis khas banjar?. Tahukah kamu, ayam asam manis khas banjar adalah sajian khas di Nusantara yang kini disukai oleh kebanyakan orang di berbagai tempat di Nusantara. Anda dapat menghidangkan ayam asam manis khas banjar kreasi sendiri di rumahmu dan pasti jadi hidangan kesenanganmu di akhir pekan.

Kita tidak usah bingung untuk menyantap ayam asam manis khas banjar, karena ayam asam manis khas banjar tidak sulit untuk ditemukan dan juga kita pun boleh memasaknya sendiri di rumah. ayam asam manis khas banjar dapat dimasak lewat bermacam cara. Sekarang ada banyak sekali cara kekinian yang membuat ayam asam manis khas banjar semakin enak.

Resep ayam asam manis khas banjar pun sangat mudah dibuat, lho. Kita jangan repot-repot untuk memesan ayam asam manis khas banjar, karena Kamu mampu menyajikan sendiri di rumah. Bagi Kalian yang akan menghidangkannya, berikut ini resep membuat ayam asam manis khas banjar yang nikamat yang mampu Anda coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Ayam Asam Manis Khas Banjar:

1. Siapkan 500 gr ayam bagian paha, potong-potong jadi beberapa bagian
1. Gunakan 1/2 buah jeruk nipis, ambil airnya saja
1. Gunakan 3 buah cabe merah besar, iris serong
1. Siapkan 3 buah cabe hijau besar, iris serong
1. Siapkan 2 sdm kecap manis
1. Gunakan 2 sdm saos tomat
1. Gunakan 2 sdm air asam Jawa pekat
1. Gunakan 150 ml air
1. Siapkan Secukupnya garam dan kaldu bubuk (me. Royco)
1. Ambil Secukupnya minyak goreng untuk menumis
1. Ambil  Bumbu Marinasi Ayam:
1. Ambil 1 sdt garam
1. Siapkan 2 sdm saos tomat
1. Ambil  Bumbu Tumis:
1. Sediakan 6 siung bawang merah, iris tipis
1. Siapkan 5 siung bawang putih, iris tipis
1. Sediakan 1/2 buah bawang bombai, iris-iris
1. Siapkan  Bumbu Halus:
1. Gunakan 4 buah tomat
1. Ambil 125 gr gula merah




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam Asam Manis Khas Banjar:

1. Siapkan bahan yang akan digunakan
1. Cuci baju ayam, berikan perasan air jeruk nipis, diamkan 10-15 menit agar tidak bau amis, lalu bilas kembali.
1. Tambahkan bumbu marinasi (garam dan saos tomat), aduk rata, diamkan selama 15 menit.
1. Sambil menunggu ayamnya di marinasi, rajang/iris-iris bumbu yang akan digunakan, dan blender bumbu halus, sisihkan
1. Setelah 15 menit kemudian, goreng ayam setengah matang, angkat dan tiriskan, sisihkan
1. Panaskan secukupnya minyak goreng, tumis bawang merah, bawang putih, bawang bombai hingga wangi
1. Kemudian masukkan bumbu halus, aduk rata. Tambahkan air, saos tomat, kecap, secukupnya garam dan kaldu bubuk (me. royco ayam), aduk rata. Koreksi rasa. (Note. Garam dan kaldu bubuk dimasukkan dikit aja dulu ya, nanti bisa ditambahkan lagi sebelum diangkat, agar tidak asin)
1. Lalu masukkan ayam yang telah di goreng setengah matang, irisan cabe merah dan cabe hijau. Aduk rata. Masak hingga ayam matang, bumbunya meresap dan kuahnya menyusut tinggal sedikit dan agak kental. Sesekali diaduk-aduk dalam proses memasaknya. Sebelum diangkat, koreksi rasa terlebih dahulu. (Jika masih ada yang kuran boleh ditambahkan lagi secukupnya garam dan kaldu bubuk), jika sudah rasanya pas, angkat dan sajikan
1. Ayam Asam Manis Khas Banjar siap disajikan 😊




Wah ternyata resep ayam asam manis khas banjar yang enak tidak rumit ini mudah banget ya! Anda Semua bisa memasaknya. Cara buat ayam asam manis khas banjar Cocok sekali untuk anda yang baru belajar memasak ataupun untuk anda yang telah ahli memasak.

Tertarik untuk mulai mencoba buat resep ayam asam manis khas banjar mantab tidak rumit ini? Kalau ingin, ayo kalian segera buruan siapin alat dan bahannya, lantas bikin deh Resep ayam asam manis khas banjar yang nikmat dan tidak ribet ini. Sangat mudah kan. 

Maka dari itu, daripada kita berlama-lama, ayo langsung aja bikin resep ayam asam manis khas banjar ini. Pasti kamu tiidak akan nyesel sudah buat resep ayam asam manis khas banjar lezat tidak rumit ini! Selamat berkreasi dengan resep ayam asam manis khas banjar lezat sederhana ini di tempat tinggal sendiri,oke!.

