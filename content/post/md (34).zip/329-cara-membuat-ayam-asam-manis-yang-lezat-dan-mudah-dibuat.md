---
description: "Cara membuat Ayam Asam Manis yang lezat dan Mudah Dibuat"
title: "Cara membuat Ayam Asam Manis yang lezat dan Mudah Dibuat"
slug: 329-cara-membuat-ayam-asam-manis-yang-lezat-dan-mudah-dibuat
date: 2021-04-29T04:21:13.531Z
image: https://img-global.cpcdn.com/recipes/028ad0e965599664/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/028ad0e965599664/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/028ad0e965599664/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
author: Rena Carr
ratingvalue: 4.8
reviewcount: 11
recipeingredient:
- " Ayam crispy "
- "1 kg ayam fillet"
- "10 sdm penuh tepung serbaguna"
- "6 sdm tepung terigu"
- "4 butir telur"
- " Saos asam manis "
- "2 sdm mentega"
- "1/2 buah nanas iris tipis"
- "2 siung bawang putih iris tipis"
- "2 siung bawang merah iris tipis"
- "1 bawang bombay iris tipis"
- "2 batang daun bawang iris bawang"
- "1 sdt kecap manis"
- "4 sdm saos extra pedas"
- "1 sdm tepung maizena"
- "Secukupnya kaldu bubuk"
- "Secukupnya garam  gula pasir"
recipeinstructions:
- "Siapkan 3 wadah untuk  1) telur kocok 2) 5 sdm tepung serbaguna campur 3 sdm tepung terigu 3) sama seperti no.2 untuk baluran setelah ayam dimasukkan ke telur"
- "Baluri ayam fillet pada adonan tepung wadah ke 2 kemudian masukkan ke telur terakhir balurkan lagi ke tepung pada wadah ke 3."
- "Goreng ayam tepung pada minyak panas pada api kecil sampai kekuningan kemudian tiriskan."
- "Siapkan wajan bersih, panaskan mentega hingga cair kemudian masukkan irisan bawang putih, bawang merah, bawang bombay dan nanas hingga harum."
- "Kemudian masukkan tepung maizena yang sudah diaduk bersama air di gelas secukupnya."
- "Masukkan kecap manis, sambal extra pedas, garam, gula pasir, dan kaldu bubuk secukupnya."
- "Aduk dan icip rasa kemudian masukkan ayam krispy dan daun bawang."
- "Aduk sebentar dan sajikan."
categories:
- Resep
tags:
- ayam
- asam
- manis

katakunci: ayam asam manis 
nutrition: 156 calories
recipecuisine: Indonesian
preptime: "PT26M"
cooktime: "PT44M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam Asam Manis](https://img-global.cpcdn.com/recipes/028ad0e965599664/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg)

Apabila kalian seorang ibu, mempersiapkan olahan mantab buat orang tercinta adalah suatu hal yang mengasyikan bagi anda sendiri. Tugas seorang ibu bukan sekedar menangani rumah saja, tapi anda juga harus memastikan keperluan nutrisi tercukupi dan juga masakan yang disantap orang tercinta mesti menggugah selera.

Di era  saat ini, kalian memang bisa mengorder masakan praktis tanpa harus susah membuatnya lebih dulu. Namun banyak juga orang yang memang mau memberikan yang terenak bagi keluarganya. Sebab, memasak yang diolah sendiri jauh lebih bersih dan kita pun bisa menyesuaikan makanan tersebut berdasarkan makanan kesukaan keluarga tercinta. 



Apakah kamu seorang penggemar ayam asam manis?. Asal kamu tahu, ayam asam manis merupakan sajian khas di Indonesia yang sekarang disenangi oleh kebanyakan orang dari berbagai tempat di Nusantara. Kita bisa membuat ayam asam manis buatan sendiri di rumahmu dan boleh dijadikan santapan favoritmu di akhir pekan.

Kita tidak usah bingung jika kamu ingin mendapatkan ayam asam manis, sebab ayam asam manis gampang untuk didapatkan dan juga kalian pun boleh memasaknya sendiri di tempatmu. ayam asam manis bisa diolah lewat bermacam cara. Saat ini sudah banyak resep kekinian yang menjadikan ayam asam manis lebih nikmat.

Resep ayam asam manis juga sangat mudah dihidangkan, lho. Kamu jangan repot-repot untuk memesan ayam asam manis, karena Kamu bisa menyiapkan di rumahmu. Untuk Kita yang hendak mencobanya, dibawah ini merupakan resep untuk menyajikan ayam asam manis yang lezat yang mampu Kalian hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Ayam Asam Manis:

1. Siapkan  Ayam crispy :
1. Siapkan 1 kg ayam fillet
1. Siapkan 10 sdm penuh tepung serbaguna
1. Gunakan 6 sdm tepung terigu
1. Siapkan 4 butir telur
1. Ambil  Saos asam manis :
1. Gunakan 2 sdm mentega
1. Ambil 1/2 buah nanas iris tipis
1. Gunakan 2 siung bawang putih iris tipis
1. Ambil 2 siung bawang merah iris tipis
1. Siapkan 1 bawang bombay iris tipis
1. Sediakan 2 batang daun bawang iris bawang
1. Gunakan 1 sdt kecap manis
1. Gunakan 4 sdm saos extra pedas
1. Siapkan 1 sdm tepung maizena
1. Ambil Secukupnya kaldu bubuk
1. Sediakan Secukupnya garam + gula pasir




<!--inarticleads2-->

##### Cara membuat Ayam Asam Manis:

1. Siapkan 3 wadah untuk  - 1) telur kocok - 2) 5 sdm tepung serbaguna campur 3 sdm tepung terigu - 3) sama seperti no.2 untuk baluran setelah ayam dimasukkan ke telur
1. Baluri ayam fillet pada adonan tepung wadah ke 2 kemudian masukkan ke telur terakhir balurkan lagi ke tepung pada wadah ke 3.
1. Goreng ayam tepung pada minyak panas pada api kecil sampai kekuningan kemudian tiriskan.
1. Siapkan wajan bersih, panaskan mentega hingga cair kemudian masukkan irisan bawang putih, bawang merah, bawang bombay dan nanas hingga harum.
1. Kemudian masukkan tepung maizena yang sudah diaduk bersama air di gelas secukupnya.
1. Masukkan kecap manis, sambal extra pedas, garam, gula pasir, dan kaldu bubuk secukupnya.
1. Aduk dan icip rasa kemudian masukkan ayam krispy dan daun bawang.
1. Aduk sebentar dan sajikan.




Ternyata resep ayam asam manis yang mantab tidak rumit ini gampang sekali ya! Semua orang mampu mencobanya. Cara buat ayam asam manis Sangat cocok sekali buat anda yang sedang belajar memasak atau juga untuk kamu yang telah pandai dalam memasak.

Tertarik untuk mulai mencoba membikin resep ayam asam manis lezat simple ini? Kalau kalian ingin, yuk kita segera siapin alat dan bahan-bahannya, setelah itu bikin deh Resep ayam asam manis yang enak dan tidak ribet ini. Sangat mudah kan. 

Maka dari itu, daripada kalian berlama-lama, hayo kita langsung bikin resep ayam asam manis ini. Pasti anda gak akan menyesal sudah buat resep ayam asam manis lezat tidak ribet ini! Selamat mencoba dengan resep ayam asam manis nikmat tidak rumit ini di tempat tinggal sendiri,ya!.

