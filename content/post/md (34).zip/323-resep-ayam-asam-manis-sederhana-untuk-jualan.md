---
description: "Resep Ayam Asam Manis Sederhana Untuk Jualan"
title: "Resep Ayam Asam Manis Sederhana Untuk Jualan"
slug: 323-resep-ayam-asam-manis-sederhana-untuk-jualan
date: 2021-01-21T17:20:25.761Z
image: https://img-global.cpcdn.com/recipes/8b4f16e3acfdb660/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8b4f16e3acfdb660/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8b4f16e3acfdb660/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg
author: Stella Holloway
ratingvalue: 4.8
reviewcount: 3
recipeingredient:
- "1/2 kg ayam fillet"
- " Tepung bumbu ayam krispy kentucky"
- "1/2 bawang bombay di iris"
- "4 siung bawang putih di cincang halus"
- "6 sdm saus tomat"
- "3 sdm saus sambal"
- "2 sdm kecap manis"
- "1 sdm saus tiram"
- "Secukupnya minyak untuk menumis"
- "Secukup nya garam dan kaldu bubuk"
- "Secukupnya air"
recipeinstructions:
- "Potong fillet ayam jadi potongan dadu (ukuran sedang)"
- "Siap kan tepung kentucky lalu campur air (adonan jangan terlalu encer dan jangan terlalu kental)"
- "Masukan ayam fillet ke adonan kentucky dan diamkan selama 10 menit"
- "Goreng ayam sampai kecoklatan lalu angkat"
- "Untuk saus asam manis, panaskan secukupnya minyak lalu tumis bawang putih yang sudah di cincang halus"
- "Masukan bawang bombay yang sudah di iris lalu aduk aduk sampai setengah matang"
- "Jika sudah tercium harum masukan saus tomat, saus sambal, kecap dan saus tiram. Aduk aduk hingga semua merata"
- "Jika sudah merata, tambahkan air secukupnya lalu tambahkan garam dan kaldu bubuk"
- "Koreksi rasa, jika sudah pas masukkan ayam ke dalam saus asam manis. Lalu di aduk sampai bumbu agak menyusut"
- "Selesaaaai~"
categories:
- Resep
tags:
- ayam
- asam
- manis

katakunci: ayam asam manis 
nutrition: 288 calories
recipecuisine: Indonesian
preptime: "PT10M"
cooktime: "PT58M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam Asam Manis](https://img-global.cpcdn.com/recipes/8b4f16e3acfdb660/680x482cq70/ayam-asam-manis-foto-resep-utama.jpg)

Apabila anda seorang wanita, menyuguhkan masakan lezat kepada keluarga tercinta adalah hal yang membahagiakan bagi kita sendiri. Tanggung jawab seorang istri bukan cuman mengerjakan pekerjaan rumah saja, tapi kamu pun wajib memastikan keperluan gizi terpenuhi dan juga panganan yang dikonsumsi keluarga tercinta mesti nikmat.

Di masa  saat ini, anda sebenarnya dapat memesan santapan yang sudah jadi tidak harus capek membuatnya dulu. Namun ada juga mereka yang memang ingin memberikan hidangan yang terlezat untuk orang tercintanya. Lantaran, memasak yang dibuat sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan hidangan tersebut sesuai dengan makanan kesukaan famili. 



Mungkinkah anda adalah salah satu penggemar ayam asam manis?. Asal kamu tahu, ayam asam manis adalah makanan khas di Nusantara yang saat ini disukai oleh setiap orang dari hampir setiap daerah di Indonesia. Kalian dapat memasak ayam asam manis sendiri di rumah dan boleh dijadikan makanan kesenanganmu di akhir pekanmu.

Anda jangan bingung untuk menyantap ayam asam manis, lantaran ayam asam manis gampang untuk dicari dan kalian pun dapat menghidangkannya sendiri di rumah. ayam asam manis bisa dibuat dengan berbagai cara. Kini pun ada banyak cara kekinian yang membuat ayam asam manis lebih enak.

Resep ayam asam manis juga mudah sekali untuk dibuat, lho. Anda tidak perlu ribet-ribet untuk membeli ayam asam manis, lantaran Kita dapat membuatnya sendiri di rumah. Bagi Kamu yang mau menyajikannya, berikut ini resep membuat ayam asam manis yang nikamat yang dapat Anda hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Ayam Asam Manis:

1. Sediakan 1/2 kg ayam fillet
1. Siapkan  Tepung bumbu ayam krispy kentucky
1. Gunakan 1/2 bawang bombay (di iris)
1. Ambil 4 siung bawang putih (di cincang halus)
1. Gunakan 6 sdm saus tomat
1. Siapkan 3 sdm saus sambal
1. Gunakan 2 sdm kecap manis
1. Ambil 1 sdm saus tiram
1. Ambil Secukupnya minyak untuk menumis
1. Gunakan Secukup nya garam dan kaldu bubuk
1. Sediakan Secukupnya air




<!--inarticleads2-->

##### Cara menyiapkan Ayam Asam Manis:

1. Potong fillet ayam jadi potongan dadu (ukuran sedang)
1. Siap kan tepung kentucky lalu campur air (adonan jangan terlalu encer dan jangan terlalu kental)
1. Masukan ayam fillet ke adonan kentucky dan diamkan selama 10 menit
1. Goreng ayam sampai kecoklatan lalu angkat
1. Untuk saus asam manis, panaskan secukupnya minyak lalu tumis bawang putih yang sudah di cincang halus
1. Masukan bawang bombay yang sudah di iris lalu aduk aduk sampai setengah matang
1. Jika sudah tercium harum masukan saus tomat, saus sambal, kecap dan saus tiram. Aduk aduk hingga semua merata
1. Jika sudah merata, tambahkan air secukupnya lalu tambahkan garam dan kaldu bubuk
1. Koreksi rasa, jika sudah pas masukkan ayam ke dalam saus asam manis. Lalu di aduk sampai bumbu agak menyusut
1. Selesaaaai~




Wah ternyata resep ayam asam manis yang enak tidak ribet ini enteng banget ya! Kita semua dapat memasaknya. Cara buat ayam asam manis Sangat sesuai banget buat kamu yang baru akan belajar memasak maupun bagi kamu yang telah pandai memasak.

Apakah kamu tertarik mulai mencoba buat resep ayam asam manis mantab tidak rumit ini? Kalau ingin, yuk kita segera siapkan peralatan dan bahan-bahannya, setelah itu bikin deh Resep ayam asam manis yang mantab dan tidak rumit ini. Benar-benar mudah kan. 

Oleh karena itu, ketimbang kita berfikir lama-lama, ayo langsung aja bikin resep ayam asam manis ini. Pasti anda gak akan menyesal bikin resep ayam asam manis lezat tidak rumit ini! Selamat berkreasi dengan resep ayam asam manis lezat sederhana ini di tempat tinggal kalian masing-masing,oke!.

