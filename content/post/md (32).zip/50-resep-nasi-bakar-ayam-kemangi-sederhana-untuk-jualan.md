---
description: "Resep Nasi Bakar Ayam Kemangi Sederhana Untuk Jualan"
title: "Resep Nasi Bakar Ayam Kemangi Sederhana Untuk Jualan"
slug: 50-resep-nasi-bakar-ayam-kemangi-sederhana-untuk-jualan
date: 2021-03-20T07:03:47.738Z
image: https://img-global.cpcdn.com/recipes/f7b1dd6bc32f4610/680x482cq70/nasi-bakar-ayam-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f7b1dd6bc32f4610/680x482cq70/nasi-bakar-ayam-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f7b1dd6bc32f4610/680x482cq70/nasi-bakar-ayam-kemangi-foto-resep-utama.jpg
author: Gavin Daniels
ratingvalue: 4.4
reviewcount: 9
recipeingredient:
- " Bahan nasi bakar"
- "5 cup beras 130gram cuci dulu"
- "8 lembar daun salam ukuran kecil"
- "2 batang sereh"
- "5 lembar daun jeruk"
- "1 ibu jari lengkuas"
- "secukupnya garam"
- "secukupnya daun pisang dijemur atau dipanaskan dulu diatas api kompor supaya layu"
- "1 bungkus santan instant 65 ml"
- "Secukupnya air untuk memasak nasi"
- " Bumbu halus untuk isian"
- "segenggam cabai merah keriting saya menggunakan 5 cabai merah keriting saja Bisa juga pakai cabai rawit jika suka lebih pedas"
- "6 siung bawang merah"
- "3 siung bawang putih"
- "1 ibu jari jahe"
- "1 ruas jari kunyit"
- "3 butir kemiri"
- "1 bungkus terasi"
- "1/2 sdt kaldu bubuk ayam"
- "seikat kemangi saya pake sekitar 23 ikat kemangi"
- " Isian"
- "500 gram ayam rebus"
- "1 batang sereh ukuran besar"
- "5 lembar daun salam ukuran kecil"
- "1 sdm gula merah"
- "2 sdm air asam jawa"
- "secukupnya garam dan gula pasir"
- "100 ml air"
recipeinstructions:
- "Campur semua bahan. Masukkan air dan santan. Untuk takaran air sesuaikan dengan berasnya ya (saya lupa menakar berapa ml karena biasanya saya menggunakan ruas jari sebagai patokan saat memasak nasi). Masak di magic com atau penanak nasi seperti biasa. Tunggu hingga matang."
- "Ayam yang sudah direbus kita suwir-suwir atau bisa juga hancurkan kasar di food processor. Sisihkan. Haluskan bawang merah, bawang putih, kemiri, jahe, kunyit, terasi. Tumis bumbu halus, masukkan serai dan daun salam. Aduk rata. Masak hingga bumbu berubah warna lebih kemerahan atau sudah matang. Masukkan gula, garam, kaldu dan air asam jawa. Aduk kembali. Cicipi rasanya apakah sudah pas atau belum."
- "Kalau sudah pas, maka bisa masukkan ayam yang tadi sudah disuir. Aduk kembali. Masukkan air kaldu. Masak hingga terasa asat. Kalau bisa, isian jangan terlalu basah ya supaya tidak mudah basi. Setelah asat, maka kita masukkan kemangi. Aduk sebentar saja. Matikan kompor."
- "Siapkan daun pisang yang sebelumnya sudah dibersihkan dan sudah dijemur (atau dipanaskan diatas api kompor). Ukurannya disesuaikan selera. Kalau saya, nasinya saya buat untuk satu porsi makan jadi agak banyak. Daunnya saya pakai agak besar. Masukkan nasi ke tengah-tengah daun pisang. Letakkan ayam suwir diatasnya. Gulung dan lipat. Ujungnya disematkan dengan tusuk gigi."
- "Bakar di atas teflon atau diatas arang (saya bakar diatas teflon grilled). Setelah terlihat bagian kulit pisang agak gosong, kita balik ke sisi satunya lalu kita angkat. Nasi bakar pun siap disajikan hangat-hangat."
categories:
- Resep
tags:
- nasi
- bakar
- ayam

katakunci: nasi bakar ayam 
nutrition: 244 calories
recipecuisine: Indonesian
preptime: "PT30M"
cooktime: "PT31M"
recipeyield: "3"
recipecategory: Dessert

---


![Nasi Bakar Ayam Kemangi](https://img-global.cpcdn.com/recipes/f7b1dd6bc32f4610/680x482cq70/nasi-bakar-ayam-kemangi-foto-resep-utama.jpg)

Jika kita seorang yang hobi masak, menyuguhkan masakan mantab kepada famili merupakan hal yang membahagiakan untuk kita sendiri. Peran seorang ibu bukan cuma mengerjakan pekerjaan rumah saja, namun anda juga harus menyediakan keperluan gizi tercukupi dan santapan yang dimakan orang tercinta mesti mantab.

Di masa  sekarang, kalian sebenarnya mampu memesan hidangan siap saji tidak harus ribet membuatnya dahulu. Namun ada juga orang yang memang ingin memberikan hidangan yang terlezat bagi orang yang dicintainya. Pasalnya, menghidangkan masakan sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan masakan tersebut sesuai dengan selera keluarga. 



Mungkinkah anda adalah salah satu penggemar nasi bakar ayam kemangi?. Tahukah kamu, nasi bakar ayam kemangi merupakan sajian khas di Indonesia yang saat ini digemari oleh banyak orang di hampir setiap wilayah di Nusantara. Kita bisa memasak nasi bakar ayam kemangi olahan sendiri di rumah dan boleh dijadikan makanan kesenanganmu di hari libur.

Kita tak perlu bingung untuk menyantap nasi bakar ayam kemangi, karena nasi bakar ayam kemangi gampang untuk didapatkan dan kamu pun bisa memasaknya sendiri di rumah. nasi bakar ayam kemangi dapat diolah lewat beraneka cara. Saat ini telah banyak banget resep modern yang membuat nasi bakar ayam kemangi lebih mantap.

Resep nasi bakar ayam kemangi pun sangat mudah untuk dibuat, lho. Anda tidak usah repot-repot untuk membeli nasi bakar ayam kemangi, karena Anda dapat menyiapkan sendiri di rumah. Bagi Anda yang akan menyajikannya, dibawah ini merupakan cara membuat nasi bakar ayam kemangi yang enak yang dapat Kamu buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Nasi Bakar Ayam Kemangi:

1. Ambil  Bahan nasi bakar:
1. Ambil 5 cup beras @130gram, cuci dulu
1. Ambil 8 lembar daun salam (ukuran kecil)
1. Gunakan 2 batang sereh
1. Sediakan 5 lembar daun jeruk
1. Siapkan 1 ibu jari lengkuas
1. Ambil secukupnya garam
1. Siapkan secukupnya daun pisang (dijemur atau dipanaskan dulu diatas api kompor supaya layu)
1. Siapkan 1 bungkus santan instant 65 ml
1. Sediakan Secukupnya air untuk memasak nasi
1. Ambil  Bumbu halus untuk isian:
1. Ambil segenggam cabai merah keriting (saya menggunakan 5 cabai merah keriting saja). Bisa juga pakai cabai rawit jika suka lebih pedas
1. Sediakan 6 siung bawang merah
1. Gunakan 3 siung bawang putih
1. Ambil 1 ibu jari jahe
1. Gunakan 1 ruas jari kunyit
1. Gunakan 3 butir kemiri
1. Sediakan 1 bungkus terasi
1. Siapkan 1/2 sdt kaldu bubuk ayam
1. Siapkan seikat kemangi (saya pake sekitar 2-3 ikat kemangi)
1. Gunakan  Isian:
1. Ambil 500 gram ayam, rebus
1. Ambil 1 batang sereh, ukuran besar
1. Ambil 5 lembar daun salam, ukuran kecil
1. Ambil 1 sdm gula merah
1. Siapkan 2 sdm air asam jawa
1. Siapkan secukupnya garam dan gula pasir
1. Ambil 100 ml air




<!--inarticleads2-->

##### Langkah-langkah membuat Nasi Bakar Ayam Kemangi:

1. Campur semua bahan. Masukkan air dan santan. Untuk takaran air sesuaikan dengan berasnya ya (saya lupa menakar berapa ml karena biasanya saya menggunakan ruas jari sebagai patokan saat memasak nasi). Masak di magic com atau penanak nasi seperti biasa. Tunggu hingga matang.
1. Ayam yang sudah direbus kita suwir-suwir atau bisa juga hancurkan kasar di food processor. Sisihkan. Haluskan bawang merah, bawang putih, kemiri, jahe, kunyit, terasi. Tumis bumbu halus, masukkan serai dan daun salam. Aduk rata. Masak hingga bumbu berubah warna lebih kemerahan atau sudah matang. Masukkan gula, garam, kaldu dan air asam jawa. Aduk kembali. Cicipi rasanya apakah sudah pas atau belum.
1. Kalau sudah pas, maka bisa masukkan ayam yang tadi sudah disuir. Aduk kembali. Masukkan air kaldu. Masak hingga terasa asat. Kalau bisa, isian jangan terlalu basah ya supaya tidak mudah basi. Setelah asat, maka kita masukkan kemangi. Aduk sebentar saja. Matikan kompor.
1. Siapkan daun pisang yang sebelumnya sudah dibersihkan dan sudah dijemur (atau dipanaskan diatas api kompor). Ukurannya disesuaikan selera. Kalau saya, nasinya saya buat untuk satu porsi makan jadi agak banyak. Daunnya saya pakai agak besar. Masukkan nasi ke tengah-tengah daun pisang. Letakkan ayam suwir diatasnya. Gulung dan lipat. Ujungnya disematkan dengan tusuk gigi.
1. Bakar di atas teflon atau diatas arang (saya bakar diatas teflon grilled). Setelah terlihat bagian kulit pisang agak gosong, kita balik ke sisi satunya lalu kita angkat. Nasi bakar pun siap disajikan hangat-hangat.




Ternyata cara buat nasi bakar ayam kemangi yang lezat simple ini gampang sekali ya! Anda Semua mampu membuatnya. Cara Membuat nasi bakar ayam kemangi Sangat cocok banget buat kamu yang baru akan belajar memasak ataupun juga untuk kalian yang telah ahli memasak.

Apakah kamu tertarik mulai mencoba bikin resep nasi bakar ayam kemangi nikmat tidak ribet ini? Kalau kamu ingin, mending kamu segera buruan menyiapkan peralatan dan bahannya, kemudian buat deh Resep nasi bakar ayam kemangi yang nikmat dan sederhana ini. Sungguh mudah kan. 

Maka, ketimbang kalian berlama-lama, yuk langsung aja buat resep nasi bakar ayam kemangi ini. Pasti kamu gak akan menyesal sudah membuat resep nasi bakar ayam kemangi enak simple ini! Selamat mencoba dengan resep nasi bakar ayam kemangi enak tidak ribet ini di rumah sendiri,oke!.

