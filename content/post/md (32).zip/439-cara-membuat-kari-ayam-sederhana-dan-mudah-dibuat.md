---
description: "Cara membuat Kari Ayam Sederhana dan Mudah Dibuat"
title: "Cara membuat Kari Ayam Sederhana dan Mudah Dibuat"
slug: 439-cara-membuat-kari-ayam-sederhana-dan-mudah-dibuat
date: 2021-03-12T11:24:02.660Z
image: https://img-global.cpcdn.com/recipes/4fefc4e6f2403f03/680x482cq70/kari-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4fefc4e6f2403f03/680x482cq70/kari-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4fefc4e6f2403f03/680x482cq70/kari-ayam-foto-resep-utama.jpg
author: Ella Hudson
ratingvalue: 4.1
reviewcount: 3
recipeingredient:
- "4 potong Paha Ayam  12kg"
- "1/2 buah Air Jeruk Nipis untuk baluran ayam"
- "2 bungkus Santan Kara 2x65ml"
- "500 ml Air"
- "1 sdt Garam"
- "1 sdt Kaldu bubuk Ayam"
- "1 sdt bubuk Kari"
- "1/2 sdt bubuk Ketumbar"
- "1 batang Sereh geprek"
- "2 lembar Daun Salam"
- "2 lembar Daun Jeruk"
- "2 cm Lengkuas geprek"
- "2 buah Cengkeh"
- "1 buah Bunga Lawang pekak"
- "2 cm Kayu Manis"
- "3 butir Kapulaga"
- "1 buah Kentang potong dadu"
- " Bumbu Halus "
- "5 siung Bawang Merah"
- "2 siung Bawang Putih"
- "2 cm Jahe"
- "2 cm Kunyit"
- "3 butir Kemiri sangrai"
- "1/2 sdt Jinten sangrai"
- "1 buah Cabai Merah Besar buang bijinya"
recipeinstructions:
- "Cuci bersih ayam kemudian beri perasan air jeruk nipis (diamkan selama 30 menit) kemudian cuci kembali sampai bersih"
- "Panaskan minyak, tumis bumbu halus, sereh, daun salam, lengkuas, daun jeruk, bunga lawang, cengkeh, kayu manis, dan kapulaga sampai harum"
- "Masukan ayam, aduk rata sampai berubah warna"
- "Masukkan air, masak selama 15 menit kemudian masukkan kentang, masak kembali sambil ditutup seperti digambar (-+20 menit) atau sampai ayam matang"
- "Setelah ayam matang, terakhir masukkan santan, garam, dan kaldu ayam, aduk rata (biarkan -+ 10 menit) supaya santan meresap, setelah agak kental matikan apinya (jangan lupa cek rasa)"
categories:
- Resep
tags:
- kari
- ayam

katakunci: kari ayam 
nutrition: 216 calories
recipecuisine: Indonesian
preptime: "PT19M"
cooktime: "PT37M"
recipeyield: "1"
recipecategory: Lunch

---


![Kari Ayam](https://img-global.cpcdn.com/recipes/4fefc4e6f2403f03/680x482cq70/kari-ayam-foto-resep-utama.jpg)

Apabila kita seorang yang hobi masak, mempersiapkan hidangan sedap kepada keluarga merupakan suatu hal yang menggembirakan untuk kamu sendiri. Peran seorang ibu Tidak sekadar mengatur rumah saja, tapi anda pun wajib menyediakan kebutuhan nutrisi tercukupi dan santapan yang dikonsumsi orang tercinta wajib lezat.

Di waktu  saat ini, kamu memang dapat membeli masakan instan meski tanpa harus capek membuatnya dulu. Namun ada juga lho mereka yang memang mau memberikan hidangan yang terbaik untuk keluarganya. Sebab, memasak yang dibuat sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan masakan tersebut berdasarkan kesukaan orang tercinta. 



Apakah anda adalah seorang penggemar kari ayam?. Asal kamu tahu, kari ayam merupakan sajian khas di Nusantara yang kini disukai oleh setiap orang dari berbagai daerah di Nusantara. Kamu dapat memasak kari ayam olahan sendiri di rumah dan boleh dijadikan camilan kesukaanmu di hari libur.

Kamu tak perlu bingung jika kamu ingin menyantap kari ayam, lantaran kari ayam tidak sulit untuk ditemukan dan kamu pun bisa memasaknya sendiri di rumah. kari ayam dapat dibuat memalui beragam cara. Sekarang telah banyak banget cara kekinian yang membuat kari ayam lebih lezat.

Resep kari ayam juga mudah sekali dihidangkan, lho. Kalian jangan capek-capek untuk memesan kari ayam, tetapi Kita dapat menyiapkan ditempatmu. Untuk Anda yang akan menghidangkannya, di bawah ini adalah resep menyajikan kari ayam yang enak yang dapat Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Kari Ayam:

1. Gunakan 4 potong Paha Ayam (-+ 1/2kg)
1. Ambil 1/2 buah Air Jeruk Nipis (untuk baluran ayam)
1. Ambil 2 bungkus Santan Kara (2x65ml)
1. Sediakan 500 ml Air
1. Siapkan 1 sdt Garam
1. Sediakan 1 sdt Kaldu bubuk Ayam
1. Gunakan 1 sdt bubuk Kari
1. Sediakan 1/2 sdt bubuk Ketumbar
1. Siapkan 1 batang Sereh, geprek
1. Siapkan 2 lembar Daun Salam
1. Sediakan 2 lembar Daun Jeruk
1. Ambil 2 cm Lengkuas, geprek
1. Sediakan 2 buah Cengkeh
1. Ambil 1 buah Bunga Lawang (pekak)
1. Ambil 2 cm Kayu Manis
1. Sediakan 3 butir Kapulaga
1. Gunakan 1 buah Kentang, potong dadu
1. Siapkan  Bumbu Halus :
1. Siapkan 5 siung Bawang Merah
1. Gunakan 2 siung Bawang Putih
1. Ambil 2 cm Jahe
1. Ambil 2 cm Kunyit
1. Siapkan 3 butir Kemiri, sangrai
1. Siapkan 1/2 sdt Jinten, sangrai
1. Sediakan 1 buah Cabai Merah Besar (buang bijinya)




<!--inarticleads2-->

##### Cara menyiapkan Kari Ayam:

1. Cuci bersih ayam kemudian beri perasan air jeruk nipis (diamkan selama 30 menit) kemudian cuci kembali sampai bersih
1. Panaskan minyak, tumis bumbu halus, sereh, daun salam, lengkuas, daun jeruk, bunga lawang, cengkeh, kayu manis, dan kapulaga sampai harum
1. Masukan ayam, aduk rata sampai berubah warna
1. Masukkan air, masak selama 15 menit kemudian masukkan kentang, masak kembali sambil ditutup seperti digambar (-+20 menit) atau sampai ayam matang
1. Setelah ayam matang, terakhir masukkan santan, garam, dan kaldu ayam, aduk rata (biarkan -+ 10 menit) supaya santan meresap, setelah agak kental matikan apinya (jangan lupa cek rasa)




Ternyata resep kari ayam yang lezat tidak rumit ini mudah banget ya! Semua orang dapat memasaknya. Cara Membuat kari ayam Sangat sesuai banget buat kalian yang sedang belajar memasak ataupun untuk anda yang sudah pandai dalam memasak.

Apakah kamu mau mulai mencoba buat resep kari ayam mantab tidak ribet ini? Kalau mau, ayo kamu segera buruan menyiapkan alat dan bahan-bahannya, maka buat deh Resep kari ayam yang nikmat dan simple ini. Sungguh taidak sulit kan. 

Jadi, ketimbang kita berlama-lama, ayo kita langsung saja buat resep kari ayam ini. Dijamin kalian tiidak akan menyesal bikin resep kari ayam mantab tidak ribet ini! Selamat berkreasi dengan resep kari ayam nikmat tidak rumit ini di rumah sendiri,oke!.

