---
description: "Cara membuat Nasi bakar ayam suwir daun kemangi yang lezat Untuk Jualan"
title: "Cara membuat Nasi bakar ayam suwir daun kemangi yang lezat Untuk Jualan"
slug: 47-cara-membuat-nasi-bakar-ayam-suwir-daun-kemangi-yang-lezat-untuk-jualan
date: 2021-05-29T02:14:27.802Z
image: https://img-global.cpcdn.com/recipes/cea937b560b2df8a/680x482cq70/nasi-bakar-ayam-suwir-daun-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/cea937b560b2df8a/680x482cq70/nasi-bakar-ayam-suwir-daun-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/cea937b560b2df8a/680x482cq70/nasi-bakar-ayam-suwir-daun-kemangi-foto-resep-utama.jpg
author: Willie Vaughn
ratingvalue: 4.2
reviewcount: 5
recipeingredient:
- " Bahan nasi gurih "
- "500 gr beras Punel"
- "360 santan cair sesuaikan dengan beras"
- " Bumbu halus "
- "2 siung bawang putih"
- "5 siung bawang merah"
- "1 batang serai geprak"
- "3 lembar daun jeruk"
- "3 lembar daun salam"
- "Secukupnya daun pandan"
- "Secukupnya daun salam"
- "Secukupnya garam"
- "Secukupnya totole"
- "Secukupnya penyedap rasa  kaldu"
- "Secukupnya royco"
- " Bahan bumbu ayam suwir "
- "1/2 kg dada ayam fillet"
- "3 siung bawang putih"
- "5 siung bawang merah"
- "2 biji cabai merah"
- "20 biji cabai rawit"
- "1 buah laos memarkan"
- "Secukupnya royco"
- "Secukupnya garam"
- "Secukupnya penyedap rasa"
- "Secukupnya lada bubuk"
- "Secukupnya kemangi"
- "Secukupnya daun pisang yang muda dan jangan terlalu tua"
recipeinstructions:
- "BAHAN NASI GURIH : Cuci bersih beras dan semua bahan sisihkan"
- "Haluskan semua bumbu yang sudah di siapkan.peras santan sekalian"
- "Siapkan panci yang sudah berisi beras masukkan santan dan tambahkan bumbu yang sudah di siapkan daun salam daun jeruk serai tambahkan garam royco penyedap rasa dan totole aduk aduk hingga tercampur rata (jika sudah komplit masuk semua lalu nyalakan kompor) sambil diaduk rata ya biar tidak gosong bawah nya jika sudah setengah matang pindahkan ke dandang kemudian masak hingga matang sisihkan dinginkan (bisa di masak di magicom juga ya)"
- "BAHAN BUMBU AYAM SUWIR : cuci bersih daging ayam rebus hingga matang dinginkan kemudian suwir suwir tiriskan"
- "Haluskan semua bumbu yang sudah disiapkan laos memarkan"
- "Panaskan penggorengan dengan secukupnya minyak tumis bumbu hingga harum masukkan sedikit air mendidih pertama tambahkan sedikit gula garam Royco dan penyedap rasa mendidih kedua masukkan ayam yang sudah disuwir aduk aduk rata tunggu hingga mendidih merata dan empuk check rasa"
- "Pipihkan daun pisang"
- "Siapkan daun pisang yang sudah di pipihkan tata nasi dan suwiran ayam tambahkan cabai rawit di atasnya kemudian bungkus seperti membungkus lontong lalu lipat bagian ujungnya rapikan dan pastikan udah rapat sematkan tusuk gigi di bagian ujungnya gunting kelebihannya supaya lebih rapi"
- "Panggang nasi diatas pemanggang arang / teflon atau oven panggang nasi bakar hingga daun berubah berwarna hitam kecoklatan tiriskan"
- "Siap di sajikan"
- "Nb : saran saya lebih tepatnya di panggang pakai arang saja ya. bau dan aromanya lebih khas Jawa bangedt.jika di panggang diatas teflon atopun oven. rasa dan baunya berbeda sama yang dipanggang dengan arang.pokoknya recomendded pakai arang ya"
categories:
- Resep
tags:
- nasi
- bakar
- ayam

katakunci: nasi bakar ayam 
nutrition: 111 calories
recipecuisine: Indonesian
preptime: "PT37M"
cooktime: "PT35M"
recipeyield: "4"
recipecategory: Lunch

---


![Nasi bakar ayam suwir daun kemangi](https://img-global.cpcdn.com/recipes/cea937b560b2df8a/680x482cq70/nasi-bakar-ayam-suwir-daun-kemangi-foto-resep-utama.jpg)

Apabila kita seorang istri, mempersiapkan olahan enak pada keluarga tercinta merupakan hal yang mengasyikan untuk kita sendiri. Kewajiban seorang istri bukan saja menangani rumah saja, tetapi kamu pun wajib memastikan keperluan nutrisi terpenuhi dan hidangan yang dimakan keluarga tercinta wajib nikmat.

Di masa  saat ini, kalian sebenarnya mampu memesan panganan instan walaupun tidak harus capek memasaknya lebih dulu. Tetapi banyak juga lho mereka yang memang mau memberikan hidangan yang terbaik bagi keluarganya. Sebab, memasak yang diolah sendiri jauh lebih higienis dan bisa menyesuaikan hidangan tersebut berdasarkan selera orang tercinta. 

Ambil nasi, letakkan diatas daun pisang lalu ratakan. Masukkan ayam suwir secukupnya, lalu gulung perlahan. Sematkan lidi di ujung nasi bakar.

Apakah anda adalah salah satu penyuka nasi bakar ayam suwir daun kemangi?. Asal kamu tahu, nasi bakar ayam suwir daun kemangi adalah hidangan khas di Indonesia yang sekarang disenangi oleh banyak orang dari hampir setiap daerah di Indonesia. Kamu dapat memasak nasi bakar ayam suwir daun kemangi buatan sendiri di rumahmu dan boleh jadi hidangan kesukaanmu di hari libur.

Anda tak perlu bingung jika kamu ingin menyantap nasi bakar ayam suwir daun kemangi, karena nasi bakar ayam suwir daun kemangi gampang untuk dicari dan juga kita pun dapat memasaknya sendiri di tempatmu. nasi bakar ayam suwir daun kemangi bisa dimasak memalui bermacam cara. Saat ini ada banyak sekali cara modern yang menjadikan nasi bakar ayam suwir daun kemangi semakin lezat.

Resep nasi bakar ayam suwir daun kemangi pun mudah sekali untuk dibuat, lho. Kita tidak usah repot-repot untuk membeli nasi bakar ayam suwir daun kemangi, tetapi Kita mampu membuatnya di rumah sendiri. Bagi Kita yang hendak mencobanya, inilah cara untuk membuat nasi bakar ayam suwir daun kemangi yang lezat yang mampu Kita hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Nasi bakar ayam suwir daun kemangi:

1. Gunakan  Bahan nasi gurih :
1. Siapkan 500 gr beras Punel
1. Gunakan 360 santan cair (sesuaikan dengan beras)
1. Gunakan  Bumbu halus :
1. Ambil 2 siung bawang putih
1. Ambil 5 siung bawang merah
1. Siapkan 1 batang serai (geprak)
1. Ambil 3 lembar daun jeruk
1. Sediakan 3 lembar daun salam
1. Gunakan Secukupnya daun pandan
1. Gunakan Secukupnya daun salam
1. Ambil Secukupnya garam
1. Sediakan Secukupnya totole
1. Ambil Secukupnya penyedap rasa / kaldu
1. Gunakan Secukupnya royco
1. Ambil  Bahan bumbu ayam suwir :
1. Gunakan 1/2 kg dada ayam (fillet)
1. Siapkan 3 siung bawang putih
1. Siapkan 5 siung bawang merah
1. Siapkan 2 biji cabai merah
1. Ambil 20 biji cabai rawit
1. Sediakan 1 buah laos (memarkan)
1. Sediakan Secukupnya royco
1. Ambil Secukupnya garam
1. Siapkan Secukupnya penyedap rasa
1. Siapkan Secukupnya lada bubuk
1. Ambil Secukupnya kemangi
1. Sediakan Secukupnya daun pisang (yang muda dan jangan terlalu tua)


Nasi bakar adalah masakan khas Indonesia yang bisa dijumpai dimana saja, terutama Pulau Jawa. Aroma harum dari nasi dibungkus daun pisang yang dibakar semakin nikmat saat dipadu ayam kemangi. Rebus ayam dengan selembar daun salam hingga matang. Tambahkan ayam suwir, daun jeruk, serta kemangi. 

<!--inarticleads2-->

##### Langkah-langkah menyiapkan Nasi bakar ayam suwir daun kemangi:

1. BAHAN NASI GURIH : Cuci bersih beras dan semua bahan sisihkan
1. Haluskan semua bumbu yang sudah di siapkan.peras santan sekalian
1. Siapkan panci yang sudah berisi beras masukkan santan dan tambahkan bumbu yang sudah di siapkan daun salam daun jeruk serai tambahkan garam royco penyedap rasa dan totole aduk aduk hingga tercampur rata (jika sudah komplit masuk semua lalu nyalakan kompor) sambil diaduk rata ya biar tidak gosong bawah nya jika sudah setengah matang pindahkan ke dandang kemudian masak hingga matang sisihkan dinginkan (bisa di masak di magicom juga ya)
1. BAHAN BUMBU AYAM SUWIR : cuci bersih daging ayam rebus hingga matang dinginkan kemudian suwir suwir tiriskan
1. Haluskan semua bumbu yang sudah disiapkan laos memarkan
1. Panaskan penggorengan dengan secukupnya minyak tumis bumbu hingga harum masukkan sedikit air mendidih pertama tambahkan sedikit gula garam Royco dan penyedap rasa mendidih kedua masukkan ayam yang sudah disuwir aduk aduk rata tunggu hingga mendidih merata dan empuk check rasa
1. Pipihkan daun pisang
1. Siapkan daun pisang yang sudah di pipihkan tata nasi dan suwiran ayam tambahkan cabai rawit di atasnya kemudian bungkus seperti membungkus lontong lalu lipat bagian ujungnya rapikan dan pastikan udah rapat sematkan tusuk gigi di bagian ujungnya gunting kelebihannya supaya lebih rapi
1. Panggang nasi diatas pemanggang arang / teflon atau oven panggang nasi bakar hingga daun berubah berwarna hitam kecoklatan tiriskan
1. Siap di sajikan
1. Nb : saran saya lebih tepatnya di panggang pakai arang saja ya. bau dan aromanya lebih khas Jawa bangedt.jika di panggang diatas teflon atopun oven. rasa dan baunya berbeda sama yang dipanggang dengan arang.pokoknya recomendded pakai arang ya


Tambahkan sedikit air agar bumbu tidak kering, masukkan garam, gula, kecap, serta penyedap rasa. Ambil potongan daun pisang, letakkan nasi lalu pipihkan dan masukkan tumisan ayam suwir kemudian gulung seperti anda membungkus lontong. Nasi bakar ayam kemangi siap disajikan selagi hangat. Nasi bakar merupakan nasi uduk yang diberi isian lalu dibungkus daun pisang dan dibakar. Rasanya yang khas dan wangi daun kemanginya membuat makanan yang satu ini begitu menggugah selera. 

Ternyata cara buat nasi bakar ayam suwir daun kemangi yang mantab tidak ribet ini mudah banget ya! Kita semua mampu membuatnya. Resep nasi bakar ayam suwir daun kemangi Cocok sekali untuk kamu yang baru belajar memasak atau juga bagi kalian yang sudah jago memasak.

Tertarik untuk mulai mencoba bikin resep nasi bakar ayam suwir daun kemangi mantab tidak rumit ini? Kalau kalian tertarik, yuk kita segera buruan siapkan peralatan dan bahannya, lantas buat deh Resep nasi bakar ayam suwir daun kemangi yang nikmat dan tidak ribet ini. Benar-benar gampang kan. 

Jadi, ketimbang kamu diam saja, hayo kita langsung hidangkan resep nasi bakar ayam suwir daun kemangi ini. Pasti kamu tiidak akan nyesel bikin resep nasi bakar ayam suwir daun kemangi lezat sederhana ini! Selamat mencoba dengan resep nasi bakar ayam suwir daun kemangi mantab simple ini di rumah kalian masing-masing,ya!.

