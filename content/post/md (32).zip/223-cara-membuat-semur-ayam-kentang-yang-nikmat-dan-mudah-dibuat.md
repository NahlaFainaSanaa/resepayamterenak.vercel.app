---
description: "Cara membuat Semur ayam kentang yang nikmat dan Mudah Dibuat"
title: "Cara membuat Semur ayam kentang yang nikmat dan Mudah Dibuat"
slug: 223-cara-membuat-semur-ayam-kentang-yang-nikmat-dan-mudah-dibuat
date: 2021-04-24T03:45:21.788Z
image: https://img-global.cpcdn.com/recipes/750ef24491a86325/680x482cq70/semur-ayam-kentang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/750ef24491a86325/680x482cq70/semur-ayam-kentang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/750ef24491a86325/680x482cq70/semur-ayam-kentang-foto-resep-utama.jpg
author: Wesley Butler
ratingvalue: 3.3
reviewcount: 14
recipeingredient:
- "1/2 kg filet dada"
- "3 buah kentang besar"
- "5 buah Cabe merah keriting"
- "10 buah cengek domba"
- "3 buah bawang putih"
- "4 buah bawang merah"
- "250 ml air putih"
- " Bumbu penyedap sesuai selera saya pakai royko totole kecap asin kecap manis gula pasir"
recipeinstructions:
- "Potong kecil” semua bahan termasuk ayam dan kentang d potong dadu kecil"
- "Goreng kentang terlebih dahulu, setelah itu tumis ayam sampai berwarna putih matang"
- "Oseng bawang putih dan merah lalu masukan air, kentang yang sudah d goreng, dan ayam"
- "Masukan cabe dan cengek lalu masukan bumbu penyedap rasa semua nya"
- "Gunakan api yang cukup besar agar bumbu cepat menyerap, tunggu hingga air menyusut lalu koreksi rasa (kurang lebih diamkan 30 mnt untuk menunggu bumbu menyerap)"
categories:
- Resep
tags:
- semur
- ayam
- kentang

katakunci: semur ayam kentang 
nutrition: 131 calories
recipecuisine: Indonesian
preptime: "PT30M"
cooktime: "PT50M"
recipeyield: "3"
recipecategory: Lunch

---


![Semur ayam kentang](https://img-global.cpcdn.com/recipes/750ef24491a86325/680x482cq70/semur-ayam-kentang-foto-resep-utama.jpg)

Selaku seorang orang tua, mempersiapkan masakan nikmat untuk keluarga merupakan hal yang menyenangkan untuk anda sendiri. Peran seorang ibu bukan cuma menjaga rumah saja, namun kamu juga harus memastikan keperluan nutrisi terpenuhi dan juga panganan yang disantap anak-anak harus nikmat.

Di zaman  sekarang, kalian sebenarnya mampu mengorder panganan siap saji tidak harus capek membuatnya lebih dulu. Tapi banyak juga lho mereka yang selalu mau memberikan yang terlezat bagi orang yang dicintainya. Pasalnya, memasak yang diolah sendiri jauh lebih bersih dan kita juga bisa menyesuaikan masakan tersebut sesuai dengan selera orang tercinta. 



Apakah anda adalah seorang penikmat semur ayam kentang?. Tahukah kamu, semur ayam kentang merupakan hidangan khas di Nusantara yang saat ini disukai oleh setiap orang dari berbagai daerah di Nusantara. Kamu dapat membuat semur ayam kentang buatan sendiri di rumahmu dan dapat dijadikan makanan kegemaranmu di hari liburmu.

Anda jangan bingung jika kamu ingin memakan semur ayam kentang, sebab semur ayam kentang gampang untuk dicari dan juga kamu pun dapat membuatnya sendiri di rumah. semur ayam kentang bisa dibuat memalui beragam cara. Saat ini telah banyak banget cara modern yang membuat semur ayam kentang lebih nikmat.

Resep semur ayam kentang pun sangat mudah dibikin, lho. Anda tidak perlu repot-repot untuk membeli semur ayam kentang, karena Anda mampu menghidangkan di rumah sendiri. Bagi Kalian yang ingin mencobanya, berikut resep membuat semur ayam kentang yang mantab yang bisa Kamu hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Semur ayam kentang:

1. Gunakan 1/2 kg filet dada
1. Ambil 3 buah kentang besar
1. Siapkan 5 buah Cabe merah keriting
1. Sediakan 10 buah cengek domba
1. Gunakan 3 buah bawang putih
1. Sediakan 4 buah bawang merah
1. Ambil 250 ml air putih
1. Sediakan  Bumbu penyedap sesuai selera (saya pakai royko, totole, kecap asin, kecap manis, gula pasir)




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Semur ayam kentang:

1. Potong kecil” semua bahan termasuk ayam dan kentang d potong dadu kecil
1. Goreng kentang terlebih dahulu, setelah itu tumis ayam sampai berwarna putih matang
1. Oseng bawang putih dan merah lalu masukan air, kentang yang sudah d goreng, dan ayam
1. Masukan cabe dan cengek lalu masukan bumbu penyedap rasa semua nya
1. Gunakan api yang cukup besar agar bumbu cepat menyerap, tunggu hingga air menyusut lalu koreksi rasa (kurang lebih diamkan 30 mnt untuk menunggu bumbu menyerap)




Ternyata cara membuat semur ayam kentang yang mantab simple ini enteng banget ya! Kamu semua dapat memasaknya. Cara buat semur ayam kentang Sesuai banget buat kamu yang baru akan belajar memasak atau juga untuk kalian yang sudah pandai dalam memasak.

Tertarik untuk mulai mencoba bikin resep semur ayam kentang mantab sederhana ini? Kalau kalian mau, yuk kita segera buruan siapin alat dan bahan-bahannya, lantas bikin deh Resep semur ayam kentang yang mantab dan simple ini. Betul-betul mudah kan. 

Oleh karena itu, ketimbang kita berlama-lama, yuk kita langsung buat resep semur ayam kentang ini. Pasti kalian tak akan menyesal sudah bikin resep semur ayam kentang mantab tidak rumit ini! Selamat berkreasi dengan resep semur ayam kentang lezat tidak ribet ini di tempat tinggal masing-masing,oke!.

