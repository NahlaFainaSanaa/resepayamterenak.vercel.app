---
description: "Bahan-bahan Kari ayam yang enak Untuk Jualan"
title: "Bahan-bahan Kari ayam yang enak Untuk Jualan"
slug: 421-bahan-bahan-kari-ayam-yang-enak-untuk-jualan
date: 2021-02-10T00:15:52.575Z
image: https://img-global.cpcdn.com/recipes/88a32ae6d591a924/680x482cq70/kari-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/88a32ae6d591a924/680x482cq70/kari-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/88a32ae6d591a924/680x482cq70/kari-ayam-foto-resep-utama.jpg
author: Jim Hudson
ratingvalue: 3.9
reviewcount: 4
recipeingredient:
- "500 gr ayam"
- "3 buah kentang"
- "1 buah bawang merah"
- "6 butir cengkeh"
- "1 buah bunga lawang"
- "2 btg kayu manis"
- "3 butir kapulaga"
- "250 gr bumbu kari ayam"
- "3 sdm bumbu babas ayam"
- "1/2 sdm jahe giling"
- "1/2 sdm bawang putih giling"
- "1 sdm bawang merah giling"
- "1 buah tomat"
- "Secukupnya garam"
- "Secukupnya kaldu jamur"
- "Secukupnya santan encer dan kental"
- "Secukupnya daun ketumbar"
recipeinstructions:
- "Potong bawang merah lalu cuci bawang, cengkeh, bunga lawang, kayumanis, dan kapulaga"
- "Cuci bersih ayam"
- "Kemudian potong kentang bela 4 lalu cuci bersih"
- "Tumis bawang, cengkeh, kayu manis, kapulaga, bunga lawang tumis hingga harum"
- "Masukan bumbu kari aduk hingga rata"
- "Masukan jahe giling aduk hingga rata"
- "Masukan bawang merah giling aduk hingga rata"
- "Masukan bawang putih giling aduk hingga rata"
- "Masukan bumbu babas aduk hingga rata"
- "Masukan tomat aduk hingga rata"
- "Masak hingga bumbu keluar minyak"
- "Lalu masukan ayam dan kentang aduk hingga rata"
- "Lalu masukan garam dan kaldu jamur aduk hingga rata"
- "Masukan santan encer aduk hingga rata"
- "Masak hingga mendidih dan ayam kentangbya matang ± 20 menit"
- "Jika sudah mendidih masukan santan kental masak ± 3 menit masukan daun ketumbar"
- "Aduk hingga rata lalu matikan kompor kari ayam siap dihidangkan"
categories:
- Resep
tags:
- kari
- ayam

katakunci: kari ayam 
nutrition: 225 calories
recipecuisine: Indonesian
preptime: "PT14M"
cooktime: "PT55M"
recipeyield: "1"
recipecategory: Lunch

---


![Kari ayam](https://img-global.cpcdn.com/recipes/88a32ae6d591a924/680x482cq70/kari-ayam-foto-resep-utama.jpg)

Apabila kamu seorang wanita, menyajikan masakan nikmat bagi famili adalah suatu hal yang memuaskan untuk kamu sendiri. Peran seorang ibu Tidak cuman menangani rumah saja, tapi anda juga wajib menyediakan keperluan gizi terpenuhi dan juga panganan yang dikonsumsi orang tercinta wajib mantab.

Di masa  sekarang, kalian memang mampu memesan panganan siap saji tidak harus capek membuatnya dahulu. Tetapi ada juga mereka yang selalu mau memberikan hidangan yang terenak bagi orang tercintanya. Pasalnya, menyajikan masakan sendiri jauh lebih higienis dan kita pun bisa menyesuaikan sesuai dengan makanan kesukaan orang tercinta. 

Resep Kari Ayam - Kari ayam merupakan salah satu makanan khas yang memiliki rasa berbeda-beda di setiap negara. Dengan rasanya yang cocok hampir di semua lidah, tentu sajian ini sangat pas. Kari ayam merupakan salah satu hidangan khas Asia Tenggara.

Mungkinkah anda adalah seorang penggemar kari ayam?. Asal kamu tahu, kari ayam merupakan hidangan khas di Nusantara yang kini digemari oleh orang-orang dari hampir setiap tempat di Nusantara. Kita bisa menghidangkan kari ayam sendiri di rumahmu dan pasti jadi makanan favoritmu di hari libur.

Kita jangan bingung untuk mendapatkan kari ayam, sebab kari ayam gampang untuk ditemukan dan juga anda pun bisa menghidangkannya sendiri di tempatmu. kari ayam dapat dimasak dengan beraneka cara. Sekarang sudah banyak resep modern yang menjadikan kari ayam lebih enak.

Resep kari ayam pun mudah dihidangkan, lho. Kamu tidak perlu capek-capek untuk memesan kari ayam, sebab Kalian bisa menyajikan sendiri di rumah. Untuk Kamu yang hendak menghidangkannya, dibawah ini merupakan cara untuk membuat kari ayam yang mantab yang dapat Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Kari ayam:

1. Ambil 500 gr ayam
1. Ambil 3 buah kentang
1. Ambil 1 buah bawang merah
1. Gunakan 6 butir cengkeh
1. Ambil 1 buah bunga lawang
1. Ambil 2 btg kayu manis
1. Siapkan 3 butir kapulaga
1. Ambil 250 gr bumbu kari ayam
1. Sediakan 3 sdm bumbu babas ayam
1. Sediakan 1/2 sdm jahe giling
1. Gunakan 1/2 sdm bawang putih giling
1. Siapkan 1 sdm bawang merah giling
1. Gunakan 1 buah tomat
1. Siapkan Secukupnya garam
1. Siapkan Secukupnya kaldu jamur
1. Ambil Secukupnya santan encer dan kental
1. Ambil Secukupnya daun ketumbar


Masakan ini terdiri dari daging ayam dengan diberi bumbu rempah seperti lengkuas, merica, jahe, kunyit, ketumbar dan sebagainya. Berikut ini Merdeka.com punya resep kari ayam yang populer sebagai makanan rumahan di Indonesia. Selain ayam, Anda juga bisa mengganti bahan utamanya dengan tahu, telur, daging, atau kepiting. Kari ayam merupakan salah satu hidangan khas Nusantara. 

<!--inarticleads2-->

##### Cara menyiapkan Kari ayam:

1. Potong bawang merah lalu cuci bawang, cengkeh, bunga lawang, kayumanis, dan kapulaga
1. Cuci bersih ayam
1. Kemudian potong kentang bela 4 lalu cuci bersih
1. Tumis bawang, cengkeh, kayu manis, kapulaga, bunga lawang tumis hingga harum
1. Masukan bumbu kari aduk hingga rata
1. Masukan jahe giling aduk hingga rata
1. Masukan bawang merah giling aduk hingga rata
1. Masukan bawang putih giling aduk hingga rata
1. Masukan bumbu babas aduk hingga rata
1. Masukan tomat aduk hingga rata
1. Masak hingga bumbu keluar minyak
1. Lalu masukan ayam dan kentang aduk hingga rata
1. Lalu masukan garam dan kaldu jamur aduk hingga rata
1. Masukan santan encer aduk hingga rata
1. Masak hingga mendidih dan ayam kentangbya matang ± 20 menit
1. Jika sudah mendidih masukan santan kental masak ± 3 menit masukan daun ketumbar
1. Aduk hingga rata lalu matikan kompor kari ayam siap dihidangkan


HIdangan ini mempunyai rasa yang cukup gurih yang berasal dari santan dan bumbu rempah yang digunakan. Kari ayam is a chicken curry that is popular in Malaysia and Indonesia. It is made with chicken pieces, onions, garlic, ginger In Malaysia, kari ayam is traditionally prepared in a clay pot, because it is not. Sebutan kari ayam atau kare ayam dan juga ayam kari. Ini merupakan masakan khas yang dihidangkan secara umum di negara-negara asia tenggara, asia selatan dan juga Carribean. 

Wah ternyata cara buat kari ayam yang enak sederhana ini mudah sekali ya! Anda Semua dapat menghidangkannya. Cara buat kari ayam Sangat cocok banget buat kamu yang baru akan belajar memasak maupun juga bagi kalian yang telah lihai dalam memasak.

Apakah kamu ingin mencoba bikin resep kari ayam enak sederhana ini? Kalau ingin, ayo kamu segera buruan siapkan alat-alat dan bahannya, maka buat deh Resep kari ayam yang enak dan tidak rumit ini. Benar-benar mudah kan. 

Jadi, daripada anda diam saja, yuk kita langsung saja hidangkan resep kari ayam ini. Pasti kalian gak akan menyesal sudah bikin resep kari ayam nikmat tidak rumit ini! Selamat berkreasi dengan resep kari ayam enak sederhana ini di tempat tinggal sendiri,oke!.

