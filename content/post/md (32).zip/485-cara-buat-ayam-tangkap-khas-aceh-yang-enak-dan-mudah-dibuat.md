---
description: "Cara buat Ayam Tangkap (khas Aceh) yang enak dan Mudah Dibuat"
title: "Cara buat Ayam Tangkap (khas Aceh) yang enak dan Mudah Dibuat"
slug: 485-cara-buat-ayam-tangkap-khas-aceh-yang-enak-dan-mudah-dibuat
date: 2021-06-17T21:25:21.341Z
image: https://img-global.cpcdn.com/recipes/0f04089760a59d46/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0f04089760a59d46/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0f04089760a59d46/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg
author: Emilie Kelley
ratingvalue: 3.1
reviewcount: 9
recipeingredient:
- "1 ekor ayam sy ukuran 1 kg potong2 kecil sesuai selera"
- "1 buah jeruk nipis ambil airnya           lihat tips"
- "3 sdm air asam jawa dari 3 mata asam"
- "2 sdt garam sesuai selera"
- "300 ml air kelapa dr 1 butir kelapa"
- "Secukupnya minyak goreng"
- " Bumbu yang dihaluskan "
- "6 siung bawang merah"
- "3 siung bawang putih"
- "5-8 buah cabai rawit hijau opsional"
- "1 sdt kunyit bubuk"
- "1/2 sdt merica bubuk"
- "1 ruas jari jahe"
- " Bahan rempah daun yang digoreng "
- "10 tangkai daun kari ambil daunnya"
- "7 lembar daun pandan potongpotong 3 cm"
- "8 buah cabai hijau potong jadi 3 bagian"
- "8 siung bawang merah irisiris tipis"
recipeinstructions:
- "Cuci bersih ayam, tiriskan, beri air jeruk nipis (dari 1/2 buah), diamkan beberapa saat, kmdn bilas kembali, tiriskan.  Siapkan juga bahan bumbu halus dan bahan rempah daunnya yang sudah diiris/dipotong2.   Blender bumbu yg akan dihaluskan. Sisihkan"
- "Masukkan ayam ke dlm wajan, balur ayam dengan garam dan campuran air jeruk nipis (dari 1/2 buah jeruk nipis) + 3 sdm air asam jawa  Masukkan bumbu halus ke dalam ayam, ratakan. Tambahkan air kelapa, adukrata    Note: jika menggunakan ayam kampung, banyaknya air kelapa bisa disesuaikan, smpai ayam kampung bisa empuk."
- "Kemdian tutup wajan, ungkep ayam sampai air menyusut dan bumbunya meresap. Sisihkan"
- "Panaskan minyak goreng (minyak hrs cukup banyak), goreng ayam dgn api sedang, kemudian balik ayam. Setelah ayam mulai berwarna kecoklatan, masukkan daun kari, daun pandan, cabai hijau dan bawang merah iris.  Goreng sampai ayam berwarna kecoklatan dan rempah daunnya kering serta bawang merahnya kecoklatan.   Note: Saya 2X goreng, jadi rempah daunnya dibagi 2."
- "Setelah ayam matang berwarna kuning kecoklatan dan rempah daun kering, angkat dan tiriskan."
- "Sajikan ayam bersama rempah daun kering, cabai hijau dan bawang goreng keringnya. Ayam ini enak disajikan saat panas-panas, sehingga rempah daunnya masih kriuk kayak kerupuk."
categories:
- Resep
tags:
- ayam
- tangkap
- khas

katakunci: ayam tangkap khas 
nutrition: 139 calories
recipecuisine: Indonesian
preptime: "PT35M"
cooktime: "PT43M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Tangkap (khas Aceh)](https://img-global.cpcdn.com/recipes/0f04089760a59d46/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg)

Selaku seorang yang hobi masak, menyediakan panganan enak pada keluarga tercinta merupakan hal yang sangat menyenangkan bagi kita sendiri. Kewajiban seorang ibu bukan sekadar mengurus rumah saja, tapi anda pun wajib memastikan keperluan nutrisi terpenuhi dan juga panganan yang dimakan anak-anak mesti menggugah selera.

Di masa  sekarang, kalian memang bisa mengorder olahan instan meski tidak harus ribet mengolahnya dahulu. Tapi banyak juga lho orang yang memang ingin memberikan hidangan yang terlezat untuk orang tercintanya. Karena, menyajikan masakan yang dibuat sendiri jauh lebih bersih dan kita pun bisa menyesuaikan hidangan tersebut berdasarkan kesukaan famili. 



Mungkinkah anda salah satu penggemar ayam tangkap (khas aceh)?. Tahukah kamu, ayam tangkap (khas aceh) merupakan hidangan khas di Nusantara yang sekarang digemari oleh orang-orang di berbagai tempat di Nusantara. Anda dapat memasak ayam tangkap (khas aceh) kreasi sendiri di rumahmu dan pasti jadi camilan kesenanganmu di hari libur.

Kamu tak perlu bingung untuk mendapatkan ayam tangkap (khas aceh), lantaran ayam tangkap (khas aceh) tidak sulit untuk ditemukan dan juga kita pun bisa mengolahnya sendiri di tempatmu. ayam tangkap (khas aceh) bisa diolah memalui berbagai cara. Kini telah banyak sekali cara modern yang membuat ayam tangkap (khas aceh) semakin lebih enak.

Resep ayam tangkap (khas aceh) juga gampang sekali untuk dibuat, lho. Kamu jangan ribet-ribet untuk memesan ayam tangkap (khas aceh), sebab Kalian bisa menghidangkan di rumah sendiri. Untuk Kalian yang ingin mencobanya, berikut cara untuk membuat ayam tangkap (khas aceh) yang lezat yang bisa Kalian coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Ayam Tangkap (khas Aceh):

1. Siapkan 1 ekor ayam /sy ukuran 1 kg (potong2 kecil sesuai selera)
1. Gunakan 1 buah jeruk nipis, ambil airnya           (lihat tips)
1. Siapkan 3 sdm air asam jawa (dari 3 mata asam)
1. Sediakan 2 sdt garam (sesuai selera)
1. Gunakan 300 ml air kelapa (dr 1 butir kelapa)
1. Ambil Secukupnya minyak goreng
1. Ambil  ⏩Bumbu yang dihaluskan :
1. Sediakan 6 siung bawang merah
1. Ambil 3 siung bawang putih
1. Sediakan 5-8 buah cabai rawit hijau (opsional)
1. Siapkan 1 sdt kunyit bubuk
1. Ambil 1/2 sdt merica bubuk
1. Ambil 1 ruas jari jahe
1. Gunakan  ⏩Bahan rempah daun yang digoreng :
1. Ambil 10 tangkai daun kari, ambil daunnya
1. Siapkan 7 lembar daun pandan, potong-potong 3 cm
1. Siapkan 8 buah cabai hijau, potong jadi 3 bagian
1. Siapkan 8 siung bawang merah, iris-iris tipis




<!--inarticleads2-->

##### Cara menyiapkan Ayam Tangkap (khas Aceh):

1. Cuci bersih ayam, tiriskan, beri air jeruk nipis (dari 1/2 buah), diamkan beberapa saat, kmdn bilas kembali, tiriskan. -  - Siapkan juga bahan bumbu halus dan bahan rempah daunnya yang sudah diiris/dipotong2.  -  - Blender bumbu yg akan dihaluskan. Sisihkan
1. Masukkan ayam ke dlm wajan, balur ayam dengan garam dan campuran air jeruk nipis (dari 1/2 buah jeruk nipis) + 3 sdm air asam jawa -  - Masukkan bumbu halus ke dalam ayam, ratakan. Tambahkan air kelapa, adukrata  -  -  Note: jika menggunakan ayam kampung, banyaknya air kelapa bisa disesuaikan, smpai ayam kampung bisa empuk.
1. Kemdian tutup wajan, ungkep ayam sampai air menyusut dan bumbunya meresap. Sisihkan
1. Panaskan minyak goreng (minyak hrs cukup banyak), goreng ayam dgn api sedang, kemudian balik ayam. Setelah ayam mulai berwarna kecoklatan, masukkan daun kari, daun pandan, cabai hijau dan bawang merah iris. -  - Goreng sampai ayam berwarna kecoklatan dan rempah daunnya kering serta bawang merahnya kecoklatan.  -  - Note: Saya 2X goreng, jadi rempah daunnya dibagi 2.
1. Setelah ayam matang berwarna kuning kecoklatan dan rempah daun kering, angkat dan tiriskan.
1. Sajikan ayam bersama rempah daun kering, cabai hijau dan bawang goreng keringnya. Ayam ini enak disajikan saat panas-panas, sehingga rempah daunnya masih kriuk kayak kerupuk.




Ternyata resep ayam tangkap (khas aceh) yang enak tidak ribet ini gampang sekali ya! Kalian semua dapat memasaknya. Cara buat ayam tangkap (khas aceh) Sangat cocok banget buat anda yang baru mau belajar memasak maupun bagi anda yang sudah hebat dalam memasak.

Tertarik untuk mulai mencoba bikin resep ayam tangkap (khas aceh) nikmat tidak ribet ini? Kalau kamu tertarik, ayo kalian segera siapkan peralatan dan bahan-bahannya, kemudian bikin deh Resep ayam tangkap (khas aceh) yang lezat dan tidak ribet ini. Betul-betul taidak sulit kan. 

Maka, ketimbang kita diam saja, ayo kita langsung hidangkan resep ayam tangkap (khas aceh) ini. Pasti kamu tiidak akan menyesal membuat resep ayam tangkap (khas aceh) lezat tidak rumit ini! Selamat berkreasi dengan resep ayam tangkap (khas aceh) nikmat tidak rumit ini di rumah kalian sendiri,oke!.

