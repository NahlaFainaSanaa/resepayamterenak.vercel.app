---
description: "Cara membuat Ayam krispy ala kfc kriuk renyah dan tahan lama yang lezat dan Mudah Dibuat"
title: "Cara membuat Ayam krispy ala kfc kriuk renyah dan tahan lama yang lezat dan Mudah Dibuat"
slug: 102-cara-membuat-ayam-krispy-ala-kfc-kriuk-renyah-dan-tahan-lama-yang-lezat-dan-mudah-dibuat
date: 2021-04-18T07:10:27.012Z
image: https://img-global.cpcdn.com/recipes/203764cba15f4399/680x482cq70/ayam-krispy-ala-kfc-kriuk-renyah-dan-tahan-lama-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/203764cba15f4399/680x482cq70/ayam-krispy-ala-kfc-kriuk-renyah-dan-tahan-lama-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/203764cba15f4399/680x482cq70/ayam-krispy-ala-kfc-kriuk-renyah-dan-tahan-lama-foto-resep-utama.jpg
author: Floyd Peters
ratingvalue: 5
reviewcount: 14
recipeingredient:
- "1 ekor ayam uk  1kg"
- " Bumbu perendam "
- " Haluskan"
- "5-10 siung bawang putih"
- "2 buah cabe merah"
- "1 bungkus kaldu bubuk rasa ayam"
- "1 sendok teh merica bubuk"
- "1 sendok makan garam"
- "1 sendok makan ketumbar bubuk"
- "1 sendok teh cabai bubuk boleh skip"
- "1/2 sensok makan saus tiram"
- "1 butir telur kocok lepas dimasukan dibagian akhir setelah direndam"
- " Tepung kriuk"
- "400 gr terigu cakra  protein tinggi"
- "100 gr tepung maizena"
- "1 bungkus kaldu bubuk rasa ayam"
- "1 sendok makan bubuk cabai boleh dikurangidi skip"
- "1/2 sdt merica bubuk"
- "Secukupnya garam"
- " Bahan pelapis "
- "100 ml air"
- "3-4 cube es batu"
- "1 sendok teh soda kue"
- "5 sendok makan campuran tepung kriuk"
- " Minyak yang banyak untuk menggoreng dengan deep fried"
recipeinstructions:
- "Campur bumbu yang dihaluskan dengan bumbu perendam lainnya."
- "Siapkan ayam, tusuk-tusuk dengan garpu.. tambahkan campuran bumbu perendam. Remas-remas.. diamkan minimal 1 jam.. (rendam 1 malam didalam kulkas jika mau bumbunya lebih meresap)"
- "Siapkan campuran tepung kriuk.."
- "Siapkan campuran bumbu perendam"
- "Panaskan minyak, yang banyak ya. Supaya nnti ayamnya bisa terendam saat di goreng."
- "Siapkan ayam yang telah direndam. Masukan telur yang dikocok lepas. Aduk merata."
- "Masukan ayam ke dalam tepung kriuk. Remas remas sampai tepung menempel. Ketuk2 ayam kepinggiran baskom agar tepung yang tidak menempel akan jatuh."
- "Masukkan kedalam bumbu pelapis"
- "Masukkan lagi kedalam tepung kriuk. Remas-remas sambil di boleh balik sampai tepungnya menempel.."
- "Ketuk2 lagi dipinggir baskom sampai terbentuk kriwil-kriwilnya.."
- "Segera goreng dalam minyak panas yang banyak dengan api sedang. Ayam harus terendam semua didalam minyak ya. (emak pakai panci magic com kecil yang sudah tidak terpakai 😬😬)"
- "Goreng sampai kulit terlihat kuning kecoklatan. Pencet ayam dengan capit untuk memastikan sudah tidak lembek dan matang)"
- "Angkat dan tiriskan."
categories:
- Resep
tags:
- ayam
- krispy
- ala

katakunci: ayam krispy ala 
nutrition: 168 calories
recipecuisine: Indonesian
preptime: "PT15M"
cooktime: "PT41M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam krispy ala kfc kriuk renyah dan tahan lama](https://img-global.cpcdn.com/recipes/203764cba15f4399/680x482cq70/ayam-krispy-ala-kfc-kriuk-renyah-dan-tahan-lama-foto-resep-utama.jpg)

Sebagai seorang istri, menyediakan santapan lezat pada orang tercinta adalah hal yang memuaskan bagi anda sendiri. Tugas seorang ibu Tidak cuma menangani rumah saja, tetapi anda pun wajib memastikan keperluan gizi tercukupi dan juga panganan yang disantap keluarga tercinta mesti mantab.

Di waktu  saat ini, kalian memang mampu membeli masakan yang sudah jadi meski tanpa harus repot memasaknya dahulu. Namun ada juga mereka yang selalu ingin memberikan yang terlezat untuk orang tercintanya. Lantaran, menghidangkan masakan sendiri jauh lebih bersih dan kita juga bisa menyesuaikan hidangan tersebut sesuai dengan masakan kesukaan orang tercinta. 

Rahasia Ayam Crispy ala KFC, GA NYANGKA mirip banget, awet buat jualan. Tutorial Tanggal Tua by Ika Faza. Resep Ayam Crispy - Ayam crispy, ayam kentucky atau fried chicken merupakan makanan yang banyak digemari oleh masyarakat karena memiliki rasa yang enak dan renyah.

Apakah anda merupakan salah satu penggemar ayam krispy ala kfc kriuk renyah dan tahan lama?. Tahukah kamu, ayam krispy ala kfc kriuk renyah dan tahan lama adalah hidangan khas di Nusantara yang saat ini disukai oleh banyak orang dari berbagai daerah di Nusantara. Kita bisa menyajikan ayam krispy ala kfc kriuk renyah dan tahan lama sendiri di rumahmu dan pasti jadi makanan favoritmu di akhir pekan.

Kita jangan bingung untuk menyantap ayam krispy ala kfc kriuk renyah dan tahan lama, lantaran ayam krispy ala kfc kriuk renyah dan tahan lama mudah untuk ditemukan dan juga anda pun dapat memasaknya sendiri di rumah. ayam krispy ala kfc kriuk renyah dan tahan lama boleh dibuat dengan bermacam cara. Kini pun ada banyak banget resep modern yang menjadikan ayam krispy ala kfc kriuk renyah dan tahan lama lebih mantap.

Resep ayam krispy ala kfc kriuk renyah dan tahan lama pun mudah sekali dihidangkan, lho. Kamu jangan repot-repot untuk membeli ayam krispy ala kfc kriuk renyah dan tahan lama, sebab Kita dapat menghidangkan di rumah sendiri. Untuk Kamu yang ingin mencobanya, inilah cara untuk menyajikan ayam krispy ala kfc kriuk renyah dan tahan lama yang mantab yang bisa Kamu coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Ayam krispy ala kfc kriuk renyah dan tahan lama:

1. Sediakan 1 ekor ayam uk +/- 1kg
1. Siapkan  Bumbu perendam :
1. Ambil  Haluskan:
1. Gunakan 5-10 siung bawang putih
1. Gunakan 2 buah cabe merah
1. Sediakan 1 bungkus kaldu bubuk rasa ayam
1. Siapkan 1 sendok teh merica bubuk
1. Sediakan 1 sendok makan garam
1. Siapkan 1 sendok makan ketumbar bubuk
1. Ambil 1 sendok teh cabai bubuk (boleh skip)
1. Ambil 1/2 sensok makan saus tiram
1. Ambil 1 butir telur, kocok lepas (dimasukan dibagian akhir setelah direndam)
1. Sediakan  Tepung kriuk:
1. Gunakan 400 gr terigu cakra / protein tinggi
1. Siapkan 100 gr tepung maizena
1. Ambil 1 bungkus kaldu bubuk rasa ayam
1. Gunakan 1 sendok makan bubuk cabai (boleh dikurangi/di skip)
1. Ambil 1/2 sdt merica bubuk
1. Ambil Secukupnya garam
1. Gunakan  Bahan pelapis :
1. Ambil 100 ml air
1. Gunakan 3-4 cube es batu
1. Siapkan 1 sendok teh soda kue
1. Siapkan 5 sendok makan campuran tepung kriuk
1. Ambil  Minyak yang banyak untuk menggoreng dengan deep fried


Resep Ayam Crispy Ala Kfc Dijamin Renyah Tahan Lama Untuk Jualan Mantap. Resep Ayam Goreng Ala Kfc Kriuk Krispi Tahan Lama. Resep Ayam KFC adalah salah satu resep favorit didalam keluarga terutama anak-anak. Adapun cara membuat Resep Ayam KFC agar bisa kriuk-kriuk Sangat mudah kan ternyata membuat ayam KFC. 

<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam krispy ala kfc kriuk renyah dan tahan lama:

1. Campur bumbu yang dihaluskan dengan bumbu perendam lainnya.
1. Siapkan ayam, tusuk-tusuk dengan garpu.. tambahkan campuran bumbu perendam. Remas-remas.. diamkan minimal 1 jam.. (rendam 1 malam didalam kulkas jika mau bumbunya lebih meresap)
1. Siapkan campuran tepung kriuk..
1. Siapkan campuran bumbu perendam
1. Panaskan minyak, yang banyak ya. Supaya nnti ayamnya bisa terendam saat di goreng.
1. Siapkan ayam yang telah direndam. Masukan telur yang dikocok lepas. Aduk merata.
1. Masukan ayam ke dalam tepung kriuk. Remas remas sampai tepung menempel. Ketuk2 ayam kepinggiran baskom agar tepung yang tidak menempel akan jatuh.
1. Masukkan kedalam bumbu pelapis
1. Masukkan lagi kedalam tepung kriuk. Remas-remas sambil di boleh balik sampai tepungnya menempel..
1. Ketuk2 lagi dipinggir baskom sampai terbentuk kriwil-kriwilnya..
1. Segera goreng dalam minyak panas yang banyak dengan api sedang. Ayam harus terendam semua didalam minyak ya. (emak pakai panci magic com kecil yang sudah tidak terpakai 😬😬)
1. Goreng sampai kulit terlihat kuning kecoklatan. Pencet ayam dengan capit untuk memastikan sudah tidak lembek dan matang)
1. Angkat dan tiriskan.


Resep Ayam KFC kriuk-kriuk &amp; renyah ini memang sangat enak, gurih, renyah, dan garing kress. Tahu Crispy Ala Kfc Renyah Tahan Sampe Seharian How To Make Tofu Ala Kfc Crispy. Ayam Goreng Kremes Renyah Dan Gurih Cara Mudah Membuat Kremesan Ayam Yang Renyah. Resep Ayam Kentucky Renyah Tahan Lama. Resep Ayam Goreng Krispy Kfc Tanpa Marinasi Lama Jadi Keriting Banget. 

Ternyata cara buat ayam krispy ala kfc kriuk renyah dan tahan lama yang mantab tidak rumit ini gampang banget ya! Anda Semua mampu membuatnya. Resep ayam krispy ala kfc kriuk renyah dan tahan lama Cocok banget buat kita yang baru belajar memasak atau juga untuk kamu yang sudah hebat dalam memasak.

Tertarik untuk mulai mencoba bikin resep ayam krispy ala kfc kriuk renyah dan tahan lama lezat simple ini? Kalau anda tertarik, mending kamu segera menyiapkan alat-alat dan bahannya, lalu buat deh Resep ayam krispy ala kfc kriuk renyah dan tahan lama yang mantab dan simple ini. Sangat gampang kan. 

Jadi, daripada kalian berfikir lama-lama, maka langsung aja buat resep ayam krispy ala kfc kriuk renyah dan tahan lama ini. Dijamin kalian gak akan menyesal membuat resep ayam krispy ala kfc kriuk renyah dan tahan lama nikmat tidak rumit ini! Selamat mencoba dengan resep ayam krispy ala kfc kriuk renyah dan tahan lama mantab simple ini di rumah sendiri,ya!.

