---
description: "Cara buat Semur Ayam Kentang yang nikmat dan Mudah Dibuat"
title: "Cara buat Semur Ayam Kentang yang nikmat dan Mudah Dibuat"
slug: 235-cara-buat-semur-ayam-kentang-yang-nikmat-dan-mudah-dibuat
date: 2021-04-16T16:15:29.560Z
image: https://img-global.cpcdn.com/recipes/edad8796346f6310/680x482cq70/semur-ayam-kentang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/edad8796346f6310/680x482cq70/semur-ayam-kentang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/edad8796346f6310/680x482cq70/semur-ayam-kentang-foto-resep-utama.jpg
author: Marcus Wood
ratingvalue: 3
reviewcount: 14
recipeingredient:
- "1/2 kg daging ayam"
- "1 buah kentang yg besar"
- "1 ikat daun bawang iris tipis"
- "1 buah tomat iris tipis"
- "1 btg serai geprek"
- "2 lbr daun jeruk"
- "1/2 sdm lada bubuk"
- "Secukupnya kecap manis"
- "Secukupnya gula"
- "Secukupnya garam"
- "Secukupnya penyedap optional"
- "2 sdm bawang merah goreng"
- "Secukupnya air untuk kuah"
- " Bumbu Halus "
- "5 siung bawang putih"
- "7 btr bawang merah"
- "1 biji kemiri"
recipeinstructions:
- "Rebus ayam dan kentang sampai matang."
- "Haluskan bumbu halus.  Panaskan sedikit minyak dan tumis bumbu, masukkan lada bubuk, serai dan daun jeruk.  Tambahkan secukupnya air."
- "Jika sudah mendidih masukkan daging ayam, kentang dan semua bumbu&#34; lainya (kecuali bawang merah goreng).  Aduk dan cek rasa."
- "Jika sudah pas, matikan api dan taburkan bawang merah goreng.  Semur ayam dan kentang siap dinikmati.  Selamat mencoba :)"
categories:
- Resep
tags:
- semur
- ayam
- kentang

katakunci: semur ayam kentang 
nutrition: 286 calories
recipecuisine: Indonesian
preptime: "PT34M"
cooktime: "PT49M"
recipeyield: "3"
recipecategory: Dinner

---


![Semur Ayam Kentang](https://img-global.cpcdn.com/recipes/edad8796346f6310/680x482cq70/semur-ayam-kentang-foto-resep-utama.jpg)

Selaku seorang ibu, mempersiapkan olahan lezat untuk famili merupakan suatu hal yang membahagiakan untuk kita sendiri. Peran seorang  wanita bukan hanya menangani rumah saja, namun anda juga wajib menyediakan keperluan nutrisi terpenuhi dan juga masakan yang dikonsumsi anak-anak mesti menggugah selera.

Di era  sekarang, kita memang dapat mengorder masakan siap saji meski tanpa harus capek memasaknya dulu. Tapi banyak juga mereka yang memang mau menghidangkan yang terlezat bagi keluarganya. Karena, menghidangkan masakan yang diolah sendiri jauh lebih bersih dan kita pun bisa menyesuaikan sesuai dengan makanan kesukaan keluarga tercinta. 



Mungkinkah kamu salah satu penikmat semur ayam kentang?. Tahukah kamu, semur ayam kentang adalah makanan khas di Indonesia yang saat ini digemari oleh kebanyakan orang di berbagai tempat di Nusantara. Anda dapat menghidangkan semur ayam kentang sendiri di rumah dan boleh dijadikan camilan kegemaranmu di hari libur.

Kamu jangan bingung untuk mendapatkan semur ayam kentang, lantaran semur ayam kentang mudah untuk ditemukan dan kamu pun bisa membuatnya sendiri di rumah. semur ayam kentang dapat dimasak lewat beraneka cara. Sekarang sudah banyak cara kekinian yang menjadikan semur ayam kentang semakin lezat.

Resep semur ayam kentang pun mudah sekali dihidangkan, lho. Anda tidak usah ribet-ribet untuk memesan semur ayam kentang, karena Kamu bisa menyajikan ditempatmu. Untuk Anda yang akan menyajikannya, berikut ini cara untuk menyajikan semur ayam kentang yang mantab yang dapat Kamu coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Semur Ayam Kentang:

1. Siapkan 1/2 kg daging ayam
1. Gunakan 1 buah kentang yg besar
1. Sediakan 1 ikat daun bawang, iris tipis
1. Ambil 1 buah tomat, iris tipis
1. Gunakan 1 btg serai, geprek
1. Siapkan 2 lbr daun jeruk
1. Gunakan 1/2 sdm lada bubuk
1. Sediakan Secukupnya kecap manis
1. Ambil Secukupnya gula
1. Ambil Secukupnya garam
1. Ambil Secukupnya penyedap (optional)
1. Siapkan 2 sdm bawang merah goreng
1. Gunakan Secukupnya air untuk kuah
1. Ambil  Bumbu Halus ::
1. Siapkan 5 siung bawang putih
1. Sediakan 7 btr bawang merah
1. Siapkan 1 biji kemiri




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Semur Ayam Kentang:

1. Rebus ayam dan kentang sampai matang.
1. Haluskan bumbu halus.  - Panaskan sedikit minyak dan tumis bumbu, masukkan lada bubuk, serai dan daun jeruk.  - Tambahkan secukupnya air.
1. Jika sudah mendidih masukkan daging ayam, kentang dan semua bumbu&#34; lainya (kecuali bawang merah goreng).  - Aduk dan cek rasa.
1. Jika sudah pas, matikan api dan taburkan bawang merah goreng.  - Semur ayam dan kentang siap dinikmati.  - Selamat mencoba :)




Wah ternyata resep semur ayam kentang yang mantab sederhana ini mudah banget ya! Anda Semua mampu membuatnya. Cara Membuat semur ayam kentang Sangat sesuai banget untuk kamu yang baru akan belajar memasak maupun untuk kamu yang sudah pandai memasak.

Tertarik untuk mulai mencoba membikin resep semur ayam kentang enak tidak rumit ini? Kalau anda mau, ayo kamu segera buruan siapkan peralatan dan bahan-bahannya, setelah itu bikin deh Resep semur ayam kentang yang enak dan tidak rumit ini. Benar-benar taidak sulit kan. 

Jadi, ketimbang anda berfikir lama-lama, ayo kita langsung hidangkan resep semur ayam kentang ini. Dijamin anda tak akan nyesel sudah membuat resep semur ayam kentang lezat simple ini! Selamat mencoba dengan resep semur ayam kentang enak simple ini di rumah kalian sendiri,ya!.

