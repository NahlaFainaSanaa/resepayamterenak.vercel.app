---
description: "Resep Ayam tangkap khas Aceh yang lezat Untuk Jualan"
title: "Resep Ayam tangkap khas Aceh yang lezat Untuk Jualan"
slug: 488-resep-ayam-tangkap-khas-aceh-yang-lezat-untuk-jualan
date: 2021-02-08T22:49:28.190Z
image: https://img-global.cpcdn.com/recipes/2b122bcb026a7b5f/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2b122bcb026a7b5f/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2b122bcb026a7b5f/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg
author: Zachary Elliott
ratingvalue: 4.2
reviewcount: 13
recipeingredient:
- "1 ekor ayam kampung sy 500 gr ayam potong"
- "1 bh jeruk nipis ambil airnya sy jeruk cui"
- "3 sdm air asam jawa sy skip"
- "2 sdt garam sesuai selera sy 1 sdt"
- "300 ml air kelapa dr 1 bh kelapa"
- "Secukupnya minyak goreng"
- " Bumbu halus"
- "6 siung bawang merah"
- "3 siung bawang putih"
- "5-8 bh cabe rawit optional sy cabe merah"
- "1 sdt kunyit bubuk"
- "1/2 sdt merica bubuk"
- "1 ruas jari Jahe"
- " Bahan lain"
- "10 tangkai daun kari ambil daunnya"
- "7 lmbr daun pandan potong kecil kecil sy 4 lmbr"
- "8 bh cabe hijau sy 4 bh potong serong"
- "8 siung bawang merah iris tipis sy 4 siung"
recipeinstructions:
- "Potong-potong ayam, cuci bersih, tiriskan, beri air jeruk nipis, diamkan beberapa saat, lalu bilas kembali, tiriskan. Siapkan juga bumbu dan bahan rempah daunnya."
- "Masukkan bumbu yang sudah halus ke dalam ayam, ratakan. Tambahkan air kelapa, kmdn ungkep ayam sambil ditutup sampai air menyusut dan bumbu meresap.  Note: jika menggunakan ayam kampung, banyaknya air kelapa bisa disesuaikan."
- "Panaskan minyak goreng (minyak banyak), goreng ayam dgn api sedang, kemudian balik ayam. Setelah ayam mulai berwarna kecoklatan, masukkan daun kari, daun pandan, cabai hijau dan bawang merah iris. Goreng sampai ayam berwarna kecoklatan dan rempah daunnya kering serta bawang merahnya kecoklatan."
- "Setelah ayam matang berwarna kuning kecoklatan dan rempah daun kering, angkat dan tiriskan."
- "Sajikan ayam bersama rempah daun kering, cabai hijau dan bawang goreng keringnya. Ayam ini enak disajikan saat panas-panas, sehingga rempah daunnya masih kriuk."
categories:
- Resep
tags:
- ayam
- tangkap
- khas

katakunci: ayam tangkap khas 
nutrition: 267 calories
recipecuisine: Indonesian
preptime: "PT36M"
cooktime: "PT39M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam tangkap khas Aceh](https://img-global.cpcdn.com/recipes/2b122bcb026a7b5f/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg)

Sebagai seorang yang hobi memasak, menyediakan santapan sedap untuk famili adalah hal yang menyenangkan bagi kita sendiri. Tugas seorang  wanita Tidak hanya mengatur rumah saja, namun kamu juga wajib menyediakan keperluan nutrisi terpenuhi dan juga santapan yang dikonsumsi anak-anak mesti lezat.

Di era  sekarang, kalian sebenarnya bisa memesan olahan siap saji tanpa harus susah mengolahnya terlebih dahulu. Namun ada juga lho orang yang memang ingin memberikan hidangan yang terenak bagi keluarganya. Karena, menyajikan masakan yang dibuat sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan sesuai kesukaan keluarga. 

#resepmasakayamtangkap #ayamtangkapkhasacehResep masak Ayam tangkap khas aceh ini sudah sering di recook pastinya. Resep masak Ayam tangkap khas Aceh ini. Resep Ayam Tangkap Khas Aceh Sederhana Spesial Lembut dan Empuk Asli Enak.

Mungkinkah anda merupakan seorang penggemar ayam tangkap khas aceh?. Tahukah kamu, ayam tangkap khas aceh merupakan makanan khas di Nusantara yang sekarang disukai oleh banyak orang di berbagai daerah di Indonesia. Kalian dapat membuat ayam tangkap khas aceh sendiri di rumah dan boleh dijadikan camilan kesenanganmu di hari liburmu.

Kita tidak usah bingung jika kamu ingin memakan ayam tangkap khas aceh, lantaran ayam tangkap khas aceh tidak sulit untuk didapatkan dan kamu pun dapat memasaknya sendiri di rumah. ayam tangkap khas aceh bisa dibuat lewat beraneka cara. Kini pun telah banyak resep kekinian yang membuat ayam tangkap khas aceh semakin lebih mantap.

Resep ayam tangkap khas aceh pun mudah dibuat, lho. Kalian tidak perlu ribet-ribet untuk membeli ayam tangkap khas aceh, karena Anda dapat menghidangkan di rumahmu. Untuk Kamu yang hendak menghidangkannya, inilah resep menyajikan ayam tangkap khas aceh yang enak yang dapat Anda coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Ayam tangkap khas Aceh:

1. Sediakan 1 ekor ayam kampung (sy 500 gr ayam potong)
1. Ambil 1 bh jeruk nipis ambil airnya (sy jeruk cui)
1. Sediakan 3 sdm air asam jawa (sy skip)
1. Ambil 2 sdt garam (sesuai selera, sy 1 sdt)
1. Siapkan 300 ml air kelapa (dr 1 bh kelapa)
1. Siapkan Secukupnya minyak goreng
1. Gunakan  Bumbu halus:
1. Sediakan 6 siung bawang merah
1. Siapkan 3 siung bawang putih
1. Sediakan 5-8 bh cabe rawit /optional (sy cabe merah)
1. Siapkan 1 sdt kunyit bubuk
1. Ambil 1/2 sdt merica bubuk
1. Gunakan 1 ruas jari Jahe
1. Gunakan  Bahan lain:
1. Siapkan 10 tangkai daun kari ambil daunnya
1. Siapkan 7 lmbr daun pandan potong kecil kecil (sy 4 lmbr)
1. Ambil 8 bh cabe hijau (sy 4 bh potong serong)
1. Gunakan 8 siung bawang merah iris tipis (sy 4 siung)


Dikenal dengan nama ayam tangkap khas Aceh. Hidangan ini dibuat dari ayam kampung yang segar. Direndam bumbu sederhana dan selalu digoreng saat akan dinikmati. Ayam tangkap khas Aceh ini biasa disebut juga dengan nama ayam tsunami karena tampilannya yang tampak porak-poranda selaksa daratan yang baru saja diterjang tsunami dahsyat. 

<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam tangkap khas Aceh:

1. Potong-potong ayam, cuci bersih, tiriskan, beri air jeruk nipis, diamkan beberapa saat, lalu bilas kembali, tiriskan. Siapkan juga bumbu dan bahan rempah daunnya.
1. Masukkan bumbu yang sudah halus ke dalam ayam, ratakan. Tambahkan air kelapa, kmdn ungkep ayam sambil ditutup sampai air menyusut dan bumbu meresap.  - Note: jika menggunakan ayam kampung, banyaknya air kelapa bisa disesuaikan.
1. Panaskan minyak goreng (minyak banyak), goreng ayam dgn api sedang, kemudian balik ayam. Setelah ayam mulai berwarna kecoklatan, masukkan daun kari, daun pandan, cabai hijau dan bawang merah iris. Goreng sampai ayam berwarna kecoklatan dan rempah daunnya kering serta bawang merahnya kecoklatan.
1. Setelah ayam matang berwarna kuning kecoklatan dan rempah daun kering, angkat dan tiriskan.
1. Sajikan ayam bersama rempah daun kering, cabai hijau dan bawang goreng keringnya. Ayam ini enak disajikan saat panas-panas, sehingga rempah daunnya masih kriuk.


Masakan ini sebenarnya berupa ayam goreng berbumbu yang dimasak bersama daun rempah seperti daun kari. Ayam goreng khas Aceh ini dilengkapi daun salam koja dan daun pandan sehingga membuat aromanya lebih harum. Selain itu daun digoreng kering, jadi camilan seperti keripik. Baca juga: Resep Ayam Goreng Tulang Lunak yang Tidak Hancur. Berikut resep ayam tangkap khas Aceh dari Sajian. 

Wah ternyata resep ayam tangkap khas aceh yang lezat simple ini mudah banget ya! Kita semua dapat membuatnya. Cara Membuat ayam tangkap khas aceh Sangat cocok sekali buat kita yang baru akan belajar memasak atau juga untuk kalian yang telah lihai dalam memasak.

Apakah kamu tertarik mencoba membikin resep ayam tangkap khas aceh enak tidak ribet ini? Kalau mau, mending kamu segera siapkan alat-alat dan bahan-bahannya, setelah itu buat deh Resep ayam tangkap khas aceh yang enak dan sederhana ini. Benar-benar mudah kan. 

Maka dari itu, ketimbang kamu berfikir lama-lama, ayo kita langsung sajikan resep ayam tangkap khas aceh ini. Dijamin kamu gak akan menyesal sudah bikin resep ayam tangkap khas aceh mantab simple ini! Selamat berkreasi dengan resep ayam tangkap khas aceh mantab tidak rumit ini di tempat tinggal kalian masing-masing,oke!.

