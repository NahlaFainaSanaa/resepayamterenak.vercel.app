---
description: "Cara buat Woku ayam yang lezat dan Mudah Dibuat"
title: "Cara buat Woku ayam yang lezat dan Mudah Dibuat"
slug: 325-cara-buat-woku-ayam-yang-lezat-dan-mudah-dibuat
date: 2021-02-05T12:43:37.473Z
image: https://img-global.cpcdn.com/recipes/868575464d733309/680x482cq70/woku-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/868575464d733309/680x482cq70/woku-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/868575464d733309/680x482cq70/woku-ayam-foto-resep-utama.jpg
author: Kathryn Paul
ratingvalue: 5
reviewcount: 13
recipeingredient:
- "1 ekor ayam potong agak kecil2"
- " Jeruk nipis"
- " Garam"
- " Bumbu halus"
- "10 btr bawang merah"
- "4 siung bawang putih"
- "2 ruas jahe"
- "1 ruas kunyit"
- "5 btr kemiri sangrai"
- "20 bh cabe rawit merah"
- "10 bh cabe merah keriting"
- " Bahan lainnya"
- "1 lbr daun kunyit simpulkan"
- "5 lbr daun jeruk"
- "2 btg serai memarkan"
- "1 bh tomat potong jadi 6 bagian"
- "2 btg daun bawang iris2"
- " I ikat kemangi petiki"
recipeinstructions:
- "Cuci bersih ayam lalu beri jeruk nipis dan sedikit ayam. Diamkan selama 30 menit"
- "Tumis bumbu halus sampai mengeluarkan bau wangi dan berminyak, masukkan serai, daun jeruk dan daun kunyit, aduk rata. Sesaat kemudian tambahkan daun bawang dan tomat..aduk kembali."
- "Masukkan ayam lalu aduk, tuang air secukupnya, beri garam dan penyedap..gunakan api sedang. Biarkan sampai ayam empuk dan bumbu meresap."
- "Sesaat sebelum diangkat tambahkan kemangi, aduk sebentar. Lalu angkat dan sajikan."
categories:
- Resep
tags:
- woku
- ayam

katakunci: woku ayam 
nutrition: 119 calories
recipecuisine: Indonesian
preptime: "PT12M"
cooktime: "PT51M"
recipeyield: "2"
recipecategory: Dessert

---


![Woku ayam](https://img-global.cpcdn.com/recipes/868575464d733309/680x482cq70/woku-ayam-foto-resep-utama.jpg)

Selaku seorang istri, menyediakan masakan nikmat untuk keluarga adalah suatu hal yang menggembirakan bagi kamu sendiri. Kewajiban seorang istri bukan sekadar mengerjakan pekerjaan rumah saja, namun anda pun wajib menyediakan kebutuhan nutrisi terpenuhi dan juga santapan yang dimakan keluarga tercinta harus enak.

Di era  saat ini, kamu memang bisa mengorder olahan siap saji tanpa harus ribet membuatnya dahulu. Tapi ada juga mereka yang memang mau memberikan yang terenak bagi orang tercintanya. Sebab, memasak sendiri akan jauh lebih higienis dan bisa menyesuaikan masakan tersebut berdasarkan masakan kesukaan orang tercinta. 



Apakah anda merupakan seorang penikmat woku ayam?. Asal kamu tahu, woku ayam adalah makanan khas di Nusantara yang saat ini digemari oleh setiap orang dari hampir setiap daerah di Nusantara. Kamu dapat menghidangkan woku ayam olahan sendiri di rumahmu dan boleh dijadikan camilan kesukaanmu di hari libur.

Kita tak perlu bingung untuk memakan woku ayam, sebab woku ayam mudah untuk dicari dan kamu pun boleh memasaknya sendiri di rumah. woku ayam dapat diolah dengan berbagai cara. Kini pun telah banyak banget cara kekinian yang menjadikan woku ayam semakin nikmat.

Resep woku ayam pun sangat gampang dihidangkan, lho. Kamu tidak usah ribet-ribet untuk membeli woku ayam, sebab Anda bisa membuatnya sendiri di rumah. Untuk Kita yang ingin mencobanya, berikut cara untuk membuat woku ayam yang mantab yang dapat Kamu coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Woku ayam:

1. Ambil 1 ekor ayam potong agak kecil2
1. Sediakan  Jeruk nipis
1. Siapkan  Garam
1. Siapkan  Bumbu halus:
1. Siapkan 10 btr bawang merah
1. Siapkan 4 siung bawang putih
1. Siapkan 2 ruas jahe
1. Sediakan 1 ruas kunyit
1. Ambil 5 btr kemiri sangrai
1. Ambil 20 bh cabe rawit merah
1. Siapkan 10 bh cabe merah keriting
1. Siapkan  Bahan lainnya:
1. Sediakan 1 lbr daun kunyit simpulkan
1. Gunakan 5 lbr daun jeruk
1. Siapkan 2 btg serai memarkan
1. Siapkan 1 bh tomat potong jadi 6 bagian
1. Sediakan 2 btg daun bawang iris2
1. Sediakan  I ikat kemangi petiki




<!--inarticleads2-->

##### Cara membuat Woku ayam:

1. Cuci bersih ayam lalu beri jeruk nipis dan sedikit ayam. Diamkan selama 30 menit
1. Tumis bumbu halus sampai mengeluarkan bau wangi dan berminyak, masukkan serai, daun jeruk dan daun kunyit, aduk rata. Sesaat kemudian tambahkan daun bawang dan tomat..aduk kembali.
1. Masukkan ayam lalu aduk, tuang air secukupnya, beri garam dan penyedap..gunakan api sedang. Biarkan sampai ayam empuk dan bumbu meresap.
1. Sesaat sebelum diangkat tambahkan kemangi, aduk sebentar. Lalu angkat dan sajikan.




Wah ternyata cara buat woku ayam yang enak sederhana ini enteng banget ya! Kalian semua dapat memasaknya. Cara Membuat woku ayam Cocok banget buat kamu yang sedang belajar memasak atau juga untuk anda yang sudah hebat memasak.

Apakah kamu ingin mencoba bikin resep woku ayam lezat sederhana ini? Kalau kamu tertarik, yuk kita segera buruan siapkan peralatan dan bahannya, maka buat deh Resep woku ayam yang nikmat dan tidak ribet ini. Benar-benar mudah kan. 

Jadi, ketimbang anda berfikir lama-lama, hayo kita langsung buat resep woku ayam ini. Pasti anda tiidak akan nyesel bikin resep woku ayam lezat tidak ribet ini! Selamat berkreasi dengan resep woku ayam enak tidak rumit ini di tempat tinggal sendiri,oke!.

