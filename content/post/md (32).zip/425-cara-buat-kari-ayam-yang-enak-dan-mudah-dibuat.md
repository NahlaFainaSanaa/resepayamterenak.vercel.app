---
description: "Cara buat Kari Ayam yang enak dan Mudah Dibuat"
title: "Cara buat Kari Ayam yang enak dan Mudah Dibuat"
slug: 425-cara-buat-kari-ayam-yang-enak-dan-mudah-dibuat
date: 2021-02-27T07:08:39.081Z
image: https://img-global.cpcdn.com/recipes/1527a5392616dae3/680x482cq70/kari-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1527a5392616dae3/680x482cq70/kari-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1527a5392616dae3/680x482cq70/kari-ayam-foto-resep-utama.jpg
author: Benjamin Simpson
ratingvalue: 4.4
reviewcount: 5
recipeingredient:
- "1200 kg ayam"
- "8 bh700 gr kentang"
- "1 pak stok bumbu kari"
- "5 siung bawang putih"
- "7 siung bawang merah"
- "2 btg serai"
- "250 ml santan kental"
- "500 ml air"
- "1 SDM garam"
- "1 sdt penyedap jamur "
- "1 SDM gula pasir"
recipeinstructions:
- "Siapkan bahan, cuci bersih ayam dan potong2, peras 1 bh jeruk sambal,sisihkan. Untuk kentang, kupas kulit, potong2 4 bh memanjang atau sesuai selera."
- "Siapkan panci, oseng wangi bawang putih+ bawang merah lalu tambahkan kentang, lalu ayam + bumbu kari, oseng sampai wangi."
- "Tuang separuh santan + air, lalu pindahkan panci, tuang habis air + santannya. Tambahkan garam + penyedap + gula.koreksi rasa. Masak sampai sekitar 25 menit atau sampai matang."
- "Matikan api, siapkan mangkok dan sajikan. Yummy 😍😋😋"
categories:
- Resep
tags:
- kari
- ayam

katakunci: kari ayam 
nutrition: 288 calories
recipecuisine: Indonesian
preptime: "PT32M"
cooktime: "PT34M"
recipeyield: "1"
recipecategory: Dinner

---


![Kari Ayam](https://img-global.cpcdn.com/recipes/1527a5392616dae3/680x482cq70/kari-ayam-foto-resep-utama.jpg)

Selaku seorang ibu, menyediakan panganan enak kepada famili adalah suatu hal yang menyenangkan untuk kita sendiri. Peran seorang  wanita bukan saja mengurus rumah saja, namun kamu juga wajib menyediakan kebutuhan nutrisi terpenuhi dan juga panganan yang disantap anak-anak harus sedap.

Di era  sekarang, kamu memang mampu membeli masakan instan meski tanpa harus repot memasaknya lebih dulu. Namun ada juga mereka yang memang ingin menyajikan yang terenak untuk orang yang dicintainya. Pasalnya, memasak yang diolah sendiri akan jauh lebih higienis dan bisa menyesuaikan berdasarkan masakan kesukaan orang tercinta. 



Apakah anda merupakan seorang penyuka kari ayam?. Tahukah kamu, kari ayam adalah hidangan khas di Nusantara yang sekarang disenangi oleh banyak orang dari berbagai daerah di Indonesia. Kalian dapat menyajikan kari ayam buatan sendiri di rumahmu dan boleh dijadikan santapan favorit di akhir pekan.

Kita tidak usah bingung jika kamu ingin memakan kari ayam, karena kari ayam sangat mudah untuk dicari dan anda pun boleh membuatnya sendiri di rumah. kari ayam boleh diolah dengan beragam cara. Kini pun telah banyak banget cara kekinian yang menjadikan kari ayam semakin mantap.

Resep kari ayam juga mudah dibikin, lho. Anda tidak usah ribet-ribet untuk memesan kari ayam, lantaran Anda bisa membuatnya ditempatmu. Untuk Kamu yang akan membuatnya, berikut ini cara membuat kari ayam yang lezat yang dapat Anda buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Kari Ayam:

1. Siapkan 1200 kg ayam
1. Sediakan 8 bh/700 gr kentang
1. Gunakan 1 pak stok bumbu kari
1. Siapkan 5 siung bawang putih
1. Siapkan 7 siung bawang merah
1. Sediakan 2 btg serai
1. Siapkan 250 ml santan kental
1. Siapkan 500 ml air
1. Ambil 1 SDM garam
1. Gunakan 1 sdt penyedap jamur 🍄
1. Gunakan 1 SDM gula pasir




<!--inarticleads2-->

##### Langkah-langkah membuat Kari Ayam:

1. Siapkan bahan, cuci bersih ayam dan potong2, peras 1 bh jeruk sambal,sisihkan. Untuk kentang, kupas kulit, potong2 4 bh memanjang atau sesuai selera.
1. Siapkan panci, oseng wangi bawang putih+ bawang merah lalu tambahkan kentang, lalu ayam + bumbu kari, oseng sampai wangi.
1. Tuang separuh santan + air, lalu pindahkan panci, tuang habis air + santannya. Tambahkan garam + penyedap + gula.koreksi rasa. Masak sampai sekitar 25 menit atau sampai matang.
1. Matikan api, siapkan mangkok dan sajikan. Yummy 😍😋😋




Ternyata cara membuat kari ayam yang mantab sederhana ini gampang sekali ya! Semua orang dapat menghidangkannya. Cara buat kari ayam Sangat cocok sekali buat kita yang baru belajar memasak maupun bagi anda yang sudah jago memasak.

Apakah kamu ingin mulai mencoba membikin resep kari ayam enak simple ini? Kalau kalian ingin, mending kamu segera buruan menyiapkan alat dan bahan-bahannya, lantas buat deh Resep kari ayam yang nikmat dan tidak rumit ini. Sangat taidak sulit kan. 

Oleh karena itu, daripada kita berfikir lama-lama, ayo langsung aja buat resep kari ayam ini. Dijamin kamu tiidak akan nyesel sudah buat resep kari ayam mantab simple ini! Selamat mencoba dengan resep kari ayam nikmat sederhana ini di tempat tinggal masing-masing,oke!.

