---
description: "Resep Semur Ayam Sederhana dan Mudah Dibuat"
title: "Resep Semur Ayam Sederhana dan Mudah Dibuat"
slug: 234-resep-semur-ayam-sederhana-dan-mudah-dibuat
date: 2021-05-28T13:25:01.534Z
image: https://img-global.cpcdn.com/recipes/0a8b43d0aefe2fbf/680x482cq70/semur-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0a8b43d0aefe2fbf/680x482cq70/semur-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0a8b43d0aefe2fbf/680x482cq70/semur-ayam-foto-resep-utama.jpg
author: Mina Vega
ratingvalue: 4.3
reviewcount: 6
recipeingredient:
- "500 gram ayam bagian paha"
- "1 buah bawang bombay ukuran kecil"
- "2 buah tomat masing masing potong jadi 4 bagian"
- "400-500 ml air"
- "2 sdm minyak untuk menumis"
- " Bumbu Halus "
- "3 siung bawang putih"
- "7 siung bawang merah"
- "2 buah cabe merah keriting"
- "2 butir kemiri"
- "1 sdt ketumbar bubuk"
- "1/2 sdt pala bubuk"
- " Bahan Cemplung "
- "2 lembar daun salam"
- "7 buah cabe rawit"
- "1 buah star anise  pekak  bunga lawang"
- " Bumbu Lainnya "
- "2 sdm kecap manis saya pakai kecap laron"
- "1 sdm gula merah"
- "1/2 sdt gula pasir optional"
- "1 sdt garam"
- "1/2 sdt lada bubuk"
- "1/2 sdt kaldu jamur"
- "1/2 sdt kecap jamur optional"
recipeinstructions:
- "Cuci bersih ayam dan siapkan bahan bahan lainnya (bunga lawang dan kemiri lupa gak kefoto). Blender bumbu halus."
- "Tumis bawang bombay dengan bumbu halus hingga harum lalu masukkan daun salam. Tumis lagi lalu masukkan ayam. Aduk rata."
- "Beri gula merah, garam, gula pasir, lada bubuk, kecap manis dan kaldu jamur. Aduk rata lalu masukkan cabe rawit."
- "Masukkan bunga lawang, air lalu aduk rata, karena warnanya kecap laron kurang pekat saya beri tambahan kecap jamur. Aduk rata."
- "Masak hingga mendidih dan air agak surut. Tes rasa. Menjelang matang masukkan potongan tomat."
- "Masak sebentar. Lalu sajikan. Buat teman nasi merah mantap. Si kecil bilang enak ayamnya 👍"
categories:
- Resep
tags:
- semur
- ayam

katakunci: semur ayam 
nutrition: 131 calories
recipecuisine: Indonesian
preptime: "PT30M"
cooktime: "PT30M"
recipeyield: "2"
recipecategory: Lunch

---


![Semur Ayam](https://img-global.cpcdn.com/recipes/0a8b43d0aefe2fbf/680x482cq70/semur-ayam-foto-resep-utama.jpg)

Selaku seorang wanita, mempersiapkan masakan mantab buat keluarga tercinta adalah suatu hal yang sangat menyenangkan untuk kamu sendiri. Peran seorang  wanita bukan hanya mengatur rumah saja, tapi anda juga wajib memastikan keperluan gizi terpenuhi dan panganan yang dikonsumsi anak-anak harus mantab.

Di masa  saat ini, kamu sebenarnya mampu mengorder hidangan praktis meski tidak harus susah mengolahnya terlebih dahulu. Tapi banyak juga orang yang memang ingin memberikan makanan yang terlezat bagi orang tercintanya. Pasalnya, menghidangkan masakan sendiri jauh lebih bersih dan kita juga bisa menyesuaikan sesuai masakan kesukaan orang tercinta. 



Mungkinkah anda merupakan seorang penikmat semur ayam?. Asal kamu tahu, semur ayam adalah sajian khas di Indonesia yang sekarang disukai oleh setiap orang dari berbagai wilayah di Nusantara. Anda bisa menyajikan semur ayam hasil sendiri di rumah dan pasti jadi santapan kesenanganmu di akhir pekanmu.

Kita jangan bingung untuk menyantap semur ayam, lantaran semur ayam tidak sulit untuk didapatkan dan juga kamu pun boleh menghidangkannya sendiri di tempatmu. semur ayam bisa dibuat memalui beraneka cara. Sekarang telah banyak cara modern yang membuat semur ayam semakin mantap.

Resep semur ayam pun mudah sekali untuk dibuat, lho. Anda tidak usah capek-capek untuk memesan semur ayam, sebab Anda bisa menyajikan ditempatmu. Bagi Kalian yang mau membuatnya, berikut resep untuk membuat semur ayam yang enak yang bisa Anda buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Semur Ayam:

1. Siapkan 500 gram ayam bagian paha
1. Ambil 1 buah bawang bombay ukuran kecil
1. Ambil 2 buah tomat, masing masing potong jadi 4 bagian
1. Siapkan 400-500 ml air
1. Siapkan 2 sdm minyak untuk menumis
1. Siapkan  Bumbu Halus :
1. Siapkan 3 siung bawang putih
1. Sediakan 7 siung bawang merah
1. Sediakan 2 buah cabe merah keriting
1. Siapkan 2 butir kemiri
1. Ambil 1 sdt ketumbar bubuk
1. Siapkan 1/2 sdt pala bubuk
1. Siapkan  Bahan Cemplung :
1. Ambil 2 lembar daun salam
1. Ambil 7 buah cabe rawit
1. Gunakan 1 buah star anise / pekak / bunga lawang
1. Sediakan  Bumbu Lainnya :
1. Sediakan 2 sdm kecap manis, saya pakai kecap laron
1. Sediakan 1 sdm gula merah
1. Ambil 1/2 sdt gula pasir (optional)
1. Ambil 1 sdt garam
1. Gunakan 1/2 sdt lada bubuk
1. Ambil 1/2 sdt kaldu jamur
1. Siapkan 1/2 sdt kecap jamur (optional)




<!--inarticleads2-->

##### Langkah-langkah membuat Semur Ayam:

1. Cuci bersih ayam dan siapkan bahan bahan lainnya (bunga lawang dan kemiri lupa gak kefoto). Blender bumbu halus.
1. Tumis bawang bombay dengan bumbu halus hingga harum lalu masukkan daun salam. Tumis lagi lalu masukkan ayam. Aduk rata.
1. Beri gula merah, garam, gula pasir, lada bubuk, kecap manis dan kaldu jamur. Aduk rata lalu masukkan cabe rawit.
1. Masukkan bunga lawang, air lalu aduk rata, karena warnanya kecap laron kurang pekat saya beri tambahan kecap jamur. Aduk rata.
1. Masak hingga mendidih dan air agak surut. Tes rasa. Menjelang matang masukkan potongan tomat.
1. Masak sebentar. Lalu sajikan. Buat teman nasi merah mantap. Si kecil bilang enak ayamnya 👍




Wah ternyata cara membuat semur ayam yang enak tidak rumit ini mudah sekali ya! Semua orang bisa menghidangkannya. Cara Membuat semur ayam Sangat sesuai sekali untuk anda yang baru mau belajar memasak maupun juga untuk kamu yang telah jago memasak.

Apakah kamu tertarik mulai mencoba bikin resep semur ayam enak simple ini? Kalau kamu mau, yuk kita segera siapin peralatan dan bahan-bahannya, kemudian buat deh Resep semur ayam yang lezat dan tidak rumit ini. Betul-betul taidak sulit kan. 

Jadi, ketimbang kamu berlama-lama, ayo kita langsung bikin resep semur ayam ini. Dijamin kalian tak akan nyesel membuat resep semur ayam mantab tidak rumit ini! Selamat berkreasi dengan resep semur ayam enak tidak rumit ini di tempat tinggal kalian masing-masing,oke!.

