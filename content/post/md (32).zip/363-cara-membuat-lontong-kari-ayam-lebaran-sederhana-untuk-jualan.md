---
description: "Cara membuat Lontong Kari Ayam Lebaran Sederhana Untuk Jualan"
title: "Cara membuat Lontong Kari Ayam Lebaran Sederhana Untuk Jualan"
slug: 363-cara-membuat-lontong-kari-ayam-lebaran-sederhana-untuk-jualan
date: 2021-02-20T04:47:09.744Z
image: https://img-global.cpcdn.com/recipes/cd85048fb4605ddb/680x482cq70/lontong-kari-ayam-lebaran-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/cd85048fb4605ddb/680x482cq70/lontong-kari-ayam-lebaran-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/cd85048fb4605ddb/680x482cq70/lontong-kari-ayam-lebaran-foto-resep-utama.jpg
author: Sean Jensen
ratingvalue: 4
reviewcount: 9
recipeingredient:
- "1 ekor ayam potong 10 bagian"
- "1.5 liter santan cair"
- "500 ml santan kental"
- "1 batang serai geprek"
- "2 lembar daun salam"
- "3 lembar daun jeruk"
- "1 sdt garam"
- "1 sdt kaldu jamur"
- "1/2 sdt gula pasir"
- " Minyak untuk menumis"
- " Bumbu Halus "
- "12 siung bawang merah"
- "8 siung bawang putih"
- "4 butir kemiri"
- "1 sdt ketumbar"
- "2 ruas jari kunyit"
- "1/2 sdt jinten"
- "1/2 lada bubuk"
- "1 ruas jari lengkuas"
- " Pelengkap "
- " Bawang goreng wajib"
- " Lontong siap rebus merk klink"
recipeinstructions:
- "Blender semua bahan bumbh, hingga benar² halus."
- "Siapkan panci, tambahkan minyak. Panaskan. Tumis bumbu hingga wangi, masukkan daun salam, serai geprek, daun jeruk. Tumis hingga wangi. Masukkan potongan ayam, aduk rata."
- "Masukkan santan cair. Aduk terus menerus hingga mendidih. Setelah mendidih masukkan santan kental, aduk lagi. Tambahkan gara., gula dan kaldu jamur. Aduk terus menerus hingga mendidih. Tes rasa dulu. Opor ini kalau sudah dibesokkan akan lebih enak. Apalagi kalau santannya di perbanyak yang kentalnya, beuuhh mantaps."
- "Siapkan mangkok. Potong² lontong. Siram dengan kuahnya dan ayam. Taburi dengan bawang goreng. Di tambah sama sambal goreng kentang pete waduuhh ancamaaan. Enak bgt."
categories:
- Resep
tags:
- lontong
- kari
- ayam

katakunci: lontong kari ayam 
nutrition: 205 calories
recipecuisine: Indonesian
preptime: "PT27M"
cooktime: "PT55M"
recipeyield: "2"
recipecategory: Dessert

---


![Lontong Kari Ayam Lebaran](https://img-global.cpcdn.com/recipes/cd85048fb4605ddb/680x482cq70/lontong-kari-ayam-lebaran-foto-resep-utama.jpg)

Jika anda seorang istri, menyuguhkan masakan enak untuk famili adalah hal yang mengasyikan untuk kamu sendiri. Peran seorang ibu bukan cuma mengerjakan pekerjaan rumah saja, namun anda juga harus memastikan keperluan gizi terpenuhi dan juga masakan yang dikonsumsi keluarga tercinta harus enak.

Di waktu  saat ini, kita memang bisa memesan olahan instan walaupun tidak harus susah memasaknya terlebih dahulu. Tapi banyak juga lho mereka yang memang ingin menyajikan yang terbaik untuk keluarganya. Sebab, memasak sendiri jauh lebih higienis dan kita juga bisa menyesuaikan sesuai dengan makanan kesukaan orang tercinta. 



Mungkinkah anda adalah salah satu penikmat lontong kari ayam lebaran?. Asal kamu tahu, lontong kari ayam lebaran adalah makanan khas di Nusantara yang saat ini digemari oleh orang-orang di hampir setiap wilayah di Indonesia. Kalian bisa membuat lontong kari ayam lebaran sendiri di rumahmu dan boleh jadi makanan kesukaanmu di hari libur.

Kalian tidak perlu bingung untuk menyantap lontong kari ayam lebaran, lantaran lontong kari ayam lebaran gampang untuk ditemukan dan kita pun boleh membuatnya sendiri di rumah. lontong kari ayam lebaran boleh dimasak lewat berbagai cara. Sekarang telah banyak sekali cara kekinian yang membuat lontong kari ayam lebaran semakin lezat.

Resep lontong kari ayam lebaran juga gampang sekali dibikin, lho. Kita tidak perlu repot-repot untuk memesan lontong kari ayam lebaran, sebab Anda dapat menyiapkan di rumahmu. Bagi Kamu yang hendak membuatnya, inilah cara untuk membuat lontong kari ayam lebaran yang lezat yang mampu Kalian hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Lontong Kari Ayam Lebaran:

1. Siapkan 1 ekor ayam potong 10 bagian
1. Sediakan 1.5 liter santan cair
1. Ambil 500 ml santan kental
1. Gunakan 1 batang serai geprek
1. Siapkan 2 lembar daun salam
1. Siapkan 3 lembar daun jeruk
1. Siapkan 1 sdt garam
1. Gunakan 1 sdt kaldu jamur
1. Siapkan 1/2 sdt gula pasir
1. Sediakan  Minyak untuk menumis
1. Siapkan  Bumbu Halus :
1. Sediakan 12 siung bawang merah
1. Sediakan 8 siung bawang putih
1. Ambil 4 butir kemiri
1. Sediakan 1 sdt ketumbar
1. Sediakan 2 ruas jari kunyit
1. Ambil 1/2 sdt jinten
1. Siapkan 1/2 lada bubuk
1. Gunakan 1 ruas jari lengkuas
1. Siapkan  Pelengkap :
1. Sediakan  Bawang goreng (wajib)
1. Ambil  Lontong siap rebus (merk klink)




<!--inarticleads2-->

##### Langkah-langkah membuat Lontong Kari Ayam Lebaran:

1. Blender semua bahan bumbh, hingga benar² halus.
1. Siapkan panci, tambahkan minyak. Panaskan. Tumis bumbu hingga wangi, masukkan daun salam, serai geprek, daun jeruk. Tumis hingga wangi. Masukkan potongan ayam, aduk rata.
1. Masukkan santan cair. Aduk terus menerus hingga mendidih. Setelah mendidih masukkan santan kental, aduk lagi. Tambahkan gara., gula dan kaldu jamur. Aduk terus menerus hingga mendidih. Tes rasa dulu. Opor ini kalau sudah dibesokkan akan lebih enak. Apalagi kalau santannya di perbanyak yang kentalnya, beuuhh mantaps.
1. Siapkan mangkok. Potong² lontong. Siram dengan kuahnya dan ayam. Taburi dengan bawang goreng. Di tambah sama sambal goreng kentang pete waduuhh ancamaaan. Enak bgt.




Ternyata cara buat lontong kari ayam lebaran yang enak simple ini gampang banget ya! Semua orang bisa memasaknya. Resep lontong kari ayam lebaran Sangat cocok sekali untuk kalian yang baru mau belajar memasak ataupun juga bagi kalian yang sudah lihai memasak.

Apakah kamu mau mulai mencoba buat resep lontong kari ayam lebaran enak tidak rumit ini? Kalau kalian mau, ayo kalian segera buruan siapin alat-alat dan bahan-bahannya, kemudian bikin deh Resep lontong kari ayam lebaran yang mantab dan tidak ribet ini. Sangat gampang kan. 

Maka dari itu, ketimbang kita diam saja, ayo langsung aja buat resep lontong kari ayam lebaran ini. Dijamin kalian gak akan menyesal sudah buat resep lontong kari ayam lebaran nikmat tidak ribet ini! Selamat berkreasi dengan resep lontong kari ayam lebaran lezat simple ini di tempat tinggal sendiri,oke!.

