---
description: "Resep Lontong Kari Ayam dan Kerecek Sederhana Untuk Jualan"
title: "Resep Lontong Kari Ayam dan Kerecek Sederhana Untuk Jualan"
slug: 374-resep-lontong-kari-ayam-dan-kerecek-sederhana-untuk-jualan
date: 2021-02-06T19:01:12.803Z
image: https://img-global.cpcdn.com/recipes/51bb4a6ce6dd9550/680x482cq70/lontong-kari-ayam-dan-kerecek-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/51bb4a6ce6dd9550/680x482cq70/lontong-kari-ayam-dan-kerecek-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/51bb4a6ce6dd9550/680x482cq70/lontong-kari-ayam-dan-kerecek-foto-resep-utama.jpg
author: Nicholas Ford
ratingvalue: 4.2
reviewcount: 12
recipeingredient:
- "500 gram daging ayam kampung rebus potongpotong"
- "1000 ml air untuk merebus"
- "2 lembar daun salam"
- "1 batang serai"
- "500 ml santan dari 12 butir kelapa"
- "50 gram kerupuk kulit kerecek"
- "4 buah tahu kuning potong bagi 4 goreng sebentar"
- "3 sdm minyak goreng"
- " Bumbu halus "
- "2 siung bawang putih"
- "3 siung bawang merah"
- "1 cm kunyit kupas iris tipis"
- "1,5 sdt garam"
- "1 sdt gula pasir"
- "1/2 sdt ketumbar"
- " Pelengkap "
- " Lontong nasi siap pakai"
- " Telur ayam rebus"
- " Bawang goreng"
- " Daun selada"
- " Sambal cabe"
recipeinstructions:
- "Rebus daging ayam hingga matang. saring air kaldu ayam hingga 750 ml. Masukkan lagi ke dalam panci. Sisihkan daging ayam rebus."
- "Tumis bumbu halus hingga harum, tambahkan salam, sereh, ayam rebus dan tahu, aduk rata. Masukkan ke dalam rebusan ayam, masak lagi hingga mendidih. Tambahkan santan, timba-timba jaga agar santan tidak pecah, setelah mendidih masukkan kerupuk kulit (krecek). Tes rasa. Angkat."
- "Buka daun pembungkus lontong, potong kecil taruh secukupnya di mangkuk saji. Kupas telur rebus, belah jadi 2."
- "Taruh diatas lontong : kerecek, tahu, daging ayam siram pake kuah kari. Lengkapi dengan telur rebus, daun selada dan bawang goreng. Sajikan hangat."
categories:
- Resep
tags:
- lontong
- kari
- ayam

katakunci: lontong kari ayam 
nutrition: 276 calories
recipecuisine: Indonesian
preptime: "PT40M"
cooktime: "PT51M"
recipeyield: "2"
recipecategory: Lunch

---


![Lontong Kari Ayam dan Kerecek](https://img-global.cpcdn.com/recipes/51bb4a6ce6dd9550/680x482cq70/lontong-kari-ayam-dan-kerecek-foto-resep-utama.jpg)

Jika kita seorang orang tua, menyajikan santapan sedap pada famili adalah hal yang menyenangkan untuk kita sendiri. Kewajiban seorang ibu Tidak hanya menjaga rumah saja, namun kamu juga harus memastikan keperluan nutrisi tercukupi dan juga olahan yang dimakan orang tercinta mesti mantab.

Di zaman  saat ini, kalian memang mampu mengorder santapan instan meski tidak harus repot mengolahnya lebih dulu. Tetapi banyak juga orang yang memang mau memberikan yang terenak untuk orang tercintanya. Sebab, memasak sendiri jauh lebih higienis dan kita pun bisa menyesuaikan berdasarkan kesukaan keluarga tercinta. 



Mungkinkah anda seorang penyuka lontong kari ayam dan kerecek?. Tahukah kamu, lontong kari ayam dan kerecek adalah makanan khas di Indonesia yang sekarang digemari oleh setiap orang di berbagai tempat di Nusantara. Kamu bisa memasak lontong kari ayam dan kerecek buatan sendiri di rumah dan boleh jadi camilan favorit di akhir pekan.

Kalian tidak usah bingung untuk mendapatkan lontong kari ayam dan kerecek, lantaran lontong kari ayam dan kerecek tidak sulit untuk didapatkan dan kita pun boleh memasaknya sendiri di tempatmu. lontong kari ayam dan kerecek boleh dimasak dengan berbagai cara. Sekarang ada banyak resep kekinian yang menjadikan lontong kari ayam dan kerecek semakin lebih enak.

Resep lontong kari ayam dan kerecek pun gampang dihidangkan, lho. Kita tidak usah capek-capek untuk memesan lontong kari ayam dan kerecek, tetapi Kalian dapat menyajikan ditempatmu. Bagi Kalian yang ingin menghidangkannya, inilah cara membuat lontong kari ayam dan kerecek yang mantab yang mampu Anda hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Lontong Kari Ayam dan Kerecek:

1. Sediakan 500 gram daging ayam kampung, rebus, potong-potong
1. Siapkan 1000 ml air untuk merebus
1. Gunakan 2 lembar daun salam
1. Ambil 1 batang serai
1. Ambil 500 ml santan dari 1/2 butir kelapa
1. Gunakan 50 gram kerupuk kulit (kerecek)
1. Gunakan 4 buah tahu kuning, potong bagi 4, goreng sebentar
1. Gunakan 3 sdm minyak goreng
1. Siapkan  Bumbu halus :
1. Gunakan 2 siung bawang putih
1. Sediakan 3 siung bawang merah
1. Ambil 1 cm kunyit kupas, iris tipis
1. Gunakan 1,5 sdt garam
1. Sediakan 1 sdt gula pasir
1. Sediakan 1/2 sdt ketumbar
1. Sediakan  Pelengkap :
1. Ambil  Lontong nasi siap pakai
1. Siapkan  Telur ayam rebus
1. Sediakan  Bawang goreng
1. Gunakan  Daun selada
1. Ambil  Sambal cabe




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Lontong Kari Ayam dan Kerecek:

1. Rebus daging ayam hingga matang. saring air kaldu ayam hingga 750 ml. Masukkan lagi ke dalam panci. Sisihkan daging ayam rebus.
1. Tumis bumbu halus hingga harum, tambahkan salam, sereh, ayam rebus dan tahu, aduk rata. Masukkan ke dalam rebusan ayam, masak lagi hingga mendidih. Tambahkan santan, timba-timba jaga agar santan tidak pecah, setelah mendidih masukkan kerupuk kulit (krecek). Tes rasa. Angkat.
1. Buka daun pembungkus lontong, potong kecil taruh secukupnya di mangkuk saji. Kupas telur rebus, belah jadi 2.
1. Taruh diatas lontong : kerecek, tahu, daging ayam siram pake kuah kari. Lengkapi dengan telur rebus, daun selada dan bawang goreng. Sajikan hangat.




Ternyata cara buat lontong kari ayam dan kerecek yang lezat simple ini mudah banget ya! Kalian semua mampu memasaknya. Cara buat lontong kari ayam dan kerecek Sangat cocok sekali untuk kalian yang sedang belajar memasak ataupun juga bagi kamu yang sudah hebat memasak.

Tertarik untuk mulai mencoba membikin resep lontong kari ayam dan kerecek lezat tidak ribet ini? Kalau kamu ingin, yuk kita segera siapin peralatan dan bahan-bahannya, lantas buat deh Resep lontong kari ayam dan kerecek yang nikmat dan sederhana ini. Sungguh mudah kan. 

Maka, daripada anda berlama-lama, maka langsung aja bikin resep lontong kari ayam dan kerecek ini. Pasti kalian tak akan menyesal sudah bikin resep lontong kari ayam dan kerecek enak sederhana ini! Selamat berkreasi dengan resep lontong kari ayam dan kerecek lezat sederhana ini di rumah kalian sendiri,ya!.

