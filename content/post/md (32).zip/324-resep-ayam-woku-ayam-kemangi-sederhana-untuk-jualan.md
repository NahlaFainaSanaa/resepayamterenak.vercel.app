---
description: "Resep Ayam woku / ayam kemangi Sederhana Untuk Jualan"
title: "Resep Ayam woku / ayam kemangi Sederhana Untuk Jualan"
slug: 324-resep-ayam-woku-ayam-kemangi-sederhana-untuk-jualan
date: 2021-02-09T09:20:19.610Z
image: https://img-global.cpcdn.com/recipes/e0e0d558d311e3f2/680x482cq70/ayam-woku-ayam-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e0e0d558d311e3f2/680x482cq70/ayam-woku-ayam-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e0e0d558d311e3f2/680x482cq70/ayam-woku-ayam-kemangi-foto-resep-utama.jpg
author: Alexander Caldwell
ratingvalue: 3
reviewcount: 11
recipeingredient:
- "1/2 kg ayam"
- "3 siung bawang putih"
- "5 siung bawang merah"
- "1 ruas kunyit"
- "1 ruas jahe digeprek"
- "5 buah cabe keriting"
- "3 buah cabe rawit"
- "2 lembar daun salam"
- "1 batang sereh geprek"
- "2 lembar daun jeruk"
- " Lengkuas digeprek"
- " Garamgulakaldu bubuk"
- "1 ikat kemangi"
recipeinstructions:
- "Potong ayam menjadi kecil2, haluskan bumbu kecuali daun jeruk, sereh, salam, lengkuas, jahe"
- "Tumis bumbu halus, lalu masukkan daun salam, sereh, lengkuas, jahe, daun jeruk.. tumis sampai harum.."
- "Masukkan ayam nya.. beri sedikit air.. aduk2"
- "Tambahkan gula+garam+kaldu bubuk.. aduk rata.. lalu tutup tunggu sampai ayam empuk dan bumbu meresap.. tes rasa"
- "Setelah ayam sudah empuk dan hampir matang masukkan daun kemangi yang sudah dipetik dan dicuci bersih"
- "Aduh sampai kemangi layu.. ayam woku siap dihidangkan dengan nasi anget+ krupuk 😄"
categories:
- Resep
tags:
- ayam
- woku
- 

katakunci: ayam woku  
nutrition: 253 calories
recipecuisine: Indonesian
preptime: "PT33M"
cooktime: "PT51M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam woku / ayam kemangi](https://img-global.cpcdn.com/recipes/e0e0d558d311e3f2/680x482cq70/ayam-woku-ayam-kemangi-foto-resep-utama.jpg)

Selaku seorang yang hobi memasak, menyajikan santapan sedap pada orang tercinta adalah hal yang memuaskan untuk kamu sendiri. Kewajiban seorang istri Tidak cuma menjaga rumah saja, namun kamu juga wajib menyediakan keperluan nutrisi tercukupi dan juga hidangan yang dimakan keluarga tercinta harus nikmat.

Di waktu  sekarang, kamu sebenarnya dapat membeli masakan yang sudah jadi walaupun tidak harus capek mengolahnya lebih dulu. Tetapi ada juga mereka yang memang mau menghidangkan yang terlezat untuk keluarganya. Karena, memasak yang dibuat sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan sesuai selera keluarga tercinta. 



Apakah anda merupakan seorang penggemar ayam woku / ayam kemangi?. Tahukah kamu, ayam woku / ayam kemangi adalah hidangan khas di Indonesia yang sekarang disukai oleh banyak orang di hampir setiap wilayah di Indonesia. Kalian bisa membuat ayam woku / ayam kemangi sendiri di rumahmu dan dapat dijadikan santapan kesenanganmu di akhir pekan.

Kamu tidak perlu bingung untuk menyantap ayam woku / ayam kemangi, sebab ayam woku / ayam kemangi tidak sukar untuk ditemukan dan kalian pun boleh mengolahnya sendiri di rumah. ayam woku / ayam kemangi dapat dimasak memalui berbagai cara. Saat ini sudah banyak banget resep modern yang menjadikan ayam woku / ayam kemangi lebih lezat.

Resep ayam woku / ayam kemangi juga gampang untuk dibuat, lho. Kalian jangan capek-capek untuk membeli ayam woku / ayam kemangi, lantaran Kita dapat membuatnya di rumahmu. Untuk Kamu yang mau mencobanya, berikut resep untuk menyajikan ayam woku / ayam kemangi yang mantab yang dapat Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Ayam woku / ayam kemangi:

1. Sediakan 1/2 kg ayam
1. Ambil 3 siung bawang putih
1. Siapkan 5 siung bawang merah
1. Gunakan 1 ruas kunyit
1. Sediakan 1 ruas jahe digeprek
1. Sediakan 5 buah cabe keriting
1. Ambil 3 buah cabe rawit
1. Gunakan 2 lembar daun salam
1. Sediakan 1 batang sereh geprek
1. Ambil 2 lembar daun jeruk
1. Siapkan  Lengkuas digeprek
1. Sediakan  Garam+gula+kaldu bubuk
1. Siapkan 1 ikat kemangi




<!--inarticleads2-->

##### Cara membuat Ayam woku / ayam kemangi:

1. Potong ayam menjadi kecil2, haluskan bumbu kecuali daun jeruk, sereh, salam, lengkuas, jahe
1. Tumis bumbu halus, lalu masukkan daun salam, sereh, lengkuas, jahe, daun jeruk.. tumis sampai harum..
1. Masukkan ayam nya.. beri sedikit air.. aduk2
1. Tambahkan gula+garam+kaldu bubuk.. aduk rata.. lalu tutup tunggu sampai ayam empuk dan bumbu meresap.. tes rasa
1. Setelah ayam sudah empuk dan hampir matang masukkan daun kemangi yang sudah dipetik dan dicuci bersih
1. Aduh sampai kemangi layu.. ayam woku siap dihidangkan dengan nasi anget+ krupuk 😄




Ternyata resep ayam woku / ayam kemangi yang nikamt tidak rumit ini gampang sekali ya! Kamu semua mampu memasaknya. Cara Membuat ayam woku / ayam kemangi Sangat cocok banget untuk kalian yang baru mau belajar memasak maupun bagi kalian yang sudah hebat memasak.

Apakah kamu mau mencoba membikin resep ayam woku / ayam kemangi lezat tidak ribet ini? Kalau kalian mau, ayo kamu segera buruan menyiapkan alat-alat dan bahan-bahannya, lalu buat deh Resep ayam woku / ayam kemangi yang lezat dan simple ini. Sungguh taidak sulit kan. 

Maka dari itu, daripada kamu berlama-lama, yuk kita langsung saja bikin resep ayam woku / ayam kemangi ini. Dijamin anda gak akan menyesal sudah bikin resep ayam woku / ayam kemangi enak sederhana ini! Selamat mencoba dengan resep ayam woku / ayam kemangi nikmat sederhana ini di rumah sendiri,oke!.

