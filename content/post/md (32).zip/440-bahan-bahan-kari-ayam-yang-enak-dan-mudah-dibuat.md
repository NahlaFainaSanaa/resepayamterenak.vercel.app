---
description: "Bahan-bahan Kari ayam yang enak dan Mudah Dibuat"
title: "Bahan-bahan Kari ayam yang enak dan Mudah Dibuat"
slug: 440-bahan-bahan-kari-ayam-yang-enak-dan-mudah-dibuat
date: 2021-01-23T03:08:44.840Z
image: https://img-global.cpcdn.com/recipes/7a989fe5a1937ab8/680x482cq70/kari-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7a989fe5a1937ab8/680x482cq70/kari-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7a989fe5a1937ab8/680x482cq70/kari-ayam-foto-resep-utama.jpg
author: Verna Schneider
ratingvalue: 4.3
reviewcount: 10
recipeingredient:
- "1 ekor ayam"
- "2 buah kentang"
- "200 ml santan kental sy pakai santan instan"
- "700-1000 ml air"
- " Bumbu halus "
- "8 cabe merah keriting"
- "5 cabe rawit bs di skip"
- "10 bawang merah"
- "6 bawang putih"
- "4 kemiri"
- "1 sdt ketumbar"
- "1/2 sdt jinten"
- "Sejempol jahe"
- "Seruas kunyit"
- "1 batang sereh ambil putih nya sj"
- "1 sdm bubuk kari"
- " Bumbu tambahan "
- "2 daun salam"
- "5 daun jeruk"
- "Secukupnya daun kari sy gak pake"
- "2 batang kayu manis"
- "3 kapulaga"
- "3 bunga lawang"
- "4 cengkeh"
recipeinstructions:
- "Siapkan bahan2 bumbu,cuci bersih ayam dan kentang,panaskan minyak tumis dulu kayu manis,cengkeh,kapulaga dan bunga lawang agar tdk terlalu bau langu baru masukan bumbu halus,daun salam daun jeruk tumis hingga matang"
- "Masukan ayam aduk rata bru masukan santan lalu beri air aduk terus hingga mendidih masukan garam,gula dan penyedap cek rasa"
- "Jika rasa sdh pas tinggal tunggu air menyusut sedikit tidak perlu kering krn kari ini berkuah"
categories:
- Resep
tags:
- kari
- ayam

katakunci: kari ayam 
nutrition: 113 calories
recipecuisine: Indonesian
preptime: "PT35M"
cooktime: "PT45M"
recipeyield: "3"
recipecategory: Dessert

---


![Kari ayam](https://img-global.cpcdn.com/recipes/7a989fe5a1937ab8/680x482cq70/kari-ayam-foto-resep-utama.jpg)

Selaku seorang yang hobi memasak, menyuguhkan panganan menggugah selera pada keluarga tercinta adalah hal yang menyenangkan bagi kita sendiri. Tugas seorang ibu bukan saja mengatur rumah saja, tetapi anda pun wajib memastikan keperluan nutrisi tercukupi dan juga olahan yang disantap keluarga tercinta harus sedap.

Di zaman  sekarang, kamu sebenarnya bisa membeli olahan yang sudah jadi meski tanpa harus susah membuatnya terlebih dahulu. Namun ada juga lho orang yang selalu mau menyajikan yang terenak bagi orang tercintanya. Karena, menghidangkan masakan yang dibuat sendiri jauh lebih higienis dan kita juga bisa menyesuaikan hidangan tersebut sesuai masakan kesukaan famili. 



Mungkinkah anda salah satu penyuka kari ayam?. Tahukah kamu, kari ayam adalah hidangan khas di Nusantara yang sekarang disenangi oleh kebanyakan orang dari hampir setiap wilayah di Nusantara. Kalian dapat memasak kari ayam buatan sendiri di rumahmu dan pasti jadi camilan kesenanganmu di akhir pekanmu.

Kita tidak perlu bingung jika kamu ingin memakan kari ayam, karena kari ayam gampang untuk ditemukan dan kita pun boleh memasaknya sendiri di tempatmu. kari ayam dapat dimasak dengan bermacam cara. Kini pun ada banyak cara modern yang menjadikan kari ayam lebih lezat.

Resep kari ayam juga gampang untuk dibuat, lho. Kita tidak perlu ribet-ribet untuk membeli kari ayam, tetapi Anda dapat menyajikan di rumah sendiri. Untuk Kita yang hendak menghidangkannya, berikut ini cara untuk menyajikan kari ayam yang enak yang dapat Kita hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Kari ayam:

1. Ambil 1 ekor ayam
1. Ambil 2 buah kentang
1. Gunakan 200 ml santan kental (sy pakai santan instan)
1. Ambil 700-1000 ml air
1. Ambil  Bumbu halus :
1. Sediakan 8 cabe merah keriting
1. Siapkan 5 cabe rawit (bs di skip)
1. Gunakan 10 bawang merah
1. Siapkan 6 bawang putih
1. Siapkan 4 kemiri
1. Ambil 1 sdt ketumbar
1. Sediakan 1/2 sdt jinten
1. Sediakan Sejempol jahe
1. Gunakan Seruas kunyit
1. Ambil 1 batang sereh (ambil putih nya sj)
1. Gunakan 1 sdm bubuk kari
1. Siapkan  Bumbu tambahan :
1. Ambil 2 daun salam
1. Sediakan 5 daun jeruk
1. Siapkan Secukupnya daun kari (sy gak pake)
1. Siapkan 2 batang kayu manis
1. Siapkan 3 kapulaga
1. Ambil 3 bunga lawang
1. Ambil 4 cengkeh




<!--inarticleads2-->

##### Cara membuat Kari ayam:

1. Siapkan bahan2 bumbu,cuci bersih ayam dan kentang,panaskan minyak tumis dulu kayu manis,cengkeh,kapulaga dan bunga lawang agar tdk terlalu bau langu baru masukan bumbu halus,daun salam daun jeruk tumis hingga matang
1. Masukan ayam aduk rata bru masukan santan lalu beri air aduk terus hingga mendidih masukan garam,gula dan penyedap cek rasa
1. Jika rasa sdh pas tinggal tunggu air menyusut sedikit tidak perlu kering krn kari ini berkuah




Ternyata cara buat kari ayam yang nikamt sederhana ini gampang banget ya! Kamu semua bisa menghidangkannya. Resep kari ayam Sangat sesuai sekali buat kalian yang sedang belajar memasak maupun untuk kalian yang telah lihai memasak.

Tertarik untuk mencoba buat resep kari ayam lezat tidak ribet ini? Kalau kamu mau, yuk kita segera buruan menyiapkan alat dan bahannya, kemudian buat deh Resep kari ayam yang lezat dan tidak ribet ini. Sangat taidak sulit kan. 

Oleh karena itu, ketimbang kita diam saja, yuk kita langsung sajikan resep kari ayam ini. Pasti kalian tiidak akan nyesel sudah membuat resep kari ayam mantab tidak ribet ini! Selamat berkreasi dengan resep kari ayam nikmat tidak ribet ini di rumah sendiri,ya!.

