---
description: "Resep Kari Ayam Pedas yang nikmat dan Mudah Dibuat"
title: "Resep Kari Ayam Pedas yang nikmat dan Mudah Dibuat"
slug: 432-resep-kari-ayam-pedas-yang-nikmat-dan-mudah-dibuat
date: 2021-03-30T22:40:41.721Z
image: https://img-global.cpcdn.com/recipes/a044c2c73343afca/680x482cq70/kari-ayam-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a044c2c73343afca/680x482cq70/kari-ayam-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a044c2c73343afca/680x482cq70/kari-ayam-pedas-foto-resep-utama.jpg
author: Linnie Harmon
ratingvalue: 4.7
reviewcount: 12
recipeingredient:
- "6 potong ayam"
- "1 sdm garam kasar utk rebusan ayam"
- "2 buah kentang"
- "1 lembar daun kunyit"
- "4 lembar daun jeruk"
- "1 batang serei geprek"
- "1 ruas lengkuas geprek"
- "250 ml santan"
- "300 ml air rebusan ayam"
- " Bumbu halus"
- "8 siung bawang merah"
- "3 siung bawang putih"
- "1 cm kunyit"
- "1 cm jahe"
- "2 butir kemiri"
- "1 sdt cabe giling"
- "1 sdt kaldu bubuk"
- "1 sdt ketumbar"
- "1 1/2 sdm bubuk kari"
- "1 sdt lada bubuk"
- "Secukupnya garam"
- "Secukupnya minyak tumis"
recipeinstructions:
- "Rebus ayam tambahkan garam kasar 1 sdm. Masak sampai empuk"
- "Siapkan bumbu, blender halus."
- "Panaskan minyak secukupnya tumis bumbu halus sampai wangi lalu masukan daun kunyit, daun jeruk, serei dan lengkuas lalu tambahkan cabe giling"
- "Masukan ayam yg sudab di rebus tadi lalu tambahkan air rebusan ayam masukan kentang masak sampai setengah mateng kentangnya"
- "Tambahkan santan, bumbu kari, kaldu bubuk, garam, lada bubuk aduk rata koreksi rasa."
- "Siap disajikan.."
categories:
- Resep
tags:
- kari
- ayam
- pedas

katakunci: kari ayam pedas 
nutrition: 177 calories
recipecuisine: Indonesian
preptime: "PT38M"
cooktime: "PT36M"
recipeyield: "3"
recipecategory: Dinner

---


![Kari Ayam Pedas](https://img-global.cpcdn.com/recipes/a044c2c73343afca/680x482cq70/kari-ayam-pedas-foto-resep-utama.jpg)

Selaku seorang istri, mempersiapkan masakan enak buat keluarga adalah suatu hal yang sangat menyenangkan bagi kamu sendiri. Tanggung jawab seorang  wanita bukan hanya mengatur rumah saja, tapi anda pun harus memastikan keperluan gizi tercukupi dan masakan yang dimakan keluarga tercinta mesti nikmat.

Di era  saat ini, kita sebenarnya mampu memesan santapan siap saji tanpa harus susah mengolahnya dulu. Tetapi banyak juga mereka yang selalu mau memberikan yang terlezat untuk orang yang dicintainya. Karena, memasak yang diolah sendiri jauh lebih bersih dan kita juga bisa menyesuaikan masakan tersebut sesuai dengan makanan kesukaan keluarga tercinta. 



Mungkinkah kamu salah satu penggemar kari ayam pedas?. Asal kamu tahu, kari ayam pedas merupakan hidangan khas di Nusantara yang sekarang disukai oleh kebanyakan orang di hampir setiap tempat di Indonesia. Kita dapat memasak kari ayam pedas hasil sendiri di rumahmu dan dapat dijadikan camilan kesenanganmu di hari libur.

Anda tidak perlu bingung untuk memakan kari ayam pedas, karena kari ayam pedas gampang untuk dicari dan kalian pun boleh memasaknya sendiri di rumah. kari ayam pedas dapat dimasak memalui beraneka cara. Saat ini ada banyak sekali cara kekinian yang membuat kari ayam pedas semakin mantap.

Resep kari ayam pedas juga gampang dibikin, lho. Kamu tidak perlu ribet-ribet untuk memesan kari ayam pedas, tetapi Kamu dapat menghidangkan ditempatmu. Untuk Kita yang hendak menyajikannya, di bawah ini adalah resep untuk menyajikan kari ayam pedas yang nikamat yang dapat Kamu buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Kari Ayam Pedas:

1. Sediakan 6 potong ayam
1. Sediakan 1 sdm garam kasar (utk rebusan ayam)
1. Gunakan 2 buah kentang
1. Gunakan 1 lembar daun kunyit
1. Ambil 4 lembar daun jeruk
1. Siapkan 1 batang serei geprek
1. Ambil 1 ruas lengkuas geprek
1. Siapkan 250 ml santan
1. Siapkan 300 ml air rebusan ayam
1. Gunakan  Bumbu halus
1. Sediakan 8 siung bawang merah
1. Sediakan 3 siung bawang putih
1. Sediakan 1 cm kunyit
1. Siapkan 1 cm jahe
1. Siapkan 2 butir kemiri
1. Siapkan 1 sdt cabe giling
1. Sediakan 1 sdt kaldu bubuk
1. Sediakan 1 sdt ketumbar
1. Sediakan 1 1/2 sdm bubuk kari
1. Sediakan 1 sdt lada bubuk
1. Ambil Secukupnya garam
1. Sediakan Secukupnya minyak tumis




<!--inarticleads2-->

##### Cara membuat Kari Ayam Pedas:

1. Rebus ayam tambahkan garam kasar 1 sdm. Masak sampai empuk
1. Siapkan bumbu, blender halus.
1. Panaskan minyak secukupnya tumis bumbu halus sampai wangi lalu masukan daun kunyit, daun jeruk, serei dan lengkuas lalu tambahkan cabe giling
1. Masukan ayam yg sudab di rebus tadi lalu tambahkan air rebusan ayam masukan kentang masak sampai setengah mateng kentangnya
1. Tambahkan santan, bumbu kari, kaldu bubuk, garam, lada bubuk aduk rata koreksi rasa.
1. Siap disajikan..




Ternyata cara membuat kari ayam pedas yang enak tidak ribet ini gampang banget ya! Semua orang dapat mencobanya. Cara Membuat kari ayam pedas Sangat cocok sekali buat kalian yang baru mau belajar memasak ataupun juga untuk anda yang telah pandai dalam memasak.

Tertarik untuk mulai mencoba membuat resep kari ayam pedas mantab simple ini? Kalau kalian mau, ayo kamu segera buruan menyiapkan alat-alat dan bahannya, lalu buat deh Resep kari ayam pedas yang nikmat dan tidak rumit ini. Betul-betul gampang kan. 

Maka, daripada kalian berlama-lama, hayo kita langsung hidangkan resep kari ayam pedas ini. Pasti kamu tiidak akan menyesal sudah buat resep kari ayam pedas lezat sederhana ini! Selamat mencoba dengan resep kari ayam pedas lezat simple ini di tempat tinggal sendiri,ya!.

