---
description: "Resep Ayam Tangkap Khas Aceh yang lezat dan Mudah Dibuat"
title: "Resep Ayam Tangkap Khas Aceh yang lezat dan Mudah Dibuat"
slug: 482-resep-ayam-tangkap-khas-aceh-yang-lezat-dan-mudah-dibuat
date: 2021-04-05T09:33:22.592Z
image: https://img-global.cpcdn.com/recipes/7915a5783234d5af/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7915a5783234d5af/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7915a5783234d5af/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg
author: Pearl Dennis
ratingvalue: 4.6
reviewcount: 5
recipeingredient:
- "1/4 ekor ayam saya pakai bagian paha"
- "Secukupnya minyak goreng"
- " Bahan Ungkep Ayam "
- "400 ml air kelapa"
- "1/2 sdt ketumbar bubuk"
- "1/2 sdt kunyit bubuk"
- "1/4 sdt lada bubuk"
- "1/2 sdt kaldu ayam bubuk"
- "1 sdt garam"
- "1/2 sdt gula pasir"
- "2 siung bawang putih haluskan"
- "2 butir bawang merah haluskan"
- "1 cm jahe haluskan"
- " Bumbu Iris "
- "5 butir bawang merah"
- "2 siung bawang putih"
- "5 buah cabe rawit"
- "4 buah cabe ijo keriting"
- "2 lembar daun pandan"
- "5 lembar daun salam koja  salam biasa tambahan saya"
recipeinstructions:
- "Siapkan semua bahan. Cuci ayam, lumuri jeruk nipis, diamkan sebentar lalu bilas. Siapkan bumbu iris juga."
- "Ungkep ayam : siapkan panci/wajan, masukkan ayam, tuang air kelapa. Tambahkan semua bumbu bubuk, garam, gula, aduk rata. Masak sampai mendidih. Jika sudah mendidih, masukkan bumbu ungkep halus, aduk rata. Masak sampai air menyusut, gunakan api sedang."
- "Jika air sudah susut (tidak sampai habis ya airnya) angkat ayamnya. Siapkan wajan/panci untuk menggoreng, panaskan minyak. Goreng ayam dengan api kecil sampai berwarna keemasan. Di tengah-tengah menggoreng, masukkan air ungkep ayam tadi 2-3x."
- "Saya tiriskan dulu ayam, kurangi sedikit minyaknya. Tumis bawang merah dan bawang putih iris hingga harum, masukkan ayam yang telah digoreng. Masukkan semua bumbu iris, aduk-aduk merata, masak sampai bumbu layu dan wanginya keluar. Matikan kompor, angkat."
- "Sajikan 💜"
categories:
- Resep
tags:
- ayam
- tangkap
- khas

katakunci: ayam tangkap khas 
nutrition: 175 calories
recipecuisine: Indonesian
preptime: "PT13M"
cooktime: "PT41M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam Tangkap Khas Aceh](https://img-global.cpcdn.com/recipes/7915a5783234d5af/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg)

Jika kita seorang yang hobi memasak, menyuguhkan hidangan enak untuk keluarga tercinta adalah hal yang membahagiakan bagi kamu sendiri. Tugas seorang ibu Tidak hanya mengurus rumah saja, tetapi anda juga harus memastikan keperluan nutrisi tercukupi dan olahan yang dimakan anak-anak mesti menggugah selera.

Di waktu  saat ini, kamu memang mampu membeli masakan yang sudah jadi meski tidak harus susah mengolahnya dahulu. Tapi ada juga mereka yang selalu mau memberikan hidangan yang terlezat untuk orang yang dicintainya. Lantaran, memasak yang diolah sendiri akan jauh lebih bersih dan bisa menyesuaikan berdasarkan makanan kesukaan famili. 



Apakah anda merupakan salah satu penggemar ayam tangkap khas aceh?. Tahukah kamu, ayam tangkap khas aceh merupakan sajian khas di Nusantara yang sekarang digemari oleh orang-orang di hampir setiap daerah di Nusantara. Kita bisa membuat ayam tangkap khas aceh sendiri di rumahmu dan boleh dijadikan santapan kegemaranmu di akhir pekan.

Kita jangan bingung jika kamu ingin menyantap ayam tangkap khas aceh, sebab ayam tangkap khas aceh gampang untuk dicari dan juga kalian pun bisa mengolahnya sendiri di tempatmu. ayam tangkap khas aceh bisa diolah lewat bermacam cara. Kini pun telah banyak sekali cara modern yang menjadikan ayam tangkap khas aceh lebih nikmat.

Resep ayam tangkap khas aceh pun mudah untuk dibuat, lho. Kamu jangan ribet-ribet untuk memesan ayam tangkap khas aceh, sebab Kalian bisa menghidangkan di rumahmu. Untuk Kita yang hendak menyajikannya, inilah cara menyajikan ayam tangkap khas aceh yang nikamat yang mampu Kalian coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Ayam Tangkap Khas Aceh:

1. Ambil 1/4 ekor ayam (saya pakai bagian paha)
1. Gunakan Secukupnya minyak goreng
1. Ambil  Bahan Ungkep Ayam :
1. Siapkan 400 ml air kelapa
1. Gunakan 1/2 sdt ketumbar bubuk
1. Ambil 1/2 sdt kunyit bubuk
1. Ambil 1/4 sdt lada bubuk
1. Gunakan 1/2 sdt kaldu ayam bubuk
1. Gunakan 1 sdt garam
1. Ambil 1/2 sdt gula pasir
1. Siapkan 2 siung bawang putih haluskan
1. Gunakan 2 butir bawang merah haluskan
1. Siapkan 1 cm jahe haluskan
1. Gunakan  Bumbu Iris :
1. Ambil 5 butir bawang merah
1. Sediakan 2 siung bawang putih
1. Gunakan 5 buah cabe rawit
1. Gunakan 4 buah cabe ijo keriting
1. Sediakan 2 lembar daun pandan
1. Siapkan 5 lembar daun salam koja / salam biasa (tambahan saya)




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Tangkap Khas Aceh:

1. Siapkan semua bahan. Cuci ayam, lumuri jeruk nipis, diamkan sebentar lalu bilas. Siapkan bumbu iris juga.
<img src="https://img-global.cpcdn.com/steps/8b3c312265760c14/160x128cq70/ayam-tangkap-khas-aceh-langkah-memasak-1-foto.jpg" alt="Ayam Tangkap Khas Aceh"><img src="https://img-global.cpcdn.com/steps/c0e586943e5d3ed5/160x128cq70/ayam-tangkap-khas-aceh-langkah-memasak-1-foto.jpg" alt="Ayam Tangkap Khas Aceh">1. Ungkep ayam : siapkan panci/wajan, masukkan ayam, tuang air kelapa. Tambahkan semua bumbu bubuk, garam, gula, aduk rata. Masak sampai mendidih. Jika sudah mendidih, masukkan bumbu ungkep halus, aduk rata. Masak sampai air menyusut, gunakan api sedang.
1. Jika air sudah susut (tidak sampai habis ya airnya) angkat ayamnya. Siapkan wajan/panci untuk menggoreng, panaskan minyak. Goreng ayam dengan api kecil sampai berwarna keemasan. Di tengah-tengah menggoreng, masukkan air ungkep ayam tadi 2-3x.
1. Saya tiriskan dulu ayam, kurangi sedikit minyaknya. Tumis bawang merah dan bawang putih iris hingga harum, masukkan ayam yang telah digoreng. Masukkan semua bumbu iris, aduk-aduk merata, masak sampai bumbu layu dan wanginya keluar. Matikan kompor, angkat.
1. Sajikan 💜




Wah ternyata cara buat ayam tangkap khas aceh yang nikamt sederhana ini mudah sekali ya! Kamu semua dapat membuatnya. Cara Membuat ayam tangkap khas aceh Sangat cocok sekali untuk anda yang baru belajar memasak ataupun bagi anda yang telah pandai dalam memasak.

Apakah kamu tertarik mencoba membikin resep ayam tangkap khas aceh mantab tidak ribet ini? Kalau anda ingin, ayo kalian segera buruan menyiapkan peralatan dan bahan-bahannya, maka buat deh Resep ayam tangkap khas aceh yang lezat dan tidak rumit ini. Benar-benar gampang kan. 

Maka dari itu, daripada kalian diam saja, yuk kita langsung sajikan resep ayam tangkap khas aceh ini. Dijamin anda tiidak akan menyesal sudah buat resep ayam tangkap khas aceh mantab tidak ribet ini! Selamat berkreasi dengan resep ayam tangkap khas aceh lezat tidak ribet ini di rumah kalian sendiri,ya!.

