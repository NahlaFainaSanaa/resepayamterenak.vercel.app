---
description: "Cara membuat Ayam Woku yang nikmat dan Mudah Dibuat"
title: "Cara membuat Ayam Woku yang nikmat dan Mudah Dibuat"
slug: 340-cara-membuat-ayam-woku-yang-nikmat-dan-mudah-dibuat
date: 2021-03-17T22:14:42.058Z
image: https://img-global.cpcdn.com/recipes/0e4f46437b61525b/680x482cq70/ayam-woku-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0e4f46437b61525b/680x482cq70/ayam-woku-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0e4f46437b61525b/680x482cq70/ayam-woku-foto-resep-utama.jpg
author: Edith Hansen
ratingvalue: 3.9
reviewcount: 13
recipeingredient:
- "3 sayap ayam"
- "8 potong chicken tenderloin"
- "1 ruas serai geprek"
- "1 ikat kemangi"
- "1 lembar daun kunyit ukuran kecil"
- "3 lembar daun pandan ikat satu per satu"
- "2 ruas daun bawang potongpotong agak panjang"
- "2 lembar daun jeruk robek helainya"
- "2 buah tomat potong wedgess"
- "1/2 buah lemon ukuran sedang"
- "10 sdm minyak goreng"
- "300 ml air"
- " Seasoning"
- " Gula merah"
- " Garam"
- " Lada putih bubuk"
- " Kaldu ayam bubuk"
- " Bumbu Dasar Halus"
- "7 siung bawang putih"
- "14 siung bawang merah"
- "2 buah cabai merah besar"
- "3 ruas serai"
- "35 gr kunyit"
- "20 gr jahe"
- "2 buah kemiri"
recipeinstructions:
- "Haluskan bahan-bahan bumbu dasar menggunakan chopper. Jangan terlalu halus."
- "Panaskan minyak. Tumis bumbu halus bersama dengan serai geprek, daun kunyit, dan daun jeruk. Tumis sampai harum dan benar-benar matang."
- "Masukkan seasoning, disusul potongan tomat."
- "Masukkan sayap ayam. Aduk dengan hati-hati."
- "Setelah sayap setengah matang, masukkan potongan tenderloin. Aduk lagi perlahan."
- "Masukkan air, disusul daun pandan."
- "Setelah mendidih dan air agak menyusut (kuah bisa disesuaikan berdasarkan selera), masukkan perasan air lemon, koreksi rasa."
- "Kalau rasa sudah pas, masukkan daun kemangi dan daun bawang. Aduk rata."
- "Siap disajikan bersama nasi putih hangat."
categories:
- Resep
tags:
- ayam
- woku

katakunci: ayam woku 
nutrition: 218 calories
recipecuisine: Indonesian
preptime: "PT10M"
cooktime: "PT33M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Woku](https://img-global.cpcdn.com/recipes/0e4f46437b61525b/680x482cq70/ayam-woku-foto-resep-utama.jpg)

Andai kamu seorang istri, menyuguhkan masakan sedap untuk famili merupakan suatu hal yang mengasyikan bagi kamu sendiri. Kewajiban seorang istri bukan cuma mengerjakan pekerjaan rumah saja, tapi anda pun harus menyediakan kebutuhan nutrisi terpenuhi dan juga panganan yang dikonsumsi keluarga tercinta mesti sedap.

Di waktu  saat ini, kita memang mampu mengorder santapan siap saji tanpa harus repot memasaknya terlebih dahulu. Tetapi banyak juga lho orang yang memang ingin menghidangkan yang terbaik bagi orang yang dicintainya. Sebab, menghidangkan masakan sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan makanan tersebut sesuai masakan kesukaan keluarga. 



Apakah anda salah satu penggemar ayam woku?. Asal kamu tahu, ayam woku merupakan hidangan khas di Nusantara yang saat ini disenangi oleh banyak orang di hampir setiap wilayah di Nusantara. Anda dapat menghidangkan ayam woku sendiri di rumahmu dan dapat dijadikan makanan favorit di hari libur.

Anda tidak usah bingung untuk memakan ayam woku, karena ayam woku sangat mudah untuk didapatkan dan juga kamu pun boleh menghidangkannya sendiri di tempatmu. ayam woku dapat diolah dengan berbagai cara. Kini pun telah banyak resep kekinian yang membuat ayam woku semakin mantap.

Resep ayam woku juga mudah untuk dibikin, lho. Anda tidak perlu repot-repot untuk memesan ayam woku, sebab Anda dapat membuatnya sendiri di rumah. Bagi Kamu yang hendak menghidangkannya, berikut resep membuat ayam woku yang mantab yang mampu Kalian coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Ayam Woku:

1. Sediakan 3 sayap ayam
1. Ambil 8 potong chicken tenderloin
1. Sediakan 1 ruas serai (geprek)
1. Gunakan 1 ikat kemangi
1. Ambil 1 lembar daun kunyit ukuran kecil
1. Sediakan 3 lembar daun pandan (ikat satu per satu)
1. Sediakan 2 ruas daun bawang (potong-potong agak panjang)
1. Gunakan 2 lembar daun jeruk (robek helainya)
1. Ambil 2 buah tomat (potong wedgess)
1. Sediakan 1/2 buah lemon ukuran sedang
1. Ambil 10 sdm minyak goreng
1. Gunakan 300 ml air
1. Ambil  Seasoning
1. Siapkan  Gula merah
1. Ambil  Garam
1. Ambil  Lada putih bubuk
1. Ambil  Kaldu ayam bubuk
1. Siapkan  Bumbu Dasar Halus
1. Sediakan 7 siung bawang putih
1. Gunakan 14 siung bawang merah
1. Gunakan 2 buah cabai merah besar
1. Sediakan 3 ruas serai
1. Gunakan 35 gr kunyit
1. Gunakan 20 gr jahe
1. Sediakan 2 buah kemiri




<!--inarticleads2-->

##### Cara membuat Ayam Woku:

1. Haluskan bahan-bahan bumbu dasar menggunakan chopper. Jangan terlalu halus.
1. Panaskan minyak. Tumis bumbu halus bersama dengan serai geprek, daun kunyit, dan daun jeruk. Tumis sampai harum dan benar-benar matang.
1. Masukkan seasoning, disusul potongan tomat.
1. Masukkan sayap ayam. Aduk dengan hati-hati.
1. Setelah sayap setengah matang, masukkan potongan tenderloin. Aduk lagi perlahan.
1. Masukkan air, disusul daun pandan.
1. Setelah mendidih dan air agak menyusut (kuah bisa disesuaikan berdasarkan selera), masukkan perasan air lemon, koreksi rasa.
1. Kalau rasa sudah pas, masukkan daun kemangi dan daun bawang. Aduk rata.
1. Siap disajikan bersama nasi putih hangat.




Wah ternyata cara membuat ayam woku yang enak simple ini enteng sekali ya! Kamu semua mampu memasaknya. Resep ayam woku Sesuai banget buat kalian yang baru belajar memasak ataupun bagi kamu yang sudah pandai memasak.

Apakah kamu tertarik mulai mencoba membuat resep ayam woku enak simple ini? Kalau kamu ingin, yuk kita segera buruan siapkan peralatan dan bahan-bahannya, kemudian buat deh Resep ayam woku yang enak dan simple ini. Sungguh gampang kan. 

Maka, ketimbang kita diam saja, yuk kita langsung saja hidangkan resep ayam woku ini. Pasti anda gak akan nyesel membuat resep ayam woku nikmat sederhana ini! Selamat berkreasi dengan resep ayam woku enak tidak rumit ini di tempat tinggal sendiri,oke!.

