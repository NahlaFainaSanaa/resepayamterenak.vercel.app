---
description: "Resep Lontong Kare Ayam Sederhana dan Mudah Dibuat"
title: "Resep Lontong Kare Ayam Sederhana dan Mudah Dibuat"
slug: 367-resep-lontong-kare-ayam-sederhana-dan-mudah-dibuat
date: 2021-02-10T21:39:06.336Z
image: https://img-global.cpcdn.com/recipes/ed4c6a1edf4d1c7b/680x482cq70/lontong-kare-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ed4c6a1edf4d1c7b/680x482cq70/lontong-kare-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ed4c6a1edf4d1c7b/680x482cq70/lontong-kare-ayam-foto-resep-utama.jpg
author: Lora Stewart
ratingvalue: 4.3
reviewcount: 4
recipeingredient:
- "1 ekor ayam kampung"
- "1 buah jeruk nipis untuk bersihkan ayam"
- "2 lembar daun jeruk buang tulangnya"
- "2 buah sereh uk kecil geprek"
- "Secukupnya gula dan garam"
- "1 buah santan sun kara kecifibercreme"
- "1 liter Air"
- " Bumbu halus"
- "7 buah bawang merah"
- "5 buah bawang putih"
- "3 buah kemiri sangrai"
- "3 buah cabe merah buang bijinya"
- "2 cm jahe"
- "1 ruas kunyit dibakar"
- "1 sdt biji ketumbar"
recipeinstructions:
- "Cuci ayam, beri perasan jeruk nipis, diamkan bbrp saat. Cuci bersih. Sisihkan. Haluskan bumbu ditambahkan minyak sedikit. Kemudian tumis bumbu halus hingga wangi. Masukkan daun jeruk dan sereh."
- "Masukkan ayam, dan air. Masak hingga matang. Terakhir masukkan gula dan garam dan santan. Aduk hingga sedikit kental. Koreksi rasa dan siap di sajikan dengan lontong dan acar"
categories:
- Resep
tags:
- lontong
- kare
- ayam

katakunci: lontong kare ayam 
nutrition: 209 calories
recipecuisine: Indonesian
preptime: "PT29M"
cooktime: "PT55M"
recipeyield: "4"
recipecategory: Lunch

---


![Lontong Kare Ayam](https://img-global.cpcdn.com/recipes/ed4c6a1edf4d1c7b/680x482cq70/lontong-kare-ayam-foto-resep-utama.jpg)

Jika kita seorang orang tua, menyuguhkan olahan sedap pada keluarga merupakan hal yang menyenangkan bagi kamu sendiri. Peran seorang  wanita Tidak sekadar mengerjakan pekerjaan rumah saja, tapi anda pun harus menyediakan keperluan nutrisi tercukupi dan panganan yang disantap keluarga tercinta wajib nikmat.

Di zaman  saat ini, kita sebenarnya dapat memesan panganan jadi walaupun tidak harus repot mengolahnya dulu. Namun ada juga mereka yang memang ingin memberikan makanan yang terlezat bagi keluarganya. Karena, menghidangkan masakan yang diolah sendiri jauh lebih bersih dan kita juga bisa menyesuaikan sesuai dengan masakan kesukaan keluarga tercinta. 



Apakah anda adalah seorang penikmat lontong kare ayam?. Tahukah kamu, lontong kare ayam adalah hidangan khas di Indonesia yang saat ini digemari oleh kebanyakan orang dari hampir setiap wilayah di Indonesia. Kamu dapat membuat lontong kare ayam hasil sendiri di rumahmu dan boleh jadi camilan kegemaranmu di akhir pekan.

Kita jangan bingung jika kamu ingin mendapatkan lontong kare ayam, karena lontong kare ayam tidak sukar untuk ditemukan dan kalian pun bisa mengolahnya sendiri di tempatmu. lontong kare ayam boleh diolah dengan beragam cara. Kini pun telah banyak banget cara modern yang menjadikan lontong kare ayam lebih mantap.

Resep lontong kare ayam pun mudah dihidangkan, lho. Kamu tidak usah capek-capek untuk memesan lontong kare ayam, lantaran Kita mampu membuatnya sendiri di rumah. Bagi Kalian yang mau menyajikannya, berikut ini cara untuk membuat lontong kare ayam yang mantab yang mampu Kamu hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Lontong Kare Ayam:

1. Siapkan 1 ekor ayam kampung
1. Ambil 1 buah jeruk nipis (untuk bersihkan ayam)
1. Sediakan 2 lembar daun jeruk (buang tulangnya)
1. Siapkan 2 buah sereh uk kecil, geprek
1. Gunakan Secukupnya gula dan garam
1. Ambil 1 buah santan sun kara keci/fibercreme
1. Siapkan 1 liter Air
1. Siapkan  Bumbu halus:
1. Ambil 7 buah bawang merah
1. Ambil 5 buah bawang putih
1. Ambil 3 buah kemiri sangrai
1. Ambil 3 buah cabe merah (buang bijinya)
1. Ambil 2 cm jahe
1. Siapkan 1 ruas kunyit (dibakar)
1. Ambil 1 sdt biji ketumbar




<!--inarticleads2-->

##### Langkah-langkah membuat Lontong Kare Ayam:

1. Cuci ayam, beri perasan jeruk nipis, diamkan bbrp saat. Cuci bersih. Sisihkan. Haluskan bumbu ditambahkan minyak sedikit. Kemudian tumis bumbu halus hingga wangi. Masukkan daun jeruk dan sereh.
1. Masukkan ayam, dan air. Masak hingga matang. Terakhir masukkan gula dan garam dan santan. Aduk hingga sedikit kental. Koreksi rasa dan siap di sajikan dengan lontong dan acar




Ternyata resep lontong kare ayam yang enak sederhana ini mudah banget ya! Anda Semua dapat membuatnya. Cara Membuat lontong kare ayam Sesuai sekali buat anda yang baru mau belajar memasak atau juga bagi anda yang sudah hebat memasak.

Tertarik untuk mulai mencoba bikin resep lontong kare ayam enak simple ini? Kalau kamu tertarik, ayo kamu segera buruan menyiapkan alat-alat dan bahannya, lalu buat deh Resep lontong kare ayam yang lezat dan sederhana ini. Betul-betul taidak sulit kan. 

Maka dari itu, ketimbang anda diam saja, hayo kita langsung saja buat resep lontong kare ayam ini. Dijamin anda tiidak akan nyesel sudah buat resep lontong kare ayam lezat simple ini! Selamat berkreasi dengan resep lontong kare ayam lezat simple ini di rumah masing-masing,ya!.

