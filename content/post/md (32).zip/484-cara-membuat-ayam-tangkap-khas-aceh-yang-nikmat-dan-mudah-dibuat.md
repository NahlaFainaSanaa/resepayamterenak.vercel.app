---
description: "Cara membuat Ayam Tangkap Khas Aceh yang nikmat dan Mudah Dibuat"
title: "Cara membuat Ayam Tangkap Khas Aceh yang nikmat dan Mudah Dibuat"
slug: 484-cara-membuat-ayam-tangkap-khas-aceh-yang-nikmat-dan-mudah-dibuat
date: 2021-07-03T20:45:31.159Z
image: https://img-global.cpcdn.com/recipes/b9c7eb78531a3d66/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b9c7eb78531a3d66/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b9c7eb78531a3d66/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg
author: Logan Hart
ratingvalue: 3.7
reviewcount: 13
recipeingredient:
- "1/2 ekor ayam kampung"
- "1 lembar daun pandan potongpotong"
- "2 cm Lengkuas"
- "2 lembar daun salam Koja atau Daun Kari"
- "1 batang sereh"
- "Secukupnya air matang"
- " Bumbu Halus"
- "2 cm jahe"
- "2 cm kunyit"
- "4 siung bawang putih"
- "1 sdt ketumbar"
- "1 sdt lada utuh"
- "Secukupnya Garam sesuai selera"
- "Secukupnya gula pasir sesuai selera"
- " Bahan pelengkap lainnya"
- "1 batang serai memarkan dan potongpotong"
- "3 lembar daun pandan yg besar potong2"
- "3 buah bawang merah rajang halus"
- "4 lembar daun Kari"
- "5 lembar daun jeruk"
- "7 Buah Cabe hijau"
- " Minyak goreng untuk menggoreng ayam"
recipeinstructions:
- "Cuci bersih ayam kampung, kemudian potong2 sesuai selera, beri perasan air jeruk lemon diamkan berberapa saat. Kemudian pindahkan ke panci atau wajan (tiriskan dari air yg tersisa) masukan Lengkuas, daun pandan, daun Kari Dan sereh yg sdh di potong2"
- "Siapkan bumbu yg akan dihaluskan. Kemudian haluskan dengan di ulek atau di blender (sesuai selera saja), jangan lupa tambahkan Garam, ulek hingga halus."
- "Masukkan bumbu halus kedalam wajan yg berisi ayam tadi, kemudian tambahkan air secukupnya (sampai ayam terendam) nyalakan api kemudian ungkep ayam hingga matang."
- "Aduk sesekali kemudian tambahkan gula sedikit, koreksi Rasa. Sambil menunggu ayam matang Kita siapkan bumbu pelengkap. Potong2 semua bumbu pelengkap, kemudian sisihkan."
- "Setelah ayam matang, matikan api. Kemudian siapkan wajan Dan minyak Siapkan minyak goreng dan bumbu pelengkap. Goreng ayam ungkep bersama dengan bumbu pelengkap. Goreng hingga matang kecokelatan, sesekali di Balik."
- "Angkat siap disajikan 😉🙏"
categories:
- Resep
tags:
- ayam
- tangkap
- khas

katakunci: ayam tangkap khas 
nutrition: 127 calories
recipecuisine: Indonesian
preptime: "PT20M"
cooktime: "PT34M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Tangkap Khas Aceh](https://img-global.cpcdn.com/recipes/b9c7eb78531a3d66/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg)

Selaku seorang ibu, menyuguhkan olahan menggugah selera bagi keluarga tercinta merupakan hal yang membahagiakan untuk kamu sendiri. Tanggung jawab seorang ibu bukan saja mengurus rumah saja, tetapi kamu pun wajib menyediakan kebutuhan gizi terpenuhi dan hidangan yang disantap orang tercinta wajib sedap.

Di masa  sekarang, kamu sebenarnya mampu memesan panganan jadi walaupun tanpa harus susah memasaknya dulu. Tapi ada juga lho mereka yang selalu mau menyajikan yang terlezat bagi keluarganya. Karena, memasak sendiri jauh lebih higienis dan kita pun bisa menyesuaikan berdasarkan makanan kesukaan keluarga. 



Apakah kamu salah satu penyuka ayam tangkap khas aceh?. Tahukah kamu, ayam tangkap khas aceh merupakan makanan khas di Indonesia yang saat ini disukai oleh orang-orang dari berbagai wilayah di Nusantara. Kamu bisa menghidangkan ayam tangkap khas aceh buatan sendiri di rumah dan pasti jadi makanan kesenanganmu di akhir pekan.

Anda jangan bingung untuk mendapatkan ayam tangkap khas aceh, karena ayam tangkap khas aceh mudah untuk dicari dan juga kamu pun boleh membuatnya sendiri di tempatmu. ayam tangkap khas aceh dapat diolah memalui bermacam cara. Sekarang telah banyak resep kekinian yang menjadikan ayam tangkap khas aceh semakin lebih enak.

Resep ayam tangkap khas aceh juga gampang untuk dibikin, lho. Anda tidak perlu capek-capek untuk memesan ayam tangkap khas aceh, tetapi Kalian mampu menyajikan di rumah sendiri. Bagi Kamu yang mau menghidangkannya, berikut ini cara menyajikan ayam tangkap khas aceh yang mantab yang bisa Kita buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Ayam Tangkap Khas Aceh:

1. Ambil 1/2 ekor ayam kampung
1. Siapkan 1 lembar daun pandan, potong-potong
1. Gunakan 2 cm Lengkuas
1. Ambil 2 lembar daun salam Koja atau Daun Kari
1. Ambil 1 batang sereh
1. Siapkan Secukupnya air matang
1. Gunakan  Bumbu Halus
1. Gunakan 2 cm jahe
1. Siapkan 2 cm kunyit
1. Siapkan 4 siung bawang putih
1. Ambil 1 sdt ketumbar
1. Sediakan 1 sdt lada utuh
1. Sediakan Secukupnya Garam (sesuai selera)
1. Sediakan Secukupnya gula pasir (sesuai selera)
1. Sediakan  Bahan pelengkap lainnya
1. Siapkan 1 batang serai, memarkan dan potong-potong
1. Sediakan 3 lembar daun pandan yg besar potong2
1. Siapkan 3 buah bawang merah rajang halus
1. Siapkan 4 lembar daun Kari
1. Ambil 5 lembar daun jeruk
1. Siapkan 7 Buah Cabe hijau
1. Siapkan  Minyak goreng untuk menggoreng ayam




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Tangkap Khas Aceh:

1. Cuci bersih ayam kampung, kemudian potong2 sesuai selera, beri perasan air jeruk lemon diamkan berberapa saat. Kemudian pindahkan ke panci atau wajan (tiriskan dari air yg tersisa) masukan Lengkuas, daun pandan, daun Kari Dan sereh yg sdh di potong2
1. Siapkan bumbu yg akan dihaluskan. Kemudian haluskan dengan di ulek atau di blender (sesuai selera saja), jangan lupa tambahkan Garam, ulek hingga halus.
1. Masukkan bumbu halus kedalam wajan yg berisi ayam tadi, kemudian tambahkan air secukupnya (sampai ayam terendam) nyalakan api kemudian ungkep ayam hingga matang.
1. Aduk sesekali kemudian tambahkan gula sedikit, koreksi Rasa. Sambil menunggu ayam matang Kita siapkan bumbu pelengkap. Potong2 semua bumbu pelengkap, kemudian sisihkan.
1. Setelah ayam matang, matikan api. Kemudian siapkan wajan Dan minyak Siapkan minyak goreng dan bumbu pelengkap. Goreng ayam ungkep bersama dengan bumbu pelengkap. Goreng hingga matang kecokelatan, sesekali di Balik.
1. Angkat siap disajikan 😉🙏




Ternyata cara membuat ayam tangkap khas aceh yang mantab tidak ribet ini enteng banget ya! Kamu semua mampu memasaknya. Resep ayam tangkap khas aceh Sesuai sekali buat kamu yang baru mau belajar memasak atau juga bagi kamu yang sudah jago memasak.

Tertarik untuk mencoba membuat resep ayam tangkap khas aceh lezat sederhana ini? Kalau ingin, mending kamu segera buruan menyiapkan alat-alat dan bahannya, kemudian buat deh Resep ayam tangkap khas aceh yang nikmat dan simple ini. Benar-benar mudah kan. 

Oleh karena itu, ketimbang kalian diam saja, maka kita langsung sajikan resep ayam tangkap khas aceh ini. Dijamin kamu tak akan nyesel membuat resep ayam tangkap khas aceh enak tidak rumit ini! Selamat berkreasi dengan resep ayam tangkap khas aceh enak simple ini di rumah kalian sendiri,ya!.

