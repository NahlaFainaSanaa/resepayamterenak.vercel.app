---
description: "Cara buat Lontong Kari Ayam yang lezat Untuk Jualan"
title: "Cara buat Lontong Kari Ayam yang lezat Untuk Jualan"
slug: 372-cara-buat-lontong-kari-ayam-yang-lezat-untuk-jualan
date: 2021-03-15T02:05:26.444Z
image: https://img-global.cpcdn.com/recipes/d74163c548c4a171/680x482cq70/lontong-kari-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d74163c548c4a171/680x482cq70/lontong-kari-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d74163c548c4a171/680x482cq70/lontong-kari-ayam-foto-resep-utama.jpg
author: Bettie Ortega
ratingvalue: 4.5
reviewcount: 6
recipeingredient:
- " Resep Kari Ayam"
- " Ayam cuci bersih"
- " santan"
- " Tumis"
- " Daun salam"
- " Serai geprek"
- " Lengkuas geprek"
- "Bunga lawang"
- " Kapulaga"
- " Pala"
- " Bumbu Halus"
- " Bawang Merah"
- " Bawang putih"
- " Kemiri"
- " Ketumbar"
- " Jahe"
- " Kunyit"
- " Cabe merah"
- " Resep sambal"
- " Cabe keriting"
- " Rawit merah"
- " Bawang merah"
- " Bawang putih"
recipeinstructions:
- "Cuci ayam sisihkan"
- "Haluskan bahan2 bumbu halus. Tumis beserta salam, serai dan laos. Masukkan air dan ayam satu persatu. Masukkan kapulaga, pala dan kembang lawang. Masak ayam hingga setengah matang. Masukkan 1 bungkus kecil kara, beri garam, kaldu jamur dan merica. Masak sampai matang."
- "Rebus semua bahan sambal sampai layu. Blender dengan sedikit air. Beri garam dan penyedap"
- "Lontong saya pakai lontong instan. Rebus selama 1 jam"
- "Sajikan kari ayam dengan lontong damnsambal. Ditambah kerupuk lebih nikmat"
categories:
- Resep
tags:
- lontong
- kari
- ayam

katakunci: lontong kari ayam 
nutrition: 289 calories
recipecuisine: Indonesian
preptime: "PT30M"
cooktime: "PT34M"
recipeyield: "2"
recipecategory: Dessert

---


![Lontong Kari Ayam](https://img-global.cpcdn.com/recipes/d74163c548c4a171/680x482cq70/lontong-kari-ayam-foto-resep-utama.jpg)

Sebagai seorang istri, menyediakan santapan enak buat orang tercinta adalah hal yang mengasyikan untuk kamu sendiri. Tanggung jawab seorang istri bukan sekedar mengatur rumah saja, namun kamu pun harus menyediakan kebutuhan nutrisi terpenuhi dan panganan yang dikonsumsi anak-anak harus enak.

Di era  saat ini, kamu memang mampu mengorder hidangan praktis meski tanpa harus capek memasaknya terlebih dahulu. Namun banyak juga orang yang selalu mau menghidangkan yang terbaik bagi orang yang dicintainya. Sebab, memasak yang dibuat sendiri jauh lebih bersih dan kita juga bisa menyesuaikan masakan tersebut sesuai selera famili. 



Mungkinkah kamu seorang penyuka lontong kari ayam?. Tahukah kamu, lontong kari ayam merupakan hidangan khas di Nusantara yang sekarang disenangi oleh kebanyakan orang di berbagai daerah di Indonesia. Kamu dapat memasak lontong kari ayam kreasi sendiri di rumah dan pasti jadi hidangan kesukaanmu di hari libur.

Kita jangan bingung untuk mendapatkan lontong kari ayam, sebab lontong kari ayam tidak sulit untuk ditemukan dan kamu pun bisa membuatnya sendiri di tempatmu. lontong kari ayam boleh dibuat lewat bermacam cara. Kini sudah banyak sekali resep kekinian yang membuat lontong kari ayam semakin lebih lezat.

Resep lontong kari ayam pun sangat gampang dibuat, lho. Anda jangan ribet-ribet untuk membeli lontong kari ayam, karena Kita dapat menghidangkan sendiri di rumah. Untuk Anda yang mau membuatnya, dibawah ini merupakan cara untuk membuat lontong kari ayam yang lezat yang bisa Anda coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Lontong Kari Ayam:

1. Sediakan  Resep Kari Ayam
1. Ambil  Ayam cuci bersih
1. Gunakan  santan
1. Siapkan  Tumis
1. Sediakan  Daun salam
1. Siapkan  Serai geprek
1. Gunakan  Lengkuas geprek
1. Sediakan Bunga lawang
1. Sediakan  Kapulaga
1. Siapkan  Pala
1. Sediakan  Bumbu Halus
1. Gunakan  Bawang Merah
1. Gunakan  Bawang putih
1. Gunakan  Kemiri
1. Ambil  Ketumbar
1. Gunakan  Jahe
1. Siapkan  Kunyit
1. Sediakan  Cabe merah
1. Gunakan  Resep sambal
1. Gunakan  Cabe keriting
1. Siapkan  Rawit merah
1. Ambil  Bawang merah
1. Gunakan  Bawang putih




<!--inarticleads2-->

##### Cara menyiapkan Lontong Kari Ayam:

1. Cuci ayam sisihkan
1. Haluskan bahan2 bumbu halus. Tumis beserta salam, serai dan laos. Masukkan air dan ayam satu persatu. Masukkan kapulaga, pala dan kembang lawang. Masak ayam hingga setengah matang. Masukkan 1 bungkus kecil kara, beri garam, kaldu jamur dan merica. Masak sampai matang.
1. Rebus semua bahan sambal sampai layu. Blender dengan sedikit air. Beri garam dan penyedap
1. Lontong saya pakai lontong instan. Rebus selama 1 jam
1. Sajikan kari ayam dengan lontong damnsambal. Ditambah kerupuk lebih nikmat




Ternyata resep lontong kari ayam yang nikamt sederhana ini mudah sekali ya! Anda Semua dapat menghidangkannya. Cara Membuat lontong kari ayam Sesuai banget untuk anda yang baru belajar memasak atau juga untuk kalian yang sudah jago memasak.

Tertarik untuk mulai mencoba buat resep lontong kari ayam lezat simple ini? Kalau kalian tertarik, ayo kamu segera siapin alat-alat dan bahan-bahannya, setelah itu buat deh Resep lontong kari ayam yang mantab dan simple ini. Sangat gampang kan. 

Maka dari itu, daripada kamu berlama-lama, hayo kita langsung hidangkan resep lontong kari ayam ini. Pasti kamu tak akan menyesal sudah membuat resep lontong kari ayam enak tidak rumit ini! Selamat mencoba dengan resep lontong kari ayam lezat sederhana ini di tempat tinggal kalian sendiri,ya!.

