---
description: "Resep Ayam bumbu rujak kemangi yang enak Untuk Jualan"
title: "Resep Ayam bumbu rujak kemangi yang enak Untuk Jualan"
slug: 356-resep-ayam-bumbu-rujak-kemangi-yang-enak-untuk-jualan
date: 2021-01-24T07:37:54.285Z
image: https://img-global.cpcdn.com/recipes/f4328fc5b3f39402/680x482cq70/ayam-bumbu-rujak-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f4328fc5b3f39402/680x482cq70/ayam-bumbu-rujak-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f4328fc5b3f39402/680x482cq70/ayam-bumbu-rujak-kemangi-foto-resep-utama.jpg
author: Elsie Wong
ratingvalue: 4.3
reviewcount: 14
recipeingredient:
- "3 potong ayam"
- "2 daun salam"
- "3 daun jeruk"
- "1 btg sereh digeprek"
- "2 cm lengkuas geprek"
- "1 genggam daun kemangi"
- "1 jumput Gula merah iris"
- " Air asem jawa"
- "1/2 Santan kara kecil"
- "secukupnya Garam dan penyedap rasa"
- " Minyak goreng"
- "secukupnya Air"
- " Bumbu Halus"
- "4 siung bawang putih"
- "5 siung bawang merah"
- "5 cabe merah rawit"
- "4 cabe merah keriting"
- "2 cm Kunyit"
- "3 kemiri"
recipeinstructions:
- "Marinasi ayam dengan garam. Selama 10 menit"
- "Goreng agak kecokelatan tiriskan"
- "Sedikit minyak untuk menumis bumbu halus, masukan sereh,daun jeruk, salam, lengkuas... Sampai harum Lalu gula merah, air asem jawa, dan santan. cicipi rasa pedas manis asam, tambahkan air secukupnya nya."
- "Terakhir masukan ayam dan daun kemangi, tunggu sampai air menyusut. Siap dihidangkan... Dengan nasi hangat..."
categories:
- Resep
tags:
- ayam
- bumbu
- rujak

katakunci: ayam bumbu rujak 
nutrition: 274 calories
recipecuisine: Indonesian
preptime: "PT40M"
cooktime: "PT31M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam bumbu rujak kemangi](https://img-global.cpcdn.com/recipes/f4328fc5b3f39402/680x482cq70/ayam-bumbu-rujak-kemangi-foto-resep-utama.jpg)

Andai kalian seorang orang tua, menyuguhkan santapan nikmat kepada keluarga adalah suatu hal yang membahagiakan untuk kita sendiri. Peran seorang istri Tidak sekadar mengerjakan pekerjaan rumah saja, namun kamu pun wajib memastikan keperluan gizi tercukupi dan juga panganan yang dikonsumsi keluarga tercinta wajib mantab.

Di zaman  saat ini, kalian sebenarnya bisa mengorder panganan siap saji tanpa harus repot membuatnya terlebih dahulu. Namun ada juga orang yang memang mau memberikan hidangan yang terbaik bagi orang tercintanya. Sebab, memasak sendiri jauh lebih higienis dan kita juga bisa menyesuaikan makanan tersebut sesuai makanan kesukaan famili. 



Apakah anda adalah salah satu penikmat ayam bumbu rujak kemangi?. Asal kamu tahu, ayam bumbu rujak kemangi merupakan makanan khas di Indonesia yang kini digemari oleh kebanyakan orang dari hampir setiap wilayah di Indonesia. Kita bisa membuat ayam bumbu rujak kemangi kreasi sendiri di rumahmu dan boleh jadi hidangan kegemaranmu di hari liburmu.

Kalian tak perlu bingung jika kamu ingin menyantap ayam bumbu rujak kemangi, lantaran ayam bumbu rujak kemangi gampang untuk didapatkan dan anda pun bisa menghidangkannya sendiri di rumah. ayam bumbu rujak kemangi dapat diolah dengan bermacam cara. Kini pun sudah banyak sekali resep modern yang menjadikan ayam bumbu rujak kemangi semakin lezat.

Resep ayam bumbu rujak kemangi pun sangat mudah untuk dibikin, lho. Kalian tidak usah repot-repot untuk membeli ayam bumbu rujak kemangi, sebab Anda bisa membuatnya di rumah sendiri. Bagi Kita yang hendak membuatnya, berikut cara menyajikan ayam bumbu rujak kemangi yang mantab yang dapat Kamu coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Ayam bumbu rujak kemangi:

1. Gunakan 3 potong ayam
1. Sediakan 2 daun salam
1. Sediakan 3 daun jeruk
1. Sediakan 1 btg sereh digeprek
1. Sediakan 2 cm lengkuas geprek
1. Sediakan 1 genggam daun kemangi
1. Ambil 1 jumput Gula merah iris
1. Gunakan  Air asem jawa
1. Siapkan 1/2 Santan kara kecil
1. Siapkan secukupnya Garam dan penyedap rasa
1. Sediakan  Minyak goreng
1. Siapkan secukupnya Air
1. Ambil  Bumbu Halus
1. Sediakan 4 siung bawang putih
1. Ambil 5 siung bawang merah
1. Gunakan 5 cabe merah rawit
1. Ambil 4 cabe merah keriting
1. Siapkan 2 cm Kunyit
1. Gunakan 3 kemiri




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam bumbu rujak kemangi:

1. Marinasi ayam dengan garam. Selama 10 menit
1. Goreng agak kecokelatan tiriskan
1. Sedikit minyak untuk menumis bumbu halus, masukan sereh,daun jeruk, salam, lengkuas... Sampai harum Lalu gula merah, air asem jawa, dan santan. cicipi rasa pedas manis asam, tambahkan air secukupnya nya.
1. Terakhir masukan ayam dan daun kemangi, tunggu sampai air menyusut. Siap dihidangkan... Dengan nasi hangat...




Ternyata cara membuat ayam bumbu rujak kemangi yang mantab sederhana ini enteng sekali ya! Anda Semua dapat memasaknya. Cara buat ayam bumbu rujak kemangi Sangat sesuai sekali buat kalian yang baru akan belajar memasak atau juga bagi kamu yang sudah hebat dalam memasak.

Tertarik untuk mulai mencoba bikin resep ayam bumbu rujak kemangi lezat simple ini? Kalau anda ingin, ayo kamu segera buruan menyiapkan alat dan bahannya, lantas buat deh Resep ayam bumbu rujak kemangi yang mantab dan tidak ribet ini. Sungguh gampang kan. 

Oleh karena itu, ketimbang kalian berlama-lama, yuk kita langsung saja hidangkan resep ayam bumbu rujak kemangi ini. Dijamin anda tak akan menyesal sudah membuat resep ayam bumbu rujak kemangi mantab tidak rumit ini! Selamat mencoba dengan resep ayam bumbu rujak kemangi nikmat tidak rumit ini di rumah sendiri,ya!.

