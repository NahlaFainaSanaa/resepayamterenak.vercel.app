---
description: "Bahan-bahan Ayam Bakar Bumbu Rujak + Sambal yang lezat Untuk Jualan"
title: "Bahan-bahan Ayam Bakar Bumbu Rujak + Sambal yang lezat Untuk Jualan"
slug: 477-bahan-bahan-ayam-bakar-bumbu-rujak-sambal-yang-lezat-untuk-jualan
date: 2021-05-26T16:04:13.274Z
image: https://img-global.cpcdn.com/recipes/9753c76134f15b59/680x482cq70/ayam-bakar-bumbu-rujak-sambal-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9753c76134f15b59/680x482cq70/ayam-bakar-bumbu-rujak-sambal-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9753c76134f15b59/680x482cq70/ayam-bakar-bumbu-rujak-sambal-foto-resep-utama.jpg
author: Glen Kelly
ratingvalue: 4.4
reviewcount: 7
recipeingredient:
- "12 potong ayam"
- " Bumbu Halus"
- "8 siung bawang merah"
- "7 siung bawang putih"
- "15 buah cabe merah keriting"
- "5 buah cabe rawit merah"
- "1 ruas kunyit bakar"
- "3 butir kemiri sangrai"
- "Secukupnya minyak sayur untuk menumis"
- " Bumbu Pelengkap"
- "65 ml santan kara"
- "1 jempol lengkuas geprek"
- "1 batang serai geprek"
- "3 lembar daun salam"
- "3 lembar daun jeruk"
- "1 sdm gula merah"
- "1-2 sdm air asam jawa"
- "Secukupnya garam sesuaikan"
- "Secukupnya kaldu bubuk sesuaikan"
- "Secukupnya air"
- " Bumbu Oles aduk rata"
- "1-2 sdm margarin cairkan"
- "Secukupnya kecap manis"
- " Sambal"
- "4 buah cabe merah keriting"
- "13 buah cabe rawit merah"
- "7 siung bawang merah"
- "1 buah tomat besar"
- "1 sachet terasi bakar"
- "1 sdt gula merah"
- "Secukupnya garam sesuaikan"
- "Secukupnya minyak sayur agak banyak"
- "1 buah jeruk limo"
recipeinstructions:
- "Cuci bersih ayam, rebus sebentar untuk menghilangkan kotoran, tiriskan. Panaskan minyak sayur, tumis bumbu halus bersama lengkuas, serai, daun salam dan daun jeruk hingga harum"
- "Masukkan ayam aduk rata, tambahkan air secukupnya masak hingga ayam empuk"
- "Tambahkan garam, kaldu bubuk, air asam jawa, gula merah dan santan kara masak hingga bumbu meresap"
- "Angkat ayam tunggu dingin lalu bakar di atas api, olesi dengan bumbu oles bolak - balik"
- "Sambal : blend duo cabe, bawang merah, tomat dan terasi dengan minyak sayur lalu tumis sampai matang jangan lupa tambahkan garam, gula merah dan juga perasan jeruk limo aduk rata"
- "Sajikan dengan nasi hangat, sambal, lalapan dan tahu tempe goreng 😋"
categories:
- Resep
tags:
- ayam
- bakar
- bumbu

katakunci: ayam bakar bumbu 
nutrition: 266 calories
recipecuisine: Indonesian
preptime: "PT19M"
cooktime: "PT49M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam Bakar Bumbu Rujak + Sambal](https://img-global.cpcdn.com/recipes/9753c76134f15b59/680x482cq70/ayam-bakar-bumbu-rujak-sambal-foto-resep-utama.jpg)

Sebagai seorang wanita, mempersiapkan panganan sedap pada keluarga merupakan hal yang mengasyikan untuk kita sendiri. Tugas seorang ibu Tidak sekedar menjaga rumah saja, tetapi kamu juga wajib memastikan keperluan gizi terpenuhi dan juga masakan yang disantap anak-anak mesti nikmat.

Di masa  saat ini, kalian sebenarnya bisa membeli panganan siap saji walaupun tidak harus repot membuatnya terlebih dahulu. Namun banyak juga lho orang yang memang mau memberikan yang terenak bagi orang tercintanya. Lantaran, memasak sendiri akan jauh lebih bersih dan bisa menyesuaikan makanan tersebut sesuai kesukaan keluarga. 



Mungkinkah kamu seorang penggemar ayam bakar bumbu rujak + sambal?. Tahukah kamu, ayam bakar bumbu rujak + sambal adalah makanan khas di Indonesia yang kini digemari oleh kebanyakan orang di berbagai wilayah di Indonesia. Kalian bisa menyajikan ayam bakar bumbu rujak + sambal sendiri di rumahmu dan dapat dijadikan camilan favoritmu di akhir pekan.

Kalian tak perlu bingung untuk menyantap ayam bakar bumbu rujak + sambal, karena ayam bakar bumbu rujak + sambal tidak sulit untuk didapatkan dan juga kamu pun bisa memasaknya sendiri di tempatmu. ayam bakar bumbu rujak + sambal boleh dimasak memalui berbagai cara. Saat ini sudah banyak sekali cara kekinian yang menjadikan ayam bakar bumbu rujak + sambal semakin lebih enak.

Resep ayam bakar bumbu rujak + sambal juga mudah dibuat, lho. Kalian jangan capek-capek untuk membeli ayam bakar bumbu rujak + sambal, sebab Anda bisa menyajikan di rumah sendiri. Untuk Kamu yang mau menghidangkannya, inilah cara untuk menyajikan ayam bakar bumbu rujak + sambal yang enak yang dapat Kita coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Ayam Bakar Bumbu Rujak + Sambal:

1. Gunakan 12 potong ayam
1. Ambil  Bumbu Halus
1. Gunakan 8 siung bawang merah
1. Sediakan 7 siung bawang putih
1. Gunakan 15 buah cabe merah keriting
1. Siapkan 5 buah cabe rawit merah
1. Gunakan 1 ruas kunyit (bakar)
1. Gunakan 3 butir kemiri (sangrai)
1. Ambil Secukupnya minyak sayur untuk menumis
1. Sediakan  Bumbu Pelengkap
1. Ambil 65 ml santan kara
1. Siapkan 1 jempol lengkuas (geprek)
1. Siapkan 1 batang serai (geprek)
1. Gunakan 3 lembar daun salam
1. Gunakan 3 lembar daun jeruk
1. Ambil 1 sdm gula merah
1. Sediakan 1-2 sdm air asam jawa
1. Sediakan Secukupnya garam (sesuaikan)
1. Sediakan Secukupnya kaldu bubuk (sesuaikan)
1. Gunakan Secukupnya air
1. Ambil  Bumbu Oles (aduk rata)
1. Sediakan 1-2 sdm margarin (cairkan)
1. Siapkan Secukupnya kecap manis
1. Ambil  Sambal
1. Gunakan 4 buah cabe merah keriting
1. Gunakan 13 buah cabe rawit merah
1. Siapkan 7 siung bawang merah
1. Sediakan 1 buah tomat besar
1. Siapkan 1 sachet terasi (bakar)
1. Ambil 1 sdt gula merah
1. Gunakan Secukupnya garam (sesuaikan)
1. Gunakan Secukupnya minyak sayur (agak banyak)
1. Gunakan 1 buah jeruk limo




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Bakar Bumbu Rujak + Sambal:

1. Cuci bersih ayam, rebus sebentar untuk menghilangkan kotoran, tiriskan. Panaskan minyak sayur, tumis bumbu halus bersama lengkuas, serai, daun salam dan daun jeruk hingga harum
1. Masukkan ayam aduk rata, tambahkan air secukupnya masak hingga ayam empuk
1. Tambahkan garam, kaldu bubuk, air asam jawa, gula merah dan santan kara masak hingga bumbu meresap
1. Angkat ayam tunggu dingin lalu bakar di atas api, olesi dengan bumbu oles bolak - balik
1. Sambal : blend duo cabe, bawang merah, tomat dan terasi dengan minyak sayur lalu tumis sampai matang jangan lupa tambahkan garam, gula merah dan juga perasan jeruk limo aduk rata
1. Sajikan dengan nasi hangat, sambal, lalapan dan tahu tempe goreng 😋




Wah ternyata resep ayam bakar bumbu rujak + sambal yang mantab tidak rumit ini enteng banget ya! Kalian semua dapat menghidangkannya. Cara buat ayam bakar bumbu rujak + sambal Sangat sesuai banget buat kita yang baru mau belajar memasak maupun bagi kamu yang telah ahli memasak.

Tertarik untuk mencoba membikin resep ayam bakar bumbu rujak + sambal enak simple ini? Kalau tertarik, mending kamu segera menyiapkan alat dan bahan-bahannya, setelah itu bikin deh Resep ayam bakar bumbu rujak + sambal yang lezat dan tidak ribet ini. Sungguh gampang kan. 

Oleh karena itu, ketimbang kamu diam saja, maka langsung aja bikin resep ayam bakar bumbu rujak + sambal ini. Dijamin kalian tiidak akan nyesel sudah buat resep ayam bakar bumbu rujak + sambal enak tidak rumit ini! Selamat berkreasi dengan resep ayam bakar bumbu rujak + sambal mantab sederhana ini di tempat tinggal kalian sendiri,ya!.

