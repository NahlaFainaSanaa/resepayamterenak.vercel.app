---
description: "Resep Ayam Tangkap Khas Aceh yang lezat dan Mudah Dibuat"
title: "Resep Ayam Tangkap Khas Aceh yang lezat dan Mudah Dibuat"
slug: 491-resep-ayam-tangkap-khas-aceh-yang-lezat-dan-mudah-dibuat
date: 2021-04-23T07:49:33.239Z
image: https://img-global.cpcdn.com/recipes/1c8bac7cbf8c2cea/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1c8bac7cbf8c2cea/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1c8bac7cbf8c2cea/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg
author: Genevieve Hardy
ratingvalue: 4.8
reviewcount: 4
recipeingredient:
- "1 ekor ayam organik bagian dada dan paha potong 8"
- "750 ml Hydrococo"
- " Bumbu halus"
- "3 butir kemiri sangrai"
- "6 butir bawang merah"
- "4 siung bawang putih"
- "5 cm lengkuas"
- "5 cm kunyit"
- " Bumbu cemplung"
- "2 batang serai geprek"
- "5 lembar daun salam"
- "1/2 sdm garam sesuai selera"
- " Bahan cemplung saat menggoreng"
- "4 lembar daun pandan"
- "4 batang daun karisalam koja ambil daunnya"
- "5 lembar daun jeruk"
recipeinstructions:
- "Ayam dilumuri pakai air jeruk nipis kemudian bilas menggunakan air mengalir, tiriskan. Sementara itu bumbu halus dihaluskan."
- "Tumis bumbu halus sampai harum, kemudian masukan ayam, aduk ayam pelan pelan sampai bumbu rata. Selanjutnya tuang hydrococo, serai, daun salam dan garam. Ungkep ayam sampai bumbu meresap dan aii hydrococo menyusut."
- "Kalau sudah set airnya, ayam dapat disimpan di dalam kulkas jika tidak langsung digoreng."
- "Cara menggoreng ayam tangkap:  goreng menggunakan wajan anti lengket dengan minyak yang merendam setengah bagian ayam. Setelah ayam kecoklatan balik bagian sisi lainnya dan masukan daun pandan, daun salam koja, dan daun jeruk nipis."
- "Goreng ayam sampai kecoklatan. Cara penyajian: tuang daun salam koja dan daun pandan di atas piring kemudian letakan ayam di atasnya."
categories:
- Resep
tags:
- ayam
- tangkap
- khas

katakunci: ayam tangkap khas 
nutrition: 110 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT56M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam Tangkap Khas Aceh](https://img-global.cpcdn.com/recipes/1c8bac7cbf8c2cea/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg)

Apabila kita seorang wanita, menyajikan hidangan enak bagi orang tercinta adalah hal yang membahagiakan untuk kita sendiri. Tanggung jawab seorang  wanita Tidak saja mengurus rumah saja, tetapi kamu pun wajib memastikan kebutuhan nutrisi tercukupi dan panganan yang disantap orang tercinta wajib lezat.

Di zaman  sekarang, anda memang dapat membeli olahan yang sudah jadi tidak harus ribet mengolahnya lebih dulu. Tetapi banyak juga mereka yang selalu mau memberikan yang terbaik bagi orang tercintanya. Sebab, menyajikan masakan yang diolah sendiri jauh lebih higienis dan kita juga bisa menyesuaikan berdasarkan selera famili. 



Mungkinkah kamu salah satu penyuka ayam tangkap khas aceh?. Asal kamu tahu, ayam tangkap khas aceh merupakan makanan khas di Indonesia yang saat ini disenangi oleh orang-orang dari berbagai daerah di Nusantara. Anda bisa menghidangkan ayam tangkap khas aceh hasil sendiri di rumahmu dan dapat dijadikan hidangan favoritmu di akhir pekan.

Kita jangan bingung untuk menyantap ayam tangkap khas aceh, sebab ayam tangkap khas aceh mudah untuk dicari dan juga kita pun bisa membuatnya sendiri di tempatmu. ayam tangkap khas aceh boleh dibuat lewat bermacam cara. Sekarang sudah banyak banget resep kekinian yang membuat ayam tangkap khas aceh lebih mantap.

Resep ayam tangkap khas aceh juga mudah dihidangkan, lho. Kamu jangan capek-capek untuk membeli ayam tangkap khas aceh, tetapi Kita mampu menyiapkan di rumahmu. Bagi Kalian yang ingin menghidangkannya, berikut ini resep membuat ayam tangkap khas aceh yang nikamat yang mampu Kamu hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Ayam Tangkap Khas Aceh:

1. Gunakan 1 ekor ayam organik bagian dada dan paha potong 8
1. Siapkan 750 ml Hydrococo
1. Siapkan  Bumbu halus
1. Siapkan 3 butir kemiri sangrai
1. Ambil 6 butir bawang merah
1. Gunakan 4 siung bawang putih
1. Gunakan 5 cm lengkuas
1. Ambil 5 cm kunyit
1. Sediakan  Bumbu cemplung
1. Ambil 2 batang serai geprek
1. Gunakan 5 lembar daun salam
1. Siapkan 1/2 sdm garam (sesuai selera)
1. Ambil  Bahan cemplung saat menggoreng
1. Ambil 4 lembar daun pandan
1. Siapkan 4 batang daun kari/salam koja ambil daunnya
1. Gunakan 5 lembar daun jeruk




<!--inarticleads2-->

##### Cara membuat Ayam Tangkap Khas Aceh:

1. Ayam dilumuri pakai air jeruk nipis kemudian bilas menggunakan air mengalir, tiriskan. Sementara itu bumbu halus dihaluskan.
<img src="https://img-global.cpcdn.com/steps/b0192e040dd38ff2/160x128cq70/ayam-tangkap-khas-aceh-langkah-memasak-1-foto.jpg" alt="Ayam Tangkap Khas Aceh"><img src="https://img-global.cpcdn.com/steps/0b51c61b8c38cef7/160x128cq70/ayam-tangkap-khas-aceh-langkah-memasak-1-foto.jpg" alt="Ayam Tangkap Khas Aceh">1. Tumis bumbu halus sampai harum, kemudian masukan ayam, aduk ayam pelan pelan sampai bumbu rata. Selanjutnya tuang hydrococo, serai, daun salam dan garam. Ungkep ayam sampai bumbu meresap dan aii hydrococo menyusut.
1. Kalau sudah set airnya, ayam dapat disimpan di dalam kulkas jika tidak langsung digoreng.
1. Cara menggoreng ayam tangkap:  - goreng menggunakan wajan anti lengket dengan minyak yang merendam setengah bagian ayam. Setelah ayam kecoklatan balik bagian sisi lainnya dan masukan daun pandan, daun salam koja, dan daun jeruk nipis.
1. Goreng ayam sampai kecoklatan. Cara penyajian: tuang daun salam koja dan daun pandan di atas piring kemudian letakan ayam di atasnya.




Ternyata resep ayam tangkap khas aceh yang enak simple ini mudah sekali ya! Kita semua bisa mencobanya. Cara buat ayam tangkap khas aceh Sangat cocok sekali untuk kalian yang baru belajar memasak maupun untuk kalian yang telah hebat memasak.

Apakah kamu mau mulai mencoba buat resep ayam tangkap khas aceh enak tidak ribet ini? Kalau mau, mending kamu segera siapin alat dan bahannya, lalu buat deh Resep ayam tangkap khas aceh yang nikmat dan simple ini. Betul-betul taidak sulit kan. 

Oleh karena itu, daripada kamu diam saja, hayo langsung aja bikin resep ayam tangkap khas aceh ini. Pasti anda gak akan nyesel sudah bikin resep ayam tangkap khas aceh nikmat tidak rumit ini! Selamat berkreasi dengan resep ayam tangkap khas aceh enak sederhana ini di rumah sendiri,ya!.

