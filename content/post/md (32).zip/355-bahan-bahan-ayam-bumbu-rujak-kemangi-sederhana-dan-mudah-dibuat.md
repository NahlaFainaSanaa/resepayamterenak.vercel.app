---
description: "Bahan-bahan Ayam bumbu rujak kemangi Sederhana dan Mudah Dibuat"
title: "Bahan-bahan Ayam bumbu rujak kemangi Sederhana dan Mudah Dibuat"
slug: 355-bahan-bahan-ayam-bumbu-rujak-kemangi-sederhana-dan-mudah-dibuat
date: 2021-06-12T18:50:29.688Z
image: https://img-global.cpcdn.com/recipes/f727cf21b9c5295e/680x482cq70/ayam-bumbu-rujak-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f727cf21b9c5295e/680x482cq70/ayam-bumbu-rujak-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f727cf21b9c5295e/680x482cq70/ayam-bumbu-rujak-kemangi-foto-resep-utama.jpg
author: Maggie Lawrence
ratingvalue: 4.3
reviewcount: 6
recipeingredient:
- "650 gr ayam"
- "1 bungkus Santan kara"
- "3 lembar daun salam"
- "3 lembar daun jeruk nipis"
- "7 bawang merah"
- "5 bawang putih"
- "7 cabe rawit"
- "8 cabe merah besar"
- "1 ruas sereh"
- "1,5 cm lengkuas"
- "2 genggam kemangi"
- "4 butir kemiri"
- "2 cm kunyit"
- " Air asem bisa diskip"
- " Garam dan penyedap"
- " Ketumbar utk marinasi"
- "1-1  5 gula merah"
recipeinstructions:
- "Marinasi ayam pakai garam dan ketumbar sedikit. Lalu goreng hingga warna cokelat muda."
- "Haluskan bawang merah, bawang putih, cabe2, kemiri dan kunyit. Lalu tumis bersama daun jeruk, salam, sereh dan lengkuas dan gula merah yang telah diserut"
- "Setelah harum tambah air sedikit lalu masukkan ayam dan daun kemangi"
- "Tambah garam dan penyedap. Masak sampai bumbu benar2 meresap. Jangan lupa koreksi rasa :)"
categories:
- Resep
tags:
- ayam
- bumbu
- rujak

katakunci: ayam bumbu rujak 
nutrition: 218 calories
recipecuisine: Indonesian
preptime: "PT13M"
cooktime: "PT34M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam bumbu rujak kemangi](https://img-global.cpcdn.com/recipes/f727cf21b9c5295e/680x482cq70/ayam-bumbu-rujak-kemangi-foto-resep-utama.jpg)

Selaku seorang yang hobi memasak, menyajikan santapan nikmat kepada famili merupakan hal yang menyenangkan bagi kita sendiri. Kewajiban seorang istri Tidak cuman mengatur rumah saja, namun kamu juga wajib memastikan kebutuhan nutrisi terpenuhi dan juga hidangan yang disantap orang tercinta mesti sedap.

Di zaman  sekarang, anda memang bisa membeli olahan instan meski tidak harus repot mengolahnya dulu. Namun ada juga lho mereka yang selalu ingin memberikan hidangan yang terlezat untuk orang yang dicintainya. Lantaran, memasak yang dibuat sendiri jauh lebih bersih dan bisa menyesuaikan makanan tersebut berdasarkan selera famili. 



Apakah anda adalah seorang penyuka ayam bumbu rujak kemangi?. Tahukah kamu, ayam bumbu rujak kemangi adalah makanan khas di Indonesia yang saat ini digemari oleh banyak orang di berbagai wilayah di Indonesia. Kamu bisa menghidangkan ayam bumbu rujak kemangi olahan sendiri di rumahmu dan pasti jadi makanan favorit di akhir pekanmu.

Kita jangan bingung untuk memakan ayam bumbu rujak kemangi, lantaran ayam bumbu rujak kemangi sangat mudah untuk ditemukan dan kamu pun boleh menghidangkannya sendiri di rumah. ayam bumbu rujak kemangi boleh dibuat lewat bermacam cara. Kini telah banyak banget resep kekinian yang membuat ayam bumbu rujak kemangi lebih enak.

Resep ayam bumbu rujak kemangi juga sangat mudah dibuat, lho. Anda jangan repot-repot untuk memesan ayam bumbu rujak kemangi, lantaran Anda bisa menghidangkan di rumah sendiri. Untuk Kalian yang akan menyajikannya, berikut ini resep membuat ayam bumbu rujak kemangi yang nikamat yang bisa Kalian hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Ayam bumbu rujak kemangi:

1. Siapkan 650 gr ayam
1. Sediakan 1 bungkus Santan kara
1. Gunakan 3 lembar daun salam
1. Ambil 3 lembar daun jeruk nipis
1. Sediakan 7 bawang merah
1. Siapkan 5 bawang putih
1. Sediakan 7 cabe rawit
1. Ambil 8 cabe merah besar
1. Siapkan 1 ruas sereh
1. Gunakan 1,5 cm lengkuas
1. Sediakan 2 genggam kemangi
1. Siapkan 4 butir kemiri
1. Siapkan 2 cm kunyit
1. Ambil  Air asem (bisa diskip)
1. Gunakan  Garam dan penyedap
1. Gunakan  Ketumbar (utk marinasi)
1. Ambil 1-1 , 5 gula merah




<!--inarticleads2-->

##### Cara membuat Ayam bumbu rujak kemangi:

1. Marinasi ayam pakai garam dan ketumbar sedikit. Lalu goreng hingga warna cokelat muda.
1. Haluskan bawang merah, bawang putih, cabe2, kemiri dan kunyit. Lalu tumis bersama daun jeruk, salam, sereh dan lengkuas dan gula merah yang telah diserut
1. Setelah harum tambah air sedikit lalu masukkan ayam dan daun kemangi
1. Tambah garam dan penyedap. Masak sampai bumbu benar2 meresap. Jangan lupa koreksi rasa :)




Ternyata cara buat ayam bumbu rujak kemangi yang nikamt sederhana ini mudah sekali ya! Anda Semua bisa membuatnya. Cara buat ayam bumbu rujak kemangi Sangat cocok sekali buat anda yang baru akan belajar memasak maupun bagi kalian yang sudah hebat memasak.

Apakah kamu mau mulai mencoba membuat resep ayam bumbu rujak kemangi lezat tidak rumit ini? Kalau kamu mau, yuk kita segera buruan siapin alat dan bahannya, lantas buat deh Resep ayam bumbu rujak kemangi yang mantab dan sederhana ini. Benar-benar gampang kan. 

Maka, daripada kamu diam saja, yuk langsung aja hidangkan resep ayam bumbu rujak kemangi ini. Dijamin kalian tiidak akan menyesal sudah membuat resep ayam bumbu rujak kemangi enak tidak rumit ini! Selamat mencoba dengan resep ayam bumbu rujak kemangi nikmat simple ini di tempat tinggal masing-masing,oke!.

