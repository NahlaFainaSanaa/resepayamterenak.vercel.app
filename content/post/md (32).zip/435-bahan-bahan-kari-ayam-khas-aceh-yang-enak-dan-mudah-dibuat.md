---
description: "Bahan-bahan Kari Ayam Khas Aceh yang enak dan Mudah Dibuat"
title: "Bahan-bahan Kari Ayam Khas Aceh yang enak dan Mudah Dibuat"
slug: 435-bahan-bahan-kari-ayam-khas-aceh-yang-enak-dan-mudah-dibuat
date: 2021-06-14T22:29:29.920Z
image: https://img-global.cpcdn.com/recipes/fc533e05e81c011b/680x482cq70/kari-ayam-khas-aceh-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/fc533e05e81c011b/680x482cq70/kari-ayam-khas-aceh-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/fc533e05e81c011b/680x482cq70/kari-ayam-khas-aceh-foto-resep-utama.jpg
author: Florence Becker
ratingvalue: 4.6
reviewcount: 8
recipeingredient:
- "500 gr ayam"
- "1 sdm ketumbar bubuk"
- "1/2 sdm kunyit bubuk"
- " Perasan jeruk nipis"
- "1 sdt garam"
- "1 sdt gula"
- "1/2 sdt kaldu bubuk"
- "200 ml santan instant kara"
- " Bumbu Halus"
- "4 siung bawang putih"
- "8 butir bawang merah"
- "7 buah cabe merah keriting"
- "15 buah cabe rawit merah"
- "1 sdt ketumbar"
- "1/2 sdt lada"
- "1/2 sdt pala"
- "1/4 sdt adas"
- "1/4 sdt jinten"
- "4 sdm kelapa sangrai yang dihaluskan"
- " Bumbu Rempah Tumisan"
- "1 butir bawang merah iris"
- "3 butir cengkeh"
- "1 buah bunga lawang"
- "2 buah kapulaga"
- "1 lembar daun pandan"
- "1 batang daun kari"
recipeinstructions:
- "Ungkep ayam dengan ketumbar, kunyit, perasan jeruk nipis dan garam, sisihkan"
- "Uleg bumbu halus"
- "Tambahkan kelapa sangrai yang dihaluskan bersama bumbu halus"
- "Campur bumbu halus, ayam ungkep dan santan. Aduk rata dan biarkan sebentar agar bumbu meresap"
- "Tumis bumbu rempah hingga wangi lalu masukkan ayam yang sudah terbalur bumbu. Aduk rata"
- "Tambahkan air dan masak hingga kuah menyusut dan ayam matang. Sajikan"
categories:
- Resep
tags:
- kari
- ayam
- khas

katakunci: kari ayam khas 
nutrition: 272 calories
recipecuisine: Indonesian
preptime: "PT21M"
cooktime: "PT37M"
recipeyield: "1"
recipecategory: Lunch

---


![Kari Ayam Khas Aceh](https://img-global.cpcdn.com/recipes/fc533e05e81c011b/680x482cq70/kari-ayam-khas-aceh-foto-resep-utama.jpg)

Andai kamu seorang orang tua, mempersiapkan olahan lezat bagi keluarga merupakan hal yang sangat menyenangkan untuk anda sendiri. Kewajiban seorang ibu bukan sekedar mengerjakan pekerjaan rumah saja, tetapi anda pun harus menyediakan keperluan nutrisi tercukupi dan juga santapan yang dikonsumsi keluarga tercinta mesti lezat.

Di zaman  sekarang, anda memang dapat membeli panganan siap saji walaupun tanpa harus repot mengolahnya dahulu. Tetapi banyak juga mereka yang selalu mau memberikan yang terbaik untuk keluarganya. Lantaran, menghidangkan masakan yang diolah sendiri jauh lebih bersih dan kita pun bisa menyesuaikan masakan tersebut sesuai selera famili. 



Mungkinkah anda seorang penikmat kari ayam khas aceh?. Asal kamu tahu, kari ayam khas aceh adalah sajian khas di Nusantara yang saat ini disukai oleh orang-orang dari berbagai wilayah di Indonesia. Kalian bisa memasak kari ayam khas aceh buatan sendiri di rumahmu dan boleh jadi makanan kesukaanmu di hari libur.

Anda tidak perlu bingung jika kamu ingin memakan kari ayam khas aceh, lantaran kari ayam khas aceh sangat mudah untuk didapatkan dan juga kalian pun bisa menghidangkannya sendiri di tempatmu. kari ayam khas aceh boleh diolah memalui beragam cara. Kini pun ada banyak banget resep kekinian yang membuat kari ayam khas aceh semakin lebih lezat.

Resep kari ayam khas aceh juga mudah sekali untuk dibikin, lho. Kita tidak usah repot-repot untuk memesan kari ayam khas aceh, sebab Kita dapat menghidangkan ditempatmu. Untuk Anda yang ingin menyajikannya, di bawah ini adalah cara untuk menyajikan kari ayam khas aceh yang mantab yang dapat Anda hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Kari Ayam Khas Aceh:

1. Sediakan 500 gr ayam
1. Siapkan 1 sdm ketumbar bubuk
1. Siapkan 1/2 sdm kunyit bubuk
1. Ambil  Perasan jeruk nipis
1. Ambil 1 sdt garam
1. Ambil 1 sdt gula
1. Siapkan 1/2 sdt kaldu bubuk
1. Ambil 200 ml santan instant kara
1. Sediakan  Bumbu Halus
1. Sediakan 4 siung bawang putih
1. Ambil 8 butir bawang merah
1. Sediakan 7 buah cabe merah keriting
1. Sediakan 15 buah cabe rawit merah
1. Ambil 1 sdt ketumbar
1. Ambil 1/2 sdt lada
1. Siapkan 1/2 sdt pala
1. Gunakan 1/4 sdt adas
1. Gunakan 1/4 sdt jinten
1. Sediakan 4 sdm kelapa sangrai yang dihaluskan
1. Ambil  Bumbu Rempah Tumisan
1. Gunakan 1 butir bawang merah, iris
1. Ambil 3 butir cengkeh
1. Siapkan 1 buah bunga lawang
1. Ambil 2 buah kapulaga
1. Gunakan 1 lembar daun pandan
1. Siapkan 1 batang daun kari




<!--inarticleads2-->

##### Langkah-langkah membuat Kari Ayam Khas Aceh:

1. Ungkep ayam dengan ketumbar, kunyit, perasan jeruk nipis dan garam, sisihkan
1. Uleg bumbu halus
1. Tambahkan kelapa sangrai yang dihaluskan bersama bumbu halus
1. Campur bumbu halus, ayam ungkep dan santan. Aduk rata dan biarkan sebentar agar bumbu meresap
1. Tumis bumbu rempah hingga wangi lalu masukkan ayam yang sudah terbalur bumbu. Aduk rata
1. Tambahkan air dan masak hingga kuah menyusut dan ayam matang. Sajikan




Wah ternyata resep kari ayam khas aceh yang enak sederhana ini enteng sekali ya! Kita semua dapat memasaknya. Cara Membuat kari ayam khas aceh Sesuai sekali untuk kamu yang sedang belajar memasak atau juga bagi anda yang sudah jago memasak.

Apakah kamu ingin mencoba membuat resep kari ayam khas aceh enak tidak ribet ini? Kalau kamu mau, yuk kita segera siapkan peralatan dan bahannya, kemudian buat deh Resep kari ayam khas aceh yang mantab dan tidak rumit ini. Sungguh gampang kan. 

Jadi, daripada kita berfikir lama-lama, hayo kita langsung saja hidangkan resep kari ayam khas aceh ini. Dijamin kamu tiidak akan menyesal sudah membuat resep kari ayam khas aceh mantab tidak ribet ini! Selamat berkreasi dengan resep kari ayam khas aceh lezat simple ini di tempat tinggal kalian masing-masing,ya!.

