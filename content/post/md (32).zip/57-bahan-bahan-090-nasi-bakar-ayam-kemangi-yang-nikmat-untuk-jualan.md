---
description: "Bahan-bahan 090. Nasi Bakar Ayam Kemangi yang nikmat Untuk Jualan"
title: "Bahan-bahan 090. Nasi Bakar Ayam Kemangi yang nikmat Untuk Jualan"
slug: 57-bahan-bahan-090-nasi-bakar-ayam-kemangi-yang-nikmat-untuk-jualan
date: 2021-05-08T12:07:07.863Z
image: https://img-global.cpcdn.com/recipes/34aadbe3e9e6845f/680x482cq70/090-nasi-bakar-ayam-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/34aadbe3e9e6845f/680x482cq70/090-nasi-bakar-ayam-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/34aadbe3e9e6845f/680x482cq70/090-nasi-bakar-ayam-kemangi-foto-resep-utama.jpg
author: Nathaniel Gutierrez
ratingvalue: 3.8
reviewcount: 7
recipeingredient:
- "250 gr nasi hangat"
- "250 gr dada ayam rebus lalu disuwir"
- "50 ml air"
- "1 batang serai geprek"
- "2 lembar daun salam"
- "2 lembar daun jeruk"
- "1 sdt garam"
- "1 sdt kaldu bubuk"
- "1 sdt gula pasir diganti gula merah juga bisa"
- "100 gr kemangi ambil daunnya"
- "Secukupnya minyak untuk menumis"
- "Secukupnya daun pisang  tusuk gigi"
- " Bumbu halus "
- "5 bh cabe rawit merah"
- "3 bh cabe keriting merah"
- "2 siung bawang putih"
- "3 siung bawang merah"
- "1 sdt merica"
- "1 cm kunyit"
- "1 ruas jahe"
recipeinstructions:
- "Panaskan minyak dalam wajan, tumis bumbu halus hingga harum, masukkan daun salam, daun jeruk, serai. Tumis sampai layu lalu tambahkan air, masak sampai mendidih."
- "Masukkan ayam suwir aduk, lalu bumbui dengan garam, kaldu bubuk, dan gula, aduk rata. Tunggu air menyusut lalu masukkan daun kemangi aduk sampai tercampur rata. Angkat sisihkan."
- "Ambil daun pisang beri nasi pipihkan lalu atasnya beri 1-2 sdm isian ayam tutup lagi dengan nasi, gulung daun berbentuk lonjong lalu bagian ujungnya sematkan tusuk gigi, ulangi sampai nasi habis."
- "Bakar nasi bungkus diatas arang hingga daun berubah warna, angkat dinginkan dan siap dinikmati."
categories:
- Resep
tags:
- 090
- nasi
- bakar

katakunci: 090 nasi bakar 
nutrition: 244 calories
recipecuisine: Indonesian
preptime: "PT27M"
cooktime: "PT46M"
recipeyield: "3"
recipecategory: Dessert

---


![090. Nasi Bakar Ayam Kemangi](https://img-global.cpcdn.com/recipes/34aadbe3e9e6845f/680x482cq70/090-nasi-bakar-ayam-kemangi-foto-resep-utama.jpg)

Jika kalian seorang yang hobi masak, menyediakan hidangan enak kepada keluarga tercinta adalah hal yang menggembirakan bagi kita sendiri. Kewajiban seorang  wanita bukan cuman mengurus rumah saja, tetapi anda juga wajib memastikan kebutuhan gizi terpenuhi dan juga masakan yang dikonsumsi anak-anak mesti enak.

Di era  saat ini, kamu sebenarnya bisa mengorder olahan jadi walaupun tanpa harus ribet mengolahnya dahulu. Tapi ada juga lho mereka yang selalu ingin menyajikan yang terenak bagi keluarganya. Lantaran, memasak yang dibuat sendiri jauh lebih higienis dan kita pun bisa menyesuaikan makanan tersebut berdasarkan masakan kesukaan keluarga tercinta. 



Apakah anda adalah salah satu penyuka 090. nasi bakar ayam kemangi?. Tahukah kamu, 090. nasi bakar ayam kemangi adalah hidangan khas di Nusantara yang sekarang digemari oleh kebanyakan orang di hampir setiap wilayah di Nusantara. Kamu dapat menghidangkan 090. nasi bakar ayam kemangi sendiri di rumah dan boleh jadi camilan kesenanganmu di hari liburmu.

Anda jangan bingung untuk mendapatkan 090. nasi bakar ayam kemangi, sebab 090. nasi bakar ayam kemangi gampang untuk ditemukan dan juga kita pun bisa memasaknya sendiri di rumah. 090. nasi bakar ayam kemangi dapat dibuat memalui beraneka cara. Saat ini telah banyak banget resep kekinian yang membuat 090. nasi bakar ayam kemangi lebih nikmat.

Resep 090. nasi bakar ayam kemangi pun sangat mudah untuk dibikin, lho. Anda tidak perlu repot-repot untuk membeli 090. nasi bakar ayam kemangi, sebab Kita bisa menyajikan ditempatmu. Untuk Kamu yang ingin menyajikannya, inilah cara untuk menyajikan 090. nasi bakar ayam kemangi yang nikamat yang bisa Kamu coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan 090. Nasi Bakar Ayam Kemangi:

1. Gunakan 250 gr nasi hangat
1. Sediakan 250 gr dada ayam, rebus lalu disuwir²
1. Sediakan 50 ml air
1. Sediakan 1 batang serai, geprek
1. Sediakan 2 lembar daun salam
1. Gunakan 2 lembar daun jeruk
1. Ambil 1 sdt garam
1. Ambil 1 sdt kaldu bubuk
1. Sediakan 1 sdt gula pasir, diganti gula merah juga bisa
1. Sediakan 100 gr kemangi, ambil daunnya
1. Sediakan Secukupnya minyak untuk menumis
1. Sediakan Secukupnya daun pisang &amp; tusuk gigi
1. Sediakan  Bumbu halus :
1. Gunakan 5 bh cabe rawit merah
1. Sediakan 3 bh cabe keriting merah
1. Sediakan 2 siung bawang putih
1. Ambil 3 siung bawang merah
1. Gunakan 1 sdt merica
1. Ambil 1 cm kunyit
1. Ambil 1 ruas jahe




<!--inarticleads2-->

##### Langkah-langkah membuat 090. Nasi Bakar Ayam Kemangi:

1. Panaskan minyak dalam wajan, tumis bumbu halus hingga harum, masukkan daun salam, daun jeruk, serai. Tumis sampai layu lalu tambahkan air, masak sampai mendidih.
1. Masukkan ayam suwir aduk, lalu bumbui dengan garam, kaldu bubuk, dan gula, aduk rata. Tunggu air menyusut lalu masukkan daun kemangi aduk sampai tercampur rata. Angkat sisihkan.
1. Ambil daun pisang beri nasi pipihkan lalu atasnya beri 1-2 sdm isian ayam tutup lagi dengan nasi, gulung daun berbentuk lonjong lalu bagian ujungnya sematkan tusuk gigi, ulangi sampai nasi habis.
1. Bakar nasi bungkus diatas arang hingga daun berubah warna, angkat dinginkan dan siap dinikmati.




Ternyata cara membuat 090. nasi bakar ayam kemangi yang enak simple ini enteng sekali ya! Kamu semua bisa menghidangkannya. Resep 090. nasi bakar ayam kemangi Sangat sesuai sekali untuk kita yang baru belajar memasak ataupun untuk kamu yang sudah jago dalam memasak.

Tertarik untuk mulai mencoba membikin resep 090. nasi bakar ayam kemangi nikmat simple ini? Kalau anda ingin, ayo kalian segera buruan menyiapkan alat dan bahannya, maka buat deh Resep 090. nasi bakar ayam kemangi yang mantab dan tidak ribet ini. Sungguh mudah kan. 

Oleh karena itu, ketimbang anda berfikir lama-lama, maka langsung aja hidangkan resep 090. nasi bakar ayam kemangi ini. Dijamin kalian tiidak akan menyesal sudah membuat resep 090. nasi bakar ayam kemangi lezat simple ini! Selamat mencoba dengan resep 090. nasi bakar ayam kemangi nikmat tidak rumit ini di tempat tinggal kalian sendiri,oke!.

