---
description: "Cara buat Woku Ayam Kampung Ala Rumah Kami yang enak Untuk Jualan"
title: "Cara buat Woku Ayam Kampung Ala Rumah Kami yang enak Untuk Jualan"
slug: 322-cara-buat-woku-ayam-kampung-ala-rumah-kami-yang-enak-untuk-jualan
date: 2021-02-22T18:30:28.771Z
image: https://img-global.cpcdn.com/recipes/ab9420fcb100bef0/680x482cq70/woku-ayam-kampung-ala-rumah-kami-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ab9420fcb100bef0/680x482cq70/woku-ayam-kampung-ala-rumah-kami-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ab9420fcb100bef0/680x482cq70/woku-ayam-kampung-ala-rumah-kami-foto-resep-utama.jpg
author: Katharine Brock
ratingvalue: 3.2
reviewcount: 6
recipeingredient:
- "1 ekor ayam kampung agak muda"
- "23-25 buah cabe merah"
- "10-15 buah cabe rawit setan"
- "10-12 siung bawang merah"
- "7-8 siung bawang putih"
- "4 butir kemiri"
- "1 ruas sedang jahe"
- "3-4 batang serai"
- "1,5 ruas kunyit"
- "3-4 lembar daun pandan segar diikat"
- "1-2 lembar daun kunyit segar kalo besar cukup 1"
- "3-5 lembar daun salam segar"
- "3-5 lembar daun jeruk segar"
- "1 ikat daun kemangi segar"
- "2 buah tomat"
- "1 SDM garam halus"
- "1 SDM kaldu ayam bubuk"
- "1 SDM gula pasir"
- "1 SDT merica halus"
recipeinstructions:
- "Siapkan bahan"
- "Bersihkan ayam kampung, potong-potong lalu cuci. Kucuri dengan jeruk kunci lalu sisihkan."
- "Bersihkan dan kupas bumbu. Kemiri, jahe, kunyit dan serai disangrai dulu biar wangi."
- "Haluskan cabe, bawang merah, bawang putih, kemiri, jahe dan kunyit yang sudah disangrai tadi"
- "Cuci bersih daun pandan, daun kunyit, daun salam, daun jeruk dan daun kemangi. Serai digeprek. Tomat dipotong-potong"
- "Tumis bumbu halus sampai tertumis sempurna. Masukkan serai"
- "Masukkan daun pandan, daun kunyit, lalu daun salam dan daun jeruk. Aduk rata."
- "Aduk dan tumis sampai daun layu dan bumbu makin harum"
- "Masukkan potongan ayam dengan tangan sedikit demi sedikit, supaya air marinasi gak ikut"
- "Lanjut tumis sampai ayam mengkeret. Lalu beri air matang sekitar 2 gelas"
- "Aduk lalu tunggu mendidih. Kemudian tutup wajan dan masak dengan metode NCC (5 menit rebus, 30 menit biarkan dan 7 menit lanjut rebus)"
- "Setelah selesai matikan kompor dan buka wajan, ayam sudah empuk dan bumbu agak sat. Boleh tambah air matang lagi sekitar 1 gelas. Tunggu mendidih lagi lalu masukkan Garam halus, bubuk merica, kaldu bubuk, gula pasir. Aduk rata."
- "Aduk lalu masukkan potongan tomat dan koreksi rasa."
- "Matikan kompor. Masukkan daun kemangi. Aduk. Jadi deh"
- "Tinggal disajikan, makan dengan nasi hangat, muantap ini. Selamat mencoba."
categories:
- Resep
tags:
- woku
- ayam
- kampung

katakunci: woku ayam kampung 
nutrition: 161 calories
recipecuisine: Indonesian
preptime: "PT29M"
cooktime: "PT35M"
recipeyield: "1"
recipecategory: Lunch

---


![Woku Ayam Kampung Ala Rumah Kami](https://img-global.cpcdn.com/recipes/ab9420fcb100bef0/680x482cq70/woku-ayam-kampung-ala-rumah-kami-foto-resep-utama.jpg)

Selaku seorang ibu, menyediakan masakan menggugah selera bagi orang tercinta merupakan hal yang memuaskan untuk anda sendiri. Peran seorang ibu Tidak hanya mengatur rumah saja, tapi kamu pun wajib menyediakan kebutuhan gizi tercukupi dan olahan yang dimakan orang tercinta harus lezat.

Di era  saat ini, kamu sebenarnya mampu mengorder santapan yang sudah jadi walaupun tidak harus capek memasaknya lebih dulu. Namun ada juga orang yang memang ingin menghidangkan yang terbaik bagi orang yang dicintainya. Karena, menghidangkan masakan sendiri akan jauh lebih bersih dan bisa menyesuaikan hidangan tersebut sesuai masakan kesukaan famili. 



Mungkinkah anda adalah salah satu penyuka woku ayam kampung ala rumah kami?. Asal kamu tahu, woku ayam kampung ala rumah kami merupakan makanan khas di Indonesia yang sekarang disenangi oleh kebanyakan orang dari hampir setiap daerah di Nusantara. Anda bisa membuat woku ayam kampung ala rumah kami sendiri di rumah dan boleh jadi camilan kesenanganmu di akhir pekan.

Kamu tak perlu bingung untuk mendapatkan woku ayam kampung ala rumah kami, karena woku ayam kampung ala rumah kami gampang untuk dicari dan juga kamu pun bisa membuatnya sendiri di tempatmu. woku ayam kampung ala rumah kami bisa dimasak lewat beragam cara. Kini telah banyak banget resep kekinian yang menjadikan woku ayam kampung ala rumah kami lebih mantap.

Resep woku ayam kampung ala rumah kami juga sangat gampang dibuat, lho. Kita tidak usah ribet-ribet untuk memesan woku ayam kampung ala rumah kami, lantaran Kamu mampu menyiapkan di rumahmu. Untuk Kamu yang akan menyajikannya, berikut ini resep untuk menyajikan woku ayam kampung ala rumah kami yang lezat yang dapat Anda buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Woku Ayam Kampung Ala Rumah Kami:

1. Gunakan 1 ekor ayam kampung agak muda
1. Siapkan 23-25 buah cabe merah
1. Gunakan 10-15 buah cabe rawit setan
1. Gunakan 10-12 siung bawang merah
1. Sediakan 7-8 siung bawang putih
1. Ambil 4 butir kemiri
1. Siapkan 1 ruas sedang jahe
1. Sediakan 3-4 batang serai
1. Gunakan 1,5 ruas kunyit
1. Gunakan 3-4 lembar daun pandan segar diikat
1. Sediakan 1-2 lembar daun kunyit segar, kalo besar cukup 1
1. Gunakan 3-5 lembar daun salam segar
1. Siapkan 3-5 lembar daun jeruk segar
1. Siapkan 1 ikat daun kemangi segar
1. Gunakan 2 buah tomat
1. Gunakan 1 SDM garam halus
1. Gunakan 1 SDM kaldu ayam bubuk
1. Sediakan 1 SDM gula pasir
1. Ambil 1 SDT merica halus




<!--inarticleads2-->

##### Langkah-langkah membuat Woku Ayam Kampung Ala Rumah Kami:

1. Siapkan bahan
1. Bersihkan ayam kampung, potong-potong lalu cuci. Kucuri dengan jeruk kunci lalu sisihkan.
1. Bersihkan dan kupas bumbu. Kemiri, jahe, kunyit dan serai disangrai dulu biar wangi.
1. Haluskan cabe, bawang merah, bawang putih, kemiri, jahe dan kunyit yang sudah disangrai tadi
1. Cuci bersih daun pandan, daun kunyit, daun salam, daun jeruk dan daun kemangi. Serai digeprek. Tomat dipotong-potong
1. Tumis bumbu halus sampai tertumis sempurna. Masukkan serai
1. Masukkan daun pandan, daun kunyit, lalu daun salam dan daun jeruk. Aduk rata.
1. Aduk dan tumis sampai daun layu dan bumbu makin harum
1. Masukkan potongan ayam dengan tangan sedikit demi sedikit, supaya air marinasi gak ikut
1. Lanjut tumis sampai ayam mengkeret. Lalu beri air matang sekitar 2 gelas
1. Aduk lalu tunggu mendidih. Kemudian tutup wajan dan masak dengan metode NCC (5 menit rebus, 30 menit biarkan dan 7 menit lanjut rebus)
1. Setelah selesai matikan kompor dan buka wajan, ayam sudah empuk dan bumbu agak sat. Boleh tambah air matang lagi sekitar 1 gelas. Tunggu mendidih lagi lalu masukkan Garam halus, bubuk merica, kaldu bubuk, gula pasir. Aduk rata.
1. Aduk lalu masukkan potongan tomat dan koreksi rasa.
1. Matikan kompor. Masukkan daun kemangi. Aduk. Jadi deh
1. Tinggal disajikan, makan dengan nasi hangat, muantap ini. Selamat mencoba.




Wah ternyata cara membuat woku ayam kampung ala rumah kami yang nikamt tidak rumit ini enteng banget ya! Kita semua dapat memasaknya. Cara Membuat woku ayam kampung ala rumah kami Cocok banget buat kalian yang baru belajar memasak maupun juga untuk anda yang sudah ahli dalam memasak.

Tertarik untuk mulai mencoba membuat resep woku ayam kampung ala rumah kami lezat simple ini? Kalau kamu mau, ayo kamu segera siapin peralatan dan bahannya, lalu bikin deh Resep woku ayam kampung ala rumah kami yang nikmat dan sederhana ini. Sangat taidak sulit kan. 

Jadi, ketimbang kalian berlama-lama, maka kita langsung saja sajikan resep woku ayam kampung ala rumah kami ini. Pasti anda gak akan nyesel membuat resep woku ayam kampung ala rumah kami lezat tidak ribet ini! Selamat mencoba dengan resep woku ayam kampung ala rumah kami enak tidak rumit ini di tempat tinggal sendiri,ya!.

