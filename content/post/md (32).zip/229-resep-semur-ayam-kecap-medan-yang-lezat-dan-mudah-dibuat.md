---
description: "Resep Semur ayam kecap medan yang lezat dan Mudah Dibuat"
title: "Resep Semur ayam kecap medan yang lezat dan Mudah Dibuat"
slug: 229-resep-semur-ayam-kecap-medan-yang-lezat-dan-mudah-dibuat
date: 2021-06-21T11:11:48.935Z
image: https://img-global.cpcdn.com/recipes/7f77f7f28c1f5923/680x482cq70/semur-ayam-kecap-medan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7f77f7f28c1f5923/680x482cq70/semur-ayam-kecap-medan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7f77f7f28c1f5923/680x482cq70/semur-ayam-kecap-medan-foto-resep-utama.jpg
author: Edna Griffin
ratingvalue: 4.3
reviewcount: 11
recipeingredient:
- "1 ekor ayampotong 8"
- "2 bh kentang potong"
- "5 btr telur rebus  sesuai kbutuhan"
- " Air scukupnya"
- "1 bh kapulaga"
- "6 lbr daun salam"
- "2 bh cengkeh"
- "1 cm btg kyu manis"
- "1/2 pala sy skip"
- "1 bh tomat potong2 sy pk 2"
- "Gram sckupnya"
- " Kcp manis sckupnya"
- " Gulamerah sckupnya"
- " Bwg goreng buat di tabur"
- " Bumbu halus"
- "1,5 ruas lengkuas"
- "1 ruas jahe"
- "8 siung bwg merah"
- "5 siung bwg ptih"
- "3 bh kemiri"
- "1/2 sdt merica"
- "10 cb merah sy pk 2 aja"
- "10 cb rawit sy skip"
recipeinstructions:
- "Tumis smua bumbu halus, ampe wangi lalu tmbhkan daun slam, kapulaga, cengkeh, kayu manis, tomat dan pala.. tumis ampe wangi dan berubah warna"
- "Lalu tmbhkan ayam dan kcp manis, gram, gulamerah. tumis sbntr lalu masukkan kentang dan aduk rata.. tmbhkan air.   Masak sampe ayam dan kentang empuk.. lalu masukkan telur rebus. Lalu masak ampe mendidih… koreksi rasa…"
- "Ta da selesai… siap buat d santap"
categories:
- Resep
tags:
- semur
- ayam
- kecap

katakunci: semur ayam kecap 
nutrition: 271 calories
recipecuisine: Indonesian
preptime: "PT38M"
cooktime: "PT39M"
recipeyield: "3"
recipecategory: Lunch

---


![Semur ayam kecap medan](https://img-global.cpcdn.com/recipes/7f77f7f28c1f5923/680x482cq70/semur-ayam-kecap-medan-foto-resep-utama.jpg)

Sebagai seorang wanita, mempersiapkan hidangan enak buat keluarga tercinta adalah hal yang memuaskan untuk anda sendiri. Kewajiban seorang  wanita bukan cuma mengurus rumah saja, tapi anda juga wajib menyediakan kebutuhan nutrisi terpenuhi dan olahan yang disantap keluarga tercinta wajib enak.

Di zaman  sekarang, anda memang bisa membeli panganan praktis meski tidak harus ribet memasaknya dahulu. Tetapi ada juga lho mereka yang memang mau menghidangkan yang terlezat untuk keluarganya. Pasalnya, menghidangkan masakan yang diolah sendiri jauh lebih bersih dan kita pun bisa menyesuaikan sesuai dengan selera keluarga tercinta. 



Mungkinkah kamu seorang penggemar semur ayam kecap medan?. Asal kamu tahu, semur ayam kecap medan merupakan makanan khas di Nusantara yang sekarang disukai oleh kebanyakan orang di berbagai daerah di Nusantara. Kamu dapat menyajikan semur ayam kecap medan buatan sendiri di rumah dan pasti jadi santapan kesukaanmu di hari libur.

Kamu tidak perlu bingung untuk memakan semur ayam kecap medan, lantaran semur ayam kecap medan gampang untuk didapatkan dan juga anda pun bisa menghidangkannya sendiri di tempatmu. semur ayam kecap medan bisa dimasak memalui beragam cara. Sekarang sudah banyak sekali cara kekinian yang membuat semur ayam kecap medan semakin lebih lezat.

Resep semur ayam kecap medan juga sangat mudah dibuat, lho. Anda tidak usah capek-capek untuk memesan semur ayam kecap medan, karena Kamu bisa membuatnya di rumah sendiri. Untuk Anda yang ingin membuatnya, berikut ini resep untuk membuat semur ayam kecap medan yang mantab yang dapat Anda buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Semur ayam kecap medan:

1. Gunakan 1 ekor ayam,potong 8
1. Ambil 2 bh kentang, potong
1. Siapkan 5 btr telur rebus / sesuai kbutuhan
1. Gunakan  Air scukupnya
1. Siapkan 1 bh kapulaga
1. Ambil 6 lbr daun salam
1. Gunakan 2 bh cengkeh
1. Gunakan 1 cm btg kyu manis
1. Siapkan 1/2 pala* sy skip
1. Siapkan 1 bh tomat potong2/ sy pk 2
1. Siapkan Gram sckupnya
1. Sediakan  Kcp manis sckupnya
1. Ambil  Gulamerah sckupnya
1. Ambil  Bwg goreng buat di tabur
1. Sediakan  Bumbu halus:
1. Siapkan 1,5 ruas lengkuas
1. Siapkan 1 ruas jahe
1. Ambil 8 siung bwg merah
1. Siapkan 5 siung bwg ptih
1. Sediakan 3 bh kemiri
1. Ambil 1/2 sdt merica
1. Sediakan 10 cb merah/ sy pk 2 aja
1. Siapkan 10 cb rawit *sy skip




<!--inarticleads2-->

##### Cara menyiapkan Semur ayam kecap medan:

1. Tumis smua bumbu halus, ampe wangi lalu tmbhkan daun slam, kapulaga, cengkeh, kayu manis, tomat dan pala.. tumis ampe wangi dan berubah warna
1. Lalu tmbhkan ayam dan kcp manis, gram, gulamerah. tumis sbntr lalu masukkan kentang dan aduk rata.. tmbhkan air.  -  - Masak sampe ayam dan kentang empuk.. lalu masukkan telur rebus. Lalu masak ampe mendidih… koreksi rasa…
1. Ta da selesai… siap buat d santap




Wah ternyata resep semur ayam kecap medan yang lezat sederhana ini enteng banget ya! Anda Semua dapat menghidangkannya. Cara Membuat semur ayam kecap medan Sesuai sekali buat anda yang baru belajar memasak ataupun juga bagi kalian yang telah hebat memasak.

Apakah kamu tertarik mulai mencoba buat resep semur ayam kecap medan nikmat simple ini? Kalau kamu tertarik, ayo kamu segera menyiapkan peralatan dan bahannya, maka buat deh Resep semur ayam kecap medan yang nikmat dan tidak ribet ini. Sungguh gampang kan. 

Oleh karena itu, daripada anda diam saja, yuk langsung aja buat resep semur ayam kecap medan ini. Dijamin kamu gak akan menyesal membuat resep semur ayam kecap medan enak tidak rumit ini! Selamat mencoba dengan resep semur ayam kecap medan mantab simple ini di tempat tinggal kalian sendiri,ya!.

