---
description: "Cara membuat Ayam Woku Kemangi yang nikmat dan Mudah Dibuat"
title: "Cara membuat Ayam Woku Kemangi yang nikmat dan Mudah Dibuat"
slug: 331-cara-membuat-ayam-woku-kemangi-yang-nikmat-dan-mudah-dibuat
date: 2021-04-16T04:16:42.186Z
image: https://img-global.cpcdn.com/recipes/601340c3372f9e30/680x482cq70/ayam-woku-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/601340c3372f9e30/680x482cq70/ayam-woku-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/601340c3372f9e30/680x482cq70/ayam-woku-kemangi-foto-resep-utama.jpg
author: Essie Reed
ratingvalue: 3
reviewcount: 4
recipeingredient:
- "1 ekor ayam potong 12"
- "1 lt air"
- " Minyak utk menumis"
- " Bumbu halus"
- "15 sg bawang merah"
- "10 sg bawang putih"
- "10 bh cabe rawit"
- "5 bh cabe keriting"
- "5 btr kemiri disangrai"
- "1 ruas kunyit"
- "1 ruas jahe"
- "1 sdm garam"
- "1 sdm gula"
- "1 sdt lada bubuk"
- " Bumbu utuh"
- "5 lbr daun salam"
- "5 lbr daun jeruk buang tulang daun"
- "3 btg sereh digeprek"
- " Pelengkap"
- "2 ikat kemangi ambil daunnya"
- "1 bh tomat dipotong2"
- " Taburan optional"
- "1 btg daun bawang diiris"
- " Bawang goreng"
recipeinstructions:
- "Cuci bersih ayam lalu baluri dgn air jeruk nipis &amp; 1 sdm garam. Dimakan selama min. 15 menit lalu bilas, kemudian ayam di-blansir. Angkat &amp; tiriskan."
- "Tumis bumbu halus hingga harum. Masukkan bumbu utuh. Masak hingga layu."
- "Masukkan ayam, aduk rata."
- "Tuang air, aduk rata. Masak hingga air menyusut."
- "Masukkan daun kemangi &amp; tomat, aduk rata. Koreksi rasa."
- "Taburi daun bawang, aduk rata."
- "Sajikan dgn taburan bawang goreng jika suka."
categories:
- Resep
tags:
- ayam
- woku
- kemangi

katakunci: ayam woku kemangi 
nutrition: 236 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT51M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam Woku Kemangi](https://img-global.cpcdn.com/recipes/601340c3372f9e30/680x482cq70/ayam-woku-kemangi-foto-resep-utama.jpg)

Sebagai seorang orang tua, mempersiapkan hidangan enak pada orang tercinta adalah suatu hal yang mengasyikan bagi kita sendiri. Tanggung jawab seorang ibu bukan hanya menangani rumah saja, namun anda juga harus menyediakan keperluan gizi tercukupi dan santapan yang dimakan anak-anak harus mantab.

Di era  sekarang, kalian memang bisa memesan masakan instan tidak harus capek membuatnya dahulu. Namun banyak juga lho mereka yang memang ingin memberikan yang terlezat untuk orang tercintanya. Pasalnya, menyajikan masakan yang dibuat sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan masakan tersebut sesuai dengan makanan kesukaan keluarga tercinta. 



Apakah anda salah satu penggemar ayam woku kemangi?. Asal kamu tahu, ayam woku kemangi merupakan makanan khas di Indonesia yang kini digemari oleh banyak orang di berbagai tempat di Nusantara. Kalian bisa menyajikan ayam woku kemangi sendiri di rumahmu dan boleh dijadikan hidangan kegemaranmu di akhir pekanmu.

Anda tidak usah bingung jika kamu ingin menyantap ayam woku kemangi, karena ayam woku kemangi mudah untuk dicari dan kita pun boleh menghidangkannya sendiri di rumah. ayam woku kemangi bisa dibuat dengan bermacam cara. Sekarang sudah banyak sekali cara modern yang membuat ayam woku kemangi semakin nikmat.

Resep ayam woku kemangi juga gampang untuk dibuat, lho. Kamu jangan ribet-ribet untuk membeli ayam woku kemangi, lantaran Kamu dapat menyiapkan ditempatmu. Untuk Kalian yang ingin membuatnya, berikut cara menyajikan ayam woku kemangi yang mantab yang dapat Kamu buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Ayam Woku Kemangi:

1. Ambil 1 ekor ayam, potong 12
1. Siapkan 1 lt air
1. Siapkan  Minyak utk menumis
1. Gunakan  Bumbu halus
1. Gunakan 15 sg bawang merah
1. Gunakan 10 sg bawang putih
1. Siapkan 10 bh cabe rawit
1. Gunakan 5 bh cabe keriting
1. Ambil 5 btr kemiri, disangrai
1. Sediakan 1 ruas kunyit
1. Sediakan 1 ruas jahe
1. Siapkan 1 sdm garam
1. Siapkan 1 sdm gula
1. Ambil 1 sdt lada bubuk
1. Gunakan  Bumbu utuh
1. Siapkan 5 lbr daun salam
1. Sediakan 5 lbr daun jeruk, buang tulang daun
1. Sediakan 3 btg sereh, digeprek
1. Siapkan  Pelengkap
1. Ambil 2 ikat kemangi, ambil daunnya
1. Ambil 1 bh tomat, dipotong2
1. Siapkan  Taburan (optional)
1. Sediakan 1 btg daun bawang, diiris
1. Siapkan  Bawang goreng




<!--inarticleads2-->

##### Cara membuat Ayam Woku Kemangi:

1. Cuci bersih ayam lalu baluri dgn air jeruk nipis &amp; 1 sdm garam. Dimakan selama min. 15 menit lalu bilas, kemudian ayam di-blansir. Angkat &amp; tiriskan.
1. Tumis bumbu halus hingga harum. Masukkan bumbu utuh. Masak hingga layu.
1. Masukkan ayam, aduk rata.
1. Tuang air, aduk rata. Masak hingga air menyusut.
1. Masukkan daun kemangi &amp; tomat, aduk rata. Koreksi rasa.
1. Taburi daun bawang, aduk rata.
1. Sajikan dgn taburan bawang goreng jika suka.




Ternyata cara buat ayam woku kemangi yang enak tidak ribet ini gampang banget ya! Kita semua dapat membuatnya. Resep ayam woku kemangi Sangat sesuai banget buat kamu yang baru belajar memasak ataupun untuk kalian yang sudah hebat memasak.

Tertarik untuk mulai mencoba bikin resep ayam woku kemangi enak tidak rumit ini? Kalau mau, ayo kalian segera siapkan peralatan dan bahan-bahannya, maka buat deh Resep ayam woku kemangi yang mantab dan simple ini. Sangat taidak sulit kan. 

Maka, ketimbang anda diam saja, ayo langsung aja buat resep ayam woku kemangi ini. Dijamin kalian gak akan nyesel sudah buat resep ayam woku kemangi enak sederhana ini! Selamat mencoba dengan resep ayam woku kemangi nikmat tidak ribet ini di tempat tinggal kalian masing-masing,oke!.

