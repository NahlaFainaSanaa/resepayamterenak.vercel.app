---
description: "Resep Lontong kari ayam #bandungrecook2_coryrahmaniah yang lezat dan Mudah Dibuat"
title: "Resep Lontong kari ayam #bandungrecook2_coryrahmaniah yang lezat dan Mudah Dibuat"
slug: 377-resep-lontong-kari-ayam-bandungrecook2-coryrahmaniah-yang-lezat-dan-mudah-dibuat
date: 2021-04-11T20:13:58.448Z
image: https://img-global.cpcdn.com/recipes/77520dcef5f35d67/680x482cq70/lontong-kari-ayam-bandungrecook2_coryrahmaniah-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/77520dcef5f35d67/680x482cq70/lontong-kari-ayam-bandungrecook2_coryrahmaniah-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/77520dcef5f35d67/680x482cq70/lontong-kari-ayam-bandungrecook2_coryrahmaniah-foto-resep-utama.jpg
author: Raymond Hayes
ratingvalue: 4.6
reviewcount: 13
recipeingredient:
- "1/2 kg ayam"
- "2 lbr daun jeruk"
- "1 btg serai"
- "1 ruas lengkuas geprek"
- "3 lbr daun salam"
- "2 bh kapulaga sya skip"
- "2 bh cengkeh sya skip"
- "1 bh bunga lawang sya skip"
- "600 ml santan"
- "1 bks bubuk kari"
- "Secukupnya garam"
- "Secukupnya kaldu bubuk"
- "Secukupnya air"
- "Secukupnya minyak goreng utk menumis"
- " Bumbu halus"
- "10 cabe keriting sya skip"
- "8 siung bwg merah"
- "6 siung bwg putih"
- "3 bh kemiri"
- "1 ruas kunyit"
- "1 ruas kecil jahe"
- "1 sdt ketumbar"
- "1/2 sdt jinten"
- " Pelengkap"
- "Secukupnya lontong"
- "Secukupnya bawang goreng"
- "Secukupnya cabe rawit tambahan dr sya"
recipeinstructions:
- "Panaskan minyak goreng lalu Tumis bumbu halus hingga harum lalu masukan lengkuas serai daun jeruk dan daun salam"
- "Lalu masukan air dan santan tunggu hingga mendidih"
- "Setelah mendidih masukan ayam lalu tambahkan garam kaldu bubuk dan bubuk kari masak hingga ayam matang"
- "Setelah matang jgn lupa tes rasa dan lontong kari ayam siap utk disajikan."
categories:
- Resep
tags:
- lontong
- kari
- ayam

katakunci: lontong kari ayam 
nutrition: 231 calories
recipecuisine: Indonesian
preptime: "PT23M"
cooktime: "PT35M"
recipeyield: "3"
recipecategory: Lunch

---


![Lontong kari ayam #bandungrecook2_coryrahmaniah](https://img-global.cpcdn.com/recipes/77520dcef5f35d67/680x482cq70/lontong-kari-ayam-bandungrecook2_coryrahmaniah-foto-resep-utama.jpg)

Selaku seorang orang tua, mempersiapkan hidangan sedap bagi orang tercinta adalah hal yang membahagiakan bagi anda sendiri. Tanggung jawab seorang ibu bukan sekedar menangani rumah saja, tetapi kamu juga wajib menyediakan keperluan gizi tercukupi dan panganan yang dimakan keluarga tercinta mesti enak.

Di masa  saat ini, kita memang dapat memesan olahan instan tidak harus capek memasaknya terlebih dahulu. Tetapi ada juga lho mereka yang selalu mau memberikan makanan yang terbaik bagi orang tercintanya. Lantaran, menghidangkan masakan yang diolah sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan hidangan tersebut sesuai masakan kesukaan orang tercinta. 



Mungkinkah anda merupakan salah satu penikmat lontong kari ayam #bandungrecook2_coryrahmaniah?. Asal kamu tahu, lontong kari ayam #bandungrecook2_coryrahmaniah adalah sajian khas di Indonesia yang kini disenangi oleh setiap orang di berbagai wilayah di Indonesia. Anda dapat memasak lontong kari ayam #bandungrecook2_coryrahmaniah buatan sendiri di rumahmu dan pasti jadi santapan favorit di hari liburmu.

Kita jangan bingung untuk memakan lontong kari ayam #bandungrecook2_coryrahmaniah, sebab lontong kari ayam #bandungrecook2_coryrahmaniah gampang untuk ditemukan dan kamu pun bisa memasaknya sendiri di tempatmu. lontong kari ayam #bandungrecook2_coryrahmaniah dapat dibuat dengan bermacam cara. Saat ini ada banyak resep kekinian yang membuat lontong kari ayam #bandungrecook2_coryrahmaniah semakin enak.

Resep lontong kari ayam #bandungrecook2_coryrahmaniah juga gampang sekali untuk dibikin, lho. Kita tidak perlu repot-repot untuk membeli lontong kari ayam #bandungrecook2_coryrahmaniah, tetapi Anda dapat menyajikan ditempatmu. Untuk Kalian yang hendak menghidangkannya, berikut resep menyajikan lontong kari ayam #bandungrecook2_coryrahmaniah yang enak yang mampu Kamu hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Lontong kari ayam #bandungrecook2_coryrahmaniah:

1. Gunakan 1/2 kg ayam
1. Ambil 2 lbr daun jeruk
1. Sediakan 1 btg serai
1. Sediakan 1 ruas lengkuas geprek
1. Gunakan 3 lbr daun salam
1. Gunakan 2 bh kapulaga (sya skip)
1. Gunakan 2 bh cengkeh (sya skip)
1. Gunakan 1 bh bunga lawang (sya skip)
1. Gunakan 600 ml santan
1. Sediakan 1 bks bubuk kari
1. Ambil Secukupnya garam
1. Gunakan Secukupnya kaldu bubuk
1. Sediakan Secukupnya air
1. Gunakan Secukupnya minyak goreng (utk menumis)
1. Sediakan  Bumbu halus:
1. Gunakan 10 cabe keriting (sya skip)
1. Gunakan 8 siung bwg merah
1. Siapkan 6 siung bwg putih
1. Sediakan 3 bh kemiri
1. Ambil 1 ruas kunyit
1. Sediakan 1 ruas kecil jahe
1. Sediakan 1 sdt ketumbar
1. Ambil 1/2 sdt jinten
1. Siapkan  Pelengkap:
1. Siapkan Secukupnya lontong
1. Gunakan Secukupnya bawang goreng
1. Sediakan Secukupnya cabe rawit (tambahan dr sya)




<!--inarticleads2-->

##### Langkah-langkah membuat Lontong kari ayam #bandungrecook2_coryrahmaniah:

1. Panaskan minyak goreng lalu Tumis bumbu halus hingga harum lalu masukan lengkuas serai daun jeruk dan daun salam
1. Lalu masukan air dan santan tunggu hingga mendidih
1. Setelah mendidih masukan ayam lalu tambahkan garam kaldu bubuk dan bubuk kari masak hingga ayam matang
1. Setelah matang jgn lupa tes rasa dan lontong kari ayam siap utk disajikan.




Ternyata cara membuat lontong kari ayam #bandungrecook2_coryrahmaniah yang mantab tidak rumit ini mudah banget ya! Semua orang mampu menghidangkannya. Cara Membuat lontong kari ayam #bandungrecook2_coryrahmaniah Sesuai banget buat kalian yang baru belajar memasak ataupun juga bagi kamu yang telah lihai dalam memasak.

Tertarik untuk mencoba buat resep lontong kari ayam #bandungrecook2_coryrahmaniah mantab tidak rumit ini? Kalau kalian ingin, ayo kalian segera buruan menyiapkan alat-alat dan bahannya, kemudian buat deh Resep lontong kari ayam #bandungrecook2_coryrahmaniah yang enak dan sederhana ini. Benar-benar mudah kan. 

Oleh karena itu, ketimbang kita diam saja, yuk kita langsung buat resep lontong kari ayam #bandungrecook2_coryrahmaniah ini. Dijamin kamu gak akan nyesel sudah buat resep lontong kari ayam #bandungrecook2_coryrahmaniah nikmat tidak rumit ini! Selamat mencoba dengan resep lontong kari ayam #bandungrecook2_coryrahmaniah enak tidak rumit ini di tempat tinggal masing-masing,ya!.

