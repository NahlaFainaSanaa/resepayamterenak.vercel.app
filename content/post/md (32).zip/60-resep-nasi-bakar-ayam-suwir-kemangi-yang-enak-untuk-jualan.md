---
description: "Resep Nasi Bakar Ayam Suwir Kemangi yang enak Untuk Jualan"
title: "Resep Nasi Bakar Ayam Suwir Kemangi yang enak Untuk Jualan"
slug: 60-resep-nasi-bakar-ayam-suwir-kemangi-yang-enak-untuk-jualan
date: 2021-04-19T07:21:11.172Z
image: https://img-global.cpcdn.com/recipes/207b7d85692171e8/680x482cq70/nasi-bakar-ayam-suwir-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/207b7d85692171e8/680x482cq70/nasi-bakar-ayam-suwir-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/207b7d85692171e8/680x482cq70/nasi-bakar-ayam-suwir-kemangi-foto-resep-utama.jpg
author: Antonio Price
ratingvalue: 4.4
reviewcount: 7
recipeingredient:
- "1/2 kg daging ayam bagian dada"
- "1/2 sdm perasan jeruk nipis"
- "8 siung bawang merah iris tipis"
- "5 siung bawang putih iris tipis"
- "3 cm lengkuas memarkan"
- "4 buah cabe merah besar potongpotong"
- " Cabe merah kecil sesuai selera"
- "1 buah tomat hijau optional"
- "1 batang sere iris tipis"
- "2 sdm minyak goreng"
- "1 sdm kecap manis"
- "1 ikat daun kemangi"
- "2 lembar daun salam"
- " Gula pasir secukupnya"
- " Garam secukupnya"
- " Penyedap rasa"
- " Air"
- " Daun pisang"
- "Tusuk lidi"
recipeinstructions:
- "Bersihkan daging ayam dan lumuri dengan perasan jeruk nipis. Diamkan 5 menit lalu bilas."
- "Didihkan air bersama 2 lembar daun salam, rebus daging ayam hingga matang. Kemudian tiriskan lalu suwir-suwir."
- "Panaskan 2 sdm minyak goreng, masukkan irisan bawang putih. Kemudian masukkan bawang merah, lengkuas, cabe merah besar, tomat hijau dan sere. Tumis hingga harum."
- "Masukkan ayam suwir dan kecap manis. Aduk-aduk hingga bumbu tercampur rata kemudian tambahkan gula, garam dan penyedap rasa. Cek rasa kemudian matikan api."
- "Bungkus nasi, suwiran ayam, daun kemangi dan cabe merah kecil dengan daun pisang yang telah dibersihkan dan di jemur."
- "Panggang di atas panggangan hingga daun pisang berubah warna dan harum."
- "Nasi bakar ayam suwir siap dinikmati."
categories:
- Resep
tags:
- nasi
- bakar
- ayam

katakunci: nasi bakar ayam 
nutrition: 276 calories
recipecuisine: Indonesian
preptime: "PT10M"
cooktime: "PT53M"
recipeyield: "3"
recipecategory: Dessert

---


![Nasi Bakar Ayam Suwir Kemangi](https://img-global.cpcdn.com/recipes/207b7d85692171e8/680x482cq70/nasi-bakar-ayam-suwir-kemangi-foto-resep-utama.jpg)

Apabila anda seorang ibu, menyajikan hidangan sedap pada famili adalah suatu hal yang memuaskan untuk anda sendiri. Peran seorang ibu Tidak saja mengurus rumah saja, namun kamu pun harus memastikan kebutuhan nutrisi tercukupi dan panganan yang dikonsumsi anak-anak mesti mantab.

Di waktu  saat ini, kita sebenarnya dapat membeli hidangan siap saji walaupun tidak harus repot memasaknya terlebih dahulu. Namun banyak juga lho mereka yang selalu mau memberikan hidangan yang terbaik bagi orang yang dicintainya. Lantaran, menghidangkan masakan yang dibuat sendiri jauh lebih higienis dan kita pun bisa menyesuaikan makanan tersebut berdasarkan makanan kesukaan famili. 



Mungkinkah anda salah satu penyuka nasi bakar ayam suwir kemangi?. Tahukah kamu, nasi bakar ayam suwir kemangi merupakan makanan khas di Indonesia yang saat ini disukai oleh orang-orang di berbagai tempat di Indonesia. Kamu dapat menghidangkan nasi bakar ayam suwir kemangi buatan sendiri di rumah dan pasti jadi hidangan kegemaranmu di akhir pekan.

Kamu tidak perlu bingung jika kamu ingin memakan nasi bakar ayam suwir kemangi, sebab nasi bakar ayam suwir kemangi gampang untuk didapatkan dan kalian pun dapat membuatnya sendiri di rumah. nasi bakar ayam suwir kemangi bisa dibuat memalui bermacam cara. Kini pun sudah banyak banget cara modern yang membuat nasi bakar ayam suwir kemangi lebih nikmat.

Resep nasi bakar ayam suwir kemangi pun sangat mudah dibikin, lho. Kamu jangan capek-capek untuk memesan nasi bakar ayam suwir kemangi, lantaran Kita bisa menyiapkan di rumahmu. Untuk Kita yang ingin membuatnya, berikut ini resep menyajikan nasi bakar ayam suwir kemangi yang mantab yang mampu Kamu buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Nasi Bakar Ayam Suwir Kemangi:

1. Siapkan 1/2 kg daging ayam bagian dada
1. Siapkan 1/2 sdm perasan jeruk nipis
1. Siapkan 8 siung bawang merah (iris tipis)
1. Ambil 5 siung bawang putih (iris tipis)
1. Sediakan 3 cm lengkuas (memarkan)
1. Sediakan 4 buah cabe merah besar (potong-potong)
1. Ambil  Cabe merah kecil (sesuai selera)
1. Ambil 1 buah tomat hijau (optional)
1. Gunakan 1 batang sere (iris tipis)
1. Siapkan 2 sdm minyak goreng
1. Gunakan 1 sdm kecap manis
1. Siapkan 1 ikat daun kemangi
1. Siapkan 2 lembar daun salam
1. Gunakan  Gula pasir (secukupnya)
1. Gunakan  Garam (secukupnya)
1. Sediakan  Penyedap rasa
1. Gunakan  Air
1. Gunakan  Daun pisang
1. Gunakan Tusuk lidi




<!--inarticleads2-->

##### Cara menyiapkan Nasi Bakar Ayam Suwir Kemangi:

1. Bersihkan daging ayam dan lumuri dengan perasan jeruk nipis. Diamkan 5 menit lalu bilas.
1. Didihkan air bersama 2 lembar daun salam, rebus daging ayam hingga matang. Kemudian tiriskan lalu suwir-suwir.
1. Panaskan 2 sdm minyak goreng, masukkan irisan bawang putih. Kemudian masukkan bawang merah, lengkuas, cabe merah besar, tomat hijau dan sere. Tumis hingga harum.
1. Masukkan ayam suwir dan kecap manis. Aduk-aduk hingga bumbu tercampur rata kemudian tambahkan gula, garam dan penyedap rasa. Cek rasa kemudian matikan api.
1. Bungkus nasi, suwiran ayam, daun kemangi dan cabe merah kecil dengan daun pisang yang telah dibersihkan dan di jemur.
1. Panggang di atas panggangan hingga daun pisang berubah warna dan harum.
1. Nasi bakar ayam suwir siap dinikmati.




Wah ternyata resep nasi bakar ayam suwir kemangi yang mantab sederhana ini enteng banget ya! Kalian semua bisa membuatnya. Cara buat nasi bakar ayam suwir kemangi Sangat cocok sekali buat kalian yang sedang belajar memasak maupun juga untuk anda yang sudah hebat dalam memasak.

Apakah kamu mau mencoba bikin resep nasi bakar ayam suwir kemangi mantab sederhana ini? Kalau anda ingin, yuk kita segera menyiapkan alat dan bahannya, maka bikin deh Resep nasi bakar ayam suwir kemangi yang mantab dan tidak rumit ini. Benar-benar mudah kan. 

Maka dari itu, daripada anda berfikir lama-lama, ayo langsung aja buat resep nasi bakar ayam suwir kemangi ini. Dijamin kamu tiidak akan menyesal sudah bikin resep nasi bakar ayam suwir kemangi nikmat simple ini! Selamat berkreasi dengan resep nasi bakar ayam suwir kemangi mantab tidak ribet ini di tempat tinggal kalian sendiri,ya!.

