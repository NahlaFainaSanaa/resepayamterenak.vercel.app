---
description: "Cara membuat Kari Ayam yang enak dan Mudah Dibuat"
title: "Cara membuat Kari Ayam yang enak dan Mudah Dibuat"
slug: 431-cara-membuat-kari-ayam-yang-enak-dan-mudah-dibuat
date: 2021-04-05T03:47:45.013Z
image: https://img-global.cpcdn.com/recipes/2a941aa5eeaaddb2/680x482cq70/kari-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2a941aa5eeaaddb2/680x482cq70/kari-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2a941aa5eeaaddb2/680x482cq70/kari-ayam-foto-resep-utama.jpg
author: Lettie Brady
ratingvalue: 4.5
reviewcount: 12
recipeingredient:
- "1/2 kg ayam kampung"
- "1 bks santan kara instan"
- "Secukupnya garam gula penyedap rasa"
- "Secukupnya bawang goreng"
- " Bumbu halus"
- "2 siung bawang putih"
- "4 siung bawang merah"
- "2 bh kemiri"
- "1/2 ruas kunyit"
- "3 bj cabe rawit skip kalau gak suka pedes"
- "1/4 ruas jahe sesuai selera"
- "1/2 sdt ketumbar bubuk"
- " Bumbu geprek"
- "1 batang serai"
- "2 daun jeruk"
- "1 daun salam"
recipeinstructions:
- "Rebus ayam yg sudah dibersihkan sampai empuk"
- "Tumis bumbu halus dan geprek sampai harum"
- "Masukkan ayam yg sudah direbus tadi aduk2 sebentar kemudian masukkan kira2 600ml air sambil diaduk2"
- "Terakhir, masukkan santan, aduk2 lagi sampai mendidih. Masukkan gula, garam, penyedap sesuai selera, jangan lupa test rasa. Kari ayam siap disajikan (ditaburi bawang goreng lebih nikmat)"
categories:
- Resep
tags:
- kari
- ayam

katakunci: kari ayam 
nutrition: 299 calories
recipecuisine: Indonesian
preptime: "PT16M"
cooktime: "PT53M"
recipeyield: "1"
recipecategory: Dinner

---


![Kari Ayam](https://img-global.cpcdn.com/recipes/2a941aa5eeaaddb2/680x482cq70/kari-ayam-foto-resep-utama.jpg)

Selaku seorang ibu, menyuguhkan masakan enak kepada keluarga tercinta merupakan hal yang sangat menyenangkan untuk anda sendiri. Peran seorang ibu bukan sekedar menangani rumah saja, tetapi anda pun wajib menyediakan keperluan nutrisi terpenuhi dan juga olahan yang disantap orang tercinta harus sedap.

Di era  sekarang, anda memang mampu memesan masakan instan meski tanpa harus susah mengolahnya dahulu. Namun banyak juga orang yang memang mau memberikan makanan yang terbaik bagi orang yang dicintainya. Karena, menghidangkan masakan sendiri jauh lebih higienis dan kita juga bisa menyesuaikan sesuai makanan kesukaan orang tercinta. 



Apakah anda salah satu penyuka kari ayam?. Asal kamu tahu, kari ayam merupakan sajian khas di Nusantara yang sekarang digemari oleh banyak orang dari hampir setiap wilayah di Nusantara. Kita bisa membuat kari ayam buatan sendiri di rumah dan boleh jadi camilan favorit di hari libur.

Kita jangan bingung untuk mendapatkan kari ayam, sebab kari ayam sangat mudah untuk ditemukan dan juga anda pun bisa memasaknya sendiri di rumah. kari ayam boleh dibuat memalui berbagai cara. Sekarang ada banyak sekali cara kekinian yang menjadikan kari ayam semakin nikmat.

Resep kari ayam pun gampang dibuat, lho. Kamu jangan capek-capek untuk membeli kari ayam, tetapi Kamu dapat membuatnya sendiri di rumah. Bagi Anda yang mau mencobanya, inilah resep menyajikan kari ayam yang lezat yang dapat Kamu buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Kari Ayam:

1. Gunakan 1/2 kg ayam kampung
1. Sediakan 1 bks santan kara instan
1. Gunakan Secukupnya garam, gula, penyedap rasa
1. Sediakan Secukupnya bawang goreng
1. Ambil  Bumbu halus
1. Sediakan 2 siung bawang putih
1. Sediakan 4 siung bawang merah
1. Ambil 2 bh kemiri
1. Sediakan 1/2 ruas kunyit
1. Ambil 3 bj cabe rawit (skip kalau gak suka pedes)
1. Siapkan 1/4 ruas jahe (sesuai selera)
1. Gunakan 1/2 sdt ketumbar bubuk
1. Siapkan  Bumbu geprek
1. Sediakan 1 batang serai
1. Sediakan 2 daun jeruk
1. Ambil 1 daun salam




<!--inarticleads2-->

##### Langkah-langkah membuat Kari Ayam:

1. Rebus ayam yg sudah dibersihkan sampai empuk
1. Tumis bumbu halus dan geprek sampai harum
1. Masukkan ayam yg sudah direbus tadi aduk2 sebentar kemudian masukkan kira2 600ml air sambil diaduk2
1. Terakhir, masukkan santan, aduk2 lagi sampai mendidih. Masukkan gula, garam, penyedap sesuai selera, jangan lupa test rasa. Kari ayam siap disajikan (ditaburi bawang goreng lebih nikmat)




Wah ternyata resep kari ayam yang mantab simple ini gampang banget ya! Anda Semua bisa membuatnya. Cara Membuat kari ayam Cocok banget buat kita yang baru belajar memasak maupun bagi kamu yang sudah lihai memasak.

Tertarik untuk mulai mencoba bikin resep kari ayam nikmat tidak rumit ini? Kalau kalian mau, ayo kalian segera buruan siapkan peralatan dan bahan-bahannya, setelah itu bikin deh Resep kari ayam yang mantab dan sederhana ini. Sungguh gampang kan. 

Maka, daripada kita berlama-lama, yuk langsung aja hidangkan resep kari ayam ini. Pasti anda gak akan nyesel bikin resep kari ayam nikmat simple ini! Selamat berkreasi dengan resep kari ayam nikmat tidak ribet ini di tempat tinggal kalian sendiri,ya!.

