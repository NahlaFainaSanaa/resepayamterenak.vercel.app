---
description: "Cara buat Ayam Tangkap Khas Aceh Sederhana dan Mudah Dibuat"
title: "Cara buat Ayam Tangkap Khas Aceh Sederhana dan Mudah Dibuat"
slug: 487-cara-buat-ayam-tangkap-khas-aceh-sederhana-dan-mudah-dibuat
date: 2021-02-15T18:14:17.251Z
image: https://img-global.cpcdn.com/recipes/d8ca77ad0f7f07f0/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d8ca77ad0f7f07f0/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d8ca77ad0f7f07f0/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg
author: Jeremiah Greene
ratingvalue: 3.1
reviewcount: 11
recipeingredient:
- "1 ekor Ayam potong kecilkecil"
- "1 buah Jeruk nipis"
- " Garam secukup rasa"
- " Air kelapa saya gak pake"
- "secukupnya Daun kari"
- "3-4 lembar Daun pandan potong pendek"
- "5 buah Cabe ijo potongpotong"
- "Secukupnya Kaldu jamur atau kaldu ayam"
- " Minyak untuk menggoreng"
- " Bumbu halus "
- "10 buah Bawang merah"
- "4 siung Bawang putih"
- "3 butir Kemiri"
- "1 sdt Kunyit bubuk"
recipeinstructions:
- "Kalo ada air kelapa, rendam dulu sebentar sekitar 15-20 menit, lalu cuci bersih. Lumuri ayam dengan jeruk nipis dan garam."
- "Haluskan bahan bumbu halus dengan blender atau lebih bagus lagi menggunakan ulekan biar gak terlalu berair."
- "Marinasi ayam dengan bumbu halus, kaldu jamur atau kaldu ayam di dalam chiller selama 30 menit."
- "Panaskan minyak, goreng ayam, kalo sudah mulai matang, masukkan sedikit daun kari, daun pandan dan cabe ijo, goreng sampai daun-daun tersebut terlihat crispy, angkat ayam beserta daun-daunannya. Ulangi prosesnya sampai ayam habis."
- "Sajikan ayam tangkap dengan nasi putih panas."
categories:
- Resep
tags:
- ayam
- tangkap
- khas

katakunci: ayam tangkap khas 
nutrition: 207 calories
recipecuisine: Indonesian
preptime: "PT17M"
cooktime: "PT54M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Tangkap Khas Aceh](https://img-global.cpcdn.com/recipes/d8ca77ad0f7f07f0/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg)

Sebagai seorang ibu, menyuguhkan olahan lezat untuk keluarga merupakan hal yang memuaskan untuk kita sendiri. Tugas seorang  wanita bukan cuma menjaga rumah saja, tapi anda pun harus memastikan kebutuhan gizi tercukupi dan olahan yang disantap orang tercinta mesti nikmat.

Di zaman  saat ini, kamu sebenarnya mampu mengorder hidangan instan walaupun tanpa harus susah membuatnya terlebih dahulu. Tetapi ada juga orang yang memang ingin memberikan hidangan yang terlezat bagi keluarganya. Lantaran, menyajikan masakan yang dibuat sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan masakan tersebut sesuai dengan masakan kesukaan orang tercinta. 



Apakah anda seorang penggemar ayam tangkap khas aceh?. Tahukah kamu, ayam tangkap khas aceh merupakan hidangan khas di Indonesia yang kini disenangi oleh orang-orang dari hampir setiap daerah di Indonesia. Kita dapat menghidangkan ayam tangkap khas aceh sendiri di rumahmu dan pasti jadi hidangan kegemaranmu di hari libur.

Kalian tidak perlu bingung jika kamu ingin mendapatkan ayam tangkap khas aceh, lantaran ayam tangkap khas aceh mudah untuk didapatkan dan kita pun bisa mengolahnya sendiri di rumah. ayam tangkap khas aceh dapat dibuat dengan berbagai cara. Sekarang ada banyak cara modern yang membuat ayam tangkap khas aceh lebih mantap.

Resep ayam tangkap khas aceh pun gampang sekali untuk dibuat, lho. Kalian tidak perlu ribet-ribet untuk membeli ayam tangkap khas aceh, lantaran Kita mampu menyiapkan di rumahmu. Bagi Kamu yang mau membuatnya, dibawah ini merupakan cara untuk membuat ayam tangkap khas aceh yang lezat yang bisa Kita coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Ayam Tangkap Khas Aceh:

1. Ambil 1 ekor Ayam, potong kecil-kecil
1. Sediakan 1 buah Jeruk nipis
1. Siapkan  Garam secukup rasa
1. Siapkan  Air kelapa (saya gak pake)
1. Gunakan secukupnya Daun kari
1. Sediakan 3-4 lembar Daun pandan, potong pendek
1. Ambil 5 buah Cabe ijo, potong-potong
1. Gunakan Secukupnya Kaldu jamur atau kaldu ayam
1. Ambil  Minyak untuk menggoreng
1. Siapkan  Bumbu halus :
1. Siapkan 10 buah Bawang merah
1. Ambil 4 siung Bawang putih
1. Ambil 3 butir Kemiri
1. Gunakan 1 sdt Kunyit bubuk




<!--inarticleads2-->

##### Cara membuat Ayam Tangkap Khas Aceh:

1. Kalo ada air kelapa, rendam dulu sebentar sekitar 15-20 menit, lalu cuci bersih. Lumuri ayam dengan jeruk nipis dan garam.
1. Haluskan bahan bumbu halus dengan blender atau lebih bagus lagi menggunakan ulekan biar gak terlalu berair.
1. Marinasi ayam dengan bumbu halus, kaldu jamur atau kaldu ayam di dalam chiller selama 30 menit.
1. Panaskan minyak, goreng ayam, kalo sudah mulai matang, masukkan sedikit daun kari, daun pandan dan cabe ijo, goreng sampai daun-daun tersebut terlihat crispy, angkat ayam beserta daun-daunannya. Ulangi prosesnya sampai ayam habis.
1. Sajikan ayam tangkap dengan nasi putih panas.




Ternyata resep ayam tangkap khas aceh yang enak tidak ribet ini mudah sekali ya! Kalian semua mampu mencobanya. Cara buat ayam tangkap khas aceh Cocok sekali untuk kalian yang baru belajar memasak maupun bagi anda yang telah pandai dalam memasak.

Apakah kamu tertarik mencoba membuat resep ayam tangkap khas aceh enak sederhana ini? Kalau kalian ingin, yuk kita segera buruan menyiapkan peralatan dan bahannya, maka bikin deh Resep ayam tangkap khas aceh yang mantab dan sederhana ini. Sangat mudah kan. 

Maka dari itu, ketimbang kalian berlama-lama, maka langsung aja hidangkan resep ayam tangkap khas aceh ini. Dijamin kamu tak akan nyesel sudah bikin resep ayam tangkap khas aceh mantab tidak ribet ini! Selamat berkreasi dengan resep ayam tangkap khas aceh enak tidak rumit ini di tempat tinggal sendiri,ya!.

