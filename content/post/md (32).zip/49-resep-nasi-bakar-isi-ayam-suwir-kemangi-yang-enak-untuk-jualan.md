---
description: "Resep Nasi Bakar isi Ayam Suwir Kemangi yang enak Untuk Jualan"
title: "Resep Nasi Bakar isi Ayam Suwir Kemangi yang enak Untuk Jualan"
slug: 49-resep-nasi-bakar-isi-ayam-suwir-kemangi-yang-enak-untuk-jualan
date: 2021-06-23T00:06:16.141Z
image: https://img-global.cpcdn.com/recipes/81e3b76fdcd3005d/680x482cq70/nasi-bakar-isi-ayam-suwir-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/81e3b76fdcd3005d/680x482cq70/nasi-bakar-isi-ayam-suwir-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/81e3b76fdcd3005d/680x482cq70/nasi-bakar-isi-ayam-suwir-kemangi-foto-resep-utama.jpg
author: Frank Ferguson
ratingvalue: 3.2
reviewcount: 7
recipeingredient:
- " Nasi Gurih"
- "1 1/4 cup beras"
- "1 batang serai"
- "2 lembar daun salam"
- "1/2 bungkus santan cair sachet"
- " Air rebusan kaldu ayam"
- "1 buah cabai rawit setan kepedasan sesuai selera"
- " Ayam Suwir Kemangi"
- "250 gr dada ayam"
- "6 butir bawang merah"
- "4 butir bawang putih"
- "5 buah cabai merah keriting"
- "5 butir kemir"
- "2 lembar daun salam"
- "1 batang serai"
- "1/2 bungkus santan cair sachet"
- "1 batang kemangi"
- "secukupnya Garam"
- "secukupnya Gula merah"
- "secukupnya Kecap"
- " Air rebusan kaldu ayam"
- " Pembungkus"
- " Daun pisang yang sudah dipanaskan"
- " Tusul gigi atau staples"
recipeinstructions:
- "Rebus daging ayam dengan air mendidih kurang lebih 10 menit. Jangan lupa tambahkan potongan bawang putih dan sedikit garam agar gurih. Ketika sudah matang suwir ayam dan sisihkan kaldunya."
- "Cuci beras sampai bersih. Masukkan daun salam, sereh, cabai rawit, santan, dan air rebusan kaldu. Aduk rata dan masak nasi dalam rice cooker."
- "Haluskan bawang merah, bawang putih, kemiri, dna cabai. Setelah lembut tumis bersama dengan daun salam dan sereh. Setelah harum masukkan gula pasir, garam, gula merah, kecap, air rebusan kaldu. Apabila rasa sudah pas masukkan ayam suwir."
- "Setelah mendidih dan bumbu tercampur rata masukkan santan."
- "Biarkah kuah sedikit surut. Setelah surut masukkan daun kemangi. Aduk rata dan tunggu sampai bumbu meresao. Selanjutkan matikan api."
- "Ambil nasi gurih dan cetak di atas daun pisang dengan susunan nasi, ayam, dan nasi. Gulung dan padatkan nasi kemudian tusuk dikedua ujungnya menggunakan lidi/ tusuk gigi."
- "Panaskan pemanggang dan panggang nasi yang sudah dibungkus. Jangan lupa dibolak balik ya supaya matangnya merata."
- "Selamat mencoba. Semoga suka dengan resepnya 🤗"
categories:
- Resep
tags:
- nasi
- bakar
- isi

katakunci: nasi bakar isi 
nutrition: 133 calories
recipecuisine: Indonesian
preptime: "PT39M"
cooktime: "PT37M"
recipeyield: "3"
recipecategory: Lunch

---


![Nasi Bakar isi Ayam Suwir Kemangi](https://img-global.cpcdn.com/recipes/81e3b76fdcd3005d/680x482cq70/nasi-bakar-isi-ayam-suwir-kemangi-foto-resep-utama.jpg)

Sebagai seorang ibu, menyajikan santapan sedap bagi orang tercinta adalah suatu hal yang membahagiakan bagi anda sendiri. Tanggung jawab seorang istri Tidak cuman menjaga rumah saja, namun kamu juga harus memastikan kebutuhan gizi terpenuhi dan juga santapan yang disantap anak-anak harus nikmat.

Di waktu  saat ini, kamu sebenarnya dapat membeli olahan instan meski tanpa harus repot mengolahnya dulu. Tetapi ada juga mereka yang selalu mau menyajikan yang terbaik bagi orang tercintanya. Karena, memasak yang dibuat sendiri jauh lebih bersih dan kita pun bisa menyesuaikan masakan tersebut sesuai dengan kesukaan keluarga tercinta. 



Apakah kamu salah satu penyuka nasi bakar isi ayam suwir kemangi?. Tahukah kamu, nasi bakar isi ayam suwir kemangi merupakan makanan khas di Nusantara yang kini disenangi oleh banyak orang dari berbagai tempat di Indonesia. Anda bisa menghidangkan nasi bakar isi ayam suwir kemangi olahan sendiri di rumahmu dan boleh dijadikan hidangan favorit di akhir pekanmu.

Anda tak perlu bingung untuk mendapatkan nasi bakar isi ayam suwir kemangi, lantaran nasi bakar isi ayam suwir kemangi tidak sulit untuk ditemukan dan juga kamu pun boleh memasaknya sendiri di rumah. nasi bakar isi ayam suwir kemangi bisa diolah dengan berbagai cara. Saat ini sudah banyak banget resep modern yang membuat nasi bakar isi ayam suwir kemangi lebih mantap.

Resep nasi bakar isi ayam suwir kemangi juga sangat mudah untuk dibuat, lho. Kalian jangan repot-repot untuk membeli nasi bakar isi ayam suwir kemangi, lantaran Kita mampu menyiapkan di rumah sendiri. Bagi Kita yang mau mencobanya, inilah resep membuat nasi bakar isi ayam suwir kemangi yang enak yang bisa Kita hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Nasi Bakar isi Ayam Suwir Kemangi:

1. Siapkan  Nasi Gurih
1. Sediakan 1 1/4 cup beras
1. Siapkan 1 batang serai
1. Sediakan 2 lembar daun salam
1. Ambil 1/2 bungkus santan cair sachet
1. Gunakan  Air rebusan kaldu ayam
1. Gunakan 1 buah cabai rawit setan (kepedasan sesuai selera)
1. Gunakan  Ayam Suwir Kemangi
1. Gunakan 250 gr dada ayam
1. Ambil 6 butir bawang merah
1. Sediakan 4 butir bawang putih
1. Gunakan 5 buah cabai merah keriting
1. Sediakan 5 butir kemir
1. Sediakan 2 lembar daun salam
1. Ambil 1 batang serai
1. Gunakan 1/2 bungkus santan cair sachet
1. Siapkan 1 batang kemangi
1. Ambil secukupnya Garam
1. Siapkan secukupnya Gula merah
1. Gunakan secukupnya Kecap
1. Gunakan  Air rebusan kaldu ayam
1. Siapkan  Pembungkus
1. Siapkan  Daun pisang yang sudah dipanaskan
1. Gunakan  Tusul gigi atau staples




<!--inarticleads2-->

##### Cara menyiapkan Nasi Bakar isi Ayam Suwir Kemangi:

1. Rebus daging ayam dengan air mendidih kurang lebih 10 menit. Jangan lupa tambahkan potongan bawang putih dan sedikit garam agar gurih. Ketika sudah matang suwir ayam dan sisihkan kaldunya.
1. Cuci beras sampai bersih. Masukkan daun salam, sereh, cabai rawit, santan, dan air rebusan kaldu. Aduk rata dan masak nasi dalam rice cooker.
1. Haluskan bawang merah, bawang putih, kemiri, dna cabai. Setelah lembut tumis bersama dengan daun salam dan sereh. Setelah harum masukkan gula pasir, garam, gula merah, kecap, air rebusan kaldu. Apabila rasa sudah pas masukkan ayam suwir.
1. Setelah mendidih dan bumbu tercampur rata masukkan santan.
1. Biarkah kuah sedikit surut. Setelah surut masukkan daun kemangi. Aduk rata dan tunggu sampai bumbu meresao. Selanjutkan matikan api.
1. Ambil nasi gurih dan cetak di atas daun pisang dengan susunan nasi, ayam, dan nasi. Gulung dan padatkan nasi kemudian tusuk dikedua ujungnya menggunakan lidi/ tusuk gigi.
1. Panaskan pemanggang dan panggang nasi yang sudah dibungkus. Jangan lupa dibolak balik ya supaya matangnya merata.
1. Selamat mencoba. Semoga suka dengan resepnya 🤗




Wah ternyata resep nasi bakar isi ayam suwir kemangi yang mantab simple ini enteng sekali ya! Kalian semua dapat membuatnya. Resep nasi bakar isi ayam suwir kemangi Sangat sesuai banget buat kita yang sedang belajar memasak maupun untuk kalian yang telah hebat dalam memasak.

Tertarik untuk mulai mencoba bikin resep nasi bakar isi ayam suwir kemangi mantab simple ini? Kalau kamu tertarik, ayo kalian segera buruan siapkan peralatan dan bahannya, setelah itu buat deh Resep nasi bakar isi ayam suwir kemangi yang lezat dan sederhana ini. Benar-benar gampang kan. 

Oleh karena itu, daripada kamu berlama-lama, hayo kita langsung buat resep nasi bakar isi ayam suwir kemangi ini. Dijamin anda tiidak akan menyesal membuat resep nasi bakar isi ayam suwir kemangi lezat tidak ribet ini! Selamat mencoba dengan resep nasi bakar isi ayam suwir kemangi lezat tidak ribet ini di rumah kalian sendiri,ya!.

