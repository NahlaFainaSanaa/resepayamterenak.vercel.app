---
description: "Resep Ayam Woku Kemangi Sederhana dan Mudah Dibuat"
title: "Resep Ayam Woku Kemangi Sederhana dan Mudah Dibuat"
slug: 328-resep-ayam-woku-kemangi-sederhana-dan-mudah-dibuat
date: 2021-02-05T02:19:00.767Z
image: https://img-global.cpcdn.com/recipes/db937e948b1d1597/680x482cq70/ayam-woku-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/db937e948b1d1597/680x482cq70/ayam-woku-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/db937e948b1d1597/680x482cq70/ayam-woku-kemangi-foto-resep-utama.jpg
author: Lora Baldwin
ratingvalue: 3.5
reviewcount: 6
recipeingredient:
- "  BAHAN "
- "1.000 ml Air Mineral"
- "1 Ekor Ayam Kampung potong jd beberapa bagian me Ayam Negri"
- "1/2 buah Jeruk lemon atau Nipis"
- "  BUMBU HALUS "
- "10 buah Cabe Merah Keriting sesuai selera"
- "8 buah Cabe Rawit Oren sesuai selera"
- "7 butir Bawang Merah"
- "4 siung Bawang Putih"
- "4 butir Kemiri disangrai dulu"
- "1 ruas jari Jahe"
- "1 ruas jari Kunyit"
- "  BUMBU LAINNYA "
- "5 lembar Daun Jeruk iris kasar me disobek"
- "3 lembar Daun Salam"
- "3 batang Sereh geprek"
- "3 ikat Daun Kemangi petikin daunnya"
- "2 sdm Kaldu Instant"
- "1 buah Tomat iris  iris"
- "1 batang Daun Bawang iris kasar"
- "1 sdt Lada bubuk"
- "1 sdm peres Gula pasir"
- "1/2 sdt Garam"
- "Secukupnya Minyak goreng untuk menumis"
recipeinstructions:
- "Siapkan semua bahan. Cuci bersih ayam lalu Lumuri ayam dengan jeruk lemon atau nipis. Diamkan sekitar 15 menit. Setelah itu bilas. Sisihkan. Kemudian iris-iris tomat dan daun bawang. Sisihkan."
- "Uleg atau Blender bahan bumbu halus."
- "Tumis bumbu halus tersebut sampai harum. Lalu masukkan sereh, daun salam dan daun jeruk."
- "Setelah itu masukkan ayam dan air mineral. Aduk rata."
- "Tambahkan Penyedap rasa / kaldu instant, Lada bubuk, gula pasir dan garam halus. Kemudian masukkan irisan tomat dan daun kemangi. Aduk rata."
- "Terakhir, masukkan irisan daun bawang. Masak sampai ayam matang. Jangan lupa tes rasa sampai bumbu dirasa sudah pas. Angkat."
- "Sajikan."
categories:
- Resep
tags:
- ayam
- woku
- kemangi

katakunci: ayam woku kemangi 
nutrition: 244 calories
recipecuisine: Indonesian
preptime: "PT24M"
cooktime: "PT53M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Woku Kemangi](https://img-global.cpcdn.com/recipes/db937e948b1d1597/680x482cq70/ayam-woku-kemangi-foto-resep-utama.jpg)

Andai kamu seorang ibu, menyuguhkan masakan sedap buat orang tercinta merupakan suatu hal yang membahagiakan bagi kamu sendiri. Kewajiban seorang ibu Tidak hanya mengatur rumah saja, tetapi kamu pun wajib menyediakan kebutuhan nutrisi tercukupi dan masakan yang disantap keluarga tercinta mesti sedap.

Di era  saat ini, anda memang dapat memesan olahan instan tanpa harus capek mengolahnya lebih dulu. Namun banyak juga mereka yang memang ingin memberikan yang terenak untuk orang yang dicintainya. Sebab, menyajikan masakan yang dibuat sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan makanan tersebut sesuai selera famili. 



Apakah anda adalah seorang penggemar ayam woku kemangi?. Asal kamu tahu, ayam woku kemangi merupakan makanan khas di Nusantara yang sekarang disenangi oleh setiap orang dari hampir setiap wilayah di Nusantara. Anda dapat menghidangkan ayam woku kemangi sendiri di rumahmu dan pasti jadi hidangan kegemaranmu di hari libur.

Kalian jangan bingung jika kamu ingin mendapatkan ayam woku kemangi, sebab ayam woku kemangi gampang untuk dicari dan juga anda pun dapat mengolahnya sendiri di tempatmu. ayam woku kemangi boleh diolah dengan bermacam cara. Sekarang telah banyak sekali resep kekinian yang membuat ayam woku kemangi semakin lebih nikmat.

Resep ayam woku kemangi juga mudah sekali dibikin, lho. Anda tidak perlu capek-capek untuk memesan ayam woku kemangi, tetapi Anda mampu menyiapkan di rumahmu. Untuk Kita yang akan menyajikannya, berikut resep untuk membuat ayam woku kemangi yang mantab yang bisa Anda buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Ayam Woku Kemangi:

1. Siapkan  🌿 BAHAN 🌿
1. Siapkan 1.000 ml Air Mineral
1. Gunakan 1 Ekor Ayam Kampung, potong jd beberapa bagian (me: Ayam Negri)
1. Gunakan 1/2 buah Jeruk lemon atau Nipis
1. Sediakan  🌿 BUMBU HALUS 🌿
1. Ambil 10 buah Cabe Merah Keriting (sesuai selera)
1. Sediakan 8 buah Cabe Rawit Oren (sesuai selera)
1. Gunakan 7 butir Bawang Merah
1. Ambil 4 siung Bawang Putih
1. Siapkan 4 butir Kemiri, disangrai dulu
1. Gunakan 1 ruas jari Jahe
1. Gunakan 1 ruas jari Kunyit
1. Ambil  🌿 BUMBU LAINNYA 🌿
1. Sediakan 5 lembar Daun Jeruk, iris kasar (me: disobek)
1. Sediakan 3 lembar Daun Salam
1. Ambil 3 batang Sereh, geprek
1. Ambil 3 ikat Daun Kemangi, petikin daunnya
1. Siapkan 2 sdm Kaldu Instant
1. Ambil 1 buah Tomat, iris - iris
1. Ambil 1 batang Daun Bawang, iris kasar
1. Sediakan 1 sdt Lada bubuk
1. Siapkan 1 sdm peres Gula pasir
1. Ambil 1/2 sdt Garam
1. Siapkan Secukupnya Minyak goreng untuk menumis




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Woku Kemangi:

1. Siapkan semua bahan. Cuci bersih ayam lalu Lumuri ayam dengan jeruk lemon atau nipis. Diamkan sekitar 15 menit. Setelah itu bilas. Sisihkan. Kemudian iris-iris tomat dan daun bawang. Sisihkan.
1. Uleg atau Blender bahan bumbu halus.
1. Tumis bumbu halus tersebut sampai harum. Lalu masukkan sereh, daun salam dan daun jeruk.
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Ayam Woku Kemangi">1. Setelah itu masukkan ayam dan air mineral. Aduk rata.
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Ayam Woku Kemangi">1. Tambahkan Penyedap rasa / kaldu instant, Lada bubuk, gula pasir dan garam halus. Kemudian masukkan irisan tomat dan daun kemangi. Aduk rata.
1. Terakhir, masukkan irisan daun bawang. Masak sampai ayam matang. Jangan lupa tes rasa sampai bumbu dirasa sudah pas. Angkat.
1. Sajikan.




Ternyata resep ayam woku kemangi yang lezat tidak ribet ini enteng banget ya! Kamu semua bisa menghidangkannya. Cara Membuat ayam woku kemangi Sangat cocok banget buat kalian yang baru belajar memasak maupun untuk kalian yang sudah pandai memasak.

Tertarik untuk mulai mencoba bikin resep ayam woku kemangi enak sederhana ini? Kalau kamu mau, mending kamu segera buruan siapin alat dan bahannya, kemudian buat deh Resep ayam woku kemangi yang lezat dan sederhana ini. Betul-betul mudah kan. 

Jadi, daripada anda berfikir lama-lama, hayo kita langsung buat resep ayam woku kemangi ini. Dijamin kalian tiidak akan menyesal sudah bikin resep ayam woku kemangi mantab tidak rumit ini! Selamat mencoba dengan resep ayam woku kemangi lezat sederhana ini di rumah kalian sendiri,ya!.

