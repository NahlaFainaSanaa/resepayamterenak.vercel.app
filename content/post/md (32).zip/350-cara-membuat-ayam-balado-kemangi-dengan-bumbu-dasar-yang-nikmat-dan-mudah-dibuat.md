---
description: "Cara membuat Ayam Balado Kemangi dengan Bumbu Dasar yang nikmat dan Mudah Dibuat"
title: "Cara membuat Ayam Balado Kemangi dengan Bumbu Dasar yang nikmat dan Mudah Dibuat"
slug: 350-cara-membuat-ayam-balado-kemangi-dengan-bumbu-dasar-yang-nikmat-dan-mudah-dibuat
date: 2021-06-06T23:49:34.932Z
image: https://img-global.cpcdn.com/recipes/3a9f40340018d44e/680x482cq70/ayam-balado-kemangi-dengan-bumbu-dasar-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/3a9f40340018d44e/680x482cq70/ayam-balado-kemangi-dengan-bumbu-dasar-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/3a9f40340018d44e/680x482cq70/ayam-balado-kemangi-dengan-bumbu-dasar-foto-resep-utama.jpg
author: Amanda Fernandez
ratingvalue: 3.5
reviewcount: 11
recipeingredient:
- "1/2 ekor ayam potong 6"
- "2 ikat kemangi ambil daunnya"
- "10 buah cabe rawit utuh"
- "200 ml air"
- "Secukupnya minyak goreng"
- " Bumbu marinasi "
- "1/2 buah jeruk nipis"
- "1 sdt garam"
- "1 sdt bumbu dasar bawang"
- " Bumbu cemplung"
- "1 batang sereh geprek"
- "1 ruas jahe geprek"
- "1 ruas lengkuas geprek"
- "2 lembar daun salam"
- "2 lembar daun jeruk"
- " Bumbu dasar "
- "1 sdt garam"
- "1 sdt kaldu bubuk"
- "1/2 buah gula merah iris"
- "1/2 buah bawang bombay iris"
- "3 sdm bumbu dasar merah           lihat resep"
- "2 sdm bumbu dasar bawang           lihat resep"
recipeinstructions:
- "Cuci bersih ayam dan marinasi dengan 1 sdt bumbu dasar bawang + 1 sdt garam + perasan jeruk nipis. Diamkan dlm kulkas selama minimal 1 jam (saya semalaman). Lalu goreng hingga berwarna kecoklatan."
- "Siapkan bahan lainnya. Panaskan minyak dlm wajan, tumis bawang bombay sampai harum, lalu masukkan bumbu dasar bawang dan bumbu dasar merah, tambahkan bumbu cemplungnya, aduk rata."
- "Tambahkan air, garam, kaldu bubuk dan gula merah tunggu mendidih lalu masukkan ayam, aduk rata. Biarkan sampai meresap dan kuah agak menyusut, koreksi rasa. Lalu masukkan cabe rawit dan kemangi, aduk rata sebentar lalu angkat."
categories:
- Resep
tags:
- ayam
- balado
- kemangi

katakunci: ayam balado kemangi 
nutrition: 156 calories
recipecuisine: Indonesian
preptime: "PT26M"
cooktime: "PT45M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam Balado Kemangi dengan Bumbu Dasar](https://img-global.cpcdn.com/recipes/3a9f40340018d44e/680x482cq70/ayam-balado-kemangi-dengan-bumbu-dasar-foto-resep-utama.jpg)

Jika kamu seorang yang hobi masak, menyuguhkan santapan lezat kepada famili merupakan hal yang memuaskan bagi anda sendiri. Tanggung jawab seorang ibu bukan cuma menjaga rumah saja, tetapi kamu pun harus menyediakan kebutuhan nutrisi terpenuhi dan panganan yang dimakan orang tercinta wajib sedap.

Di zaman  sekarang, anda memang mampu memesan santapan yang sudah jadi tanpa harus repot membuatnya dulu. Tetapi ada juga orang yang memang mau menghidangkan yang terlezat untuk orang tercintanya. Karena, menyajikan masakan yang diolah sendiri jauh lebih bersih dan bisa menyesuaikan sesuai makanan kesukaan orang tercinta. 



Mungkinkah kamu salah satu penikmat ayam balado kemangi dengan bumbu dasar?. Tahukah kamu, ayam balado kemangi dengan bumbu dasar adalah makanan khas di Nusantara yang sekarang disukai oleh banyak orang di hampir setiap wilayah di Indonesia. Kalian dapat menghidangkan ayam balado kemangi dengan bumbu dasar sendiri di rumah dan dapat dijadikan camilan kesenanganmu di akhir pekanmu.

Anda tidak usah bingung jika kamu ingin memakan ayam balado kemangi dengan bumbu dasar, sebab ayam balado kemangi dengan bumbu dasar gampang untuk didapatkan dan juga kita pun dapat mengolahnya sendiri di rumah. ayam balado kemangi dengan bumbu dasar dapat dimasak lewat beragam cara. Saat ini sudah banyak sekali resep modern yang menjadikan ayam balado kemangi dengan bumbu dasar lebih mantap.

Resep ayam balado kemangi dengan bumbu dasar juga mudah dibikin, lho. Anda tidak perlu capek-capek untuk memesan ayam balado kemangi dengan bumbu dasar, karena Kamu dapat menghidangkan di rumahmu. Untuk Kalian yang mau menyajikannya, berikut resep untuk menyajikan ayam balado kemangi dengan bumbu dasar yang lezat yang mampu Anda buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Ayam Balado Kemangi dengan Bumbu Dasar:

1. Gunakan 1/2 ekor ayam, potong 6
1. Siapkan 2 ikat kemangi, ambil daunnya
1. Gunakan 10 buah cabe rawit utuh
1. Gunakan 200 ml air
1. Gunakan Secukupnya minyak goreng
1. Sediakan  Bumbu marinasi :
1. Ambil 1/2 buah jeruk nipis
1. Sediakan 1 sdt garam
1. Gunakan 1 sdt bumbu dasar bawang
1. Siapkan  Bumbu cemplung:
1. Siapkan 1 batang sereh, geprek
1. Sediakan 1 ruas jahe, geprek
1. Ambil 1 ruas lengkuas, geprek
1. Siapkan 2 lembar daun salam
1. Siapkan 2 lembar daun jeruk
1. Siapkan  Bumbu dasar :
1. Gunakan 1 sdt garam
1. Gunakan 1 sdt kaldu bubuk
1. Sediakan 1/2 buah gula merah, iris
1. Sediakan 1/2 buah bawang bombay, iris
1. Sediakan 3 sdm bumbu dasar merah           (lihat resep)
1. Gunakan 2 sdm bumbu dasar bawang           (lihat resep)




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam Balado Kemangi dengan Bumbu Dasar:

1. Cuci bersih ayam dan marinasi dengan 1 sdt bumbu dasar bawang + 1 sdt garam + perasan jeruk nipis. Diamkan dlm kulkas selama minimal 1 jam (saya semalaman). Lalu goreng hingga berwarna kecoklatan.
1. Siapkan bahan lainnya. Panaskan minyak dlm wajan, tumis bawang bombay sampai harum, lalu masukkan bumbu dasar bawang dan bumbu dasar merah, tambahkan bumbu cemplungnya, aduk rata.
1. Tambahkan air, garam, kaldu bubuk dan gula merah tunggu mendidih lalu masukkan ayam, aduk rata. Biarkan sampai meresap dan kuah agak menyusut, koreksi rasa. Lalu masukkan cabe rawit dan kemangi, aduk rata sebentar lalu angkat.




Wah ternyata cara membuat ayam balado kemangi dengan bumbu dasar yang nikamt tidak rumit ini gampang sekali ya! Kita semua dapat membuatnya. Resep ayam balado kemangi dengan bumbu dasar Sesuai banget buat kita yang baru akan belajar memasak ataupun bagi anda yang sudah jago dalam memasak.

Apakah kamu mau mencoba buat resep ayam balado kemangi dengan bumbu dasar enak tidak ribet ini? Kalau kamu tertarik, mending kamu segera menyiapkan alat-alat dan bahannya, maka buat deh Resep ayam balado kemangi dengan bumbu dasar yang lezat dan simple ini. Sangat mudah kan. 

Maka dari itu, daripada kalian berfikir lama-lama, hayo kita langsung saja bikin resep ayam balado kemangi dengan bumbu dasar ini. Dijamin anda tak akan menyesal sudah membuat resep ayam balado kemangi dengan bumbu dasar enak simple ini! Selamat berkreasi dengan resep ayam balado kemangi dengan bumbu dasar enak simple ini di rumah masing-masing,ya!.

