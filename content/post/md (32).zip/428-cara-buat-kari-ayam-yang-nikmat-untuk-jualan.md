---
description: "Cara buat Kari Ayam yang nikmat Untuk Jualan"
title: "Cara buat Kari Ayam yang nikmat Untuk Jualan"
slug: 428-cara-buat-kari-ayam-yang-nikmat-untuk-jualan
date: 2021-01-18T08:45:40.301Z
image: https://img-global.cpcdn.com/recipes/104e6b71a89f06f6/680x482cq70/kari-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/104e6b71a89f06f6/680x482cq70/kari-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/104e6b71a89f06f6/680x482cq70/kari-ayam-foto-resep-utama.jpg
author: Emma Chandler
ratingvalue: 4.5
reviewcount: 10
recipeingredient:
- "250 gr ayam"
- "100 ml santan karaair 2 sdm fiber creme"
- "100 ml air"
- "1/4 sdt bubuk kari"
- "Secukupnya Garam gula dan kaldu bubuk"
- " Bumbu cemplung"
- "2 lembar daun salam"
- "2 lbr daun jeruk"
- "1 batang serai memarkan"
- "1/2 ruas lengkuas memarkan"
- "1-2 buah kapulaga"
- "2 cm kayumanis"
- "1 buah bunga pekak"
- " Bumbu Halus"
- "4 siung bawang merah"
- "1 siung bwg putih"
- "1-2 buah cabai"
- "1 cm jahe"
- "1-2 buah kemiri"
- "1/4 sdt kunyit bubuk"
- "1/4 sdt ketumbar"
- "1/4 sdt jinten"
recipeinstructions:
- "Tumis bumbu halus sampai wangi, masukkan bumbu cemplung, aduk sebentar sampai harum dan matang."
- "Masukkan ayam dan air, tambahkan bumbu kari, masak sampai ayam setengah empuk."
- "Masukkan santan, tambahkan garam, gula dan kaldu bubuk. Koreksi rasa.  Masak sampai ayam empuk.  Matikan api."
- "Angkat, sajikan"
categories:
- Resep
tags:
- kari
- ayam

katakunci: kari ayam 
nutrition: 255 calories
recipecuisine: Indonesian
preptime: "PT32M"
cooktime: "PT48M"
recipeyield: "1"
recipecategory: Lunch

---


![Kari Ayam](https://img-global.cpcdn.com/recipes/104e6b71a89f06f6/680x482cq70/kari-ayam-foto-resep-utama.jpg)

Andai kamu seorang orang tua, menyuguhkan panganan lezat bagi famili adalah hal yang membahagiakan untuk anda sendiri. Tanggung jawab seorang istri Tidak saja mengurus rumah saja, tetapi anda pun harus memastikan keperluan nutrisi tercukupi dan hidangan yang dimakan orang tercinta harus enak.

Di masa  saat ini, kita sebenarnya bisa membeli masakan instan walaupun tidak harus susah mengolahnya dahulu. Tapi banyak juga lho orang yang memang ingin menghidangkan yang terbaik bagi orang tercintanya. Karena, memasak sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan masakan tersebut sesuai masakan kesukaan keluarga tercinta. 



Apakah anda salah satu penikmat kari ayam?. Tahukah kamu, kari ayam adalah sajian khas di Nusantara yang sekarang disenangi oleh orang-orang di berbagai tempat di Indonesia. Anda dapat menyajikan kari ayam buatan sendiri di rumahmu dan dapat dijadikan camilan favoritmu di hari liburmu.

Kalian tidak perlu bingung jika kamu ingin mendapatkan kari ayam, sebab kari ayam tidak sukar untuk didapatkan dan kamu pun dapat memasaknya sendiri di rumah. kari ayam boleh diolah memalui beraneka cara. Saat ini telah banyak sekali resep modern yang menjadikan kari ayam semakin enak.

Resep kari ayam juga sangat gampang untuk dibuat, lho. Kamu tidak perlu ribet-ribet untuk membeli kari ayam, sebab Kita mampu menyiapkan ditempatmu. Bagi Kalian yang mau menyajikannya, di bawah ini adalah resep menyajikan kari ayam yang lezat yang bisa Kalian coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Kari Ayam:

1. Ambil 250 gr ayam
1. Sediakan 100 ml santan (kara+air)/ 2 sdm fiber creme
1. Ambil 100 ml air
1. Gunakan 1/4 sdt bubuk kari
1. Siapkan Secukupnya Garam, gula dan kaldu bubuk
1. Siapkan  Bumbu cemplung:
1. Sediakan 2 lembar daun salam
1. Siapkan 2 lbr daun jeruk
1. Ambil 1 batang serai (memarkan)
1. Siapkan 1/2 ruas lengkuas (memarkan)
1. Siapkan 1-2 buah kapulaga
1. Siapkan 2 cm kayumanis
1. Sediakan 1 buah bunga pekak
1. Siapkan  Bumbu Halus:
1. Gunakan 4 siung bawang merah
1. Ambil 1 siung bwg putih
1. Sediakan 1-2 buah cabai
1. Gunakan 1 cm jahe
1. Sediakan 1-2 buah kemiri
1. Gunakan 1/4 sdt kunyit bubuk
1. Sediakan 1/4 sdt ketumbar
1. Siapkan 1/4 sdt jinten




<!--inarticleads2-->

##### Cara membuat Kari Ayam:

1. Tumis bumbu halus sampai wangi, masukkan bumbu cemplung, aduk sebentar sampai harum dan matang.
1. Masukkan ayam dan air, tambahkan bumbu kari, masak sampai ayam setengah empuk.
1. Masukkan santan, tambahkan garam, gula dan kaldu bubuk. Koreksi rasa.  - Masak sampai ayam empuk.  - Matikan api.
1. Angkat, sajikan




Ternyata resep kari ayam yang mantab sederhana ini gampang sekali ya! Kalian semua dapat membuatnya. Cara Membuat kari ayam Sangat cocok sekali buat kamu yang baru belajar memasak maupun juga bagi anda yang sudah pandai memasak.

Apakah kamu ingin mencoba buat resep kari ayam enak sederhana ini? Kalau kalian tertarik, mending kamu segera siapin alat dan bahannya, lantas bikin deh Resep kari ayam yang nikmat dan sederhana ini. Benar-benar mudah kan. 

Jadi, daripada kamu berlama-lama, yuk langsung aja hidangkan resep kari ayam ini. Dijamin kamu gak akan menyesal bikin resep kari ayam nikmat tidak ribet ini! Selamat berkreasi dengan resep kari ayam enak tidak rumit ini di tempat tinggal kalian masing-masing,ya!.

