---
description: "Resep *Steak Ayam* yang lezat dan Mudah Dibuat"
title: "Resep *Steak Ayam* yang lezat dan Mudah Dibuat"
slug: 263-resep-steak-ayam-yang-lezat-dan-mudah-dibuat
date: 2021-02-14T12:10:23.976Z
image: https://img-global.cpcdn.com/recipes/c7ed37061e882c7d/680x482cq70/steak-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c7ed37061e882c7d/680x482cq70/steak-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c7ed37061e882c7d/680x482cq70/steak-ayam-foto-resep-utama.jpg
author: Sean Palmer
ratingvalue: 3.5
reviewcount: 5
recipeingredient:
- "250 gr dada ayam fillet"
- "10 gr margarine  1 sdm"
- "  1 sachet saus tiram"
- "1 sdm kecap inggris sy saus teriyaki"
- "1 sdt royco ayam"
- "1 sdt lada bubuk"
- "1 sdt garam"
- "2 sdm tpg maizena cairkan"
- "1 gelas air"
- "1/2 sdm gula pasir"
- "2 sdm kecap manis"
- "1/2 butir bawang bombay"
- "4 siung bawang putih"
- " Pelengkap "
- "2 buah Kentang goreng"
- "1 bonggol brokoli rebus"
- "1 buah wortel rebus"
recipeinstructions:
- "Cuci bersih ayam lalu potong tipis jadi 2 bagian dan kerat2 agar bumbunya lebih mudah meresap. Haluskan 2 siung bawang putih dengan 1/2 sdt garam lalu balurkan pada daging ayam"
- "Kemudian beri 1/2 saschet saus tiram, 1/2 bgks royco, 1/2 sdt lada bubuk, aduk merata pada daging ayam dan biarkan hingga bumbu meresap. Iris bawang bombay dan bawang putih, keprek lalu cincang"
- "Tumis bawang putih dan bawang bombay hingga harum lalu masukkan sisa saus tiram, saus teriyaki, kaldu bubuk, kecap manis, gula pasir lalu beri air"
- "Aduk rata, biarkan mendidih lalu tuangkan larutan maizena, aduk-aduk.hingga mengental. Cek rasa, didihkan, angkat, sisihkan"
- "Panaskan teflon, beri margarine dan ratakan lalu panggang ayam berbumbu bolak-balik hingga benar-benar matang, angkat sisihkan."
- "Didihkan air secukupnya bersama sedikit garam untuk merebus wortel dan brokoli dan goreng kentang"
- "Siapkan semua bahan lalu tata dalam piring saji."
categories:
- Resep
tags:
- steak
- ayam

katakunci: steak ayam 
nutrition: 124 calories
recipecuisine: Indonesian
preptime: "PT39M"
cooktime: "PT52M"
recipeyield: "4"
recipecategory: Lunch

---


![*Steak Ayam*](https://img-global.cpcdn.com/recipes/c7ed37061e882c7d/680x482cq70/steak-ayam-foto-resep-utama.jpg)

Selaku seorang wanita, menyediakan panganan enak pada keluarga merupakan hal yang menggembirakan bagi anda sendiri. Tugas seorang  wanita bukan hanya mengurus rumah saja, namun kamu juga harus memastikan kebutuhan gizi tercukupi dan juga panganan yang dimakan orang tercinta wajib nikmat.

Di waktu  saat ini, kalian sebenarnya dapat mengorder santapan praktis walaupun tidak harus susah memasaknya dahulu. Tapi ada juga orang yang memang mau memberikan makanan yang terbaik bagi orang tercintanya. Lantaran, menghidangkan masakan sendiri jauh lebih higienis dan kita pun bisa menyesuaikan masakan tersebut berdasarkan masakan kesukaan orang tercinta. 



Mungkinkah anda seorang penikmat *steak ayam*?. Asal kamu tahu, *steak ayam* merupakan makanan khas di Indonesia yang kini disukai oleh orang-orang di berbagai daerah di Indonesia. Kamu bisa memasak *steak ayam* hasil sendiri di rumahmu dan dapat dijadikan santapan favoritmu di akhir pekanmu.

Kamu tidak usah bingung jika kamu ingin mendapatkan *steak ayam*, sebab *steak ayam* gampang untuk didapatkan dan juga kamu pun bisa memasaknya sendiri di rumah. *steak ayam* boleh dibuat memalui beraneka cara. Sekarang telah banyak banget cara kekinian yang membuat *steak ayam* semakin mantap.

Resep *steak ayam* juga sangat gampang dibuat, lho. Anda tidak usah capek-capek untuk membeli *steak ayam*, lantaran Kita mampu menyajikan sendiri di rumah. Bagi Kamu yang akan mencobanya, berikut cara untuk menyajikan *steak ayam* yang lezat yang bisa Kita coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan *Steak Ayam*:

1. Sediakan 250 gr dada ayam fillet
1. Siapkan 10 gr margarine /± 1 sdm
1. Gunakan  ± 1 sachet saus tiram
1. Sediakan 1 sdm kecap inggris (sy, saus teriyaki
1. Siapkan 1 sdt royco ayam
1. Siapkan 1 sdt lada bubuk
1. Gunakan 1 sdt garam
1. Gunakan 2 sdm tpg maizena, cairkan
1. Siapkan 1 gelas air
1. Ambil 1/2 sdm gula pasir
1. Sediakan 2 sdm kecap manis
1. Ambil 1/2 butir bawang bombay
1. Gunakan 4 siung bawang putih
1. Siapkan  Pelengkap :
1. Sediakan 2 buah Kentang, goreng
1. Gunakan 1 bonggol brokoli, rebus
1. Siapkan 1 buah wortel, rebus




<!--inarticleads2-->

##### Cara menyiapkan *Steak Ayam*:

1. Cuci bersih ayam lalu potong tipis jadi 2 bagian dan kerat2 agar bumbunya lebih mudah meresap. Haluskan 2 siung bawang putih dengan 1/2 sdt garam lalu balurkan pada daging ayam
1. Kemudian beri 1/2 saschet saus tiram, 1/2 bgks royco, 1/2 sdt lada bubuk, aduk merata pada daging ayam dan biarkan hingga bumbu meresap. Iris bawang bombay dan bawang putih, keprek lalu cincang
1. Tumis bawang putih dan bawang bombay hingga harum lalu masukkan sisa saus tiram, saus teriyaki, kaldu bubuk, kecap manis, gula pasir lalu beri air
1. Aduk rata, biarkan mendidih lalu tuangkan larutan maizena, aduk-aduk.hingga mengental. Cek rasa, didihkan, angkat, sisihkan
1. Panaskan teflon, beri margarine dan ratakan lalu panggang ayam berbumbu bolak-balik hingga benar-benar matang, angkat sisihkan.
1. Didihkan air secukupnya bersama sedikit garam untuk merebus wortel dan brokoli dan goreng kentang
1. Siapkan semua bahan lalu tata dalam piring saji.




Wah ternyata cara buat *steak ayam* yang mantab tidak rumit ini gampang sekali ya! Semua orang dapat memasaknya. Cara buat *steak ayam* Cocok sekali untuk kamu yang sedang belajar memasak ataupun bagi anda yang telah jago memasak.

Apakah kamu tertarik mencoba buat resep *steak ayam* lezat tidak ribet ini? Kalau kalian mau, mending kamu segera siapin peralatan dan bahan-bahannya, maka buat deh Resep *steak ayam* yang mantab dan sederhana ini. Betul-betul mudah kan. 

Maka, ketimbang kalian berfikir lama-lama, ayo langsung aja bikin resep *steak ayam* ini. Pasti kamu tiidak akan nyesel membuat resep *steak ayam* nikmat tidak rumit ini! Selamat mencoba dengan resep *steak ayam* mantab tidak ribet ini di rumah kalian masing-masing,oke!.

