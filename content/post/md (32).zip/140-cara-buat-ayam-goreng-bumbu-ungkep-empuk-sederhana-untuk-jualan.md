---
description: "Cara buat Ayam Goreng Bumbu ungkep empuk Sederhana Untuk Jualan"
title: "Cara buat Ayam Goreng Bumbu ungkep empuk Sederhana Untuk Jualan"
slug: 140-cara-buat-ayam-goreng-bumbu-ungkep-empuk-sederhana-untuk-jualan
date: 2021-02-23T22:28:13.362Z
image: https://img-global.cpcdn.com/recipes/987e68688319f902/680x482cq70/ayam-goreng-bumbu-ungkep-empuk-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/987e68688319f902/680x482cq70/ayam-goreng-bumbu-ungkep-empuk-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/987e68688319f902/680x482cq70/ayam-goreng-bumbu-ungkep-empuk-foto-resep-utama.jpg
author: Charles Green
ratingvalue: 3.5
reviewcount: 14
recipeingredient:
- "2 kilo ayam biasa"
- "1 kilo dipotong 12 potong"
- "2 buah jeruk nipis"
- "4 batang sereh geprek"
- "4 lembar daun salam"
- "6 lembar daun jeruk"
- "Secukupnya garam"
- "Secukupnya penyedap rasa ayam  kaldu Jamur"
- "300 ml air"
- " Bumbu halus "
- "20 siung bawang merah"
- "10 siung bawang putih"
- "1 jempol jahe"
- "1 jempol kunyit"
- "1 jmpol lengkuas"
- "2 sdm ketumbar bubuk"
- "1 sdm ladabubuk"
recipeinstructions:
- "Cuci bersih ayam,Marinasi dngan jeruk nipis diamkan 15 mnt,lalu Cuci bersih ayam tiriskan"
- "Haluskan bumbu lalu balurkan bumbu halus ke potongan ayam. Tambahkan sereh, daun salam, daun jeruk, garam dan penyedap rasa ayam. Aduk rata. Lalu beri air."
- "Masak atau ungkep ayam dengan api kecil sampai ayam matang. Jangan lupa ditutup agar matang sempurna. Angkat."
- ""
- "Goreng ayam sampai berwarna coklat keemasan."
- "Sajikan dengan nasi panas Dan sambal goreng nikmat alhamdulillh 😍🥰❤️💋"
categories:
- Resep
tags:
- ayam
- goreng
- bumbu

katakunci: ayam goreng bumbu 
nutrition: 164 calories
recipecuisine: Indonesian
preptime: "PT35M"
cooktime: "PT38M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam Goreng Bumbu ungkep empuk](https://img-global.cpcdn.com/recipes/987e68688319f902/680x482cq70/ayam-goreng-bumbu-ungkep-empuk-foto-resep-utama.jpg)

Selaku seorang istri, menyajikan masakan mantab pada keluarga tercinta adalah hal yang mengasyikan bagi kita sendiri. Kewajiban seorang ibu bukan cuma mengurus rumah saja, tetapi kamu juga wajib menyediakan kebutuhan nutrisi tercukupi dan panganan yang dimakan orang tercinta mesti enak.

Di masa  saat ini, kamu sebenarnya dapat membeli hidangan instan meski tidak harus capek memasaknya lebih dulu. Tetapi ada juga lho orang yang memang mau memberikan hidangan yang terlezat untuk orang yang dicintainya. Lantaran, memasak yang dibuat sendiri akan jauh lebih bersih dan bisa menyesuaikan makanan tersebut berdasarkan masakan kesukaan keluarga. 



Apakah anda merupakan salah satu penyuka ayam goreng bumbu ungkep empuk?. Asal kamu tahu, ayam goreng bumbu ungkep empuk merupakan hidangan khas di Indonesia yang sekarang disukai oleh kebanyakan orang di berbagai tempat di Indonesia. Kita dapat memasak ayam goreng bumbu ungkep empuk sendiri di rumahmu dan boleh dijadikan camilan favoritmu di hari liburmu.

Kalian tak perlu bingung untuk menyantap ayam goreng bumbu ungkep empuk, lantaran ayam goreng bumbu ungkep empuk mudah untuk didapatkan dan kita pun boleh menghidangkannya sendiri di tempatmu. ayam goreng bumbu ungkep empuk boleh dibuat memalui berbagai cara. Saat ini telah banyak banget resep kekinian yang menjadikan ayam goreng bumbu ungkep empuk lebih mantap.

Resep ayam goreng bumbu ungkep empuk juga gampang sekali untuk dibikin, lho. Anda tidak usah repot-repot untuk memesan ayam goreng bumbu ungkep empuk, tetapi Anda dapat membuatnya ditempatmu. Untuk Anda yang hendak menyajikannya, berikut ini resep untuk membuat ayam goreng bumbu ungkep empuk yang mantab yang dapat Anda hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Ayam Goreng Bumbu ungkep empuk:

1. Sediakan 2 kilo ayam biasa
1. Siapkan 1 kilo dipotong 12 potong
1. Ambil 2 buah jeruk nipis
1. Gunakan 4 batang sereh, geprek
1. Siapkan 4 lembar daun salam
1. Sediakan 6 lembar daun jeruk
1. Siapkan Secukupnya garam
1. Siapkan Secukupnya penyedap rasa ayam / kaldu Jamur
1. Ambil 300 ml air
1. Ambil  Bumbu halus :
1. Siapkan 20 siung bawang merah
1. Siapkan 10 siung bawang putih
1. Gunakan 1 jempol jahe
1. Gunakan 1 jempol kunyit
1. Siapkan 1 jmpol lengkuas
1. Siapkan 2 sdm ketumbar bubuk
1. Gunakan 1 sdm ladabubuk




<!--inarticleads2-->

##### Cara menyiapkan Ayam Goreng Bumbu ungkep empuk:

1. Cuci bersih ayam,Marinasi dngan jeruk nipis diamkan 15 mnt,lalu Cuci bersih ayam tiriskan
1. Haluskan bumbu lalu balurkan bumbu halus ke potongan ayam. Tambahkan sereh, daun salam, daun jeruk, garam dan penyedap rasa ayam. Aduk rata. Lalu beri air.
1. Masak atau ungkep ayam dengan api kecil sampai ayam matang. Jangan lupa ditutup agar matang sempurna. Angkat.
1. 
1. Goreng ayam sampai berwarna coklat keemasan.
1. Sajikan dengan nasi panas Dan sambal goreng nikmat alhamdulillh 😍🥰❤️💋




Ternyata cara buat ayam goreng bumbu ungkep empuk yang mantab tidak ribet ini enteng sekali ya! Anda Semua mampu memasaknya. Cara Membuat ayam goreng bumbu ungkep empuk Sangat cocok banget untuk kalian yang baru belajar memasak maupun juga untuk kalian yang sudah lihai memasak.

Tertarik untuk mulai mencoba membikin resep ayam goreng bumbu ungkep empuk lezat sederhana ini? Kalau anda ingin, ayo kalian segera menyiapkan alat dan bahan-bahannya, setelah itu bikin deh Resep ayam goreng bumbu ungkep empuk yang mantab dan tidak rumit ini. Betul-betul taidak sulit kan. 

Jadi, ketimbang kita diam saja, yuk kita langsung hidangkan resep ayam goreng bumbu ungkep empuk ini. Dijamin kamu tak akan nyesel sudah buat resep ayam goreng bumbu ungkep empuk lezat tidak ribet ini! Selamat berkreasi dengan resep ayam goreng bumbu ungkep empuk mantab tidak rumit ini di rumah kalian masing-masing,oke!.

