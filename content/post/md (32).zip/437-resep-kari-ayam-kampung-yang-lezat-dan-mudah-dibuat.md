---
description: "Resep Kari Ayam kampung yang lezat dan Mudah Dibuat"
title: "Resep Kari Ayam kampung yang lezat dan Mudah Dibuat"
slug: 437-resep-kari-ayam-kampung-yang-lezat-dan-mudah-dibuat
date: 2021-06-10T06:21:37.992Z
image: https://img-global.cpcdn.com/recipes/ab907527636e5223/680x482cq70/kari-ayam-kampung-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ab907527636e5223/680x482cq70/kari-ayam-kampung-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ab907527636e5223/680x482cq70/kari-ayam-kampung-foto-resep-utama.jpg
author: Susie Vaughn
ratingvalue: 4.3
reviewcount: 5
recipeingredient:
- "1 ekor ayam kampung lumuri lemon lalu bilas"
- "3 buah kentang potong kotak goreng"
- "5 butir telur rebus dan kupas"
- "1 liter Air"
- "2 Santan kara kemasan 65 ml"
- "1 sdm garam atau sesuai selera"
- "1 sdm gula"
- "1 sdm penyedap rasa atau sesuai selera"
- "1 sdt lada bubuk atau secukupnya"
- "5 daun jeruk"
- "3 serai geprek"
- "1 ruas lengkuas gerpek"
- " Bawang goreng untuk taburan"
- " Bumbu halus"
- "15 siung bawang merah"
- "8 siung bawang putih"
- "4 buah cabe merah besar"
- "1 ruas jahe"
- "1 ruas kunyit"
- "1 sdt jintan"
- "1 sdt ketumbar butir"
recipeinstructions:
- "Blender bumbu halus lalu tumis bersama daun jeruk, sereh geprek dan lengkuas geprek. Tumis hingga matang dan bau langu hilang"
- "Masukkan air dan ayam. Tutup wajan dan masak hingga ayam mulai lunak"
- "Tambahkan 2 bungkus santan, aduk rata. Kecil kan api. Masak hingga mendidih."
- "Saat sudah akan matang, masukkan kentang dan telur rebus."
- "Tambahkan garam, gula dan penyedap. Tes rasa."
- "Angkat kari ayam, berikan taburan bawang goreng. Bisa dimakan dengan nasi atau roti canai 🤗"
categories:
- Resep
tags:
- kari
- ayam
- kampung

katakunci: kari ayam kampung 
nutrition: 142 calories
recipecuisine: Indonesian
preptime: "PT28M"
cooktime: "PT57M"
recipeyield: "4"
recipecategory: Dessert

---


![Kari Ayam kampung](https://img-global.cpcdn.com/recipes/ab907527636e5223/680x482cq70/kari-ayam-kampung-foto-resep-utama.jpg)

Sebagai seorang orang tua, mempersiapkan panganan menggugah selera buat orang tercinta adalah suatu hal yang menggembirakan bagi anda sendiri. Tugas seorang istri bukan saja mengerjakan pekerjaan rumah saja, namun anda juga harus memastikan keperluan nutrisi tercukupi dan panganan yang dikonsumsi keluarga tercinta harus enak.

Di waktu  sekarang, anda sebenarnya bisa mengorder masakan jadi meski tanpa harus capek memasaknya terlebih dahulu. Tetapi ada juga mereka yang memang mau memberikan yang terenak bagi orang yang dicintainya. Sebab, menyajikan masakan yang diolah sendiri jauh lebih bersih dan kita juga bisa menyesuaikan masakan tersebut sesuai dengan makanan kesukaan famili. 



Mungkinkah kamu seorang penikmat kari ayam kampung?. Asal kamu tahu, kari ayam kampung merupakan hidangan khas di Indonesia yang kini digemari oleh orang-orang di hampir setiap daerah di Indonesia. Kalian dapat memasak kari ayam kampung buatan sendiri di rumah dan boleh dijadikan santapan kegemaranmu di akhir pekan.

Kita jangan bingung untuk menyantap kari ayam kampung, lantaran kari ayam kampung tidak sukar untuk dicari dan kalian pun dapat memasaknya sendiri di tempatmu. kari ayam kampung bisa dimasak memalui beraneka cara. Kini ada banyak banget resep kekinian yang menjadikan kari ayam kampung lebih lezat.

Resep kari ayam kampung pun gampang untuk dibuat, lho. Kalian jangan capek-capek untuk membeli kari ayam kampung, karena Anda dapat menyajikan sendiri di rumah. Untuk Kamu yang ingin mencobanya, dibawah ini merupakan cara menyajikan kari ayam kampung yang mantab yang dapat Kalian buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Kari Ayam kampung:

1. Ambil 1 ekor ayam kampung, lumuri lemon, lalu bilas
1. Ambil 3 buah kentang, potong kotak, goreng
1. Sediakan 5 butir telur, rebus dan kupas
1. Siapkan 1 liter Air
1. Gunakan 2 Santan kara kemasan 65 ml
1. Ambil 1 sdm garam atau sesuai selera
1. Ambil 1 sdm gula
1. Siapkan 1 sdm penyedap rasa atau sesuai selera
1. Gunakan 1 sdt lada bubuk atau secukupnya
1. Siapkan 5 daun jeruk
1. Sediakan 3 serai geprek
1. Sediakan 1 ruas lengkuas gerpek
1. Ambil  Bawang goreng untuk taburan
1. Siapkan  Bumbu halus
1. Ambil 15 siung bawang merah
1. Sediakan 8 siung bawang putih
1. Siapkan 4 buah cabe merah besar
1. Sediakan 1 ruas jahe
1. Gunakan 1 ruas kunyit
1. Sediakan 1 sdt jintan
1. Siapkan 1 sdt ketumbar butir




<!--inarticleads2-->

##### Langkah-langkah membuat Kari Ayam kampung:

1. Blender bumbu halus lalu tumis bersama daun jeruk, sereh geprek dan lengkuas geprek. Tumis hingga matang dan bau langu hilang
1. Masukkan air dan ayam. Tutup wajan dan masak hingga ayam mulai lunak
1. Tambahkan 2 bungkus santan, aduk rata. Kecil kan api. Masak hingga mendidih.
1. Saat sudah akan matang, masukkan kentang dan telur rebus.
1. Tambahkan garam, gula dan penyedap. Tes rasa.
1. Angkat kari ayam, berikan taburan bawang goreng. Bisa dimakan dengan nasi atau roti canai 🤗




Ternyata resep kari ayam kampung yang enak tidak rumit ini gampang banget ya! Kita semua bisa menghidangkannya. Resep kari ayam kampung Sangat sesuai banget untuk kita yang baru mau belajar memasak maupun bagi kalian yang telah ahli dalam memasak.

Apakah kamu ingin mulai mencoba bikin resep kari ayam kampung lezat simple ini? Kalau anda mau, yuk kita segera buruan siapkan alat dan bahannya, lalu bikin deh Resep kari ayam kampung yang mantab dan sederhana ini. Sungguh taidak sulit kan. 

Oleh karena itu, ketimbang kita diam saja, ayo langsung aja sajikan resep kari ayam kampung ini. Dijamin kamu gak akan nyesel sudah buat resep kari ayam kampung lezat tidak ribet ini! Selamat berkreasi dengan resep kari ayam kampung enak simple ini di rumah kalian masing-masing,ya!.

