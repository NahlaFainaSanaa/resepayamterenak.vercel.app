---
description: "Bahan-bahan Ayam Tangkap Khas Aceh yang nikmat dan Mudah Dibuat"
title: "Bahan-bahan Ayam Tangkap Khas Aceh yang nikmat dan Mudah Dibuat"
slug: 481-bahan-bahan-ayam-tangkap-khas-aceh-yang-nikmat-dan-mudah-dibuat
date: 2021-04-23T22:39:59.744Z
image: https://img-global.cpcdn.com/recipes/f29ad02fbc0b21e8/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f29ad02fbc0b21e8/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f29ad02fbc0b21e8/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg
author: Lucille Pope
ratingvalue: 3.4
reviewcount: 8
recipeingredient:
- "1 ekor ayam pejantan"
- "500 ml air kelapa"
- "1 tangkai daun kari"
- "1 daun pandan simpulkan"
- "1 ruas lengkuas"
- "2 sdt garam"
- " BUMBU HALUS "
- "1 sdm ketumbar"
- "1 ruas kunyit"
- "3 bawang putih"
- "1 sdt lada"
- " BAHAN GORENG "
- "5 cabe hijau belah"
- "1 lembar daun pandan iris"
- "2 lembar daun salam iris"
- "2 tangkai daun kari"
- "4 lembar daun jeruk sobek"
- "2 tangkai daun kari"
recipeinstructions:
- "Potong- potong ayam lalu lumuri dengan bumbu, daun pandan, lengkuas, lalu diamkan 30 menit."
- "Tuang air kelapa di wajan, tambahkan ayam, lalu garam dan ungkep sampai asat."
- "Jika sudah asat, angkat dan tiriskan."
- "Goreng ayam sampai setengah matang."
- "Masukan dedaunan lalu goreng sampai kering. Ini wangi banget loh 🥰"
- "Kalau sudah seperti ini angkat dan tiriskan yah."
- "Ayam Tangkap siap untuk disajikan."
categories:
- Resep
tags:
- ayam
- tangkap
- khas

katakunci: ayam tangkap khas 
nutrition: 249 calories
recipecuisine: Indonesian
preptime: "PT30M"
cooktime: "PT49M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Tangkap Khas Aceh](https://img-global.cpcdn.com/recipes/f29ad02fbc0b21e8/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg)

Selaku seorang istri, mempersiapkan panganan nikmat pada keluarga tercinta adalah hal yang membahagiakan bagi kita sendiri. Peran seorang  wanita Tidak cuman menangani rumah saja, tetapi anda pun harus menyediakan keperluan nutrisi tercukupi dan juga olahan yang dikonsumsi keluarga tercinta wajib lezat.

Di era  saat ini, kita sebenarnya dapat membeli santapan instan tanpa harus ribet membuatnya lebih dulu. Tetapi ada juga lho orang yang memang mau memberikan hidangan yang terbaik bagi keluarganya. Pasalnya, memasak yang dibuat sendiri jauh lebih bersih dan kita juga bisa menyesuaikan makanan tersebut berdasarkan makanan kesukaan keluarga tercinta. 



Apakah anda seorang penyuka ayam tangkap khas aceh?. Asal kamu tahu, ayam tangkap khas aceh adalah makanan khas di Nusantara yang sekarang disukai oleh orang-orang dari hampir setiap daerah di Nusantara. Kita dapat menyajikan ayam tangkap khas aceh buatan sendiri di rumah dan boleh dijadikan camilan kesukaanmu di akhir pekanmu.

Kamu tak perlu bingung jika kamu ingin menyantap ayam tangkap khas aceh, sebab ayam tangkap khas aceh sangat mudah untuk didapatkan dan juga kalian pun boleh membuatnya sendiri di rumah. ayam tangkap khas aceh boleh diolah memalui bermacam cara. Sekarang ada banyak sekali cara modern yang menjadikan ayam tangkap khas aceh lebih enak.

Resep ayam tangkap khas aceh pun gampang sekali untuk dibuat, lho. Kamu jangan capek-capek untuk memesan ayam tangkap khas aceh, tetapi Kamu dapat menyiapkan sendiri di rumah. Bagi Kalian yang akan menghidangkannya, berikut resep menyajikan ayam tangkap khas aceh yang mantab yang dapat Kita buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Ayam Tangkap Khas Aceh:

1. Siapkan 1 ekor ayam pejantan
1. Sediakan 500 ml air kelapa
1. Gunakan 1 tangkai daun kari
1. Sediakan 1 daun pandan simpulkan
1. Siapkan 1 ruas lengkuas
1. Gunakan 2 sdt garam
1. Siapkan  BUMBU HALUS :
1. Ambil 1 sdm ketumbar
1. Ambil 1 ruas kunyit
1. Siapkan 3 bawang putih
1. Siapkan 1 sdt lada
1. Sediakan  BAHAN GORENG :
1. Ambil 5 cabe hijau belah
1. Gunakan 1 lembar daun pandan iris
1. Ambil 2 lembar daun salam iris
1. Gunakan 2 tangkai daun kari
1. Ambil 4 lembar daun jeruk sobek
1. Siapkan 2 tangkai daun kari




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam Tangkap Khas Aceh:

1. Potong- potong ayam lalu lumuri dengan bumbu, daun pandan, lengkuas, lalu diamkan 30 menit.
1. Tuang air kelapa di wajan, tambahkan ayam, lalu garam dan ungkep sampai asat.
1. Jika sudah asat, angkat dan tiriskan.
1. Goreng ayam sampai setengah matang.
1. Masukan dedaunan lalu goreng sampai kering. Ini wangi banget loh 🥰
1. Kalau sudah seperti ini angkat dan tiriskan yah.
1. Ayam Tangkap siap untuk disajikan.




Ternyata cara membuat ayam tangkap khas aceh yang enak sederhana ini enteng sekali ya! Anda Semua dapat membuatnya. Cara Membuat ayam tangkap khas aceh Sesuai banget buat kamu yang baru akan belajar memasak ataupun untuk kalian yang telah jago memasak.

Tertarik untuk mulai mencoba bikin resep ayam tangkap khas aceh nikmat tidak ribet ini? Kalau anda mau, mending kamu segera buruan siapin peralatan dan bahannya, kemudian bikin deh Resep ayam tangkap khas aceh yang nikmat dan simple ini. Benar-benar mudah kan. 

Maka dari itu, daripada kalian diam saja, maka kita langsung bikin resep ayam tangkap khas aceh ini. Pasti anda gak akan nyesel sudah buat resep ayam tangkap khas aceh nikmat sederhana ini! Selamat berkreasi dengan resep ayam tangkap khas aceh nikmat sederhana ini di rumah sendiri,oke!.

