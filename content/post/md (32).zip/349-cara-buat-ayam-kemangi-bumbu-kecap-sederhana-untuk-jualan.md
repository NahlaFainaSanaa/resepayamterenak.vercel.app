---
description: "Cara buat Ayam Kemangi Bumbu Kecap Sederhana Untuk Jualan"
title: "Cara buat Ayam Kemangi Bumbu Kecap Sederhana Untuk Jualan"
slug: 349-cara-buat-ayam-kemangi-bumbu-kecap-sederhana-untuk-jualan
date: 2021-05-20T14:43:53.704Z
image: https://img-global.cpcdn.com/recipes/255cf25275cf1af9/680x482cq70/ayam-kemangi-bumbu-kecap-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/255cf25275cf1af9/680x482cq70/ayam-kemangi-bumbu-kecap-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/255cf25275cf1af9/680x482cq70/ayam-kemangi-bumbu-kecap-foto-resep-utama.jpg
author: Jorge Paul
ratingvalue: 3.5
reviewcount: 10
recipeingredient:
- "1 kg ayam"
- "1 ikat kemangi pisahkan batangnya"
- "6 siung bawang putih"
- "4 siung bawang merah"
- "1 ruas lengkuas"
- "2 buah cabe keriting atau sesuai selera jika mau pedas"
- "Secukupnya kecap manis"
- "Secukupnya garam"
- "Secukupnya gula"
- "Secukupnya merica"
- "Secukupnya penyedap"
- "Secukupnya minyak goreng"
- "Secukupnya air"
recipeinstructions:
- "Potong ayam sesuai selera. Kalau saya jadi 8 bagian. Kemudian cuci bersih."
- "Didihkah air kaldu, masukkan ayam, 2 siung bawang putih geprek, garam, merica. Masak hingga ± 20-30 menit. Kemudian tiriskan, jangan buang kaldunya."
- "Potong halus 4 siung bawang putih, 4 siung bawang merah, cabai keriting, lengkuas."
- "Panaskan minyak, goreng setengah matang ayam yang sudah di ungkep bumbu. Tiriskan."
- "Panaskan minyak untuk menumis. Masukkan bahan yang telah dipotong, tumis hingga harum."
- "Masukkan air, ayam goreng, kecap, garam, gula, dan merica. Tunggu hingga mendidih."
- "Setelah mendidih, masukkan kemangi yang telah dipotong, dan penyedap secukupnya. Masak hingga air menyusut. Tes rasa."
- "Matikan api jika air sudah menyusut. Sajikan.  Selamat mencoba."
categories:
- Resep
tags:
- ayam
- kemangi
- bumbu

katakunci: ayam kemangi bumbu 
nutrition: 172 calories
recipecuisine: Indonesian
preptime: "PT21M"
cooktime: "PT41M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam Kemangi Bumbu Kecap](https://img-global.cpcdn.com/recipes/255cf25275cf1af9/680x482cq70/ayam-kemangi-bumbu-kecap-foto-resep-utama.jpg)

Apabila kita seorang istri, mempersiapkan olahan mantab bagi orang tercinta merupakan hal yang memuaskan untuk anda sendiri. Peran seorang  wanita bukan sekadar menjaga rumah saja, tetapi kamu pun harus menyediakan keperluan gizi terpenuhi dan masakan yang dimakan anak-anak mesti nikmat.

Di era  sekarang, kamu memang bisa mengorder olahan jadi tanpa harus ribet mengolahnya terlebih dahulu. Namun ada juga lho mereka yang memang mau menghidangkan yang terenak bagi orang tercintanya. Karena, memasak yang diolah sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan masakan tersebut berdasarkan kesukaan keluarga tercinta. 



Apakah anda salah satu penyuka ayam kemangi bumbu kecap?. Asal kamu tahu, ayam kemangi bumbu kecap merupakan makanan khas di Indonesia yang sekarang digemari oleh orang-orang di berbagai tempat di Nusantara. Kamu bisa menghidangkan ayam kemangi bumbu kecap sendiri di rumahmu dan pasti jadi santapan kegemaranmu di hari liburmu.

Kalian tidak perlu bingung jika kamu ingin mendapatkan ayam kemangi bumbu kecap, sebab ayam kemangi bumbu kecap mudah untuk ditemukan dan juga kita pun dapat menghidangkannya sendiri di tempatmu. ayam kemangi bumbu kecap boleh dibuat lewat bermacam cara. Kini sudah banyak resep modern yang menjadikan ayam kemangi bumbu kecap semakin lebih enak.

Resep ayam kemangi bumbu kecap juga gampang sekali dibuat, lho. Kamu tidak usah ribet-ribet untuk memesan ayam kemangi bumbu kecap, lantaran Kamu mampu membuatnya di rumahmu. Bagi Anda yang akan mencobanya, berikut cara untuk menyajikan ayam kemangi bumbu kecap yang nikamat yang dapat Anda hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Ayam Kemangi Bumbu Kecap:

1. Gunakan 1 kg ayam
1. Ambil 1 ikat kemangi (pisahkan batangnya)
1. Ambil 6 siung bawang putih
1. Ambil 4 siung bawang merah
1. Gunakan 1 ruas lengkuas
1. Ambil 2 buah cabe keriting (atau sesuai selera jika mau pedas)
1. Siapkan Secukupnya kecap manis
1. Gunakan Secukupnya garam
1. Gunakan Secukupnya gula
1. Sediakan Secukupnya merica
1. Siapkan Secukupnya penyedap
1. Siapkan Secukupnya minyak goreng
1. Gunakan Secukupnya air




<!--inarticleads2-->

##### Cara menyiapkan Ayam Kemangi Bumbu Kecap:

1. Potong ayam sesuai selera. Kalau saya jadi 8 bagian. Kemudian cuci bersih.
1. Didihkah air kaldu, masukkan ayam, 2 siung bawang putih geprek, garam, merica. Masak hingga ± 20-30 menit. Kemudian tiriskan, jangan buang kaldunya.
1. Potong halus 4 siung bawang putih, 4 siung bawang merah, cabai keriting, lengkuas.
1. Panaskan minyak, goreng setengah matang ayam yang sudah di ungkep bumbu. Tiriskan.
1. Panaskan minyak untuk menumis. Masukkan bahan yang telah dipotong, tumis hingga harum.
1. Masukkan air, ayam goreng, kecap, garam, gula, dan merica. Tunggu hingga mendidih.
1. Setelah mendidih, masukkan kemangi yang telah dipotong, dan penyedap secukupnya. Masak hingga air menyusut. Tes rasa.
1. Matikan api jika air sudah menyusut. Sajikan. -  - Selamat mencoba.




Wah ternyata cara membuat ayam kemangi bumbu kecap yang mantab sederhana ini mudah banget ya! Semua orang mampu memasaknya. Cara buat ayam kemangi bumbu kecap Sesuai banget untuk anda yang baru akan belajar memasak maupun bagi kamu yang sudah hebat dalam memasak.

Tertarik untuk mulai mencoba bikin resep ayam kemangi bumbu kecap enak sederhana ini? Kalau kalian tertarik, ayo kalian segera buruan menyiapkan alat dan bahan-bahannya, lalu bikin deh Resep ayam kemangi bumbu kecap yang enak dan tidak rumit ini. Benar-benar mudah kan. 

Oleh karena itu, ketimbang anda berlama-lama, hayo kita langsung saja hidangkan resep ayam kemangi bumbu kecap ini. Dijamin kamu tiidak akan nyesel sudah membuat resep ayam kemangi bumbu kecap enak tidak ribet ini! Selamat mencoba dengan resep ayam kemangi bumbu kecap nikmat tidak ribet ini di rumah kalian masing-masing,ya!.

