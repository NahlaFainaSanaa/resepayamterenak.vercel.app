---
description: "Cara buat Lontong Kari Ayam yang nikmat Untuk Jualan"
title: "Cara buat Lontong Kari Ayam yang nikmat Untuk Jualan"
slug: 378-cara-buat-lontong-kari-ayam-yang-nikmat-untuk-jualan
date: 2021-01-19T02:54:52.104Z
image: https://img-global.cpcdn.com/recipes/4ef21aaa57a23b1a/680x482cq70/lontong-kari-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4ef21aaa57a23b1a/680x482cq70/lontong-kari-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4ef21aaa57a23b1a/680x482cq70/lontong-kari-ayam-foto-resep-utama.jpg
author: Roxie Torres
ratingvalue: 3.1
reviewcount: 14
recipeingredient:
- "1/2 kg ayam"
- "2 lembar daun jeruk"
- "1 batang sereh geprek"
- "1 ruas jari lengkuas geprek"
- "3 lembar daun salam"
- "2 buah kapulaga"
- "2 buah cengkeh"
- "1 buah bunga lawang"
- "600 ml santan 3 sachet kara plus air"
- "1 bungkus bubuk kari"
- "secukupnya Garam"
- "secukupnya Penyedap rasa"
- "secukupnya Air"
- " Minyak untuk menumis"
- " Bumbu Halus blender "
- "10 buah cabe keriting merah"
- "8 siung bbawang merah"
- "6 siung bawang putih"
- "3 buah kemiri"
- "1 buah kunyit"
- "1 ruas jari jahe"
- "1 sdt ketumbar"
- "1/2 sdt jinten"
- " Pelengkap "
- " Lontong"
- " Bawang goreng"
- " Sambal goreng kentang"
recipeinstructions:
- "Siapkan panci teflon berisi minyak. Panaskan. Tumis bumbu halus hingga harum. Masukkan daun salam, daun jeruk, sereh dan lengkuas. Aduk rata."
- "Masukkan santan"
- "Tambahkan secukupnya air. Lalu masukkan kapulaga, cengkeh, bunga lawang. Tambahkan garam, bubuk kari dan penyedap rasa. Lalu masukkan ayam. Masak hingga ayam matang. Tes rasa ya."
- "Siapkan mangkok saji. Potong lontong lalu siram denga kuah kari. Lontong kari siap disajikan."
categories:
- Resep
tags:
- lontong
- kari
- ayam

katakunci: lontong kari ayam 
nutrition: 256 calories
recipecuisine: Indonesian
preptime: "PT25M"
cooktime: "PT39M"
recipeyield: "1"
recipecategory: Dinner

---


![Lontong Kari Ayam](https://img-global.cpcdn.com/recipes/4ef21aaa57a23b1a/680x482cq70/lontong-kari-ayam-foto-resep-utama.jpg)

Jika kalian seorang orang tua, menyuguhkan olahan menggugah selera untuk keluarga tercinta adalah suatu hal yang mengasyikan untuk kamu sendiri. Kewajiban seorang ibu Tidak saja menjaga rumah saja, namun anda juga wajib menyediakan kebutuhan gizi terpenuhi dan panganan yang dimakan keluarga tercinta mesti enak.

Di era  saat ini, kamu memang dapat membeli panganan praktis tidak harus repot memasaknya dulu. Namun banyak juga lho orang yang selalu mau menyajikan yang terlezat bagi orang tercintanya. Lantaran, menyajikan masakan yang dibuat sendiri akan jauh lebih bersih dan bisa menyesuaikan berdasarkan makanan kesukaan famili. 



Mungkinkah kamu seorang penggemar lontong kari ayam?. Tahukah kamu, lontong kari ayam merupakan hidangan khas di Nusantara yang kini disenangi oleh setiap orang dari hampir setiap wilayah di Nusantara. Kalian dapat memasak lontong kari ayam sendiri di rumah dan boleh dijadikan makanan favorit di hari libur.

Kita jangan bingung jika kamu ingin memakan lontong kari ayam, lantaran lontong kari ayam mudah untuk dicari dan juga kamu pun dapat mengolahnya sendiri di rumah. lontong kari ayam bisa dimasak memalui bermacam cara. Kini telah banyak banget cara kekinian yang menjadikan lontong kari ayam lebih mantap.

Resep lontong kari ayam pun mudah dibikin, lho. Anda tidak usah capek-capek untuk membeli lontong kari ayam, tetapi Kalian dapat menyiapkan ditempatmu. Bagi Kamu yang ingin mencobanya, di bawah ini adalah cara membuat lontong kari ayam yang mantab yang mampu Kamu hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Lontong Kari Ayam:

1. Siapkan 1/2 kg ayam
1. Sediakan 2 lembar daun jeruk
1. Ambil 1 batang sereh geprek
1. Sediakan 1 ruas jari lengkuas geprek
1. Sediakan 3 lembar daun salam
1. Sediakan 2 buah kapulaga
1. Siapkan 2 buah cengkeh
1. Ambil 1 buah bunga lawang
1. Gunakan 600 ml santan (3 sachet kara plus air)
1. Ambil 1 bungkus bubuk kari
1. Siapkan secukupnya Garam
1. Gunakan secukupnya Penyedap rasa
1. Siapkan secukupnya Air
1. Sediakan  Minyak untuk menumis
1. Siapkan  👌Bumbu Halus blender :
1. Sediakan 10 buah cabe keriting merah
1. Sediakan 8 siung bbawang merah
1. Gunakan 6 siung bawang putih
1. Ambil 3 buah kemiri
1. Ambil 1 buah kunyit
1. Siapkan 1 ruas jari jahe
1. Sediakan 1 sdt ketumbar
1. Gunakan 1/2 sdt jinten
1. Ambil  👌Pelengkap :
1. Siapkan  Lontong
1. Gunakan  Bawang goreng
1. Siapkan  Sambal goreng kentang




<!--inarticleads2-->

##### Cara membuat Lontong Kari Ayam:

1. Siapkan panci teflon berisi minyak. Panaskan. Tumis bumbu halus hingga harum. Masukkan daun salam, daun jeruk, sereh dan lengkuas. Aduk rata.
1. Masukkan santan
1. Tambahkan secukupnya air. Lalu masukkan kapulaga, cengkeh, bunga lawang. Tambahkan garam, bubuk kari dan penyedap rasa. Lalu masukkan ayam. Masak hingga ayam matang. Tes rasa ya.
1. Siapkan mangkok saji. Potong lontong lalu siram denga kuah kari. Lontong kari siap disajikan.




Ternyata cara buat lontong kari ayam yang nikamt simple ini mudah sekali ya! Kalian semua mampu menghidangkannya. Resep lontong kari ayam Sangat sesuai banget untuk anda yang sedang belajar memasak atau juga bagi anda yang telah hebat dalam memasak.

Tertarik untuk mulai mencoba membikin resep lontong kari ayam nikmat sederhana ini? Kalau anda ingin, yuk kita segera buruan siapin alat-alat dan bahan-bahannya, maka buat deh Resep lontong kari ayam yang enak dan simple ini. Sungguh mudah kan. 

Maka dari itu, daripada kalian berfikir lama-lama, ayo kita langsung saja bikin resep lontong kari ayam ini. Dijamin kalian gak akan nyesel membuat resep lontong kari ayam mantab tidak ribet ini! Selamat mencoba dengan resep lontong kari ayam nikmat sederhana ini di rumah kalian sendiri,oke!.

