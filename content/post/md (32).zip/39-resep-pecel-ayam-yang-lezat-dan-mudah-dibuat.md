---
description: "Resep Pecel Ayam yang lezat dan Mudah Dibuat"
title: "Resep Pecel Ayam yang lezat dan Mudah Dibuat"
slug: 39-resep-pecel-ayam-yang-lezat-dan-mudah-dibuat
date: 2021-04-13T07:14:03.408Z
image: https://img-global.cpcdn.com/recipes/d6120096d24a4cd0/680x482cq70/pecel-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d6120096d24a4cd0/680x482cq70/pecel-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d6120096d24a4cd0/680x482cq70/pecel-ayam-foto-resep-utama.jpg
author: Jack Taylor
ratingvalue: 3.5
reviewcount: 5
recipeingredient:
- "1 ekor ayam bersihkan lumuri garam dan jeruk nipis"
- "1 btg Serai geprek"
- "3 lbr daun salam"
- "3 lbr daun jeruk"
- "1 gelas air"
- " Bumbu ungkep "
- "6 siung bawang merah"
- "5 siung bawang putih  1 sdm"
- "1 ruas kunyit 1 sdt"
- "1 ruas lengkuas 1 sdt"
- "1 ruas jahe  1 sdt"
- "1 sdm ketumbar halus"
- "secukupnya Garam merica gula"
recipeinstructions:
- "Lumuri ayam dengan bumbu ungkep, diamkan 15 menit"
- "Tumis serai, daun salam, daun jeruk hingga Wangi, lalu masukkan ayam yg telah dibumbui tadi. Lalu tambahkan air aduk rata. Tutup masak dgn api sedang saja dan biarkan hingga air menyusut. Matikan api"
- "Ayam siap untuk digoreng dalam minyak panas. Sajikan bersama sambal terasi dan sayuran."
categories:
- Resep
tags:
- pecel
- ayam

katakunci: pecel ayam 
nutrition: 250 calories
recipecuisine: Indonesian
preptime: "PT35M"
cooktime: "PT45M"
recipeyield: "1"
recipecategory: Lunch

---


![Pecel Ayam](https://img-global.cpcdn.com/recipes/d6120096d24a4cd0/680x482cq70/pecel-ayam-foto-resep-utama.jpg)

Jika kalian seorang yang hobi memasak, menyuguhkan santapan enak bagi keluarga tercinta adalah hal yang sangat menyenangkan bagi kita sendiri. Peran seorang ibu bukan saja mengerjakan pekerjaan rumah saja, namun anda pun harus memastikan keperluan gizi tercukupi dan panganan yang dimakan anak-anak wajib nikmat.

Di zaman  sekarang, kamu memang bisa mengorder hidangan praktis walaupun tidak harus capek membuatnya terlebih dahulu. Tetapi ada juga lho orang yang memang mau memberikan yang terbaik bagi orang tercintanya. Sebab, memasak sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan masakan tersebut berdasarkan kesukaan keluarga. 



Mungkinkah kamu seorang penggemar pecel ayam?. Tahukah kamu, pecel ayam merupakan hidangan khas di Nusantara yang sekarang disenangi oleh kebanyakan orang dari hampir setiap daerah di Nusantara. Kalian bisa menyajikan pecel ayam sendiri di rumah dan boleh dijadikan santapan kesukaanmu di hari liburmu.

Anda tak perlu bingung untuk mendapatkan pecel ayam, sebab pecel ayam sangat mudah untuk didapatkan dan kamu pun dapat memasaknya sendiri di rumah. pecel ayam boleh dibuat dengan beraneka cara. Kini pun telah banyak sekali resep kekinian yang menjadikan pecel ayam semakin enak.

Resep pecel ayam pun mudah untuk dibuat, lho. Kamu jangan ribet-ribet untuk memesan pecel ayam, lantaran Anda bisa membuatnya ditempatmu. Untuk Kamu yang akan menyajikannya, berikut cara untuk membuat pecel ayam yang enak yang bisa Kalian hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Pecel Ayam:

1. Gunakan 1 ekor ayam, bersihkan lumuri garam dan jeruk nipis
1. Gunakan 1 btg Serai geprek
1. Sediakan 3 lbr daun salam
1. Ambil 3 lbr daun jeruk
1. Sediakan 1 gelas air
1. Sediakan  Bumbu ungkep :
1. Sediakan 6 siung bawang merah
1. Gunakan 5 siung bawang putih / 1 sdm
1. Sediakan 1 ruas kunyit /1 sdt
1. Ambil 1 ruas lengkuas/ 1 sdt
1. Sediakan 1 ruas jahe / 1 sdt
1. Siapkan 1 sdm ketumbar halus
1. Sediakan secukupnya Garam, merica, gula




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Pecel Ayam:

1. Lumuri ayam dengan bumbu ungkep, diamkan 15 menit
<img src="https://img-global.cpcdn.com/steps/40b438a63d6a653d/160x128cq70/pecel-ayam-langkah-memasak-1-foto.jpg" alt="Pecel Ayam">1. Tumis serai, daun salam, daun jeruk hingga Wangi, lalu masukkan ayam yg telah dibumbui tadi. Lalu tambahkan air aduk rata. Tutup masak dgn api sedang saja dan biarkan hingga air menyusut. Matikan api
<img src="https://img-global.cpcdn.com/steps/203752b9fbbf33c2/160x128cq70/pecel-ayam-langkah-memasak-2-foto.jpg" alt="Pecel Ayam"><img src="https://img-global.cpcdn.com/steps/e9dbd3c56ff8884c/160x128cq70/pecel-ayam-langkah-memasak-2-foto.jpg" alt="Pecel Ayam">1. Ayam siap untuk digoreng dalam minyak panas. Sajikan bersama sambal terasi dan sayuran.




Wah ternyata cara membuat pecel ayam yang mantab sederhana ini mudah sekali ya! Kita semua bisa membuatnya. Resep pecel ayam Sesuai banget buat kamu yang baru mau belajar memasak atau juga untuk kalian yang sudah jago dalam memasak.

Apakah kamu ingin mulai mencoba membikin resep pecel ayam nikmat tidak ribet ini? Kalau anda tertarik, ayo kamu segera buruan siapkan alat dan bahannya, lantas buat deh Resep pecel ayam yang mantab dan tidak rumit ini. Benar-benar mudah kan. 

Maka, daripada kalian berlama-lama, yuk kita langsung hidangkan resep pecel ayam ini. Dijamin kamu gak akan nyesel sudah bikin resep pecel ayam lezat simple ini! Selamat berkreasi dengan resep pecel ayam nikmat tidak rumit ini di rumah sendiri,oke!.

