---
description: "Cara membuat Ayam Kemangi Bumbu Kuning Sederhana dan Mudah Dibuat"
title: "Cara membuat Ayam Kemangi Bumbu Kuning Sederhana dan Mudah Dibuat"
slug: 353-cara-membuat-ayam-kemangi-bumbu-kuning-sederhana-dan-mudah-dibuat
date: 2021-03-12T01:34:37.089Z
image: https://img-global.cpcdn.com/recipes/0a4cd6e81ce37f43/680x482cq70/ayam-kemangi-bumbu-kuning-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0a4cd6e81ce37f43/680x482cq70/ayam-kemangi-bumbu-kuning-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0a4cd6e81ce37f43/680x482cq70/ayam-kemangi-bumbu-kuning-foto-resep-utama.jpg
author: Marian Page
ratingvalue: 3.2
reviewcount: 3
recipeingredient:
- "1 ekor ayam kampung atau 2 ekor ayam TG"
- " Garam"
- " Gula"
- " Penyedap rasa"
- "3 ikat Kemangi"
- " Minyak"
- " Air"
- "8 buah cabai rawit domba"
- " Bumbu halus "
- "6 siung bawang putih"
- "10 siung bawang merah"
- "5 buah cabai rawit domba kalau suka pedas bisa ditambah"
- "3 buah cabai merah"
- "3 ruas kunyit"
- "3 butir kemiri"
recipeinstructions:
- "Goreng ayam sampai setengah matang, lalu tiriskan"
- "Haluskan bahan-bahan untuk bumbu halus : cabai rawit, cabai merah, bawang putih, bawang merah, kemiri, kunyit"
- "Panaskan minyak, lalu tumis bumbu halus sampai berubah warna dan matang. Agar tidak langu"
- "Masukkan ayam yang sudah setengah matang, lalu tambahkan air secukupnya (kurang lebih 800ml)"
- "Tambahkan garam, gula, penyedap rasa. Harus dicicip ya Bund, biar sesuai dengan selera."
- "Masak ayam dan biarkan 10-15 menit dengan api sedang dan tutup panci"
- "Siapkan kemangi yang sudah dipetik, dan cabai rawit domba yang sudah dibuang tangkainya"
- "Setelah bumbu cukup meresap dan ayam matang, masukkan kemangi dan cabai rawit domba. Aduk sebentar lalu matikan api."
categories:
- Resep
tags:
- ayam
- kemangi
- bumbu

katakunci: ayam kemangi bumbu 
nutrition: 205 calories
recipecuisine: Indonesian
preptime: "PT31M"
cooktime: "PT31M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Kemangi Bumbu Kuning](https://img-global.cpcdn.com/recipes/0a4cd6e81ce37f43/680x482cq70/ayam-kemangi-bumbu-kuning-foto-resep-utama.jpg)

Sebagai seorang wanita, menyediakan olahan enak untuk keluarga merupakan hal yang mengasyikan bagi anda sendiri. Peran seorang ibu Tidak sekedar menjaga rumah saja, tetapi kamu juga wajib memastikan keperluan nutrisi terpenuhi dan juga olahan yang dimakan anak-anak harus nikmat.

Di waktu  saat ini, anda sebenarnya bisa membeli olahan praktis walaupun tanpa harus susah membuatnya dulu. Tetapi banyak juga lho mereka yang memang ingin memberikan makanan yang terlezat bagi orang yang dicintainya. Pasalnya, memasak yang dibuat sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan makanan tersebut sesuai dengan kesukaan keluarga tercinta. 



Mungkinkah anda merupakan salah satu penggemar ayam kemangi bumbu kuning?. Asal kamu tahu, ayam kemangi bumbu kuning merupakan makanan khas di Indonesia yang saat ini disukai oleh setiap orang dari berbagai daerah di Nusantara. Kalian dapat memasak ayam kemangi bumbu kuning sendiri di rumah dan pasti jadi santapan favoritmu di hari libur.

Kamu tak perlu bingung jika kamu ingin memakan ayam kemangi bumbu kuning, lantaran ayam kemangi bumbu kuning tidak sulit untuk didapatkan dan anda pun boleh mengolahnya sendiri di tempatmu. ayam kemangi bumbu kuning bisa dimasak memalui berbagai cara. Saat ini telah banyak banget cara modern yang membuat ayam kemangi bumbu kuning semakin lebih nikmat.

Resep ayam kemangi bumbu kuning pun sangat gampang dibuat, lho. Kita jangan capek-capek untuk memesan ayam kemangi bumbu kuning, tetapi Kalian dapat menyajikan ditempatmu. Bagi Kamu yang mau mencobanya, inilah resep untuk membuat ayam kemangi bumbu kuning yang mantab yang dapat Kamu buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Ayam Kemangi Bumbu Kuning:

1. Ambil 1 ekor ayam kampung atau 2 ekor ayam TG
1. Ambil  Garam
1. Sediakan  Gula
1. Siapkan  Penyedap rasa
1. Ambil 3 ikat Kemangi
1. Gunakan  Minyak
1. Gunakan  Air
1. Ambil 8 buah cabai rawit domba
1. Ambil  Bumbu halus :
1. Gunakan 6 siung bawang putih
1. Siapkan 10 siung bawang merah
1. Ambil 5 buah cabai rawit domba (kalau suka pedas, bisa ditambah)
1. Gunakan 3 buah cabai merah
1. Ambil 3 ruas kunyit
1. Gunakan 3 butir kemiri




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam Kemangi Bumbu Kuning:

1. Goreng ayam sampai setengah matang, lalu tiriskan
1. Haluskan bahan-bahan untuk bumbu halus : cabai rawit, cabai merah, bawang putih, bawang merah, kemiri, kunyit
1. Panaskan minyak, lalu tumis bumbu halus sampai berubah warna dan matang. Agar tidak langu
1. Masukkan ayam yang sudah setengah matang, lalu tambahkan air secukupnya (kurang lebih 800ml)
1. Tambahkan garam, gula, penyedap rasa. Harus dicicip ya Bund, biar sesuai dengan selera.
1. Masak ayam dan biarkan 10-15 menit dengan api sedang dan tutup panci
1. Siapkan kemangi yang sudah dipetik, dan cabai rawit domba yang sudah dibuang tangkainya
1. Setelah bumbu cukup meresap dan ayam matang, masukkan kemangi dan cabai rawit domba. Aduk sebentar lalu matikan api.




Wah ternyata cara membuat ayam kemangi bumbu kuning yang mantab tidak rumit ini mudah banget ya! Kalian semua mampu menghidangkannya. Cara buat ayam kemangi bumbu kuning Cocok sekali buat anda yang baru mau belajar memasak ataupun untuk kamu yang telah lihai dalam memasak.

Apakah kamu ingin mencoba membuat resep ayam kemangi bumbu kuning lezat tidak rumit ini? Kalau kamu mau, mending kamu segera buruan siapin alat-alat dan bahannya, kemudian buat deh Resep ayam kemangi bumbu kuning yang lezat dan sederhana ini. Sangat mudah kan. 

Jadi, daripada kita diam saja, maka langsung aja buat resep ayam kemangi bumbu kuning ini. Pasti kalian gak akan nyesel membuat resep ayam kemangi bumbu kuning enak tidak rumit ini! Selamat mencoba dengan resep ayam kemangi bumbu kuning enak tidak ribet ini di rumah kalian masing-masing,oke!.

