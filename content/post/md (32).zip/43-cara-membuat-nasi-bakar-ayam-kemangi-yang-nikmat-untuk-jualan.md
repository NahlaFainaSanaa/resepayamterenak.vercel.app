---
description: "Cara membuat Nasi Bakar Ayam Kemangi yang nikmat Untuk Jualan"
title: "Cara membuat Nasi Bakar Ayam Kemangi yang nikmat Untuk Jualan"
slug: 43-cara-membuat-nasi-bakar-ayam-kemangi-yang-nikmat-untuk-jualan
date: 2021-04-08T16:37:24.483Z
image: https://img-global.cpcdn.com/recipes/06c6706a5497d417/680x482cq70/nasi-bakar-ayam-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/06c6706a5497d417/680x482cq70/nasi-bakar-ayam-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/06c6706a5497d417/680x482cq70/nasi-bakar-ayam-kemangi-foto-resep-utama.jpg
author: Brandon Castro
ratingvalue: 3.3
reviewcount: 14
recipeingredient:
- "  bahan nasi"
- "600 gr nasi putih"
- "50 ml santan"
- "1 sdt garam"
- "  bahan ayam"
- "150 gr ayam fillet"
- "1/2 buah jeruk nipis"
- "300 ml air u merebus ayam"
- "6 siung bawang merah"
- "3 siung bawang putih"
- "5 buah cabe merah"
- "3 buah cabe rawit"
- "1/2 cm kunyit"
- "1/2 cm jahe"
- "3 buah kemiri"
- "1 batang sereh"
- "2 buah daun salam"
- "3 buah daun jeruk"
- "1 ikat  1 genggam daun kemangi"
- "100 ml santan kental"
- "1 sdt garam"
- "1 sdt kaldu jamur"
- "  pelengkap"
- " Daun pisang"
- "Lidi  tusuk gigi"
recipeinstructions:
- "Letakkan nasi semalam dalam baskom, lalu beri santan, aduk rata n kukus selama 10 menit. Sisihkan. Haluskan semua bumbu, kecuali sereh, daun jeruk, daun salam n kemangi."
- "Bersihkan ayam, beri perasan air jeruk, diamkan selama 5 menit, cuci bersih. Lalu didihkan air n rebus ayam sampai matang, lalu suir2, sisihkan."
- "Panaskan minyak, lalu tumis bumbu halus sampai matang, tambahkan sereh, daun jeruk n daun salam. Lalu masukkan ayam, oseng sampai rata, beri garam, kaldu jamur n santan. Masak sampai santan mengering, lalu tambahkan daun kemangi. Sisihkan."
- "Siapkan daun yang sudah di bersihkan, lalu tata nasi n ayam, lalu gulung nasi, sematkan ujung2nya dengan lidi."
- "Panggang dengan teflon. Sajikan selagi panas ke hangat. Selamat mencoba n semoga suka ya 😊"
categories:
- Resep
tags:
- nasi
- bakar
- ayam

katakunci: nasi bakar ayam 
nutrition: 151 calories
recipecuisine: Indonesian
preptime: "PT15M"
cooktime: "PT45M"
recipeyield: "3"
recipecategory: Lunch

---


![Nasi Bakar Ayam Kemangi](https://img-global.cpcdn.com/recipes/06c6706a5497d417/680x482cq70/nasi-bakar-ayam-kemangi-foto-resep-utama.jpg)

Jika kita seorang orang tua, menyuguhkan panganan nikmat pada famili adalah suatu hal yang menyenangkan untuk kamu sendiri. Tugas seorang istri Tidak hanya mengatur rumah saja, namun anda juga wajib memastikan kebutuhan gizi tercukupi dan olahan yang disantap anak-anak mesti nikmat.

Di zaman  sekarang, kalian sebenarnya bisa memesan santapan praktis meski tanpa harus ribet mengolahnya dulu. Tetapi banyak juga lho orang yang selalu mau memberikan yang terenak bagi orang tercintanya. Sebab, menghidangkan masakan yang dibuat sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan makanan tersebut sesuai dengan makanan kesukaan orang tercinta. 



Apakah anda seorang penggemar nasi bakar ayam kemangi?. Asal kamu tahu, nasi bakar ayam kemangi adalah hidangan khas di Indonesia yang saat ini digemari oleh kebanyakan orang di berbagai tempat di Nusantara. Kita bisa menyajikan nasi bakar ayam kemangi sendiri di rumahmu dan boleh jadi hidangan favorit di akhir pekan.

Kamu tak perlu bingung jika kamu ingin menyantap nasi bakar ayam kemangi, karena nasi bakar ayam kemangi mudah untuk didapatkan dan kita pun bisa mengolahnya sendiri di tempatmu. nasi bakar ayam kemangi boleh dibuat memalui beraneka cara. Saat ini sudah banyak banget resep modern yang menjadikan nasi bakar ayam kemangi lebih nikmat.

Resep nasi bakar ayam kemangi juga sangat gampang dibikin, lho. Kalian tidak usah capek-capek untuk membeli nasi bakar ayam kemangi, lantaran Kamu dapat menghidangkan di rumah sendiri. Untuk Anda yang mau menghidangkannya, berikut ini cara untuk membuat nasi bakar ayam kemangi yang lezat yang mampu Kalian buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Nasi Bakar Ayam Kemangi:

1. Sediakan  ☝️ bahan nasi
1. Ambil 600 gr nasi putih
1. Sediakan 50 ml santan
1. Siapkan 1 sdt garam
1. Sediakan  ✌ bahan ayam
1. Gunakan 150 gr ayam fillet
1. Sediakan 1/2 buah jeruk nipis
1. Ambil 300 ml air u merebus ayam
1. Siapkan 6 siung bawang merah
1. Gunakan 3 siung bawang putih
1. Siapkan 5 buah cabe merah
1. Ambil 3 buah cabe rawit
1. Siapkan 1/2 cm kunyit
1. Gunakan 1/2 cm jahe
1. Ambil 3 buah kemiri
1. Sediakan 1 batang sereh
1. Gunakan 2 buah daun salam
1. Ambil 3 buah daun jeruk
1. Gunakan 1 ikat / 1 genggam daun kemangi
1. Sediakan 100 ml santan kental
1. Siapkan 1 sdt garam
1. Gunakan 1 sdt kaldu jamur
1. Sediakan  👌 pelengkap
1. Sediakan  Daun pisang
1. Sediakan Lidi / /tusuk gigi




<!--inarticleads2-->

##### Langkah-langkah membuat Nasi Bakar Ayam Kemangi:

1. Letakkan nasi semalam dalam baskom, lalu beri santan, aduk rata n kukus selama 10 menit. Sisihkan. Haluskan semua bumbu, kecuali sereh, daun jeruk, daun salam n kemangi.
1. Bersihkan ayam, beri perasan air jeruk, diamkan selama 5 menit, cuci bersih. Lalu didihkan air n rebus ayam sampai matang, lalu suir2, sisihkan.
1. Panaskan minyak, lalu tumis bumbu halus sampai matang, tambahkan sereh, daun jeruk n daun salam. Lalu masukkan ayam, oseng sampai rata, beri garam, kaldu jamur n santan. Masak sampai santan mengering, lalu tambahkan daun kemangi. Sisihkan.
1. Siapkan daun yang sudah di bersihkan, lalu tata nasi n ayam, lalu gulung nasi, sematkan ujung2nya dengan lidi.
1. Panggang dengan teflon. Sajikan selagi panas ke hangat. Selamat mencoba n semoga suka ya 😊




Wah ternyata cara membuat nasi bakar ayam kemangi yang enak tidak ribet ini gampang banget ya! Semua orang dapat mencobanya. Cara buat nasi bakar ayam kemangi Cocok banget buat kita yang baru mau belajar memasak ataupun juga untuk anda yang sudah hebat memasak.

Tertarik untuk mencoba membuat resep nasi bakar ayam kemangi lezat tidak ribet ini? Kalau kalian mau, mending kamu segera buruan siapin alat dan bahannya, lantas bikin deh Resep nasi bakar ayam kemangi yang lezat dan simple ini. Sangat gampang kan. 

Jadi, ketimbang kamu berlama-lama, hayo langsung aja sajikan resep nasi bakar ayam kemangi ini. Pasti kalian tak akan nyesel bikin resep nasi bakar ayam kemangi nikmat tidak rumit ini! Selamat berkreasi dengan resep nasi bakar ayam kemangi enak simple ini di rumah kalian sendiri,oke!.

