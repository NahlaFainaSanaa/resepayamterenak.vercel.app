---
description: "Cara membuat Woku Ayam khas Manado Sederhana Untuk Jualan"
title: "Cara membuat Woku Ayam khas Manado Sederhana Untuk Jualan"
slug: 323-cara-membuat-woku-ayam-khas-manado-sederhana-untuk-jualan
date: 2021-02-05T12:04:16.335Z
image: https://img-global.cpcdn.com/recipes/d55c05341a59da20/680x482cq70/woku-ayam-khas-manado-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d55c05341a59da20/680x482cq70/woku-ayam-khas-manado-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d55c05341a59da20/680x482cq70/woku-ayam-khas-manado-foto-resep-utama.jpg
author: Ryan Rodgers
ratingvalue: 3.8
reviewcount: 9
recipeingredient:
- "1 kg ayampotong kecil"
- "3 buah kentangtambahan saya"
- "5 ikat kemangidipetiki"
- "1 buah jerukdiperas"
- "15 buah cabe rawit"
- "secukupnya Garam merica gularoyco"
- " Bumbu Halus "
- "9 siung bawang merah"
- "5 Siung bawang putih"
- "1 rj kunyit"
- "3 buah Kemiridigoreng dulu"
- "2 rj Jahe"
- "5 buah Cabe merah"
- " Bahan yang diiris "
- "7 lbr daun jeruk iris tipis halus"
- "2 buah Tomat belah empat"
- "2 lbr daun pandan disimpul saja"
- "2 lbr daun kunyitdisimpul saja"
- "2 btg sereh geprek"
- "1 jempol laos geprek"
- "2 lbr Daun salam"
- "2 lbr daun bawang iris tipis"
recipeinstructions:
- "Ayam dan kentang digoreng setengah matang."
- "Bumbu dihaluskan"
- "Panaskan minyak goreng, bumbu halus, tambahkan daun pandan,serai,daun kunyit,tumis sampai wangi."
- "Masukan ayam,gula garam,lada,royco dan air, masak sampai air sat dan bumbu meresap"
- "Tambahkan kentang,daun bawang dan kemangi"
- "Tes rasa dan sajikan"
categories:
- Resep
tags:
- woku
- ayam
- khas

katakunci: woku ayam khas 
nutrition: 179 calories
recipecuisine: Indonesian
preptime: "PT29M"
cooktime: "PT45M"
recipeyield: "2"
recipecategory: Lunch

---


![Woku Ayam khas Manado](https://img-global.cpcdn.com/recipes/d55c05341a59da20/680x482cq70/woku-ayam-khas-manado-foto-resep-utama.jpg)

Sebagai seorang orang tua, menyajikan olahan lezat kepada keluarga tercinta merupakan suatu hal yang menggembirakan bagi anda sendiri. Tugas seorang  wanita bukan sekedar menangani rumah saja, namun kamu juga wajib memastikan keperluan nutrisi terpenuhi dan juga masakan yang dimakan keluarga tercinta wajib sedap.

Di masa  saat ini, kita sebenarnya mampu mengorder panganan siap saji meski tidak harus ribet memasaknya dahulu. Tetapi ada juga mereka yang memang ingin memberikan hidangan yang terenak untuk orang tercintanya. Sebab, memasak sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan hidangan tersebut sesuai dengan masakan kesukaan famili. 



Apakah anda merupakan salah satu penyuka woku ayam khas manado?. Tahukah kamu, woku ayam khas manado adalah sajian khas di Nusantara yang sekarang disukai oleh setiap orang dari berbagai wilayah di Indonesia. Anda bisa menyajikan woku ayam khas manado buatan sendiri di rumahmu dan boleh dijadikan hidangan kesenanganmu di hari liburmu.

Kamu tidak perlu bingung untuk memakan woku ayam khas manado, sebab woku ayam khas manado tidak sulit untuk didapatkan dan kalian pun boleh mengolahnya sendiri di rumah. woku ayam khas manado bisa dimasak dengan beragam cara. Sekarang telah banyak sekali resep modern yang membuat woku ayam khas manado lebih lezat.

Resep woku ayam khas manado juga sangat gampang dihidangkan, lho. Kamu tidak usah ribet-ribet untuk memesan woku ayam khas manado, tetapi Kalian bisa menyajikan di rumah sendiri. Bagi Kamu yang ingin membuatnya, di bawah ini adalah resep menyajikan woku ayam khas manado yang lezat yang dapat Kamu coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Woku Ayam khas Manado:

1. Siapkan 1 kg ayam(potong kecil)
1. Gunakan 3 buah kentang(tambahan saya)
1. Gunakan 5 ikat kemangi(dipetiki)
1. Sediakan 1 buah jeruk,(diperas)
1. Ambil 15 buah cabe rawit
1. Siapkan secukupnya Garam, merica, gula,royco
1. Siapkan  Bumbu Halus :
1. Ambil 9 siung bawang merah
1. Gunakan 5 Siung bawang putih
1. Ambil 1 rj kunyit
1. Ambil 3 buah Kemiri(digoreng dulu)
1. Sediakan 2 rj Jahe
1. Gunakan 5 buah Cabe merah
1. Gunakan  Bahan yang diiris :
1. Siapkan 7 lbr daun jeruk (iris tipis halus)
1. Ambil 2 buah Tomat (belah empat)
1. Gunakan 2 lbr daun pandan (disimpul saja)
1. Sediakan 2 lbr daun kunyit(disimpul saja)
1. Sediakan 2 btg sereh (geprek)
1. Gunakan 1 jempol laos (geprek)
1. Siapkan 2 lbr Daun salam
1. Sediakan 2 lbr daun bawang (iris tipis)




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Woku Ayam khas Manado:

1. Ayam dan kentang digoreng setengah matang.
1. Bumbu dihaluskan
1. Panaskan minyak goreng, bumbu halus, tambahkan daun pandan,serai,daun kunyit,tumis sampai wangi.
1. Masukan ayam,gula garam,lada,royco dan air, masak sampai air sat dan bumbu meresap
1. Tambahkan kentang,daun bawang dan kemangi
1. Tes rasa dan sajikan




Wah ternyata cara buat woku ayam khas manado yang nikamt simple ini gampang banget ya! Kamu semua bisa membuatnya. Cara Membuat woku ayam khas manado Cocok sekali buat kamu yang baru mau belajar memasak ataupun bagi anda yang sudah ahli dalam memasak.

Apakah kamu tertarik mencoba bikin resep woku ayam khas manado enak tidak rumit ini? Kalau anda tertarik, ayo kalian segera buruan siapin alat-alat dan bahan-bahannya, maka bikin deh Resep woku ayam khas manado yang lezat dan simple ini. Benar-benar taidak sulit kan. 

Maka dari itu, daripada anda berlama-lama, yuk kita langsung sajikan resep woku ayam khas manado ini. Dijamin kamu tak akan nyesel sudah bikin resep woku ayam khas manado lezat tidak ribet ini! Selamat berkreasi dengan resep woku ayam khas manado nikmat simple ini di rumah masing-masing,oke!.

