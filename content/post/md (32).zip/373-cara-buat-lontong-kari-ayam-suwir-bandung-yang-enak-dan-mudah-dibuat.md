---
description: "Cara buat Lontong Kari Ayam Suwir Bandung yang enak dan Mudah Dibuat"
title: "Cara buat Lontong Kari Ayam Suwir Bandung yang enak dan Mudah Dibuat"
slug: 373-cara-buat-lontong-kari-ayam-suwir-bandung-yang-enak-dan-mudah-dibuat
date: 2021-01-09T19:28:24.375Z
image: https://img-global.cpcdn.com/recipes/815a7bf7cfb242e2/680x482cq70/lontong-kari-ayam-suwir-bandung-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/815a7bf7cfb242e2/680x482cq70/lontong-kari-ayam-suwir-bandung-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/815a7bf7cfb242e2/680x482cq70/lontong-kari-ayam-suwir-bandung-foto-resep-utama.jpg
author: Della Moreno
ratingvalue: 3.3
reviewcount: 9
recipeingredient:
- " Bahan ayam suwir "
- "2 buah filet ayam"
- "secukupnya Garam"
- "secukupnya Penyedap rasa"
- " Bumbu halus ayam suwir "
- "5 siung bawang merah"
- "3 siung bawang putih"
- "1 ruas jari kunyit"
- "1 ruas lengkuas"
- "1 sdt ketumbar"
- " Bahan kuah kari ayam "
- "5 buah potongan ayam"
- "600 ml santan cair"
- "1 ruas jari lengkuas geprek"
- "2 batang serai geprek"
- "5 lembar daun jeruk buang tulangnya"
- "2 lembar daun salam"
- "3 buah cengkeh"
- "2 buah bunga lawang"
- "3 biji kapulaga"
- "1 batang kayu manis ukuran kecil"
- "Sedikit merica"
- "secukupnya Garam"
- "secukupnya Penyedap rasa"
- " Bumbu halus kuah kari ayam "
- "6 buah cabe merah keriting"
- "8 siung bawang merah"
- "6 siung bawang putih"
- "1 ruas jari kunyit"
- "1 ruas jari jahe"
- "5 butir kemiri"
- "1/2 sdt jinten"
- "1/2 sdt ketumbar"
- " Bahan Pelengkap "
- " Lontong"
- " Telur rebus"
- " Bawang goreng"
- " Sambel"
recipeinstructions:
- "Membuat ayam suwir. Ungkep filet ayam dengan bumbu halus. Hingga air surut. Goreng ayam ungkep. Angkat tiriskan. Lalu suwir suwir. Sisihkan."
- "Membuat kuah kari. Blender halus bahan bumbu halus."
- "Siapkan panci. Tambahkan minyak. Tumis bumbu hingga harum. Masukkan kapulaga, cengkeh, bunga lawang dan kayu manis. Tumis lagi sebentar. Tambahkan daun jeruk, salam, lengkuas dan serai. Tambahkan ayam. Masukkan santan. Aduk rata. Tambahkan garam, merica bubuk dan penyedap rasa. Masak hingga matang. Ayam empuk dan kuah keluar minyaknya. Tes rasa."
- "Siapkan mangkok. Masukkan lontong. Tambahkan suwir ayam. Siram dengan kuah kari. Taburi bawang goreng. Siap di santap selagi hangat. Enak banget. Kaya akan rempah."
categories:
- Resep
tags:
- lontong
- kari
- ayam

katakunci: lontong kari ayam 
nutrition: 207 calories
recipecuisine: Indonesian
preptime: "PT30M"
cooktime: "PT41M"
recipeyield: "1"
recipecategory: Dessert

---


![Lontong Kari Ayam Suwir Bandung](https://img-global.cpcdn.com/recipes/815a7bf7cfb242e2/680x482cq70/lontong-kari-ayam-suwir-bandung-foto-resep-utama.jpg)

Sebagai seorang wanita, menyajikan panganan nikmat kepada keluarga tercinta merupakan hal yang memuaskan untuk kamu sendiri. Tugas seorang  wanita Tidak sekadar mengurus rumah saja, tapi kamu juga harus memastikan kebutuhan gizi tercukupi dan juga santapan yang dimakan orang tercinta mesti enak.

Di zaman  saat ini, anda sebenarnya bisa membeli santapan siap saji meski tidak harus ribet memasaknya terlebih dahulu. Tapi banyak juga lho mereka yang selalu mau menghidangkan yang terenak bagi orang tercintanya. Karena, menyajikan masakan sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan makanan tersebut sesuai makanan kesukaan keluarga. 



Mungkinkah kamu seorang penyuka lontong kari ayam suwir bandung?. Asal kamu tahu, lontong kari ayam suwir bandung adalah makanan khas di Indonesia yang saat ini disenangi oleh orang-orang di hampir setiap wilayah di Indonesia. Kalian bisa menghidangkan lontong kari ayam suwir bandung buatan sendiri di rumah dan boleh dijadikan hidangan kesenanganmu di akhir pekanmu.

Anda jangan bingung jika kamu ingin menyantap lontong kari ayam suwir bandung, lantaran lontong kari ayam suwir bandung gampang untuk ditemukan dan kita pun boleh membuatnya sendiri di rumah. lontong kari ayam suwir bandung boleh dimasak dengan beraneka cara. Kini pun ada banyak sekali resep kekinian yang membuat lontong kari ayam suwir bandung semakin nikmat.

Resep lontong kari ayam suwir bandung pun gampang sekali untuk dibikin, lho. Kalian jangan ribet-ribet untuk membeli lontong kari ayam suwir bandung, tetapi Kalian mampu menyajikan di rumah sendiri. Untuk Kalian yang ingin menyajikannya, inilah cara membuat lontong kari ayam suwir bandung yang lezat yang bisa Kalian coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Lontong Kari Ayam Suwir Bandung:

1. Ambil  Bahan ayam suwir :
1. Ambil 2 buah filet ayam
1. Sediakan secukupnya Garam
1. Gunakan secukupnya Penyedap rasa
1. Siapkan  Bumbu halus ayam suwir :
1. Siapkan 5 siung bawang merah
1. Siapkan 3 siung bawang putih
1. Gunakan 1 ruas jari kunyit
1. Siapkan 1 ruas lengkuas
1. Gunakan 1 sdt ketumbar
1. Gunakan  Bahan kuah kari ayam :
1. Gunakan 5 buah potongan ayam
1. Gunakan 600 ml santan cair
1. Sediakan 1 ruas jari lengkuas geprek
1. Gunakan 2 batang serai geprek
1. Gunakan 5 lembar daun jeruk buang tulangnya
1. Siapkan 2 lembar daun salam
1. Sediakan 3 buah cengkeh
1. Ambil 2 buah bunga lawang
1. Ambil 3 biji kapulaga
1. Siapkan 1 batang kayu manis ukuran kecil
1. Ambil Sedikit merica
1. Siapkan secukupnya Garam
1. Gunakan secukupnya Penyedap rasa
1. Gunakan  Bumbu halus kuah kari ayam :
1. Ambil 6 buah cabe merah keriting
1. Gunakan 8 siung bawang merah
1. Gunakan 6 siung bawang putih
1. Sediakan 1 ruas jari kunyit
1. Siapkan 1 ruas jari jahe
1. Ambil 5 butir kemiri
1. Ambil 1/2 sdt jinten
1. Siapkan 1/2 sdt ketumbar
1. Ambil  Bahan Pelengkap :
1. Gunakan  Lontong
1. Siapkan  Telur rebus
1. Ambil  Bawang goreng
1. Sediakan  Sambel




<!--inarticleads2-->

##### Langkah-langkah membuat Lontong Kari Ayam Suwir Bandung:

1. Membuat ayam suwir. Ungkep filet ayam dengan bumbu halus. Hingga air surut. Goreng ayam ungkep. Angkat tiriskan. Lalu suwir suwir. Sisihkan.
1. Membuat kuah kari. Blender halus bahan bumbu halus.
1. Siapkan panci. Tambahkan minyak. Tumis bumbu hingga harum. Masukkan kapulaga, cengkeh, bunga lawang dan kayu manis. Tumis lagi sebentar. Tambahkan daun jeruk, salam, lengkuas dan serai. Tambahkan ayam. Masukkan santan. Aduk rata. Tambahkan garam, merica bubuk dan penyedap rasa. Masak hingga matang. Ayam empuk dan kuah keluar minyaknya. Tes rasa.
1. Siapkan mangkok. Masukkan lontong. Tambahkan suwir ayam. Siram dengan kuah kari. Taburi bawang goreng. Siap di santap selagi hangat. Enak banget. Kaya akan rempah.




Wah ternyata cara buat lontong kari ayam suwir bandung yang nikamt sederhana ini mudah banget ya! Semua orang mampu mencobanya. Cara Membuat lontong kari ayam suwir bandung Sesuai banget buat kalian yang baru akan belajar memasak maupun bagi kalian yang telah ahli dalam memasak.

Tertarik untuk mulai mencoba bikin resep lontong kari ayam suwir bandung lezat simple ini? Kalau mau, ayo kamu segera buruan siapin alat-alat dan bahan-bahannya, lantas buat deh Resep lontong kari ayam suwir bandung yang nikmat dan tidak rumit ini. Sangat taidak sulit kan. 

Oleh karena itu, daripada kamu berlama-lama, ayo kita langsung sajikan resep lontong kari ayam suwir bandung ini. Dijamin kamu tak akan menyesal bikin resep lontong kari ayam suwir bandung lezat sederhana ini! Selamat berkreasi dengan resep lontong kari ayam suwir bandung nikmat simple ini di rumah sendiri,ya!.

