---
description: "Bahan-bahan Kari Ayam yang lezat Untuk Jualan"
title: "Bahan-bahan Kari Ayam yang lezat Untuk Jualan"
slug: 430-bahan-bahan-kari-ayam-yang-lezat-untuk-jualan
date: 2021-02-04T11:05:59.113Z
image: https://img-global.cpcdn.com/recipes/6fbb52e0de8fa5e1/680x482cq70/kari-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6fbb52e0de8fa5e1/680x482cq70/kari-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6fbb52e0de8fa5e1/680x482cq70/kari-ayam-foto-resep-utama.jpg
author: Myrtie Fuller
ratingvalue: 3
reviewcount: 14
recipeingredient:
- "1/2 ekor ayam ukuran sedang aku pakai ayam negeri biasa ya"
- "1 bungkus santan kara"
- " Bumbu Halus"
- "10 siung bawang merah"
- "5 siung bawang"
- "3 siung cabai merah"
- "4 butir kemiri sangrai"
- "1,5 sdt ketumbar sangrai"
- "3 ruas jari kunyit"
- " Bumbu Cemplung"
- "2 lbr daun salam"
- "1 batang sereh geprek"
- "2 ruas laos geprek"
- "4 lbr daun jeruk"
- "1 sdt gula merah mau pakai gula pasir juga gpp yah "
recipeinstructions:
- "Cuci bersih ayam yang sudah di potong2 nyaa"
- "Marinasi ayam pakai jeruk nipis sama bawang putih yg di haluskan, lalu tutup yaa tunggu sampai 15menit"
- "Rebus ayam sebentar asal ajaa"
- "Panaskan minyak goreng untuk menggoreng ayam terlebih dahulu"
- "Campurkan semua Bumbu Halus dan Bahan Cemplung sampai matang dan wangiiiii"
- "Masukan ayam, aduk rata dengan bumbu biar kecampur rata lalu kasih air sampai si ayam terendam"
- "Masak sampai mendidih, kecilkan api nyaa buat masukan santan nyaaa ya jangan lupaa santannyaaaaa 🥰"
- "Kasih gula merah, lau beri penyedap rasaa jangan lupa icip icip biar ga keasinan nanti disangka nya pen nikah lagiii 😂 canda nikah✌️"
- "Kalo sudah mendidih matiin apinyaa dan siap deh di hidangkan 🤤🤤 jangan lupa kasih taburan bawang goreng yaa biar makin sedeppp"
- "YUKKKK buibuuu JANGAN LUPA MARKICOBBB YAAAA DI RUMAH ❤️❤️"
categories:
- Resep
tags:
- kari
- ayam

katakunci: kari ayam 
nutrition: 231 calories
recipecuisine: Indonesian
preptime: "PT21M"
cooktime: "PT46M"
recipeyield: "2"
recipecategory: Dinner

---


![Kari Ayam](https://img-global.cpcdn.com/recipes/6fbb52e0de8fa5e1/680x482cq70/kari-ayam-foto-resep-utama.jpg)

Sebagai seorang orang tua, menyediakan santapan menggugah selera bagi keluarga tercinta adalah suatu hal yang sangat menyenangkan bagi kamu sendiri. Tanggung jawab seorang ibu Tidak cuma mengatur rumah saja, tetapi kamu juga harus menyediakan kebutuhan nutrisi tercukupi dan juga olahan yang disantap anak-anak mesti enak.

Di waktu  saat ini, kamu memang dapat mengorder masakan instan tidak harus susah membuatnya dulu. Tetapi ada juga lho orang yang memang mau memberikan hidangan yang terlezat bagi keluarganya. Sebab, menghidangkan masakan yang diolah sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan sesuai masakan kesukaan famili. 



Mungkinkah anda merupakan salah satu penikmat kari ayam?. Tahukah kamu, kari ayam merupakan hidangan khas di Nusantara yang saat ini disenangi oleh orang-orang di hampir setiap daerah di Indonesia. Kalian bisa menghidangkan kari ayam sendiri di rumahmu dan boleh dijadikan camilan kesukaanmu di hari libur.

Kalian jangan bingung jika kamu ingin menyantap kari ayam, karena kari ayam mudah untuk didapatkan dan kamu pun dapat mengolahnya sendiri di tempatmu. kari ayam bisa dimasak memalui bermacam cara. Saat ini ada banyak sekali resep kekinian yang membuat kari ayam lebih nikmat.

Resep kari ayam juga mudah sekali untuk dibikin, lho. Anda tidak usah repot-repot untuk memesan kari ayam, sebab Kamu bisa menyiapkan di rumah sendiri. Untuk Anda yang hendak menyajikannya, berikut ini cara membuat kari ayam yang lezat yang dapat Kita hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Kari Ayam:

1. Siapkan 1/2 ekor ayam ukuran sedang (aku pakai ayam negeri biasa ya)
1. Ambil 1 bungkus santan kara
1. Siapkan  Bumbu Halus
1. Ambil 10 siung bawang merah
1. Sediakan 5 siung bawang
1. Gunakan 3 siung cabai merah
1. Ambil 4 butir kemiri (sangrai)
1. Siapkan 1,5 sdt ketumbar (sangrai)
1. Siapkan 3 ruas jari kunyit
1. Ambil  Bumbu Cemplung
1. Gunakan 2 lbr daun salam
1. Ambil 1 batang sereh (geprek)
1. Siapkan 2 ruas laos (geprek)
1. Siapkan 4 lbr daun jeruk
1. Siapkan 1 sdt gula merah (mau pakai gula pasir juga gpp yah) )




<!--inarticleads2-->

##### Cara menyiapkan Kari Ayam:

1. Cuci bersih ayam yang sudah di potong2 nyaa
1. Marinasi ayam pakai jeruk nipis sama bawang putih yg di haluskan, lalu tutup yaa tunggu sampai 15menit
1. Rebus ayam sebentar asal ajaa
1. Panaskan minyak goreng untuk menggoreng ayam terlebih dahulu
1. Campurkan semua Bumbu Halus dan Bahan Cemplung sampai matang dan wangiiiii
1. Masukan ayam, aduk rata dengan bumbu biar kecampur rata lalu kasih air sampai si ayam terendam
1. Masak sampai mendidih, kecilkan api nyaa buat masukan santan nyaaa ya jangan lupaa santannyaaaaa 🥰
1. Kasih gula merah, lau beri penyedap rasaa jangan lupa icip icip biar ga keasinan nanti disangka nya pen nikah lagiii 😂 canda nikah✌️
1. Kalo sudah mendidih matiin apinyaa dan siap deh di hidangkan 🤤🤤 jangan lupa kasih taburan bawang goreng yaa biar makin sedeppp
1. YUKKKK buibuuu JANGAN LUPA MARKICOBBB YAAAA DI RUMAH ❤️❤️




Ternyata cara buat kari ayam yang nikamt simple ini mudah banget ya! Semua orang mampu mencobanya. Cara Membuat kari ayam Sangat sesuai banget buat kita yang baru akan belajar memasak maupun untuk anda yang telah jago memasak.

Apakah kamu ingin mulai mencoba membuat resep kari ayam lezat simple ini? Kalau kamu mau, ayo kalian segera buruan menyiapkan alat-alat dan bahannya, lalu bikin deh Resep kari ayam yang enak dan simple ini. Sungguh gampang kan. 

Jadi, daripada anda diam saja, ayo langsung aja bikin resep kari ayam ini. Dijamin kalian tak akan nyesel membuat resep kari ayam enak tidak ribet ini! Selamat berkreasi dengan resep kari ayam enak sederhana ini di rumah kalian sendiri,ya!.

