---
description: "Cara membuat Ayam Goreng Tepung Krispi (awet kriuk) yang enak Untuk Jualan"
title: "Cara membuat Ayam Goreng Tepung Krispi (awet kriuk) yang enak Untuk Jualan"
slug: 187-cara-membuat-ayam-goreng-tepung-krispi-awet-kriuk-yang-enak-untuk-jualan
date: 2021-02-04T00:48:51.507Z
image: https://img-global.cpcdn.com/recipes/537b0146220cffc7/680x482cq70/ayam-goreng-tepung-krispi-awet-kriuk-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/537b0146220cffc7/680x482cq70/ayam-goreng-tepung-krispi-awet-kriuk-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/537b0146220cffc7/680x482cq70/ayam-goreng-tepung-krispi-awet-kriuk-foto-resep-utama.jpg
author: Lela Kim
ratingvalue: 4.8
reviewcount: 5
recipeingredient:
- "1/2 kg ayam potong2 selera"
- " Bumbu Marinasi "
- "3 siung bawang putih"
- "1/2 sdt merica bubuk"
- "1/2 sdt garam"
- " Bahan Kering "
- "250 gr tepung terigu"
- "1 sdm tepung beras"
- "1 sdt garam"
- "1/2 sdt kaldu bubuk"
- " Bahan Cair "
- "500 ml air"
- "1/2 sdt baking soda"
recipeinstructions:
- "Marinasi ayam, dengan bumbu marinasi, selama minimum 30 menit"
- "Campur dan ayakkan bahan kering"
- "Masukkan ayam dalam tepung. Bolak balikkan dengan tangan. Tidak usah di remas"
- "Celupkan ayam di bahan cair Balur lagi dengan tepung"
- "Celupkan lagi di air. Balur dengan tepung lagi, ulangi langkah ini sebanyak 3x. Ketuk-ketuk ayam agar tepung tidak banyak menempal"
- "Goreng di minyak yang panas dan banyak.  Pastikan semua terendam"
categories:
- Resep
tags:
- ayam
- goreng
- tepung

katakunci: ayam goreng tepung 
nutrition: 298 calories
recipecuisine: Indonesian
preptime: "PT29M"
cooktime: "PT55M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Goreng Tepung Krispi (awet kriuk)](https://img-global.cpcdn.com/recipes/537b0146220cffc7/680x482cq70/ayam-goreng-tepung-krispi-awet-kriuk-foto-resep-utama.jpg)

Sebagai seorang orang tua, menyediakan masakan sedap buat keluarga adalah suatu hal yang memuaskan bagi anda sendiri. Kewajiban seorang ibu Tidak cuman menangani rumah saja, tapi kamu juga harus menyediakan kebutuhan gizi terpenuhi dan olahan yang dikonsumsi orang tercinta harus nikmat.

Di waktu  saat ini, kita sebenarnya bisa memesan santapan siap saji meski tidak harus susah mengolahnya lebih dulu. Tapi ada juga orang yang memang mau memberikan makanan yang terlezat untuk keluarganya. Karena, menghidangkan masakan sendiri jauh lebih higienis dan kita juga bisa menyesuaikan hidangan tersebut berdasarkan makanan kesukaan famili. 



Mungkinkah kamu seorang penggemar ayam goreng tepung krispi (awet kriuk)?. Asal kamu tahu, ayam goreng tepung krispi (awet kriuk) adalah hidangan khas di Nusantara yang saat ini disenangi oleh kebanyakan orang di hampir setiap wilayah di Indonesia. Anda dapat menyajikan ayam goreng tepung krispi (awet kriuk) sendiri di rumah dan pasti jadi hidangan kesenanganmu di hari liburmu.

Kalian tak perlu bingung jika kamu ingin menyantap ayam goreng tepung krispi (awet kriuk), sebab ayam goreng tepung krispi (awet kriuk) tidak sukar untuk ditemukan dan kamu pun boleh mengolahnya sendiri di tempatmu. ayam goreng tepung krispi (awet kriuk) boleh dibuat memalui beragam cara. Kini pun sudah banyak sekali resep kekinian yang menjadikan ayam goreng tepung krispi (awet kriuk) semakin mantap.

Resep ayam goreng tepung krispi (awet kriuk) pun sangat gampang dihidangkan, lho. Kamu jangan repot-repot untuk membeli ayam goreng tepung krispi (awet kriuk), lantaran Kamu dapat menyiapkan ditempatmu. Untuk Kalian yang mau mencobanya, berikut ini cara membuat ayam goreng tepung krispi (awet kriuk) yang enak yang mampu Kalian buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Ayam Goreng Tepung Krispi (awet kriuk):

1. Sediakan 1/2 kg ayam, potong2 selera
1. Ambil  Bumbu Marinasi :
1. Sediakan 3 siung bawang putih
1. Sediakan 1/2 sdt merica bubuk
1. Ambil 1/2 sdt garam
1. Gunakan  Bahan Kering :
1. Gunakan 250 gr tepung terigu
1. Siapkan 1 sdm tepung beras
1. Siapkan 1 sdt garam
1. Siapkan 1/2 sdt kaldu bubuk
1. Sediakan  Bahan Cair :
1. Sediakan 500 ml air
1. Ambil 1/2 sdt baking soda




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Goreng Tepung Krispi (awet kriuk):

1. Marinasi ayam, dengan bumbu marinasi, selama minimum 30 menit
<img src="https://img-global.cpcdn.com/steps/f6571b36b1402217/160x128cq70/ayam-goreng-tepung-krispi-awet-kriuk-langkah-memasak-1-foto.jpg" alt="Ayam Goreng Tepung Krispi (awet kriuk)">1. Campur dan ayakkan bahan kering
1. Masukkan ayam dalam tepung. Bolak balikkan dengan tangan. Tidak usah di remas
1. Celupkan ayam di bahan cair - Balur lagi dengan tepung
1. Celupkan lagi di air. Balur dengan tepung lagi, ulangi langkah ini sebanyak 3x. Ketuk-ketuk ayam agar tepung tidak banyak menempal
1. Goreng di minyak yang panas dan banyak.  - Pastikan semua terendam




Wah ternyata cara buat ayam goreng tepung krispi (awet kriuk) yang nikamt tidak ribet ini mudah sekali ya! Semua orang mampu membuatnya. Cara Membuat ayam goreng tepung krispi (awet kriuk) Sesuai sekali untuk kamu yang sedang belajar memasak ataupun juga untuk anda yang sudah hebat dalam memasak.

Apakah kamu tertarik mulai mencoba buat resep ayam goreng tepung krispi (awet kriuk) nikmat tidak rumit ini? Kalau kamu mau, ayo kamu segera buruan menyiapkan peralatan dan bahan-bahannya, lalu bikin deh Resep ayam goreng tepung krispi (awet kriuk) yang nikmat dan tidak rumit ini. Betul-betul gampang kan. 

Maka dari itu, ketimbang kamu diam saja, maka kita langsung saja sajikan resep ayam goreng tepung krispi (awet kriuk) ini. Pasti kalian tak akan nyesel sudah membuat resep ayam goreng tepung krispi (awet kriuk) nikmat simple ini! Selamat mencoba dengan resep ayam goreng tepung krispi (awet kriuk) lezat simple ini di rumah masing-masing,oke!.

