---
description: "Bahan-bahan Ayam Tangkap Khas Aceh yang nikmat dan Mudah Dibuat"
title: "Bahan-bahan Ayam Tangkap Khas Aceh yang nikmat dan Mudah Dibuat"
slug: 489-bahan-bahan-ayam-tangkap-khas-aceh-yang-nikmat-dan-mudah-dibuat
date: 2021-01-21T21:00:22.727Z
image: https://img-global.cpcdn.com/recipes/3d5e992e6a1aacc5/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/3d5e992e6a1aacc5/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/3d5e992e6a1aacc5/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg
author: Gerald Goodwin
ratingvalue: 4.6
reviewcount: 3
recipeingredient:
- "1 ekor ayam kampungpotong sy ayam potong 13 kg"
- "1 buah jeruk nipis ambil airnya"
- "3 sdm air asam jawa dr 3 mata asam"
- "2 sdt garam sesuai selera"
- "300 ml air kelapa dr 1 butir kelapa"
- "Secukupnya minyak goreng"
- " Bumbu halus"
- "6 siung bawang merah"
- "3 siung bawang putih"
- "5-8 buah cabai rawit hijau opsional"
- "1 sdt kunyit bubuk"
- "1/2 sdt merica bubuk"
- "1 ruas jari jahe"
- " Bahan"
- "10 tangkai daun kari ambil daunnya"
- "7 lembar daun pandan potong kecil"
- "8 buah cabai hijau potong jadi 3 bagian"
- "8 siung bawang merah iris tipis"
recipeinstructions:
- "Potong kecil-kecil ayam, cuci bersih, tiriskan, beri air jeruk nipis (dari 1/2 buah), diamkan beberapa saat, kmdn bilas kembali, tiriskan. Masukkan ayam ke dlm wajan, balur ayam dengan garam dan campuran air jeruk nipis (dari 1/2 buah jeruk nipis) + 3 sdm air asam jawa. Siapkan juga bahan rempah daunnya."
- "Masukkan bumbu halus ke dalam ayam, ratakan. Tambahkan air kelapa, kmdn ungkep ayam sambil ditutup sampai air menyusut dan bumbu meresap. Note: jika menggunakan ayam kampung, banyaknya air kelapa bisa disesuaikan."
- "Panaskan minyak goreng (minyak banyak), goreng ayam dgn api sedang, kemudian balik ayam. Setelah ayam mulai berwarna kecoklatan, masukkan daun kari, daun pandan, cabai hijau dan bawang merah iris. Goreng sampai ayam berwarna kecoklatan dan rempah daunnya kering serta bawang merahnya kecoklatan. Note: Saya 2X goreng, jadi rempah daunnya dibagi 2."
- "Setelah ayam matang berwarna kuning kecoklatan dan rempah daun kering, angkat dan tiriskan."
- "Sajikan ayam bersama rempah daun kering, cabai hijau dan bawang goreng keringnya. Ayam ini enak disajikan saat panas-panas, sehingga rempah daunnya masih kriuk."
categories:
- Resep
tags:
- ayam
- tangkap
- khas

katakunci: ayam tangkap khas 
nutrition: 132 calories
recipecuisine: Indonesian
preptime: "PT21M"
cooktime: "PT31M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam Tangkap Khas Aceh](https://img-global.cpcdn.com/recipes/3d5e992e6a1aacc5/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg)

Andai kalian seorang yang hobi masak, mempersiapkan olahan lezat buat keluarga tercinta adalah hal yang menyenangkan bagi anda sendiri. Tanggung jawab seorang ibu bukan sekedar mengatur rumah saja, namun kamu juga wajib memastikan keperluan nutrisi terpenuhi dan olahan yang dimakan anak-anak harus mantab.

Di era  saat ini, anda sebenarnya bisa membeli olahan jadi walaupun tanpa harus ribet membuatnya terlebih dahulu. Tetapi banyak juga mereka yang memang ingin memberikan makanan yang terbaik untuk orang yang dicintainya. Pasalnya, memasak yang dibuat sendiri akan jauh lebih higienis dan bisa menyesuaikan berdasarkan masakan kesukaan famili. 



Mungkinkah kamu salah satu penikmat ayam tangkap khas aceh?. Asal kamu tahu, ayam tangkap khas aceh adalah makanan khas di Nusantara yang kini disenangi oleh setiap orang di hampir setiap daerah di Nusantara. Kita bisa menyajikan ayam tangkap khas aceh sendiri di rumah dan boleh dijadikan makanan favorit di hari libur.

Kalian tidak perlu bingung jika kamu ingin memakan ayam tangkap khas aceh, sebab ayam tangkap khas aceh tidak sukar untuk didapatkan dan kalian pun dapat membuatnya sendiri di tempatmu. ayam tangkap khas aceh boleh diolah lewat beragam cara. Sekarang sudah banyak cara kekinian yang menjadikan ayam tangkap khas aceh semakin lebih mantap.

Resep ayam tangkap khas aceh pun sangat mudah dibuat, lho. Kalian tidak usah capek-capek untuk membeli ayam tangkap khas aceh, karena Kamu mampu membuatnya di rumah sendiri. Bagi Kamu yang akan membuatnya, di bawah ini adalah cara menyajikan ayam tangkap khas aceh yang nikamat yang dapat Kita coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Ayam Tangkap Khas Aceh:

1. Ambil 1 ekor ayam kampung/potong (sy: ayam potong 1,3 kg)
1. Ambil 1 buah jeruk nipis, ambil airnya
1. Sediakan 3 sdm air asam jawa (dr 3 mata asam)
1. Siapkan 2 sdt garam (sesuai selera)
1. Ambil 300 ml air kelapa (dr 1 butir kelapa)
1. Ambil Secukupnya minyak goreng
1. Ambil  Bumbu halus:
1. Sediakan 6 siung bawang merah
1. Ambil 3 siung bawang putih
1. Sediakan 5-8 buah cabai rawit hijau (opsional)
1. Gunakan 1 sdt kunyit bubuk
1. Sediakan 1/2 sdt merica bubuk
1. Siapkan 1 ruas jari jahe
1. Siapkan  Bahan
1. Gunakan 10 tangkai daun kari, ambil daunnya
1. Ambil 7 lembar daun pandan, potong kecil
1. Sediakan 8 buah cabai hijau, potong jadi 3 bagian
1. Sediakan 8 siung bawang merah, iris tipis




<!--inarticleads2-->

##### Cara menyiapkan Ayam Tangkap Khas Aceh:

1. Potong kecil-kecil ayam, cuci bersih, tiriskan, beri air jeruk nipis (dari 1/2 buah), diamkan beberapa saat, kmdn bilas kembali, tiriskan. Masukkan ayam ke dlm wajan, balur ayam dengan garam dan campuran air jeruk nipis (dari 1/2 buah jeruk nipis) + 3 sdm air asam jawa. Siapkan juga bahan rempah daunnya.
1. Masukkan bumbu halus ke dalam ayam, ratakan. Tambahkan air kelapa, kmdn ungkep ayam sambil ditutup sampai air menyusut dan bumbu meresap. Note: jika menggunakan ayam kampung, banyaknya air kelapa bisa disesuaikan.
1. Panaskan minyak goreng (minyak banyak), goreng ayam dgn api sedang, kemudian balik ayam. Setelah ayam mulai berwarna kecoklatan, masukkan daun kari, daun pandan, cabai hijau dan bawang merah iris. Goreng sampai ayam berwarna kecoklatan dan rempah daunnya kering serta bawang merahnya kecoklatan. Note: Saya 2X goreng, jadi rempah daunnya dibagi 2.
1. Setelah ayam matang berwarna kuning kecoklatan dan rempah daun kering, angkat dan tiriskan.
1. Sajikan ayam bersama rempah daun kering, cabai hijau dan bawang goreng keringnya. Ayam ini enak disajikan saat panas-panas, sehingga rempah daunnya masih kriuk.




Ternyata cara buat ayam tangkap khas aceh yang lezat sederhana ini gampang banget ya! Anda Semua bisa memasaknya. Cara Membuat ayam tangkap khas aceh Cocok banget untuk kalian yang baru belajar memasak atau juga bagi anda yang telah pandai dalam memasak.

Tertarik untuk mulai mencoba membikin resep ayam tangkap khas aceh lezat tidak rumit ini? Kalau tertarik, ayo kamu segera siapin alat-alat dan bahannya, lalu buat deh Resep ayam tangkap khas aceh yang enak dan tidak rumit ini. Betul-betul gampang kan. 

Maka dari itu, ketimbang kalian diam saja, yuk kita langsung saja buat resep ayam tangkap khas aceh ini. Dijamin kamu tak akan nyesel sudah bikin resep ayam tangkap khas aceh lezat simple ini! Selamat mencoba dengan resep ayam tangkap khas aceh lezat sederhana ini di tempat tinggal kalian masing-masing,oke!.

