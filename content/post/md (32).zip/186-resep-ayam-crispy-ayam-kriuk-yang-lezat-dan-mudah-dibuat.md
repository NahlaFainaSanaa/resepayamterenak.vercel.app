---
description: "Resep Ayam crispy/ ayam kriuk yang lezat dan Mudah Dibuat"
title: "Resep Ayam crispy/ ayam kriuk yang lezat dan Mudah Dibuat"
slug: 186-resep-ayam-crispy-ayam-kriuk-yang-lezat-dan-mudah-dibuat
date: 2021-01-18T11:45:32.248Z
image: https://img-global.cpcdn.com/recipes/57745367a3a847ed/680x482cq70/ayam-crispy-ayam-kriuk-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/57745367a3a847ed/680x482cq70/ayam-crispy-ayam-kriuk-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/57745367a3a847ed/680x482cq70/ayam-crispy-ayam-kriuk-foto-resep-utama.jpg
author: Katharine Owen
ratingvalue: 3.8
reviewcount: 10
recipeingredient:
- "1/2 kg potong jadi 5"
- " Bumbu marinasi"
- "11/2 sdt garam"
- "3 siung bawang putih"
- "1/2 sdt baking powder"
- "Sepucuk sdt lada bubuk"
- "50 ml air"
- "1 liter minyak untuk menggoreng"
- " Adonan tepung kering"
- "125 gr tepung terigu"
- "75 gr tepung sasa serbaguna"
- "1/2 bks royco sapi"
- " Adonan tepung basah"
- "3 sdm adonan tepung kering"
- "secukupnya Air"
recipeinstructions:
- "Cuci bersih daging ayam yang sudah dipotong lalu siapkan bumbu marinasi. Kemudian rendam daging ayam ke dalam bumbu marinasi lalu diamkan 30 menit di kulkas."
- "Siapkan adonan tepung kering dan basah. Keluarkan daging ayam dari kulkas lalu masukkan satu per satu daging ke dalam tepung kering-tepung basah- tepung kering lagi. Tebas-tebas tepungnya. (Jangan diremas-remas agar tepung menempel natural dan tidak bantat)"
- "Goreng pada minyak panas (deep frying) dengan api kecil agar matang hingga dalam. Goreng hingga kuning keemasan."
categories:
- Resep
tags:
- ayam
- crispy
- ayam

katakunci: ayam crispy ayam 
nutrition: 119 calories
recipecuisine: Indonesian
preptime: "PT15M"
cooktime: "PT46M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam crispy/ ayam kriuk](https://img-global.cpcdn.com/recipes/57745367a3a847ed/680x482cq70/ayam-crispy-ayam-kriuk-foto-resep-utama.jpg)

Sebagai seorang yang hobi memasak, menyuguhkan santapan enak kepada keluarga merupakan hal yang mengasyikan bagi kamu sendiri. Tugas seorang  wanita Tidak sekadar menjaga rumah saja, tapi kamu pun wajib menyediakan kebutuhan gizi tercukupi dan olahan yang disantap orang tercinta wajib menggugah selera.

Di waktu  saat ini, kamu sebenarnya dapat memesan panganan jadi meski tidak harus ribet memasaknya dulu. Tetapi banyak juga orang yang selalu mau menyajikan yang terlezat bagi orang tercintanya. Pasalnya, menghidangkan masakan sendiri jauh lebih bersih dan kita juga bisa menyesuaikan makanan tersebut berdasarkan masakan kesukaan orang tercinta. 



Mungkinkah anda adalah salah satu penggemar ayam crispy/ ayam kriuk?. Asal kamu tahu, ayam crispy/ ayam kriuk merupakan makanan khas di Indonesia yang saat ini disukai oleh setiap orang dari berbagai daerah di Indonesia. Anda dapat membuat ayam crispy/ ayam kriuk buatan sendiri di rumahmu dan pasti jadi hidangan kesukaanmu di hari liburmu.

Kamu tidak usah bingung jika kamu ingin mendapatkan ayam crispy/ ayam kriuk, sebab ayam crispy/ ayam kriuk sangat mudah untuk ditemukan dan juga kita pun bisa membuatnya sendiri di rumah. ayam crispy/ ayam kriuk dapat diolah memalui berbagai cara. Saat ini sudah banyak banget cara kekinian yang menjadikan ayam crispy/ ayam kriuk lebih nikmat.

Resep ayam crispy/ ayam kriuk pun mudah sekali untuk dibikin, lho. Kamu tidak perlu repot-repot untuk memesan ayam crispy/ ayam kriuk, sebab Kalian dapat menyajikan sendiri di rumah. Untuk Kita yang akan membuatnya, inilah cara membuat ayam crispy/ ayam kriuk yang mantab yang dapat Kamu hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Ayam crispy/ ayam kriuk:

1. Gunakan 1/2 kg potong jadi 5
1. Siapkan  Bumbu marinasi
1. Gunakan 11/2 sdt garam
1. Ambil 3 siung bawang putih
1. Gunakan 1/2 sdt baking powder
1. Ambil Sepucuk sdt lada bubuk
1. Siapkan 50 ml air
1. Sediakan 1 liter minyak untuk menggoreng
1. Sediakan  Adonan tepung kering
1. Gunakan 125 gr tepung terigu
1. Sediakan 75 gr tepung sasa serbaguna
1. Siapkan 1/2 bks royco sapi
1. Gunakan  Adonan tepung basah
1. Siapkan 3 sdm adonan tepung kering
1. Ambil secukupnya Air




<!--inarticleads2-->

##### Cara membuat Ayam crispy/ ayam kriuk:

1. Cuci bersih daging ayam yang sudah dipotong lalu siapkan bumbu marinasi. Kemudian rendam daging ayam ke dalam bumbu marinasi lalu diamkan 30 menit di kulkas.
1. Siapkan adonan tepung kering dan basah. Keluarkan daging ayam dari kulkas lalu masukkan satu per satu daging ke dalam tepung kering-tepung basah- tepung kering lagi. Tebas-tebas tepungnya. (Jangan diremas-remas agar tepung menempel natural dan tidak bantat)
1. Goreng pada minyak panas (deep frying) dengan api kecil agar matang hingga dalam. Goreng hingga kuning keemasan.




Wah ternyata cara buat ayam crispy/ ayam kriuk yang lezat tidak ribet ini enteng banget ya! Anda Semua bisa menghidangkannya. Cara buat ayam crispy/ ayam kriuk Sesuai sekali untuk kita yang baru mau belajar memasak ataupun juga bagi kamu yang sudah lihai dalam memasak.

Tertarik untuk mencoba membuat resep ayam crispy/ ayam kriuk enak simple ini? Kalau kalian ingin, mending kamu segera siapin alat dan bahan-bahannya, setelah itu buat deh Resep ayam crispy/ ayam kriuk yang mantab dan tidak ribet ini. Betul-betul gampang kan. 

Jadi, daripada kamu diam saja, hayo kita langsung hidangkan resep ayam crispy/ ayam kriuk ini. Pasti kalian gak akan menyesal sudah membuat resep ayam crispy/ ayam kriuk lezat tidak ribet ini! Selamat berkreasi dengan resep ayam crispy/ ayam kriuk lezat tidak ribet ini di rumah kalian sendiri,oke!.

