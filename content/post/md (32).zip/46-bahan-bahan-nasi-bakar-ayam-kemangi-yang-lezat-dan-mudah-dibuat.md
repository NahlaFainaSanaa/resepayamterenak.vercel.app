---
description: "Bahan-bahan Nasi bakar ayam kemangi yang lezat dan Mudah Dibuat"
title: "Bahan-bahan Nasi bakar ayam kemangi yang lezat dan Mudah Dibuat"
slug: 46-bahan-bahan-nasi-bakar-ayam-kemangi-yang-lezat-dan-mudah-dibuat
date: 2021-03-12T16:03:11.256Z
image: https://img-global.cpcdn.com/recipes/3b89de42a42348a5/680x482cq70/nasi-bakar-ayam-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/3b89de42a42348a5/680x482cq70/nasi-bakar-ayam-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/3b89de42a42348a5/680x482cq70/nasi-bakar-ayam-kemangi-foto-resep-utama.jpg
author: Paul Roberson
ratingvalue: 4.6
reviewcount: 6
recipeingredient:
- "130 gr ayam suwir rebus dengan 2 ruas jahe"
- "5 bh cabe merah besar"
- "7 cabe rawit orange"
- "6 bh cabe rawit orangebiarkan utuh optional utk yg suka pedes"
- "6 sg bwg merah"
- "3 sg bwg putih"
- "4 lembar daun jeruk iris"
- "2 bh irisan cabe merah besar"
- "1 genggam penuh kemangi"
- "2 bh sereh potong2"
- "secukupnya Garam kaldu jamur gula"
- " Bahan nasi gurih"
- "450 gr nasi panas"
- "secukupnya Garam micin"
- " Bahan tambahan"
- " Daun pisang dipanaskan dulu agar mudah dibentuk"
- " Minyak goreng"
recipeinstructions:
- "Rebus ayam fillet bersama dengan jahe dan garam...angkat dan suwir2..ambil suwiran ayam sebanyak 130 gr"
- "Haluskan 3 bwg putih, 6 bwg merah, 5 cabe besar, 7 cabe rawit dengan menggunakan 5 sdm minyak"
- "Tumis bumbu halus, daun jeruk, hingga wangi kemudian masukkan irisan cabe merah, dan cabe orange utuh..tumis hingga agak layu"
- "Masukkan ayam suwir dan beri air sedikit saja..sekitar 3 sdm dan tambahkan garam, gula, kaldu jamur secukupnya lalu tumis hingga matang..setelah itu terakhir masukkan kemangi...aduk rata"
- "Utk nasi gurih :aduk nasi panas bersama dengan garam dan micin secukupnya"
- "Siapkan daun pisang...lalu taruh nasi dan isi dengan tumisan ayam suwir kemangi"
- "Panggang diatas teflon yg sudah diolesi oleh minyak...panggang hingga matang...sajikan"
categories:
- Resep
tags:
- nasi
- bakar
- ayam

katakunci: nasi bakar ayam 
nutrition: 273 calories
recipecuisine: Indonesian
preptime: "PT23M"
cooktime: "PT55M"
recipeyield: "1"
recipecategory: Lunch

---


![Nasi bakar ayam kemangi](https://img-global.cpcdn.com/recipes/3b89de42a42348a5/680x482cq70/nasi-bakar-ayam-kemangi-foto-resep-utama.jpg)

Jika kita seorang ibu, menyuguhkan santapan mantab bagi famili adalah suatu hal yang memuaskan bagi kamu sendiri. Tanggung jawab seorang ibu Tidak cuman menangani rumah saja, tapi kamu juga wajib memastikan kebutuhan gizi tercukupi dan juga masakan yang dikonsumsi orang tercinta wajib lezat.

Di waktu  sekarang, anda sebenarnya dapat membeli hidangan praktis tanpa harus susah membuatnya lebih dulu. Namun ada juga mereka yang selalu mau menghidangkan yang terbaik untuk keluarganya. Lantaran, menghidangkan masakan yang diolah sendiri jauh lebih bersih dan kita pun bisa menyesuaikan masakan tersebut berdasarkan selera orang tercinta. 



Mungkinkah anda salah satu penggemar nasi bakar ayam kemangi?. Asal kamu tahu, nasi bakar ayam kemangi adalah makanan khas di Nusantara yang kini digemari oleh orang-orang di berbagai daerah di Nusantara. Kalian dapat memasak nasi bakar ayam kemangi sendiri di rumahmu dan boleh dijadikan camilan kesukaanmu di akhir pekan.

Kita tidak perlu bingung jika kamu ingin mendapatkan nasi bakar ayam kemangi, sebab nasi bakar ayam kemangi tidak sukar untuk ditemukan dan kalian pun bisa menghidangkannya sendiri di rumah. nasi bakar ayam kemangi bisa dibuat memalui bermacam cara. Kini sudah banyak sekali cara modern yang menjadikan nasi bakar ayam kemangi semakin lezat.

Resep nasi bakar ayam kemangi juga gampang sekali dibikin, lho. Kalian tidak usah ribet-ribet untuk memesan nasi bakar ayam kemangi, karena Kita mampu menghidangkan sendiri di rumah. Bagi Kalian yang hendak membuatnya, inilah resep menyajikan nasi bakar ayam kemangi yang mantab yang dapat Kamu buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Nasi bakar ayam kemangi:

1. Sediakan 130 gr ayam suwir, rebus dengan 2 ruas jahe
1. Gunakan 5 bh cabe merah besar
1. Sediakan 7 cabe rawit orange
1. Ambil 6 bh cabe rawit orange,biarkan utuh (optional utk yg suka pedes)
1. Ambil 6 sg bwg merah
1. Gunakan 3 sg bwg putih
1. Ambil 4 lembar daun jeruk, iris
1. Gunakan 2 bh irisan cabe merah besar
1. Ambil 1 genggam penuh kemangi
1. Sediakan 2 bh sereh, potong2
1. Sediakan secukupnya Garam, kaldu jamur, gula
1. Ambil  Bahan nasi gurih
1. Ambil 450 gr nasi panas
1. Gunakan secukupnya Garam, micin
1. Siapkan  Bahan tambahan
1. Siapkan  Daun pisang, dipanaskan dulu agar mudah dibentuk
1. Sediakan  Minyak goreng




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Nasi bakar ayam kemangi:

1. Rebus ayam fillet bersama dengan jahe dan garam...angkat dan suwir2..ambil suwiran ayam sebanyak 130 gr
1. Haluskan 3 bwg putih, 6 bwg merah, 5 cabe besar, 7 cabe rawit dengan menggunakan 5 sdm minyak
1. Tumis bumbu halus, daun jeruk, hingga wangi kemudian masukkan irisan cabe merah, dan cabe orange utuh..tumis hingga agak layu
1. Masukkan ayam suwir dan beri air sedikit saja..sekitar 3 sdm dan tambahkan garam, gula, kaldu jamur secukupnya lalu tumis hingga matang..setelah itu terakhir masukkan kemangi...aduk rata
1. Utk nasi gurih :aduk nasi panas bersama dengan garam dan micin secukupnya
1. Siapkan daun pisang...lalu taruh nasi dan isi dengan tumisan ayam suwir kemangi
1. Panggang diatas teflon yg sudah diolesi oleh minyak...panggang hingga matang...sajikan




Ternyata resep nasi bakar ayam kemangi yang enak sederhana ini gampang banget ya! Kalian semua bisa membuatnya. Cara Membuat nasi bakar ayam kemangi Sesuai banget untuk kalian yang baru mau belajar memasak ataupun juga bagi anda yang sudah lihai dalam memasak.

Tertarik untuk mulai mencoba membuat resep nasi bakar ayam kemangi nikmat simple ini? Kalau anda tertarik, mending kamu segera buruan menyiapkan alat dan bahan-bahannya, lantas bikin deh Resep nasi bakar ayam kemangi yang mantab dan tidak rumit ini. Benar-benar taidak sulit kan. 

Jadi, daripada anda berlama-lama, hayo kita langsung saja sajikan resep nasi bakar ayam kemangi ini. Dijamin kamu tiidak akan nyesel sudah membuat resep nasi bakar ayam kemangi nikmat tidak rumit ini! Selamat berkreasi dengan resep nasi bakar ayam kemangi enak tidak ribet ini di rumah kalian masing-masing,ya!.

