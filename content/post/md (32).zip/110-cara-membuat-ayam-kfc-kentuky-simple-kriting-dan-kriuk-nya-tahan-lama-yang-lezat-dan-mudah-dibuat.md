---
description: "Cara membuat Ayam kfc/ kentuky simple,kriting dan kriuk nya tahan lama, yang lezat dan Mudah Dibuat"
title: "Cara membuat Ayam kfc/ kentuky simple,kriting dan kriuk nya tahan lama, yang lezat dan Mudah Dibuat"
slug: 110-cara-membuat-ayam-kfc-kentuky-simple-kriting-dan-kriuk-nya-tahan-lama-yang-lezat-dan-mudah-dibuat
date: 2021-03-23T23:36:42.387Z
image: https://img-global.cpcdn.com/recipes/803ecb3a54cbb7cf/680x482cq70/ayam-kfc-kentuky-simplekriting-dan-kriuk-nya-tahan-lama-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/803ecb3a54cbb7cf/680x482cq70/ayam-kfc-kentuky-simplekriting-dan-kriuk-nya-tahan-lama-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/803ecb3a54cbb7cf/680x482cq70/ayam-kfc-kentuky-simplekriting-dan-kriuk-nya-tahan-lama-foto-resep-utama.jpg
author: Tyler Tran
ratingvalue: 5
reviewcount: 14
recipeingredient:
- "1/2 kg daging ayam"
- "1/2 kg gandum segi3"
- "1/2 bks tepung maizena"
- "1 bks es batu2rban"
- "1 btr telur"
- "4 bks royco ayam"
- " Bumbu"
- "4 siung BP"
- "1 siung BM"
- "secukupnya Garam"
- "secukupnya Mrica"
- "secukupnya Tumbar"
- "1ruas jari Jahe"
- "1ruas jari Kunyit"
- " Bahan lumuran tambahkn Baking soda"
recipeinstructions:
- "Langkah 1, haluskan semua bumbu tambahkn 1bks royco(aq pkk blender olhnya lg bwaan bayi tangnya semutan)"
- "Mariminasi ayam, masukan setngh es batu kdlm bumbu yg sdh dituang ke wadah ayam yg sdh dibersihkn,ksih royco 1 ½bks( biarkan dlu sembri kita siapkn bahan lumuran dan bahan Kering,"
- "Bumbu kring, campurkn tepung segitiga dan maizena tmbhkn 1bks royco, aduk2 sampai rata"
- "Bahan celupan, masukn sisa es batu kdlm baskom bri secukupy air,(jngn terllu bnyak nnti gk dingin) tmbhkn royco 1bks tambah sedikit bahan kering dan beking soda tambahkn telur yg sdh di ceplok(aduk hingga rata)"
- "Selnjutnya, ambil ayam 1 persatu yg sdh di mariminasi msukan kebhan kering(bolak balik smbil di cubit2,, (sembri panaskn minyak)"
- "Angkat lalu msukn ke adonan celupan es tunggu kurleb 1mnit, lalu angkat gulingkn ke adonan kering sambil di cubit2 biar ngbntuk kriting2,"
- "Lalu angkat goreng menggunkn minyak panas, kmudian kcilkn api(jngn terllu besar) tkut daging ngk mateng, tunggu hingga kcoklatan (jngn di bolak balik terus y, bisa rontok kriting2nya, balik ayam jika sdh kring."
- "Lalu tiriskn"
- "Selmat mencoba"
categories:
- Resep
tags:
- ayam
- kfc
- kentuky

katakunci: ayam kfc kentuky 
nutrition: 181 calories
recipecuisine: Indonesian
preptime: "PT11M"
cooktime: "PT48M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam kfc/ kentuky simple,kriting dan kriuk nya tahan lama,](https://img-global.cpcdn.com/recipes/803ecb3a54cbb7cf/680x482cq70/ayam-kfc-kentuky-simplekriting-dan-kriuk-nya-tahan-lama-foto-resep-utama.jpg)

Jika kamu seorang wanita, menyuguhkan hidangan lezat buat famili merupakan suatu hal yang menyenangkan bagi kita sendiri. Tugas seorang  wanita Tidak sekadar menjaga rumah saja, tapi anda juga wajib menyediakan kebutuhan nutrisi tercukupi dan juga olahan yang dikonsumsi keluarga tercinta wajib sedap.

Di waktu  saat ini, kamu memang bisa mengorder hidangan jadi walaupun tanpa harus capek membuatnya terlebih dahulu. Tetapi ada juga orang yang memang ingin memberikan makanan yang terbaik bagi orang yang dicintainya. Karena, menghidangkan masakan yang diolah sendiri jauh lebih higienis dan bisa menyesuaikan masakan tersebut sesuai selera keluarga tercinta. 



Mungkinkah anda adalah salah satu penggemar ayam kfc/ kentuky simple,kriting dan kriuk nya tahan lama,?. Tahukah kamu, ayam kfc/ kentuky simple,kriting dan kriuk nya tahan lama, merupakan hidangan khas di Nusantara yang kini digemari oleh setiap orang dari berbagai wilayah di Nusantara. Kalian bisa memasak ayam kfc/ kentuky simple,kriting dan kriuk nya tahan lama, hasil sendiri di rumahmu dan pasti jadi hidangan favorit di hari liburmu.

Kita jangan bingung jika kamu ingin menyantap ayam kfc/ kentuky simple,kriting dan kriuk nya tahan lama,, lantaran ayam kfc/ kentuky simple,kriting dan kriuk nya tahan lama, sangat mudah untuk didapatkan dan anda pun bisa memasaknya sendiri di tempatmu. ayam kfc/ kentuky simple,kriting dan kriuk nya tahan lama, dapat dibuat memalui berbagai cara. Kini telah banyak cara kekinian yang menjadikan ayam kfc/ kentuky simple,kriting dan kriuk nya tahan lama, semakin nikmat.

Resep ayam kfc/ kentuky simple,kriting dan kriuk nya tahan lama, pun mudah dihidangkan, lho. Kamu jangan ribet-ribet untuk membeli ayam kfc/ kentuky simple,kriting dan kriuk nya tahan lama,, lantaran Kamu dapat membuatnya di rumah sendiri. Bagi Kamu yang hendak menghidangkannya, berikut resep untuk membuat ayam kfc/ kentuky simple,kriting dan kriuk nya tahan lama, yang lezat yang dapat Kamu buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Ayam kfc/ kentuky simple,kriting dan kriuk nya tahan lama,:

1. Ambil 1/2 kg daging ayam
1. Gunakan 1/2 kg gandum segi3
1. Gunakan 1/2 bks tepung maizena
1. Gunakan 1 bks es batu(2rban)
1. Gunakan 1 btr telur
1. Sediakan 4 bks royco ayam
1. Siapkan  Bumbu
1. Gunakan 4 siung BP
1. Ambil 1 siung BM
1. Ambil secukupnya Garam
1. Siapkan secukupnya Mrica
1. Siapkan secukupnya Tumbar
1. Gunakan 1ruas jari Jahe
1. Gunakan 1ruas jari Kunyit
1. Siapkan  Bahan lumuran tambahkn Baking soda




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam kfc/ kentuky simple,kriting dan kriuk nya tahan lama,:

1. Langkah 1, haluskan semua bumbu tambahkn 1bks royco(aq pkk blender olhnya lg bwaan bayi tangnya semutan)
1. Mariminasi ayam, masukan setngh es batu kdlm bumbu yg sdh dituang ke wadah ayam yg sdh dibersihkn,ksih royco 1 ½bks( biarkan dlu sembri kita siapkn bahan lumuran dan bahan Kering,
1. Bumbu kring, campurkn tepung segitiga dan maizena tmbhkn 1bks royco, aduk2 sampai rata
1. Bahan celupan, masukn sisa es batu kdlm baskom bri secukupy air,(jngn terllu bnyak nnti gk dingin) tmbhkn royco 1bks tambah sedikit bahan kering dan beking soda tambahkn telur yg sdh di ceplok(aduk hingga rata)
1. Selnjutnya, ambil ayam 1 persatu yg sdh di mariminasi msukan kebhan kering(bolak balik smbil di cubit2,, (sembri panaskn minyak)
1. Angkat lalu msukn ke adonan celupan es tunggu kurleb 1mnit, lalu angkat gulingkn ke adonan kering sambil di cubit2 biar ngbntuk kriting2,
1. Lalu angkat goreng menggunkn minyak panas, kmudian kcilkn api(jngn terllu besar) tkut daging ngk mateng, tunggu hingga kcoklatan (jngn di bolak balik terus y, bisa rontok kriting2nya, balik ayam jika sdh kring.
1. Lalu tiriskn
1. Selmat mencoba




Ternyata resep ayam kfc/ kentuky simple,kriting dan kriuk nya tahan lama, yang mantab simple ini enteng sekali ya! Kita semua dapat membuatnya. Resep ayam kfc/ kentuky simple,kriting dan kriuk nya tahan lama, Sesuai banget buat kita yang baru mau belajar memasak atau juga bagi kalian yang sudah lihai memasak.

Apakah kamu tertarik mencoba bikin resep ayam kfc/ kentuky simple,kriting dan kriuk nya tahan lama, nikmat tidak ribet ini? Kalau kamu mau, ayo kamu segera buruan siapin alat dan bahannya, setelah itu bikin deh Resep ayam kfc/ kentuky simple,kriting dan kriuk nya tahan lama, yang enak dan sederhana ini. Sungguh taidak sulit kan. 

Jadi, ketimbang kamu berfikir lama-lama, ayo kita langsung saja hidangkan resep ayam kfc/ kentuky simple,kriting dan kriuk nya tahan lama, ini. Pasti kamu gak akan nyesel sudah bikin resep ayam kfc/ kentuky simple,kriting dan kriuk nya tahan lama, mantab simple ini! Selamat mencoba dengan resep ayam kfc/ kentuky simple,kriting dan kriuk nya tahan lama, nikmat sederhana ini di rumah kalian masing-masing,oke!.

