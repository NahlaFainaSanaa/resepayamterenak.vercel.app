---
description: "Cara membuat Nasi Bakar Ayam Suwir Kemangi yang enak Untuk Jualan"
title: "Cara membuat Nasi Bakar Ayam Suwir Kemangi yang enak Untuk Jualan"
slug: 53-cara-membuat-nasi-bakar-ayam-suwir-kemangi-yang-enak-untuk-jualan
date: 2021-02-27T03:40:36.725Z
image: https://img-global.cpcdn.com/recipes/017c2742f694213e/680x482cq70/nasi-bakar-ayam-suwir-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/017c2742f694213e/680x482cq70/nasi-bakar-ayam-suwir-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/017c2742f694213e/680x482cq70/nasi-bakar-ayam-suwir-kemangi-foto-resep-utama.jpg
author: Philip Graves
ratingvalue: 4.4
reviewcount: 15
recipeingredient:
- "500 gr beras cuci bersih"
- " Air secukupnya sesuaikan jenis berasnya"
- "1 sachet Santan kara 65 ml"
- "1 batang serai"
- "2 daun salam"
- "1 lembar daun pandan potong ikat simpul"
- "1/2 sachet kecil Kaldu bubuk"
- "secukupnya Garam"
- " Bahan lainnya "
- " Ayam suwir           lihat resep"
- " Kemangi  irisan cabe merah"
- " Daun pisang  tusuk gigi"
recipeinstructions:
- "Siapkan bahan nasi gurih nya, cuci beras dan lainnya."
- "Masukkan beras, daun pandan, serai, daun salam, kaldu bubuk, garam ke magic com, tambahkan air (air disesuaikan jenis berasnya masing2 ya), masukkan juga santan nya, aduk rata, masak seperti biasa, sesekali diaduk ya, tunggu hingga klik tandanya nasi dah matang, aduk lagi, tutup dan biarkan 5 menitan, hingga nasi benar benar matang."
- "Siapkan ayam suwirnya.           (lihat resep)"
- "Siapkan 2 lembar daun pisang yang sudah dicuci dan dipanggang sebentar diatas kompor, agar daun sedikit layu dan tidak mudah sobek ketika ditusuk lidi, taruh diatas daun pisang, nasi ayam suwir dan kemangi + irisan cabe merah."
- "Gulung dan semat kedua ujung daun pisangnya (ini step paling susah, nasi bisa keluar dari samping ujung daun, hehee....perlu kesabaran yaa), panggang hingga kedua sisi daunnya kecoklatan."
- "Jika kedua sisi daun pisang sudah kecoklatan, angkat."
- "Nasi Bakar Ayam Suwir Kemangi siap disajikan."
categories:
- Resep
tags:
- nasi
- bakar
- ayam

katakunci: nasi bakar ayam 
nutrition: 279 calories
recipecuisine: Indonesian
preptime: "PT29M"
cooktime: "PT45M"
recipeyield: "2"
recipecategory: Lunch

---


![Nasi Bakar Ayam Suwir Kemangi](https://img-global.cpcdn.com/recipes/017c2742f694213e/680x482cq70/nasi-bakar-ayam-suwir-kemangi-foto-resep-utama.jpg)

Selaku seorang ibu, mempersiapkan masakan menggugah selera untuk keluarga tercinta adalah hal yang menyenangkan bagi kamu sendiri. Tugas seorang  wanita bukan cuman menangani rumah saja, namun anda pun wajib memastikan keperluan nutrisi tercukupi dan juga olahan yang disantap anak-anak mesti sedap.

Di era  sekarang, anda sebenarnya mampu mengorder hidangan praktis tanpa harus repot mengolahnya terlebih dahulu. Tetapi banyak juga orang yang selalu mau menghidangkan yang terlezat untuk orang tercintanya. Karena, menghidangkan masakan yang dibuat sendiri jauh lebih higienis dan kita juga bisa menyesuaikan masakan tersebut sesuai dengan selera keluarga. 



Mungkinkah anda adalah seorang penggemar nasi bakar ayam suwir kemangi?. Tahukah kamu, nasi bakar ayam suwir kemangi merupakan sajian khas di Nusantara yang sekarang disukai oleh banyak orang dari berbagai tempat di Indonesia. Kalian bisa memasak nasi bakar ayam suwir kemangi sendiri di rumah dan dapat dijadikan camilan favoritmu di hari libur.

Kita jangan bingung untuk menyantap nasi bakar ayam suwir kemangi, lantaran nasi bakar ayam suwir kemangi gampang untuk ditemukan dan juga kamu pun boleh menghidangkannya sendiri di rumah. nasi bakar ayam suwir kemangi dapat diolah lewat bermacam cara. Kini pun telah banyak resep modern yang membuat nasi bakar ayam suwir kemangi semakin lebih mantap.

Resep nasi bakar ayam suwir kemangi pun sangat mudah dibuat, lho. Anda tidak usah capek-capek untuk membeli nasi bakar ayam suwir kemangi, sebab Anda bisa menghidangkan di rumahmu. Untuk Kalian yang mau menghidangkannya, dibawah ini merupakan cara untuk menyajikan nasi bakar ayam suwir kemangi yang enak yang bisa Kamu coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Nasi Bakar Ayam Suwir Kemangi:

1. Siapkan 500 gr beras, cuci bersih
1. Siapkan  Air secukupnya, sesuaikan jenis berasnya
1. Ambil 1 sachet Santan kara 65 ml
1. Ambil 1 batang serai
1. Gunakan 2 daun salam
1. Gunakan 1 lembar daun pandan, potong/ ikat simpul
1. Sediakan 1/2 sachet kecil Kaldu bubuk
1. Gunakan secukupnya Garam
1. Gunakan  Bahan lainnya :
1. Sediakan  Ayam suwir           (lihat resep)
1. Gunakan  Kemangi + irisan cabe merah
1. Siapkan  Daun pisang + tusuk gigi




<!--inarticleads2-->

##### Cara menyiapkan Nasi Bakar Ayam Suwir Kemangi:

1. Siapkan bahan nasi gurih nya, cuci beras dan lainnya.
<img src="https://img-global.cpcdn.com/steps/94bc99a02f715afa/160x128cq70/nasi-bakar-ayam-suwir-kemangi-langkah-memasak-1-foto.jpg" alt="Nasi Bakar Ayam Suwir Kemangi">1. Masukkan beras, daun pandan, serai, daun salam, kaldu bubuk, garam ke magic com, tambahkan air (air disesuaikan jenis berasnya masing2 ya), masukkan juga santan nya, aduk rata, masak seperti biasa, sesekali diaduk ya, tunggu hingga klik tandanya nasi dah matang, aduk lagi, tutup dan biarkan 5 menitan, hingga nasi benar benar matang.
1. Siapkan ayam suwirnya. -           (lihat resep)
1. Siapkan 2 lembar daun pisang yang sudah dicuci dan dipanggang sebentar diatas kompor, agar daun sedikit layu dan tidak mudah sobek ketika ditusuk lidi, taruh diatas daun pisang, nasi ayam suwir dan kemangi + irisan cabe merah.
1. Gulung dan semat kedua ujung daun pisangnya (ini step paling susah, nasi bisa keluar dari samping ujung daun, hehee....perlu kesabaran yaa), panggang hingga kedua sisi daunnya kecoklatan.
1. Jika kedua sisi daun pisang sudah kecoklatan, angkat.
1. Nasi Bakar Ayam Suwir Kemangi siap disajikan.




Wah ternyata resep nasi bakar ayam suwir kemangi yang mantab simple ini mudah banget ya! Kita semua dapat memasaknya. Cara Membuat nasi bakar ayam suwir kemangi Cocok sekali buat kamu yang sedang belajar memasak ataupun juga bagi kalian yang telah ahli memasak.

Apakah kamu ingin mulai mencoba buat resep nasi bakar ayam suwir kemangi nikmat simple ini? Kalau mau, yuk kita segera buruan siapkan alat dan bahan-bahannya, lantas bikin deh Resep nasi bakar ayam suwir kemangi yang lezat dan sederhana ini. Sangat mudah kan. 

Maka, ketimbang kalian berlama-lama, maka langsung aja sajikan resep nasi bakar ayam suwir kemangi ini. Pasti anda tak akan menyesal sudah bikin resep nasi bakar ayam suwir kemangi mantab tidak rumit ini! Selamat berkreasi dengan resep nasi bakar ayam suwir kemangi lezat tidak rumit ini di tempat tinggal kalian masing-masing,ya!.

