---
description: "Cara membuat Steak Ayam Crispy yang enak Untuk Jualan"
title: "Cara membuat Steak Ayam Crispy yang enak Untuk Jualan"
slug: 264-cara-membuat-steak-ayam-crispy-yang-enak-untuk-jualan
date: 2021-06-09T06:59:01.737Z
image: https://img-global.cpcdn.com/recipes/d3fe478b891a64a9/680x482cq70/steak-ayam-crispy-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d3fe478b891a64a9/680x482cq70/steak-ayam-crispy-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d3fe478b891a64a9/680x482cq70/steak-ayam-crispy-foto-resep-utama.jpg
author: Emma Newton
ratingvalue: 4
reviewcount: 3
recipeingredient:
- " Bahan ayam crispy "
- "8 potong ayam ungkep blh pki dada ayam fillet"
- "8 sdm tepung terigu serbaguna"
- "3 sdm maizena"
- "1 atau 2 butir telur"
- "1/4 sdt garam"
- "1 sdt kaldu bubuk"
- "1/4 sdt lada bubuk"
- " Bahan saos "
- "1 siung bawang putih cincang"
- "1/3 siung bawang bombai cincang"
- "3 buah cengkeh"
- "60 gr gula merah"
- "25 gr asam jawa"
- "400 ml air"
- "1 sdm maizena"
- "Sejumput pala"
- "1/4 sdt lada hitam"
- "1 sdt garam"
- "2 sdt gula pasir"
- "1 sdm margarin"
- " Bahan pelengkapnya "
- "2 buah kentang"
- "1/4 sdt garam"
recipeinstructions:
- "Siapkan bahan. Ayam yang sudah diungkep. Telur ayam yang di kocok. Kentang yang sudah di potong² dan di cuci bersih."
- "Siapkan juga bumbu yang lain untuk saosnya. Siapkan wadah,masukan tepung terigu,maizena, lada,garam,kaldu bubuk lalu aduk rata,baru masukan ayam,lalu lumuri ayam dengan tepung."
- "Angkat lalu masukan ayam ke kocokan telur hingga rata baru angkat lagi masukan ayam ke adonan tepung,lumuri lagi ayam dengan tepung hingga rata."
- "Lakukan hal yang sama dengan ayam yang lain. Panaskan minyak,lalu goreng ayam yang sudah di tepungi tadi."
- "Bila sudah matang angkat dan tiriskan. Utk membuat saosnya,panaskan 1 sdm margarin,lalu masukan bawang bombai dan bawang putih,tumis hingga harum."
- "Jika sudah masukan semua bahan saos,masak hingga mendidih jangan lupa di aduk²,bila sudah matang angkat."
- "Panaskan minyak,taburi garam kentangnya lalu aduk rata dan goreng di minyak panas,bolak balik hingga matang merata,lalu angkat"
- "Siapkan wadah,masukan kentang dan ayam,lalu siram dengan saosnya.steak ayam crispy siap di sajikan."
categories:
- Resep
tags:
- steak
- ayam
- crispy

katakunci: steak ayam crispy 
nutrition: 233 calories
recipecuisine: Indonesian
preptime: "PT27M"
cooktime: "PT51M"
recipeyield: "1"
recipecategory: Dinner

---


![Steak Ayam Crispy](https://img-global.cpcdn.com/recipes/d3fe478b891a64a9/680x482cq70/steak-ayam-crispy-foto-resep-utama.jpg)

Sebagai seorang yang hobi memasak, menyediakan masakan nikmat pada orang tercinta adalah suatu hal yang sangat menyenangkan untuk anda sendiri. Peran seorang  wanita Tidak sekadar menjaga rumah saja, tapi anda juga wajib memastikan keperluan nutrisi tercukupi dan hidangan yang dimakan anak-anak wajib nikmat.

Di masa  saat ini, kalian memang bisa membeli olahan yang sudah jadi meski tidak harus capek mengolahnya terlebih dahulu. Namun banyak juga orang yang selalu mau memberikan yang terlezat bagi keluarganya. Lantaran, menghidangkan masakan sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan masakan tersebut sesuai dengan kesukaan keluarga tercinta. 



Apakah anda adalah salah satu penggemar steak ayam crispy?. Tahukah kamu, steak ayam crispy merupakan sajian khas di Nusantara yang sekarang disukai oleh banyak orang di hampir setiap daerah di Indonesia. Anda bisa memasak steak ayam crispy buatan sendiri di rumah dan boleh dijadikan makanan favorit di akhir pekanmu.

Kalian tidak perlu bingung jika kamu ingin menyantap steak ayam crispy, karena steak ayam crispy tidak sulit untuk dicari dan anda pun bisa mengolahnya sendiri di tempatmu. steak ayam crispy dapat dimasak dengan beraneka cara. Kini pun sudah banyak resep kekinian yang membuat steak ayam crispy semakin lebih enak.

Resep steak ayam crispy juga sangat mudah dibuat, lho. Anda jangan ribet-ribet untuk membeli steak ayam crispy, tetapi Anda dapat menghidangkan ditempatmu. Untuk Kamu yang ingin mencobanya, berikut ini resep menyajikan steak ayam crispy yang nikamat yang mampu Kita hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Steak Ayam Crispy:

1. Gunakan  Bahan ayam crispy :
1. Gunakan 8 potong ayam ungkep (blh pki dada ayam fillet)
1. Ambil 8 sdm tepung terigu serbaguna
1. Siapkan 3 sdm maizena
1. Siapkan 1 atau 2 butir telur
1. Gunakan 1/4 sdt garam
1. Sediakan 1 sdt kaldu bubuk
1. Ambil 1/4 sdt lada bubuk
1. Sediakan  Bahan saos :
1. Sediakan 1 siung bawang putih cincang
1. Gunakan 1/3 siung bawang bombai cincang
1. Siapkan 3 buah cengkeh
1. Siapkan 60 gr gula merah
1. Siapkan 25 gr asam jawa
1. Siapkan 400 ml air
1. Gunakan 1 sdm maizena
1. Siapkan Sejumput pala
1. Siapkan 1/4 sdt lada hitam
1. Ambil 1 sdt garam
1. Gunakan 2 sdt gula pasir
1. Siapkan 1 sdm margarin
1. Ambil  Bahan pelengkapnya :
1. Ambil 2 buah kentang
1. Gunakan 1/4 sdt garam




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Steak Ayam Crispy:

1. Siapkan bahan. - Ayam yang sudah diungkep. - Telur ayam yang di kocok. - Kentang yang sudah di potong² dan di cuci bersih.
1. Siapkan juga bumbu yang lain untuk saosnya. - Siapkan wadah,masukan tepung terigu,maizena, - lada,garam,kaldu bubuk lalu aduk rata,baru masukan ayam,lalu lumuri ayam dengan tepung.
1. Angkat lalu masukan ayam ke kocokan telur hingga rata baru angkat lagi masukan ayam ke adonan tepung,lumuri lagi ayam dengan tepung hingga rata.
1. Lakukan hal yang sama dengan ayam yang lain. - Panaskan minyak,lalu goreng ayam yang sudah di tepungi tadi.
1. Bila sudah matang angkat dan tiriskan. - Utk membuat saosnya,panaskan 1 sdm margarin,lalu masukan bawang bombai dan bawang putih,tumis hingga harum.
1. Jika sudah masukan semua bahan saos,masak hingga mendidih jangan lupa di aduk²,bila sudah matang angkat.
1. Panaskan minyak,taburi garam kentangnya lalu aduk rata dan goreng di minyak panas,bolak balik hingga matang merata,lalu angkat
1. Siapkan wadah,masukan kentang dan ayam,lalu siram dengan saosnya.steak ayam crispy siap di sajikan.




Wah ternyata cara buat steak ayam crispy yang enak tidak ribet ini mudah banget ya! Kamu semua bisa menghidangkannya. Cara buat steak ayam crispy Sesuai banget untuk kamu yang baru belajar memasak maupun juga untuk kalian yang sudah lihai memasak.

Tertarik untuk mencoba bikin resep steak ayam crispy nikmat sederhana ini? Kalau anda tertarik, mending kamu segera menyiapkan peralatan dan bahannya, lantas bikin deh Resep steak ayam crispy yang nikmat dan sederhana ini. Betul-betul gampang kan. 

Oleh karena itu, daripada kita berlama-lama, yuk langsung aja sajikan resep steak ayam crispy ini. Dijamin anda tiidak akan menyesal sudah membuat resep steak ayam crispy enak tidak ribet ini! Selamat mencoba dengan resep steak ayam crispy nikmat simple ini di rumah kalian sendiri,ya!.

