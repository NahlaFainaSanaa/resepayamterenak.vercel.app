---
description: "Resep Kari Ayam yang nikmat Untuk Jualan"
title: "Resep Kari Ayam yang nikmat Untuk Jualan"
slug: 426-resep-kari-ayam-yang-nikmat-untuk-jualan
date: 2021-03-17T13:25:30.369Z
image: https://img-global.cpcdn.com/recipes/04e2c0ecad04a2a4/680x482cq70/kari-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/04e2c0ecad04a2a4/680x482cq70/kari-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/04e2c0ecad04a2a4/680x482cq70/kari-ayam-foto-resep-utama.jpg
author: Maude Powell
ratingvalue: 4.7
reviewcount: 6
recipeingredient:
- "1/2 ekor ayam potong sesuai seleracuci bersih"
- "5 bh kentang kecilsdg potong sesuai selera jangan kecil x"
- " bisa hancur bila diaduk terus"
- "1/2 bh kelapa peras jdi 2 bagian kental dan encer"
- " 1000ml encer 300ml kental"
- " Bahan ulekblender"
- "1 jempol kunyit buang kulit potong"
- "1 ruas lengkuas buang kulit potong"
- "1 ruas jahebuang kulit potong"
- "1 bh cabai kering cuci bersih buang biji"
- "5 siung bamer"
- "4 siung baput"
- "3 bh kemiri"
- "1/4 sdm ketumbar"
- "1/4 sdt merica"
- " "
- "1-2 btg sereh geprek"
- "3 lbr daun jeruk"
- " Pelengkap 1 bks rempahBlawang kapulaga dll"
- "1/2 sdm garam"
- "1/2 sdm gula"
- "1/2 sdt royco"
- " Noted kurang asin bisa ditambahkan garam"
- " Minyak utk menumis bumbu"
recipeinstructions:
- "Kompor 1: siapkan panci Didihkan santan encer(bisa diganti air, bila tdk suka terlalu lemak, atau susu ya moms). Kompor 2: panaskan minyak pd wajan tumis bumbu halus. Bila air santan sdh mendidih, masukan ayam dan bumbu halusnya. Aduk, beri perasa pd kari nya. Kemudian masak smp ayam 1/2 matang, masukan kentang, masak smp matang ayam dan kentang, baru santan kentalnya. Bila sdh mendidih dan rasa sdh pas. Matikan kompor. Taburi dgn bwg goreng. Selamat mencoba. Note: dijaga jgn smp pecah santan."
categories:
- Resep
tags:
- kari
- ayam

katakunci: kari ayam 
nutrition: 182 calories
recipecuisine: Indonesian
preptime: "PT28M"
cooktime: "PT59M"
recipeyield: "4"
recipecategory: Dessert

---


![Kari Ayam](https://img-global.cpcdn.com/recipes/04e2c0ecad04a2a4/680x482cq70/kari-ayam-foto-resep-utama.jpg)

Sebagai seorang wanita, mempersiapkan olahan lezat bagi keluarga tercinta adalah hal yang menggembirakan bagi anda sendiri. Tugas seorang ibu Tidak hanya mengerjakan pekerjaan rumah saja, tetapi anda juga harus memastikan keperluan nutrisi tercukupi dan panganan yang dikonsumsi orang tercinta wajib menggugah selera.

Di waktu  sekarang, kamu memang bisa membeli masakan jadi tidak harus capek mengolahnya lebih dulu. Tapi ada juga mereka yang selalu ingin memberikan hidangan yang terenak bagi keluarganya. Lantaran, memasak sendiri akan jauh lebih higienis dan bisa menyesuaikan masakan tersebut sesuai dengan kesukaan keluarga. 



Apakah anda salah satu penggemar kari ayam?. Asal kamu tahu, kari ayam merupakan hidangan khas di Nusantara yang saat ini disukai oleh setiap orang di hampir setiap tempat di Indonesia. Kalian bisa menghidangkan kari ayam sendiri di rumahmu dan pasti jadi camilan kegemaranmu di hari libur.

Kamu jangan bingung jika kamu ingin memakan kari ayam, sebab kari ayam mudah untuk ditemukan dan juga kamu pun bisa membuatnya sendiri di rumah. kari ayam dapat dimasak dengan berbagai cara. Kini sudah banyak banget resep modern yang menjadikan kari ayam semakin mantap.

Resep kari ayam pun sangat gampang dibikin, lho. Anda jangan capek-capek untuk membeli kari ayam, tetapi Kamu dapat menyiapkan di rumah sendiri. Bagi Kamu yang mau menyajikannya, di bawah ini adalah cara menyajikan kari ayam yang enak yang dapat Anda coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Kari Ayam:

1. Siapkan 1/2 ekor ayam, potong sesuai selera,cuci bersih
1. Ambil 5 bh kentang kecil/sdg potong sesuai selera, jangan kecil x
1. Sediakan  (bisa hancur bila diaduk² terus)
1. Gunakan 1/2 bh kelapa, peras jdi 2 bagian, kental dan encer
1. Gunakan  (1.000ml encer. 300ml kental)
1. Ambil  Bahan ulek/blender:
1. Siapkan 1 jempol kunyit, buang kulit, potong²
1. Sediakan 1 ruas lengkuas, buang kulit, potong²
1. Siapkan 1 ruas jahe,buang kulit, potong²
1. Siapkan 1 bh cabai kering, cuci bersih, buang biji
1. Gunakan 5 siung bamer
1. Siapkan 4 siung baput
1. Gunakan 3 bh kemiri
1. Gunakan 1/4 sdm ketumbar
1. Ambil 1/4 sdt merica
1. Gunakan  ...
1. Siapkan 1-2 btg sereh, geprek
1. Siapkan 3 lbr daun jeruk
1. Gunakan  Pelengkap :1 bks rempah²(B.lawang, kapulaga, dll)
1. Siapkan 1/2 sdm garam
1. Sediakan 1/2 sdm gula
1. Gunakan 1/2 sdt royco
1. Sediakan  Noted: kurang asin, bisa ditambahkan garam
1. Gunakan  Minyak utk menumis bumbu




<!--inarticleads2-->

##### Cara menyiapkan Kari Ayam:

1. Kompor 1: siapkan panci Didihkan santan encer(bisa diganti air, bila tdk suka terlalu lemak, atau susu ya moms). Kompor 2: panaskan minyak pd wajan tumis bumbu halus. Bila air santan sdh mendidih, masukan ayam dan bumbu halusnya. Aduk, beri perasa pd kari nya. Kemudian masak smp ayam 1/2 matang, masukan kentang, masak smp matang ayam dan kentang, baru santan kentalnya. Bila sdh mendidih dan rasa sdh pas. Matikan kompor. Taburi dgn bwg goreng. Selamat mencoba. Note: dijaga jgn smp pecah santan.




Ternyata cara membuat kari ayam yang lezat tidak ribet ini mudah banget ya! Kamu semua bisa menghidangkannya. Cara Membuat kari ayam Sangat sesuai banget untuk kamu yang baru akan belajar memasak maupun untuk kamu yang telah ahli dalam memasak.

Tertarik untuk mulai mencoba buat resep kari ayam nikmat simple ini? Kalau ingin, yuk kita segera menyiapkan peralatan dan bahannya, maka bikin deh Resep kari ayam yang lezat dan sederhana ini. Sangat taidak sulit kan. 

Maka, ketimbang kita diam saja, maka kita langsung bikin resep kari ayam ini. Pasti anda tak akan menyesal bikin resep kari ayam lezat tidak rumit ini! Selamat berkreasi dengan resep kari ayam enak simple ini di tempat tinggal sendiri,oke!.

