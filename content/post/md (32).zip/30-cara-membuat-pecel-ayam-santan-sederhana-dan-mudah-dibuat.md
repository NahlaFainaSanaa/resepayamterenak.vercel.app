---
description: "Cara membuat Pecel Ayam Santan Sederhana dan Mudah Dibuat"
title: "Cara membuat Pecel Ayam Santan Sederhana dan Mudah Dibuat"
slug: 30-cara-membuat-pecel-ayam-santan-sederhana-dan-mudah-dibuat
date: 2021-06-18T06:04:18.849Z
image: https://img-global.cpcdn.com/recipes/d45b91dde0af6275/680x482cq70/pecel-ayam-santan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d45b91dde0af6275/680x482cq70/pecel-ayam-santan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d45b91dde0af6275/680x482cq70/pecel-ayam-santan-foto-resep-utama.jpg
author: Florence Delgado
ratingvalue: 4
reviewcount: 9
recipeingredient:
- "500 grm ayam dipotong jd 6 bagian"
- "2 kotak tahu dipotong kotak"
- "1 mangkok daun kemangi"
- "1 aachet santan kara"
- " Bumbu Halus"
- "8 butir bawang merah"
- "2 butir bawang putih"
- "2 buah cabe merah"
- "10 buah cabe rawit"
- "1 ruas kunyit"
- "3 butir kemiri"
- "3 cm kencur"
- "secukupnya Garam dan gula"
- "secukupnya Kaldu bubuk"
- "2 lmbr daun jeruk"
- "2 lembar daun salam"
- "1 batang serai"
- "secukupnya Air"
recipeinstructions:
- "Panaskan minyak lalu tumis bumbu halus bersama daun salam, daun jeruk dan serai geprek, tumis sampai harum"
- "Tuang air secukupnya lalu masukkan ayam dan tahu goreng, biarkan mendidih hingga ayam matang, tambahkan garam, gula dan kaldu bubuk"
- "Setelah ayam matang, masukkan santan, sambil diaduk aduk hingga mendidih, jangan lupa test rasa"
- "Terakhir masukkan kemangi aduk aduk sebentar hingga kemangi layu dan matikan kompor, pecel ayam santan siap disajikan"
categories:
- Resep
tags:
- pecel
- ayam
- santan

katakunci: pecel ayam santan 
nutrition: 250 calories
recipecuisine: Indonesian
preptime: "PT11M"
cooktime: "PT32M"
recipeyield: "4"
recipecategory: Dessert

---


![Pecel Ayam Santan](https://img-global.cpcdn.com/recipes/d45b91dde0af6275/680x482cq70/pecel-ayam-santan-foto-resep-utama.jpg)

Sebagai seorang wanita, menyajikan olahan enak buat keluarga tercinta merupakan suatu hal yang memuaskan untuk anda sendiri. Peran seorang  wanita bukan cuman mengerjakan pekerjaan rumah saja, namun anda juga harus memastikan kebutuhan nutrisi terpenuhi dan juga santapan yang disantap orang tercinta mesti mantab.

Di zaman  sekarang, kamu memang bisa mengorder olahan praktis walaupun tanpa harus repot mengolahnya lebih dulu. Namun banyak juga orang yang selalu ingin menghidangkan yang terlezat bagi orang tercintanya. Lantaran, memasak yang dibuat sendiri jauh lebih bersih dan kita pun bisa menyesuaikan masakan tersebut sesuai dengan masakan kesukaan orang tercinta. 



Mungkinkah anda adalah salah satu penyuka pecel ayam santan?. Asal kamu tahu, pecel ayam santan adalah hidangan khas di Indonesia yang saat ini disukai oleh kebanyakan orang dari hampir setiap daerah di Nusantara. Kalian dapat menghidangkan pecel ayam santan kreasi sendiri di rumahmu dan boleh dijadikan camilan favoritmu di akhir pekan.

Kamu tak perlu bingung jika kamu ingin memakan pecel ayam santan, lantaran pecel ayam santan tidak sukar untuk dicari dan anda pun bisa membuatnya sendiri di rumah. pecel ayam santan dapat diolah dengan bermacam cara. Kini pun ada banyak sekali resep modern yang membuat pecel ayam santan semakin lebih mantap.

Resep pecel ayam santan pun gampang sekali dibikin, lho. Kamu tidak usah repot-repot untuk membeli pecel ayam santan, sebab Kamu dapat menyiapkan sendiri di rumah. Untuk Kalian yang mau membuatnya, di bawah ini adalah cara menyajikan pecel ayam santan yang nikamat yang bisa Anda buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Pecel Ayam Santan:

1. Sediakan 500 grm ayam dipotong jd 6 bagian
1. Sediakan 2 kotak tahu dipotong kotak&#34;
1. Sediakan 1 mangkok daun kemangi
1. Sediakan 1 aachet santan kara
1. Siapkan  Bumbu Halus
1. Ambil 8 butir bawang merah
1. Gunakan 2 butir bawang putih
1. Gunakan 2 buah cabe merah
1. Ambil 10 buah cabe rawit
1. Gunakan 1 ruas kunyit
1. Siapkan 3 butir kemiri
1. Ambil 3 cm kencur
1. Sediakan secukupnya Garam dan gula
1. Gunakan secukupnya Kaldu bubuk
1. Siapkan 2 lmbr daun jeruk
1. Ambil 2 lembar daun salam
1. Ambil 1 batang serai
1. Gunakan secukupnya Air




<!--inarticleads2-->

##### Cara menyiapkan Pecel Ayam Santan:

1. Panaskan minyak lalu tumis bumbu halus bersama daun salam, daun jeruk dan serai geprek, tumis sampai harum
<img src="https://img-global.cpcdn.com/steps/4e13d9b7dbcb5071/160x128cq70/pecel-ayam-santan-langkah-memasak-1-foto.jpg" alt="Pecel Ayam Santan">1. Tuang air secukupnya lalu masukkan ayam dan tahu goreng, biarkan mendidih hingga ayam matang, tambahkan garam, gula dan kaldu bubuk
1. Setelah ayam matang, masukkan santan, sambil diaduk aduk hingga mendidih, jangan lupa test rasa
1. Terakhir masukkan kemangi aduk aduk sebentar hingga kemangi layu dan matikan kompor, pecel ayam santan siap disajikan




Wah ternyata cara buat pecel ayam santan yang mantab simple ini enteng banget ya! Kamu semua bisa mencobanya. Cara Membuat pecel ayam santan Sesuai sekali untuk kalian yang sedang belajar memasak maupun juga untuk kalian yang sudah pandai memasak.

Tertarik untuk mulai mencoba buat resep pecel ayam santan nikmat simple ini? Kalau kalian tertarik, ayo kalian segera buruan siapin alat-alat dan bahan-bahannya, lalu buat deh Resep pecel ayam santan yang mantab dan simple ini. Benar-benar gampang kan. 

Maka, ketimbang anda berfikir lama-lama, hayo kita langsung saja sajikan resep pecel ayam santan ini. Dijamin kalian tak akan nyesel sudah membuat resep pecel ayam santan enak tidak rumit ini! Selamat mencoba dengan resep pecel ayam santan mantab tidak rumit ini di rumah kalian sendiri,ya!.

