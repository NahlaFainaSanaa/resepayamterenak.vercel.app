---
description: "Cara membuat Ayam Goreng Crispy Ala KFC (Awet Renyah) Sederhana dan Mudah Dibuat"
title: "Cara membuat Ayam Goreng Crispy Ala KFC (Awet Renyah) Sederhana dan Mudah Dibuat"
slug: 104-cara-membuat-ayam-goreng-crispy-ala-kfc-awet-renyah-sederhana-dan-mudah-dibuat
date: 2021-04-14T13:06:26.253Z
image: https://img-global.cpcdn.com/recipes/d304a44bc927d42c/680x482cq70/ayam-goreng-crispy-ala-kfc-awet-renyah-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d304a44bc927d42c/680x482cq70/ayam-goreng-crispy-ala-kfc-awet-renyah-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d304a44bc927d42c/680x482cq70/ayam-goreng-crispy-ala-kfc-awet-renyah-foto-resep-utama.jpg
author: Adrian Bridges
ratingvalue: 3.6
reviewcount: 7
recipeingredient:
- "1 kg ayam"
- "1 buah jeruk nipis ambil airnya"
- "1 L air es"
- "Secukupnya minyak goreng me 1 L"
- " Bumbu marinasi"
- "5 siung bawang putih haluskan"
- "2-2,5 sdt garam"
- "1 sdt gula pasir"
- "1/2 sdt merica bubuk"
- "1 sdt cabai bubuk"
- "200-250 ml susu cair me 1 bks susu bubuk  200 ml air"
- "1 sdm air jeruk nipis"
- " Tepung kering utk 2 kali"
- "1 kg tepung terigu protein tinggi"
- "2-2,5 sdt garam"
- "2 sdt paprika bubuk"
- "2 sdt Italian herb seasoning oregano basil bwg putih peterse"
- "1 sdt lada hitam"
- "1 sdt merica bubuk"
- "2-3 sdt kaldu bubuk"
- "1 sdt cabai bubuk"
- "1 sdt soda kue"
recipeinstructions:
- "Cuci bersih ayam, beri air jeruk nipis, diamkan beberapa saat. Kemudian bilas kembali dengan air bersih, tiriskan. Selanjutnya beri ayam dengan garam, bawang putih, merica bubuk dan cabai bubuk. Remas-remas supaya bumbu meresap. Kmdn tuang campuran susu cair dan 1 sdm air jeruk lemon/nipis. Simpan ayam dalam wadah kedap udara dan rendam minimal 2 jam dalam kulkas (sy semalaman)."
- "Campur dalam wadah besar semua bahan tepung kering, kemudian aduk sampai rata. Bagi tepung menjadi 2 bagian, satu utk menepungi ayam dan yg satu kita tambahkan jika dirasa tepung kurang. Jadi tepung 1 kg jgn dipakai langsung semua. Karena utk 1 kg ayam sebenarnya hanya membutuhkan 500-600 gr tepung saja, dan itupun akan sisa juga. Jadi jika bikin 1 kg tepung, sisanya bisa disimpan utk stok. Note: sendok takar yg sy pakai."
- "Siapkan semua bahan yg akan dipakai utk menepungi ayam. Keluarkan ayam dari dalam kulkas, kmdn masukkan beberapa potong ayam ke dalam tepung kering, aduk rata dgn cara diaduk-aduk tetapi jangan ditekan/diremas supaya tepung nantinya tidak keras. Cukup diaduk dan disiram2kan tepung diatas ayam."
- "Kemudian angkat ayam dan kibas-kibaskan supaya tepung yg tidak menempel lepas. Celupkan sebentar saja ayam ke dalam air es, angkat dan tiriskan dalam saringan."
- "Setelah air tiris, masukkan kembali ayam ke dalam tepung kering, aduk perlahan dan tidak perlu diremas-remas. Celupkan lagi ke dalam air es, tiriskan dalam saringan dan balur kembali dengan tepung kering. Lakukan 2-3X penepungan utk hasil tepung yg keriting dan tebal. Sebelum digoreng, kibas-kibaskan ayam supaya tepung yg tdk menempel lepas."
- "Segera goreng ayam yg sudah ditepungi ke dalam minyak yg banyak dan benar-benar panas (saat dimasukkan tepung, minyak berbuih banyak). Saat menggoreng, ayam harus tenggelam dalam minyak. Untuk itu saya menggunakan panci kecil utk menggoreng. Di 5 menit pertama goreng dengan api sedang cenderung besar, setelah 5 menit, kecilkan api dan goreng sampai ayam matang dan berwarna kuning kecoklatan. Waktu menggoreng ayam kurang lebih 15 menit dan dgn suhu 170°C."
- "Jika tepung kering sudah banyak yg menggumpal, sebelum tepung kering kita gunakan kembali utk menepungi ayam, ayak terlebih dahulu tepung supaya hasil ayam krispinya tidak keras. Dan tambahkan secukupnya tepung kering yg baru jika dirasa tepung tidak cukup. Gumpalan tepung bisa kita goreng terpisah sebagai kriuk, dan yg halus kita gunakan kembali."
- "Setelah ayam matang, angkat dan tiriskan. Hasil ayam yg sebelah kiri yg ditepung 3 kali dan yg kanan yg ditepung 2 kali."
- "Tepungnya krispi dan daging ayamnya juicy lembab, ga kering."
categories:
- Resep
tags:
- ayam
- goreng
- crispy

katakunci: ayam goreng crispy 
nutrition: 131 calories
recipecuisine: Indonesian
preptime: "PT26M"
cooktime: "PT43M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Goreng Crispy Ala KFC (Awet Renyah)](https://img-global.cpcdn.com/recipes/d304a44bc927d42c/680x482cq70/ayam-goreng-crispy-ala-kfc-awet-renyah-foto-resep-utama.jpg)

Sebagai seorang istri, mempersiapkan masakan sedap buat famili merupakan hal yang sangat menyenangkan untuk kamu sendiri. Tugas seorang  wanita bukan sekedar mengatur rumah saja, namun anda pun wajib menyediakan kebutuhan gizi terpenuhi dan masakan yang dimakan keluarga tercinta wajib nikmat.

Di era  sekarang, kita memang mampu mengorder hidangan jadi tanpa harus susah memasaknya terlebih dahulu. Tapi banyak juga lho orang yang selalu ingin memberikan yang terenak untuk keluarganya. Pasalnya, menghidangkan masakan yang diolah sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan masakan tersebut sesuai selera orang tercinta. 



Mungkinkah anda salah satu penikmat ayam goreng crispy ala kfc (awet renyah)?. Asal kamu tahu, ayam goreng crispy ala kfc (awet renyah) adalah hidangan khas di Nusantara yang kini disukai oleh banyak orang di hampir setiap daerah di Nusantara. Anda dapat memasak ayam goreng crispy ala kfc (awet renyah) hasil sendiri di rumah dan boleh dijadikan hidangan kegemaranmu di hari libur.

Kalian jangan bingung jika kamu ingin menyantap ayam goreng crispy ala kfc (awet renyah), lantaran ayam goreng crispy ala kfc (awet renyah) tidak sulit untuk ditemukan dan juga kamu pun dapat memasaknya sendiri di rumah. ayam goreng crispy ala kfc (awet renyah) dapat dimasak dengan berbagai cara. Kini pun ada banyak banget cara modern yang menjadikan ayam goreng crispy ala kfc (awet renyah) lebih lezat.

Resep ayam goreng crispy ala kfc (awet renyah) pun mudah sekali untuk dibikin, lho. Kalian tidak perlu ribet-ribet untuk membeli ayam goreng crispy ala kfc (awet renyah), lantaran Anda dapat menyiapkan ditempatmu. Untuk Kalian yang akan mencobanya, di bawah ini adalah resep untuk menyajikan ayam goreng crispy ala kfc (awet renyah) yang mantab yang bisa Kalian coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Ayam Goreng Crispy Ala KFC (Awet Renyah):

1. Sediakan 1 kg ayam
1. Sediakan 1 buah jeruk nipis, ambil airnya
1. Gunakan 1 L air es
1. Sediakan Secukupnya minyak goreng (me: 1 L)
1. Ambil  Bumbu marinasi:
1. Gunakan 5 siung bawang putih, haluskan
1. Gunakan 2-2,5 sdt garam
1. Sediakan 1 sdt gula pasir
1. Gunakan 1/2 sdt merica bubuk
1. Siapkan 1 sdt cabai bubuk
1. Ambil 200-250 ml susu cair (me: 1 bks susu bubuk + 200 ml air)
1. Sediakan 1 sdm air jeruk nipis
1. Sediakan  Tepung kering (utk 2 kali):
1. Gunakan 1 kg tepung terigu protein tinggi
1. Siapkan 2-2,5 sdt garam
1. Siapkan 2 sdt paprika bubuk
1. Ambil 2 sdt Italian herb seasoning (oregano, basil, bwg putih, peterse
1. Sediakan 1 sdt lada hitam
1. Sediakan 1 sdt merica bubuk
1. Sediakan 2-3 sdt kaldu bubuk
1. Ambil 1 sdt cabai bubuk
1. Sediakan 1 sdt soda kue




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Goreng Crispy Ala KFC (Awet Renyah):

1. Cuci bersih ayam, beri air jeruk nipis, diamkan beberapa saat. Kemudian bilas kembali dengan air bersih, tiriskan. Selanjutnya beri ayam dengan garam, bawang putih, merica bubuk dan cabai bubuk. Remas-remas supaya bumbu meresap. Kmdn tuang campuran susu cair dan 1 sdm air jeruk lemon/nipis. Simpan ayam dalam wadah kedap udara dan rendam minimal 2 jam dalam kulkas (sy semalaman).
1. Campur dalam wadah besar semua bahan tepung kering, kemudian aduk sampai rata. Bagi tepung menjadi 2 bagian, satu utk menepungi ayam dan yg satu kita tambahkan jika dirasa tepung kurang. Jadi tepung 1 kg jgn dipakai langsung semua. Karena utk 1 kg ayam sebenarnya hanya membutuhkan 500-600 gr tepung saja, dan itupun akan sisa juga. Jadi jika bikin 1 kg tepung, sisanya bisa disimpan utk stok. Note: sendok takar yg sy pakai.
1. Siapkan semua bahan yg akan dipakai utk menepungi ayam. Keluarkan ayam dari dalam kulkas, kmdn masukkan beberapa potong ayam ke dalam tepung kering, aduk rata dgn cara diaduk-aduk tetapi jangan ditekan/diremas supaya tepung nantinya tidak keras. Cukup diaduk dan disiram2kan tepung diatas ayam.
1. Kemudian angkat ayam dan kibas-kibaskan supaya tepung yg tidak menempel lepas. Celupkan sebentar saja ayam ke dalam air es, angkat dan tiriskan dalam saringan.
1. Setelah air tiris, masukkan kembali ayam ke dalam tepung kering, aduk perlahan dan tidak perlu diremas-remas. Celupkan lagi ke dalam air es, tiriskan dalam saringan dan balur kembali dengan tepung kering. Lakukan 2-3X penepungan utk hasil tepung yg keriting dan tebal. Sebelum digoreng, kibas-kibaskan ayam supaya tepung yg tdk menempel lepas.
1. Segera goreng ayam yg sudah ditepungi ke dalam minyak yg banyak dan benar-benar panas (saat dimasukkan tepung, minyak berbuih banyak). Saat menggoreng, ayam harus tenggelam dalam minyak. Untuk itu saya menggunakan panci kecil utk menggoreng. Di 5 menit pertama goreng dengan api sedang cenderung besar, setelah 5 menit, kecilkan api dan goreng sampai ayam matang dan berwarna kuning kecoklatan. Waktu menggoreng ayam kurang lebih 15 menit dan dgn suhu 170°C.
1. Jika tepung kering sudah banyak yg menggumpal, sebelum tepung kering kita gunakan kembali utk menepungi ayam, ayak terlebih dahulu tepung supaya hasil ayam krispinya tidak keras. Dan tambahkan secukupnya tepung kering yg baru jika dirasa tepung tidak cukup. Gumpalan tepung bisa kita goreng terpisah sebagai kriuk, dan yg halus kita gunakan kembali.
1. Setelah ayam matang, angkat dan tiriskan. Hasil ayam yg sebelah kiri yg ditepung 3 kali dan yg kanan yg ditepung 2 kali.
1. Tepungnya krispi dan daging ayamnya juicy lembab, ga kering.




Ternyata cara buat ayam goreng crispy ala kfc (awet renyah) yang nikamt tidak ribet ini enteng sekali ya! Kita semua mampu membuatnya. Resep ayam goreng crispy ala kfc (awet renyah) Cocok banget untuk anda yang baru akan belajar memasak ataupun juga bagi anda yang telah lihai memasak.

Tertarik untuk mencoba membikin resep ayam goreng crispy ala kfc (awet renyah) nikmat tidak ribet ini? Kalau anda mau, mending kamu segera siapin alat dan bahannya, kemudian bikin deh Resep ayam goreng crispy ala kfc (awet renyah) yang lezat dan sederhana ini. Betul-betul mudah kan. 

Oleh karena itu, daripada anda berfikir lama-lama, hayo langsung aja sajikan resep ayam goreng crispy ala kfc (awet renyah) ini. Dijamin kalian gak akan nyesel bikin resep ayam goreng crispy ala kfc (awet renyah) lezat simple ini! Selamat berkreasi dengan resep ayam goreng crispy ala kfc (awet renyah) enak tidak rumit ini di tempat tinggal masing-masing,ya!.

