---
description: "Bahan-bahan Ayam Woku Khas Manado yang enak Untuk Jualan"
title: "Bahan-bahan Ayam Woku Khas Manado yang enak Untuk Jualan"
slug: 333-bahan-bahan-ayam-woku-khas-manado-yang-enak-untuk-jualan
date: 2021-03-27T20:41:05.906Z
image: https://img-global.cpcdn.com/recipes/20fd3b08fada4c85/680x482cq70/ayam-woku-khas-manado-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/20fd3b08fada4c85/680x482cq70/ayam-woku-khas-manado-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/20fd3b08fada4c85/680x482cq70/ayam-woku-khas-manado-foto-resep-utama.jpg
author: Augusta Hawkins
ratingvalue: 3.9
reviewcount: 15
recipeingredient:
- "1/2 kg ayam kota boleh pake ayam kampung yaa"
- "2 genggam daun kemangi"
- "2 batang daun bawang potong"
- "1 bh tomat potong dadu"
- "2 lembar daun pandan simpul"
- "1 lembar daun kunyit optional"
- "5 bh cabe rawit utuh optional"
- "800 ml air boleh kurang klo mau dibikin agak nyemek"
- " Minyak utk menumis"
- " BUMBU HALUS "
- "5 siung bawang merah"
- "3 siung bawang putih"
- "10 bh cabe rawit"
- "1 ruas kunyit"
- "1 ruas jahe"
- "3 butir kemiri sangrai"
- "1/2 sdt lada bubuk"
- " BUMBU CEMPLUNG "
- "3 lembar daun salam"
- "5 lembar daun jeruk"
- "1 batang sereh geprek"
- "1 ruas lengkuas geprek"
recipeinstructions:
- "Panaskan minyak, lalu tumis bumbu halus, daun pandan, daun kunyit (bila ada), serta bumbu cemplung, jgn lupa garam &amp; kaldu ayam secukupnya."
- "Tumis hingga harum dan matang, kemudian masukkan ayam, tumis sebentar bersama bumbu, lalu tuangkan air."
- "Tunggu hingga ayam empuk, matang &amp; bumbu meresap."
- "Masukkan tomat, daun kemangi dan daun bawang. Koreksi rasa."
- "Sajikan bersama nasi hangat."
categories:
- Resep
tags:
- ayam
- woku
- khas

katakunci: ayam woku khas 
nutrition: 147 calories
recipecuisine: Indonesian
preptime: "PT25M"
cooktime: "PT48M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Woku Khas Manado](https://img-global.cpcdn.com/recipes/20fd3b08fada4c85/680x482cq70/ayam-woku-khas-manado-foto-resep-utama.jpg)

Apabila kita seorang wanita, menyediakan hidangan sedap kepada keluarga adalah suatu hal yang sangat menyenangkan untuk kamu sendiri. Peran seorang istri Tidak sekadar menangani rumah saja, tapi anda pun harus menyediakan keperluan nutrisi terpenuhi dan juga panganan yang dimakan orang tercinta mesti lezat.

Di masa  saat ini, kamu memang dapat membeli masakan instan meski tanpa harus repot mengolahnya lebih dulu. Tapi ada juga orang yang memang mau memberikan hidangan yang terenak untuk orang yang dicintainya. Karena, menghidangkan masakan yang dibuat sendiri akan jauh lebih higienis dan bisa menyesuaikan sesuai selera keluarga. 



Apakah anda merupakan seorang penggemar ayam woku khas manado?. Tahukah kamu, ayam woku khas manado merupakan makanan khas di Indonesia yang saat ini disukai oleh kebanyakan orang di berbagai tempat di Indonesia. Kalian dapat menghidangkan ayam woku khas manado sendiri di rumahmu dan boleh jadi makanan kesukaanmu di hari liburmu.

Kita jangan bingung jika kamu ingin menyantap ayam woku khas manado, sebab ayam woku khas manado sangat mudah untuk dicari dan anda pun bisa menghidangkannya sendiri di tempatmu. ayam woku khas manado boleh dibuat lewat beragam cara. Kini pun sudah banyak banget resep modern yang menjadikan ayam woku khas manado semakin lebih lezat.

Resep ayam woku khas manado juga sangat mudah untuk dibuat, lho. Anda tidak perlu capek-capek untuk membeli ayam woku khas manado, sebab Anda bisa menghidangkan di rumahmu. Untuk Kita yang mau menyajikannya, inilah cara menyajikan ayam woku khas manado yang lezat yang mampu Kamu buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Ayam Woku Khas Manado:

1. Siapkan 1/2 kg ayam kota (boleh pake ayam kampung yaa)
1. Ambil 2 genggam daun kemangi
1. Gunakan 2 batang daun bawang, potong²
1. Ambil 1 bh tomat, potong dadu
1. Sediakan 2 lembar daun pandan, simpul
1. Siapkan 1 lembar daun kunyit (optional)
1. Gunakan 5 bh cabe rawit utuh (optional)
1. Sediakan 800 ml air (boleh kurang klo mau dibikin agak nyemek)
1. Siapkan  Minyak utk menumis
1. Ambil  BUMBU HALUS :
1. Gunakan 5 siung bawang merah
1. Siapkan 3 siung bawang putih
1. Siapkan 10 bh cabe rawit
1. Ambil 1 ruas kunyit
1. Siapkan 1 ruas jahe
1. Ambil 3 butir kemiri sangrai
1. Gunakan 1/2 sdt lada bubuk
1. Siapkan  BUMBU CEMPLUNG :
1. Siapkan 3 lembar daun salam
1. Gunakan 5 lembar daun jeruk
1. Gunakan 1 batang sereh, geprek
1. Gunakan 1 ruas lengkuas, geprek




<!--inarticleads2-->

##### Cara menyiapkan Ayam Woku Khas Manado:

1. Panaskan minyak, lalu tumis bumbu halus, daun pandan, daun kunyit (bila ada), serta bumbu cemplung, jgn lupa garam &amp; kaldu ayam secukupnya.
1. Tumis hingga harum dan matang, kemudian masukkan ayam, tumis sebentar bersama bumbu, lalu tuangkan air.
1. Tunggu hingga ayam empuk, matang &amp; bumbu meresap.
1. Masukkan tomat, daun kemangi dan daun bawang. Koreksi rasa.
1. Sajikan bersama nasi hangat.




Ternyata cara membuat ayam woku khas manado yang mantab tidak rumit ini mudah sekali ya! Kamu semua bisa mencobanya. Cara Membuat ayam woku khas manado Sangat cocok sekali buat kamu yang baru mau belajar memasak atau juga bagi kamu yang telah pandai memasak.

Tertarik untuk mencoba bikin resep ayam woku khas manado enak sederhana ini? Kalau anda ingin, ayo kamu segera buruan siapkan alat-alat dan bahan-bahannya, lantas buat deh Resep ayam woku khas manado yang lezat dan tidak ribet ini. Betul-betul taidak sulit kan. 

Maka dari itu, daripada kita berfikir lama-lama, yuk langsung aja buat resep ayam woku khas manado ini. Dijamin kamu gak akan nyesel sudah membuat resep ayam woku khas manado nikmat tidak ribet ini! Selamat berkreasi dengan resep ayam woku khas manado mantab sederhana ini di rumah kalian masing-masing,ya!.

