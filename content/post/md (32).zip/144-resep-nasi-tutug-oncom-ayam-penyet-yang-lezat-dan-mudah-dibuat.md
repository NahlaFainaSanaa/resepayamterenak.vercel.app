---
description: "Resep Nasi tutug oncom + ayam penyet yang lezat dan Mudah Dibuat"
title: "Resep Nasi tutug oncom + ayam penyet yang lezat dan Mudah Dibuat"
slug: 144-resep-nasi-tutug-oncom-ayam-penyet-yang-lezat-dan-mudah-dibuat
date: 2021-01-13T06:10:30.505Z
image: https://img-global.cpcdn.com/recipes/03efa34ba3161daf/680x482cq70/nasi-tutug-oncom-ayam-penyet-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/03efa34ba3161daf/680x482cq70/nasi-tutug-oncom-ayam-penyet-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/03efa34ba3161daf/680x482cq70/nasi-tutug-oncom-ayam-penyet-foto-resep-utama.jpg
author: Rachel Day
ratingvalue: 3
reviewcount: 8
recipeingredient:
- " Bahan nasi tutug oncom"
- "1 liter beras masak smpe matang"
- "4 potong oncom"
- "1 ruas kencur"
- "5 siung bawang merah"
- "5 siung bawang putih"
- "5 buah cabe merah"
- "Secukupnya garam"
- " bahah ayam penyet"
- "1 ekor ayam sy potong 8 lalu ungkep ayam"
- " bahan sambal"
- "15 siung bawang merah"
- "15 siung bawang putih"
- "20 buah cabe merah kriting"
- "15 buah cabe rawit"
- "2 buah tomat uk besar"
- " Garam gula merah terasi"
recipeinstructions:
- "Cara buat nasi tutug oncom : haluskan oncom bersama bawang merah, bawang putih, cabe merah, kencur, kasih garam, dan sedikit gula, lalu tumis oncom tanpa memakai minyak y Bun.. masak oncom smpe benar2 kering dan koreksi rasa sampai berasa asin y Bun kena kalo sudah d campur k nasi rasanya jd hambar...."
- "Stelah matang... Ambil nasi secukupnya lalu ambil oncom secukupnya... Aduk2 smpe rata, lalu cetak sisihkan.."
- "CARA MEMBUAT AYAM PENYET : ungkep ayam sampe Mateng Dan empuk.. lalu goreng ayam Ampe warna kecoklatan.."
- "Goreng bahan sambal... Jgn sampe gosong... Lalu haluskan biarkan sedikit kasar, tambahkan gula, garam, lalu koreksi rasa... Dan siram dgn minyak panas sisa goreng ayam..."
- "Ambil ayam...lalu penyet ayam dan taro sambal d atasnya... Lalu sajikan. Dengan nasi tutug oncom... Siap d hidangkan 😁 selamat mencoba 😍🤗"
categories:
- Resep
tags:
- nasi
- tutug
- oncom

katakunci: nasi tutug oncom 
nutrition: 235 calories
recipecuisine: Indonesian
preptime: "PT20M"
cooktime: "PT35M"
recipeyield: "1"
recipecategory: Dinner

---


![Nasi tutug oncom + ayam penyet](https://img-global.cpcdn.com/recipes/03efa34ba3161daf/680x482cq70/nasi-tutug-oncom-ayam-penyet-foto-resep-utama.jpg)

Sebagai seorang wanita, mempersiapkan masakan menggugah selera kepada orang tercinta merupakan suatu hal yang menyenangkan bagi kamu sendiri. Tugas seorang  wanita bukan cuman menjaga rumah saja, tetapi kamu juga wajib menyediakan kebutuhan gizi tercukupi dan masakan yang dikonsumsi anak-anak mesti enak.

Di era  saat ini, anda sebenarnya bisa memesan panganan jadi meski tidak harus ribet mengolahnya dahulu. Namun banyak juga lho orang yang memang ingin memberikan makanan yang terbaik untuk orang yang dicintainya. Lantaran, menyajikan masakan sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan sesuai dengan kesukaan famili. 

Nasi hangat, oncom, leunca, kemangi, bawang merah, bawang putih, cabai rawit merah, kencur (dibakar), lalapan, tempe penyet sambalado, kulit krispy. Bakar oncom. kencur juga dibakar ya. Haluskan bumbu. kencur, duo Bawang, Cabai rawit merah.

Mungkinkah anda adalah seorang penyuka nasi tutug oncom + ayam penyet?. Tahukah kamu, nasi tutug oncom + ayam penyet adalah hidangan khas di Nusantara yang kini disenangi oleh kebanyakan orang dari hampir setiap daerah di Indonesia. Anda bisa menyajikan nasi tutug oncom + ayam penyet sendiri di rumahmu dan boleh jadi camilan favorit di akhir pekanmu.

Kita jangan bingung untuk mendapatkan nasi tutug oncom + ayam penyet, sebab nasi tutug oncom + ayam penyet gampang untuk ditemukan dan kalian pun boleh memasaknya sendiri di tempatmu. nasi tutug oncom + ayam penyet boleh dimasak dengan berbagai cara. Saat ini ada banyak banget resep modern yang membuat nasi tutug oncom + ayam penyet lebih mantap.

Resep nasi tutug oncom + ayam penyet juga sangat mudah untuk dibuat, lho. Kalian tidak usah ribet-ribet untuk membeli nasi tutug oncom + ayam penyet, sebab Kita bisa menyiapkan di rumahmu. Bagi Kita yang ingin mencobanya, di bawah ini adalah cara membuat nasi tutug oncom + ayam penyet yang lezat yang dapat Kita coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Nasi tutug oncom + ayam penyet:

1. Gunakan  Bahan nasi tutug oncom
1. Ambil 1 liter beras (masak smpe matang)
1. Siapkan 4 potong oncom
1. Sediakan 1 ruas kencur
1. Siapkan 5 siung bawang merah
1. Gunakan 5 siung bawang putih
1. Gunakan 5 buah cabe merah
1. Sediakan Secukupnya garam
1. Siapkan  bahah ayam penyet
1. Gunakan 1 ekor ayam (sy potong 8) lalu ungkep ayam
1. Ambil  bahan sambal
1. Ambil 15 siung bawang merah
1. Siapkan 15 siung bawang putih
1. Gunakan 20 buah cabe merah kriting
1. Ambil 15 buah cabe rawit
1. Sediakan 2 buah tomat (uk besar)
1. Sediakan  Garam, gula merah, terasi


Nasi campur oncom khas Sunda ini biasanya disajikan dengan lalapan, sambel, dan lauk seperti tahu/tempe goreng, ikan asin, atau ayam goreng. Di Tasikmalaya, nasi tutug oncom atau TO ini menjadi menu primadona oleh para pecinta kuliner tradisional. Tak jarang, setiap warung yang menyajikan menu Resep nasi tutug oncom yang akan kita buat kali ini merupakan resep komplit di mana kita juga akan menambahkan ayam goreng, tempe. Nasi tutug oncom or sometimes simply called tutug oncom, is an Indonesian style rice dish, made of rice mixed with oncom fermented beans, originally from Tasikmalaya, West Java. 

<!--inarticleads2-->

##### Cara menyiapkan Nasi tutug oncom + ayam penyet:

1. Cara buat nasi tutug oncom : haluskan oncom bersama bawang merah, bawang putih, cabe merah, kencur, kasih garam, dan sedikit gula, lalu tumis oncom tanpa memakai minyak y Bun.. masak oncom smpe benar2 kering dan koreksi rasa sampai berasa asin y Bun kena kalo sudah d campur k nasi rasanya jd hambar....
1. Stelah matang... Ambil nasi secukupnya lalu ambil oncom secukupnya... Aduk2 smpe rata, lalu cetak sisihkan..
1. CARA MEMBUAT AYAM PENYET : ungkep ayam sampe Mateng Dan empuk.. lalu goreng ayam Ampe warna kecoklatan..
1. Goreng bahan sambal... Jgn sampe gosong... Lalu haluskan biarkan sedikit kasar, tambahkan gula, garam, lalu koreksi rasa... Dan siram dgn minyak panas sisa goreng ayam...
1. Ambil ayam...lalu penyet ayam dan taro sambal d atasnya... Lalu sajikan. Dengan nasi tutug oncom... Siap d hidangkan 😁 selamat mencoba 😍🤗


It is usually wrapped in banana leaves and served with various side dishes. Tekan/penyet hingga ayam agak memar dan pipih. Sajikan bersama nasi dan bahan lalapan. Nasi berbumbu rempah dengan potongan nanas dan bawang goreng sebagai taburannya. Nasi tutug + ayam dengan berbaqgai macam sambel pilihan +tahu/tempe + kol goreng. 

Wah ternyata cara buat nasi tutug oncom + ayam penyet yang mantab simple ini gampang sekali ya! Kamu semua bisa membuatnya. Cara Membuat nasi tutug oncom + ayam penyet Sangat cocok sekali untuk kamu yang baru mau belajar memasak ataupun untuk kamu yang sudah pandai memasak.

Tertarik untuk mencoba buat resep nasi tutug oncom + ayam penyet nikmat tidak ribet ini? Kalau kamu ingin, ayo kalian segera siapin alat-alat dan bahan-bahannya, setelah itu bikin deh Resep nasi tutug oncom + ayam penyet yang nikmat dan tidak ribet ini. Benar-benar taidak sulit kan. 

Maka dari itu, ketimbang kamu diam saja, hayo kita langsung bikin resep nasi tutug oncom + ayam penyet ini. Pasti kamu tiidak akan nyesel sudah buat resep nasi tutug oncom + ayam penyet enak tidak ribet ini! Selamat mencoba dengan resep nasi tutug oncom + ayam penyet nikmat sederhana ini di tempat tinggal masing-masing,ya!.

