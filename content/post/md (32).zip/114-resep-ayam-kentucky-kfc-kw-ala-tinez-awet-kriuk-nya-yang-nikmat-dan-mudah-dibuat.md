---
description: "Resep Ayam Kentucky / KFC kw ala Tinez Awet Kriuk nya yang nikmat dan Mudah Dibuat"
title: "Resep Ayam Kentucky / KFC kw ala Tinez Awet Kriuk nya yang nikmat dan Mudah Dibuat"
slug: 114-resep-ayam-kentucky-kfc-kw-ala-tinez-awet-kriuk-nya-yang-nikmat-dan-mudah-dibuat
date: 2021-03-09T07:21:54.472Z
image: https://img-global.cpcdn.com/recipes/4b31e640c7c860af/680x482cq70/ayam-kentucky-kfc-kw-ala-tinez-awet-kriuk-nya-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4b31e640c7c860af/680x482cq70/ayam-kentucky-kfc-kw-ala-tinez-awet-kriuk-nya-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4b31e640c7c860af/680x482cq70/ayam-kentucky-kfc-kw-ala-tinez-awet-kriuk-nya-foto-resep-utama.jpg
author: Corey Farmer
ratingvalue: 3.2
reviewcount: 11
recipeingredient:
- "1/4 kg ayam"
- "200 ml air es"
- "1/4 sdt soda kue"
- " Marinasi "
- "Secukupnya merica garam royco rasa sapi"
- "2 bj bawang putih haluskan"
- " Adonan tepung kering "
- "7,5 sdm tepung terigu cakra"
- "1,5 sdm tepung maizena"
- "Sedikit merica garam  royco sapi di kira2 sendiri aja"
recipeinstructions:
- "Cuci bersih ayam &amp; lumuri jeruk nipis. Cuci lagi &amp; sisihkan."
- "Marinasi ayam dengan bawang putih yg sdh di haluskan, garam &amp; royco sapi. Kalo mau meresap sempurna diamkan semalaman d kulkas u/ digoreng besok paginya. Kalo memang keburu, diamkan aja 3-5 jam sdh cukup."
- "Adonan tepung kering : campur semua adonan tepung terigu, tepung maizena, garam, merica &amp; royco. Aduk rata."
- "Adonan basah : ambil 2,5 sdm adonan tepung kering, masukkan ke dalam 200 ml air es. Tambahkan soda kue. Aduk rata yaa.. Sisihkan / masukin kulkas lagi yaa gpp.."
- "Setelah selesai marinasi, sambil menunggu ayamnya di tepungin. Panaskan minyak dulu ya. Minyak harus banyak sampe ayam terendam ya..."
- "Sambil memanaskan minyak, ambil ayam, celupkan ke adonan basah. Celupkan ke adonan kering, remas2 &amp; jgn lupa di cubit2 biar keriting. Celupkan ke adonan basah lagi. Celupkan lagi ke adonan kering, di remas2 lagi, di cubit2 lagi biar keriting."
- "Goreng dlm minyak panas. Pakai api sedang cenderung kecil, spy dagingnya matang sempurna."
- "Tips : sebaiknya setelah ayam di tepungin &amp; di cubit2 harus langsung di goreng dlm minyak panas. Jangan menunggu semua ayam di tepungin baru d goreng, nanti teksturnya sdh berbeda, keritingnya ga muncul bagus.."
- "Selamat mencoba yaa.. 👏😆😍😘"
categories:
- Resep
tags:
- ayam
- kentucky
- 

katakunci: ayam kentucky  
nutrition: 119 calories
recipecuisine: Indonesian
preptime: "PT35M"
cooktime: "PT58M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam Kentucky / KFC kw ala Tinez Awet Kriuk nya](https://img-global.cpcdn.com/recipes/4b31e640c7c860af/680x482cq70/ayam-kentucky-kfc-kw-ala-tinez-awet-kriuk-nya-foto-resep-utama.jpg)

Sebagai seorang wanita, mempersiapkan santapan enak kepada famili merupakan hal yang memuaskan bagi kamu sendiri. Kewajiban seorang ibu bukan cuma menangani rumah saja, tapi anda juga harus menyediakan kebutuhan nutrisi tercukupi dan hidangan yang dimakan keluarga tercinta harus sedap.

Di waktu  saat ini, kamu sebenarnya mampu memesan panganan praktis tanpa harus ribet membuatnya dahulu. Tetapi ada juga lho orang yang memang ingin memberikan makanan yang terbaik untuk orang yang dicintainya. Karena, menghidangkan masakan yang dibuat sendiri akan jauh lebih bersih dan bisa menyesuaikan berdasarkan masakan kesukaan famili. 



Mungkinkah anda salah satu penikmat ayam kentucky / kfc kw ala tinez awet kriuk nya?. Asal kamu tahu, ayam kentucky / kfc kw ala tinez awet kriuk nya merupakan hidangan khas di Nusantara yang saat ini disenangi oleh banyak orang dari berbagai wilayah di Nusantara. Kalian dapat menyajikan ayam kentucky / kfc kw ala tinez awet kriuk nya hasil sendiri di rumahmu dan dapat dijadikan hidangan favoritmu di akhir pekanmu.

Kamu tidak usah bingung untuk menyantap ayam kentucky / kfc kw ala tinez awet kriuk nya, sebab ayam kentucky / kfc kw ala tinez awet kriuk nya mudah untuk ditemukan dan kita pun bisa membuatnya sendiri di rumah. ayam kentucky / kfc kw ala tinez awet kriuk nya dapat diolah lewat beraneka cara. Saat ini ada banyak banget cara modern yang menjadikan ayam kentucky / kfc kw ala tinez awet kriuk nya semakin lebih enak.

Resep ayam kentucky / kfc kw ala tinez awet kriuk nya juga gampang dibikin, lho. Kalian tidak perlu repot-repot untuk memesan ayam kentucky / kfc kw ala tinez awet kriuk nya, karena Kalian mampu menyiapkan di rumahmu. Untuk Kita yang hendak menyajikannya, inilah cara membuat ayam kentucky / kfc kw ala tinez awet kriuk nya yang enak yang dapat Kita coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Ayam Kentucky / KFC kw ala Tinez Awet Kriuk nya:

1. Ambil 1/4 kg ayam
1. Ambil 200 ml air es
1. Ambil 1/4 sdt soda kue
1. Ambil  Marinasi :
1. Ambil Secukupnya merica, garam, royco rasa sapi
1. Siapkan 2 bj bawang putih haluskan
1. Siapkan  Adonan tepung kering :
1. Sediakan 7,5 sdm tepung terigu cakra
1. Sediakan 1,5 sdm tepung maizena
1. Siapkan Sedikit merica, garam &amp; royco sapi (di kira2 sendiri aja..)




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Kentucky / KFC kw ala Tinez Awet Kriuk nya:

1. Cuci bersih ayam &amp; lumuri jeruk nipis. Cuci lagi &amp; sisihkan.
1. Marinasi ayam dengan bawang putih yg sdh di haluskan, garam &amp; royco sapi. Kalo mau meresap sempurna diamkan semalaman d kulkas u/ digoreng besok paginya. Kalo memang keburu, diamkan aja 3-5 jam sdh cukup.
1. Adonan tepung kering : campur semua adonan tepung terigu, tepung maizena, garam, merica &amp; royco. Aduk rata.
1. Adonan basah : ambil 2,5 sdm adonan tepung kering, masukkan ke dalam 200 ml air es. Tambahkan soda kue. Aduk rata yaa.. Sisihkan / masukin kulkas lagi yaa gpp..
1. Setelah selesai marinasi, sambil menunggu ayamnya di tepungin. Panaskan minyak dulu ya. Minyak harus banyak sampe ayam terendam ya...
1. Sambil memanaskan minyak, ambil ayam, celupkan ke adonan basah. Celupkan ke adonan kering, remas2 &amp; jgn lupa di cubit2 biar keriting. Celupkan ke adonan basah lagi. Celupkan lagi ke adonan kering, di remas2 lagi, di cubit2 lagi biar keriting.
1. Goreng dlm minyak panas. Pakai api sedang cenderung kecil, spy dagingnya matang sempurna.
1. Tips : sebaiknya setelah ayam di tepungin &amp; di cubit2 harus langsung di goreng dlm minyak panas. Jangan menunggu semua ayam di tepungin baru d goreng, nanti teksturnya sdh berbeda, keritingnya ga muncul bagus..
1. Selamat mencoba yaa.. 👏😆😍😘




Ternyata cara membuat ayam kentucky / kfc kw ala tinez awet kriuk nya yang enak sederhana ini enteng sekali ya! Kalian semua bisa memasaknya. Cara buat ayam kentucky / kfc kw ala tinez awet kriuk nya Sangat sesuai banget untuk kalian yang baru akan belajar memasak maupun bagi kalian yang sudah pandai memasak.

Apakah kamu mau mencoba membikin resep ayam kentucky / kfc kw ala tinez awet kriuk nya nikmat tidak rumit ini? Kalau kamu tertarik, ayo kamu segera siapin peralatan dan bahannya, setelah itu buat deh Resep ayam kentucky / kfc kw ala tinez awet kriuk nya yang lezat dan simple ini. Benar-benar mudah kan. 

Maka, ketimbang kamu berfikir lama-lama, maka kita langsung saja buat resep ayam kentucky / kfc kw ala tinez awet kriuk nya ini. Pasti kamu gak akan nyesel sudah bikin resep ayam kentucky / kfc kw ala tinez awet kriuk nya nikmat tidak ribet ini! Selamat berkreasi dengan resep ayam kentucky / kfc kw ala tinez awet kriuk nya mantab simple ini di tempat tinggal kalian masing-masing,oke!.

