---
description: "Cara membuat Ayam bakar sambal bajak (bumil friendly) Sederhana dan Mudah Dibuat"
title: "Cara membuat Ayam bakar sambal bajak (bumil friendly) Sederhana dan Mudah Dibuat"
slug: 466-cara-membuat-ayam-bakar-sambal-bajak-bumil-friendly-sederhana-dan-mudah-dibuat
date: 2021-06-11T03:49:20.360Z
image: https://img-global.cpcdn.com/recipes/bb39982369b1367e/680x482cq70/ayam-bakar-sambal-bajak-bumil-friendly-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/bb39982369b1367e/680x482cq70/ayam-bakar-sambal-bajak-bumil-friendly-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/bb39982369b1367e/680x482cq70/ayam-bakar-sambal-bajak-bumil-friendly-foto-resep-utama.jpg
author: Leona Ingram
ratingvalue: 4.7
reviewcount: 8
recipeingredient:
- "1/2 kg ayam saya 3 buah bagian paha atas bawah"
- "secukupnya Gula garam lada bubuk"
- " Sambal bajak"
- "50 gr cabai merah besar"
- "60 gr cabai keriting"
- "4 bawang merah"
- "4 bawang putih"
- "2 kemiri sangrai"
- "2 sdm ketumbar"
- "2 tomat merah ukuran besar"
- " Bumbu rempah"
- "1 ruas jahe"
- "1 ruas lengkuas"
- "1 sereh"
- "3 daun jeruk"
- "2 daun salam"
- " Bahan oles"
- "1 sdm margarin"
- "1 sdm sambal tomat"
- "2 sdm kecap"
- " Bahan marinasi saya skip ganti bumbu ungkep"
- " Lada bubuk"
- " Merica"
- " Garam"
recipeinstructions:
- "Bersihkan ayam, marinasi ayam dengan bumbu marinasi (saya skip ya karna ayamnya saya ungkep) untuk bumbu ungkep seperti biasa, setelah matang tiriskan ya bun"
- "Blender semua bumbu bajak lalu tumis hingga harum, masukkan semua bahan rempah2, lalu tambahkan gula, garam, merica secukupnya masak hingga matang sisihkan"
- "Siapkan teflon beri sedikit margarin, baluti ayam dengan bumbu oles bakar dengan api kecil bolak balik, lalu baluti dengan sambel bajak bakar sampai ayam matang merata ya"
- "Jika sudah matang siap untuk disajikan 😍😍 jangan lupa diberi lalapan sesuai selera ya"
categories:
- Resep
tags:
- ayam
- bakar
- sambal

katakunci: ayam bakar sambal 
nutrition: 207 calories
recipecuisine: Indonesian
preptime: "PT24M"
cooktime: "PT31M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam bakar sambal bajak (bumil friendly)](https://img-global.cpcdn.com/recipes/bb39982369b1367e/680x482cq70/ayam-bakar-sambal-bajak-bumil-friendly-foto-resep-utama.jpg)

Selaku seorang orang tua, menyediakan hidangan menggugah selera kepada keluarga tercinta adalah suatu hal yang mengasyikan untuk anda sendiri. Tanggung jawab seorang  wanita Tidak hanya mengurus rumah saja, tapi anda pun harus menyediakan kebutuhan nutrisi tercukupi dan juga masakan yang dimakan orang tercinta wajib lezat.

Di zaman  sekarang, kamu memang bisa membeli hidangan jadi walaupun tanpa harus susah mengolahnya dulu. Namun banyak juga lho mereka yang memang mau memberikan makanan yang terlezat bagi orang tercintanya. Pasalnya, menyajikan masakan yang diolah sendiri jauh lebih higienis dan bisa menyesuaikan masakan tersebut sesuai dengan kesukaan keluarga tercinta. 



Apakah anda seorang penggemar ayam bakar sambal bajak (bumil friendly)?. Asal kamu tahu, ayam bakar sambal bajak (bumil friendly) adalah sajian khas di Nusantara yang kini disenangi oleh banyak orang di hampir setiap wilayah di Indonesia. Kamu bisa membuat ayam bakar sambal bajak (bumil friendly) olahan sendiri di rumahmu dan boleh dijadikan camilan favorit di hari liburmu.

Kalian tidak perlu bingung untuk menyantap ayam bakar sambal bajak (bumil friendly), sebab ayam bakar sambal bajak (bumil friendly) tidak sulit untuk didapatkan dan juga kamu pun dapat mengolahnya sendiri di tempatmu. ayam bakar sambal bajak (bumil friendly) boleh diolah memalui beragam cara. Sekarang ada banyak sekali cara kekinian yang menjadikan ayam bakar sambal bajak (bumil friendly) semakin lebih enak.

Resep ayam bakar sambal bajak (bumil friendly) juga mudah dibuat, lho. Anda tidak usah repot-repot untuk membeli ayam bakar sambal bajak (bumil friendly), sebab Kita dapat membuatnya ditempatmu. Untuk Kita yang ingin menyajikannya, dibawah ini merupakan resep untuk menyajikan ayam bakar sambal bajak (bumil friendly) yang enak yang dapat Kalian hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Ayam bakar sambal bajak (bumil friendly):

1. Siapkan 1/2 kg ayam saya 3 buah bagian paha atas bawah
1. Siapkan secukupnya Gula, garam, lada bubuk
1. Siapkan  Sambal bajak
1. Sediakan 50 gr cabai merah besar
1. Sediakan 60 gr cabai keriting
1. Ambil 4 bawang merah
1. Siapkan 4 bawang putih
1. Gunakan 2 kemiri sangrai
1. Ambil 2 sdm ketumbar
1. Ambil 2 tomat merah ukuran besar
1. Gunakan  Bumbu rempah
1. Gunakan 1 ruas jahe
1. Sediakan 1 ruas lengkuas
1. Siapkan 1 sereh
1. Siapkan 3 daun jeruk
1. Ambil 2 daun salam
1. Gunakan  Bahan oles
1. Siapkan 1 sdm margarin
1. Ambil 1 sdm sambal tomat
1. Gunakan 2 sdm kecap
1. Ambil  Bahan marinasi (saya skip ganti bumbu ungkep)
1. Sediakan  Lada bubuk
1. Siapkan  Merica
1. Sediakan  Garam




<!--inarticleads2-->

##### Cara menyiapkan Ayam bakar sambal bajak (bumil friendly):

1. Bersihkan ayam, marinasi ayam dengan bumbu marinasi (saya skip ya karna ayamnya saya ungkep) untuk bumbu ungkep seperti biasa, setelah matang tiriskan ya bun
1. Blender semua bumbu bajak lalu tumis hingga harum, masukkan semua bahan rempah2, lalu tambahkan gula, garam, merica secukupnya masak hingga matang sisihkan
1. Siapkan teflon beri sedikit margarin, baluti ayam dengan bumbu oles bakar dengan api kecil bolak balik, lalu baluti dengan sambel bajak bakar sampai ayam matang merata ya
1. Jika sudah matang siap untuk disajikan 😍😍 jangan lupa diberi lalapan sesuai selera ya




Wah ternyata cara buat ayam bakar sambal bajak (bumil friendly) yang nikamt sederhana ini mudah banget ya! Anda Semua bisa memasaknya. Cara Membuat ayam bakar sambal bajak (bumil friendly) Sangat cocok sekali untuk kalian yang baru belajar memasak maupun bagi kalian yang sudah hebat memasak.

Tertarik untuk mulai mencoba buat resep ayam bakar sambal bajak (bumil friendly) nikmat tidak ribet ini? Kalau tertarik, yuk kita segera siapin peralatan dan bahan-bahannya, kemudian bikin deh Resep ayam bakar sambal bajak (bumil friendly) yang nikmat dan tidak ribet ini. Betul-betul mudah kan. 

Maka, ketimbang kita berlama-lama, maka langsung aja buat resep ayam bakar sambal bajak (bumil friendly) ini. Pasti kamu gak akan nyesel sudah bikin resep ayam bakar sambal bajak (bumil friendly) lezat tidak rumit ini! Selamat mencoba dengan resep ayam bakar sambal bajak (bumil friendly) nikmat simple ini di rumah sendiri,oke!.

