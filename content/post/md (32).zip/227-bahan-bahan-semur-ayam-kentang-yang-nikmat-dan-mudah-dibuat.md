---
description: "Bahan-bahan Semur Ayam Kentang yang nikmat dan Mudah Dibuat"
title: "Bahan-bahan Semur Ayam Kentang yang nikmat dan Mudah Dibuat"
slug: 227-bahan-bahan-semur-ayam-kentang-yang-nikmat-dan-mudah-dibuat
date: 2021-01-29T04:38:15.606Z
image: https://img-global.cpcdn.com/recipes/a6c416bc6724acca/680x482cq70/semur-ayam-kentang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a6c416bc6724acca/680x482cq70/semur-ayam-kentang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a6c416bc6724acca/680x482cq70/semur-ayam-kentang-foto-resep-utama.jpg
author: Alice West
ratingvalue: 3.3
reviewcount: 13
recipeingredient:
- "500 gram paha atas ayam"
- "3 buah kentang"
- "1 buah tomat optional potongpotong"
- "3 buah cabe merah iris"
- "1 batang kayu manis kecil"
- " Kecap manis"
- " Kecap asin"
- "secukupnya Garam"
- "secukupnya Gula"
- "secukupnya Air"
- " Bumbu halus"
- "9 siung bawang merah"
- "4 siung bawang putih"
- "Sedikit pala"
- "1 sdt lada"
recipeinstructions:
- "Potong ayam menjadi beberapa bagian. Lalu cuci bersih dan rebus sebentar di air mendidih.           (lihat tips)"
- "Potong kentang, goreng setengah matang. Tiriskan."
- "Tumis bumbu halus dengan sedikit minyak. Masukkan cabe, kayu manis, dan tomat. Tumis sampai harum. Masukkan ayam, aduk rata. Beri air secukupnya"
- "Jika ayam sudah mulai empuk masukkan kecap, garam, gula, lada dan kentang. Aduk rata hingga kuah agak menyusut. Koreksi rasa. Sajikan."
categories:
- Resep
tags:
- semur
- ayam
- kentang

katakunci: semur ayam kentang 
nutrition: 230 calories
recipecuisine: Indonesian
preptime: "PT10M"
cooktime: "PT53M"
recipeyield: "2"
recipecategory: Dinner

---


![Semur Ayam Kentang](https://img-global.cpcdn.com/recipes/a6c416bc6724acca/680x482cq70/semur-ayam-kentang-foto-resep-utama.jpg)

Sebagai seorang orang tua, menyajikan hidangan nikmat untuk famili adalah suatu hal yang mengasyikan untuk kamu sendiri. Tugas seorang ibu Tidak saja mengurus rumah saja, tapi anda juga wajib menyediakan kebutuhan nutrisi terpenuhi dan juga panganan yang dikonsumsi orang tercinta harus sedap.

Di zaman  saat ini, anda memang mampu membeli hidangan praktis tidak harus repot membuatnya terlebih dahulu. Tetapi banyak juga orang yang selalu ingin memberikan makanan yang terenak bagi orang tercintanya. Karena, memasak yang diolah sendiri jauh lebih higienis dan kita juga bisa menyesuaikan makanan tersebut sesuai dengan kesukaan orang tercinta. 



Apakah anda adalah salah satu penyuka semur ayam kentang?. Asal kamu tahu, semur ayam kentang merupakan sajian khas di Nusantara yang kini digemari oleh banyak orang dari hampir setiap tempat di Indonesia. Kamu bisa menghidangkan semur ayam kentang sendiri di rumahmu dan pasti jadi camilan kegemaranmu di akhir pekanmu.

Kalian jangan bingung untuk mendapatkan semur ayam kentang, sebab semur ayam kentang mudah untuk didapatkan dan juga anda pun dapat membuatnya sendiri di tempatmu. semur ayam kentang dapat dibuat dengan bermacam cara. Sekarang telah banyak cara modern yang membuat semur ayam kentang semakin nikmat.

Resep semur ayam kentang pun mudah sekali untuk dibuat, lho. Kalian tidak usah capek-capek untuk memesan semur ayam kentang, sebab Kita mampu membuatnya ditempatmu. Bagi Anda yang ingin menyajikannya, di bawah ini adalah resep membuat semur ayam kentang yang lezat yang mampu Kalian coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Semur Ayam Kentang:

1. Siapkan 500 gram paha atas ayam
1. Sediakan 3 buah kentang
1. Ambil 1 buah tomat (optional), potong-potong
1. Siapkan 3 buah cabe merah, iris
1. Sediakan 1 batang kayu manis kecil
1. Siapkan  Kecap manis
1. Siapkan  Kecap asin
1. Siapkan secukupnya Garam
1. Gunakan secukupnya Gula
1. Sediakan secukupnya Air
1. Siapkan  Bumbu halus
1. Siapkan 9 siung bawang merah
1. Sediakan 4 siung bawang putih
1. Gunakan Sedikit pala
1. Ambil 1 sdt lada




<!--inarticleads2-->

##### Cara menyiapkan Semur Ayam Kentang:

1. Potong ayam menjadi beberapa bagian. Lalu cuci bersih dan rebus sebentar di air mendidih. -           (lihat tips)
1. Potong kentang, goreng setengah matang. Tiriskan.
1. Tumis bumbu halus dengan sedikit minyak. Masukkan cabe, kayu manis, dan tomat. Tumis sampai harum. Masukkan ayam, aduk rata. Beri air secukupnya
1. Jika ayam sudah mulai empuk masukkan kecap, garam, gula, lada dan kentang. Aduk rata hingga kuah agak menyusut. Koreksi rasa. Sajikan.




Wah ternyata resep semur ayam kentang yang mantab simple ini gampang banget ya! Kamu semua dapat memasaknya. Cara Membuat semur ayam kentang Cocok banget buat kalian yang baru akan belajar memasak maupun juga untuk kalian yang sudah jago memasak.

Apakah kamu ingin mulai mencoba membuat resep semur ayam kentang nikmat tidak rumit ini? Kalau tertarik, yuk kita segera buruan siapin alat dan bahan-bahannya, lalu bikin deh Resep semur ayam kentang yang lezat dan simple ini. Benar-benar taidak sulit kan. 

Maka, daripada kita berlama-lama, hayo kita langsung saja hidangkan resep semur ayam kentang ini. Dijamin kalian gak akan menyesal membuat resep semur ayam kentang lezat simple ini! Selamat mencoba dengan resep semur ayam kentang enak sederhana ini di tempat tinggal masing-masing,oke!.

