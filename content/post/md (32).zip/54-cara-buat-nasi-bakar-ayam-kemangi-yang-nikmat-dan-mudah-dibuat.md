---
description: "Cara buat Nasi Bakar Ayam Kemangi yang nikmat dan Mudah Dibuat"
title: "Cara buat Nasi Bakar Ayam Kemangi yang nikmat dan Mudah Dibuat"
slug: 54-cara-buat-nasi-bakar-ayam-kemangi-yang-nikmat-dan-mudah-dibuat
date: 2021-06-16T13:26:01.597Z
image: https://img-global.cpcdn.com/recipes/6dc9c09765cac85d/680x482cq70/nasi-bakar-ayam-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6dc9c09765cac85d/680x482cq70/nasi-bakar-ayam-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6dc9c09765cac85d/680x482cq70/nasi-bakar-ayam-kemangi-foto-resep-utama.jpg
author: Calvin Cruz
ratingvalue: 4.3
reviewcount: 5
recipeingredient:
- " Bahan nasi "
- "4 cup beras"
- "1 sachet santan kara 65ml"
- "1 batang sereh geprek"
- "2 lembar daun salam"
- "1 sdt garam"
- "Secukupnya air untuk memasak nasi"
- " Bahan ayam "
- "500 gr ayam saya bagian dada"
- "2 lembar daun salam untuk merebus ayam"
- "1 batang sereh geprek"
- "2 lembar daun salam untuk ditumis"
- "3 lembar daun jeruk"
- "1 ikat daun kemangi"
- "Secukupnya garam gula pasir dan kaldu jamur"
- " Daun pisang untuk membungkus nasi"
- " Bumbu halus "
- "8 siung bawang merah"
- "4 siung bawang putih"
- "7 biji cabe merah besar atau sesuai selera"
- "1 ruas kunyit"
- "1 ruas jahe"
- "1 sdm gula jawa sisir"
- "2 sdm air asam jawa"
- "1/2 sdt lada bubuk"
recipeinstructions:
- "Cuci beras. Lalu campur semua bahan nasi. Masak menggunakan rice cooker."
- "Rebus ayam lebih dulu dengan daun salam hingga ayam empuk. Lalu suwir2 ayam, sisihkan."
- "Haluskan bumbu, saya menggunakan blender kecil."
- "Panaskan sedikit minyak, tumis bumbu halus beserta daun salam, daun jeruk dan sereh hingga harum. Lalu masukkan ayam suwir."
- "Aduk rata ayam dan bumbu, lalu bumbui dengan garam, gula pasir dan kaldu jamur. Beri sedikit air agar bawahnya tidak gosong. Masak hingga bumbu meresap dan air menyusut. Menjelang matang masukkan daun kemangi. Aduk sebentar. Matikan api"
- "Siapkan daun pisang yang sudah dibersihkan dan dipanggang sebentar sampe layu saja (agar tidak robek saat dilipat). Tata nasi secukupnya, gulung dan padatkan dulu. Lalu tuang ayam kemangi diatasnya. Bungkus. Kemudian panggang hingga daun menjadi kering. Lakukan hingga selesai."
- "MasyaAllah, nikmat Tuhan manakah yang kau dustakan 😋"
categories:
- Resep
tags:
- nasi
- bakar
- ayam

katakunci: nasi bakar ayam 
nutrition: 185 calories
recipecuisine: Indonesian
preptime: "PT34M"
cooktime: "PT34M"
recipeyield: "4"
recipecategory: Dessert

---


![Nasi Bakar Ayam Kemangi](https://img-global.cpcdn.com/recipes/6dc9c09765cac85d/680x482cq70/nasi-bakar-ayam-kemangi-foto-resep-utama.jpg)

Selaku seorang orang tua, menyediakan masakan nikmat pada orang tercinta merupakan hal yang membahagiakan bagi kamu sendiri. Peran seorang  wanita Tidak saja menjaga rumah saja, tetapi kamu pun wajib memastikan keperluan nutrisi terpenuhi dan santapan yang disantap keluarga tercinta mesti mantab.

Di zaman  saat ini, kalian memang mampu mengorder santapan praktis tidak harus ribet membuatnya terlebih dahulu. Tapi banyak juga mereka yang selalu ingin memberikan makanan yang terlezat bagi orang tercintanya. Pasalnya, memasak yang dibuat sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan sesuai dengan selera famili. 



Mungkinkah anda merupakan seorang penikmat nasi bakar ayam kemangi?. Asal kamu tahu, nasi bakar ayam kemangi merupakan sajian khas di Nusantara yang sekarang digemari oleh setiap orang dari hampir setiap tempat di Indonesia. Kalian bisa membuat nasi bakar ayam kemangi sendiri di rumah dan boleh dijadikan santapan favorit di hari liburmu.

Kamu tidak usah bingung untuk mendapatkan nasi bakar ayam kemangi, karena nasi bakar ayam kemangi tidak sukar untuk dicari dan anda pun dapat menghidangkannya sendiri di tempatmu. nasi bakar ayam kemangi bisa dibuat memalui beraneka cara. Sekarang sudah banyak sekali resep kekinian yang membuat nasi bakar ayam kemangi semakin lebih nikmat.

Resep nasi bakar ayam kemangi pun sangat gampang dibikin, lho. Kalian tidak perlu ribet-ribet untuk memesan nasi bakar ayam kemangi, sebab Kamu dapat menyajikan di rumahmu. Bagi Kita yang akan menyajikannya, inilah cara untuk membuat nasi bakar ayam kemangi yang nikamat yang bisa Kamu coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Nasi Bakar Ayam Kemangi:

1. Siapkan  Bahan nasi :
1. Siapkan 4 cup beras
1. Gunakan 1 sachet santan kara @65ml
1. Gunakan 1 batang sereh, geprek
1. Sediakan 2 lembar daun salam
1. Sediakan 1 sdt garam
1. Sediakan Secukupnya air untuk memasak nasi
1. Gunakan  Bahan ayam :
1. Siapkan 500 gr ayam (saya bagian dada)
1. Sediakan 2 lembar daun salam (untuk merebus ayam)
1. Sediakan 1 batang sereh, geprek
1. Sediakan 2 lembar daun salam (untuk ditumis)
1. Sediakan 3 lembar daun jeruk
1. Siapkan 1 ikat daun kemangi
1. Ambil Secukupnya garam, gula pasir dan kaldu jamur
1. Ambil  Daun pisang untuk membungkus nasi
1. Ambil  Bumbu halus :
1. Ambil 8 siung bawang merah
1. Ambil 4 siung bawang putih
1. Siapkan 7 biji cabe merah besar (atau sesuai selera)
1. Sediakan 1 ruas kunyit
1. Ambil 1 ruas jahe
1. Sediakan 1 sdm gula jawa sisir
1. Gunakan 2 sdm air asam jawa
1. Sediakan 1/2 sdt lada bubuk




<!--inarticleads2-->

##### Langkah-langkah membuat Nasi Bakar Ayam Kemangi:

1. Cuci beras. Lalu campur semua bahan nasi. Masak menggunakan rice cooker.
1. Rebus ayam lebih dulu dengan daun salam hingga ayam empuk. Lalu suwir2 ayam, sisihkan.
1. Haluskan bumbu, saya menggunakan blender kecil.
1. Panaskan sedikit minyak, tumis bumbu halus beserta daun salam, daun jeruk dan sereh hingga harum. Lalu masukkan ayam suwir.
1. Aduk rata ayam dan bumbu, lalu bumbui dengan garam, gula pasir dan kaldu jamur. Beri sedikit air agar bawahnya tidak gosong. Masak hingga bumbu meresap dan air menyusut. Menjelang matang masukkan daun kemangi. Aduk sebentar. Matikan api
1. Siapkan daun pisang yang sudah dibersihkan dan dipanggang sebentar sampe layu saja (agar tidak robek saat dilipat). Tata nasi secukupnya, gulung dan padatkan dulu. Lalu tuang ayam kemangi diatasnya. Bungkus. Kemudian panggang hingga daun menjadi kering. Lakukan hingga selesai.
1. MasyaAllah, nikmat Tuhan manakah yang kau dustakan 😋




Wah ternyata cara buat nasi bakar ayam kemangi yang enak tidak ribet ini enteng banget ya! Kita semua bisa memasaknya. Cara buat nasi bakar ayam kemangi Sesuai sekali buat kalian yang baru mau belajar memasak ataupun untuk kamu yang telah ahli dalam memasak.

Tertarik untuk mencoba bikin resep nasi bakar ayam kemangi lezat simple ini? Kalau mau, yuk kita segera siapin alat-alat dan bahannya, kemudian buat deh Resep nasi bakar ayam kemangi yang mantab dan tidak ribet ini. Sungguh mudah kan. 

Maka dari itu, daripada anda diam saja, yuk kita langsung hidangkan resep nasi bakar ayam kemangi ini. Dijamin anda gak akan menyesal sudah buat resep nasi bakar ayam kemangi mantab simple ini! Selamat mencoba dengan resep nasi bakar ayam kemangi nikmat tidak ribet ini di tempat tinggal sendiri,oke!.

