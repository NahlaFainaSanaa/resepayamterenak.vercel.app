---
description: "Resep Ayam tepung bumbu pedas kemangi Sederhana Untuk Jualan"
title: "Resep Ayam tepung bumbu pedas kemangi Sederhana Untuk Jualan"
slug: 342-resep-ayam-tepung-bumbu-pedas-kemangi-sederhana-untuk-jualan
date: 2021-05-14T02:54:16.359Z
image: https://img-global.cpcdn.com/recipes/452234720f5cfdb1/680x482cq70/ayam-tepung-bumbu-pedas-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/452234720f5cfdb1/680x482cq70/ayam-tepung-bumbu-pedas-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/452234720f5cfdb1/680x482cq70/ayam-tepung-bumbu-pedas-kemangi-foto-resep-utama.jpg
author: Eleanor Pena
ratingvalue: 4.7
reviewcount: 11
recipeingredient:
- "1/2 ekor ayam"
- "1 Iket kecil daun kemangi"
- " Tomat ijo kecil iris sesuai selera"
- " Bawang Bombay seperempat aja"
- " Tepung kentaqi terserah pake merek sesuai selera"
- " Bumbu halus"
- "4 cabe merah besar"
- "8 cabe rawit hijau"
- "4 siung bawang merah"
- "2 siung bawang putih"
- "2 kemiri"
- " Kunyit bubuk sedikit aja"
- "secukupnya Garam"
- "secukupnya Gula"
- "secukupnya Penyedap rasa"
- " Air"
- " Minyak"
- "secukupnya Saus tiram"
- "secukupnya Lada bubuk"
recipeinstructions:
- "Potong ayam sesuai selera cuci bersih lalu terserah mau di rebus dulu apa gak...kalau saya tak rebus dulu setelah matang angkat dinginkan bentar"
- "Ambil tepung kentaqi nya setelah itu Ambil 2 sendok dan kasih air dingin secukupnya...lalu ambil ayam celupkan d adonan basah lalu guling kan keadonan kering... lakukan sampe selesai..."
- "Setelah itu panaskan minyak lalu goreng ayam tepung nya hingga matang...setelah matang angkat dan tiriskan"
- "Petikin daun kemangi nya lalu cuci bersih"
- "Potong tomat hijau dan bawang Bombay nya"
- "Panaskan minyak goreng secukupnya untuk menumis... Tumis bawang Bombay dulu hingga harum dan matang lalu masukkan bumbu yg sudah di haluskan tadi...masak hingga matang... tambahkan garam...aduk lalu masukkan gula secukupnya...aduk lalu masukkan air sedikit aja...masak bentr..lalu masukkan ayam tepung nya.... terus aduk perlahan aja..."
- "Lalu masukkan tomat hijau dan daun kemangi nya...aduk perlahan hingga rata dan matang... tambahkan penyedab rasa,lada bubuk aduk rata lalu masukkan saus tiram secukupnya masak aduk rata....tes rasa kalau d rasa sudah pas..dan matang angkat terus sajikan...."
categories:
- Resep
tags:
- ayam
- tepung
- bumbu

katakunci: ayam tepung bumbu 
nutrition: 278 calories
recipecuisine: Indonesian
preptime: "PT16M"
cooktime: "PT60M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam tepung bumbu pedas kemangi](https://img-global.cpcdn.com/recipes/452234720f5cfdb1/680x482cq70/ayam-tepung-bumbu-pedas-kemangi-foto-resep-utama.jpg)

Sebagai seorang yang hobi memasak, mempersiapkan santapan lezat untuk keluarga tercinta adalah suatu hal yang mengasyikan untuk anda sendiri. Tanggung jawab seorang ibu bukan saja menangani rumah saja, tapi kamu juga wajib menyediakan keperluan gizi tercukupi dan juga olahan yang dikonsumsi keluarga tercinta harus nikmat.

Di era  saat ini, anda sebenarnya mampu memesan santapan jadi meski tanpa harus repot mengolahnya lebih dulu. Tapi ada juga lho mereka yang memang mau memberikan yang terbaik bagi keluarganya. Karena, menghidangkan masakan sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan makanan tersebut sesuai selera orang tercinta. 



Apakah anda merupakan salah satu penikmat ayam tepung bumbu pedas kemangi?. Asal kamu tahu, ayam tepung bumbu pedas kemangi merupakan hidangan khas di Nusantara yang kini disukai oleh kebanyakan orang di hampir setiap wilayah di Nusantara. Kalian bisa menghidangkan ayam tepung bumbu pedas kemangi sendiri di rumahmu dan dapat dijadikan santapan favorit di akhir pekanmu.

Kita tidak perlu bingung untuk memakan ayam tepung bumbu pedas kemangi, lantaran ayam tepung bumbu pedas kemangi sangat mudah untuk didapatkan dan juga kamu pun boleh menghidangkannya sendiri di tempatmu. ayam tepung bumbu pedas kemangi dapat dibuat lewat beraneka cara. Kini pun ada banyak sekali resep kekinian yang menjadikan ayam tepung bumbu pedas kemangi semakin enak.

Resep ayam tepung bumbu pedas kemangi pun gampang sekali untuk dibuat, lho. Kita tidak usah ribet-ribet untuk membeli ayam tepung bumbu pedas kemangi, tetapi Kita bisa menyajikan sendiri di rumah. Untuk Kamu yang ingin menghidangkannya, dibawah ini merupakan resep membuat ayam tepung bumbu pedas kemangi yang lezat yang dapat Kamu coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Ayam tepung bumbu pedas kemangi:

1. Sediakan 1/2 ekor ayam
1. Sediakan 1 Iket kecil daun kemangi
1. Sediakan  Tomat ijo kecil (iris sesuai selera)
1. Ambil  Bawang Bombay seperempat aja
1. Sediakan  Tepung kentaqi (terserah pake merek sesuai selera)
1. Siapkan  Bumbu halus
1. Siapkan 4 cabe merah besar
1. Sediakan 8 cabe rawit hijau
1. Siapkan 4 siung bawang merah
1. Siapkan 2 siung bawang putih
1. Sediakan 2 kemiri
1. Ambil  Kunyit bubuk sedikit aja
1. Ambil secukupnya Garam
1. Gunakan secukupnya Gula
1. Ambil secukupnya Penyedap rasa
1. Gunakan  Air
1. Ambil  Minyak
1. Sediakan secukupnya Saus tiram
1. Ambil secukupnya Lada bubuk




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam tepung bumbu pedas kemangi:

1. Potong ayam sesuai selera cuci bersih lalu terserah mau di rebus dulu apa gak...kalau saya tak rebus dulu setelah matang angkat dinginkan bentar
1. Ambil tepung kentaqi nya setelah itu Ambil 2 sendok dan kasih air dingin secukupnya...lalu ambil ayam celupkan d adonan basah lalu guling kan keadonan kering... lakukan sampe selesai...
1. Setelah itu panaskan minyak lalu goreng ayam tepung nya hingga matang...setelah matang angkat dan tiriskan
1. Petikin daun kemangi nya lalu cuci bersih
1. Potong tomat hijau dan bawang Bombay nya
1. Panaskan minyak goreng secukupnya untuk menumis... - Tumis bawang Bombay dulu hingga harum dan matang lalu masukkan bumbu yg sudah di haluskan tadi...masak hingga matang... tambahkan garam...aduk lalu masukkan gula secukupnya...aduk lalu masukkan air sedikit aja...masak bentr..lalu masukkan ayam tepung nya.... terus aduk perlahan aja...
1. Lalu masukkan tomat hijau dan daun kemangi nya...aduk perlahan hingga rata dan matang... tambahkan penyedab rasa,lada bubuk aduk rata lalu masukkan saus tiram secukupnya masak aduk rata....tes rasa kalau d rasa sudah pas..dan matang angkat terus sajikan....




Wah ternyata resep ayam tepung bumbu pedas kemangi yang lezat tidak ribet ini mudah banget ya! Semua orang dapat membuatnya. Cara Membuat ayam tepung bumbu pedas kemangi Sangat sesuai banget buat kita yang baru belajar memasak atau juga bagi anda yang sudah hebat memasak.

Tertarik untuk mencoba membuat resep ayam tepung bumbu pedas kemangi mantab simple ini? Kalau kamu tertarik, mending kamu segera buruan siapin peralatan dan bahannya, lantas buat deh Resep ayam tepung bumbu pedas kemangi yang mantab dan simple ini. Sungguh taidak sulit kan. 

Maka, daripada kalian diam saja, ayo kita langsung bikin resep ayam tepung bumbu pedas kemangi ini. Dijamin kalian tak akan nyesel sudah membuat resep ayam tepung bumbu pedas kemangi mantab tidak rumit ini! Selamat mencoba dengan resep ayam tepung bumbu pedas kemangi nikmat tidak rumit ini di tempat tinggal masing-masing,oke!.

