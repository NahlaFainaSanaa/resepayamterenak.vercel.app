---
description: "Resep Nasi Bakar Ayam Suwir Kemangi✨ yang nikmat dan Mudah Dibuat"
title: "Resep Nasi Bakar Ayam Suwir Kemangi✨ yang nikmat dan Mudah Dibuat"
slug: 44-resep-nasi-bakar-ayam-suwir-kemangi-yang-nikmat-dan-mudah-dibuat
date: 2021-02-14T06:35:58.683Z
image: https://img-global.cpcdn.com/recipes/d422f0874478a9a1/680x482cq70/nasi-bakar-ayam-suwir-kemangi✨-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d422f0874478a9a1/680x482cq70/nasi-bakar-ayam-suwir-kemangi✨-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d422f0874478a9a1/680x482cq70/nasi-bakar-ayam-suwir-kemangi✨-foto-resep-utama.jpg
author: Matilda Ramirez
ratingvalue: 3.3
reviewcount: 12
recipeingredient:
- " bahan utama"
- "500 gr dada ayam ambil air kaldu"
- "1 ikat kemangi"
- "7 lembar daun jeruk"
- "7 lembar daun salam"
- "3 batang serai"
- "1 sdm air jeruk nipis"
- "2,5 sdm saus tiram"
- "1 sdm minyak wijen"
- "1,5 sdm gula pasir"
- "2 sdt garam halus"
- "1 sdm kaldu jamur"
- "1 sdt lada bubuk"
- "8 sdm kaldu ayam"
- " bumbu halus"
- "20 buah cabai rawit merah cabai setan"
- "20 buah cabai merah keriting"
- "1 buah tomat buang biji"
- "10 siung bawang merah"
- "5 siung bawang putih"
- "2 cm kunyit"
- "2 cm jahe"
- "2 cm kencur"
- "3 sdm minyak goreng"
recipeinstructions:
- "Kukus ayam dengan 2 batang serai, 4 lembar daun jeruk, 4 lembar daun salam. Suwir2 dan ambil air kaldu nya."
- "Tumis bumbu halus, tambahkan serai, daun jeruk, daun salam, air jeruk nipis, saus tiram, gula, garam, kaldu jamur, lada, minyak wijen.   Tumis hingga wangi, lalu tambahkan 8 sdm kaldu ayam, tunggu sampai sedikit mengering."
- "Masukkan ayam suwir, aduk hingga rata."
- "Tambahkan kemangi, aduk hingga kemangi layu."
- "Siapkan daun pisang yang sudah di bersihkan (di lap basah dan kering lalu di layur di api kompor agar tidak kaku), tambahkan nasi dan ayam suwir."
- "Bungkus daun pisang lalu bakar di teflon hingga daun pisang sedikit hangus dan wangi."
- "Siap disajikan! Bisa di tambah telor ceplok biar lebih sedep."
categories:
- Resep
tags:
- nasi
- bakar
- ayam

katakunci: nasi bakar ayam 
nutrition: 283 calories
recipecuisine: Indonesian
preptime: "PT34M"
cooktime: "PT52M"
recipeyield: "1"
recipecategory: Lunch

---


![Nasi Bakar Ayam Suwir Kemangi✨](https://img-global.cpcdn.com/recipes/d422f0874478a9a1/680x482cq70/nasi-bakar-ayam-suwir-kemangi✨-foto-resep-utama.jpg)

Andai kita seorang wanita, menyuguhkan santapan mantab untuk keluarga tercinta adalah suatu hal yang menggembirakan bagi kamu sendiri. Tugas seorang istri bukan cuman mengurus rumah saja, tetapi kamu juga harus memastikan keperluan nutrisi tercukupi dan hidangan yang dikonsumsi orang tercinta wajib mantab.

Di zaman  saat ini, kita memang dapat mengorder olahan siap saji walaupun tanpa harus capek membuatnya dahulu. Namun ada juga lho orang yang selalu ingin menyajikan yang terenak untuk orang tercintanya. Lantaran, menghidangkan masakan sendiri jauh lebih bersih dan kita pun bisa menyesuaikan sesuai masakan kesukaan famili. 



Mungkinkah anda adalah salah satu penikmat nasi bakar ayam suwir kemangi✨?. Asal kamu tahu, nasi bakar ayam suwir kemangi✨ merupakan makanan khas di Nusantara yang saat ini digemari oleh orang-orang di berbagai tempat di Nusantara. Kita dapat menyajikan nasi bakar ayam suwir kemangi✨ buatan sendiri di rumah dan pasti jadi hidangan kegemaranmu di akhir pekanmu.

Anda jangan bingung jika kamu ingin mendapatkan nasi bakar ayam suwir kemangi✨, sebab nasi bakar ayam suwir kemangi✨ tidak sukar untuk didapatkan dan kamu pun dapat membuatnya sendiri di rumah. nasi bakar ayam suwir kemangi✨ dapat dibuat dengan berbagai cara. Saat ini telah banyak banget cara kekinian yang menjadikan nasi bakar ayam suwir kemangi✨ semakin lebih mantap.

Resep nasi bakar ayam suwir kemangi✨ pun sangat mudah dihidangkan, lho. Anda tidak perlu capek-capek untuk memesan nasi bakar ayam suwir kemangi✨, sebab Kita dapat menyiapkan sendiri di rumah. Untuk Kamu yang akan menyajikannya, berikut ini resep menyajikan nasi bakar ayam suwir kemangi✨ yang mantab yang dapat Kalian coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Nasi Bakar Ayam Suwir Kemangi✨:

1. Ambil  bahan utama
1. Gunakan 500 gr dada ayam (ambil air kaldu)
1. Siapkan 1 ikat kemangi
1. Sediakan 7 lembar daun jeruk
1. Sediakan 7 lembar daun salam
1. Gunakan 3 batang serai
1. Ambil 1 sdm air jeruk nipis
1. Gunakan 2,5 sdm saus tiram
1. Gunakan 1 sdm minyak wijen
1. Siapkan 1,5 sdm gula pasir
1. Gunakan 2 sdt garam halus
1. Ambil 1 sdm kaldu jamur
1. Gunakan 1 sdt lada bubuk
1. Gunakan 8 sdm kaldu ayam
1. Siapkan  bumbu halus
1. Sediakan 20 buah cabai rawit merah (cabai setan)
1. Ambil 20 buah cabai merah keriting
1. Gunakan 1 buah tomat (buang biji)
1. Ambil 10 siung bawang merah
1. Gunakan 5 siung bawang putih
1. Sediakan 2 cm kunyit
1. Sediakan 2 cm jahe
1. Ambil 2 cm kencur
1. Sediakan 3 sdm minyak goreng




<!--inarticleads2-->

##### Cara membuat Nasi Bakar Ayam Suwir Kemangi✨:

1. Kukus ayam dengan 2 batang serai, 4 lembar daun jeruk, 4 lembar daun salam. Suwir2 dan ambil air kaldu nya.
1. Tumis bumbu halus, tambahkan serai, daun jeruk, daun salam, air jeruk nipis, saus tiram, gula, garam, kaldu jamur, lada, minyak wijen.  -  - Tumis hingga wangi, lalu tambahkan 8 sdm kaldu ayam, tunggu sampai sedikit mengering.
1. Masukkan ayam suwir, aduk hingga rata.
1. Tambahkan kemangi, aduk hingga kemangi layu.
1. Siapkan daun pisang yang sudah di bersihkan (di lap basah dan kering lalu di layur di api kompor agar tidak kaku), tambahkan nasi dan ayam suwir.
1. Bungkus daun pisang lalu bakar di teflon hingga daun pisang sedikit hangus dan wangi.
1. Siap disajikan! - Bisa di tambah telor ceplok biar lebih sedep.




Wah ternyata resep nasi bakar ayam suwir kemangi✨ yang nikamt tidak ribet ini enteng sekali ya! Kamu semua dapat mencobanya. Cara buat nasi bakar ayam suwir kemangi✨ Sesuai sekali buat anda yang baru mau belajar memasak ataupun bagi kamu yang telah lihai dalam memasak.

Tertarik untuk mencoba membikin resep nasi bakar ayam suwir kemangi✨ nikmat simple ini? Kalau tertarik, ayo kamu segera siapin peralatan dan bahan-bahannya, lalu bikin deh Resep nasi bakar ayam suwir kemangi✨ yang enak dan simple ini. Sungguh gampang kan. 

Jadi, daripada kita diam saja, hayo kita langsung bikin resep nasi bakar ayam suwir kemangi✨ ini. Pasti kalian gak akan nyesel bikin resep nasi bakar ayam suwir kemangi✨ mantab simple ini! Selamat berkreasi dengan resep nasi bakar ayam suwir kemangi✨ mantab sederhana ini di tempat tinggal sendiri,ya!.

