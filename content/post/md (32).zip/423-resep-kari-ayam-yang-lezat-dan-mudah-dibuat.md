---
description: "Resep Kari ayam yang lezat dan Mudah Dibuat"
title: "Resep Kari ayam yang lezat dan Mudah Dibuat"
slug: 423-resep-kari-ayam-yang-lezat-dan-mudah-dibuat
date: 2021-03-02T08:12:12.191Z
image: https://img-global.cpcdn.com/recipes/f897c5652ea54002/680x482cq70/kari-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f897c5652ea54002/680x482cq70/kari-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f897c5652ea54002/680x482cq70/kari-ayam-foto-resep-utama.jpg
author: Derek Andrews
ratingvalue: 4.9
reviewcount: 15
recipeingredient:
- "7 potong ayam"
- "5 siung Bawang merah"
- "6 siung bawang putih"
- "3 bh kemiri"
- "5 bh cabe merah"
- "1 ruas jahe"
- "1 ruas laos geprek"
- "1 ruas kunyit"
- "1 batang sereh geprek"
- "1 bh kapulaga"
- "2 bh bunga lawang"
- "200 ml santan atau bisa diganti kara cukup 1bks kcl"
- "1/2 lbr daun kunyit"
- "4 lbr daun jeruk"
- "2 lbr daun salam"
- "secukupnya Garam dan gula"
recipeinstructions:
- "Cuci bersih ayam, tiriskan"
- "Blender halus bawang, cabe, kemiri, jahe, kunyit"
- "Tumis bumbu halus, masukkan salam, sereh, laos, daun jeruk, daun kunyit, kapulaga, dan bunga lawang. Tumis sampai harum"
- "Masukkan ayam, bolak balik hingga bumbu tercampur"
- "Masukkan air secukupnya, aduk rata, masukkan santan, garam, gula. Aduk rata"
- "Tunggu hingga daging empuk, sambil diaduk sesekali. Cek rasa. Sajikan dengan ditaburi bawang goreng"
categories:
- Resep
tags:
- kari
- ayam

katakunci: kari ayam 
nutrition: 211 calories
recipecuisine: Indonesian
preptime: "PT38M"
cooktime: "PT43M"
recipeyield: "4"
recipecategory: Dinner

---


![Kari ayam](https://img-global.cpcdn.com/recipes/f897c5652ea54002/680x482cq70/kari-ayam-foto-resep-utama.jpg)

Selaku seorang orang tua, menyajikan santapan menggugah selera untuk famili merupakan hal yang sangat menyenangkan untuk kamu sendiri. Tugas seorang istri bukan saja menjaga rumah saja, tapi anda pun wajib menyediakan kebutuhan gizi terpenuhi dan masakan yang dikonsumsi keluarga tercinta harus menggugah selera.

Di masa  saat ini, kamu sebenarnya dapat mengorder masakan siap saji meski tanpa harus ribet membuatnya terlebih dahulu. Tetapi ada juga orang yang memang ingin memberikan yang terlezat bagi orang tercintanya. Pasalnya, menghidangkan masakan sendiri akan jauh lebih higienis dan bisa menyesuaikan masakan tersebut berdasarkan makanan kesukaan famili. 



Mungkinkah anda adalah seorang penyuka kari ayam?. Tahukah kamu, kari ayam merupakan makanan khas di Nusantara yang saat ini disukai oleh orang-orang di hampir setiap daerah di Indonesia. Kita bisa memasak kari ayam sendiri di rumahmu dan boleh dijadikan santapan favoritmu di hari liburmu.

Kamu tak perlu bingung untuk memakan kari ayam, karena kari ayam sangat mudah untuk dicari dan juga anda pun bisa membuatnya sendiri di rumah. kari ayam bisa dibuat lewat berbagai cara. Sekarang telah banyak sekali cara modern yang membuat kari ayam semakin nikmat.

Resep kari ayam pun sangat mudah dibikin, lho. Kalian tidak usah repot-repot untuk memesan kari ayam, sebab Kita dapat menghidangkan sendiri di rumah. Untuk Kita yang akan menghidangkannya, berikut cara membuat kari ayam yang mantab yang mampu Kamu hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Kari ayam:

1. Siapkan 7 potong ayam
1. Ambil 5 siung Bawang merah
1. Sediakan 6 siung bawang putih
1. Ambil 3 bh kemiri
1. Siapkan 5 bh cabe merah
1. Sediakan 1 ruas jahe
1. Ambil 1 ruas laos, geprek
1. Ambil 1 ruas kunyit
1. Sediakan 1 batang sereh, geprek
1. Gunakan 1 bh kapulaga
1. Sediakan 2 bh bunga lawang
1. Gunakan 200 ml santan atau bisa diganti kara (cukup 1bks kcl)
1. Ambil 1/2 lbr daun kunyit
1. Gunakan 4 lbr daun jeruk
1. Siapkan 2 lbr daun salam
1. Ambil secukupnya Garam dan gula




<!--inarticleads2-->

##### Cara membuat Kari ayam:

1. Cuci bersih ayam, tiriskan
1. Blender halus bawang, cabe, kemiri, jahe, kunyit
1. Tumis bumbu halus, masukkan salam, sereh, laos, daun jeruk, daun kunyit, kapulaga, dan bunga lawang. Tumis sampai harum
1. Masukkan ayam, bolak balik hingga bumbu tercampur
1. Masukkan air secukupnya, aduk rata, masukkan santan, garam, gula. Aduk rata
1. Tunggu hingga daging empuk, sambil diaduk sesekali. Cek rasa. Sajikan dengan ditaburi bawang goreng




Wah ternyata cara buat kari ayam yang enak tidak rumit ini gampang sekali ya! Kalian semua dapat memasaknya. Resep kari ayam Sangat sesuai sekali buat kalian yang sedang belajar memasak ataupun untuk anda yang sudah ahli memasak.

Tertarik untuk mulai mencoba membikin resep kari ayam enak tidak ribet ini? Kalau kamu ingin, mending kamu segera siapkan alat dan bahan-bahannya, lantas bikin deh Resep kari ayam yang mantab dan tidak rumit ini. Benar-benar taidak sulit kan. 

Oleh karena itu, ketimbang kamu berlama-lama, hayo kita langsung saja sajikan resep kari ayam ini. Pasti anda gak akan nyesel sudah buat resep kari ayam lezat simple ini! Selamat berkreasi dengan resep kari ayam lezat tidak rumit ini di tempat tinggal sendiri,ya!.

