---
description: "Cara membuat Lontong Kari Ayam yang enak Untuk Jualan"
title: "Cara membuat Lontong Kari Ayam yang enak Untuk Jualan"
slug: 361-cara-membuat-lontong-kari-ayam-yang-enak-untuk-jualan
date: 2021-03-07T18:43:35.759Z
image: https://img-global.cpcdn.com/recipes/c618a8dd19a9a9b4/680x482cq70/lontong-kari-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c618a8dd19a9a9b4/680x482cq70/lontong-kari-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c618a8dd19a9a9b4/680x482cq70/lontong-kari-ayam-foto-resep-utama.jpg
author: Daniel Ferguson
ratingvalue: 3.2
reviewcount: 11
recipeingredient:
- " Bahan lontong"
- "3 cup beras"
- "Plastik tahan panas"
- " Bahan kari"
- "1/2 kg ayam"
- "1 1/2 ruas jari lengkuas memarkan"
- "1 1/2 luas jari jahe memarkan"
- "3 lembar daun salam"
- "4 lembar daun jeruk"
- "2 batang serai memarkan"
- "90 ml santan instan"
- "Secukupnya air"
- "1 sdt gula merah sisir"
- " Garam merica kaldu bubuk gula pasir"
- " Bumbu halus"
- "7 siung bawang merah"
- "5 siung bawang putih"
- "4 buah cabe merah besar buang bijinya"
- "4 butir kemiri"
- "1 sdt ketumbar"
- "1 sdt jinten"
- " Pelengkap"
- " Telur rebus"
- " Emping"
- " Kacang kedelai goreng"
- " Bawang goreng"
- " Kecap manis"
- " Jeruk limau"
recipeinstructions:
- "Buat lontong terlebih dahulu :"
- "Cuci bersih beras &amp; rendam selama 30 menit. Tiriskan"
- "Masukkan ke dalam plastik tahan panas sebanyak 1/2 lebih sedikit dari volume plastik. Seal / rekatkan plastik. Tusuk2 dengan bantuan tusuk sate/garpu supaya air dapat masuk"
- "Didihkan secukupnya air. Rebus beras selama 20 menit atau sampai lontong matang &amp; padat. Tunggu dingin &amp; menjadi set. Sisihkan"
- "Buat kari :"
- "Didihkan air dalam panci. masukkan ayam yang sudah dicuci bersih &amp; tambahkan garam. Rebus sampai ayam empuk"
- "Keluarkan ayam dari rebusan kaldu. Suwir2 &amp; sisihkan"
- "Tumis bumbu halus bersama daun salam, daun jeruk, jahe, lengkuas &amp; serai sampai harum"
- "Masukkan tumisan bumbu ke dalam panci rebusan kaldu. Aduk rata"
- "Tambahkan gula merah &amp; sisa bumbu. Terakhir tuang santan. Aduk rata &amp; koreksi rasa"
- "Penyajian: tata irisan lontong di piring saji. Tuang kuah kari, taburi ayam suir, kacang kedelai &amp; bawang goreng. Beri sedikit kecap manis. Lengkapai dengan telur rebus, jeruk limau &amp; emping"
categories:
- Resep
tags:
- lontong
- kari
- ayam

katakunci: lontong kari ayam 
nutrition: 273 calories
recipecuisine: Indonesian
preptime: "PT35M"
cooktime: "PT56M"
recipeyield: "1"
recipecategory: Dessert

---


![Lontong Kari Ayam](https://img-global.cpcdn.com/recipes/c618a8dd19a9a9b4/680x482cq70/lontong-kari-ayam-foto-resep-utama.jpg)

Sebagai seorang yang hobi memasak, mempersiapkan hidangan sedap untuk famili merupakan suatu hal yang menyenangkan untuk anda sendiri. Kewajiban seorang ibu Tidak saja menjaga rumah saja, tapi kamu juga wajib menyediakan kebutuhan gizi terpenuhi dan santapan yang disantap orang tercinta harus nikmat.

Di waktu  sekarang, kamu sebenarnya mampu mengorder olahan praktis tanpa harus repot memasaknya lebih dulu. Tetapi ada juga lho orang yang selalu ingin menghidangkan yang terlezat untuk orang tercintanya. Sebab, menghidangkan masakan yang dibuat sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan sesuai makanan kesukaan keluarga tercinta. 



Apakah anda seorang penyuka lontong kari ayam?. Tahukah kamu, lontong kari ayam merupakan sajian khas di Nusantara yang sekarang disenangi oleh banyak orang di berbagai tempat di Indonesia. Kalian dapat memasak lontong kari ayam olahan sendiri di rumah dan dapat dijadikan hidangan kegemaranmu di akhir pekan.

Anda tidak usah bingung jika kamu ingin menyantap lontong kari ayam, sebab lontong kari ayam sangat mudah untuk dicari dan kamu pun bisa memasaknya sendiri di tempatmu. lontong kari ayam boleh dimasak lewat beraneka cara. Kini pun sudah banyak resep kekinian yang membuat lontong kari ayam lebih mantap.

Resep lontong kari ayam pun sangat mudah untuk dibikin, lho. Kalian tidak usah repot-repot untuk membeli lontong kari ayam, karena Kamu dapat membuatnya sendiri di rumah. Untuk Anda yang hendak menghidangkannya, berikut ini resep membuat lontong kari ayam yang nikamat yang dapat Kalian buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Lontong Kari Ayam:

1. Gunakan  Bahan lontong
1. Ambil 3 cup beras
1. Gunakan Plastik tahan panas
1. Sediakan  Bahan kari
1. Siapkan 1/2 kg ayam
1. Gunakan 1 1/2 ruas jari lengkuas, memarkan
1. Ambil 1 1/2 luas jari jahe, memarkan
1. Siapkan 3 lembar daun salam
1. Gunakan 4 lembar daun jeruk
1. Sediakan 2 batang serai, memarkan
1. Gunakan 90 ml santan instan
1. Siapkan Secukupnya air
1. Gunakan 1 sdt gula merah, sisir
1. Gunakan  Garam, merica, kaldu bubuk, gula pasir
1. Siapkan  Bumbu halus
1. Sediakan 7 siung bawang merah
1. Ambil 5 siung bawang putih
1. Ambil 4 buah cabe merah besar, buang bijinya
1. Siapkan 4 butir kemiri
1. Ambil 1 sdt ketumbar
1. Gunakan 1 sdt jinten
1. Gunakan  Pelengkap
1. Siapkan  Telur rebus,
1. Gunakan  Emping
1. Siapkan  Kacang kedelai goreng
1. Siapkan  Bawang goreng
1. Sediakan  Kecap manis
1. Ambil  Jeruk limau




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Lontong Kari Ayam:

1. Buat lontong terlebih dahulu :
1. Cuci bersih beras &amp; rendam selama 30 menit. Tiriskan
1. Masukkan ke dalam plastik tahan panas sebanyak 1/2 lebih sedikit dari volume plastik. Seal / rekatkan plastik. Tusuk2 dengan bantuan tusuk sate/garpu supaya air dapat masuk
1. Didihkan secukupnya air. Rebus beras selama 20 menit atau sampai lontong matang &amp; padat. Tunggu dingin &amp; menjadi set. Sisihkan
1. Buat kari :
1. Didihkan air dalam panci. masukkan ayam yang sudah dicuci bersih &amp; tambahkan garam. Rebus sampai ayam empuk
1. Keluarkan ayam dari rebusan kaldu. Suwir2 &amp; sisihkan
1. Tumis bumbu halus bersama daun salam, daun jeruk, jahe, lengkuas &amp; serai sampai harum
1. Masukkan tumisan bumbu ke dalam panci rebusan kaldu. Aduk rata
1. Tambahkan gula merah &amp; sisa bumbu. Terakhir tuang santan. Aduk rata &amp; koreksi rasa
1. Penyajian: tata irisan lontong di piring saji. Tuang kuah kari, taburi ayam suir, kacang kedelai &amp; bawang goreng. Beri sedikit kecap manis. Lengkapai dengan telur rebus, jeruk limau &amp; emping




Ternyata cara membuat lontong kari ayam yang mantab tidak rumit ini gampang banget ya! Semua orang bisa mencobanya. Cara buat lontong kari ayam Sesuai sekali untuk kita yang sedang belajar memasak ataupun juga untuk anda yang sudah ahli dalam memasak.

Apakah kamu ingin mulai mencoba membuat resep lontong kari ayam lezat simple ini? Kalau ingin, ayo kalian segera buruan siapin peralatan dan bahannya, lantas bikin deh Resep lontong kari ayam yang lezat dan sederhana ini. Benar-benar mudah kan. 

Oleh karena itu, ketimbang kamu berlama-lama, yuk kita langsung saja sajikan resep lontong kari ayam ini. Pasti anda gak akan menyesal membuat resep lontong kari ayam mantab tidak rumit ini! Selamat berkreasi dengan resep lontong kari ayam enak tidak ribet ini di rumah sendiri,ya!.

