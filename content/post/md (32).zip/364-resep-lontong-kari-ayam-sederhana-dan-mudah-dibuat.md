---
description: "Resep Lontong kari ayam Sederhana dan Mudah Dibuat"
title: "Resep Lontong kari ayam Sederhana dan Mudah Dibuat"
slug: 364-resep-lontong-kari-ayam-sederhana-dan-mudah-dibuat
date: 2021-03-20T16:33:06.448Z
image: https://img-global.cpcdn.com/recipes/8c6945eec19fc3b9/680x482cq70/lontong-kari-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8c6945eec19fc3b9/680x482cq70/lontong-kari-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8c6945eec19fc3b9/680x482cq70/lontong-kari-ayam-foto-resep-utama.jpg
author: Linnie Meyer
ratingvalue: 3.5
reviewcount: 15
recipeingredient:
- "4 potong ayam"
- " Jeruk nipis"
- "1 batang serai memarkan"
- "2 lembar daun jeruk buang tulangnya"
- "1 liter air"
- "1 buat Labu siam potong korek api opsional"
- "1 bungkus Santan kara kecil"
- "2 sdt garam"
- "1/2 keping gula merah kecil"
- "1 sdt gula pasir"
- "2 sdt kaldu bubuk"
- " Minyak untuk menumis"
- " Bumbu halus"
- "5 siung bawang merah"
- "3 siung bawang putih"
- "2 butir Kemiri sangrai"
- "2 buah cabe merah buang bijinya"
- "1 cm kunyit bakar"
- "1/2 cm jahe"
- "1 sdt ketumbar bubuk"
recipeinstructions:
- "Bersihkan ayam, lumuri jeruk nipis, diamkan, bilas bersih ketika akan dimasak"
- "Haluskan bumbu, tumis hingga bumbu matang (wangi dan kadar air berkurang), masukkan serai dan daun jeruk, tumis kembali sebentar."
- "Masukkan ayam, aduk aduk sebentar, lalu masukkan air. Masak hingga ayam matang. Setelah itu masukkan labu siam, garam, gula merah, gula pasir dan kaldu jamur dan Santan. Masak hingga Labu matang. Jangan lupa koreksi rasa ya."
- "Lontong kari ayam siap dinikmati dengan lontong nasi, kerupuk, sambal dan sedikit kecap manis."
categories:
- Resep
tags:
- lontong
- kari
- ayam

katakunci: lontong kari ayam 
nutrition: 242 calories
recipecuisine: Indonesian
preptime: "PT34M"
cooktime: "PT32M"
recipeyield: "3"
recipecategory: Dinner

---


![Lontong kari ayam](https://img-global.cpcdn.com/recipes/8c6945eec19fc3b9/680x482cq70/lontong-kari-ayam-foto-resep-utama.jpg)

Andai anda seorang istri, menyajikan olahan menggugah selera kepada keluarga tercinta adalah hal yang sangat menyenangkan untuk anda sendiri. Tugas seorang istri Tidak cuma mengatur rumah saja, tetapi anda juga harus menyediakan kebutuhan nutrisi terpenuhi dan juga hidangan yang dikonsumsi keluarga tercinta mesti menggugah selera.

Di waktu  sekarang, anda sebenarnya bisa membeli panganan praktis walaupun tanpa harus ribet memasaknya dulu. Tapi banyak juga mereka yang memang ingin memberikan makanan yang terbaik bagi orang tercintanya. Karena, memasak yang diolah sendiri jauh lebih bersih dan kita juga bisa menyesuaikan makanan tersebut sesuai selera keluarga. 



Apakah anda merupakan salah satu penikmat lontong kari ayam?. Asal kamu tahu, lontong kari ayam merupakan hidangan khas di Indonesia yang kini disenangi oleh orang-orang dari hampir setiap daerah di Indonesia. Kamu bisa menghidangkan lontong kari ayam sendiri di rumahmu dan boleh jadi camilan kesukaanmu di hari libur.

Anda tidak perlu bingung jika kamu ingin memakan lontong kari ayam, lantaran lontong kari ayam gampang untuk ditemukan dan juga kalian pun dapat membuatnya sendiri di tempatmu. lontong kari ayam boleh diolah lewat bermacam cara. Saat ini telah banyak banget resep modern yang menjadikan lontong kari ayam lebih mantap.

Resep lontong kari ayam juga sangat mudah dibuat, lho. Kalian jangan capek-capek untuk membeli lontong kari ayam, lantaran Anda mampu menyajikan di rumah sendiri. Bagi Kamu yang ingin menyajikannya, berikut resep untuk membuat lontong kari ayam yang lezat yang dapat Anda buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Lontong kari ayam:

1. Sediakan 4 potong ayam
1. Ambil  Jeruk nipis
1. Sediakan 1 batang serai memarkan
1. Ambil 2 lembar daun jeruk, buang tulangnya
1. Sediakan 1 liter air
1. Siapkan 1 buat Labu siam, potong korek api (opsional)
1. Sediakan 1 bungkus Santan kara kecil
1. Siapkan 2 sdt garam
1. Sediakan 1/2 keping gula merah kecil
1. Sediakan 1 sdt gula pasir
1. Sediakan 2 sdt kaldu bubuk
1. Gunakan  Minyak untuk menumis
1. Sediakan  Bumbu halus
1. Gunakan 5 siung bawang merah
1. Ambil 3 siung bawang putih
1. Sediakan 2 butir Kemiri sangrai
1. Gunakan 2 buah cabe merah buang bijinya
1. Ambil 1 cm kunyit bakar
1. Gunakan 1/2 cm jahe
1. Sediakan 1 sdt ketumbar bubuk




<!--inarticleads2-->

##### Cara membuat Lontong kari ayam:

1. Bersihkan ayam, lumuri jeruk nipis, diamkan, bilas bersih ketika akan dimasak
1. Haluskan bumbu, tumis hingga bumbu matang (wangi dan kadar air berkurang), masukkan serai dan daun jeruk, tumis kembali sebentar.
1. Masukkan ayam, aduk aduk sebentar, lalu masukkan air. Masak hingga ayam matang. Setelah itu masukkan labu siam, garam, gula merah, gula pasir dan kaldu jamur dan Santan. Masak hingga Labu matang. Jangan lupa koreksi rasa ya.
1. Lontong kari ayam siap dinikmati dengan lontong nasi, kerupuk, sambal dan sedikit kecap manis.




Ternyata cara buat lontong kari ayam yang lezat tidak ribet ini mudah banget ya! Anda Semua bisa membuatnya. Resep lontong kari ayam Sangat cocok sekali buat anda yang baru belajar memasak maupun juga untuk anda yang telah pandai memasak.

Apakah kamu ingin mulai mencoba bikin resep lontong kari ayam lezat tidak rumit ini? Kalau anda ingin, ayo kalian segera buruan siapkan peralatan dan bahannya, maka buat deh Resep lontong kari ayam yang nikmat dan tidak rumit ini. Sangat mudah kan. 

Oleh karena itu, daripada kamu berfikir lama-lama, hayo kita langsung saja bikin resep lontong kari ayam ini. Dijamin kalian tiidak akan nyesel sudah membuat resep lontong kari ayam lezat simple ini! Selamat berkreasi dengan resep lontong kari ayam nikmat tidak ribet ini di rumah kalian sendiri,ya!.

