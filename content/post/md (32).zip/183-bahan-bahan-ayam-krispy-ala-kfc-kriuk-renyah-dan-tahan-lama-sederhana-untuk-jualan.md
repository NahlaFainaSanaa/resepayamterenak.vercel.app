---
description: "Bahan-bahan Ayam krispy ala kfc kriuk renyah dan tahan lama Sederhana Untuk Jualan"
title: "Bahan-bahan Ayam krispy ala kfc kriuk renyah dan tahan lama Sederhana Untuk Jualan"
slug: 183-bahan-bahan-ayam-krispy-ala-kfc-kriuk-renyah-dan-tahan-lama-sederhana-untuk-jualan
date: 2021-02-08T05:25:02.844Z
image: https://img-global.cpcdn.com/recipes/203764cba15f4399/680x482cq70/ayam-krispy-ala-kfc-kriuk-renyah-dan-tahan-lama-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/203764cba15f4399/680x482cq70/ayam-krispy-ala-kfc-kriuk-renyah-dan-tahan-lama-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/203764cba15f4399/680x482cq70/ayam-krispy-ala-kfc-kriuk-renyah-dan-tahan-lama-foto-resep-utama.jpg
author: Jessie Clark
ratingvalue: 4.1
reviewcount: 8
recipeingredient:
- "1 ekor ayam uk  1kg"
- " Bumbu perendam "
- " Haluskan"
- "5-10 siung bawang putih"
- "2 buah cabe merah"
- "1 bungkus kaldu bubuk rasa ayam"
- "1 sendok teh merica bubuk"
- "1 sendok makan garam"
- "1 sendok makan ketumbar bubuk"
- "1 sendok teh cabai bubuk boleh skip"
- "1/2 sensok makan saus tiram"
- "1 butir telur kocok lepas dimasukan dibagian akhir setelah direndam"
- " Tepung kriuk"
- "400 gr terigu cakra  protein tinggi"
- "100 gr tepung maizena"
- "1 bungkus kaldu bubuk rasa ayam"
- "1 sendok makan bubuk cabai boleh dikurangidi skip"
- "1/2 sdt merica bubuk"
- "Secukupnya garam"
- " Bahan pelapis "
- "100 ml air"
- "3-4 cube es batu"
- "1 sendok teh soda kue"
- "5 sendok makan campuran tepung kriuk"
- " Minyak yang banyak untuk menggoreng dengan deep fried"
recipeinstructions:
- "Campur bumbu yang dihaluskan dengan bumbu perendam lainnya."
- "Siapkan ayam, tusuk-tusuk dengan garpu.. tambahkan campuran bumbu perendam. Remas-remas.. diamkan minimal 1 jam.. (rendam 1 malam didalam kulkas jika mau bumbunya lebih meresap)"
- "Siapkan campuran tepung kriuk.."
- "Siapkan campuran bumbu perendam"
- "Panaskan minyak, yang banyak ya. Supaya nnti ayamnya bisa terendam saat di goreng."
- "Siapkan ayam yang telah direndam. Masukan telur yang dikocok lepas. Aduk merata."
- "Masukan ayam ke dalam tepung kriuk. Remas remas sampai tepung menempel. Ketuk2 ayam kepinggiran baskom agar tepung yang tidak menempel akan jatuh."
- "Masukkan kedalam bumbu pelapis"
- "Masukkan lagi kedalam tepung kriuk. Remas-remas sambil di boleh balik sampai tepungnya menempel.."
- "Ketuk2 lagi dipinggir baskom sampai terbentuk kriwil-kriwilnya.."
- "Segera goreng dalam minyak panas yang banyak dengan api sedang. Ayam harus terendam semua didalam minyak ya. (emak pakai panci magic com kecil yang sudah tidak terpakai 😬😬)"
- "Goreng sampai kulit terlihat kuning kecoklatan. Pencet ayam dengan capit untuk memastikan sudah tidak lembek dan matang)"
- "Angkat dan tiriskan."
categories:
- Resep
tags:
- ayam
- krispy
- ala

katakunci: ayam krispy ala 
nutrition: 155 calories
recipecuisine: Indonesian
preptime: "PT29M"
cooktime: "PT38M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam krispy ala kfc kriuk renyah dan tahan lama](https://img-global.cpcdn.com/recipes/203764cba15f4399/680x482cq70/ayam-krispy-ala-kfc-kriuk-renyah-dan-tahan-lama-foto-resep-utama.jpg)

Selaku seorang ibu, mempersiapkan panganan mantab kepada orang tercinta merupakan suatu hal yang memuaskan bagi anda sendiri. Kewajiban seorang ibu Tidak cuma mengatur rumah saja, namun anda pun wajib menyediakan kebutuhan gizi terpenuhi dan juga masakan yang disantap keluarga tercinta harus lezat.

Di era  sekarang, kamu sebenarnya bisa memesan panganan praktis tanpa harus repot memasaknya dahulu. Tapi banyak juga lho orang yang memang ingin memberikan yang terlezat untuk orang tercintanya. Lantaran, memasak sendiri jauh lebih higienis dan kita juga bisa menyesuaikan hidangan tersebut berdasarkan selera famili. 



Mungkinkah anda merupakan seorang penikmat ayam krispy ala kfc kriuk renyah dan tahan lama?. Tahukah kamu, ayam krispy ala kfc kriuk renyah dan tahan lama adalah sajian khas di Nusantara yang sekarang disenangi oleh banyak orang di hampir setiap wilayah di Nusantara. Anda bisa memasak ayam krispy ala kfc kriuk renyah dan tahan lama buatan sendiri di rumah dan boleh jadi hidangan favorit di hari liburmu.

Kamu tak perlu bingung jika kamu ingin memakan ayam krispy ala kfc kriuk renyah dan tahan lama, karena ayam krispy ala kfc kriuk renyah dan tahan lama tidak sukar untuk didapatkan dan kita pun boleh membuatnya sendiri di tempatmu. ayam krispy ala kfc kriuk renyah dan tahan lama boleh dibuat memalui beraneka cara. Saat ini telah banyak resep modern yang menjadikan ayam krispy ala kfc kriuk renyah dan tahan lama lebih lezat.

Resep ayam krispy ala kfc kriuk renyah dan tahan lama pun gampang sekali untuk dibikin, lho. Kita tidak usah repot-repot untuk memesan ayam krispy ala kfc kriuk renyah dan tahan lama, karena Kita dapat menyiapkan di rumahmu. Untuk Anda yang mau menyajikannya, di bawah ini adalah resep menyajikan ayam krispy ala kfc kriuk renyah dan tahan lama yang mantab yang mampu Kamu buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Ayam krispy ala kfc kriuk renyah dan tahan lama:

1. Gunakan 1 ekor ayam uk +/- 1kg
1. Sediakan  Bumbu perendam :
1. Ambil  Haluskan:
1. Gunakan 5-10 siung bawang putih
1. Gunakan 2 buah cabe merah
1. Ambil 1 bungkus kaldu bubuk rasa ayam
1. Siapkan 1 sendok teh merica bubuk
1. Ambil 1 sendok makan garam
1. Ambil 1 sendok makan ketumbar bubuk
1. Ambil 1 sendok teh cabai bubuk (boleh skip)
1. Sediakan 1/2 sensok makan saus tiram
1. Sediakan 1 butir telur, kocok lepas (dimasukan dibagian akhir setelah direndam)
1. Sediakan  Tepung kriuk:
1. Siapkan 400 gr terigu cakra / protein tinggi
1. Ambil 100 gr tepung maizena
1. Gunakan 1 bungkus kaldu bubuk rasa ayam
1. Ambil 1 sendok makan bubuk cabai (boleh dikurangi/di skip)
1. Siapkan 1/2 sdt merica bubuk
1. Ambil Secukupnya garam
1. Ambil  Bahan pelapis :
1. Gunakan 100 ml air
1. Siapkan 3-4 cube es batu
1. Siapkan 1 sendok teh soda kue
1. Sediakan 5 sendok makan campuran tepung kriuk
1. Sediakan  Minyak yang banyak untuk menggoreng dengan deep fried




<!--inarticleads2-->

##### Cara membuat Ayam krispy ala kfc kriuk renyah dan tahan lama:

1. Campur bumbu yang dihaluskan dengan bumbu perendam lainnya.
1. Siapkan ayam, tusuk-tusuk dengan garpu.. tambahkan campuran bumbu perendam. Remas-remas.. diamkan minimal 1 jam.. (rendam 1 malam didalam kulkas jika mau bumbunya lebih meresap)
1. Siapkan campuran tepung kriuk..
1. Siapkan campuran bumbu perendam
1. Panaskan minyak, yang banyak ya. Supaya nnti ayamnya bisa terendam saat di goreng.
1. Siapkan ayam yang telah direndam. Masukan telur yang dikocok lepas. Aduk merata.
1. Masukan ayam ke dalam tepung kriuk. Remas remas sampai tepung menempel. Ketuk2 ayam kepinggiran baskom agar tepung yang tidak menempel akan jatuh.
1. Masukkan kedalam bumbu pelapis
1. Masukkan lagi kedalam tepung kriuk. Remas-remas sambil di boleh balik sampai tepungnya menempel..
1. Ketuk2 lagi dipinggir baskom sampai terbentuk kriwil-kriwilnya..
1. Segera goreng dalam minyak panas yang banyak dengan api sedang. Ayam harus terendam semua didalam minyak ya. (emak pakai panci magic com kecil yang sudah tidak terpakai 😬😬)
1. Goreng sampai kulit terlihat kuning kecoklatan. Pencet ayam dengan capit untuk memastikan sudah tidak lembek dan matang)
1. Angkat dan tiriskan.




Ternyata cara buat ayam krispy ala kfc kriuk renyah dan tahan lama yang mantab sederhana ini enteng banget ya! Anda Semua mampu menghidangkannya. Resep ayam krispy ala kfc kriuk renyah dan tahan lama Sangat cocok banget untuk kita yang baru mau belajar memasak atau juga untuk kamu yang telah pandai dalam memasak.

Tertarik untuk mulai mencoba membikin resep ayam krispy ala kfc kriuk renyah dan tahan lama nikmat tidak rumit ini? Kalau kamu tertarik, mending kamu segera siapin alat-alat dan bahannya, lantas bikin deh Resep ayam krispy ala kfc kriuk renyah dan tahan lama yang lezat dan tidak rumit ini. Sangat taidak sulit kan. 

Jadi, daripada kamu berlama-lama, hayo langsung aja buat resep ayam krispy ala kfc kriuk renyah dan tahan lama ini. Dijamin kamu gak akan menyesal sudah buat resep ayam krispy ala kfc kriuk renyah dan tahan lama lezat tidak rumit ini! Selamat mencoba dengan resep ayam krispy ala kfc kriuk renyah dan tahan lama nikmat tidak ribet ini di rumah sendiri,oke!.

