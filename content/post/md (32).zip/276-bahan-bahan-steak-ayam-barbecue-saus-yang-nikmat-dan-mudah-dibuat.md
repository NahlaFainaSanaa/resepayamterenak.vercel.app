---
description: "Bahan-bahan Steak Ayam Barbecue Saus yang nikmat dan Mudah Dibuat"
title: "Bahan-bahan Steak Ayam Barbecue Saus yang nikmat dan Mudah Dibuat"
slug: 276-bahan-bahan-steak-ayam-barbecue-saus-yang-nikmat-dan-mudah-dibuat
date: 2021-02-28T21:30:49.742Z
image: https://img-global.cpcdn.com/recipes/f330037b06a07291/680x482cq70/steak-ayam-barbecue-saus-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f330037b06a07291/680x482cq70/steak-ayam-barbecue-saus-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f330037b06a07291/680x482cq70/steak-ayam-barbecue-saus-foto-resep-utama.jpg
author: Jay Reed
ratingvalue: 4.3
reviewcount: 14
recipeingredient:
- "4 pcs ayam fillet dadapaha"
- "2 sendok makan mentega"
- " Bahan Bumbu Marinasi"
- "1/2 buah air lemon"
- "1/2 sendok teh garam"
- "1/2 sendok teh merica bubuk"
- "2 siung bawang putih cincang"
- " Bahan Saus Barbecue"
- "1/2 buah bawang bombai cincang"
- "2 siung bawang putih cincang"
- "1/2 ibu jari jahe cincang"
- "1 sendok makan mentega"
- "2 sendok makan cuka"
- "1 sendok makan brown sugar gula merah"
- "1/2 sendok teh lada hitam"
- "1 sendok makan tomato paste"
- "2 sendok makan saus tomat"
- "250 ml air"
recipeinstructions:
- "Siapkan ayam fillet, bumbui dengan bahan bumbu marinasi dan diamkan 15 menit."
- "Kemudian siapkan bahan saus barbecue, panaskan 1 sendok makan mentega lalu tumis bawang bombai,bawang putih dan jahe cincang sampai harum. Kemudian masukan air, brown sugar/ gula merah, saus tomat, tomato paste, cuka dan lada hitam, aduk rata dan masak sampai mengental. Setelah mengental matikan api dan sisihkan."
- "Kemudian siapkan teplon beri 2 sendok makan mentega setelah panas panggang ayam yang sudah di marinasi tadi, panggang sampai berubah warna kedua sisih nya."
- "Setelah matang angkat dan taruh dalam wadah/ piring beri kentang panggang atau kentang sesuai selera dan salad sebagai pelengkapnya, kemudian panaskan kembali sausnya dan siramkan di atas ayam sesuai selera lalu sajikan."
categories:
- Resep
tags:
- steak
- ayam
- barbecue

katakunci: steak ayam barbecue 
nutrition: 179 calories
recipecuisine: Indonesian
preptime: "PT38M"
cooktime: "PT30M"
recipeyield: "1"
recipecategory: Dessert

---


![Steak Ayam Barbecue Saus](https://img-global.cpcdn.com/recipes/f330037b06a07291/680x482cq70/steak-ayam-barbecue-saus-foto-resep-utama.jpg)

Selaku seorang ibu, menyediakan panganan enak bagi keluarga tercinta merupakan suatu hal yang menyenangkan untuk kamu sendiri. Peran seorang istri bukan sekadar menangani rumah saja, namun anda juga harus menyediakan keperluan gizi terpenuhi dan panganan yang dikonsumsi keluarga tercinta mesti mantab.

Di masa  sekarang, kalian sebenarnya dapat memesan hidangan jadi walaupun tanpa harus ribet membuatnya dahulu. Tetapi ada juga lho orang yang memang mau menghidangkan yang terlezat untuk orang tercintanya. Sebab, menyajikan masakan yang dibuat sendiri jauh lebih higienis dan bisa menyesuaikan masakan tersebut sesuai dengan masakan kesukaan keluarga. 



Apakah anda salah satu penggemar steak ayam barbecue saus?. Asal kamu tahu, steak ayam barbecue saus adalah hidangan khas di Nusantara yang saat ini disukai oleh setiap orang dari berbagai tempat di Indonesia. Anda bisa menyajikan steak ayam barbecue saus sendiri di rumah dan boleh dijadikan hidangan favorit di hari liburmu.

Anda jangan bingung jika kamu ingin mendapatkan steak ayam barbecue saus, lantaran steak ayam barbecue saus gampang untuk ditemukan dan juga kita pun boleh membuatnya sendiri di tempatmu. steak ayam barbecue saus boleh dibuat lewat bermacam cara. Sekarang telah banyak resep modern yang membuat steak ayam barbecue saus lebih nikmat.

Resep steak ayam barbecue saus pun mudah dibikin, lho. Kalian tidak perlu ribet-ribet untuk membeli steak ayam barbecue saus, tetapi Anda bisa menyajikan di rumahmu. Untuk Anda yang mau menyajikannya, berikut resep untuk menyajikan steak ayam barbecue saus yang lezat yang bisa Kita coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Steak Ayam Barbecue Saus:

1. Sediakan 4 pcs ayam fillet (dada/paha)
1. Ambil 2 sendok makan mentega
1. Ambil  Bahan Bumbu Marinasi
1. Ambil 1/2 buah air lemon
1. Sediakan 1/2 sendok teh garam
1. Gunakan 1/2 sendok teh merica bubuk
1. Siapkan 2 siung bawang putih cincang
1. Ambil  Bahan Saus Barbecue
1. Siapkan 1/2 buah bawang bombai cincang
1. Sediakan 2 siung bawang putih cincang
1. Ambil 1/2 ibu jari jahe cincang
1. Sediakan 1 sendok makan mentega
1. Gunakan 2 sendok makan cuka
1. Gunakan 1 sendok makan brown sugar/ gula merah
1. Sediakan 1/2 sendok teh lada hitam
1. Gunakan 1 sendok makan tomato paste
1. Gunakan 2 sendok makan saus tomat
1. Gunakan 250 ml air




<!--inarticleads2-->

##### Langkah-langkah membuat Steak Ayam Barbecue Saus:

1. Siapkan ayam fillet, bumbui dengan bahan bumbu marinasi dan diamkan 15 menit.
1. Kemudian siapkan bahan saus barbecue, panaskan 1 sendok makan mentega lalu tumis bawang bombai,bawang putih dan jahe cincang sampai harum. Kemudian masukan air, brown sugar/ gula merah, saus tomat, tomato paste, cuka dan lada hitam, aduk rata dan masak sampai mengental. Setelah mengental matikan api dan sisihkan.
1. Kemudian siapkan teplon beri 2 sendok makan mentega setelah panas panggang ayam yang sudah di marinasi tadi, panggang sampai berubah warna kedua sisih nya.
1. Setelah matang angkat dan taruh dalam wadah/ piring beri kentang panggang atau kentang sesuai selera dan salad sebagai pelengkapnya, kemudian panaskan kembali sausnya dan siramkan di atas ayam sesuai selera lalu sajikan.




Ternyata cara buat steak ayam barbecue saus yang nikamt tidak rumit ini enteng banget ya! Kalian semua mampu memasaknya. Cara buat steak ayam barbecue saus Cocok banget untuk kita yang baru belajar memasak maupun juga untuk kamu yang sudah pandai memasak.

Tertarik untuk mulai mencoba membikin resep steak ayam barbecue saus mantab tidak ribet ini? Kalau anda mau, ayo kalian segera buruan siapkan alat-alat dan bahannya, lantas bikin deh Resep steak ayam barbecue saus yang nikmat dan tidak ribet ini. Betul-betul gampang kan. 

Maka, ketimbang kamu berfikir lama-lama, maka langsung aja buat resep steak ayam barbecue saus ini. Pasti kalian gak akan nyesel bikin resep steak ayam barbecue saus enak simple ini! Selamat mencoba dengan resep steak ayam barbecue saus mantab sederhana ini di tempat tinggal sendiri,ya!.

