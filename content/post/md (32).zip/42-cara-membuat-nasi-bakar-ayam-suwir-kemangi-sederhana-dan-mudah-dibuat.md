---
description: "Cara membuat Nasi bakar ayam suwir kemangi Sederhana dan Mudah Dibuat"
title: "Cara membuat Nasi bakar ayam suwir kemangi Sederhana dan Mudah Dibuat"
slug: 42-cara-membuat-nasi-bakar-ayam-suwir-kemangi-sederhana-dan-mudah-dibuat
date: 2021-05-09T09:33:43.378Z
image: https://img-global.cpcdn.com/recipes/2bc20212a4ce1dca/680x482cq70/nasi-bakar-ayam-suwir-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2bc20212a4ce1dca/680x482cq70/nasi-bakar-ayam-suwir-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2bc20212a4ce1dca/680x482cq70/nasi-bakar-ayam-suwir-kemangi-foto-resep-utama.jpg
author: Louisa Ross
ratingvalue: 3
reviewcount: 15
recipeingredient:
- "1/2 dada ayam fillet"
- "3 batang Kemangi"
- "7 siung bawang merah"
- "5 siung Bawang putih"
- "4 buah Cabe merah keriting"
- "sesuai selera Cabe rawit"
- "2 lembar Daun salam"
- " Garam"
- " Penyedap rasa ayam"
- " Lada bubuk"
- " Kecap manis"
- " Nasi Uduk"
- "3 cup Nasi putih"
- " Santan kental aku pake Kara 65ml campur air sesuai takaran masak nasi biasanya"
- " Daun salam"
- " Sereh"
- "Secukupnya Garam"
- " Bungkusan Nasi bakar"
- "7 helai Daun Pisang"
- "14 buah tusuk gigi"
recipeinstructions:
- "Cuci bersih beras seperti biasa klo masak nasi, masukkan santal kental lalu campurkan air sampai banyaknya seperti biasa klo moms masak nasi ya, masukkan sereh geprek, daun salam, &amp; garam biar gurih, aduk2 hingga merata lalu dimasak. Oia, Masak nasinya aku di ricecooker biar lebih simple."
- "Sambil tunggu nasinya masak kita siapkan dlu isian ayam suwirnya. Dididhkan air, Rebus ayam dan masukkan daun salam hingga masak. Tiriskan, setelah agak dingin ayamnya di suwir yaa moms"
- "Siapkan bumbu halus bawang merah, bawang putih, cabe merah keriting, cabe rawit, haluskan pake blender boleh, di uleg jg boleh.."
- "Tumis bumbu halus, tambahkan kecap manis, garam, penyedap rasa, lada bubuk. Boleh tambahkan air sedikit ya moms"
- "Kalo bumbunya udah wangi, dirasa udah matang masukkan ayam suwir tadi, aduk2 hingga minyaknya kluar, koreksi rasa. Terakhir masukkan daun kemangi ya moms."
- "Masukkan nasi ke dalam daun pisang, lalu masukkan isian ayamnya, boleh ditambahkan lg kemangi diatasnya klo suka ya.."
- "Lipat daun pisangnya (berbentuk panjang ya) sampe isinya tertutup smua, 2 sisi ujungnya masing2 kiri &amp; kanan kita rekatkan pake tusuk gigi."
- "Siapkan pembakaran atau teflon, bakar nasi sampai wangi daun pisangnya keluar ya..   siap disajikan🤤"
- "Siapkan daun pisang.  Kalo Nasinya udah matang sisihkan dulu diwadah lain sampai agak dingin spya klo dibungkus ga terlalu panas. Tips: Daun pisangnya aku pake 2 lapis ya moms biar aman nasinya ga beleber pas dibakar."
categories:
- Resep
tags:
- nasi
- bakar
- ayam

katakunci: nasi bakar ayam 
nutrition: 111 calories
recipecuisine: Indonesian
preptime: "PT29M"
cooktime: "PT42M"
recipeyield: "4"
recipecategory: Lunch

---


![Nasi bakar ayam suwir kemangi](https://img-global.cpcdn.com/recipes/2bc20212a4ce1dca/680x482cq70/nasi-bakar-ayam-suwir-kemangi-foto-resep-utama.jpg)

Selaku seorang orang tua, menyuguhkan masakan nikmat pada keluarga merupakan suatu hal yang sangat menyenangkan bagi kamu sendiri. Tanggung jawab seorang istri Tidak sekedar mengerjakan pekerjaan rumah saja, tapi kamu pun wajib memastikan keperluan gizi terpenuhi dan santapan yang disantap keluarga tercinta wajib lezat.

Di era  sekarang, anda memang dapat mengorder masakan praktis meski tidak harus capek memasaknya lebih dulu. Tapi banyak juga mereka yang memang ingin menyajikan yang terlezat bagi keluarganya. Karena, memasak sendiri jauh lebih higienis dan kita juga bisa menyesuaikan hidangan tersebut sesuai selera keluarga. 



Mungkinkah anda salah satu penyuka nasi bakar ayam suwir kemangi?. Tahukah kamu, nasi bakar ayam suwir kemangi merupakan sajian khas di Indonesia yang kini disukai oleh banyak orang di berbagai wilayah di Indonesia. Anda bisa menghidangkan nasi bakar ayam suwir kemangi buatan sendiri di rumah dan pasti jadi camilan favorit di hari libur.

Kita tidak perlu bingung jika kamu ingin memakan nasi bakar ayam suwir kemangi, karena nasi bakar ayam suwir kemangi gampang untuk ditemukan dan juga anda pun boleh mengolahnya sendiri di tempatmu. nasi bakar ayam suwir kemangi dapat dimasak memalui bermacam cara. Kini telah banyak banget resep modern yang menjadikan nasi bakar ayam suwir kemangi semakin mantap.

Resep nasi bakar ayam suwir kemangi pun sangat gampang dibuat, lho. Anda tidak usah repot-repot untuk memesan nasi bakar ayam suwir kemangi, sebab Kita dapat membuatnya sendiri di rumah. Untuk Anda yang ingin membuatnya, berikut ini cara menyajikan nasi bakar ayam suwir kemangi yang lezat yang mampu Kalian coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Nasi bakar ayam suwir kemangi:

1. Gunakan 1/2 dada ayam fillet
1. Siapkan 3 batang Kemangi
1. Siapkan 7 siung bawang merah
1. Siapkan 5 siung Bawang putih
1. Sediakan 4 buah Cabe merah keriting
1. Ambil sesuai selera Cabe rawit
1. Siapkan 2 lembar Daun salam
1. Ambil  Garam
1. Gunakan  Penyedap rasa ayam
1. Ambil  Lada bubuk
1. Ambil  Kecap manis
1. Ambil  Nasi Uduk
1. Gunakan 3 cup Nasi putih
1. Ambil  Santan kental (aku pake Kara 65ml) campur air sesuai takaran masak nasi biasanya
1. Gunakan  Daun salam
1. Ambil  Sereh
1. Siapkan Secukupnya Garam
1. Gunakan  Bungkusan Nasi bakar
1. Ambil 7 helai Daun Pisang
1. Siapkan 14 buah tusuk gigi




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Nasi bakar ayam suwir kemangi:

1. Cuci bersih beras seperti biasa klo masak nasi, masukkan santal kental lalu campurkan air sampai banyaknya seperti biasa klo moms masak nasi ya, masukkan sereh geprek, daun salam, &amp; garam biar gurih, aduk2 hingga merata lalu dimasak. Oia, Masak nasinya aku di ricecooker biar lebih simple.
1. Sambil tunggu nasinya masak kita siapkan dlu isian ayam suwirnya. - Dididhkan air, Rebus ayam dan masukkan daun salam hingga masak. Tiriskan, setelah agak dingin ayamnya di suwir yaa moms
1. Siapkan bumbu halus bawang merah, bawang putih, cabe merah keriting, cabe rawit, haluskan pake blender boleh, di uleg jg boleh..
1. Tumis bumbu halus, tambahkan kecap manis, garam, penyedap rasa, lada bubuk. Boleh tambahkan air sedikit ya moms
1. Kalo bumbunya udah wangi, dirasa udah matang masukkan ayam suwir tadi, aduk2 hingga minyaknya kluar, koreksi rasa. Terakhir masukkan daun kemangi ya moms.
1. Masukkan nasi ke dalam daun pisang, lalu masukkan isian ayamnya, boleh ditambahkan lg kemangi diatasnya klo suka ya..
1. Lipat daun pisangnya (berbentuk panjang ya) sampe isinya tertutup smua, 2 sisi ujungnya masing2 kiri &amp; kanan kita rekatkan pake tusuk gigi.
1. Siapkan pembakaran atau teflon, bakar nasi sampai wangi daun pisangnya keluar ya..  -  - siap disajikan🤤
1. Siapkan daun pisang.  - Kalo Nasinya udah matang sisihkan dulu diwadah lain sampai agak dingin spya klo dibungkus ga terlalu panas. - Tips: Daun pisangnya aku pake 2 lapis ya moms biar aman nasinya ga beleber pas dibakar.




Wah ternyata cara membuat nasi bakar ayam suwir kemangi yang enak simple ini enteng banget ya! Anda Semua mampu menghidangkannya. Cara buat nasi bakar ayam suwir kemangi Sesuai sekali untuk kalian yang baru akan belajar memasak maupun bagi kamu yang telah lihai dalam memasak.

Apakah kamu tertarik mencoba membikin resep nasi bakar ayam suwir kemangi enak tidak ribet ini? Kalau ingin, ayo kamu segera siapin peralatan dan bahannya, setelah itu bikin deh Resep nasi bakar ayam suwir kemangi yang enak dan tidak rumit ini. Betul-betul taidak sulit kan. 

Maka, daripada kita berlama-lama, yuk langsung aja buat resep nasi bakar ayam suwir kemangi ini. Pasti kalian tak akan menyesal membuat resep nasi bakar ayam suwir kemangi lezat tidak rumit ini! Selamat mencoba dengan resep nasi bakar ayam suwir kemangi nikmat tidak ribet ini di tempat tinggal sendiri,oke!.

