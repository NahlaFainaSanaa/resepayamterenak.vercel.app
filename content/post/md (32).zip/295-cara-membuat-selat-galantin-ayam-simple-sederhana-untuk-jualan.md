---
description: "Cara membuat Selat Galantin Ayam (Simple) Sederhana Untuk Jualan"
title: "Cara membuat Selat Galantin Ayam (Simple) Sederhana Untuk Jualan"
slug: 295-cara-membuat-selat-galantin-ayam-simple-sederhana-untuk-jualan
date: 2021-04-17T13:37:35.102Z
image: https://img-global.cpcdn.com/recipes/0b40cc0dd74d4aa1/680x482cq70/selat-galantin-ayam-simple-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0b40cc0dd74d4aa1/680x482cq70/selat-galantin-ayam-simple-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0b40cc0dd74d4aa1/680x482cq70/selat-galantin-ayam-simple-foto-resep-utama.jpg
author: Georgie Nguyen
ratingvalue: 4
reviewcount: 7
recipeingredient:
- "  Bumbu  Bahan Galantin"
- "1 kg daging ayam"
- "250 gr tepung panir"
- "8 siung bawang putih haluskan"
- "3 butir telur"
- "4 sdt garam"
- "1 sdt kaldu bubuk rasa ayam"
- "1 sdm gula pasir"
- "1/4 butir pala haluskan"
- "1 sdm merica bubuk"
- " Bahan Pelengkap"
- "5 butir telur kecap direbus"
- "2 buah wortel potong memanjang direbus"
- "100 gr buncis potong direbus"
- "5 buah kentang potong memanjang direbus"
- "3 buah tomat merah potong potong"
- "1 buah mentimun ukuran sedang potong memanjang"
- "1 ikat daun selada saya skip"
- " kripik kentang secukupnya saya skip"
- "3 siung bawang merah irisiris boleh di skip"
- "2 sdm mayonaise secukupnya  saya beli jadi"
- " Bumbu Halus untuk Kuah"
- "5 siung bawang putih"
- "4 siung bawang merah"
- "1 sdt merica"
- "1/4 sdt pala bubuk"
- " Kuah"
- "800 ml air"
- "100 ml air kaldu rebusan daging ayam"
- "100 gr daging  gajih ayam"
- "2 butir gula merah"
- "3 sdm kecap manis"
- "1/2 butir pala geprek"
- "1 buah bawang bombay iris"
- "2 sdt garam"
- "2 sdt gula"
- "1 sdt kaldu bubuk"
recipeinstructions:
- "📌MEMBUAT GALANTIN AYAM : Haluskan daging ayam, bersama bumbu2. Setelah halus masukkan tepung panir dan telur. Aduk sampai rata. Setelah itu ambil adonan dan gulung dengan daun pisang. Kukus selama kurleb 30 menit. Test tusuk. Setelah matang angkat, sisihkan dan Potong2 sesuai selera."
- "Rebus telur hingga matang. Setelah itu biarkan dingin lalu kupas kulit telur, sisihkan."
- "Di tungku kompor yang berbeda, rebus wortel, buncis dan kentang hingga empuk. Angkat, tiriskan. Potong-potong mentimun."
- "📌MEMBUAT KUAH : Didihkan air, masukkan gajih dan daging ayam. Masak sampai empuk dan menjadi kaldu. Angat, Sisihkan  Panaskan butter, Tumis bumbu halus dengan bawang bombay sampai harum. Tambahkan air &amp; sedikit air kaldu. masak hingga mendidih. Beri pala, merica, gula merah, garam, gula pasir, kaldu bubuk dan kecap manis. Masak sampai mendidih, koreksi rasa. Matikan api."
- "📌PENYAJIAN : Tata dalam piring galantin, buncis, wortel, mentimun, bawang merah dan telur kecap, beri irisan tomat. Tambahkan bawang goreng dan mayonaise (jika ada). Enjoy it ❤️"
categories:
- Resep
tags:
- selat
- galantin
- ayam

katakunci: selat galantin ayam 
nutrition: 175 calories
recipecuisine: Indonesian
preptime: "PT17M"
cooktime: "PT33M"
recipeyield: "2"
recipecategory: Lunch

---


![Selat Galantin Ayam (Simple)](https://img-global.cpcdn.com/recipes/0b40cc0dd74d4aa1/680x482cq70/selat-galantin-ayam-simple-foto-resep-utama.jpg)

Sebagai seorang wanita, menyajikan masakan nikmat pada famili adalah hal yang mengasyikan untuk kita sendiri. Tanggung jawab seorang istri bukan cuman menangani rumah saja, tapi anda juga wajib memastikan keperluan gizi terpenuhi dan juga masakan yang disantap keluarga tercinta wajib nikmat.

Di zaman  saat ini, kamu memang dapat membeli masakan yang sudah jadi walaupun tanpa harus ribet membuatnya dulu. Tapi banyak juga lho mereka yang selalu ingin memberikan hidangan yang terlezat untuk keluarganya. Pasalnya, menghidangkan masakan yang diolah sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan masakan tersebut sesuai dengan makanan kesukaan famili. 



Mungkinkah kamu salah satu penyuka selat galantin ayam (simple)?. Asal kamu tahu, selat galantin ayam (simple) merupakan makanan khas di Nusantara yang sekarang disenangi oleh orang-orang di berbagai tempat di Indonesia. Kamu dapat menyajikan selat galantin ayam (simple) sendiri di rumah dan pasti jadi santapan favorit di hari libur.

Anda tak perlu bingung jika kamu ingin menyantap selat galantin ayam (simple), lantaran selat galantin ayam (simple) tidak sulit untuk ditemukan dan juga kita pun dapat menghidangkannya sendiri di rumah. selat galantin ayam (simple) boleh diolah lewat beragam cara. Sekarang telah banyak resep modern yang menjadikan selat galantin ayam (simple) semakin nikmat.

Resep selat galantin ayam (simple) pun mudah sekali dibikin, lho. Kalian jangan capek-capek untuk memesan selat galantin ayam (simple), sebab Kita dapat menyajikan sendiri di rumah. Bagi Anda yang akan membuatnya, berikut ini cara untuk membuat selat galantin ayam (simple) yang mantab yang dapat Kalian coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Selat Galantin Ayam (Simple):

1. Siapkan  📌 Bumbu &amp; Bahan Galantin
1. Ambil 1 kg daging ayam
1. Gunakan 250 gr tepung panir
1. Ambil 8 siung bawang putih, haluskan
1. Gunakan 3 butir telur
1. Gunakan 4 sdt garam
1. Gunakan 1 sdt kaldu bubuk rasa ayam
1. Siapkan 1 sdm gula pasir
1. Sediakan 1/4 butir pala haluskan
1. Gunakan 1 sdm merica bubuk
1. Siapkan  📌Bahan Pelengkap
1. Ambil 5 butir telur kecap, direbus
1. Siapkan 2 buah wortel potong memanjang, direbus
1. Ambil 100 gr buncis potong², direbus
1. Sediakan 5 buah kentang potong memanjang, direbus
1. Ambil 3 buah tomat merah, potong potong
1. Ambil 1 buah mentimun ukuran sedang, potong memanjang
1. Ambil 1 ikat daun selada, (saya skip)
1. Siapkan  kripik kentang secukupnya (saya skip)
1. Ambil 3 siung bawang merah, iris-iris (boleh di skip)
1. Siapkan 2 sdm mayonaise (secukupnya &amp; saya beli jadi)
1. Siapkan  📌Bumbu Halus untuk Kuah
1. Gunakan 5 siung bawang putih
1. Gunakan 4 siung bawang merah
1. Ambil 1 sdt merica
1. Ambil 1/4 sdt pala bubuk
1. Gunakan  📌Kuah
1. Siapkan 800 ml air
1. Ambil 100 ml air kaldu (rebusan daging ayam)
1. Ambil 100 gr daging &amp; gajih ayam
1. Siapkan 2 butir gula merah
1. Siapkan 3 sdm kecap manis
1. Siapkan 1/2 butir pala geprek
1. Sediakan 1 buah bawang bombay, iris
1. Ambil 2 sdt garam
1. Siapkan 2 sdt gula
1. Sediakan 1 sdt kaldu bubuk




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Selat Galantin Ayam (Simple):

1. 📌MEMBUAT GALANTIN AYAM : - Haluskan daging ayam, bersama bumbu2. Setelah halus masukkan tepung panir dan telur. Aduk sampai rata. - Setelah itu ambil adonan dan gulung dengan daun pisang. Kukus selama kurleb 30 menit. Test tusuk. Setelah matang angkat, sisihkan dan Potong2 sesuai selera.
1. Rebus telur hingga matang. Setelah itu biarkan dingin lalu kupas kulit telur, sisihkan.
1. Di tungku kompor yang berbeda, rebus wortel, buncis dan kentang hingga empuk. Angkat, tiriskan. Potong-potong mentimun.
1. 📌MEMBUAT KUAH : Didihkan air, masukkan gajih dan daging ayam. Masak sampai empuk dan menjadi kaldu. Angat, Sisihkan -  - Panaskan butter, Tumis bumbu halus dengan bawang bombay sampai harum. Tambahkan air &amp; sedikit air kaldu. masak hingga mendidih. Beri pala, merica, gula merah, garam, gula pasir, kaldu bubuk dan kecap manis. Masak sampai mendidih, koreksi rasa. Matikan api.
1. 📌PENYAJIAN : - Tata dalam piring galantin, buncis, wortel, mentimun, bawang merah dan telur kecap, beri irisan tomat. Tambahkan bawang goreng dan mayonaise (jika ada). Enjoy it ❤️




Wah ternyata resep selat galantin ayam (simple) yang lezat sederhana ini enteng banget ya! Kalian semua mampu memasaknya. Cara Membuat selat galantin ayam (simple) Cocok banget buat kalian yang baru belajar memasak maupun untuk kalian yang telah ahli memasak.

Tertarik untuk mulai mencoba buat resep selat galantin ayam (simple) enak simple ini? Kalau anda tertarik, ayo kalian segera siapkan peralatan dan bahannya, maka buat deh Resep selat galantin ayam (simple) yang lezat dan tidak rumit ini. Sangat taidak sulit kan. 

Oleh karena itu, daripada kamu berlama-lama, ayo langsung aja buat resep selat galantin ayam (simple) ini. Dijamin kamu gak akan menyesal membuat resep selat galantin ayam (simple) lezat simple ini! Selamat berkreasi dengan resep selat galantin ayam (simple) mantab tidak rumit ini di tempat tinggal sendiri,oke!.

