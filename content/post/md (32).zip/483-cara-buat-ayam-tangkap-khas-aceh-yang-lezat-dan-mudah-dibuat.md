---
description: "Cara buat Ayam Tangkap khas Aceh yang lezat dan Mudah Dibuat"
title: "Cara buat Ayam Tangkap khas Aceh yang lezat dan Mudah Dibuat"
slug: 483-cara-buat-ayam-tangkap-khas-aceh-yang-lezat-dan-mudah-dibuat
date: 2021-01-18T12:38:57.880Z
image: https://img-global.cpcdn.com/recipes/6b59b9e59d125d9a/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6b59b9e59d125d9a/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6b59b9e59d125d9a/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg
author: Jackson Green
ratingvalue: 3.8
reviewcount: 12
recipeingredient:
- "1 ekor ayam kampung potong 8"
- "1 liter air kelapa"
- "1 buah jeruk nipis"
- "1 sdt garam"
- "  bumbu halus"
- "6 siung bawang merah"
- "5 siung bawang putih"
- "1 cm jahe"
- "1 cm kunyit"
- "1/4 sdt lada"
- "1/2 sdt ketumbar halus"
- "1 sdt garam"
- "1/2 sdt kaldu jamur"
- "1/4 sdt gula"
- "iris  bumbu"
- "5 buah cabe ijo"
- "5 buah cabe rawit"
- "3 siung bawang merah"
- "10 lembar daun kari"
- "2 lembar daun pandan"
recipeinstructions:
- "Cuci bersih ayam, lalu beri air perasan jeruk n garam, diamkan selama 15 menit, lalu bilas bersih n tiriskan. Haluskan semua bumbu halus."
- "Didihkan air kelapa, masukkan bumbu, masak sampai mendidih, lalu masukkan ayam, beri garam, kaldu jamur n garam. Masak ayam sampai air menyusut n ayam lembut. Sisihkan."
- "Iriis2 semua bumbu iris. Panaskan minyak dalam wajan, lalu goreng ayam sampai setengah kuning lalu masukkan sebagian bumbu iris."
- "Setelah bumbu matang, angkat ayam n semua bumbu. Ayam tangkap siap di sajikan. Selamat mencoba n semoga suka ya"
categories:
- Resep
tags:
- ayam
- tangkap
- khas

katakunci: ayam tangkap khas 
nutrition: 219 calories
recipecuisine: Indonesian
preptime: "PT12M"
cooktime: "PT53M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam Tangkap khas Aceh](https://img-global.cpcdn.com/recipes/6b59b9e59d125d9a/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg)

Sebagai seorang istri, menyediakan hidangan sedap kepada keluarga adalah suatu hal yang sangat menyenangkan bagi kita sendiri. Kewajiban seorang istri bukan cuman mengerjakan pekerjaan rumah saja, tapi anda pun harus memastikan keperluan gizi terpenuhi dan hidangan yang dikonsumsi keluarga tercinta wajib mantab.

Di masa  saat ini, kita sebenarnya mampu memesan panganan instan meski tanpa harus capek memasaknya dulu. Tetapi ada juga lho orang yang memang mau menyajikan yang terlezat bagi orang tercintanya. Karena, menghidangkan masakan yang diolah sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan sesuai dengan selera famili. 



Apakah anda adalah salah satu penggemar ayam tangkap khas aceh?. Asal kamu tahu, ayam tangkap khas aceh merupakan makanan khas di Nusantara yang sekarang disenangi oleh kebanyakan orang dari hampir setiap tempat di Indonesia. Kalian bisa menghidangkan ayam tangkap khas aceh hasil sendiri di rumah dan boleh jadi hidangan kesukaanmu di akhir pekan.

Kamu tidak perlu bingung untuk mendapatkan ayam tangkap khas aceh, lantaran ayam tangkap khas aceh gampang untuk ditemukan dan anda pun boleh menghidangkannya sendiri di rumah. ayam tangkap khas aceh boleh diolah dengan beraneka cara. Saat ini ada banyak resep kekinian yang menjadikan ayam tangkap khas aceh semakin nikmat.

Resep ayam tangkap khas aceh juga mudah sekali dibuat, lho. Anda tidak perlu ribet-ribet untuk memesan ayam tangkap khas aceh, sebab Anda dapat menghidangkan sendiri di rumah. Untuk Kalian yang ingin menyajikannya, di bawah ini adalah cara untuk membuat ayam tangkap khas aceh yang mantab yang bisa Kita coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Ayam Tangkap khas Aceh:

1. Ambil 1 ekor ayam kampung, potong 8
1. Ambil 1 liter air kelapa
1. Gunakan 1 buah jeruk nipis
1. Ambil 1 sdt garam
1. Siapkan  ❤ bumbu halus
1. Gunakan 6 siung bawang merah
1. Sediakan 5 siung bawang putih
1. Sediakan 1 cm jahe
1. Ambil 1 cm kunyit
1. Ambil 1/4 sdt lada
1. Sediakan 1/2 sdt ketumbar halus
1. Ambil 1 sdt garam
1. Siapkan 1/2 sdt kaldu jamur
1. Siapkan 1/4 sdt gula
1. Gunakan iris ❤ bumbu
1. Ambil 5 buah cabe ijo
1. Gunakan 5 buah cabe rawit
1. Siapkan 3 siung bawang merah
1. Sediakan 10 lembar daun kari
1. Ambil 2 lembar daun pandan




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam Tangkap khas Aceh:

1. Cuci bersih ayam, lalu beri air perasan jeruk n garam, diamkan selama 15 menit, lalu bilas bersih n tiriskan. Haluskan semua bumbu halus.
1. Didihkan air kelapa, masukkan bumbu, masak sampai mendidih, lalu masukkan ayam, beri garam, kaldu jamur n garam. Masak ayam sampai air menyusut n ayam lembut. Sisihkan.
1. Iriis2 semua bumbu iris. Panaskan minyak dalam wajan, lalu goreng ayam sampai setengah kuning lalu masukkan sebagian bumbu iris.
1. Setelah bumbu matang, angkat ayam n semua bumbu. Ayam tangkap siap di sajikan. Selamat mencoba n semoga suka ya




Wah ternyata resep ayam tangkap khas aceh yang enak tidak rumit ini enteng sekali ya! Kita semua dapat membuatnya. Cara buat ayam tangkap khas aceh Sangat sesuai sekali untuk kamu yang baru akan belajar memasak maupun bagi anda yang sudah lihai dalam memasak.

Tertarik untuk mencoba bikin resep ayam tangkap khas aceh lezat tidak rumit ini? Kalau ingin, yuk kita segera buruan siapin peralatan dan bahan-bahannya, lantas bikin deh Resep ayam tangkap khas aceh yang enak dan sederhana ini. Betul-betul mudah kan. 

Oleh karena itu, ketimbang anda berfikir lama-lama, yuk kita langsung saja hidangkan resep ayam tangkap khas aceh ini. Pasti kalian tiidak akan menyesal sudah membuat resep ayam tangkap khas aceh lezat tidak ribet ini! Selamat berkreasi dengan resep ayam tangkap khas aceh enak simple ini di rumah sendiri,oke!.

