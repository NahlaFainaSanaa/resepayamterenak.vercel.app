---
description: "Cara buat Ayam Woku Khas Manado yang enak dan Mudah Dibuat"
title: "Cara buat Ayam Woku Khas Manado yang enak dan Mudah Dibuat"
slug: 336-cara-buat-ayam-woku-khas-manado-yang-enak-dan-mudah-dibuat
date: 2021-01-10T04:28:32.351Z
image: https://img-global.cpcdn.com/recipes/e29f291d961a88cd/680x482cq70/ayam-woku-khas-manado-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e29f291d961a88cd/680x482cq70/ayam-woku-khas-manado-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e29f291d961a88cd/680x482cq70/ayam-woku-khas-manado-foto-resep-utama.jpg
author: Jesus Sandoval
ratingvalue: 4.7
reviewcount: 9
recipeingredient:
- "1 kg ayam potong2"
- "3 buah Sereh"
- "2 buah Tomat"
- "1 buah jeruk nipis"
- "5-7 lembar daun jeruk"
- "3 lembar daun pandan"
- "2 daun bawangbawang pre"
- "secukupnya Kemangi"
- " Bumbu halus"
- " Bawang merah"
- " Bawang putih"
- "2 biji Kemiri"
- "3 Sereh dipotong2"
- "3 Cabe merah besar"
- " Cabe rawit"
- " Kunyit"
- " Jahe"
recipeinstructions:
- "Tumis bumbu halus"
- "Masukkan tomat yang sudah dipotong2"
- "Masukkan ayam"
- "Tambahkan air, biarkan hingga mendidih"
- "Masukkan daun jeruk dan sere"
- "Masukkan daun pandan"
- "Masukkan jeruk nipis"
- "Masukkan daun bawang yg sudah dipotong2"
- "Bumbui dengan garam gula dan lada, koreksi rasa"
- "Masukkan kemangi"
- "Bisa disajikan"
categories:
- Resep
tags:
- ayam
- woku
- khas

katakunci: ayam woku khas 
nutrition: 101 calories
recipecuisine: Indonesian
preptime: "PT14M"
cooktime: "PT40M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Woku Khas Manado](https://img-global.cpcdn.com/recipes/e29f291d961a88cd/680x482cq70/ayam-woku-khas-manado-foto-resep-utama.jpg)

Apabila kita seorang istri, menyajikan masakan nikmat untuk famili adalah hal yang sangat menyenangkan bagi kita sendiri. Kewajiban seorang  wanita Tidak cuma mengatur rumah saja, tapi kamu pun wajib memastikan keperluan gizi terpenuhi dan juga panganan yang dikonsumsi anak-anak mesti mantab.

Di waktu  sekarang, anda sebenarnya dapat membeli panganan jadi meski tidak harus susah memasaknya lebih dulu. Tetapi ada juga lho mereka yang memang ingin memberikan yang terenak bagi keluarganya. Pasalnya, memasak sendiri akan jauh lebih higienis dan bisa menyesuaikan sesuai dengan selera keluarga. 



Apakah anda merupakan salah satu penyuka ayam woku khas manado?. Tahukah kamu, ayam woku khas manado merupakan hidangan khas di Indonesia yang saat ini disukai oleh setiap orang dari hampir setiap tempat di Indonesia. Kamu dapat memasak ayam woku khas manado sendiri di rumahmu dan pasti jadi hidangan favoritmu di hari libur.

Kita tidak usah bingung jika kamu ingin mendapatkan ayam woku khas manado, lantaran ayam woku khas manado gampang untuk dicari dan juga kalian pun dapat membuatnya sendiri di tempatmu. ayam woku khas manado boleh dibuat lewat berbagai cara. Sekarang sudah banyak sekali resep modern yang membuat ayam woku khas manado semakin nikmat.

Resep ayam woku khas manado juga mudah sekali dibuat, lho. Anda tidak usah ribet-ribet untuk membeli ayam woku khas manado, lantaran Kalian mampu menyiapkan sendiri di rumah. Untuk Kalian yang mau membuatnya, di bawah ini adalah resep untuk membuat ayam woku khas manado yang lezat yang bisa Kita buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Ayam Woku Khas Manado:

1. Ambil 1 kg ayam potong2
1. Siapkan 3 buah Sereh
1. Siapkan 2 buah Tomat
1. Sediakan 1 buah jeruk nipis
1. Siapkan 5-7 lembar daun jeruk
1. Sediakan 3 lembar daun pandan
1. Gunakan 2 daun bawang/bawang pre
1. Sediakan secukupnya Kemangi
1. Gunakan  Bumbu halus
1. Sediakan  Bawang merah
1. Gunakan  Bawang putih
1. Ambil 2 biji Kemiri
1. Gunakan 3 Sereh dipotong2
1. Sediakan 3 Cabe merah besar
1. Sediakan  Cabe rawit
1. Sediakan  Kunyit
1. Gunakan  Jahe




<!--inarticleads2-->

##### Cara membuat Ayam Woku Khas Manado:

1. Tumis bumbu halus
1. Masukkan tomat yang sudah dipotong2
1. Masukkan ayam
1. Tambahkan air, biarkan hingga mendidih
1. Masukkan daun jeruk dan sere
1. Masukkan daun pandan
1. Masukkan jeruk nipis
1. Masukkan daun bawang yg sudah dipotong2
1. Bumbui dengan garam gula dan lada, koreksi rasa
1. Masukkan kemangi
1. Bisa disajikan




Ternyata cara buat ayam woku khas manado yang nikamt tidak ribet ini mudah banget ya! Semua orang bisa menghidangkannya. Cara buat ayam woku khas manado Sesuai banget untuk kamu yang baru mau belajar memasak ataupun juga untuk anda yang sudah lihai dalam memasak.

Tertarik untuk mulai mencoba buat resep ayam woku khas manado enak sederhana ini? Kalau kamu ingin, yuk kita segera buruan siapkan alat-alat dan bahannya, lalu buat deh Resep ayam woku khas manado yang lezat dan simple ini. Benar-benar mudah kan. 

Maka dari itu, ketimbang kamu berlama-lama, maka langsung aja sajikan resep ayam woku khas manado ini. Dijamin anda gak akan menyesal sudah bikin resep ayam woku khas manado nikmat simple ini! Selamat berkreasi dengan resep ayam woku khas manado nikmat tidak ribet ini di tempat tinggal kalian sendiri,oke!.

