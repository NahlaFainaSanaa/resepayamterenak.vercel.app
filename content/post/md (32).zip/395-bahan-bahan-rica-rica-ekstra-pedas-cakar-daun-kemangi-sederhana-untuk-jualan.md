---
description: "Bahan-bahan Rica-rica ekstra pedas Cakar daun kemangi Sederhana Untuk Jualan"
title: "Bahan-bahan Rica-rica ekstra pedas Cakar daun kemangi Sederhana Untuk Jualan"
slug: 395-bahan-bahan-rica-rica-ekstra-pedas-cakar-daun-kemangi-sederhana-untuk-jualan
date: 2021-04-02T09:59:03.974Z
image: https://img-global.cpcdn.com/recipes/03b687bf74145682/680x482cq70/rica-rica-ekstra-pedas-cakar-daun-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/03b687bf74145682/680x482cq70/rica-rica-ekstra-pedas-cakar-daun-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/03b687bf74145682/680x482cq70/rica-rica-ekstra-pedas-cakar-daun-kemangi-foto-resep-utama.jpg
author: Mollie Mann
ratingvalue: 3.7
reviewcount: 9
recipeingredient:
- "500 gr cakar yang sudah di bersihkan"
- "10 Cabai rawit setan utuh potek jadi 2"
- "10 batang daun kemangi ambil daunnya"
- "1 sdm kecap manis"
- "1 sdt gula pasir"
- "1 1/2 sdt garam sesuai selera"
- "1 sdt penyedap masakan"
- "1/4 potong gula jawa"
- "2 lembar daun salam"
- "1 ruas lengkuas geprek"
- "1 sereh geprek"
- "4 sdm minyak goreng"
- "2 gelas belimbing air"
- " Bahan yg di haluskan "
- "10 siung bawang putih pilih yang besar"
- "2 siung bawang merah"
- "1 ruas kunyit"
- "1 sdt lada bubuk"
- "1 sdt ketumbar"
- "1 ruas jahe"
- "3 lembar daun jeruk"
- "3 butir kemiri"
- "20 cabe rawit setan"
recipeinstructions:
- "Panaskan wajan dengan minyak goreng, tumis bumbu halus hingga wangi, masukkan daun salam, sereh, lengkuas, cabe rawit utuh, gula, garam, gula jawa, penyedap. Tumis hingga wangi &amp; tercampur, berikan sedikit air supaya bumbu lebih matang."
- "Masukkan cakar ayam, kecap manis, dan air sampai cakar tertutup air semua, aduk sebentar agar bumbu tercampur, tutup wajan ± 10 menit, kemudian aduk2 terus, tutup wajan lagi ±7 menit agar cakar matang benar dengan api sedang besar, aduk2 kembali cakar dan masukkan daun kemangi, aduk2 terus terus sampai kuah mengental dan surut (sesuai keinginan) test rasa, sajikan."
categories:
- Resep
tags:
- ricarica
- ekstra
- pedas

katakunci: ricarica ekstra pedas 
nutrition: 160 calories
recipecuisine: Indonesian
preptime: "PT21M"
cooktime: "PT45M"
recipeyield: "4"
recipecategory: Lunch

---


![Rica-rica ekstra pedas Cakar daun kemangi](https://img-global.cpcdn.com/recipes/03b687bf74145682/680x482cq70/rica-rica-ekstra-pedas-cakar-daun-kemangi-foto-resep-utama.jpg)

Sebagai seorang istri, mempersiapkan santapan nikmat untuk famili merupakan suatu hal yang memuaskan bagi kamu sendiri. Tugas seorang ibu bukan hanya menangani rumah saja, tapi kamu pun wajib memastikan keperluan gizi tercukupi dan juga panganan yang dikonsumsi orang tercinta harus menggugah selera.

Di waktu  sekarang, kalian memang mampu membeli santapan instan walaupun tanpa harus susah memasaknya dahulu. Tetapi ada juga lho mereka yang memang ingin menghidangkan yang terlezat bagi keluarganya. Karena, memasak yang diolah sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan sesuai dengan masakan kesukaan famili. 



Apakah anda adalah salah satu penggemar rica-rica ekstra pedas cakar daun kemangi?. Asal kamu tahu, rica-rica ekstra pedas cakar daun kemangi adalah hidangan khas di Nusantara yang kini digemari oleh banyak orang di berbagai wilayah di Indonesia. Kamu bisa memasak rica-rica ekstra pedas cakar daun kemangi kreasi sendiri di rumahmu dan pasti jadi santapan kesukaanmu di akhir pekanmu.

Kamu tak perlu bingung untuk mendapatkan rica-rica ekstra pedas cakar daun kemangi, lantaran rica-rica ekstra pedas cakar daun kemangi tidak sulit untuk ditemukan dan anda pun bisa mengolahnya sendiri di tempatmu. rica-rica ekstra pedas cakar daun kemangi dapat dimasak lewat beraneka cara. Saat ini ada banyak resep modern yang membuat rica-rica ekstra pedas cakar daun kemangi lebih mantap.

Resep rica-rica ekstra pedas cakar daun kemangi juga gampang dibuat, lho. Kamu jangan repot-repot untuk memesan rica-rica ekstra pedas cakar daun kemangi, lantaran Kita dapat menyiapkan ditempatmu. Untuk Kita yang akan mencobanya, di bawah ini adalah resep untuk menyajikan rica-rica ekstra pedas cakar daun kemangi yang mantab yang mampu Kamu buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Rica-rica ekstra pedas Cakar daun kemangi:

1. Gunakan 500 gr cakar yang sudah di bersihkan
1. Gunakan 10 Cabai rawit setan utuh, potek jadi 2
1. Siapkan 10 batang daun kemangi, ambil daunnya
1. Sediakan 1 sdm kecap manis
1. Sediakan 1 sdt gula pasir
1. Sediakan 1 1/2 sdt garam (sesuai selera)
1. Gunakan 1 sdt penyedap masakan
1. Gunakan 1/4 potong gula jawa
1. Sediakan 2 lembar daun salam
1. Ambil 1 ruas lengkuas geprek
1. Siapkan 1 sereh geprek
1. Gunakan 4 sdm minyak goreng
1. Siapkan 2 gelas belimbing air
1. Siapkan  Bahan yg di haluskan :
1. Ambil 10 siung bawang putih, pilih yang besar
1. Gunakan 2 siung bawang merah
1. Siapkan 1 ruas kunyit
1. Sediakan 1 sdt lada bubuk
1. Ambil 1 sdt ketumbar
1. Gunakan 1 ruas jahe
1. Sediakan 3 lembar daun jeruk
1. Siapkan 3 butir kemiri
1. Siapkan 20 cabe rawit setan




<!--inarticleads2-->

##### Langkah-langkah membuat Rica-rica ekstra pedas Cakar daun kemangi:

1. Panaskan wajan dengan minyak goreng, tumis bumbu halus hingga wangi, masukkan daun salam, sereh, lengkuas, cabe rawit utuh, gula, garam, gula jawa, penyedap. Tumis hingga wangi &amp; tercampur, berikan sedikit air supaya bumbu lebih matang.
1. Masukkan cakar ayam, kecap manis, dan air sampai cakar tertutup air semua, aduk sebentar agar bumbu tercampur, tutup wajan ± 10 menit, kemudian aduk2 terus, tutup wajan lagi ±7 menit agar cakar matang benar dengan api sedang besar, aduk2 kembali cakar dan masukkan daun kemangi, aduk2 terus terus sampai kuah mengental dan surut (sesuai keinginan) test rasa, sajikan.




Ternyata resep rica-rica ekstra pedas cakar daun kemangi yang nikamt simple ini enteng sekali ya! Anda Semua mampu memasaknya. Cara buat rica-rica ekstra pedas cakar daun kemangi Cocok banget untuk kamu yang baru belajar memasak maupun untuk anda yang sudah lihai dalam memasak.

Tertarik untuk mencoba membuat resep rica-rica ekstra pedas cakar daun kemangi mantab simple ini? Kalau anda mau, ayo kalian segera buruan siapkan alat-alat dan bahan-bahannya, maka bikin deh Resep rica-rica ekstra pedas cakar daun kemangi yang enak dan sederhana ini. Sangat mudah kan. 

Oleh karena itu, ketimbang kalian berfikir lama-lama, maka kita langsung saja buat resep rica-rica ekstra pedas cakar daun kemangi ini. Dijamin kamu tiidak akan menyesal sudah membuat resep rica-rica ekstra pedas cakar daun kemangi lezat tidak rumit ini! Selamat berkreasi dengan resep rica-rica ekstra pedas cakar daun kemangi lezat sederhana ini di tempat tinggal kalian masing-masing,ya!.

