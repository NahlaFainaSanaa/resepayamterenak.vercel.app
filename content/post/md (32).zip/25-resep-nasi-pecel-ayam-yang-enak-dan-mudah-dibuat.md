---
description: "Resep Nasi Pecel Ayam yang enak dan Mudah Dibuat"
title: "Resep Nasi Pecel Ayam yang enak dan Mudah Dibuat"
slug: 25-resep-nasi-pecel-ayam-yang-enak-dan-mudah-dibuat
date: 2021-06-26T04:05:27.336Z
image: https://img-global.cpcdn.com/recipes/e4a6af78517fbbe5/680x482cq70/nasi-pecel-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e4a6af78517fbbe5/680x482cq70/nasi-pecel-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e4a6af78517fbbe5/680x482cq70/nasi-pecel-ayam-foto-resep-utama.jpg
author: Hester Andrews
ratingvalue: 4.8
reviewcount: 7
recipeingredient:
- "6 porsi nasi putih"
- " Bahan ayam goreng "
- "6 potong750gr ayam TG cuci bersih"
- "8 siung bawang putih haluskan"
- "2 ruas jari kunyit haluskan"
- "2.5 sdt garam"
- "1/2 sdt gula pasir"
- "500 ml air"
- " Bahan sambal pecel ayam "
- "20 butir cabe rawit ijo kecil"
- "5 butir bawang merah"
- "3 butir kemiri"
- "2 buah tomat merah"
- "1 sdt garam"
- "1 sdm gula merah aren sisir"
- " Pelengkap "
- " Tahu goreng"
- " Tempe goreng"
- " Lalapan kemangi dan kol sesuai selera"
recipeinstructions:
- "AYAM GORENG : campur air, ayam, bumbu halus, garam dan gula pasir. Tambahkan tahu diatasnya lalu ungkep hingga ayam matang dan airnya menyusut. Matikan api"
- "Pindahkan ayam dan tahu kedalam wadah. Untuk tempe setelah dipotong-potong dan dicuci, dikasih garam aja"
- "Goreng ayam, tahu dan tempe hingga kecoklatan. Angkat dan tiriskan"
- "SAMBAL PECEL AYAM : goreng cabe rawit, bawang merah, kemiri dan tomat hingga matang dan harum. Pindahkan kedalam ulekan, tambahkan garam dan gula merah aren. Ulek hingga halus. Koreksi rasa dan siap disajikan"
- "Sajikan nasi bersama ayam goreng, tahu tempe goreng, sambal dan lalapannya"
categories:
- Resep
tags:
- nasi
- pecel
- ayam

katakunci: nasi pecel ayam 
nutrition: 270 calories
recipecuisine: Indonesian
preptime: "PT18M"
cooktime: "PT37M"
recipeyield: "1"
recipecategory: Dinner

---


![Nasi Pecel Ayam](https://img-global.cpcdn.com/recipes/e4a6af78517fbbe5/680x482cq70/nasi-pecel-ayam-foto-resep-utama.jpg)

Jika kalian seorang istri, menyuguhkan santapan lezat pada orang tercinta adalah suatu hal yang menyenangkan bagi kamu sendiri. Tugas seorang  wanita Tidak saja mengerjakan pekerjaan rumah saja, namun anda juga harus menyediakan kebutuhan gizi terpenuhi dan panganan yang dimakan orang tercinta mesti enak.

Di masa  saat ini, kalian sebenarnya mampu mengorder olahan jadi meski tidak harus ribet mengolahnya dulu. Namun ada juga orang yang selalu ingin memberikan hidangan yang terbaik untuk orang yang dicintainya. Pasalnya, menghidangkan masakan yang dibuat sendiri jauh lebih higienis dan kita pun bisa menyesuaikan sesuai dengan makanan kesukaan keluarga. 



Mungkinkah anda salah satu penyuka nasi pecel ayam?. Asal kamu tahu, nasi pecel ayam merupakan sajian khas di Nusantara yang saat ini digemari oleh setiap orang dari berbagai wilayah di Nusantara. Kalian bisa memasak nasi pecel ayam kreasi sendiri di rumah dan pasti jadi santapan favorit di hari libur.

Kalian tidak perlu bingung untuk memakan nasi pecel ayam, lantaran nasi pecel ayam gampang untuk didapatkan dan juga anda pun boleh menghidangkannya sendiri di tempatmu. nasi pecel ayam boleh dimasak lewat beragam cara. Kini telah banyak cara modern yang membuat nasi pecel ayam semakin lebih enak.

Resep nasi pecel ayam pun mudah sekali untuk dibikin, lho. Kita tidak perlu capek-capek untuk membeli nasi pecel ayam, sebab Kita bisa menghidangkan di rumah sendiri. Bagi Kalian yang mau mencobanya, berikut resep untuk menyajikan nasi pecel ayam yang lezat yang mampu Anda hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Nasi Pecel Ayam:

1. Ambil 6 porsi nasi putih
1. Siapkan  Bahan ayam goreng :
1. Gunakan 6 potong/750gr ayam TG, cuci bersih
1. Siapkan 8 siung bawang putih, haluskan
1. Gunakan 2 ruas jari kunyit, haluskan
1. Gunakan 2.5 sdt garam
1. Ambil 1/2 sdt gula pasir
1. Siapkan 500 ml air
1. Siapkan  Bahan sambal pecel ayam :
1. Ambil 20 butir cabe rawit ijo kecil
1. Ambil 5 butir bawang merah
1. Gunakan 3 butir kemiri
1. Siapkan 2 buah tomat merah
1. Ambil 1 sdt garam
1. Siapkan 1 sdm gula merah aren, sisir
1. Ambil  Pelengkap :
1. Gunakan  Tahu goreng
1. Ambil  Tempe goreng
1. Siapkan  Lalapan kemangi dan kol (sesuai selera)




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Nasi Pecel Ayam:

1. AYAM GORENG : campur air, ayam, bumbu halus, garam dan gula pasir. Tambahkan tahu diatasnya lalu ungkep hingga ayam matang dan airnya menyusut. Matikan api
1. Pindahkan ayam dan tahu kedalam wadah. Untuk tempe setelah dipotong-potong dan dicuci, dikasih garam aja
1. Goreng ayam, tahu dan tempe hingga kecoklatan. Angkat dan tiriskan
1. SAMBAL PECEL AYAM : goreng cabe rawit, bawang merah, kemiri dan tomat hingga matang dan harum. Pindahkan kedalam ulekan, tambahkan garam dan gula merah aren. Ulek hingga halus. Koreksi rasa dan siap disajikan
1. Sajikan nasi bersama ayam goreng, tahu tempe goreng, sambal dan lalapannya




Wah ternyata cara buat nasi pecel ayam yang nikamt tidak rumit ini gampang sekali ya! Kita semua dapat memasaknya. Cara Membuat nasi pecel ayam Cocok sekali buat kamu yang baru mau belajar memasak maupun juga bagi anda yang telah jago memasak.

Tertarik untuk mencoba bikin resep nasi pecel ayam enak tidak rumit ini? Kalau anda ingin, mending kamu segera menyiapkan peralatan dan bahan-bahannya, maka bikin deh Resep nasi pecel ayam yang lezat dan tidak ribet ini. Betul-betul gampang kan. 

Maka dari itu, daripada kita berfikir lama-lama, ayo kita langsung bikin resep nasi pecel ayam ini. Dijamin kamu gak akan nyesel bikin resep nasi pecel ayam mantab tidak ribet ini! Selamat berkreasi dengan resep nasi pecel ayam nikmat tidak rumit ini di tempat tinggal kalian sendiri,ya!.

