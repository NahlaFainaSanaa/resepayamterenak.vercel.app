---
description: "Resep 51. Ayam Tangkap Khas Aceh yang nikmat Untuk Jualan"
title: "Resep 51. Ayam Tangkap Khas Aceh yang nikmat Untuk Jualan"
slug: 492-resep-51-ayam-tangkap-khas-aceh-yang-nikmat-untuk-jualan
date: 2021-04-25T03:26:10.936Z
image: https://img-global.cpcdn.com/recipes/e7ca1aa49d18da12/680x482cq70/51-ayam-tangkap-khas-aceh-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e7ca1aa49d18da12/680x482cq70/51-ayam-tangkap-khas-aceh-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e7ca1aa49d18da12/680x482cq70/51-ayam-tangkap-khas-aceh-foto-resep-utama.jpg
author: Ruby Little
ratingvalue: 4.8
reviewcount: 15
recipeingredient:
- "1 kg ayam potong kecil2"
- "500 ml air kelapa sy pakai Hydro Coco"
- "1 sdm air asam jawa"
- "10 lembar daun pandan"
- "20 batang daun kari"
- "20 buah cabe hijau keriting"
- "1 buah jeruk nipis"
- " Bumbu Halus "
- "4 siung bawang putih"
- "6 siung bawang merah"
- "1 sdm ketumbar"
- "1 sdt merica butiran"
- "3 butir kemiri sangrai"
- "3 cm kunyit bakar geprek"
- "3 cm lengkuas"
- "1 sdt garam"
recipeinstructions:
- "Cuci bersih ayam. Lumuri dengan garam dan perasan jeruk nipis. Diamkan 15 menit. Cuci kembali."
- "Masukkan ayam dalam wajan. Lumuri ayam dengan bumbu halus sampai rata."
- "Masukkan air kelapa sampai ayam terendam. Tambahkan 3 lbr daun pandan (diikat), 2 batang daun kari dan air asam jawa. Ungkep selama kurang lebih 45 menit. Tiriskan."
- "Panaskan minyak agak banyak. Sambil menunggu minyak panas, petik semua daun kari, potong-potong daun pandan, cabe hijau keriting utuh, cuci bersih semua. Jumlah daun bisa sesuaikan selera, kalo sy suka daun2nya banyak krn bisa dimakan dan enak banget rasanya"
- "Jika minyak sudah benar2 panas, goreng ayam dengan api sedang. Jika ayam sudah setengah matang, masukkan daun2an, goreng sampai garing. Tiriskan."
- "Konsep ayam tangkap itu katanya karena ayamnya mau ditangkap, jadi dia sembunyi di tumpukan dedaunan, jadi penyajiannya emang ayam2nya pada disembunyiin wkwkwk."
categories:
- Resep
tags:
- 51
- ayam
- tangkap

katakunci: 51 ayam tangkap 
nutrition: 228 calories
recipecuisine: Indonesian
preptime: "PT39M"
cooktime: "PT32M"
recipeyield: "1"
recipecategory: Dessert

---


![51. Ayam Tangkap Khas Aceh](https://img-global.cpcdn.com/recipes/e7ca1aa49d18da12/680x482cq70/51-ayam-tangkap-khas-aceh-foto-resep-utama.jpg)

Andai kamu seorang ibu, menyuguhkan olahan mantab untuk famili adalah hal yang membahagiakan untuk kita sendiri. Kewajiban seorang ibu bukan saja menangani rumah saja, namun anda pun harus menyediakan kebutuhan gizi tercukupi dan olahan yang disantap keluarga tercinta wajib enak.

Di waktu  sekarang, kamu sebenarnya bisa memesan hidangan instan meski tanpa harus capek memasaknya dulu. Tetapi ada juga mereka yang selalu mau memberikan yang terlezat untuk orang yang dicintainya. Pasalnya, memasak yang dibuat sendiri akan jauh lebih higienis dan bisa menyesuaikan makanan tersebut berdasarkan makanan kesukaan keluarga tercinta. 



Mungkinkah anda merupakan seorang penikmat 51. ayam tangkap khas aceh?. Tahukah kamu, 51. ayam tangkap khas aceh merupakan makanan khas di Nusantara yang sekarang disenangi oleh setiap orang di hampir setiap wilayah di Indonesia. Kamu bisa menghidangkan 51. ayam tangkap khas aceh kreasi sendiri di rumah dan dapat dijadikan camilan kesenanganmu di hari liburmu.

Kalian jangan bingung untuk menyantap 51. ayam tangkap khas aceh, sebab 51. ayam tangkap khas aceh sangat mudah untuk didapatkan dan kalian pun dapat mengolahnya sendiri di rumah. 51. ayam tangkap khas aceh boleh dimasak memalui beraneka cara. Kini pun ada banyak resep modern yang menjadikan 51. ayam tangkap khas aceh semakin lebih mantap.

Resep 51. ayam tangkap khas aceh juga gampang sekali untuk dibuat, lho. Anda tidak usah ribet-ribet untuk memesan 51. ayam tangkap khas aceh, sebab Anda mampu menghidangkan ditempatmu. Untuk Anda yang mau menghidangkannya, berikut ini resep menyajikan 51. ayam tangkap khas aceh yang lezat yang mampu Kamu buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan 51. Ayam Tangkap Khas Aceh:

1. Sediakan 1 kg ayam, potong kecil2
1. Ambil 500 ml air kelapa (sy pakai Hydro Coco)
1. Gunakan 1 sdm air asam jawa
1. Ambil 10 lembar daun pandan
1. Gunakan 20 batang daun kari
1. Ambil 20 buah cabe hijau keriting
1. Ambil 1 buah jeruk nipis
1. Ambil  Bumbu Halus :
1. Gunakan 4 siung bawang putih
1. Gunakan 6 siung bawang merah
1. Sediakan 1 sdm ketumbar
1. Sediakan 1 sdt merica butiran
1. Sediakan 3 butir kemiri, sangrai
1. Sediakan 3 cm kunyit bakar, geprek
1. Sediakan 3 cm lengkuas
1. Gunakan 1 sdt garam




<!--inarticleads2-->

##### Cara membuat 51. Ayam Tangkap Khas Aceh:

1. Cuci bersih ayam. Lumuri dengan garam dan perasan jeruk nipis. Diamkan 15 menit. Cuci kembali.
1. Masukkan ayam dalam wajan. Lumuri ayam dengan bumbu halus sampai rata.
1. Masukkan air kelapa sampai ayam terendam. Tambahkan 3 lbr daun pandan (diikat), 2 batang daun kari dan air asam jawa. Ungkep selama kurang lebih 45 menit. Tiriskan.
1. Panaskan minyak agak banyak. Sambil menunggu minyak panas, petik semua daun kari, potong-potong daun pandan, cabe hijau keriting utuh, cuci bersih semua. Jumlah daun bisa sesuaikan selera, kalo sy suka daun2nya banyak krn bisa dimakan dan enak banget rasanya
1. Jika minyak sudah benar2 panas, goreng ayam dengan api sedang. Jika ayam sudah setengah matang, masukkan daun2an, goreng sampai garing. Tiriskan.
1. Konsep ayam tangkap itu katanya karena ayamnya mau ditangkap, jadi dia sembunyi di tumpukan dedaunan, jadi penyajiannya emang ayam2nya pada disembunyiin wkwkwk.




Ternyata resep 51. ayam tangkap khas aceh yang nikamt simple ini enteng sekali ya! Semua orang bisa mencobanya. Resep 51. ayam tangkap khas aceh Sangat sesuai banget untuk kalian yang baru mau belajar memasak atau juga untuk kalian yang sudah pandai dalam memasak.

Tertarik untuk mulai mencoba buat resep 51. ayam tangkap khas aceh mantab simple ini? Kalau ingin, yuk kita segera buruan menyiapkan peralatan dan bahan-bahannya, lantas buat deh Resep 51. ayam tangkap khas aceh yang mantab dan sederhana ini. Sangat taidak sulit kan. 

Maka, ketimbang kalian berfikir lama-lama, maka langsung aja hidangkan resep 51. ayam tangkap khas aceh ini. Dijamin kalian tiidak akan nyesel sudah buat resep 51. ayam tangkap khas aceh nikmat simple ini! Selamat berkreasi dengan resep 51. ayam tangkap khas aceh lezat simple ini di rumah kalian masing-masing,ya!.

