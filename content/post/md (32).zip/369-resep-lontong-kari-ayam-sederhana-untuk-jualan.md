---
description: "Resep Lontong kari ayam Sederhana Untuk Jualan"
title: "Resep Lontong kari ayam Sederhana Untuk Jualan"
slug: 369-resep-lontong-kari-ayam-sederhana-untuk-jualan
date: 2021-04-25T14:46:55.142Z
image: https://img-global.cpcdn.com/recipes/4df4f313e331e318/680x482cq70/lontong-kari-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4df4f313e331e318/680x482cq70/lontong-kari-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4df4f313e331e318/680x482cq70/lontong-kari-ayam-foto-resep-utama.jpg
author: Alfred Frank
ratingvalue: 3.5
reviewcount: 11
recipeingredient:
- " Kari ayam"
- "1 1/2 kg ayam"
- "5 Bawang putih "
- "12 Bawang merah"
- "10 Kemiri"
- "5 cm Lengkuas"
- "5 Cm Jahe"
- "2 Kara"
- "5 lbr Daun jeruk"
- "4 lbr Daun salam"
- "2 btg Sereh"
- "1 SDm ketumbar bubuk"
- "1 bks kunyit"
- "1 SDm Garam"
- "2 SDM Gula"
- "1 sdt Merica"
- "1/2 sdt kayu manis bubuk"
- "1 1/2 liter air"
- " Lontong"
- "2 cup beras"
- "1 ruas jari Air setinggi"
- "1 sdt garam"
- "2 lbr Daun pandan"
recipeinstructions:
- "Kari ayam: Haluskan bawang putih, bawang merah,kemiri*.."
- "Tumis bumbu halus dengan sedikit minyak sampai harum tambahkan Jahe,lengkuas,sereh di geprek tambah air,daun salam, daun jeruk,garam,gula,merica,kunyit,ketumbar aduk rata cek rasa masak sampai mendidih masukan kara aduk lalu masukan ayam. Tunggu 45 menit api besar"
- "Lontong: masak nasi di rice cooker 25 menit. Aduk tunggu sampai uap panas hilang"
- "Potong daun dan panaskan di api kompor sisihkan. Bentuk lontong sekepal tangan bentuk memanjang. Masukan ke daun. Kunci dengan tusuk gigi."
- "Didihkan air lalu masukan lontong(harus terendam air). Saat lontong sudah masuk dan air mendidih hitung 5 menit. Lalu matikan tutup rapat panci 30 menit. Nyalakan kembali api. Hitung 7 menit setelah air mendidih."
categories:
- Resep
tags:
- lontong
- kari
- ayam

katakunci: lontong kari ayam 
nutrition: 183 calories
recipecuisine: Indonesian
preptime: "PT35M"
cooktime: "PT57M"
recipeyield: "4"
recipecategory: Lunch

---


![Lontong kari ayam](https://img-global.cpcdn.com/recipes/4df4f313e331e318/680x482cq70/lontong-kari-ayam-foto-resep-utama.jpg)

Sebagai seorang ibu, menyuguhkan hidangan sedap kepada famili adalah hal yang menyenangkan bagi kamu sendiri. Kewajiban seorang  wanita Tidak sekedar mengerjakan pekerjaan rumah saja, tetapi anda juga wajib menyediakan kebutuhan nutrisi terpenuhi dan juga olahan yang disantap anak-anak mesti mantab.

Di zaman  saat ini, kalian memang dapat membeli masakan instan meski tidak harus repot membuatnya dulu. Tetapi ada juga lho orang yang memang mau menyajikan yang terlezat bagi orang tercintanya. Karena, menghidangkan masakan yang dibuat sendiri akan jauh lebih higienis dan bisa menyesuaikan berdasarkan kesukaan keluarga. 



Apakah anda merupakan salah satu penggemar lontong kari ayam?. Asal kamu tahu, lontong kari ayam merupakan sajian khas di Nusantara yang kini disukai oleh orang-orang di berbagai wilayah di Nusantara. Kamu dapat menghidangkan lontong kari ayam sendiri di rumahmu dan dapat dijadikan santapan kegemaranmu di akhir pekanmu.

Kita tidak usah bingung untuk memakan lontong kari ayam, karena lontong kari ayam tidak sulit untuk didapatkan dan anda pun bisa membuatnya sendiri di tempatmu. lontong kari ayam boleh dimasak lewat beraneka cara. Kini ada banyak banget cara modern yang membuat lontong kari ayam lebih lezat.

Resep lontong kari ayam pun gampang sekali dibikin, lho. Anda tidak perlu repot-repot untuk membeli lontong kari ayam, lantaran Kita mampu menyajikan sendiri di rumah. Bagi Kalian yang mau menyajikannya, dibawah ini merupakan cara untuk membuat lontong kari ayam yang nikamat yang bisa Kamu hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Lontong kari ayam:

1. Gunakan  Kari ayam:
1. Sediakan 1 1/2 kg ayam
1. Ambil 5 Bawang putih *
1. Ambil 12 Bawang merah*
1. Sediakan 10 Kemiri*
1. Siapkan 5 cm Lengkuas
1. Sediakan 5 Cm Jahe
1. Ambil 2 Kara
1. Gunakan 5 lbr Daun jeruk
1. Siapkan 4 lbr Daun salam
1. Siapkan 2 btg Sereh
1. Ambil 1 SDm ketumbar bubuk
1. Ambil 1 bks kunyit
1. Gunakan 1 SDm Garam
1. Siapkan 2 SDM Gula
1. Sediakan 1 sdt Merica
1. Sediakan 1/2 sdt kayu manis bubuk
1. Ambil 1 1/2 liter air
1. Gunakan  Lontong:
1. Sediakan 2 cup beras
1. Sediakan 1 ruas jari Air setinggi
1. Siapkan 1 sdt garam
1. Gunakan 2 lbr Daun pandan




<!--inarticleads2-->

##### Langkah-langkah membuat Lontong kari ayam:

1. Kari ayam: Haluskan bawang putih, bawang merah,kemiri*..
1. Tumis bumbu halus dengan sedikit minyak sampai harum tambahkan Jahe,lengkuas,sereh di geprek tambah air,daun salam, daun jeruk,garam,gula,merica,kunyit,ketumbar aduk rata cek rasa masak sampai mendidih masukan kara aduk lalu masukan ayam. Tunggu 45 menit api besar
1. Lontong: masak nasi di rice cooker 25 menit. Aduk tunggu sampai uap panas hilang
1. Potong daun dan panaskan di api kompor sisihkan. Bentuk lontong sekepal tangan bentuk memanjang. Masukan ke daun. Kunci dengan tusuk gigi.
1. Didihkan air lalu masukan lontong(harus terendam air). Saat lontong sudah masuk dan air mendidih hitung 5 menit. Lalu matikan tutup rapat panci 30 menit. Nyalakan kembali api. Hitung 7 menit setelah air mendidih.




Ternyata cara buat lontong kari ayam yang mantab tidak rumit ini mudah banget ya! Kamu semua dapat menghidangkannya. Cara buat lontong kari ayam Sesuai banget buat anda yang baru akan belajar memasak ataupun bagi kamu yang sudah lihai memasak.

Tertarik untuk mulai mencoba membikin resep lontong kari ayam nikmat tidak ribet ini? Kalau tertarik, ayo kalian segera buruan menyiapkan alat dan bahan-bahannya, lalu bikin deh Resep lontong kari ayam yang enak dan sederhana ini. Sungguh taidak sulit kan. 

Jadi, ketimbang kita diam saja, yuk kita langsung buat resep lontong kari ayam ini. Pasti kalian tak akan nyesel sudah bikin resep lontong kari ayam nikmat tidak ribet ini! Selamat berkreasi dengan resep lontong kari ayam nikmat tidak rumit ini di rumah masing-masing,oke!.

