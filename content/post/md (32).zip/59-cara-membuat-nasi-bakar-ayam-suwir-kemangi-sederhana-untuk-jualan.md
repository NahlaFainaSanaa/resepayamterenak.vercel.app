---
description: "Cara membuat Nasi Bakar Ayam Suwir Kemangi Sederhana Untuk Jualan"
title: "Cara membuat Nasi Bakar Ayam Suwir Kemangi Sederhana Untuk Jualan"
slug: 59-cara-membuat-nasi-bakar-ayam-suwir-kemangi-sederhana-untuk-jualan
date: 2021-02-04T05:23:06.081Z
image: https://img-global.cpcdn.com/recipes/a4246c5f7fb3363d/680x482cq70/nasi-bakar-ayam-suwir-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a4246c5f7fb3363d/680x482cq70/nasi-bakar-ayam-suwir-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a4246c5f7fb3363d/680x482cq70/nasi-bakar-ayam-suwir-kemangi-foto-resep-utama.jpg
author: Richard Henry
ratingvalue: 3.2
reviewcount: 7
recipeingredient:
- " Bahan Nasi"
- "500 gram nasi"
- "700 ml santan"
- "1 sdt garam"
- "2 lembar daun salam"
- " Bahan Ayam Suwir Kemangi"
- "500 gram dada ayam fillet"
- "3 siung bawang putih"
- "5 siung bawang merah"
- "20 buah cabe rawit merah"
- "10 buah cabe merah keriting"
- "150 ml air kaldu"
- "1/2 sdt garam"
- "1/2 sdt kaldu bubuk"
- "1/2 keping gula merah"
- "1 lembar daun salam"
- " Bahan pelengkap"
- " Lalapan timun dan tomat"
- " Tempe goreng"
- " Daun pisang"
- " Lidi"
recipeinstructions:
- "Cuci bersih beras kemudian campurkan dengan santan, garam dan daun salam. Masak hingga santan menyusut. Kemudian pindahkan ke kukusan yg sudah dipanaskan terlebih dahulu. Kukus kurang lebih 30 menit. Jika sudah matang sisihkan (kalo mau praktis pakai magic com juga bisa ya)."
- "Rebus ayam hingga empuk. Jika sudah dingin, suwir-suwir dan sisihkan air kaldunya."
- "Uleg/blender cabe rawit, cabe keriting dan duo bawang. Panaskan minyak lalu tumis bumbu halus hingga harum. Tambahkan daun salam. Masukkan ayam, tambahkan air kaldu, garam dan kaldu bubuk. Koreksi rasa. Tunggu hingga air menyusut dan masukkan daun kemangi. Aduk merata dan angkat jika sudah matang."
- "Siapkan daun. Ambil 1 centong nasi, letakkan di atas daun kemudian tambahkan ayam suwir. Lalu tutup lagi dengan nasi. Bungkus dan sematkan lidi."
- "Setelah selesai dibungkus, kemudian panggang di atas teflon kurang lebih 5 - 10 menit (sampai daun kecokelatan)."
- "Sajikan dengan lalapan dan tambahan lauk sesuai selera."
categories:
- Resep
tags:
- nasi
- bakar
- ayam

katakunci: nasi bakar ayam 
nutrition: 137 calories
recipecuisine: Indonesian
preptime: "PT23M"
cooktime: "PT36M"
recipeyield: "1"
recipecategory: Lunch

---


![Nasi Bakar Ayam Suwir Kemangi](https://img-global.cpcdn.com/recipes/a4246c5f7fb3363d/680x482cq70/nasi-bakar-ayam-suwir-kemangi-foto-resep-utama.jpg)

Selaku seorang orang tua, mempersiapkan olahan mantab buat orang tercinta adalah hal yang menggembirakan untuk anda sendiri. Peran seorang ibu bukan sekedar menangani rumah saja, tapi anda pun harus menyediakan keperluan gizi tercukupi dan santapan yang disantap anak-anak mesti lezat.

Di waktu  saat ini, kita memang mampu mengorder olahan siap saji meski tanpa harus ribet mengolahnya dulu. Tapi ada juga mereka yang selalu mau memberikan yang terlezat untuk keluarganya. Pasalnya, menghidangkan masakan yang dibuat sendiri akan jauh lebih higienis dan bisa menyesuaikan makanan tersebut sesuai makanan kesukaan orang tercinta. 



Mungkinkah anda adalah seorang penggemar nasi bakar ayam suwir kemangi?. Asal kamu tahu, nasi bakar ayam suwir kemangi merupakan makanan khas di Indonesia yang sekarang disukai oleh kebanyakan orang dari berbagai tempat di Nusantara. Kalian dapat menghidangkan nasi bakar ayam suwir kemangi sendiri di rumah dan dapat dijadikan camilan kesenanganmu di hari libur.

Kita tak perlu bingung jika kamu ingin menyantap nasi bakar ayam suwir kemangi, lantaran nasi bakar ayam suwir kemangi sangat mudah untuk didapatkan dan juga kamu pun dapat mengolahnya sendiri di rumah. nasi bakar ayam suwir kemangi dapat diolah dengan beraneka cara. Kini ada banyak cara kekinian yang membuat nasi bakar ayam suwir kemangi semakin lebih mantap.

Resep nasi bakar ayam suwir kemangi pun sangat mudah dihidangkan, lho. Anda tidak usah ribet-ribet untuk memesan nasi bakar ayam suwir kemangi, tetapi Kamu bisa menyiapkan sendiri di rumah. Untuk Kalian yang hendak membuatnya, di bawah ini adalah resep untuk menyajikan nasi bakar ayam suwir kemangi yang mantab yang bisa Kalian coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Nasi Bakar Ayam Suwir Kemangi:

1. Ambil  Bahan Nasi:
1. Ambil 500 gram nasi
1. Gunakan 700 ml santan
1. Sediakan 1 sdt garam
1. Gunakan 2 lembar daun salam
1. Sediakan  Bahan Ayam Suwir Kemangi:
1. Siapkan 500 gram dada ayam fillet
1. Siapkan 3 siung bawang putih
1. Gunakan 5 siung bawang merah
1. Gunakan 20 buah cabe rawit merah
1. Sediakan 10 buah cabe merah keriting
1. Sediakan 150 ml air kaldu
1. Sediakan 1/2 sdt garam
1. Gunakan 1/2 sdt kaldu bubuk
1. Siapkan 1/2 keping gula merah
1. Gunakan 1 lembar daun salam
1. Sediakan  Bahan pelengkap:
1. Sediakan  Lalapan (timun dan tomat)
1. Ambil  Tempe goreng
1. Siapkan  Daun pisang
1. Ambil  Lidi




<!--inarticleads2-->

##### Cara membuat Nasi Bakar Ayam Suwir Kemangi:

1. Cuci bersih beras kemudian campurkan dengan santan, garam dan daun salam. Masak hingga santan menyusut. Kemudian pindahkan ke kukusan yg sudah dipanaskan terlebih dahulu. Kukus kurang lebih 30 menit. Jika sudah matang sisihkan (kalo mau praktis pakai magic com juga bisa ya).
1. Rebus ayam hingga empuk. Jika sudah dingin, suwir-suwir dan sisihkan air kaldunya.
1. Uleg/blender cabe rawit, cabe keriting dan duo bawang. Panaskan minyak lalu tumis bumbu halus hingga harum. Tambahkan daun salam. Masukkan ayam, tambahkan air kaldu, garam dan kaldu bubuk. Koreksi rasa. Tunggu hingga air menyusut dan masukkan daun kemangi. Aduk merata dan angkat jika sudah matang.
1. Siapkan daun. Ambil 1 centong nasi, letakkan di atas daun kemudian tambahkan ayam suwir. Lalu tutup lagi dengan nasi. Bungkus dan sematkan lidi.
1. Setelah selesai dibungkus, kemudian panggang di atas teflon kurang lebih 5 - 10 menit (sampai daun kecokelatan).
1. Sajikan dengan lalapan dan tambahan lauk sesuai selera.




Ternyata resep nasi bakar ayam suwir kemangi yang lezat simple ini mudah banget ya! Kamu semua dapat memasaknya. Cara buat nasi bakar ayam suwir kemangi Sesuai sekali buat anda yang baru mau belajar memasak maupun bagi kamu yang sudah ahli dalam memasak.

Tertarik untuk mulai mencoba membuat resep nasi bakar ayam suwir kemangi enak sederhana ini? Kalau anda mau, ayo kalian segera buruan siapin alat-alat dan bahannya, lalu buat deh Resep nasi bakar ayam suwir kemangi yang enak dan simple ini. Sungguh taidak sulit kan. 

Maka, daripada anda berfikir lama-lama, hayo kita langsung hidangkan resep nasi bakar ayam suwir kemangi ini. Dijamin kalian tak akan menyesal sudah membuat resep nasi bakar ayam suwir kemangi nikmat tidak ribet ini! Selamat berkreasi dengan resep nasi bakar ayam suwir kemangi lezat tidak ribet ini di rumah sendiri,oke!.

