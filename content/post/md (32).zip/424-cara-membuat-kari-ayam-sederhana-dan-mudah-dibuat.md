---
description: "Cara membuat Kari Ayam Sederhana dan Mudah Dibuat"
title: "Cara membuat Kari Ayam Sederhana dan Mudah Dibuat"
slug: 424-cara-membuat-kari-ayam-sederhana-dan-mudah-dibuat
date: 2021-02-06T02:14:44.167Z
image: https://img-global.cpcdn.com/recipes/74a60a3f1aad1747/680x482cq70/kari-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/74a60a3f1aad1747/680x482cq70/kari-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/74a60a3f1aad1747/680x482cq70/kari-ayam-foto-resep-utama.jpg
author: Isabelle Benson
ratingvalue: 4.9
reviewcount: 12
recipeingredient:
- "1/2 kg Ayam"
- "1 pcs Wortel"
- "1/2 siung Bawang Bombay"
- "1 Buah Kentang"
- "1 Blok Kari"
- "Sedikit garam"
- "Sedikit kaldu jamur"
- "500 ml air"
recipeinstructions:
- "Rebus ayam terlebih dahulu hingga busa coklatnya keluar. Buang air lalu bilas bersih"
- "Potong kotak kentang dan wortelnya. Cuci bersih"
- "Tumis bawang bombay hingga harum. Lalu masukkan wortel dan ayam yg sudah di rebus, aduk rata"
- "Tambahkan 500 ml air,masak hingga air menyusut setengah"
- "Tambahkan kentang dan masukkan blok kari nya. Tambahkan sedikit kaldu jamur dan garam, sedikit saja. Aduk rata masak hingga mengental"
- "Untuk blok karinya saya pakai yg ini, 1 resep ini 1 bungkus. Jgn lupa di potong ya kalau mau dimasukkan ke dalam masakan."
categories:
- Resep
tags:
- kari
- ayam

katakunci: kari ayam 
nutrition: 236 calories
recipecuisine: Indonesian
preptime: "PT19M"
cooktime: "PT51M"
recipeyield: "3"
recipecategory: Dessert

---


![Kari Ayam](https://img-global.cpcdn.com/recipes/74a60a3f1aad1747/680x482cq70/kari-ayam-foto-resep-utama.jpg)

Apabila kita seorang orang tua, menyajikan masakan sedap buat keluarga merupakan hal yang menggembirakan bagi anda sendiri. Peran seorang  wanita bukan saja menjaga rumah saja, tapi anda pun harus memastikan kebutuhan nutrisi terpenuhi dan juga masakan yang dimakan anak-anak harus sedap.

Di masa  sekarang, kita memang dapat memesan olahan instan meski tidak harus capek memasaknya lebih dulu. Namun ada juga lho mereka yang selalu mau memberikan yang terbaik untuk orang tercintanya. Sebab, menghidangkan masakan sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan makanan tersebut sesuai dengan kesukaan keluarga tercinta. 



Mungkinkah anda seorang penikmat kari ayam?. Tahukah kamu, kari ayam adalah makanan khas di Nusantara yang sekarang disukai oleh setiap orang di hampir setiap daerah di Nusantara. Kamu bisa menghidangkan kari ayam kreasi sendiri di rumahmu dan boleh dijadikan makanan kegemaranmu di hari liburmu.

Kita tidak usah bingung jika kamu ingin mendapatkan kari ayam, karena kari ayam sangat mudah untuk didapatkan dan juga kalian pun dapat menghidangkannya sendiri di rumah. kari ayam bisa diolah lewat berbagai cara. Kini sudah banyak sekali resep modern yang menjadikan kari ayam semakin enak.

Resep kari ayam juga gampang dibikin, lho. Kalian tidak usah repot-repot untuk membeli kari ayam, tetapi Kita dapat menghidangkan ditempatmu. Untuk Kalian yang mau menghidangkannya, berikut ini cara untuk membuat kari ayam yang lezat yang bisa Kita coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Kari Ayam:

1. Siapkan 1/2 kg Ayam
1. Siapkan 1 pcs Wortel
1. Siapkan 1/2 siung Bawang Bombay
1. Sediakan 1 Buah Kentang
1. Gunakan 1 Blok Kari
1. Gunakan Sedikit garam
1. Sediakan Sedikit kaldu jamur
1. Sediakan 500 ml air




<!--inarticleads2-->

##### Cara membuat Kari Ayam:

1. Rebus ayam terlebih dahulu hingga busa coklatnya keluar. Buang air lalu bilas bersih
<img src="https://img-global.cpcdn.com/steps/d2d03c418118cdc9/160x128cq70/kari-ayam-langkah-memasak-1-foto.jpg" alt="Kari Ayam">1. Potong kotak kentang dan wortelnya. Cuci bersih
<img src="https://img-global.cpcdn.com/steps/a95785a6438d2eb1/160x128cq70/kari-ayam-langkah-memasak-2-foto.jpg" alt="Kari Ayam">1. Tumis bawang bombay hingga harum. Lalu masukkan wortel dan ayam yg sudah di rebus, aduk rata
1. Tambahkan 500 ml air,masak hingga air menyusut setengah
1. Tambahkan kentang dan masukkan blok kari nya. Tambahkan sedikit kaldu jamur dan garam, sedikit saja. Aduk rata masak hingga mengental
1. Untuk blok karinya saya pakai yg ini, 1 resep ini 1 bungkus. Jgn lupa di potong ya kalau mau dimasukkan ke dalam masakan.




Wah ternyata cara buat kari ayam yang nikamt tidak ribet ini gampang sekali ya! Anda Semua bisa mencobanya. Cara buat kari ayam Cocok sekali untuk kalian yang sedang belajar memasak ataupun untuk kalian yang telah lihai memasak.

Apakah kamu tertarik mencoba bikin resep kari ayam lezat simple ini? Kalau tertarik, ayo kamu segera buruan siapkan alat-alat dan bahan-bahannya, lalu bikin deh Resep kari ayam yang enak dan simple ini. Sungguh gampang kan. 

Maka dari itu, ketimbang kita berfikir lama-lama, hayo kita langsung saja sajikan resep kari ayam ini. Dijamin anda tak akan nyesel sudah membuat resep kari ayam enak tidak rumit ini! Selamat mencoba dengan resep kari ayam nikmat tidak rumit ini di tempat tinggal sendiri,oke!.

