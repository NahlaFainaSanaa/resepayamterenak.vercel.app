---
description: "Cara buat Ayam Ungkep Presto yang nikmat dan Mudah Dibuat"
title: "Cara buat Ayam Ungkep Presto yang nikmat dan Mudah Dibuat"
slug: 139-cara-buat-ayam-ungkep-presto-yang-nikmat-dan-mudah-dibuat
date: 2021-06-26T21:10:48.250Z
image: https://img-global.cpcdn.com/recipes/0f2f969873832379/680x482cq70/ayam-ungkep-presto-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0f2f969873832379/680x482cq70/ayam-ungkep-presto-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0f2f969873832379/680x482cq70/ayam-ungkep-presto-foto-resep-utama.jpg
author: Ola Oliver
ratingvalue: 4.8
reviewcount: 4
recipeingredient:
- "1 ekor ayam potong jadi 14"
- "10 siung bawang putih"
- "2 sdt garam"
- "1 sdt gula"
- "1/2 sdt kaldu bubuk saya pakai royco ayam"
- "1 sdt ketumbar"
- "1/2 sdt lada saya pakai biji lada"
- "1 cm kunyit"
- "2 cm lengkuas di geprek"
- "2 batang sereh digeprek"
- "2 lembar daun salam"
- "4 lembar daun jeruk purut"
recipeinstructions:
- "Bersihkan ayam yang sudah dipotong 12 bagian, rendam sebentar di air perasan jeruk nipis"
- "Haluskan bawang putih, garam, gula, kaldu bubuk, ketumbar, lada, kunyit. Geprek sereh dan lengkuas"
- "Campur bumbu halus dg ayam dalam panci presto selama 30 menit sampai bumbu meresap, masukkan sereh, lengkuas, daun salam, daun jeruk purut diatasnya"
- "Setelah 30 menit tambahkan air dalam panci presto sampai dg ayam terendam"
- "Masak ayam di panci presto, kecilkan api kompor setelah panci presto berbunyi, tunggu sampai dengan 30 menit."
- "Setelah 30 menit, dinginkan panci presto sampai bisa dibuka. Tiriskan ayam, bisa langsung goreng sebentar atau bisa buat stok di kulkas"
categories:
- Resep
tags:
- ayam
- ungkep
- presto

katakunci: ayam ungkep presto 
nutrition: 242 calories
recipecuisine: Indonesian
preptime: "PT14M"
cooktime: "PT58M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Ungkep Presto](https://img-global.cpcdn.com/recipes/0f2f969873832379/680x482cq70/ayam-ungkep-presto-foto-resep-utama.jpg)

Selaku seorang orang tua, menyajikan panganan lezat kepada orang tercinta adalah suatu hal yang menggembirakan bagi kamu sendiri. Kewajiban seorang  wanita bukan sekedar menjaga rumah saja, tetapi kamu juga harus memastikan keperluan nutrisi tercukupi dan masakan yang dikonsumsi keluarga tercinta harus menggugah selera.

Di masa  sekarang, kamu sebenarnya dapat mengorder olahan siap saji meski tidak harus repot memasaknya dulu. Namun banyak juga lho orang yang selalu ingin menghidangkan yang terbaik bagi orang yang dicintainya. Karena, menyajikan masakan yang dibuat sendiri jauh lebih higienis dan bisa menyesuaikan sesuai selera keluarga tercinta. 



Mungkinkah anda merupakan seorang penikmat ayam ungkep presto?. Tahukah kamu, ayam ungkep presto adalah makanan khas di Indonesia yang kini disukai oleh orang-orang di hampir setiap wilayah di Nusantara. Kita dapat menyajikan ayam ungkep presto sendiri di rumahmu dan dapat dijadikan santapan favoritmu di akhir pekanmu.

Kita tidak usah bingung untuk mendapatkan ayam ungkep presto, karena ayam ungkep presto tidak sukar untuk ditemukan dan juga kita pun bisa menghidangkannya sendiri di rumah. ayam ungkep presto dapat diolah dengan beragam cara. Saat ini telah banyak cara kekinian yang menjadikan ayam ungkep presto lebih lezat.

Resep ayam ungkep presto juga sangat gampang dibikin, lho. Kita tidak usah ribet-ribet untuk memesan ayam ungkep presto, lantaran Kamu dapat menghidangkan sendiri di rumah. Bagi Kamu yang hendak mencobanya, berikut ini resep untuk membuat ayam ungkep presto yang mantab yang mampu Kita coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Ayam Ungkep Presto:

1. Siapkan 1 ekor ayam, potong jadi 14
1. Ambil 10 siung bawang putih
1. Ambil 2 sdt garam
1. Gunakan 1 sdt gula
1. Gunakan 1/2 sdt kaldu bubuk (saya pakai royco ayam)
1. Sediakan 1 sdt ketumbar
1. Ambil 1/2 sdt lada (saya pakai biji lada)
1. Siapkan 1 cm kunyit
1. Gunakan 2 cm lengkuas di geprek
1. Siapkan 2 batang sereh digeprek
1. Gunakan 2 lembar daun salam
1. Ambil 4 lembar daun jeruk purut




<!--inarticleads2-->

##### Cara menyiapkan Ayam Ungkep Presto:

1. Bersihkan ayam yang sudah dipotong 12 bagian, rendam sebentar di air perasan jeruk nipis
1. Haluskan bawang putih, garam, gula, kaldu bubuk, ketumbar, lada, kunyit. - Geprek sereh dan lengkuas
1. Campur bumbu halus dg ayam dalam panci presto selama 30 menit sampai bumbu meresap, masukkan sereh, lengkuas, daun salam, daun jeruk purut diatasnya
1. Setelah 30 menit tambahkan air dalam panci presto sampai dg ayam terendam
1. Masak ayam di panci presto, kecilkan api kompor setelah panci presto berbunyi, tunggu sampai dengan 30 menit.
1. Setelah 30 menit, dinginkan panci presto sampai bisa dibuka. Tiriskan ayam, bisa langsung goreng sebentar atau bisa buat stok di kulkas




Wah ternyata resep ayam ungkep presto yang enak tidak rumit ini gampang banget ya! Kita semua mampu menghidangkannya. Cara Membuat ayam ungkep presto Sangat sesuai banget buat kita yang baru akan belajar memasak atau juga bagi anda yang sudah jago memasak.

Apakah kamu tertarik mulai mencoba membikin resep ayam ungkep presto lezat tidak ribet ini? Kalau anda tertarik, ayo kalian segera siapin alat dan bahannya, lantas buat deh Resep ayam ungkep presto yang nikmat dan tidak ribet ini. Sungguh mudah kan. 

Jadi, ketimbang anda berfikir lama-lama, hayo kita langsung saja hidangkan resep ayam ungkep presto ini. Pasti kamu gak akan menyesal bikin resep ayam ungkep presto nikmat simple ini! Selamat mencoba dengan resep ayam ungkep presto enak tidak rumit ini di rumah sendiri,ya!.

