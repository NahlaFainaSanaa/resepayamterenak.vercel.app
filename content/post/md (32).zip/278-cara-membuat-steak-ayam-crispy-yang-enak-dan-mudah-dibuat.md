---
description: "Cara membuat Steak Ayam Crispy yang enak dan Mudah Dibuat"
title: "Cara membuat Steak Ayam Crispy yang enak dan Mudah Dibuat"
slug: 278-cara-membuat-steak-ayam-crispy-yang-enak-dan-mudah-dibuat
date: 2021-05-11T09:12:29.054Z
image: https://img-global.cpcdn.com/recipes/4c0d81ee15730d08/680x482cq70/steak-ayam-crispy-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4c0d81ee15730d08/680x482cq70/steak-ayam-crispy-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4c0d81ee15730d08/680x482cq70/steak-ayam-crispy-foto-resep-utama.jpg
author: Phillip Terry
ratingvalue: 4.3
reviewcount: 5
recipeingredient:
- " Bahan Utama"
- "500 gr dada ayam fillet"
- " Minyak untuk menggoreng"
- " Bahan Marinasi "
- "100 ml susu uht putih"
- "1/2 sdt garam"
- "1/2 sdt kaldu ayam bubuk"
- "1/2 sdt lada bubuk"
- "1 sdm bawang putih bubuk"
- " Bahan pelapis kering "
- "250 gr terigu"
- "1 sdt garam"
- "1 sdt kaldu bubuk"
- "1/2 sdt lada bubuk"
- "1/2 sdt bawang putih bubuk"
- " Bahan pencelup "
- "2 butir telur kocok lepas"
- " Bahan saus "
- "2 siung bawang putih cincang halus"
- "1/2 buah bawang Bombaycincang halus"
- "1 sdm maizenalarutkan dgn air"
- "250-300 ml air"
- "1 sdm saus tiram"
- "5 sdm saos tomat"
- "1 sdm saos sambal"
- "secukupnya Garamgulakaldu bubuk"
- " margarin secukupnya untuk menumis"
- " Pelengkap "
- "1 buah kentang ukuran besar"
- "1 buah wortelpotong panjang"
- "5 buah buncispotong panjang"
recipeinstructions:
- "Campur semua bumbu marinasi hingga rata. Iris tipis melebar dada ayam lalu pipihkan dgn ulekan batu,lalu campur ayam dgn bumbu marinasi,biarkan di kulkas kurleb minimal 1 jam"
- "Setelah 1 jam gulingkan ayam ke bahan pelapis kering,lalu celupkan ke bahan pencelup,gulingkan lagi ke bahan pelapis kering sambil sedikit di cubit &#34;,lakukan hingga ayam hbs"
- "Goreng ayam dgn minyak panas sampai matang kecoklatan sisihkan"
- "Saus :lelehkan margarin,tumis bawang putih dan bawang Bombay hingga harum dan layu lalu tambahkan bahan saus dan bumbu aduk rata"
- "Lalu masukan air dan larutan maizena,masak sampai meletup letup dan kental,jangan lupa koreksi rasa,sisihkan"
- "Pelengkap : rebus kentang yang sdh d potong &#34; sampai matang,lalu rebus sebentar wortel dan buncis angkat,sisihkan"
- "Tata steak ayam di piring,beri bahan pelengkap,lalu siram dgn saus...steak ayam crispy siap di sajikan"
categories:
- Resep
tags:
- steak
- ayam
- crispy

katakunci: steak ayam crispy 
nutrition: 152 calories
recipecuisine: Indonesian
preptime: "PT34M"
cooktime: "PT60M"
recipeyield: "2"
recipecategory: Dinner

---


![Steak Ayam Crispy](https://img-global.cpcdn.com/recipes/4c0d81ee15730d08/680x482cq70/steak-ayam-crispy-foto-resep-utama.jpg)

Sebagai seorang orang tua, mempersiapkan olahan sedap buat orang tercinta merupakan suatu hal yang membahagiakan bagi anda sendiri. Kewajiban seorang ibu bukan hanya mengurus rumah saja, tetapi kamu juga wajib memastikan keperluan nutrisi terpenuhi dan juga hidangan yang dimakan anak-anak harus sedap.

Di masa  saat ini, anda sebenarnya mampu mengorder panganan praktis walaupun tidak harus susah memasaknya terlebih dahulu. Tetapi banyak juga orang yang selalu ingin menyajikan yang terbaik untuk keluarganya. Karena, memasak yang diolah sendiri jauh lebih bersih dan kita pun bisa menyesuaikan masakan tersebut sesuai kesukaan famili. 



Mungkinkah anda adalah seorang penggemar steak ayam crispy?. Asal kamu tahu, steak ayam crispy merupakan sajian khas di Indonesia yang kini digemari oleh orang-orang di hampir setiap wilayah di Indonesia. Kamu dapat memasak steak ayam crispy olahan sendiri di rumahmu dan dapat dijadikan camilan favorit di hari liburmu.

Kita tidak perlu bingung jika kamu ingin menyantap steak ayam crispy, lantaran steak ayam crispy tidak sukar untuk didapatkan dan juga kalian pun boleh membuatnya sendiri di tempatmu. steak ayam crispy dapat diolah dengan beragam cara. Kini pun sudah banyak banget cara kekinian yang membuat steak ayam crispy lebih mantap.

Resep steak ayam crispy pun gampang dibuat, lho. Kamu jangan repot-repot untuk membeli steak ayam crispy, tetapi Kamu bisa menyiapkan ditempatmu. Bagi Kita yang hendak menghidangkannya, berikut ini cara membuat steak ayam crispy yang mantab yang bisa Kalian coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Steak Ayam Crispy:

1. Siapkan  Bahan Utama:
1. Siapkan 500 gr dada ayam fillet
1. Gunakan  Minyak untuk menggoreng
1. Gunakan  Bahan Marinasi :
1. Gunakan 100 ml susu uht putih
1. Siapkan 1/2 sdt garam
1. Siapkan 1/2 sdt kaldu ayam bubuk
1. Gunakan 1/2 sdt lada bubuk
1. Siapkan 1 sdm bawang putih bubuk
1. Ambil  Bahan pelapis kering :
1. Sediakan 250 gr terigu
1. Siapkan 1 sdt garam
1. Gunakan 1 sdt kaldu bubuk
1. Sediakan 1/2 sdt lada bubuk
1. Gunakan 1/2 sdt bawang putih bubuk
1. Siapkan  Bahan pencelup :
1. Sediakan 2 butir telur kocok lepas
1. Gunakan  Bahan saus :
1. Ambil 2 siung bawang putih, cincang halus
1. Ambil 1/2 buah bawang Bombay,cincang halus
1. Ambil 1 sdm maizena,larutkan dgn air
1. Gunakan 250-300 ml air
1. Gunakan 1 sdm saus tiram
1. Sediakan 5 sdm saos tomat
1. Gunakan 1 sdm saos sambal
1. Sediakan secukupnya Garam,gula,kaldu bubuk
1. Gunakan  margarin secukupnya untuk menumis
1. Ambil  Pelengkap :
1. Siapkan 1 buah kentang ukuran besar
1. Sediakan 1 buah wortel,potong panjang
1. Ambil 5 buah buncis,potong panjang




<!--inarticleads2-->

##### Cara membuat Steak Ayam Crispy:

1. Campur semua bumbu marinasi hingga rata. Iris tipis melebar dada ayam lalu pipihkan dgn ulekan batu,lalu campur ayam dgn bumbu marinasi,biarkan di kulkas kurleb minimal 1 jam
1. Setelah 1 jam gulingkan ayam ke bahan pelapis kering,lalu celupkan ke bahan pencelup,gulingkan lagi ke bahan pelapis kering sambil sedikit di cubit &#34;,lakukan hingga ayam hbs
1. Goreng ayam dgn minyak panas sampai matang kecoklatan sisihkan
1. Saus :lelehkan margarin,tumis bawang putih dan bawang Bombay hingga harum dan layu lalu tambahkan bahan saus dan bumbu aduk rata
1. Lalu masukan air dan larutan maizena,masak sampai meletup letup dan kental,jangan lupa koreksi rasa,sisihkan
1. Pelengkap : rebus kentang yang sdh d potong &#34; sampai matang,lalu rebus sebentar wortel dan buncis angkat,sisihkan
1. Tata steak ayam di piring,beri bahan pelengkap,lalu siram dgn saus...steak ayam crispy siap di sajikan




Wah ternyata cara membuat steak ayam crispy yang enak simple ini gampang sekali ya! Kalian semua dapat membuatnya. Cara Membuat steak ayam crispy Sangat cocok sekali untuk anda yang baru belajar memasak atau juga bagi kamu yang sudah jago memasak.

Apakah kamu mau mencoba buat resep steak ayam crispy nikmat sederhana ini? Kalau tertarik, mending kamu segera buruan menyiapkan alat dan bahan-bahannya, kemudian bikin deh Resep steak ayam crispy yang lezat dan sederhana ini. Betul-betul gampang kan. 

Oleh karena itu, ketimbang kita berfikir lama-lama, maka kita langsung buat resep steak ayam crispy ini. Pasti anda tak akan menyesal bikin resep steak ayam crispy lezat simple ini! Selamat berkreasi dengan resep steak ayam crispy mantab sederhana ini di rumah sendiri,ya!.

