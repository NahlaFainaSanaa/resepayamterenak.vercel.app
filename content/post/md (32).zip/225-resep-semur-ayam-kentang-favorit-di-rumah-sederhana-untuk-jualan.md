---
description: "Resep Semur Ayam Kentang Favorit di Rumah Sederhana Untuk Jualan"
title: "Resep Semur Ayam Kentang Favorit di Rumah Sederhana Untuk Jualan"
slug: 225-resep-semur-ayam-kentang-favorit-di-rumah-sederhana-untuk-jualan
date: 2021-04-05T09:11:46.652Z
image: https://img-global.cpcdn.com/recipes/4f00c258c2a36113/680x482cq70/semur-ayam-kentang-favorit-di-rumah-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4f00c258c2a36113/680x482cq70/semur-ayam-kentang-favorit-di-rumah-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4f00c258c2a36113/680x482cq70/semur-ayam-kentang-favorit-di-rumah-foto-resep-utama.jpg
author: Eugene Moreno
ratingvalue: 4.2
reviewcount: 13
recipeingredient:
- "500 gr ayam potong potong"
- "2 buah wortel potong potong"
- "2 buah kentang kupas dan goreng hingga matang"
- "secukupnya Garam"
- "secukupnya Gula merah"
- "secukupnya Gula pasir"
- "1 sdt kaldu jamur"
- "1 sdm kecap asin"
- "5 sdm kecap manis"
- "750 ml air"
- " Bumbu halus"
- "8 siung bawang merah"
- "4 siung bawang putih"
- "1/2 sdt merica bubuk 12 sdt merica butiran"
- "1/4 sdt pala bubuk seujung kuku kelingking pala utuh"
- "1/2 sdt kayumanis bubuk 3 cm kayu manis biarkan utuh"
recipeinstructions:
- "Siapkan semua bahan dan potong potong"
- "Haluskan bumbu"
- "Goreng kentang hingga matang"
- "Tumis bumbu hingga matang"
- "Masukan ayam dan aduk hingga berubah warna"
- "Masukan wortel, aduk rata"
- "Tambahkan air, biarkan panas lalu masukan bumbu tambahan. Masak hingga mendidih"
- "Setelah mendidih, masukan kentang goreng. Masak sambil sesekali diaduk, hingga air menyusut (sesuaikan selera mau seberapa susutnya), jangan lupa koreksi rasa ya."
categories:
- Resep
tags:
- semur
- ayam
- kentang

katakunci: semur ayam kentang 
nutrition: 272 calories
recipecuisine: Indonesian
preptime: "PT31M"
cooktime: "PT56M"
recipeyield: "4"
recipecategory: Dessert

---


![Semur Ayam Kentang Favorit di Rumah](https://img-global.cpcdn.com/recipes/4f00c258c2a36113/680x482cq70/semur-ayam-kentang-favorit-di-rumah-foto-resep-utama.jpg)

Selaku seorang ibu, menyuguhkan panganan mantab kepada keluarga merupakan hal yang menggembirakan untuk anda sendiri. Tanggung jawab seorang ibu Tidak sekadar mengatur rumah saja, tetapi kamu juga harus memastikan kebutuhan gizi terpenuhi dan olahan yang dikonsumsi anak-anak wajib enak.

Di masa  sekarang, kamu sebenarnya mampu membeli olahan yang sudah jadi walaupun tidak harus susah memasaknya lebih dulu. Namun banyak juga orang yang selalu ingin memberikan yang terlezat untuk keluarganya. Pasalnya, menyajikan masakan yang dibuat sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan makanan tersebut berdasarkan selera orang tercinta. 



Apakah anda adalah salah satu penyuka semur ayam kentang favorit di rumah?. Tahukah kamu, semur ayam kentang favorit di rumah adalah sajian khas di Nusantara yang saat ini disukai oleh kebanyakan orang di berbagai daerah di Indonesia. Anda dapat membuat semur ayam kentang favorit di rumah sendiri di rumahmu dan boleh jadi makanan favoritmu di akhir pekanmu.

Anda tak perlu bingung jika kamu ingin memakan semur ayam kentang favorit di rumah, lantaran semur ayam kentang favorit di rumah sangat mudah untuk ditemukan dan kita pun bisa memasaknya sendiri di rumah. semur ayam kentang favorit di rumah bisa diolah memalui beragam cara. Sekarang ada banyak sekali cara modern yang membuat semur ayam kentang favorit di rumah semakin lebih nikmat.

Resep semur ayam kentang favorit di rumah pun gampang sekali dihidangkan, lho. Kalian tidak perlu ribet-ribet untuk membeli semur ayam kentang favorit di rumah, karena Kamu bisa membuatnya sendiri di rumah. Untuk Kamu yang ingin membuatnya, inilah resep untuk membuat semur ayam kentang favorit di rumah yang mantab yang mampu Kalian buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Semur Ayam Kentang Favorit di Rumah:

1. Gunakan 500 gr ayam, potong potong
1. Siapkan 2 buah wortel, potong potong
1. Gunakan 2 buah kentang, kupas dan goreng hingga matang
1. Siapkan secukupnya Garam
1. Siapkan secukupnya Gula merah
1. Ambil secukupnya Gula pasir
1. Ambil 1 sdt kaldu jamur
1. Gunakan 1 sdm kecap asin
1. Siapkan 5 sdm kecap manis
1. Gunakan 750 ml air
1. Gunakan  Bumbu halus
1. Sediakan 8 siung bawang merah
1. Siapkan 4 siung bawang putih
1. Ambil 1/2 sdt merica bubuk (1/2 sdt merica butiran)
1. Siapkan 1/4 sdt pala bubuk (seujung kuku kelingking pala utuh)
1. Gunakan 1/2 sdt kayumanis bubuk (3 cm kayu manis, biarkan utuh)




<!--inarticleads2-->

##### Cara membuat Semur Ayam Kentang Favorit di Rumah:

1. Siapkan semua bahan dan potong potong
<img src="https://img-global.cpcdn.com/steps/a1f711aa5fc8259c/160x128cq70/semur-ayam-kentang-favorit-di-rumah-langkah-memasak-1-foto.jpg" alt="Semur Ayam Kentang Favorit di Rumah"><img src="https://img-global.cpcdn.com/steps/d35e0217b504faac/160x128cq70/semur-ayam-kentang-favorit-di-rumah-langkah-memasak-1-foto.jpg" alt="Semur Ayam Kentang Favorit di Rumah">1. Haluskan bumbu
1. Goreng kentang hingga matang
1. Tumis bumbu hingga matang
1. Masukan ayam dan aduk hingga berubah warna
1. Masukan wortel, aduk rata
1. Tambahkan air, biarkan panas lalu masukan bumbu tambahan. Masak hingga mendidih
1. Setelah mendidih, masukan kentang goreng. Masak sambil sesekali diaduk, hingga air menyusut (sesuaikan selera mau seberapa susutnya), jangan lupa koreksi rasa ya.




Ternyata cara buat semur ayam kentang favorit di rumah yang lezat simple ini mudah banget ya! Anda Semua mampu memasaknya. Resep semur ayam kentang favorit di rumah Sangat sesuai banget buat anda yang sedang belajar memasak ataupun juga untuk kalian yang telah ahli memasak.

Apakah kamu ingin mulai mencoba buat resep semur ayam kentang favorit di rumah mantab sederhana ini? Kalau mau, yuk kita segera siapkan alat dan bahan-bahannya, maka bikin deh Resep semur ayam kentang favorit di rumah yang mantab dan tidak rumit ini. Sungguh mudah kan. 

Maka dari itu, daripada kamu berlama-lama, maka kita langsung buat resep semur ayam kentang favorit di rumah ini. Pasti kalian tiidak akan menyesal membuat resep semur ayam kentang favorit di rumah mantab simple ini! Selamat mencoba dengan resep semur ayam kentang favorit di rumah mantab simple ini di rumah kalian masing-masing,oke!.

