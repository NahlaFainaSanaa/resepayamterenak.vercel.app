---
description: "Resep Lontong Kari Ayam yang lezat dan Mudah Dibuat"
title: "Resep Lontong Kari Ayam yang lezat dan Mudah Dibuat"
slug: 371-resep-lontong-kari-ayam-yang-lezat-dan-mudah-dibuat
date: 2021-05-04T02:06:32.308Z
image: https://img-global.cpcdn.com/recipes/1cec0e22b8c8d352/680x482cq70/lontong-kari-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1cec0e22b8c8d352/680x482cq70/lontong-kari-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1cec0e22b8c8d352/680x482cq70/lontong-kari-ayam-foto-resep-utama.jpg
author: Leona Morales
ratingvalue: 4.1
reviewcount: 3
recipeingredient:
- "4 buah lontong yg sudah jadi"
- "250 gr ayam filet ayam potong juga bisa"
- "100 gr buncis"
- "100 gr kelapa parut sangrai dan dihaluskan"
- "2 buah wortel"
- "1 gelas santan"
- "1 lt air"
- "3 lbr daun salam"
- "secukupnya Garam gula pasir merica"
- "1 buah tomat"
- " Daun bawang"
- " Bumbu halus"
- "3 siung bawang putih"
- "6 siung bawang merah"
- "1 ruas jari jahe"
- "2 ruas jari kunyit"
- "1 buah cabe merah besar"
- "2 butir kemiri sangrai"
- "1/2 sdt ketumbar sangrai"
- " Bumbu geprek "
- " Bumbu geprek"
- "1 ruas lengkuas"
- "1 batang sereh"
recipeinstructions:
- "Cuci bersih ayam, lalu tiriskan. Siapkan bumbu halus, setelah bumbu halus siap, haluskan sangrai kelapa parut."
- "Siapkan wajan, beri sedikit minyak. Setelah panas, tumis bumbu halus ditambah bumbu geprek sampai tercium harum. Lalu masukkan kelapa sangrai tadi."
- "Masukkan air, tunggu sampai mendidih. Lalu masukkan ayam, tunggu sampai setengah matang."
- "Masukkan wortel Dan buncis yg sudah dipotong sesuai selera dan sudah dibersihkan ke dalam wajan. Wortel dahulu baru buncis ya."
- "Lalu masukkan garam, gula, merica bubuk sesuai selera sambil koreksi rasa. Setelah itu tambahkan santan. Sebelum diangkat masukkan tomat dan daun bawang. Setelah tercampur, angkat Dan sisihkan."
- "Siapkan lontong yg sudah dipotong-potong dalam mangkuk, masukkan kari ayam tadi, lalu tambahkan bawang goreng. Lontong Kari Ayam siap disajikan"
categories:
- Resep
tags:
- lontong
- kari
- ayam

katakunci: lontong kari ayam 
nutrition: 202 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT52M"
recipeyield: "3"
recipecategory: Dinner

---


![Lontong Kari Ayam](https://img-global.cpcdn.com/recipes/1cec0e22b8c8d352/680x482cq70/lontong-kari-ayam-foto-resep-utama.jpg)

Sebagai seorang wanita, menyuguhkan masakan enak pada orang tercinta adalah suatu hal yang menggembirakan bagi kita sendiri. Kewajiban seorang istri bukan hanya mengatur rumah saja, tapi anda juga harus memastikan kebutuhan gizi terpenuhi dan santapan yang disantap anak-anak wajib enak.

Di waktu  saat ini, anda memang dapat mengorder masakan yang sudah jadi walaupun tidak harus capek memasaknya terlebih dahulu. Tetapi banyak juga mereka yang memang ingin memberikan yang terlezat bagi orang tercintanya. Karena, menyajikan masakan yang dibuat sendiri jauh lebih higienis dan bisa menyesuaikan masakan tersebut berdasarkan kesukaan keluarga tercinta. 



Apakah kamu seorang penyuka lontong kari ayam?. Asal kamu tahu, lontong kari ayam merupakan sajian khas di Nusantara yang kini digemari oleh orang-orang di berbagai tempat di Indonesia. Kamu dapat memasak lontong kari ayam buatan sendiri di rumahmu dan boleh jadi camilan favorit di hari liburmu.

Kamu tidak perlu bingung jika kamu ingin memakan lontong kari ayam, karena lontong kari ayam sangat mudah untuk ditemukan dan juga kamu pun dapat memasaknya sendiri di rumah. lontong kari ayam bisa dimasak memalui beraneka cara. Saat ini sudah banyak sekali resep kekinian yang menjadikan lontong kari ayam semakin mantap.

Resep lontong kari ayam juga gampang dibuat, lho. Kalian tidak usah capek-capek untuk membeli lontong kari ayam, lantaran Kita dapat menghidangkan ditempatmu. Bagi Kamu yang hendak menghidangkannya, berikut ini resep menyajikan lontong kari ayam yang nikamat yang dapat Kalian coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Lontong Kari Ayam:

1. Ambil 4 buah lontong yg sudah jadi
1. Sediakan 250 gr ayam filet (ayam potong juga bisa)
1. Ambil 100 gr buncis
1. Gunakan 100 gr kelapa parut sangrai dan dihaluskan
1. Siapkan 2 buah wortel
1. Ambil 1 gelas santan
1. Ambil 1 lt air
1. Ambil 3 lbr daun salam
1. Siapkan secukupnya Garam, gula pasir, merica
1. Ambil 1 buah tomat
1. Ambil  Daun bawang
1. Gunakan  Bumbu halus
1. Ambil 3 siung bawang putih
1. Siapkan 6 siung bawang merah
1. Ambil 1 ruas jari jahe
1. Siapkan 2 ruas jari kunyit
1. Ambil 1 buah cabe merah besar
1. Gunakan 2 butir kemiri sangrai
1. Sediakan 1/2 sdt ketumbar sangrai
1. Siapkan  Bumbu geprek :
1. Gunakan  Bumbu geprek
1. Ambil 1 ruas lengkuas
1. Sediakan 1 batang sereh




<!--inarticleads2-->

##### Langkah-langkah membuat Lontong Kari Ayam:

1. Cuci bersih ayam, lalu tiriskan. Siapkan bumbu halus, setelah bumbu halus siap, haluskan sangrai kelapa parut.
1. Siapkan wajan, beri sedikit minyak. Setelah panas, tumis bumbu halus ditambah bumbu geprek sampai tercium harum. Lalu masukkan kelapa sangrai tadi.
1. Masukkan air, tunggu sampai mendidih. Lalu masukkan ayam, tunggu sampai setengah matang.
1. Masukkan wortel Dan buncis yg sudah dipotong sesuai selera dan sudah dibersihkan ke dalam wajan. Wortel dahulu baru buncis ya.
1. Lalu masukkan garam, gula, merica bubuk sesuai selera sambil koreksi rasa. Setelah itu tambahkan santan. Sebelum diangkat masukkan tomat dan daun bawang. Setelah tercampur, angkat Dan sisihkan.
1. Siapkan lontong yg sudah dipotong-potong dalam mangkuk, masukkan kari ayam tadi, lalu tambahkan bawang goreng. Lontong Kari Ayam siap disajikan




Ternyata cara buat lontong kari ayam yang enak sederhana ini enteng sekali ya! Anda Semua bisa memasaknya. Resep lontong kari ayam Cocok banget buat kita yang baru mau belajar memasak maupun untuk anda yang sudah ahli memasak.

Apakah kamu tertarik mencoba membikin resep lontong kari ayam lezat simple ini? Kalau kamu tertarik, yuk kita segera buruan siapkan alat-alat dan bahan-bahannya, kemudian buat deh Resep lontong kari ayam yang lezat dan tidak rumit ini. Betul-betul gampang kan. 

Maka dari itu, ketimbang anda berlama-lama, maka kita langsung buat resep lontong kari ayam ini. Dijamin kamu tiidak akan nyesel bikin resep lontong kari ayam mantab sederhana ini! Selamat berkreasi dengan resep lontong kari ayam mantab sederhana ini di tempat tinggal kalian masing-masing,oke!.

