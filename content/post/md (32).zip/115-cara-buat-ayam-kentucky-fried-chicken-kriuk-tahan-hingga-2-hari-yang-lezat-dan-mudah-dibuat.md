---
description: "Cara buat Ayam kentucky (fried chicken) kriuk tahan hingga 2 hari yang lezat dan Mudah Dibuat"
title: "Cara buat Ayam kentucky (fried chicken) kriuk tahan hingga 2 hari yang lezat dan Mudah Dibuat"
slug: 115-cara-buat-ayam-kentucky-fried-chicken-kriuk-tahan-hingga-2-hari-yang-lezat-dan-mudah-dibuat
date: 2021-04-02T17:56:15.550Z
image: https://img-global.cpcdn.com/recipes/4a546ba5fb406865/680x482cq70/ayam-kentucky-fried-chicken-kriuk-tahan-hingga-2-hari-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4a546ba5fb406865/680x482cq70/ayam-kentucky-fried-chicken-kriuk-tahan-hingga-2-hari-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4a546ba5fb406865/680x482cq70/ayam-kentucky-fried-chicken-kriuk-tahan-hingga-2-hari-foto-resep-utama.jpg
author: Walter Adkins
ratingvalue: 4.8
reviewcount: 4
recipeingredient:
- "1 kg ayam potong kecilkecil"
- "5 siung bawang putih"
- "2 sendok makan merica"
- "1/2 ruas jari kunyit"
- "1 butir telur"
- "Secukupnya garam"
- "Secukupnya penyedap rasa"
- "1 kg tepung terigu serbaguna"
- "1 sendok teh baking powder"
- " Air es es batu"
- " Minyak goreng"
recipeinstructions:
- "Potong dan cuci ayam hingga bersih"
- "Haluskan bawang putih, garam, kunyit,merica"
- "Masukan bumbu halus kedalam ayam yang sudah dibersihkan tadi, lalu dimasukan kedalam kulkas selama kurang lebih 30 menit"
- "Siapkan wadah agak besar (baskom) lalu masukkan tepung terigu setengah dulu, 1 sendok baking powder, dan penyedap rasa 1 bungkus kecil. Aduk sampai rata (tanpa air)"
- "Siapkan mangkok lalu masukan 1 buah telur, air es secukupnya (sampai bisa untuk mencelup ayam)"
- "Setelah ayam 30 menit dalam kulkas, ambil sebagian ayam masukkan kedalam adonan tepung diaduk bolak balik jangan dicubit ya. Lalu celupkan kedalam cairan telur tadi, masukkan lagi dalam adonan tepung, ulangi lagi sampai ketebalan tepung yang diinginkan."
- "Goreng dalam minyak panas hingga ayam terendam dalam minyak, dan tunggu hingga coklat kekuningan. Lalu angkat, sajikan"
- "Selamat menikmati, lebih enak menggunakan saos atau dengan digeprek sambal bawang mentah (bawang putih 1 siung, cabe rawit 10 buah, garam secukupnya)"
categories:
- Resep
tags:
- ayam
- kentucky
- fried

katakunci: ayam kentucky fried 
nutrition: 163 calories
recipecuisine: Indonesian
preptime: "PT40M"
cooktime: "PT33M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam kentucky (fried chicken) kriuk tahan hingga 2 hari](https://img-global.cpcdn.com/recipes/4a546ba5fb406865/680x482cq70/ayam-kentucky-fried-chicken-kriuk-tahan-hingga-2-hari-foto-resep-utama.jpg)

Selaku seorang wanita, menyediakan olahan sedap pada orang tercinta merupakan suatu hal yang sangat menyenangkan untuk kita sendiri. Tanggung jawab seorang istri Tidak cuman mengurus rumah saja, namun kamu juga harus menyediakan kebutuhan nutrisi terpenuhi dan olahan yang dikonsumsi keluarga tercinta wajib sedap.

Di waktu  sekarang, anda sebenarnya mampu memesan hidangan praktis walaupun tanpa harus repot mengolahnya dulu. Namun banyak juga lho mereka yang memang ingin menyajikan yang terenak untuk orang yang dicintainya. Sebab, memasak yang diolah sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan makanan tersebut sesuai dengan selera famili. 

Resep ayam goreng fried chicken kriuk renyah lengkap. Yuk belajar cara membuat adonan tepung Kentucky Fried Chicken menjadi inspirasi untuk membuat kreasi masakan ayam goreng. Meskipun anda mengkonsumsi daging ayam setiap hari.

Mungkinkah kamu salah satu penikmat ayam kentucky (fried chicken) kriuk tahan hingga 2 hari?. Asal kamu tahu, ayam kentucky (fried chicken) kriuk tahan hingga 2 hari adalah sajian khas di Indonesia yang sekarang disukai oleh banyak orang di hampir setiap tempat di Nusantara. Kamu dapat memasak ayam kentucky (fried chicken) kriuk tahan hingga 2 hari sendiri di rumah dan dapat dijadikan hidangan kegemaranmu di hari liburmu.

Kamu jangan bingung jika kamu ingin menyantap ayam kentucky (fried chicken) kriuk tahan hingga 2 hari, sebab ayam kentucky (fried chicken) kriuk tahan hingga 2 hari gampang untuk dicari dan kamu pun bisa membuatnya sendiri di rumah. ayam kentucky (fried chicken) kriuk tahan hingga 2 hari boleh diolah dengan bermacam cara. Kini pun telah banyak cara kekinian yang menjadikan ayam kentucky (fried chicken) kriuk tahan hingga 2 hari semakin enak.

Resep ayam kentucky (fried chicken) kriuk tahan hingga 2 hari juga gampang untuk dibuat, lho. Kita tidak perlu ribet-ribet untuk membeli ayam kentucky (fried chicken) kriuk tahan hingga 2 hari, lantaran Anda mampu membuatnya ditempatmu. Untuk Kita yang hendak membuatnya, inilah cara untuk menyajikan ayam kentucky (fried chicken) kriuk tahan hingga 2 hari yang nikamat yang bisa Anda buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Ayam kentucky (fried chicken) kriuk tahan hingga 2 hari:

1. Ambil 1 kg ayam (potong kecil-kecil)
1. Siapkan 5 siung bawang putih
1. Siapkan 2 sendok makan merica
1. Sediakan 1/2 ruas jari kunyit
1. Sediakan 1 butir telur
1. Ambil Secukupnya garam
1. Sediakan Secukupnya penyedap rasa
1. Ambil 1 kg tepung terigu serbaguna
1. Siapkan 1 sendok teh baking powder
1. Siapkan  Air es/ es batu
1. Gunakan  Minyak goreng


Verification KFC alias Kentucky Fried Chicken merupakan salah satu restoran makanan cepat saji (fast food) yang terkenal di dunia. Tak hanya menu ayam yang diandalkan oleh KFC, namun banyak juga menu-menu olahan ayam lainnya seperti Yakiniku, Bento, burger, sandwich, hingga minuman olahan. Lihat juga resep Ayam krispi kentucky awet kriuk enak lainnya. Dua kali pencelupan dilakukan agar ayam goreng KFC ini bisa memiliki tekstur kulit atau tepung yang renyah besar krispi dan garing. 

<!--inarticleads2-->

##### Langkah-langkah membuat Ayam kentucky (fried chicken) kriuk tahan hingga 2 hari:

1. Potong dan cuci ayam hingga bersih
1. Haluskan bawang putih, garam, kunyit,merica
1. Masukan bumbu halus kedalam ayam yang sudah dibersihkan tadi, lalu dimasukan kedalam kulkas selama kurang lebih 30 menit
1. Siapkan wadah agak besar (baskom) lalu masukkan tepung terigu setengah dulu, 1 sendok baking powder, dan penyedap rasa 1 bungkus kecil. Aduk sampai rata (tanpa air)
1. Siapkan mangkok lalu masukan 1 buah telur, air es secukupnya (sampai bisa untuk mencelup ayam)
1. Setelah ayam 30 menit dalam kulkas, ambil sebagian ayam masukkan kedalam adonan tepung diaduk bolak balik jangan dicubit ya. Lalu celupkan kedalam cairan telur tadi, masukkan lagi dalam adonan tepung, ulangi lagi sampai ketebalan tepung yang diinginkan.
1. Goreng dalam minyak panas hingga ayam terendam dalam minyak, dan tunggu hingga coklat kekuningan. Lalu angkat, sajikan
1. Selamat menikmati, lebih enak menggunakan saos atau dengan digeprek sambal bawang mentah (bawang putih 1 siung, cabe rawit 10 buah, garam secukupnya)


Kentucky Fried Chicken atau disingkat dengan KFC merupakan salah satu brand perusahaan siapkan air. campurkan semua bahan perendam. Resep Ayam Goreng Crispy Tahan Lama Ide Usaha. Tips dan trik cara buat Fried chicken renyah seharian Tutorial tentang bagaimana memasak ayam goreng tepung / kentucky fried chicken selamat Hai, hari nie saya share cara buat ayam goreng ala kfc mudah dan senang tak perlu banyak bahan hanya. Purveyors of the World&#39;s Best Chicken. www.kfc.com/menu/sandwiches/kfc-sandwich. Fried chicken atau ayam goreng tepung dikenal sebagai makanan Amerika. 

Wah ternyata cara membuat ayam kentucky (fried chicken) kriuk tahan hingga 2 hari yang lezat tidak ribet ini mudah banget ya! Anda Semua dapat memasaknya. Resep ayam kentucky (fried chicken) kriuk tahan hingga 2 hari Cocok banget untuk kita yang baru belajar memasak atau juga bagi kalian yang sudah jago dalam memasak.

Tertarik untuk mulai mencoba buat resep ayam kentucky (fried chicken) kriuk tahan hingga 2 hari enak tidak rumit ini? Kalau kalian ingin, yuk kita segera buruan siapin alat dan bahannya, lantas buat deh Resep ayam kentucky (fried chicken) kriuk tahan hingga 2 hari yang enak dan simple ini. Betul-betul gampang kan. 

Jadi, ketimbang kalian berfikir lama-lama, hayo kita langsung saja sajikan resep ayam kentucky (fried chicken) kriuk tahan hingga 2 hari ini. Pasti kalian gak akan nyesel sudah buat resep ayam kentucky (fried chicken) kriuk tahan hingga 2 hari lezat sederhana ini! Selamat berkreasi dengan resep ayam kentucky (fried chicken) kriuk tahan hingga 2 hari enak tidak ribet ini di tempat tinggal kalian sendiri,ya!.

