---
description: "Bahan-bahan Lontong Kari Ayam yang enak dan Mudah Dibuat"
title: "Bahan-bahan Lontong Kari Ayam yang enak dan Mudah Dibuat"
slug: 362-bahan-bahan-lontong-kari-ayam-yang-enak-dan-mudah-dibuat
date: 2021-02-22T09:29:37.356Z
image: https://img-global.cpcdn.com/recipes/25f1d7b8e038977a/680x482cq70/lontong-kari-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/25f1d7b8e038977a/680x482cq70/lontong-kari-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/25f1d7b8e038977a/680x482cq70/lontong-kari-ayam-foto-resep-utama.jpg
author: Herman Hayes
ratingvalue: 3.3
reviewcount: 5
recipeingredient:
- "1/2 ekor ayam saya 12 kg sayap ayam"
- "2 batang sereh geprek"
- "4 lbr daun salam"
- "4 lbr daun jeruk"
- "2 ruas lengkuas geprek"
- "1 bungkus tahu bandung digoreng"
- "5 butir telur rebus lalu goreng"
- "1 sdt bubuk kari saya bubuk kari India merk Jays"
- "3 sdm minyak goreng utk menumis bumbu"
- "500 ml air"
- "1 pack santan KARA ukuran 200 ml"
- "1 sdm garam"
- "1 sdm Gula merah iris halus"
- "1/2 sdm kaldu bubuk"
- " Bumbu A"
- "5 camer keriting"
- "5 camer besar"
- "10 butir bawang merah"
- "8 butir bawang putih"
- "1 1/2 ruas jahe"
- "1 ruas kunyit"
- "4 butir kemiri sangrai"
- "1 sdt ketumbar sangrai"
- "1 sdt jinten sangrai"
- "1 sdt laput"
- " Bumbu B"
- "4 butir kapulaga"
- "3 ruas jari kayu manis"
- "1 butir bunga lawang"
- "4 butir cengkeh"
- " Pendamping"
- " Bawang goreng"
- " Lontongnasi"
- " Sambel kentang"
- " Emping"
recipeinstructions:
- "Sangrai Bumbu B, sisihkan"
- "Haluskan Bumbu A. Tumis hingga harum, masukkan Bumbu B, salam, sereh, lengkuas, dan bubuk kari. Tumis lagi terus hingga matang dan betul2 tanak"
- "Masukkan ayam, aduk hingga ayam berubah warna. Masukkan air, telur dan tahu yg sdh digoreng, garam, Gula merah iris, dan kaldu bubuk, masak hingga mendidih"
- "Masukkan santan KARA, aduk hingga mendidih. Koreksi rasa. Jika sdh oke, matikan api, siap disajikan bersama lontong atau nasi hangat ngepul2, pleus sambel kentang, taburi bawang goreng biar makin syedep, dan emping buat sound effect kriuk kriuk. Sluuurrpp hwaaaahh, nikmeehh... 👍"
categories:
- Resep
tags:
- lontong
- kari
- ayam

katakunci: lontong kari ayam 
nutrition: 122 calories
recipecuisine: Indonesian
preptime: "PT24M"
cooktime: "PT52M"
recipeyield: "3"
recipecategory: Dinner

---


![Lontong Kari Ayam](https://img-global.cpcdn.com/recipes/25f1d7b8e038977a/680x482cq70/lontong-kari-ayam-foto-resep-utama.jpg)

Selaku seorang yang hobi memasak, menyajikan hidangan sedap buat keluarga tercinta adalah hal yang menggembirakan bagi kita sendiri. Peran seorang  wanita Tidak sekadar mengerjakan pekerjaan rumah saja, tetapi kamu juga wajib menyediakan keperluan nutrisi terpenuhi dan panganan yang disantap orang tercinta wajib lezat.

Di masa  sekarang, kita sebenarnya bisa mengorder olahan instan walaupun tanpa harus ribet membuatnya dahulu. Tapi ada juga lho orang yang memang ingin memberikan yang terlezat bagi orang yang dicintainya. Sebab, menyajikan masakan yang dibuat sendiri jauh lebih higienis dan kita pun bisa menyesuaikan masakan tersebut sesuai dengan masakan kesukaan keluarga. 



Mungkinkah kamu salah satu penggemar lontong kari ayam?. Asal kamu tahu, lontong kari ayam merupakan hidangan khas di Indonesia yang sekarang digemari oleh setiap orang dari hampir setiap daerah di Indonesia. Kalian bisa membuat lontong kari ayam sendiri di rumah dan boleh jadi hidangan kesukaanmu di akhir pekanmu.

Kalian jangan bingung jika kamu ingin menyantap lontong kari ayam, lantaran lontong kari ayam tidak sukar untuk ditemukan dan juga kita pun bisa memasaknya sendiri di tempatmu. lontong kari ayam bisa diolah memalui bermacam cara. Saat ini telah banyak sekali resep kekinian yang membuat lontong kari ayam semakin nikmat.

Resep lontong kari ayam juga sangat mudah dibikin, lho. Kamu jangan ribet-ribet untuk membeli lontong kari ayam, karena Kamu dapat membuatnya sendiri di rumah. Untuk Kalian yang hendak menghidangkannya, inilah cara untuk membuat lontong kari ayam yang enak yang bisa Anda coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Lontong Kari Ayam:

1. Siapkan 1/2 ekor ayam (saya: 1/2 kg sayap ayam)
1. Ambil 2 batang sereh, geprek
1. Ambil 4 lbr daun salam
1. Sediakan 4 lbr daun jeruk
1. Sediakan 2 ruas lengkuas, geprek
1. Sediakan 1 bungkus tahu bandung, digoreng
1. Sediakan 5 butir telur, rebus lalu goreng
1. Sediakan 1 sdt bubuk kari (saya: bubuk kari India merk Jay&#39;s)
1. Sediakan 3 sdm minyak goreng utk menumis bumbu
1. Sediakan 500 ml air
1. Gunakan 1 pack santan KARA ukuran 200 ml
1. Ambil 1 sdm garam
1. Sediakan 1 sdm Gula merah, iris halus
1. Gunakan 1/2 sdm kaldu bubuk
1. Siapkan  Bumbu A
1. Sediakan 5 camer keriting
1. Gunakan 5 camer besar
1. Siapkan 10 butir bawang merah
1. Ambil 8 butir bawang putih
1. Gunakan 1 1/2 ruas jahe
1. Gunakan 1 ruas kunyit
1. Gunakan 4 butir kemiri, sangrai
1. Siapkan 1 sdt ketumbar, sangrai
1. Ambil 1 sdt jinten, sangrai
1. Gunakan 1 sdt laput
1. Siapkan  Bumbu B
1. Sediakan 4 butir kapulaga
1. Gunakan 3 ruas jari kayu manis
1. Ambil 1 butir bunga lawang
1. Siapkan 4 butir cengkeh
1. Sediakan  Pendamping
1. Sediakan  Bawang goreng
1. Siapkan  Lontong/nasi
1. Siapkan  Sambel kentang
1. Sediakan  Emping




<!--inarticleads2-->

##### Cara menyiapkan Lontong Kari Ayam:

1. Sangrai Bumbu B, sisihkan
1. Haluskan Bumbu A. Tumis hingga harum, masukkan Bumbu B, salam, sereh, lengkuas, dan bubuk kari. Tumis lagi terus hingga matang dan betul2 tanak
1. Masukkan ayam, aduk hingga ayam berubah warna. Masukkan air, telur dan tahu yg sdh digoreng, garam, Gula merah iris, dan kaldu bubuk, masak hingga mendidih
1. Masukkan santan KARA, aduk hingga mendidih. Koreksi rasa. Jika sdh oke, matikan api, siap disajikan bersama lontong atau nasi hangat ngepul2, pleus sambel kentang, taburi bawang goreng biar makin syedep, dan emping buat sound effect kriuk kriuk. Sluuurrpp hwaaaahh, nikmeehh... 👍




Ternyata cara buat lontong kari ayam yang nikamt tidak ribet ini enteng banget ya! Kita semua bisa membuatnya. Resep lontong kari ayam Sangat cocok banget buat kalian yang baru belajar memasak maupun juga bagi anda yang sudah hebat dalam memasak.

Apakah kamu tertarik mulai mencoba buat resep lontong kari ayam nikmat sederhana ini? Kalau kamu ingin, ayo kamu segera menyiapkan alat-alat dan bahannya, kemudian bikin deh Resep lontong kari ayam yang nikmat dan sederhana ini. Benar-benar taidak sulit kan. 

Maka, ketimbang kamu berlama-lama, hayo kita langsung saja sajikan resep lontong kari ayam ini. Dijamin kamu gak akan menyesal bikin resep lontong kari ayam nikmat tidak rumit ini! Selamat berkreasi dengan resep lontong kari ayam nikmat simple ini di tempat tinggal kalian sendiri,ya!.

