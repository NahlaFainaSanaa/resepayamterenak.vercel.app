---
description: "Cara buat Kari Ayam Tahu yang nikmat Untuk Jualan"
title: "Cara buat Kari Ayam Tahu yang nikmat Untuk Jualan"
slug: 434-cara-buat-kari-ayam-tahu-yang-nikmat-untuk-jualan
date: 2021-07-05T07:27:01.038Z
image: https://img-global.cpcdn.com/recipes/d5516cf9997785f1/680x482cq70/kari-ayam-tahu-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d5516cf9997785f1/680x482cq70/kari-ayam-tahu-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d5516cf9997785f1/680x482cq70/kari-ayam-tahu-foto-resep-utama.jpg
author: Thomas Rodriquez
ratingvalue: 3.5
reviewcount: 9
recipeingredient:
- "1/2 Kg Ayam"
- " Tahu matang"
- " Bawang Merah"
- " Bawang Putih"
- "1 ruas kunyit"
- "1 ruas lengkuas geprek"
- "1 batang serai geprek"
- " Daun jeruk"
- " Daun salam"
- " Jinten"
- " Kemiri"
- " Merica"
- " Ketumbar"
- " Garam"
- " Masako optional tes rasa bila kurang asin"
- "2 bungkus santan kara"
- " Bawang goreng"
- " Minyak goreng untuk menumis bumbu"
recipeinstructions:
- "Potong ayam menjadi beberapa bagian kemudian cuci bersih ayam"
- "Didihkan air kemudian rebus ayam yang sudah dicuci bersih sampai air surut. Setelah itu buang air hasil rebusan tadi dan tambahkan air kedalam panci untuk direbus ulang untuk step ini air jangan dibuang ya bun"
- "Kemudian ulek bumbu yang sudah disiapkan sampai halus (bisa juga diblender)"
- "Setelah itu tumis bumbu yang sudah dihaluskan, kemudian masukkan daun jeruk daun salam serai dan lengkuas yang sudah digeprek. Tumis hingga harum"
- "Langkah terakhir masukkan tumisan bumbu kedalam panci yang berisi ayam dan tambahkan 2 bungkus santan kara. Aduk2 hingga benar2 matang dan mulai tes rasa apabila dirasa sayur kurang asin. Matikan kompor lalu beri taburan bawang goreng.Sajikan pindah kedalam mangkok/wadah lainnya"
categories:
- Resep
tags:
- kari
- ayam
- tahu

katakunci: kari ayam tahu 
nutrition: 149 calories
recipecuisine: Indonesian
preptime: "PT35M"
cooktime: "PT56M"
recipeyield: "4"
recipecategory: Dessert

---


![Kari Ayam Tahu](https://img-global.cpcdn.com/recipes/d5516cf9997785f1/680x482cq70/kari-ayam-tahu-foto-resep-utama.jpg)

Apabila kamu seorang orang tua, menyajikan hidangan lezat bagi keluarga tercinta adalah hal yang mengasyikan untuk kita sendiri. Tugas seorang istri Tidak sekedar mengerjakan pekerjaan rumah saja, tetapi kamu pun harus menyediakan keperluan nutrisi tercukupi dan juga hidangan yang dikonsumsi keluarga tercinta harus lezat.

Di era  sekarang, kamu memang mampu membeli olahan siap saji tidak harus capek memasaknya terlebih dahulu. Tapi banyak juga lho orang yang selalu mau memberikan makanan yang terenak untuk keluarganya. Lantaran, memasak sendiri jauh lebih bersih dan bisa menyesuaikan masakan tersebut berdasarkan kesukaan orang tercinta. 



Mungkinkah kamu seorang penyuka kari ayam tahu?. Asal kamu tahu, kari ayam tahu merupakan sajian khas di Nusantara yang sekarang disenangi oleh banyak orang dari hampir setiap wilayah di Nusantara. Anda dapat membuat kari ayam tahu sendiri di rumahmu dan boleh dijadikan camilan kesenanganmu di akhir pekanmu.

Kita jangan bingung jika kamu ingin mendapatkan kari ayam tahu, karena kari ayam tahu mudah untuk dicari dan juga kamu pun bisa menghidangkannya sendiri di tempatmu. kari ayam tahu dapat dimasak lewat beragam cara. Kini telah banyak sekali cara kekinian yang menjadikan kari ayam tahu lebih mantap.

Resep kari ayam tahu juga mudah sekali untuk dibikin, lho. Kita jangan capek-capek untuk memesan kari ayam tahu, lantaran Anda mampu menyajikan di rumahmu. Bagi Kamu yang hendak membuatnya, berikut cara membuat kari ayam tahu yang nikamat yang mampu Kamu coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Kari Ayam Tahu:

1. Ambil 1/2 Kg Ayam
1. Gunakan  Tahu matang
1. Ambil  Bawang Merah
1. Sediakan  Bawang Putih
1. Ambil 1 ruas kunyit
1. Ambil 1 ruas lengkuas geprek
1. Ambil 1 batang serai geprek
1. Ambil  Daun jeruk
1. Ambil  Daun salam
1. Gunakan  Jinten
1. Siapkan  Kemiri
1. Gunakan  Merica
1. Siapkan  Ketumbar
1. Siapkan  Garam
1. Gunakan  Masako optional tes rasa bila kurang asin
1. Siapkan 2 bungkus santan kara
1. Siapkan  Bawang goreng
1. Siapkan  Minyak goreng untuk menumis bumbu




<!--inarticleads2-->

##### Cara menyiapkan Kari Ayam Tahu:

1. Potong ayam menjadi beberapa bagian kemudian cuci bersih ayam
1. Didihkan air kemudian rebus ayam yang sudah dicuci bersih sampai air surut. Setelah itu buang air hasil rebusan tadi dan tambahkan air kedalam panci untuk direbus ulang untuk step ini air jangan dibuang ya bun
1. Kemudian ulek bumbu yang sudah disiapkan sampai halus (bisa juga diblender)
1. Setelah itu tumis bumbu yang sudah dihaluskan, kemudian masukkan daun jeruk daun salam serai dan lengkuas yang sudah digeprek. Tumis hingga harum
1. Langkah terakhir masukkan tumisan bumbu kedalam panci yang berisi ayam dan tambahkan 2 bungkus santan kara. - Aduk2 hingga benar2 matang dan mulai tes rasa apabila dirasa sayur kurang asin. Matikan kompor lalu beri taburan bawang goreng.Sajikan pindah kedalam mangkok/wadah lainnya




Wah ternyata resep kari ayam tahu yang mantab simple ini gampang sekali ya! Semua orang dapat membuatnya. Cara buat kari ayam tahu Sesuai sekali buat anda yang baru belajar memasak maupun juga bagi kalian yang telah lihai dalam memasak.

Tertarik untuk mencoba membuat resep kari ayam tahu nikmat tidak ribet ini? Kalau kalian tertarik, ayo kamu segera menyiapkan peralatan dan bahan-bahannya, lalu buat deh Resep kari ayam tahu yang lezat dan tidak rumit ini. Sangat taidak sulit kan. 

Maka dari itu, daripada kita berlama-lama, hayo kita langsung buat resep kari ayam tahu ini. Pasti kalian tak akan nyesel membuat resep kari ayam tahu lezat tidak rumit ini! Selamat berkreasi dengan resep kari ayam tahu nikmat sederhana ini di tempat tinggal masing-masing,ya!.

