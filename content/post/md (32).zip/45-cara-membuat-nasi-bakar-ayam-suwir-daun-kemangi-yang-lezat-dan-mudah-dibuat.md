---
description: "Cara membuat Nasi Bakar Ayam Suwir Daun Kemangi yang lezat dan Mudah Dibuat"
title: "Cara membuat Nasi Bakar Ayam Suwir Daun Kemangi yang lezat dan Mudah Dibuat"
slug: 45-cara-membuat-nasi-bakar-ayam-suwir-daun-kemangi-yang-lezat-dan-mudah-dibuat
date: 2021-01-23T01:53:17.119Z
image: https://img-global.cpcdn.com/recipes/e12f64b57c81e434/680x482cq70/nasi-bakar-ayam-suwir-daun-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e12f64b57c81e434/680x482cq70/nasi-bakar-ayam-suwir-daun-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e12f64b57c81e434/680x482cq70/nasi-bakar-ayam-suwir-daun-kemangi-foto-resep-utama.jpg
author: Eugenia Harris
ratingvalue: 3.6
reviewcount: 4
recipeingredient:
- " Bumbu Nasi Bakar"
- "2 lembar daun jeruk"
- "3 lembar daun salam"
- "3 siung bawang merah"
- "2 siung bawang putih"
- "1/4 sdt garam"
- "1 batang serai"
- "200 gr beras"
- " Air kaldu dari sisa rebusan 700 ml air dan ayam"
- " Bahan Ayam Suwir"
- "130 gr ayam rebus  suwir"
- "Secukupnya daun kemangi"
- "2 buah cabai merah iris"
- "3 lembar daun jeruk"
- "40 gr gula merah"
- "1/2 sdt garam"
- "50-100 ml air"
- " Bumbu Halus"
- "6-7 siung bawang merah"
- "3 siung bawang putih"
- "3 buah cabai merah"
- "5 buah cabai rawit"
- "2-3 sdm air"
recipeinstructions:
- "Rebus air dan ayam. Sisihkan airnya dan ambil ayam kemudian suwir. Sisihkan."
- "Sangrai bumbu halus dengan api kecil hingga harum lalu masukkan daun jeruk dan irisan cabai merah. Tuang air dan bumbui. Koreksi rasa."
- "Masukkan ayam dan daun kemangi. Aduk hingga rata. Sisihkan."
- "Masak beras, air kaldu dan bumbu hingga setengah matang kemudian kukus hingga matang."
- "Siapkan lidi dan daun pisang. Ambil secukupnya nasi dan ayam suwir lalu rekatkan dengan lidi."
- "Siapkan panggangan dan panggang hingga daun pisang kering."
- "Sajikan."
categories:
- Resep
tags:
- nasi
- bakar
- ayam

katakunci: nasi bakar ayam 
nutrition: 185 calories
recipecuisine: Indonesian
preptime: "PT32M"
cooktime: "PT42M"
recipeyield: "2"
recipecategory: Dinner

---


![Nasi Bakar Ayam Suwir Daun Kemangi](https://img-global.cpcdn.com/recipes/e12f64b57c81e434/680x482cq70/nasi-bakar-ayam-suwir-daun-kemangi-foto-resep-utama.jpg)

Selaku seorang ibu, menyuguhkan masakan mantab untuk orang tercinta merupakan hal yang membahagiakan bagi kamu sendiri. Kewajiban seorang  wanita Tidak cuman menangani rumah saja, tapi kamu juga wajib memastikan kebutuhan nutrisi tercukupi dan santapan yang dimakan keluarga tercinta mesti menggugah selera.

Di masa  sekarang, kita sebenarnya bisa mengorder masakan praktis walaupun tidak harus ribet membuatnya dulu. Tapi banyak juga lho mereka yang selalu mau menghidangkan yang terbaik bagi orang tercintanya. Karena, memasak yang dibuat sendiri akan jauh lebih higienis dan bisa menyesuaikan makanan tersebut sesuai dengan makanan kesukaan orang tercinta. 



Mungkinkah anda adalah seorang penikmat nasi bakar ayam suwir daun kemangi?. Asal kamu tahu, nasi bakar ayam suwir daun kemangi adalah hidangan khas di Nusantara yang saat ini disenangi oleh kebanyakan orang di berbagai wilayah di Nusantara. Anda dapat membuat nasi bakar ayam suwir daun kemangi sendiri di rumahmu dan boleh dijadikan camilan kesenanganmu di akhir pekan.

Kamu tak perlu bingung jika kamu ingin menyantap nasi bakar ayam suwir daun kemangi, karena nasi bakar ayam suwir daun kemangi tidak sukar untuk didapatkan dan anda pun dapat menghidangkannya sendiri di rumah. nasi bakar ayam suwir daun kemangi boleh dimasak memalui berbagai cara. Kini ada banyak sekali resep modern yang menjadikan nasi bakar ayam suwir daun kemangi semakin lezat.

Resep nasi bakar ayam suwir daun kemangi pun mudah dihidangkan, lho. Kalian tidak usah ribet-ribet untuk memesan nasi bakar ayam suwir daun kemangi, karena Anda dapat membuatnya di rumah sendiri. Bagi Kita yang mau menyajikannya, dibawah ini merupakan cara menyajikan nasi bakar ayam suwir daun kemangi yang mantab yang dapat Anda coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Nasi Bakar Ayam Suwir Daun Kemangi:

1. Siapkan  Bumbu Nasi Bakar
1. Siapkan 2 lembar daun jeruk
1. Siapkan 3 lembar daun salam
1. Ambil 3 siung bawang merah
1. Siapkan 2 siung bawang putih
1. Sediakan 1/4 sdt garam
1. Siapkan 1 batang serai
1. Ambil 200 gr beras
1. Ambil  Air kaldu dari sisa rebusan 700 ml air dan ayam
1. Siapkan  Bahan Ayam Suwir
1. Sediakan 130 gr ayam (rebus + suwir)
1. Siapkan Secukupnya daun kemangi
1. Gunakan 2 buah cabai merah (iris)
1. Ambil 3 lembar daun jeruk
1. Ambil 40 gr gula merah
1. Ambil 1/2 sdt garam
1. Ambil 50-100 ml air
1. Ambil  Bumbu Halus
1. Sediakan 6-7 siung bawang merah
1. Gunakan 3 siung bawang putih
1. Gunakan 3 buah cabai merah
1. Sediakan 5 buah cabai rawit
1. Gunakan 2-3 sdm air




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Nasi Bakar Ayam Suwir Daun Kemangi:

1. Rebus air dan ayam. Sisihkan airnya dan ambil ayam kemudian suwir. Sisihkan.
1. Sangrai bumbu halus dengan api kecil hingga harum lalu masukkan daun jeruk dan irisan cabai merah. Tuang air dan bumbui. Koreksi rasa.
1. Masukkan ayam dan daun kemangi. Aduk hingga rata. Sisihkan.
1. Masak beras, air kaldu dan bumbu hingga setengah matang kemudian kukus hingga matang.
1. Siapkan lidi dan daun pisang. Ambil secukupnya nasi dan ayam suwir lalu rekatkan dengan lidi.
1. Siapkan panggangan dan panggang hingga daun pisang kering.
1. Sajikan.




Ternyata cara buat nasi bakar ayam suwir daun kemangi yang lezat sederhana ini mudah sekali ya! Kalian semua bisa membuatnya. Resep nasi bakar ayam suwir daun kemangi Cocok sekali buat kita yang baru akan belajar memasak maupun bagi kamu yang telah lihai memasak.

Tertarik untuk mencoba membuat resep nasi bakar ayam suwir daun kemangi enak tidak rumit ini? Kalau kalian ingin, ayo kamu segera menyiapkan alat dan bahan-bahannya, lantas bikin deh Resep nasi bakar ayam suwir daun kemangi yang nikmat dan tidak ribet ini. Benar-benar mudah kan. 

Maka dari itu, daripada kalian berlama-lama, hayo kita langsung saja buat resep nasi bakar ayam suwir daun kemangi ini. Dijamin kamu tak akan nyesel sudah buat resep nasi bakar ayam suwir daun kemangi nikmat tidak rumit ini! Selamat mencoba dengan resep nasi bakar ayam suwir daun kemangi lezat tidak rumit ini di tempat tinggal kalian masing-masing,oke!.

