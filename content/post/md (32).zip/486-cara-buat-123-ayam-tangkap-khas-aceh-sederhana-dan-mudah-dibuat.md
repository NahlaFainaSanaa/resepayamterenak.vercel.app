---
description: "Cara buat 123. Ayam Tangkap khas Aceh Sederhana dan Mudah Dibuat"
title: "Cara buat 123. Ayam Tangkap khas Aceh Sederhana dan Mudah Dibuat"
slug: 486-cara-buat-123-ayam-tangkap-khas-aceh-sederhana-dan-mudah-dibuat
date: 2021-03-10T11:33:23.227Z
image: https://img-global.cpcdn.com/recipes/bda5c614a79824d4/680x482cq70/123-ayam-tangkap-khas-aceh-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/bda5c614a79824d4/680x482cq70/123-ayam-tangkap-khas-aceh-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/bda5c614a79824d4/680x482cq70/123-ayam-tangkap-khas-aceh-foto-resep-utama.jpg
author: Rachel Grant
ratingvalue: 3.7
reviewcount: 4
recipeingredient:
- "1 ekor  700 g ayam kampung"
- "2 batang serai memarkan"
- "6 lembar daun jeruk buang tulang daunnya"
- "500 ml air kelapa"
- "200 ml air"
- " minyak untuk menggoreng"
- " Bumbu Halus "
- "100 g bawang merah"
- "8 siung bawang putih"
- "4 cm jahe"
- "4 cm kunyit"
- "1/2-1 sdt merica"
- "1 1/2 sdt garam"
- "1 sdm air asam jawa"
- "1 sdm gula merah"
- " Bahan Kasar "
- "125 g bawang merah iris tipis"
- "8 siung bawang putih iris tipis"
- "2 lembar daun pandan iris ukuran 2 cm"
- "2 tangkai daun salam koja petik daunnya"
- "5 buah cabai hijau belah dua memanjang me cabe merah"
- "4 batang daun bawang iris ukuran 3 cm"
- "3 lembar daun kunyit iris  cm"
- "4 batang serai memarkan"
recipeinstructions:
- "Potong-potong kecil ayam beserta tulangnya ukuran 3 cm. Campur potongan ayam dengan bumbu halus, aduk rata, diamkan selama ± 30 menit agar bumbu meresap."
- "Taruh ayam berikut bumbunya dalam wajan, masukkan serai dan daun jeruk. Tuangi air kelapa dan air, jerang di atas api, masak hingga mendidih. Kecilkan apinya, tutup wajan, masak terus hingga airnya mengering dan ayam empuk."
- "Panaskan minyak goreng yang banyak dalam wajan di atas api sedang. Goreng masing-masing bumbu kasar secara terpisah, aduk-aduk hingga masing-masing bumbu matang dan kering, angkat. Campur jadi satu semua bumbu kasar yang sudah digoreng tadi, sisihkan."
- "Panaskan kembali bekas menggoreng bumbu, masukkan setengah bagian ayam ungkep. Goreng sambil diaduk-aduk hingga ayam kering, angkat, tiriskan. Lakukan hal yang sama untuk sisa ayam."
- "Taruh ayam goreng dan bumbu kasar goreng dalam wadah, aduk rata, hidangkan."
categories:
- Resep
tags:
- 123
- ayam
- tangkap

katakunci: 123 ayam tangkap 
nutrition: 264 calories
recipecuisine: Indonesian
preptime: "PT32M"
cooktime: "PT49M"
recipeyield: "1"
recipecategory: Dinner

---


![123. Ayam Tangkap khas Aceh](https://img-global.cpcdn.com/recipes/bda5c614a79824d4/680x482cq70/123-ayam-tangkap-khas-aceh-foto-resep-utama.jpg)

Apabila kamu seorang istri, menyuguhkan hidangan nikmat bagi orang tercinta adalah suatu hal yang membahagiakan bagi kamu sendiri. Tugas seorang  wanita Tidak cuma menjaga rumah saja, tapi anda pun wajib menyediakan keperluan gizi terpenuhi dan masakan yang dikonsumsi anak-anak wajib nikmat.

Di waktu  saat ini, anda memang mampu mengorder santapan jadi walaupun tanpa harus ribet mengolahnya terlebih dahulu. Namun ada juga lho orang yang selalu mau memberikan hidangan yang terenak bagi orang tercintanya. Sebab, menghidangkan masakan sendiri jauh lebih bersih dan kita pun bisa menyesuaikan makanan tersebut sesuai dengan selera famili. 



Apakah anda adalah salah satu penggemar 123. ayam tangkap khas aceh?. Asal kamu tahu, 123. ayam tangkap khas aceh adalah makanan khas di Indonesia yang saat ini disukai oleh setiap orang dari berbagai wilayah di Indonesia. Anda dapat memasak 123. ayam tangkap khas aceh sendiri di rumah dan boleh jadi makanan kesukaanmu di akhir pekan.

Kalian tidak usah bingung untuk memakan 123. ayam tangkap khas aceh, lantaran 123. ayam tangkap khas aceh mudah untuk didapatkan dan juga kamu pun boleh mengolahnya sendiri di tempatmu. 123. ayam tangkap khas aceh boleh dimasak dengan beraneka cara. Kini ada banyak cara modern yang membuat 123. ayam tangkap khas aceh semakin nikmat.

Resep 123. ayam tangkap khas aceh juga gampang untuk dibuat, lho. Kita tidak usah repot-repot untuk memesan 123. ayam tangkap khas aceh, karena Kita dapat membuatnya ditempatmu. Bagi Kamu yang mau menyajikannya, berikut resep untuk menyajikan 123. ayam tangkap khas aceh yang mantab yang bisa Kalian buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan 123. Ayam Tangkap khas Aceh:

1. Siapkan 1 ekor (± 700 g) ayam kampung
1. Sediakan 2 batang serai, memarkan
1. Gunakan 6 lembar daun jeruk, buang tulang daunnya
1. Siapkan 500 ml air kelapa
1. Gunakan 200 ml air
1. Siapkan  minyak untuk menggoreng
1. Ambil  Bumbu Halus :
1. Sediakan 100 g bawang merah
1. Gunakan 8 siung bawang putih
1. Gunakan 4 cm jahe
1. Ambil 4 cm kunyit
1. Sediakan 1/2-1 sdt merica
1. Ambil 1 1/2 sdt garam
1. Gunakan 1 sdm air asam jawa
1. Sediakan 1 sdm gula merah
1. Ambil  Bahan Kasar :
1. Gunakan 125 g bawang merah, iris tipis
1. Sediakan 8 siung bawang putih, iris tipis
1. Gunakan 2 lembar daun pandan, iris ukuran 2 cm
1. Sediakan 2 tangkai daun salam koja, petik daunnya
1. Siapkan 5 buah cabai hijau, belah dua memanjang (me: cabe merah)
1. Ambil 4 batang daun bawang, iris ukuran 3 cm
1. Sediakan 3 lembar daun kunyit, iris ½ cm
1. Sediakan 4 batang serai, memarkan




<!--inarticleads2-->

##### Cara membuat 123. Ayam Tangkap khas Aceh:

1. Potong-potong kecil ayam beserta tulangnya ukuran 3 cm. Campur potongan ayam dengan bumbu halus, aduk rata, diamkan selama ± 30 menit agar bumbu meresap.
1. Taruh ayam berikut bumbunya dalam wajan, masukkan serai dan daun jeruk. Tuangi air kelapa dan air, jerang di atas api, masak hingga mendidih. Kecilkan apinya, tutup wajan, masak terus hingga airnya mengering dan ayam empuk.
1. Panaskan minyak goreng yang banyak dalam wajan di atas api sedang. Goreng masing-masing bumbu kasar secara terpisah, aduk-aduk hingga masing-masing bumbu matang dan kering, angkat. Campur jadi satu semua bumbu kasar yang sudah digoreng tadi, sisihkan.
1. Panaskan kembali bekas menggoreng bumbu, masukkan setengah bagian ayam ungkep. Goreng sambil diaduk-aduk hingga ayam kering, angkat, tiriskan. Lakukan hal yang sama untuk sisa ayam.
1. Taruh ayam goreng dan bumbu kasar goreng dalam wadah, aduk rata, hidangkan.




Wah ternyata cara membuat 123. ayam tangkap khas aceh yang mantab simple ini mudah banget ya! Semua orang bisa membuatnya. Cara buat 123. ayam tangkap khas aceh Sangat sesuai banget buat kalian yang baru akan belajar memasak maupun juga untuk kamu yang sudah jago dalam memasak.

Apakah kamu ingin mencoba buat resep 123. ayam tangkap khas aceh mantab simple ini? Kalau anda mau, yuk kita segera buruan siapin peralatan dan bahannya, lantas buat deh Resep 123. ayam tangkap khas aceh yang lezat dan sederhana ini. Benar-benar taidak sulit kan. 

Oleh karena itu, ketimbang kamu berlama-lama, yuk kita langsung buat resep 123. ayam tangkap khas aceh ini. Dijamin kamu gak akan nyesel sudah bikin resep 123. ayam tangkap khas aceh nikmat tidak ribet ini! Selamat berkreasi dengan resep 123. ayam tangkap khas aceh nikmat tidak rumit ini di tempat tinggal sendiri,oke!.

