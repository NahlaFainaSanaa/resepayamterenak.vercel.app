---
description: "Cara membuat Lontong Kari Ayam yang lezat dan Mudah Dibuat"
title: "Cara membuat Lontong Kari Ayam yang lezat dan Mudah Dibuat"
slug: 436-cara-membuat-lontong-kari-ayam-yang-lezat-dan-mudah-dibuat
date: 2021-05-20T20:05:13.861Z
image: https://img-global.cpcdn.com/recipes/c618a8dd19a9a9b4/680x482cq70/lontong-kari-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c618a8dd19a9a9b4/680x482cq70/lontong-kari-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c618a8dd19a9a9b4/680x482cq70/lontong-kari-ayam-foto-resep-utama.jpg
author: Tillie Richardson
ratingvalue: 4.1
reviewcount: 14
recipeingredient:
- " Bahan lontong"
- "3 cup beras"
- "Plastik tahan panas"
- " Bahan kari"
- "1/2 kg ayam"
- "1 1/2 ruas jari lengkuas memarkan"
- "1 1/2 luas jari jahe memarkan"
- "3 lembar daun salam"
- "4 lembar daun jeruk"
- "2 batang serai memarkan"
- "90 ml santan instan"
- "Secukupnya air"
- "1 sdt gula merah sisir"
- " Garam merica kaldu bubuk gula pasir"
- " Bumbu halus"
- "7 siung bawang merah"
- "5 siung bawang putih"
- "4 buah cabe merah besar buang bijinya"
- "4 butir kemiri"
- "1 sdt ketumbar"
- "1 sdt jinten"
- " Pelengkap"
- " Telur rebus"
- " Emping"
- " Kacang kedelai goreng"
- " Bawang goreng"
- " Kecap manis"
- " Jeruk limau"
recipeinstructions:
- "Buat lontong terlebih dahulu :"
- "Cuci bersih beras &amp; rendam selama 30 menit. Tiriskan"
- "Masukkan ke dalam plastik tahan panas sebanyak 1/2 lebih sedikit dari volume plastik. Seal / rekatkan plastik. Tusuk2 dengan bantuan tusuk sate/garpu supaya air dapat masuk"
- "Didihkan secukupnya air. Rebus beras selama 20 menit atau sampai lontong matang &amp; padat. Tunggu dingin &amp; menjadi set. Sisihkan"
- "Buat kari :"
- "Didihkan air dalam panci. masukkan ayam yang sudah dicuci bersih &amp; tambahkan garam. Rebus sampai ayam empuk"
- "Keluarkan ayam dari rebusan kaldu. Suwir2 &amp; sisihkan"
- "Tumis bumbu halus bersama daun salam, daun jeruk, jahe, lengkuas &amp; serai sampai harum"
- "Masukkan tumisan bumbu ke dalam panci rebusan kaldu. Aduk rata"
- "Tambahkan gula merah &amp; sisa bumbu. Terakhir tuang santan. Aduk rata &amp; koreksi rasa"
- "Penyajian: tata irisan lontong di piring saji. Tuang kuah kari, taburi ayam suir, kacang kedelai &amp; bawang goreng. Beri sedikit kecap manis. Lengkapai dengan telur rebus, jeruk limau &amp; emping"
categories:
- Resep
tags:
- lontong
- kari
- ayam

katakunci: lontong kari ayam 
nutrition: 142 calories
recipecuisine: Indonesian
preptime: "PT35M"
cooktime: "PT43M"
recipeyield: "2"
recipecategory: Dinner

---


![Lontong Kari Ayam](https://img-global.cpcdn.com/recipes/c618a8dd19a9a9b4/680x482cq70/lontong-kari-ayam-foto-resep-utama.jpg)

Andai kamu seorang istri, menyediakan santapan menggugah selera pada orang tercinta adalah suatu hal yang sangat menyenangkan untuk kamu sendiri. Peran seorang istri bukan sekedar mengurus rumah saja, tetapi anda pun harus memastikan kebutuhan nutrisi terpenuhi dan santapan yang dikonsumsi orang tercinta harus sedap.

Di masa  sekarang, kamu memang dapat membeli masakan instan tidak harus ribet membuatnya dahulu. Tetapi ada juga orang yang memang mau menghidangkan yang terlezat bagi orang yang dicintainya. Lantaran, memasak yang dibuat sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan hidangan tersebut sesuai dengan masakan kesukaan keluarga. 



Apakah anda merupakan seorang penggemar lontong kari ayam?. Asal kamu tahu, lontong kari ayam adalah hidangan khas di Nusantara yang saat ini digemari oleh kebanyakan orang di berbagai daerah di Indonesia. Anda bisa membuat lontong kari ayam kreasi sendiri di rumah dan boleh jadi makanan kesukaanmu di hari libur.

Anda jangan bingung jika kamu ingin menyantap lontong kari ayam, sebab lontong kari ayam mudah untuk dicari dan juga kalian pun dapat menghidangkannya sendiri di tempatmu. lontong kari ayam bisa diolah dengan beragam cara. Kini pun telah banyak cara kekinian yang menjadikan lontong kari ayam semakin mantap.

Resep lontong kari ayam pun mudah untuk dibuat, lho. Kamu tidak perlu ribet-ribet untuk memesan lontong kari ayam, tetapi Anda bisa menghidangkan di rumah sendiri. Bagi Anda yang mau membuatnya, berikut ini cara untuk membuat lontong kari ayam yang lezat yang dapat Kalian coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Lontong Kari Ayam:

1. Siapkan  Bahan lontong
1. Ambil 3 cup beras
1. Siapkan Plastik tahan panas
1. Sediakan  Bahan kari
1. Ambil 1/2 kg ayam
1. Sediakan 1 1/2 ruas jari lengkuas, memarkan
1. Gunakan 1 1/2 luas jari jahe, memarkan
1. Sediakan 3 lembar daun salam
1. Ambil 4 lembar daun jeruk
1. Siapkan 2 batang serai, memarkan
1. Gunakan 90 ml santan instan
1. Sediakan Secukupnya air
1. Ambil 1 sdt gula merah, sisir
1. Sediakan  Garam, merica, kaldu bubuk, gula pasir
1. Siapkan  Bumbu halus
1. Sediakan 7 siung bawang merah
1. Gunakan 5 siung bawang putih
1. Gunakan 4 buah cabe merah besar, buang bijinya
1. Sediakan 4 butir kemiri
1. Siapkan 1 sdt ketumbar
1. Gunakan 1 sdt jinten
1. Ambil  Pelengkap
1. Siapkan  Telur rebus,
1. Gunakan  Emping
1. Ambil  Kacang kedelai goreng
1. Sediakan  Bawang goreng
1. Siapkan  Kecap manis
1. Siapkan  Jeruk limau




<!--inarticleads2-->

##### Cara membuat Lontong Kari Ayam:

1. Buat lontong terlebih dahulu :
1. Cuci bersih beras &amp; rendam selama 30 menit. Tiriskan
1. Masukkan ke dalam plastik tahan panas sebanyak 1/2 lebih sedikit dari volume plastik. Seal / rekatkan plastik. Tusuk2 dengan bantuan tusuk sate/garpu supaya air dapat masuk
1. Didihkan secukupnya air. Rebus beras selama 20 menit atau sampai lontong matang &amp; padat. Tunggu dingin &amp; menjadi set. Sisihkan
1. Buat kari :
1. Didihkan air dalam panci. masukkan ayam yang sudah dicuci bersih &amp; tambahkan garam. Rebus sampai ayam empuk
1. Keluarkan ayam dari rebusan kaldu. Suwir2 &amp; sisihkan
1. Tumis bumbu halus bersama daun salam, daun jeruk, jahe, lengkuas &amp; serai sampai harum
1. Masukkan tumisan bumbu ke dalam panci rebusan kaldu. Aduk rata
1. Tambahkan gula merah &amp; sisa bumbu. Terakhir tuang santan. Aduk rata &amp; koreksi rasa
1. Penyajian: tata irisan lontong di piring saji. Tuang kuah kari, taburi ayam suir, kacang kedelai &amp; bawang goreng. Beri sedikit kecap manis. Lengkapai dengan telur rebus, jeruk limau &amp; emping




Wah ternyata resep lontong kari ayam yang enak tidak rumit ini mudah banget ya! Anda Semua mampu mencobanya. Resep lontong kari ayam Sesuai sekali untuk kamu yang sedang belajar memasak ataupun juga untuk anda yang sudah jago memasak.

Apakah kamu mau mulai mencoba membikin resep lontong kari ayam enak simple ini? Kalau anda ingin, ayo kamu segera siapkan alat dan bahan-bahannya, kemudian buat deh Resep lontong kari ayam yang lezat dan sederhana ini. Sangat gampang kan. 

Oleh karena itu, ketimbang kalian berlama-lama, ayo langsung aja sajikan resep lontong kari ayam ini. Dijamin anda tiidak akan menyesal sudah bikin resep lontong kari ayam enak tidak rumit ini! Selamat berkreasi dengan resep lontong kari ayam mantab simple ini di tempat tinggal kalian masing-masing,oke!.

