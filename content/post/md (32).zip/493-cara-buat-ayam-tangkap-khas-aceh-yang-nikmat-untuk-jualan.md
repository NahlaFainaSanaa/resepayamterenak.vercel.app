---
description: "Cara buat Ayam Tangkap Khas Aceh yang nikmat Untuk Jualan"
title: "Cara buat Ayam Tangkap Khas Aceh yang nikmat Untuk Jualan"
slug: 493-cara-buat-ayam-tangkap-khas-aceh-yang-nikmat-untuk-jualan
date: 2021-03-13T16:38:50.906Z
image: https://img-global.cpcdn.com/recipes/e7a0a83a5ac34c83/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e7a0a83a5ac34c83/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e7a0a83a5ac34c83/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg
author: Rhoda Miller
ratingvalue: 4.5
reviewcount: 10
recipeingredient:
- "1/2 ekor ayam sekitar 500 gram"
- "1/2 potong jeruk nipis"
- "1 1/2 sdt garam"
- "1 sdt gula"
- "secukupnya Minyak goreng"
- " Bumbu halus"
- "7 siung bawang merah"
- "3 siung bawang putih"
- "1 ruas jahe"
- "1 ruas kunyit"
- "1 sdt ketumbar bubuk"
- "1/2 sdt lada bubuk"
- "3 buah asam sunti belimbing wuluh yang dikeringkan"
- " Daundaun rempah"
- "6-7 tangkai daun temuru daun karisalam koja"
- "3 lembar daun pandan"
- "1 lembar daun kunyit"
- "1 batang serai diambil batang putihnya"
- "5 siung bawang merah"
- "Secukupnya cabe hijau"
recipeinstructions:
- "Potong ayam dengan ukuran kecil-kecil, tapi tidak terlalu kecil. Cuci bersih kemudian lumuri dengan jeruk nipis dan garam. Sisihkan"
- "Siapkan bumbu halus. Haluskan dengan blender. Kemudian masukan bumbu halus ke dalam ayam yang sudah dibaluri dengan jeruk nipis dan garam. Aduk-aduk bumbu hingga merata. Tambahkan gula dan aduk-aduk lagi. Tutup wadah, dan simpan di lemari es selama lebih kurang 1 jam. (Kalau menggunakan ayam kampung, lebih baik ayamnya diungkap terlebih dahulu. Terus kalau ga ada asam sunti, bisa diganti dengan air asam jawa, atau boleh diskip.)"
- "Sambil menunggu ayam dimarinasi, siapkan daun-daun rempah. Iris bawang dan serai. Petik daun temuru dari tangkainya, gunting kecil-kecil daun pandan dan daun kunyit. Sisihkan"
- "Setelah satu jam, panaskan minyak goreng. Keluarkan ayam dari kulkas. Setelah minyak panas goreng ayam hingga hampir matang atau hampir kecoklatan seluruh bagiannya."
- "Setelah itu, masukan bawang dan serai. Goreng bawang hingga hampir coklat, tapi belum kecoklatan ya. Kemudian masukan daun temuru, daun pandan dan daun kunyit, serta cabai. Goreng hingga ayam matang keseluruhan sambil diaduk-aduk saat menggorengnya. Kalau sudah matang matikan kompor, kemudian angkat ayam bersama rempah daunnya sambil ditiriskan. Saya suka goreng daunnya sebelum ayam matang karena wangi dan rasa ayamnya akan berbeda. Kalau moms mau goreng daunnya secara terpisah boleh saja ya."
- "Goreng ayam hingga habis. Tadi saya gorengnya dua kali, jadi ayam dan rempah daunnya dibagi dua. Setelah matang ayam goreng siap disajikan selagi hangat."
- "Paling enak makannya bersama nasi hangat, dan sambal. Tadi saya buat sambal kecap kesukaan anak-anak. Moms boleh ganti sambal apa aja ya yang disukai."
- "Selamat mencoba 😍"
categories:
- Resep
tags:
- ayam
- tangkap
- khas

katakunci: ayam tangkap khas 
nutrition: 249 calories
recipecuisine: Indonesian
preptime: "PT12M"
cooktime: "PT54M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Tangkap Khas Aceh](https://img-global.cpcdn.com/recipes/e7a0a83a5ac34c83/680x482cq70/ayam-tangkap-khas-aceh-foto-resep-utama.jpg)

Selaku seorang yang hobi memasak, menyajikan panganan nikmat untuk keluarga merupakan hal yang menyenangkan bagi kita sendiri. Peran seorang  wanita Tidak sekedar menjaga rumah saja, tetapi kamu pun harus memastikan kebutuhan nutrisi terpenuhi dan juga olahan yang disantap keluarga tercinta wajib nikmat.

Di era  saat ini, anda sebenarnya bisa membeli olahan yang sudah jadi tidak harus capek membuatnya dulu. Tapi banyak juga mereka yang selalu ingin memberikan makanan yang terenak bagi orang tercintanya. Karena, menyajikan masakan yang diolah sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan makanan tersebut sesuai dengan makanan kesukaan keluarga. 



Mungkinkah anda seorang penggemar ayam tangkap khas aceh?. Asal kamu tahu, ayam tangkap khas aceh adalah makanan khas di Indonesia yang saat ini disukai oleh orang-orang dari berbagai tempat di Indonesia. Kita dapat menghidangkan ayam tangkap khas aceh sendiri di rumahmu dan dapat dijadikan camilan favorit di hari libur.

Anda jangan bingung untuk menyantap ayam tangkap khas aceh, karena ayam tangkap khas aceh sangat mudah untuk didapatkan dan juga anda pun bisa menghidangkannya sendiri di tempatmu. ayam tangkap khas aceh dapat diolah dengan berbagai cara. Kini telah banyak sekali resep kekinian yang membuat ayam tangkap khas aceh lebih enak.

Resep ayam tangkap khas aceh juga mudah dibuat, lho. Kalian tidak usah ribet-ribet untuk membeli ayam tangkap khas aceh, sebab Kalian dapat menyajikan ditempatmu. Bagi Kita yang akan mencobanya, inilah resep untuk menyajikan ayam tangkap khas aceh yang nikamat yang dapat Kita hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Ayam Tangkap Khas Aceh:

1. Siapkan 1/2 ekor ayam sekitar 500 gram
1. Siapkan 1/2 potong jeruk nipis
1. Gunakan 1 1/2 sdt garam
1. Sediakan 1 sdt gula
1. Sediakan secukupnya Minyak goreng
1. Sediakan  Bumbu halus
1. Gunakan 7 siung bawang merah
1. Siapkan 3 siung bawang putih
1. Gunakan 1 ruas jahe
1. Gunakan 1 ruas kunyit
1. Ambil 1 sdt ketumbar bubuk
1. Sediakan 1/2 sdt lada bubuk
1. Siapkan 3 buah asam sunti (belimbing wuluh yang dikeringkan)
1. Sediakan  Daun-daun rempah
1. Siapkan 6-7 tangkai daun temuru (daun kari/salam koja)
1. Ambil 3 lembar daun pandan
1. Sediakan 1 lembar daun kunyit
1. Siapkan 1 batang serai diambil batang putihnya
1. Sediakan 5 siung bawang merah
1. Gunakan Secukupnya cabe hijau




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Tangkap Khas Aceh:

1. Potong ayam dengan ukuran kecil-kecil, tapi tidak terlalu kecil. Cuci bersih kemudian lumuri dengan jeruk nipis dan garam. Sisihkan
1. Siapkan bumbu halus. Haluskan dengan blender. Kemudian masukan bumbu halus ke dalam ayam yang sudah dibaluri dengan jeruk nipis dan garam. Aduk-aduk bumbu hingga merata. Tambahkan gula dan aduk-aduk lagi. Tutup wadah, dan simpan di lemari es selama lebih kurang 1 jam. (Kalau menggunakan ayam kampung, lebih baik ayamnya diungkap terlebih dahulu. Terus kalau ga ada asam sunti, bisa diganti dengan air asam jawa, atau boleh diskip.)
1. Sambil menunggu ayam dimarinasi, siapkan daun-daun rempah. Iris bawang dan serai. Petik daun temuru dari tangkainya, gunting kecil-kecil daun pandan dan daun kunyit. Sisihkan
1. Setelah satu jam, panaskan minyak goreng. Keluarkan ayam dari kulkas. Setelah minyak panas goreng ayam hingga hampir matang atau hampir kecoklatan seluruh bagiannya.
1. Setelah itu, masukan bawang dan serai. Goreng bawang hingga hampir coklat, tapi belum kecoklatan ya. Kemudian masukan daun temuru, daun pandan dan daun kunyit, serta cabai. Goreng hingga ayam matang keseluruhan sambil diaduk-aduk saat menggorengnya. Kalau sudah matang matikan kompor, kemudian angkat ayam bersama rempah daunnya sambil ditiriskan. Saya suka goreng daunnya sebelum ayam matang karena wangi dan rasa ayamnya akan berbeda. Kalau moms mau goreng daunnya secara terpisah boleh saja ya.
1. Goreng ayam hingga habis. Tadi saya gorengnya dua kali, jadi ayam dan rempah daunnya dibagi dua. Setelah matang ayam goreng siap disajikan selagi hangat.
1. Paling enak makannya bersama nasi hangat, dan sambal. Tadi saya buat sambal kecap kesukaan anak-anak. Moms boleh ganti sambal apa aja ya yang disukai.
1. Selamat mencoba 😍




Ternyata cara buat ayam tangkap khas aceh yang nikamt sederhana ini gampang sekali ya! Anda Semua bisa membuatnya. Cara Membuat ayam tangkap khas aceh Sangat cocok sekali untuk kamu yang baru akan belajar memasak maupun juga bagi anda yang sudah hebat memasak.

Tertarik untuk mencoba membikin resep ayam tangkap khas aceh lezat simple ini? Kalau anda ingin, mending kamu segera buruan siapin peralatan dan bahan-bahannya, lantas bikin deh Resep ayam tangkap khas aceh yang nikmat dan tidak rumit ini. Betul-betul gampang kan. 

Maka, daripada anda berfikir lama-lama, hayo langsung aja sajikan resep ayam tangkap khas aceh ini. Dijamin anda tiidak akan nyesel sudah membuat resep ayam tangkap khas aceh lezat tidak ribet ini! Selamat mencoba dengan resep ayam tangkap khas aceh mantab simple ini di tempat tinggal sendiri,oke!.

