---
description: "Cara buat Ayam Woku yang lezat dan Mudah Dibuat"
title: "Cara buat Ayam Woku yang lezat dan Mudah Dibuat"
slug: 338-cara-buat-ayam-woku-yang-lezat-dan-mudah-dibuat
date: 2021-04-15T03:33:31.652Z
image: https://img-global.cpcdn.com/recipes/d574b4134770c6e7/680x482cq70/ayam-woku-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d574b4134770c6e7/680x482cq70/ayam-woku-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d574b4134770c6e7/680x482cq70/ayam-woku-foto-resep-utama.jpg
author: Zachary Mitchell
ratingvalue: 4.3
reviewcount: 6
recipeingredient:
- "1/2 ekor ayam"
- "1 ikat daun kemangi"
- " Bumbu Halus"
- "8-10 siung bawang merah"
- "4 siung bawang putih"
- "4 cabe rawit"
- "6 cabe merah keriting"
- "1 butir kemiri"
- " Bumbu utuh"
- "2 lembar daun salam"
- "2 batang sereh"
- "2 ruas lengkuas"
- "2 lembar daun jeruk"
- " Bumbu Penyedap"
- " Gula"
- " Garam"
- " Kaldu jamur"
- " Gula merah"
recipeinstructions:
- "Cuci bersih ayam lalu lumuri dengan air perasan jeruk nipis"
- "Goreng ayam sebentar agar tidak hancur saat dimasak dan sisa kotorannya hilang lalu tiriskan"
- "Tumis bumbu halus dan bumbu utuh yg digeprek sampai harum, lalu masukan ayam yg sudah digoreng tambahkan 500ml air dan bumbui dgn gula,garam,kaldu jamur, dan diamkan hingga airnya menyusut"
- "Jika airnya sudah mulai kering koreksi lagi rasanya jika sudah pas masukan daun kemangi dan aduk&#34; hingga daunnya layu lalu matikan api dan sajikan"
categories:
- Resep
tags:
- ayam
- woku

katakunci: ayam woku 
nutrition: 121 calories
recipecuisine: Indonesian
preptime: "PT14M"
cooktime: "PT43M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam Woku](https://img-global.cpcdn.com/recipes/d574b4134770c6e7/680x482cq70/ayam-woku-foto-resep-utama.jpg)

Selaku seorang orang tua, menyediakan santapan lezat kepada keluarga tercinta adalah suatu hal yang sangat menyenangkan bagi kita sendiri. Tanggung jawab seorang istri Tidak hanya mengatur rumah saja, namun anda pun wajib memastikan kebutuhan nutrisi tercukupi dan juga panganan yang disantap keluarga tercinta harus sedap.

Di era  sekarang, kita memang bisa mengorder santapan instan meski tanpa harus ribet memasaknya dahulu. Namun banyak juga orang yang selalu mau memberikan hidangan yang terlezat untuk orang yang dicintainya. Sebab, memasak yang dibuat sendiri jauh lebih higienis dan kita juga bisa menyesuaikan hidangan tersebut sesuai kesukaan keluarga. 



Apakah anda salah satu penggemar ayam woku?. Asal kamu tahu, ayam woku merupakan sajian khas di Nusantara yang sekarang digemari oleh kebanyakan orang dari berbagai wilayah di Nusantara. Kamu bisa menghidangkan ayam woku sendiri di rumahmu dan pasti jadi camilan favoritmu di hari liburmu.

Kita jangan bingung untuk mendapatkan ayam woku, lantaran ayam woku tidak sulit untuk dicari dan juga kita pun dapat membuatnya sendiri di tempatmu. ayam woku boleh dimasak dengan berbagai cara. Kini pun telah banyak resep modern yang menjadikan ayam woku semakin lebih mantap.

Resep ayam woku juga sangat gampang dibikin, lho. Kamu jangan repot-repot untuk membeli ayam woku, tetapi Kamu mampu menyiapkan sendiri di rumah. Untuk Kalian yang mau menyajikannya, berikut cara membuat ayam woku yang enak yang mampu Kita coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Ayam Woku:

1. Siapkan 1/2 ekor ayam
1. Siapkan 1 ikat daun kemangi
1. Sediakan  Bumbu Halus
1. Gunakan 8-10 siung bawang merah
1. Siapkan 4 siung bawang putih
1. Sediakan 4 cabe rawit
1. Siapkan 6 cabe merah keriting
1. Ambil 1 butir kemiri
1. Gunakan  Bumbu utuh
1. Sediakan 2 lembar daun salam
1. Ambil 2 batang sereh
1. Ambil 2 ruas lengkuas
1. Siapkan 2 lembar daun jeruk
1. Siapkan  Bumbu Penyedap
1. Siapkan  Gula
1. Gunakan  Garam
1. Gunakan  Kaldu jamur
1. Sediakan  Gula merah




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Woku:

1. Cuci bersih ayam lalu lumuri dengan air perasan jeruk nipis
1. Goreng ayam sebentar agar tidak hancur saat dimasak dan sisa kotorannya hilang lalu tiriskan
1. Tumis bumbu halus dan bumbu utuh yg digeprek sampai harum, lalu masukan ayam yg sudah digoreng tambahkan 500ml air dan bumbui dgn gula,garam,kaldu jamur, dan diamkan hingga airnya menyusut
1. Jika airnya sudah mulai kering koreksi lagi rasanya jika sudah pas masukan daun kemangi dan aduk&#34; hingga daunnya layu lalu matikan api dan sajikan




Ternyata cara membuat ayam woku yang nikamt sederhana ini mudah banget ya! Semua orang dapat membuatnya. Cara buat ayam woku Cocok sekali untuk anda yang baru belajar memasak ataupun juga untuk kamu yang sudah lihai dalam memasak.

Apakah kamu mau mencoba bikin resep ayam woku lezat tidak ribet ini? Kalau anda tertarik, mending kamu segera siapkan alat-alat dan bahan-bahannya, setelah itu buat deh Resep ayam woku yang lezat dan tidak ribet ini. Betul-betul gampang kan. 

Maka dari itu, ketimbang anda berfikir lama-lama, ayo langsung aja buat resep ayam woku ini. Pasti kamu tak akan nyesel bikin resep ayam woku lezat tidak ribet ini! Selamat mencoba dengan resep ayam woku lezat tidak ribet ini di tempat tinggal masing-masing,oke!.

