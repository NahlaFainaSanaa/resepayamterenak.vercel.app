---
description: "Bahan-bahan Lontong Kari Ayam yang nikmat Untuk Jualan"
title: "Bahan-bahan Lontong Kari Ayam yang nikmat Untuk Jualan"
slug: 365-bahan-bahan-lontong-kari-ayam-yang-nikmat-untuk-jualan
date: 2021-04-05T11:10:18.246Z
image: https://img-global.cpcdn.com/recipes/e2051f6422c7ffe6/680x482cq70/lontong-kari-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e2051f6422c7ffe6/680x482cq70/lontong-kari-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e2051f6422c7ffe6/680x482cq70/lontong-kari-ayam-foto-resep-utama.jpg
author: Terry Horton
ratingvalue: 3.1
reviewcount: 3
recipeingredient:
- " Lontong"
- "500 gr ayam"
- "1 buah wortel"
- "100 gr buncis"
- " Bumbu halus"
- "8 siung bawang merah"
- "6 siung bawang putih"
- "3 buah cabai merah besar"
- "2 ruas kunyit"
- "2 buah kemiri"
- "1 sdt ketumbar"
- " Bumbu lain"
- "2 ruas lengkuas"
- "1 ruas jahe"
- "1 batang serai"
- "2 lembar daun salam"
- "2 lembar daun jeruk"
- "100 ml santan"
- "secukupnya garam"
- "secukupnya gula pasir"
- "secukupnya merica"
- "secukupnya penyedap rasa ayan"
- " Bahan pelengkap"
- "secukupnya bawang goreng"
- "secukupnya cabai rawit utuh"
- " Optional"
- "1/2 papan tempe"
- "1 potong tahu"
- "10 butir telur puyuh matang"
recipeinstructions:
- "Potong ayam, wortel, buncis sesuai selera lalu cuci bersih. Rebus ayam 5 menit untuk membuang buih kotor, lalu cuci ayam kembali, sisihkan."
- "Ulek semua bumbu halus. Geprek lengkuas, jahe dan serai."
- "Panaskan minyak goreng lalu masukkan bumbu halus, bahan yang sudah digeprek dan daun salam serta daun jeruk. Tumis hingga wangi."
- "Tambahkan air lalu masukkan santan, garam, gula, merica dan penyedap rasa ayam (royko/masako). Aduk sesekali agar santan tidak pecah."
- "Masukkan ayam, wortel dan buncis. Beri tambahan bawang goreng dan rawit utuh jika suka."
- "Masak hingga kuah mulai surut, tes rasa. Potong-potong lontong, sajikan dengan kari."
- "Ps : anda dapat menambahkan bahan-bahan optional dan isian lainnya jika suka. 😊"
categories:
- Resep
tags:
- lontong
- kari
- ayam

katakunci: lontong kari ayam 
nutrition: 253 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT45M"
recipeyield: "1"
recipecategory: Dinner

---


![Lontong Kari Ayam](https://img-global.cpcdn.com/recipes/e2051f6422c7ffe6/680x482cq70/lontong-kari-ayam-foto-resep-utama.jpg)

Selaku seorang orang tua, mempersiapkan hidangan enak pada keluarga adalah suatu hal yang membahagiakan untuk anda sendiri. Kewajiban seorang  wanita Tidak saja menangani rumah saja, tetapi anda pun harus menyediakan kebutuhan nutrisi tercukupi dan juga panganan yang disantap anak-anak wajib mantab.

Di era  saat ini, anda memang dapat mengorder masakan jadi walaupun tidak harus capek membuatnya dulu. Namun banyak juga lho mereka yang selalu mau menyajikan yang terbaik bagi keluarganya. Pasalnya, menyajikan masakan sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan berdasarkan kesukaan orang tercinta. 



Mungkinkah anda adalah salah satu penyuka lontong kari ayam?. Asal kamu tahu, lontong kari ayam merupakan makanan khas di Indonesia yang kini digemari oleh orang-orang dari berbagai daerah di Nusantara. Kamu dapat menghidangkan lontong kari ayam kreasi sendiri di rumah dan boleh dijadikan makanan kesukaanmu di akhir pekanmu.

Kamu jangan bingung untuk mendapatkan lontong kari ayam, karena lontong kari ayam mudah untuk ditemukan dan kamu pun bisa mengolahnya sendiri di tempatmu. lontong kari ayam bisa diolah dengan beraneka cara. Kini ada banyak banget resep modern yang menjadikan lontong kari ayam semakin lebih lezat.

Resep lontong kari ayam juga gampang dibikin, lho. Kita tidak perlu repot-repot untuk membeli lontong kari ayam, sebab Kita dapat menyajikan di rumahmu. Untuk Kalian yang hendak mencobanya, inilah resep untuk membuat lontong kari ayam yang nikamat yang bisa Kita coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Lontong Kari Ayam:

1. Ambil  Lontong
1. Siapkan 500 gr ayam
1. Sediakan 1 buah wortel
1. Gunakan 100 gr buncis
1. Siapkan  Bumbu halus
1. Sediakan 8 siung bawang merah
1. Sediakan 6 siung bawang putih
1. Gunakan 3 buah cabai merah besar
1. Ambil 2 ruas kunyit
1. Gunakan 2 buah kemiri
1. Gunakan 1 sdt ketumbar
1. Siapkan  Bumbu lain
1. Gunakan 2 ruas lengkuas
1. Ambil 1 ruas jahe
1. Ambil 1 batang serai
1. Ambil 2 lembar daun salam
1. Gunakan 2 lembar daun jeruk
1. Gunakan 100 ml santan
1. Sediakan secukupnya garam
1. Ambil secukupnya gula pasir
1. Sediakan secukupnya merica
1. Sediakan secukupnya penyedap rasa ayan
1. Sediakan  Bahan pelengkap
1. Gunakan secukupnya bawang goreng
1. Gunakan secukupnya cabai rawit utuh
1. Siapkan  Optional
1. Ambil 1/2 papan tempe
1. Ambil 1 potong tahu
1. Sediakan 10 butir telur puyuh matang




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Lontong Kari Ayam:

1. Potong ayam, wortel, buncis sesuai selera lalu cuci bersih. Rebus ayam 5 menit untuk membuang buih kotor, lalu cuci ayam kembali, sisihkan.
1. Ulek semua bumbu halus. Geprek lengkuas, jahe dan serai.
1. Panaskan minyak goreng lalu masukkan bumbu halus, bahan yang sudah digeprek dan daun salam serta daun jeruk. Tumis hingga wangi.
1. Tambahkan air lalu masukkan santan, garam, gula, merica dan penyedap rasa ayam (royko/masako). Aduk sesekali agar santan tidak pecah.
1. Masukkan ayam, wortel dan buncis. Beri tambahan bawang goreng dan rawit utuh jika suka.
1. Masak hingga kuah mulai surut, tes rasa. Potong-potong lontong, sajikan dengan kari.
1. Ps : anda dapat menambahkan bahan-bahan optional dan isian lainnya jika suka. 😊




Ternyata resep lontong kari ayam yang nikamt tidak rumit ini mudah sekali ya! Anda Semua mampu membuatnya. Resep lontong kari ayam Sangat cocok banget untuk kamu yang baru akan belajar memasak ataupun untuk anda yang sudah hebat memasak.

Apakah kamu tertarik mulai mencoba buat resep lontong kari ayam nikmat tidak rumit ini? Kalau kalian tertarik, ayo kalian segera buruan siapkan peralatan dan bahannya, maka bikin deh Resep lontong kari ayam yang nikmat dan sederhana ini. Sangat taidak sulit kan. 

Jadi, ketimbang kamu diam saja, yuk langsung aja hidangkan resep lontong kari ayam ini. Pasti anda gak akan nyesel sudah membuat resep lontong kari ayam enak tidak rumit ini! Selamat mencoba dengan resep lontong kari ayam lezat simple ini di rumah kalian sendiri,ya!.

