---
description: "Resep Hati ayam kentang masak kecap Sederhana Untuk Jualan"
title: "Resep Hati ayam kentang masak kecap Sederhana Untuk Jualan"
slug: 334-resep-hati-ayam-kentang-masak-kecap-sederhana-untuk-jualan
date: 2021-04-29T15:19:48.392Z
image: https://img-global.cpcdn.com/recipes/2f1d81f284043d58/680x482cq70/hati-ayam-kentang-masak-kecap-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2f1d81f284043d58/680x482cq70/hati-ayam-kentang-masak-kecap-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2f1d81f284043d58/680x482cq70/hati-ayam-kentang-masak-kecap-foto-resep-utama.jpg
author: Elijah Holland
ratingvalue: 3.9
reviewcount: 5
recipeingredient:
- "4 bh hati ayam"
- "4 bh kentang"
- "3 bh bawang merah  1 bh bombay"
- "2 bh bawang putih"
- "secukupnya Merica"
- "2 helai daun bawang iris"
- "1 bh tomat besar iris"
- "1 ruas jahe"
- "2 sdm kecap manis"
- "1 sdt saori saus tiram"
- "secukupnya Garampenyedap"
- "secukupnya Air"
recipeinstructions:
- "Rebus hati ayam,stlh masak potong dan sisihkan"
- "Kupas dan potong kentang sesuai selera,lalu digoreng"
- "Iris bawang merah,geprek bawang putih dan jahe"
- "Tumis bawang,jahe dan merica hingga harum"
- "Tambahkan garam,penyedap dan air"
- "Lalu masukkan saori,dan kecap manis"
- "Masukkan hati ayam dan kentang,aduk rata dan diamkan sejenak sampai seluruh bumbu meresap."
- "Terakhir masukkan irisan daun bawang dan tomat sbg pelengkap,aduk rata"
- "Siap dihidangkan🤗"
categories:
- Resep
tags:
- hati
- ayam
- kentang

katakunci: hati ayam kentang 
nutrition: 150 calories
recipecuisine: Indonesian
preptime: "PT10M"
cooktime: "PT58M"
recipeyield: "3"
recipecategory: Dessert

---


![Hati ayam kentang masak kecap](https://img-global.cpcdn.com/recipes/2f1d81f284043d58/680x482cq70/hati-ayam-kentang-masak-kecap-foto-resep-utama.jpg)

Sebagai seorang yang hobi memasak, menyuguhkan panganan lezat untuk keluarga adalah hal yang menyenangkan untuk anda sendiri. Peran seorang  wanita Tidak sekedar mengurus rumah saja, tetapi anda juga harus menyediakan keperluan gizi terpenuhi dan juga olahan yang dimakan anak-anak mesti lezat.

Di masa  saat ini, kalian memang bisa mengorder masakan yang sudah jadi tanpa harus capek membuatnya dahulu. Namun banyak juga mereka yang memang ingin menyajikan yang terenak untuk keluarganya. Karena, menyajikan masakan yang dibuat sendiri jauh lebih higienis dan bisa menyesuaikan makanan tersebut berdasarkan masakan kesukaan keluarga. 



Mungkinkah anda seorang penyuka hati ayam kentang masak kecap?. Tahukah kamu, hati ayam kentang masak kecap adalah makanan khas di Indonesia yang sekarang digemari oleh kebanyakan orang dari berbagai wilayah di Indonesia. Anda dapat menyajikan hati ayam kentang masak kecap buatan sendiri di rumahmu dan pasti jadi makanan favorit di hari libur.

Kita jangan bingung untuk menyantap hati ayam kentang masak kecap, karena hati ayam kentang masak kecap gampang untuk didapatkan dan juga kalian pun bisa menghidangkannya sendiri di tempatmu. hati ayam kentang masak kecap dapat dibuat lewat bermacam cara. Kini ada banyak banget resep modern yang membuat hati ayam kentang masak kecap lebih enak.

Resep hati ayam kentang masak kecap pun mudah untuk dibuat, lho. Kalian jangan capek-capek untuk memesan hati ayam kentang masak kecap, lantaran Kalian dapat menyiapkan sendiri di rumah. Bagi Anda yang akan menyajikannya, di bawah ini adalah resep menyajikan hati ayam kentang masak kecap yang enak yang bisa Kita buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Hati ayam kentang masak kecap:

1. Ambil 4 bh hati ayam
1. Sediakan 4 bh kentang
1. Gunakan 3 bh bawang merah / 1 bh bombay
1. Sediakan 2 bh bawang putih
1. Sediakan secukupnya Merica
1. Siapkan 2 helai daun bawang, iris
1. Gunakan 1 bh tomat besar, iris
1. Gunakan 1 ruas jahe
1. Ambil 2 sdm kecap manis
1. Gunakan 1 sdt saori saus tiram
1. Siapkan secukupnya Garam,penyedap
1. Siapkan secukupnya Air




<!--inarticleads2-->

##### Cara menyiapkan Hati ayam kentang masak kecap:

1. Rebus hati ayam,stlh masak potong dan sisihkan
1. Kupas dan potong kentang sesuai selera,lalu digoreng
1. Iris bawang merah,geprek bawang putih dan jahe
1. Tumis bawang,jahe dan merica hingga harum
1. Tambahkan garam,penyedap dan air
1. Lalu masukkan saori,dan kecap manis
1. Masukkan hati ayam dan kentang,aduk rata dan diamkan sejenak sampai seluruh bumbu meresap.
1. Terakhir masukkan irisan daun bawang dan tomat sbg pelengkap,aduk rata
1. Siap dihidangkan🤗




Wah ternyata cara membuat hati ayam kentang masak kecap yang enak simple ini mudah banget ya! Semua orang mampu memasaknya. Resep hati ayam kentang masak kecap Sesuai banget buat anda yang baru mau belajar memasak ataupun juga bagi kamu yang sudah pandai dalam memasak.

Apakah kamu tertarik mencoba bikin resep hati ayam kentang masak kecap mantab tidak rumit ini? Kalau kalian tertarik, ayo kalian segera siapkan peralatan dan bahannya, lantas bikin deh Resep hati ayam kentang masak kecap yang mantab dan simple ini. Betul-betul taidak sulit kan. 

Jadi, daripada kalian diam saja, maka langsung aja bikin resep hati ayam kentang masak kecap ini. Dijamin kamu gak akan nyesel bikin resep hati ayam kentang masak kecap nikmat tidak ribet ini! Selamat mencoba dengan resep hati ayam kentang masak kecap mantab tidak ribet ini di tempat tinggal kalian sendiri,ya!.

