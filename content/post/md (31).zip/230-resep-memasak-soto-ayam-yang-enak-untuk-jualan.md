---
description: "Resep memasak Soto Ayam yang enak Untuk Jualan"
title: "Resep memasak Soto Ayam yang enak Untuk Jualan"
slug: 230-resep-memasak-soto-ayam-yang-enak-untuk-jualan
date: 2021-04-12T13:40:52.896Z
image: https://img-global.cpcdn.com/recipes/f72d50f2556d9875/680x482cq70/soto-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f72d50f2556d9875/680x482cq70/soto-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f72d50f2556d9875/680x482cq70/soto-ayam-foto-resep-utama.jpg
author: Austin Sparks
ratingvalue: 4.8
reviewcount: 7
recipeingredient:
- "1 ekor ayam potong 8 bagian"
- "1 sdt ketumbar"
- "2 cm jahe"
- "2 cm lengkuas"
- "2 cm kunyit"
- "15 bawang merah"
- "10 bawang putih"
- "1 sdt merica"
- "5 butir kemiri"
- "100 gr toge"
- "2 bungkus kecil soun"
- "2 batang daun bawang"
- "5 batang seledri"
- "3 daun jeruk 3 daun salam 3 batang sereh"
- " Sambal  15 cabe rawit  2 bawang putih"
- "2 lt air 5 sdm minyak untuk menumis"
- " Garam dan penyedap rasa opsional"
- " Jeruk nipis dipotong kecil2"
recipeinstructions:
- "Haluskan / blender : ketumbar, merica, bawang merah, bawang putih, jahe, lengkuas, kunyit, kemiri."
- "Panaskan minyak, tumis bumbu yang sudah di haluskan di dalam panci, tambahkan daun jeruk, sereh dan daun salam hingga harum aromanya.  Kemudian tambahkan air 1lt.  Tutup panci"
- "Setelah mendidih, masukkan ayam. Tambahkan garam dan penyedap rasa. Rebus hingga 30 menit."
- "Setelah bumbu meresap, keluarkan ayam dari panci.  Kemudian tambahkan air 1Lt lagi di panci, aduk sekali2."
- "Goreng ayam di minyak panas, tiriskan.  Lalu potong kecil2 / suwir.  Setelah itu masukkan lagi ke dalam panci rebusan kuah soto.  Kecilkan api dan tes rasa, bila diperlukan tambahkan garam dan penyedap rasa."
- "Bahan pelengkap : Potong/iris tipis kol.  Cuci kol dan toge. Lalu di panci lain, rebus air hingga mendidih.  Matikan api, celupkan kol, toge dan soun lalu segera tiriskan. Siapkan di mangkok."
- "Bahan tabur : Potong/iris daun bawang, seledri. Siapkan di piring kecil"
- "Sambal soto : Rebus cabe dan bawang putih. Setelah itu, uleg kasar saja.  Taruh di mangkuk kecil, lalu tuangkan 1 sendok sup kuah soto ke sambal."
- "Penyajian : taruh bahan tabur, soun, kol dan toge di mangkok. Siram dengan kuah soto. Tambahkan sambal dan jeruk nipis. Nikmati selagi hangat. Silahkan mencoba"
categories:
- Resep
tags:
- soto
- ayam

katakunci: soto ayam 
nutrition: 140 calories
recipecuisine: Indonesian
preptime: "PT19M"
cooktime: "PT39M"
recipeyield: "2"
recipecategory: Lunch

---


![Soto Ayam](https://img-global.cpcdn.com/recipes/f72d50f2556d9875/680x482cq70/soto-ayam-foto-resep-utama.jpg)

Andai anda seorang orang tua, mempersiapkan hidangan menggugah selera pada keluarga tercinta adalah suatu hal yang sangat menyenangkan bagi anda sendiri. Peran seorang istri Tidak cuman mengerjakan pekerjaan rumah saja, tetapi kamu juga harus memastikan kebutuhan nutrisi terpenuhi dan panganan yang dikonsumsi orang tercinta harus menggugah selera.

Di masa  sekarang, kita memang dapat membeli olahan jadi walaupun tidak harus ribet memasaknya dulu. Tetapi banyak juga mereka yang memang mau memberikan makanan yang terenak untuk orang yang dicintainya. Pasalnya, menghidangkan masakan yang dibuat sendiri jauh lebih bersih dan kita juga bisa menyesuaikan hidangan tersebut sesuai makanan kesukaan keluarga tercinta. 



Mungkinkah anda merupakan salah satu penyuka soto ayam?. Asal kamu tahu, soto ayam adalah sajian khas di Nusantara yang kini disenangi oleh kebanyakan orang di hampir setiap daerah di Nusantara. Kalian dapat memasak soto ayam sendiri di rumahmu dan boleh dijadikan santapan kesenanganmu di hari liburmu.

Kalian jangan bingung jika kamu ingin memakan soto ayam, sebab soto ayam mudah untuk ditemukan dan kalian pun boleh memasaknya sendiri di rumah. soto ayam boleh diolah dengan beragam cara. Saat ini telah banyak banget resep modern yang membuat soto ayam lebih nikmat.

Resep soto ayam pun gampang untuk dibikin, lho. Kalian jangan repot-repot untuk memesan soto ayam, sebab Kita dapat menghidangkan sendiri di rumah. Untuk Kalian yang hendak menghidangkannya, berikut resep membuat soto ayam yang mantab yang mampu Anda hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Soto Ayam:

1. Siapkan 1 ekor ayam potong 8 bagian
1. Gunakan 1 sdt ketumbar
1. Sediakan 2 cm jahe
1. Ambil 2 cm lengkuas
1. Sediakan 2 cm kunyit
1. Siapkan 15 bawang merah
1. Ambil 10 bawang putih
1. Sediakan 1 sdt merica
1. Gunakan 5 butir kemiri
1. Gunakan 100 gr toge
1. Siapkan 2 bungkus kecil soun
1. Gunakan 2 batang daun bawang
1. Gunakan 5 batang seledri
1. Sediakan 3 daun jeruk, 3 daun salam, 3 batang sereh
1. Siapkan  Sambal : 15 cabe rawit + 2 bawang putih
1. Gunakan 2 lt air, 5 sdm minyak untuk menumis
1. Gunakan  Garam dan penyedap rasa (opsional)
1. Ambil  Jeruk nipis dipotong kecil2




<!--inarticleads2-->

##### Cara menyiapkan Soto Ayam:

1. Haluskan / blender : ketumbar, merica, bawang merah, bawang putih, jahe, lengkuas, kunyit, kemiri.
1. Panaskan minyak, tumis bumbu yang sudah di haluskan di dalam panci, tambahkan daun jeruk, sereh dan daun salam hingga harum aromanya.  - Kemudian tambahkan air 1lt.  - Tutup panci
1. Setelah mendidih, masukkan ayam. Tambahkan garam dan penyedap rasa. Rebus hingga 30 menit.
1. Setelah bumbu meresap, keluarkan ayam dari panci.  - Kemudian tambahkan air 1Lt lagi di panci, aduk sekali2.
1. Goreng ayam di minyak panas, tiriskan.  - Lalu potong kecil2 / suwir.  - Setelah itu masukkan lagi ke dalam panci rebusan kuah soto.  - Kecilkan api dan tes rasa, bila diperlukan tambahkan garam dan penyedap rasa.
1. Bahan pelengkap : - Potong/iris tipis kol.  - Cuci kol dan toge. - Lalu di panci lain, rebus air hingga mendidih.  - Matikan api, celupkan kol, toge dan soun lalu segera tiriskan. - Siapkan di mangkok.
1. Bahan tabur : - Potong/iris daun bawang, seledri. Siapkan di piring kecil
1. Sambal soto : - Rebus cabe dan bawang putih. Setelah itu, uleg kasar saja.  - Taruh di mangkuk kecil, lalu tuangkan 1 sendok sup kuah soto ke sambal.
1. Penyajian : taruh bahan tabur, soun, kol dan toge di mangkok. Siram dengan kuah soto. Tambahkan sambal dan jeruk nipis. Nikmati selagi hangat. - Silahkan mencoba




Ternyata cara membuat soto ayam yang enak simple ini enteng sekali ya! Kamu semua bisa memasaknya. Cara buat soto ayam Sesuai sekali buat kalian yang sedang belajar memasak maupun untuk kamu yang telah lihai memasak.

Tertarik untuk mulai mencoba membikin resep soto ayam lezat simple ini? Kalau anda ingin, ayo kalian segera menyiapkan alat-alat dan bahan-bahannya, setelah itu bikin deh Resep soto ayam yang mantab dan simple ini. Sangat mudah kan. 

Jadi, ketimbang kamu berlama-lama, ayo kita langsung sajikan resep soto ayam ini. Pasti kamu tak akan menyesal sudah buat resep soto ayam nikmat simple ini! Selamat mencoba dengan resep soto ayam enak sederhana ini di rumah masing-masing,oke!.

