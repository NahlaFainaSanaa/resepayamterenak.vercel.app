---
description: "Bahan-bahan DOUBLE LAYERED BASQUE 😍🤩😍 yang lezat Untuk Jualan"
title: "Bahan-bahan DOUBLE LAYERED BASQUE 😍🤩😍 yang lezat Untuk Jualan"
slug: 170-bahan-bahan-double-layered-basque-yang-lezat-untuk-jualan
date: 2021-01-27T16:55:34.057Z
image: https://img-global.cpcdn.com/recipes/046b40c688fea818/680x482cq70/double-layered-basque-😍🤩😍-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/046b40c688fea818/680x482cq70/double-layered-basque-😍🤩😍-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/046b40c688fea818/680x482cq70/double-layered-basque-😍🤩😍-foto-resep-utama.jpg
author: Lelia Bennett
ratingvalue: 4.2
reviewcount: 9
recipeingredient:
- " Bahan Dasar"
- "230 gr creamcheese"
- "60 gr gula pasir"
- "2 butir telur ayam uk kecil ke sedang"
- " Layer dasar Matcha"
- "7.5 gr bubuk matcha"
- "68 gr whipping cream cair"
- " Layer atas"
- "5 gr tepung terigu protein rendah"
- "68 gr whipping cream cair"
- "1/2 sdt vanilla ekstrak"
- "1/2 sdt air lemon"
recipeinstructions:
- "Campur bahan layer matcha dan layer atas (tanpa vanilla ekstrak dan air lemon), aduk rata, sisihkan."
- "Mixer cream cheese sampai creamy, lalu masukan gula pasir, mixer dengan kecepatan tinggi sampai fluffy lalu satu persatu masukan telur, aduk rata dengan kecepatan rendah saja."
- "Bagi adonan menjadi 2 sama banyak lalu buat masing masing layer. Layer atas : kedalam setengah adonan, masukan larutan tepung dan whipping cream (langkah 1), tambahkan vanilla ekstrak dan air lemon lalu aduk rata, pindahkan ke plastik segitiga."
- "Layer matcha : kedalam setengah adonan lain, masukan larutan matcha whipping cream (langkah 1), lalu aduk rata menggunakan teknik aduk lipat. Pindahkan ke loyang yang telah dialasi 2 lapis baking paper. Panaskan oven api atas bawah 220 derajat."
- "Ratakan permukaannya, kemudian beri lapisan layer putih mulai dari tengah ya😃 goyangkan agar merata😍"
- "Panggang selama 25-28 menit, lalu pindah ke api atas 3-5 menit (kalau mau lebih hitam, saya ga suka gosong banget, 3 menit cukup🤩)"
- "Diamkan dalam suhu ruang lalu masukan kulkas min 6 jam. Potong, maem, nyam🤩"
categories:
- Resep
tags:
- double
- layered
- basque

katakunci: double layered basque 
nutrition: 132 calories
recipecuisine: Indonesian
preptime: "PT29M"
cooktime: "PT58M"
recipeyield: "2"
recipecategory: Lunch

---


![DOUBLE LAYERED BASQUE 😍🤩😍](https://img-global.cpcdn.com/recipes/046b40c688fea818/680x482cq70/double-layered-basque-😍🤩😍-foto-resep-utama.jpg)

Andai anda seorang wanita, mempersiapkan hidangan nikmat kepada orang tercinta merupakan suatu hal yang sangat menyenangkan bagi kita sendiri. Kewajiban seorang ibu Tidak cuman mengurus rumah saja, tapi anda pun wajib menyediakan kebutuhan gizi tercukupi dan santapan yang disantap orang tercinta harus sedap.

Di zaman  sekarang, kita memang bisa membeli panganan yang sudah jadi tanpa harus susah mengolahnya terlebih dahulu. Tapi banyak juga mereka yang selalu ingin memberikan yang terbaik bagi orang tercintanya. Pasalnya, memasak yang diolah sendiri jauh lebih bersih dan bisa menyesuaikan sesuai dengan makanan kesukaan orang tercinta. 



Mungkinkah kamu salah satu penggemar double layered basque 😍🤩😍?. Asal kamu tahu, double layered basque 😍🤩😍 adalah makanan khas di Indonesia yang kini digemari oleh setiap orang di hampir setiap wilayah di Nusantara. Kita bisa membuat double layered basque 😍🤩😍 sendiri di rumahmu dan pasti jadi hidangan kegemaranmu di hari liburmu.

Anda jangan bingung untuk menyantap double layered basque 😍🤩😍, karena double layered basque 😍🤩😍 gampang untuk didapatkan dan juga kalian pun bisa memasaknya sendiri di rumah. double layered basque 😍🤩😍 boleh dibuat dengan bermacam cara. Kini ada banyak sekali cara modern yang membuat double layered basque 😍🤩😍 semakin mantap.

Resep double layered basque 😍🤩😍 pun mudah sekali dihidangkan, lho. Kita tidak perlu ribet-ribet untuk memesan double layered basque 😍🤩😍, sebab Kalian mampu menyiapkan ditempatmu. Bagi Kita yang ingin mencobanya, dibawah ini merupakan cara membuat double layered basque 😍🤩😍 yang lezat yang dapat Kita buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan DOUBLE LAYERED BASQUE 😍🤩😍:

1. Gunakan  Bahan Dasar
1. Sediakan 230 gr creamcheese
1. Siapkan 60 gr gula pasir
1. Gunakan 2 butir telur ayam uk kecil ke sedang
1. Gunakan  Layer dasar (Matcha)
1. Ambil 7.5 gr bubuk matcha
1. Siapkan 68 gr whipping cream cair
1. Sediakan  Layer atas
1. Gunakan 5 gr tepung terigu protein rendah
1. Gunakan 68 gr whipping cream cair
1. Gunakan 1/2 sdt vanilla ekstrak
1. Sediakan 1/2 sdt air lemon




<!--inarticleads2-->

##### Langkah-langkah menyiapkan DOUBLE LAYERED BASQUE 😍🤩😍:

1. Campur bahan layer matcha dan layer atas (tanpa vanilla ekstrak dan air lemon), aduk rata, sisihkan.
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="DOUBLE LAYERED BASQUE 😍🤩😍">1. Mixer cream cheese sampai creamy, lalu masukan gula pasir, mixer dengan kecepatan tinggi sampai fluffy lalu satu persatu masukan telur, aduk rata dengan kecepatan rendah saja.
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="DOUBLE LAYERED BASQUE 😍🤩😍"><img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="DOUBLE LAYERED BASQUE 😍🤩😍">1. Bagi adonan menjadi 2 sama banyak lalu buat masing masing layer. Layer atas : kedalam setengah adonan, masukan larutan tepung dan whipping cream (langkah 1), tambahkan vanilla ekstrak dan air lemon lalu aduk rata, pindahkan ke plastik segitiga.
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="DOUBLE LAYERED BASQUE 😍🤩😍">1. Layer matcha : kedalam setengah adonan lain, masukan larutan matcha whipping cream (langkah 1), lalu aduk rata menggunakan teknik aduk lipat. Pindahkan ke loyang yang telah dialasi 2 lapis baking paper. Panaskan oven api atas bawah 220 derajat.
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="DOUBLE LAYERED BASQUE 😍🤩😍"><img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="DOUBLE LAYERED BASQUE 😍🤩😍"><img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="DOUBLE LAYERED BASQUE 😍🤩😍">1. Ratakan permukaannya, kemudian beri lapisan layer putih mulai dari tengah ya😃 goyangkan agar merata😍
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="DOUBLE LAYERED BASQUE 😍🤩😍"><img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="DOUBLE LAYERED BASQUE 😍🤩😍">1. Panggang selama 25-28 menit, lalu pindah ke api atas 3-5 menit (kalau mau lebih hitam, saya ga suka gosong banget, 3 menit cukup🤩)
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="DOUBLE LAYERED BASQUE 😍🤩😍">1. Diamkan dalam suhu ruang lalu masukan kulkas min 6 jam. Potong, maem, nyam🤩
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="DOUBLE LAYERED BASQUE 😍🤩😍">



Wah ternyata cara membuat double layered basque 😍🤩😍 yang enak simple ini gampang sekali ya! Semua orang bisa memasaknya. Cara buat double layered basque 😍🤩😍 Sangat cocok banget buat kamu yang baru mau belajar memasak atau juga untuk kamu yang telah lihai dalam memasak.

Apakah kamu ingin mencoba membikin resep double layered basque 😍🤩😍 nikmat tidak ribet ini? Kalau anda tertarik, ayo kalian segera siapin alat-alat dan bahan-bahannya, kemudian bikin deh Resep double layered basque 😍🤩😍 yang enak dan tidak rumit ini. Sangat taidak sulit kan. 

Oleh karena itu, daripada kita berlama-lama, maka langsung aja sajikan resep double layered basque 😍🤩😍 ini. Dijamin kamu tiidak akan nyesel membuat resep double layered basque 😍🤩😍 nikmat sederhana ini! Selamat berkreasi dengan resep double layered basque 😍🤩😍 nikmat simple ini di rumah kalian masing-masing,ya!.

