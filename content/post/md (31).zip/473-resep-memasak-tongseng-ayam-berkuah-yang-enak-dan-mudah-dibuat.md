---
description: "Resep memasak Tongseng ayam (berkuah) yang enak dan Mudah Dibuat"
title: "Resep memasak Tongseng ayam (berkuah) yang enak dan Mudah Dibuat"
slug: 473-resep-memasak-tongseng-ayam-berkuah-yang-enak-dan-mudah-dibuat
date: 2021-01-20T18:42:20.773Z
image: https://img-global.cpcdn.com/recipes/68a076dce64520a8/680x482cq70/tongseng-ayam-berkuah-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/68a076dce64520a8/680x482cq70/tongseng-ayam-berkuah-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/68a076dce64520a8/680x482cq70/tongseng-ayam-berkuah-foto-resep-utama.jpg
author: Lenora Craig
ratingvalue: 4.6
reviewcount: 8
recipeingredient:
- "1/2 ekor Ayam potong"
- "Secukupnya Kol"
- "1 buah Tomat Merah"
- "1 batang Daun Bawang"
- "3 lembar Daun Salam"
- "3 lembar Daun Jeruk"
- "2 batang Sereh pakai putihnya aja geprek"
- "1 cm Lengkuas geprek"
- "3 sdm Kecap Manis"
- "300 ml Air"
- "65 ml Santan Instan"
- "2 cm Kayu Manis saya skip kehabisan"
- "10 buah Cabe Rawit utuh saya skip"
- "Secukupnya Gula saya 1sdm"
- "Secukupnya Garam saya 1sdt"
- " Bumbu halus"
- "6 siung Bawang Merah"
- "4 siung Bawang Putih"
- "5 buah Cabe Kriting"
- "2 butir Kemiri sangrai"
- "1 ruas Kunyit bakar"
- "1 sdt Merica bubuk"
- "1 sdt Ketumbar bubuk"
recipeinstructions:
- "Siapkan bahan² yg sudah dicuci bersih. Haluskan bahan bumbu halus. Tumis bumbu halus juga daun salam, daun jeruk, lengkuas, sereh dan kayu manis hingga harum."
- "Masukkan ayam, masak sebentar kemudian tambahkan air. Masak lagi sampai ayam matang lalu masukkan santan, gula, garam, kecap manis. Sambil diicip icip. Sebelum kompor dimatikan masukkan irisan kol, daun bawang, dan tomat. Masak sebentar saja sampai tomat rada layu. Kemudian matikan kompor dan Tongseng ayam siap disantap."
categories:
- Resep
tags:
- tongseng
- ayam
- berkuah

katakunci: tongseng ayam berkuah 
nutrition: 259 calories
recipecuisine: Indonesian
preptime: "PT29M"
cooktime: "PT30M"
recipeyield: "3"
recipecategory: Lunch

---


![Tongseng ayam (berkuah)](https://img-global.cpcdn.com/recipes/68a076dce64520a8/680x482cq70/tongseng-ayam-berkuah-foto-resep-utama.jpg)

Selaku seorang istri, menyajikan olahan menggugah selera bagi keluarga merupakan suatu hal yang memuaskan bagi kita sendiri. Tugas seorang istri bukan cuman menjaga rumah saja, namun anda juga wajib menyediakan keperluan gizi terpenuhi dan hidangan yang disantap anak-anak harus lezat.

Di era  sekarang, kita sebenarnya dapat memesan santapan instan walaupun tanpa harus ribet memasaknya lebih dulu. Namun ada juga lho mereka yang selalu ingin menghidangkan yang terbaik bagi orang yang dicintainya. Sebab, menyajikan masakan yang dibuat sendiri akan jauh lebih bersih dan bisa menyesuaikan masakan tersebut berdasarkan makanan kesukaan keluarga. 



Apakah anda seorang penikmat tongseng ayam (berkuah)?. Asal kamu tahu, tongseng ayam (berkuah) adalah hidangan khas di Nusantara yang sekarang digemari oleh kebanyakan orang dari hampir setiap daerah di Nusantara. Kamu dapat memasak tongseng ayam (berkuah) sendiri di rumahmu dan dapat dijadikan makanan kegemaranmu di akhir pekan.

Kalian tidak perlu bingung untuk mendapatkan tongseng ayam (berkuah), karena tongseng ayam (berkuah) tidak sulit untuk didapatkan dan anda pun bisa memasaknya sendiri di tempatmu. tongseng ayam (berkuah) dapat dibuat memalui berbagai cara. Kini pun telah banyak sekali cara kekinian yang menjadikan tongseng ayam (berkuah) semakin lebih enak.

Resep tongseng ayam (berkuah) pun sangat gampang dibuat, lho. Kita tidak perlu repot-repot untuk memesan tongseng ayam (berkuah), karena Kita mampu menghidangkan sendiri di rumah. Bagi Kamu yang mau menyajikannya, berikut ini resep untuk membuat tongseng ayam (berkuah) yang nikamat yang mampu Kamu coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Tongseng ayam (berkuah):

1. Sediakan 1/2 ekor Ayam (potong²)
1. Siapkan Secukupnya Kol
1. Sediakan 1 buah Tomat Merah
1. Siapkan 1 batang Daun Bawang
1. Siapkan 3 lembar Daun Salam
1. Gunakan 3 lembar Daun Jeruk
1. Sediakan 2 batang Sereh (pakai putihnya aja, geprek)
1. Ambil 1 cm Lengkuas (geprek)
1. Ambil 3 sdm Kecap Manis
1. Gunakan 300 ml Air
1. Ambil 65 ml Santan Instan
1. Gunakan 2 cm Kayu Manis (saya skip, kehabisan)
1. Ambil 10 buah Cabe Rawit utuh (saya skip)
1. Ambil Secukupnya Gula (saya 1sdm)
1. Ambil Secukupnya Garam (saya 1½sdt)
1. Gunakan  Bumbu halus
1. Ambil 6 siung Bawang Merah
1. Ambil 4 siung Bawang Putih
1. Gunakan 5 buah Cabe Kriting
1. Siapkan 2 butir Kemiri (sangrai)
1. Gunakan 1 ruas Kunyit (bakar)
1. Ambil 1 sdt Merica bubuk
1. Gunakan 1 sdt Ketumbar bubuk




<!--inarticleads2-->

##### Cara menyiapkan Tongseng ayam (berkuah):

1. Siapkan bahan² yg sudah dicuci bersih. Haluskan bahan bumbu halus. Tumis bumbu halus juga daun salam, daun jeruk, lengkuas, sereh dan kayu manis hingga harum.
1. Masukkan ayam, masak sebentar kemudian tambahkan air. Masak lagi sampai ayam matang lalu masukkan santan, gula, garam, kecap manis. Sambil diicip icip. Sebelum kompor dimatikan masukkan irisan kol, daun bawang, dan tomat. Masak sebentar saja sampai tomat rada layu. Kemudian matikan kompor dan Tongseng ayam siap disantap.




Wah ternyata cara membuat tongseng ayam (berkuah) yang lezat tidak rumit ini mudah banget ya! Kamu semua dapat membuatnya. Cara Membuat tongseng ayam (berkuah) Cocok banget untuk kita yang baru belajar memasak ataupun untuk kamu yang sudah pandai dalam memasak.

Apakah kamu ingin mulai mencoba bikin resep tongseng ayam (berkuah) mantab tidak ribet ini? Kalau ingin, mending kamu segera siapin peralatan dan bahannya, lalu buat deh Resep tongseng ayam (berkuah) yang lezat dan tidak rumit ini. Sungguh mudah kan. 

Jadi, daripada anda berfikir lama-lama, maka langsung aja buat resep tongseng ayam (berkuah) ini. Pasti kamu gak akan menyesal sudah bikin resep tongseng ayam (berkuah) nikmat simple ini! Selamat berkreasi dengan resep tongseng ayam (berkuah) mantab tidak ribet ini di tempat tinggal masing-masing,oke!.

