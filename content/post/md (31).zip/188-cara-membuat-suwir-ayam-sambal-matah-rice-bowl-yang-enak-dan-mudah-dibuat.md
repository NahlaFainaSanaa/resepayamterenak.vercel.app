---
description: "Cara membuat Suwir Ayam Sambal Matah (Rice Bowl) 🍚🍚 yang enak dan Mudah Dibuat"
title: "Cara membuat Suwir Ayam Sambal Matah (Rice Bowl) 🍚🍚 yang enak dan Mudah Dibuat"
slug: 188-cara-membuat-suwir-ayam-sambal-matah-rice-bowl-yang-enak-dan-mudah-dibuat
date: 2021-02-16T13:45:28.913Z
image: https://img-global.cpcdn.com/recipes/66b15b5b39abd665/680x482cq70/suwir-ayam-sambal-matah-rice-bowl-🍚🍚-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/66b15b5b39abd665/680x482cq70/suwir-ayam-sambal-matah-rice-bowl-🍚🍚-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/66b15b5b39abd665/680x482cq70/suwir-ayam-sambal-matah-rice-bowl-🍚🍚-foto-resep-utama.jpg
author: Ryan Bailey
ratingvalue: 4
reviewcount: 13
recipeingredient:
- "1/4 Kg Daging Ayam"
- "1/2 Bawang Bombay"
- "4 Daun Bawang"
- "3-4 Porsi Nasi Putih"
- " Bumbu ayam suwir "
- "5 Siung Bawang Merah"
- "3 Siung Bawang Putih"
- "1/4 SDT Pala"
- "1 SDT Merica Bubuk"
- "1 Batang Sereh"
- "2 Daun Salam"
- " Jahe"
- " Gula"
- " Garam"
- " Penyedap rasa optional"
- " Air"
- " Minyak goreng menumis bumbu"
- " Sambal Matah "
- "3 Siung Bawang Merah"
- "1 Siung Bawang Putih"
- "9 Cabe Rawit sesuai selera"
- "1 Lembar Daun Jeruk"
- "1 Batang Sereh"
- "1/2 Jeruk Nipis ambil air"
- " Terasi"
- " Gula"
- " Garam"
- " Minyak Goreng Panas secukupnya"
recipeinstructions:
- "Rebus daging ayam hingga matang, lalu suwir-suwir. Setelah itu potong daun bawang dan bawang bombay, sisihkan."
- "Haluskan bawang merah, bawang putih, pala, dan garam sebagai bahan bumbu untuk membuat ayam suwir."
- "Panaskan minyak goreng, lalu tumis sebentar bawang bombay hingga harum. Setelah itu masukkan bumbu halus, sereh dan jahe yang telah digeprek berserta daun salam. Tumis hingga bumbu halus."
- "Masukkan ayam yang telah disuwir ke dalam tumisan bumbu. Tambahkan sedikit air agar tidak terlalu kering, masukkan merica dan tambahkan kembali gula, garam sesuai selera apabila rasa masih kurang. Masak hingga semua ayam dan bumbu tercampur."
- "Membuat sambal matah : - Potong tipis-tipis bawang merah, bawang putih, cabai, sereh, dan daun jeruk. Masukkan ke dalam mangkuk kecil, lalu tambahkan sedikit gula, garam, terasi, dan perasan air jeruk nipis. Aduk rata dan sisihkan..  - Panaskan minyak kelapa hingga panas, lalu siramkan minyak ke dalam mangkuk bahan sambal matah. Aduk rata semua bahan hingga tercampur rata."
- "Siapkan mangkuk yang berisi nasi hangat, lalu tambahkan ayam suwir dan sambal matah diatasnya. Rice bowl ayam suwir sambal matah siap disajikan."
categories:
- Resep
tags:
- suwir
- ayam
- sambal

katakunci: suwir ayam sambal 
nutrition: 201 calories
recipecuisine: Indonesian
preptime: "PT30M"
cooktime: "PT47M"
recipeyield: "1"
recipecategory: Dessert

---


![Suwir Ayam Sambal Matah (Rice Bowl) 🍚🍚](https://img-global.cpcdn.com/recipes/66b15b5b39abd665/680x482cq70/suwir-ayam-sambal-matah-rice-bowl-🍚🍚-foto-resep-utama.jpg)

Andai kamu seorang istri, menyediakan hidangan sedap buat keluarga tercinta merupakan hal yang menyenangkan bagi anda sendiri. Tanggung jawab seorang ibu bukan sekadar mengurus rumah saja, namun kamu pun harus menyediakan kebutuhan nutrisi tercukupi dan hidangan yang dimakan keluarga tercinta mesti sedap.

Di era  sekarang, kita sebenarnya bisa mengorder hidangan jadi walaupun tidak harus capek mengolahnya dahulu. Namun ada juga lho mereka yang memang mau memberikan yang terbaik bagi orang yang dicintainya. Karena, menghidangkan masakan yang diolah sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan masakan tersebut sesuai kesukaan famili. 



Apakah anda adalah seorang penikmat suwir ayam sambal matah (rice bowl) 🍚🍚?. Asal kamu tahu, suwir ayam sambal matah (rice bowl) 🍚🍚 adalah sajian khas di Nusantara yang sekarang disenangi oleh banyak orang dari berbagai wilayah di Nusantara. Anda dapat membuat suwir ayam sambal matah (rice bowl) 🍚🍚 sendiri di rumahmu dan pasti jadi hidangan favoritmu di hari libur.

Kita tidak perlu bingung untuk menyantap suwir ayam sambal matah (rice bowl) 🍚🍚, sebab suwir ayam sambal matah (rice bowl) 🍚🍚 gampang untuk dicari dan juga kita pun boleh membuatnya sendiri di tempatmu. suwir ayam sambal matah (rice bowl) 🍚🍚 dapat dibuat memalui berbagai cara. Saat ini ada banyak sekali cara kekinian yang membuat suwir ayam sambal matah (rice bowl) 🍚🍚 semakin lebih lezat.

Resep suwir ayam sambal matah (rice bowl) 🍚🍚 pun gampang sekali dibikin, lho. Kamu tidak perlu ribet-ribet untuk membeli suwir ayam sambal matah (rice bowl) 🍚🍚, tetapi Anda dapat membuatnya di rumah sendiri. Untuk Kamu yang akan menyajikannya, di bawah ini adalah resep menyajikan suwir ayam sambal matah (rice bowl) 🍚🍚 yang nikamat yang mampu Kalian coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Suwir Ayam Sambal Matah (Rice Bowl) 🍚🍚:

1. Ambil 1/4 Kg Daging Ayam
1. Siapkan 1/2 Bawang Bombay
1. Ambil 4 Daun Bawang
1. Siapkan 3-4 Porsi Nasi Putih
1. Siapkan  Bumbu ayam suwir :
1. Ambil 5 Siung Bawang Merah
1. Gunakan 3 Siung Bawang Putih
1. Sediakan 1/4 SDT Pala
1. Siapkan 1 SDT Merica Bubuk
1. Gunakan 1 Batang Sereh
1. Siapkan 2 Daun Salam
1. Sediakan  Jahe
1. Ambil  Gula
1. Gunakan  Garam
1. Gunakan  Penyedap rasa (optional)
1. Siapkan  Air
1. Gunakan  Minyak goreng (menumis bumbu)
1. Sediakan  Sambal Matah :
1. Gunakan 3 Siung Bawang Merah
1. Siapkan 1 Siung Bawang Putih
1. Ambil 9 Cabe Rawit (sesuai selera)
1. Siapkan 1 Lembar Daun Jeruk
1. Ambil 1 Batang Sereh
1. Ambil 1/2 Jeruk Nipis (ambil air)
1. Gunakan  Terasi
1. Sediakan  Gula
1. Siapkan  Garam
1. Gunakan  Minyak Goreng Panas (secukupnya)




<!--inarticleads2-->

##### Cara menyiapkan Suwir Ayam Sambal Matah (Rice Bowl) 🍚🍚:

1. Rebus daging ayam hingga matang, lalu suwir-suwir. Setelah itu potong daun bawang dan bawang bombay, sisihkan.
1. Haluskan bawang merah, bawang putih, pala, dan garam sebagai bahan bumbu untuk membuat ayam suwir.
1. Panaskan minyak goreng, lalu tumis sebentar bawang bombay hingga harum. Setelah itu masukkan bumbu halus, sereh dan jahe yang telah digeprek berserta daun salam. Tumis hingga bumbu halus.
1. Masukkan ayam yang telah disuwir ke dalam tumisan bumbu. Tambahkan sedikit air agar tidak terlalu kering, masukkan merica dan tambahkan kembali gula, garam sesuai selera apabila rasa masih kurang. Masak hingga semua ayam dan bumbu tercampur.
1. Membuat sambal matah : - - Potong tipis-tipis bawang merah, bawang putih, cabai, sereh, dan daun jeruk. Masukkan ke dalam mangkuk kecil, lalu tambahkan sedikit gula, garam, terasi, dan perasan air jeruk nipis. Aduk rata dan sisihkan..  - - Panaskan minyak kelapa hingga panas, lalu siramkan minyak ke dalam mangkuk bahan sambal matah. Aduk rata semua bahan hingga tercampur rata.
1. Siapkan mangkuk yang berisi nasi hangat, lalu tambahkan ayam suwir dan sambal matah diatasnya. Rice bowl ayam suwir sambal matah siap disajikan.




Ternyata cara membuat suwir ayam sambal matah (rice bowl) 🍚🍚 yang nikamt simple ini enteng banget ya! Kita semua mampu memasaknya. Cara Membuat suwir ayam sambal matah (rice bowl) 🍚🍚 Cocok banget buat kalian yang baru mau belajar memasak maupun juga untuk kamu yang telah hebat memasak.

Tertarik untuk mencoba buat resep suwir ayam sambal matah (rice bowl) 🍚🍚 mantab sederhana ini? Kalau kamu tertarik, ayo kamu segera buruan siapkan peralatan dan bahan-bahannya, lantas bikin deh Resep suwir ayam sambal matah (rice bowl) 🍚🍚 yang lezat dan simple ini. Benar-benar mudah kan. 

Oleh karena itu, daripada kalian diam saja, ayo langsung aja buat resep suwir ayam sambal matah (rice bowl) 🍚🍚 ini. Pasti anda tiidak akan nyesel sudah bikin resep suwir ayam sambal matah (rice bowl) 🍚🍚 nikmat simple ini! Selamat mencoba dengan resep suwir ayam sambal matah (rice bowl) 🍚🍚 nikmat simple ini di rumah kalian sendiri,ya!.

