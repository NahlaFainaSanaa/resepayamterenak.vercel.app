---
description: "Resep Ayam Paha Crispy Pedas Asam Lemon / Spicy &amp;amp; Lemon Sauce yang enak Untuk Jualan"
title: "Resep Ayam Paha Crispy Pedas Asam Lemon / Spicy &amp;amp; Lemon Sauce yang enak Untuk Jualan"
slug: 344-resep-ayam-paha-crispy-pedas-asam-lemon-spicy-and-amp-lemon-sauce-yang-enak-untuk-jualan
date: 2021-05-22T22:34:24.156Z
image: https://img-global.cpcdn.com/recipes/38b423589f432354/680x482cq70/ayam-paha-crispy-pedas-asam-lemon-spicy-lemon-sauce-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/38b423589f432354/680x482cq70/ayam-paha-crispy-pedas-asam-lemon-spicy-lemon-sauce-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/38b423589f432354/680x482cq70/ayam-paha-crispy-pedas-asam-lemon-spicy-lemon-sauce-foto-resep-utama.jpg
author: Mittie Clarke
ratingvalue: 4.8
reviewcount: 5
recipeingredient:
- "750 gr ayam bag paha blh ganti dgn wings  bag sesuai selera"
- " Bahan marinasi"
- "3 siung bawang putih parut"
- "1/2 sdm kecap asin  garam"
- "1 sdt perasan lemon"
- "1 sdt lada bubuk"
- " Tepung crispy"
- "8 sdm tepung terigu"
- "3 sdm tepung maizena"
- "1/2 sdt garam"
- " Bumbu saus"
- "5 buah cabe merah keriting cincang kasar"
- "Sesuai selera cabe rawit cincang kasar"
- "1 siung bawang bombay ukuran besar potong2 kecil"
- "5 sdm saus tomat  2 buah tomat haluskan dgn sedikit air"
- "1,5 sdm saus tiram"
- "1 sdm saus hot lava optional"
- "1 sdm perasan jeruk lemon"
- "Sedikit zest jeruk lemon"
- "1 sdm gula"
- "Secukupnya garam"
- "Secukupnya minyak"
- "Sedikit air"
recipeinstructions:
- "Campurkan ayam dgn seluruh bahan2 marinasi, marinasi ayam min 20 menit."
- "Campurkan semua bahan tepung crispy, baluri ayam dgn tepung hingga rata (terus bolak balik), goreng ayam hingga matang &amp; kecoklatan, tiriskan"
- "Tumis bawang bombay, cabe keriting &amp; cabe rawit hingga wangi. Masukkan seluruh sisa bahan saus. Aduk2 hingga mengental."
- "Masukkan ayam satu persatu, sambil diaduk hingga ayam terbaluti saus. Sajikan.. happy cooking! 😊"
categories:
- Resep
tags:
- ayam
- paha
- crispy

katakunci: ayam paha crispy 
nutrition: 160 calories
recipecuisine: Indonesian
preptime: "PT27M"
cooktime: "PT30M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Paha Crispy Pedas Asam Lemon / Spicy &amp; Lemon Sauce](https://img-global.cpcdn.com/recipes/38b423589f432354/680x482cq70/ayam-paha-crispy-pedas-asam-lemon-spicy-lemon-sauce-foto-resep-utama.jpg)

Andai kita seorang ibu, menyuguhkan santapan sedap kepada keluarga adalah suatu hal yang menggembirakan untuk anda sendiri. Kewajiban seorang  wanita bukan cuman mengurus rumah saja, tetapi anda juga wajib memastikan kebutuhan nutrisi tercukupi dan juga santapan yang dikonsumsi orang tercinta mesti enak.

Di zaman  sekarang, anda sebenarnya bisa membeli masakan yang sudah jadi meski tidak harus repot memasaknya terlebih dahulu. Namun banyak juga lho orang yang memang mau memberikan hidangan yang terbaik untuk keluarganya. Pasalnya, menyajikan masakan yang dibuat sendiri akan jauh lebih higienis dan bisa menyesuaikan masakan tersebut sesuai dengan selera famili. 



Mungkinkah anda salah satu penikmat ayam paha crispy pedas asam lemon / spicy &amp; lemon sauce?. Tahukah kamu, ayam paha crispy pedas asam lemon / spicy &amp; lemon sauce adalah sajian khas di Indonesia yang saat ini disukai oleh setiap orang di hampir setiap daerah di Nusantara. Kamu bisa membuat ayam paha crispy pedas asam lemon / spicy &amp; lemon sauce kreasi sendiri di rumah dan pasti jadi hidangan kesenanganmu di akhir pekanmu.

Kalian tidak usah bingung jika kamu ingin menyantap ayam paha crispy pedas asam lemon / spicy &amp; lemon sauce, lantaran ayam paha crispy pedas asam lemon / spicy &amp; lemon sauce sangat mudah untuk didapatkan dan kita pun dapat memasaknya sendiri di rumah. ayam paha crispy pedas asam lemon / spicy &amp; lemon sauce boleh diolah memalui berbagai cara. Kini pun sudah banyak resep modern yang menjadikan ayam paha crispy pedas asam lemon / spicy &amp; lemon sauce lebih lezat.

Resep ayam paha crispy pedas asam lemon / spicy &amp; lemon sauce juga gampang sekali dibuat, lho. Kita tidak usah capek-capek untuk memesan ayam paha crispy pedas asam lemon / spicy &amp; lemon sauce, lantaran Kalian bisa menyiapkan sendiri di rumah. Bagi Kita yang ingin mencobanya, dibawah ini merupakan cara membuat ayam paha crispy pedas asam lemon / spicy &amp; lemon sauce yang mantab yang dapat Kita coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Ayam Paha Crispy Pedas Asam Lemon / Spicy &amp; Lemon Sauce:

1. Ambil 750 gr ayam (bag paha, blh ganti dgn wings / bag sesuai selera)
1. Ambil  Bahan marinasi:
1. Ambil 3 siung bawang putih (parut)
1. Siapkan 1/2 sdm kecap asin / garam
1. Sediakan 1 sdt perasan lemon
1. Sediakan 1 sdt lada bubuk
1. Ambil  Tepung crispy:
1. Gunakan 8 sdm tepung terigu
1. Ambil 3 sdm tepung maizena
1. Ambil 1/2 sdt garam
1. Siapkan  Bumbu saus:
1. Ambil 5 buah cabe merah keriting (cincang kasar)
1. Siapkan Sesuai selera cabe rawit (cincang kasar)
1. Siapkan 1 siung bawang bombay (ukuran besar, potong2 kecil)
1. Siapkan 5 sdm saus tomat / 2 buah tomat (haluskan dgn sedikit air)
1. Sediakan 1,5 sdm saus tiram
1. Siapkan 1 sdm saus hot lava (optional)
1. Sediakan 1 sdm perasan jeruk lemon
1. Siapkan Sedikit zest jeruk lemon
1. Sediakan 1 sdm gula
1. Siapkan Secukupnya garam
1. Gunakan Secukupnya minyak
1. Gunakan Sedikit air




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Paha Crispy Pedas Asam Lemon / Spicy &amp; Lemon Sauce:

1. Campurkan ayam dgn seluruh bahan2 marinasi, marinasi ayam min 20 menit.
1. Campurkan semua bahan tepung crispy, baluri ayam dgn tepung hingga rata (terus bolak balik), goreng ayam hingga matang &amp; kecoklatan, tiriskan
1. Tumis bawang bombay, cabe keriting &amp; cabe rawit hingga wangi. Masukkan seluruh sisa bahan saus. Aduk2 hingga mengental.
1. Masukkan ayam satu persatu, sambil diaduk hingga ayam terbaluti saus. Sajikan.. happy cooking! 😊




Ternyata resep ayam paha crispy pedas asam lemon / spicy &amp; lemon sauce yang enak sederhana ini mudah sekali ya! Semua orang dapat membuatnya. Cara Membuat ayam paha crispy pedas asam lemon / spicy &amp; lemon sauce Cocok banget buat anda yang baru belajar memasak atau juga bagi anda yang sudah pandai memasak.

Tertarik untuk mencoba membikin resep ayam paha crispy pedas asam lemon / spicy &amp; lemon sauce mantab sederhana ini? Kalau kamu tertarik, ayo kamu segera menyiapkan alat-alat dan bahan-bahannya, lantas buat deh Resep ayam paha crispy pedas asam lemon / spicy &amp; lemon sauce yang nikmat dan tidak rumit ini. Benar-benar taidak sulit kan. 

Jadi, ketimbang kita berfikir lama-lama, ayo kita langsung buat resep ayam paha crispy pedas asam lemon / spicy &amp; lemon sauce ini. Dijamin anda tiidak akan nyesel sudah buat resep ayam paha crispy pedas asam lemon / spicy &amp; lemon sauce nikmat sederhana ini! Selamat mencoba dengan resep ayam paha crispy pedas asam lemon / spicy &amp; lemon sauce mantab simple ini di tempat tinggal kalian sendiri,oke!.

