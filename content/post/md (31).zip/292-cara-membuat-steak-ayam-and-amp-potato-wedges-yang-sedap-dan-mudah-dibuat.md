---
description: "Cara membuat Steak ayam &amp;amp; potato wedges yang sedap dan Mudah Dibuat"
title: "Cara membuat Steak ayam &amp;amp; potato wedges yang sedap dan Mudah Dibuat"
slug: 292-cara-membuat-steak-ayam-and-amp-potato-wedges-yang-sedap-dan-mudah-dibuat
date: 2021-05-22T10:32:39.979Z
image: https://img-global.cpcdn.com/recipes/b7e0b031e5112eba/680x482cq70/steak-ayam-potato-wedges-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b7e0b031e5112eba/680x482cq70/steak-ayam-potato-wedges-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b7e0b031e5112eba/680x482cq70/steak-ayam-potato-wedges-foto-resep-utama.jpg
author: Myrtle Turner
ratingvalue: 3.5
reviewcount: 11
recipeingredient:
- " Bahansteak ayam"
- "1/4 kg ayam fillet"
- " Bahan A marinasi"
- "1/2 sdt garam"
- "2 bawang putih haluskan"
- "1/2 sdt lada"
- "1/2 jeruk nipis"
- " Bahan B basah"
- "1 butir telur"
- " Bahan C kering"
- "2 sdm maizena"
- "6 sdm tepung bumbu serbaguna"
- "  bahan potato wedges"
- "1 buah kentang iris sesuai gambar"
- " Bahan D rebus kentang"
- "1 bawang putih geprek dan cincang"
- "Secukupnya garam"
- "Secukupnya lada"
- " Bahan E kering"
- "1 sdm maizena"
- "1 sdm tepung bumbu"
- "1/2 sdm nori boncabe  oregano sledri"
- " bahan saus"
- "1/4 bawang bombay cincang"
- "2 bawang putih ukuran sedang cincang"
- "4 bawang merah ukuran sedang cincang"
- "1 buah tomat ukuran besar rebus hingga empuk"
- "1 sdt pala"
- "1 sdm saori tiram"
- "1 sdt kecap"
- "1 sdt saus tomat"
- "1 sdt saus pedas"
- "Secukupnya garam"
- "Secukupnya lada"
- "Secukupnya masako"
- "Secukupnya gula"
- "1 sdm maizena campur air"
- "Secukupnya air"
recipeinstructions:
- "Pertama, Marinasi ayam fillet dengan bumbu A diamkan dalam kulkas/ frezeer."
- "Kedua. Sembari menunggu marinasi. Rebus kentang udah di iris-iris dan masukan bumbu D, rebus 8 menit dan tiriskan. Lalu lumuri kentang dengan bahan E. Dan simpan dalam frezeer."
- "Ketiga, masak saus. Siapkan semua bahan saus. Rebus tomat hingga empuk lalu iris2. Tumis bawang bombay hingga layu lalu masukan bawang merah dan bawang putih hingga wangi dan layu lalu masukan pala, tomat, saori, kecap, saus pedas dan tomat aduk aduk hingga tercampur lalu masukan air tunggu hingga mendidih, lalu masukan larutan maizena dan tunggu blubuk-blubuk. Test rasa."
- "Keempat. Kluarkan fillet ayam dan lumuri dengan bahan B dan C, cubit cubit adonan lalu goreng."
- "Kelima. Kluarkan kentang lalu goreng di minyak jgn terlalu panas 3 menit tiriskan, lalu goreng lg di minya panas hingga kering. Lalu angkat"
- "Sudah siap"
categories:
- Resep
tags:
- steak
- ayam
- 

katakunci: steak ayam  
nutrition: 128 calories
recipecuisine: Indonesian
preptime: "PT33M"
cooktime: "PT34M"
recipeyield: "1"
recipecategory: Lunch

---


![Steak ayam &amp; potato wedges](https://img-global.cpcdn.com/recipes/b7e0b031e5112eba/680x482cq70/steak-ayam-potato-wedges-foto-resep-utama.jpg)

Sebagai seorang wanita, menyediakan hidangan mantab pada orang tercinta merupakan hal yang menyenangkan bagi anda sendiri. Tanggung jawab seorang istri Tidak sekadar mengatur rumah saja, tapi kamu pun wajib memastikan kebutuhan nutrisi tercukupi dan olahan yang dikonsumsi orang tercinta mesti nikmat.

Di waktu  sekarang, anda memang dapat memesan hidangan jadi meski tanpa harus susah mengolahnya lebih dulu. Tetapi ada juga lho mereka yang memang mau menghidangkan yang terlezat untuk orang tercintanya. Sebab, memasak yang dibuat sendiri jauh lebih bersih dan bisa menyesuaikan hidangan tersebut sesuai kesukaan keluarga tercinta. 



Apakah anda merupakan salah satu penyuka steak ayam &amp; potato wedges?. Asal kamu tahu, steak ayam &amp; potato wedges adalah sajian khas di Indonesia yang kini disenangi oleh orang-orang dari berbagai wilayah di Indonesia. Anda bisa memasak steak ayam &amp; potato wedges sendiri di rumah dan boleh jadi makanan kesukaanmu di akhir pekanmu.

Anda tidak perlu bingung jika kamu ingin mendapatkan steak ayam &amp; potato wedges, lantaran steak ayam &amp; potato wedges gampang untuk ditemukan dan juga kamu pun dapat membuatnya sendiri di tempatmu. steak ayam &amp; potato wedges boleh dibuat lewat berbagai cara. Kini pun ada banyak sekali cara modern yang membuat steak ayam &amp; potato wedges semakin lebih enak.

Resep steak ayam &amp; potato wedges pun sangat gampang dibikin, lho. Kalian tidak usah capek-capek untuk membeli steak ayam &amp; potato wedges, karena Kamu mampu membuatnya sendiri di rumah. Untuk Kita yang mau menyajikannya, berikut ini resep untuk membuat steak ayam &amp; potato wedges yang mantab yang mampu Kita buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Steak ayam &amp; potato wedges:

1. Sediakan  ✨Bahansteak ayam
1. Ambil 1/4 kg ayam fillet
1. Sediakan  Bahan A (marinasi)
1. Ambil 1/2 sdt garam
1. Ambil 2 bawang putih haluskan
1. Gunakan 1/2 sdt lada
1. Gunakan 1/2 jeruk nipis
1. Gunakan  Bahan B (basah)
1. Sediakan 1 butir telur
1. Sediakan  Bahan C (kering)
1. Gunakan 2 sdm maizena
1. Ambil 6 sdm tepung bumbu serbaguna
1. Gunakan  ✨ bahan potato wedges
1. Siapkan 1 buah kentang iris sesuai gambar
1. Gunakan  Bahan D (rebus kentang)
1. Siapkan 1 bawang putih geprek dan cincang
1. Siapkan Secukupnya garam
1. Ambil Secukupnya lada
1. Gunakan  Bahan E (kering)
1. Sediakan 1 sdm maizena
1. Siapkan 1 sdm tepung bumbu
1. Ambil 1/2 sdm nori boncabe / oregano/ sledri
1. Siapkan  ✨bahan saus
1. Sediakan 1/4 bawang bombay cincang
1. Gunakan 2 bawang putih ukuran sedang cincang
1. Siapkan 4 bawang merah ukuran sedang cincang
1. Ambil 1 buah tomat ukuran besar rebus hingga empuk
1. Sediakan 1 sdt pala
1. Ambil 1 sdm saori tiram
1. Ambil 1 sdt kecap
1. Siapkan 1 sdt saus tomat
1. Sediakan 1 sdt saus pedas
1. Gunakan Secukupnya garam
1. Ambil Secukupnya lada
1. Gunakan Secukupnya masako
1. Ambil Secukupnya gula
1. Sediakan 1 sdm maizena campur air
1. Siapkan Secukupnya air




<!--inarticleads2-->

##### Langkah-langkah membuat Steak ayam &amp; potato wedges:

1. Pertama, Marinasi ayam fillet dengan bumbu A diamkan dalam kulkas/ frezeer.
1. Kedua. Sembari menunggu marinasi. Rebus kentang udah di iris-iris dan masukan bumbu D, rebus 8 menit dan tiriskan. Lalu lumuri kentang dengan bahan E. Dan simpan dalam frezeer.
1. Ketiga, masak saus. Siapkan semua bahan saus. Rebus tomat hingga empuk lalu iris2. Tumis bawang bombay hingga layu lalu masukan bawang merah dan bawang putih hingga wangi dan layu lalu masukan pala, tomat, saori, kecap, saus pedas dan tomat aduk aduk hingga tercampur lalu masukan air tunggu hingga mendidih, lalu masukan larutan maizena dan tunggu blubuk-blubuk. Test rasa.
1. Keempat. Kluarkan fillet ayam dan lumuri dengan bahan B dan C, cubit cubit adonan lalu goreng.
1. Kelima. Kluarkan kentang lalu goreng di minyak jgn terlalu panas 3 menit tiriskan, lalu goreng lg di minya panas hingga kering. Lalu angkat
1. Sudah siap




Wah ternyata resep steak ayam &amp; potato wedges yang enak tidak rumit ini gampang banget ya! Kalian semua bisa memasaknya. Cara Membuat steak ayam &amp; potato wedges Sesuai banget untuk anda yang baru akan belajar memasak maupun juga bagi kamu yang telah ahli memasak.

Apakah kamu mau mulai mencoba membikin resep steak ayam &amp; potato wedges mantab simple ini? Kalau kamu ingin, ayo kamu segera buruan menyiapkan alat-alat dan bahan-bahannya, maka bikin deh Resep steak ayam &amp; potato wedges yang nikmat dan sederhana ini. Sungguh gampang kan. 

Jadi, ketimbang kalian diam saja, ayo langsung aja sajikan resep steak ayam &amp; potato wedges ini. Dijamin kamu tiidak akan menyesal sudah buat resep steak ayam &amp; potato wedges nikmat simple ini! Selamat mencoba dengan resep steak ayam &amp; potato wedges mantab tidak rumit ini di tempat tinggal sendiri,oke!.

