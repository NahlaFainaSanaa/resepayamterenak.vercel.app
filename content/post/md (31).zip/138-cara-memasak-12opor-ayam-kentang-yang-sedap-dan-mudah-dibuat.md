---
description: "Cara memasak 12.Opor ayam kentang yang sedap dan Mudah Dibuat"
title: "Cara memasak 12.Opor ayam kentang yang sedap dan Mudah Dibuat"
slug: 138-cara-memasak-12opor-ayam-kentang-yang-sedap-dan-mudah-dibuat
date: 2021-03-12T04:06:48.653Z
image: https://img-global.cpcdn.com/recipes/099fcfc4b46bf0b2/680x482cq70/12opor-ayam-kentang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/099fcfc4b46bf0b2/680x482cq70/12opor-ayam-kentang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/099fcfc4b46bf0b2/680x482cq70/12opor-ayam-kentang-foto-resep-utama.jpg
author: Belle Burton
ratingvalue: 3.1
reviewcount: 15
recipeingredient:
- "1/2 ekor ayam potongpotong lalu cuci bersih"
- "3 buah kentang potongpotong sesuai selera"
- "500 ml air"
- "500 ml santan resep asli 1 liter santan"
- "2 lembar daun salam"
- "1 batang sereh geprek"
- "1 ruas lengkuas geprek"
- "Secukupnya garam"
- "Secukupnya kaldu bubuk"
- "Secukupnya gula pasir"
- " Bawang goreng untuk taburan"
- " Bumbu halus "
- "5 siung bawang merah"
- "3 siung bawang putih"
- "1 ruas kunyit"
- "1 ruas jahe"
- "3 butir kemiri"
- "1/2 sdt ketumbar"
- "1/2 sdt merica"
recipeinstructions:
- "Siapkan semua bahan"
- "Haluskan bumbu halus dan tumis, masukkan daun salam,sereh dan lengkuas,masak sampai harum.masukkan ayam masak,masak ayam sampai berubah warna"
- "Tambahkan air.masak sampai mendidih,masukkan kentang, tambahkan garam, gula pasir dan kaldu bubuk.aduk rata.masak sampai ayam empuk.masukkan santan,aduk-aduk sampai mendidih dan matang."
- "Sajikan dengan taburan bawang goreng."
categories:
- Resep
tags:
- 12opor
- ayam
- kentang

katakunci: 12opor ayam kentang 
nutrition: 122 calories
recipecuisine: Indonesian
preptime: "PT21M"
cooktime: "PT44M"
recipeyield: "3"
recipecategory: Dinner

---


![12.Opor ayam kentang](https://img-global.cpcdn.com/recipes/099fcfc4b46bf0b2/680x482cq70/12opor-ayam-kentang-foto-resep-utama.jpg)

Selaku seorang orang tua, menyediakan panganan sedap pada orang tercinta adalah suatu hal yang sangat menyenangkan bagi kamu sendiri. Kewajiban seorang istri Tidak cuman menjaga rumah saja, tapi kamu pun harus menyediakan kebutuhan gizi terpenuhi dan santapan yang dimakan keluarga tercinta harus menggugah selera.

Di zaman  saat ini, kita memang mampu mengorder panganan jadi meski tanpa harus capek mengolahnya terlebih dahulu. Namun banyak juga mereka yang memang mau memberikan hidangan yang terenak untuk orang tercintanya. Sebab, memasak yang dibuat sendiri jauh lebih bersih dan bisa menyesuaikan masakan tersebut sesuai dengan makanan kesukaan famili. 

Ketika lebaran tiba, opor ayam bumbu kuning merupakan salah satu sajian yang banyak dihidangkan. Bagi sebagian masyarakat Indonesia memang kurang afdol apabila berlebaran tanpa ada hidangan opor ayam di rumah. Opor ayam merupakan masakan berkuah santan kental berwarna kekuningan.

Apakah anda salah satu penyuka 12.opor ayam kentang?. Asal kamu tahu, 12.opor ayam kentang merupakan hidangan khas di Nusantara yang sekarang digemari oleh kebanyakan orang dari hampir setiap tempat di Nusantara. Kamu bisa menghidangkan 12.opor ayam kentang sendiri di rumahmu dan pasti jadi makanan favorit di hari libur.

Anda tidak perlu bingung untuk memakan 12.opor ayam kentang, sebab 12.opor ayam kentang gampang untuk dicari dan juga anda pun boleh memasaknya sendiri di tempatmu. 12.opor ayam kentang boleh diolah memalui bermacam cara. Saat ini telah banyak sekali cara kekinian yang membuat 12.opor ayam kentang semakin lebih mantap.

Resep 12.opor ayam kentang juga mudah dihidangkan, lho. Kamu jangan ribet-ribet untuk membeli 12.opor ayam kentang, tetapi Kamu bisa membuatnya di rumah sendiri. Untuk Kita yang hendak mencobanya, di bawah ini adalah cara membuat 12.opor ayam kentang yang mantab yang dapat Kamu coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan 12.Opor ayam kentang:

1. Gunakan 1/2 ekor ayam, potong-potong lalu cuci bersih
1. Ambil 3 buah kentang, potong-potong sesuai selera
1. Siapkan 500 ml air
1. Siapkan 500 ml santan (resep asli 1 liter santan)
1. Sediakan 2 lembar daun salam
1. Gunakan 1 batang sereh, geprek
1. Siapkan 1 ruas lengkuas, geprek
1. Siapkan Secukupnya garam
1. Siapkan Secukupnya kaldu bubuk
1. Siapkan Secukupnya gula pasir
1. Sediakan  Bawang goreng untuk taburan
1. Gunakan  Bumbu halus :
1. Siapkan 5 siung bawang merah
1. Gunakan 3 siung bawang putih
1. Gunakan 1 ruas kunyit
1. Siapkan 1 ruas jahe
1. Ambil 3 butir kemiri
1. Gunakan 1/2 sdt ketumbar
1. Ambil 1/2 sdt merica


Suara.com - Hari Raya Idulfitri segera hadir. Berbagai persiapan pun telah dilakukan untuk menyambut hari kemenangan tersebut, termasuk menu wajib Lebaran seperti opor. Resep opor ayam dari detikFood ini bisa jadi referensi para Bunda untuk menyiapkan menu Lebaran. Ada yang pakai santan dan juga tanpa santan. 

<!--inarticleads2-->

##### Langkah-langkah menyiapkan 12.Opor ayam kentang:

1. Siapkan semua bahan
1. Haluskan bumbu halus dan tumis, masukkan daun salam,sereh dan lengkuas,masak sampai harum.masukkan ayam masak,masak ayam sampai berubah warna
1. Tambahkan air.masak sampai mendidih,masukkan kentang, tambahkan garam, gula pasir dan kaldu bubuk.aduk rata.masak sampai ayam empuk.masukkan santan,aduk-aduk sampai mendidih dan matang.
1. Sajikan dengan taburan bawang goreng.


Cuci bersih dan tiriskan hingga kering. Bumbu: Tumbuk atau giling semua bahan bumbu hingga halus. Resep Opor Ayam dengan panduan cara memasak Opor Ayam ala Dapur Cantik. Masukkan ayam, telur rebus dan kentang. Setelah ayamnya berubah warna baru masukkan santan. 

Wah ternyata cara buat 12.opor ayam kentang yang mantab sederhana ini gampang sekali ya! Semua orang mampu menghidangkannya. Resep 12.opor ayam kentang Sangat cocok sekali buat kalian yang baru mau belajar memasak atau juga bagi kamu yang telah hebat dalam memasak.

Tertarik untuk mulai mencoba bikin resep 12.opor ayam kentang mantab sederhana ini? Kalau mau, ayo kalian segera siapin peralatan dan bahannya, lalu bikin deh Resep 12.opor ayam kentang yang nikmat dan tidak ribet ini. Sungguh gampang kan. 

Maka, daripada kamu diam saja, hayo langsung aja hidangkan resep 12.opor ayam kentang ini. Dijamin kamu tiidak akan menyesal sudah buat resep 12.opor ayam kentang nikmat tidak rumit ini! Selamat mencoba dengan resep 12.opor ayam kentang mantab tidak ribet ini di rumah masing-masing,ya!.

