---
description: "Cara memasak Ayam Bakar Wong Solo yang lezat dan Mudah Dibuat"
title: "Cara memasak Ayam Bakar Wong Solo yang lezat dan Mudah Dibuat"
slug: 303-cara-memasak-ayam-bakar-wong-solo-yang-lezat-dan-mudah-dibuat
date: 2021-05-18T19:15:58.886Z
image: https://img-global.cpcdn.com/recipes/8d15e5b63f3bf116/680x482cq70/ayam-bakar-wong-solo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8d15e5b63f3bf116/680x482cq70/ayam-bakar-wong-solo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8d15e5b63f3bf116/680x482cq70/ayam-bakar-wong-solo-foto-resep-utama.jpg
author: Bill Figueroa
ratingvalue: 3.4
reviewcount: 7
recipeingredient:
- "1.5 kg ayam potong"
- " Bumbu Ungkep Untuk Bakaran "
- "8 bawang merah"
- "5 bawang putih"
- "30 gr gula merah"
- "2 sdm margarin"
- "30 ml minyak sayur"
- "1/2 sdt garam"
- "1/2 sdt lada bubuk"
- "sedikit air"
- "secukupnya kecap manis"
- " Bahan Sambal Manis "
- "15 cabe merah keriting"
- "9 bawang merah"
- "3 bawang putih"
- "5 gr gula merah"
- "1/2 jempol terasi bakar"
- "1 buah tomat"
- "1/4 sdt garam"
- "1 sdt gulapasir"
- "15 ml air"
- "20 ml minyak goreng"
recipeinstructions:
- "Terlebih dahulu ungkep ayam dgn bumbu dasar kuning hingga ayam matang. (resep pake andalan masing2 ya)"
- "Bumbu Bakaran : haluskan bawang merah + putih dgn margarin. tumis hingga harum. masukkan air + gula merah + garam + lada bubuk. masak hingga air menyusut dan bumbu kental.  ▫️pindahkan bumbu bakaran ke wadah, tambahkan minyak + kecap manis."
- "Ambil ayam. oles dgn bumbu bakaran beberapa kali. bakar diatas teflon."
- "Sambal Manis : haluskan cabe + duo bawang + terasi. ▫️tumis bumbu halus hingga harum, tambahkan tomat + gula pasir + garam + air. masak hingga air menyusut. sajikan dgn ayam bakar + lalapan 😋"
categories:
- Resep
tags:
- ayam
- bakar
- wong

katakunci: ayam bakar wong 
nutrition: 158 calories
recipecuisine: Indonesian
preptime: "PT17M"
cooktime: "PT40M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam Bakar Wong Solo](https://img-global.cpcdn.com/recipes/8d15e5b63f3bf116/680x482cq70/ayam-bakar-wong-solo-foto-resep-utama.jpg)

Selaku seorang istri, menyajikan masakan menggugah selera untuk keluarga tercinta merupakan suatu hal yang menyenangkan untuk kita sendiri. Kewajiban seorang  wanita bukan hanya mengurus rumah saja, namun kamu pun wajib memastikan keperluan nutrisi terpenuhi dan panganan yang disantap anak-anak mesti mantab.

Di waktu  saat ini, anda sebenarnya dapat memesan olahan instan walaupun tanpa harus ribet membuatnya dahulu. Namun ada juga lho mereka yang memang mau memberikan yang terlezat bagi orang tercintanya. Sebab, menghidangkan masakan yang diolah sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan masakan tersebut sesuai dengan kesukaan keluarga tercinta. 



Mungkinkah anda adalah salah satu penikmat ayam bakar wong solo?. Asal kamu tahu, ayam bakar wong solo adalah sajian khas di Nusantara yang sekarang digemari oleh orang-orang di berbagai tempat di Indonesia. Kita bisa menyajikan ayam bakar wong solo kreasi sendiri di rumah dan boleh dijadikan makanan kesenanganmu di hari liburmu.

Kamu tidak usah bingung untuk mendapatkan ayam bakar wong solo, lantaran ayam bakar wong solo mudah untuk dicari dan juga kalian pun dapat membuatnya sendiri di tempatmu. ayam bakar wong solo bisa dimasak lewat berbagai cara. Sekarang sudah banyak resep modern yang membuat ayam bakar wong solo semakin nikmat.

Resep ayam bakar wong solo juga sangat gampang dibikin, lho. Kamu tidak usah ribet-ribet untuk memesan ayam bakar wong solo, tetapi Kita mampu menyajikan sendiri di rumah. Bagi Anda yang mau menghidangkannya, inilah resep untuk membuat ayam bakar wong solo yang mantab yang mampu Anda hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Ayam Bakar Wong Solo:

1. Gunakan 1.5 kg ayam potong
1. Sediakan  Bumbu Ungkep Untuk Bakaran :
1. Sediakan 8 bawang merah
1. Sediakan 5 bawang putih
1. Siapkan 30 gr gula merah
1. Ambil 2 sdm margarin
1. Siapkan 30 ml minyak sayur
1. Siapkan 1/2 sdt garam
1. Siapkan 1/2 sdt lada bubuk
1. Gunakan sedikit air
1. Siapkan secukupnya kecap manis
1. Siapkan  Bahan Sambal Manis :
1. Sediakan 15 cabe merah keriting
1. Gunakan 9 bawang merah
1. Gunakan 3 bawang putih
1. Gunakan 5 gr gula merah
1. Ambil 1/2 jempol terasi bakar
1. Gunakan 1 buah tomat
1. Sediakan 1/4 sdt garam
1. Ambil 1 sdt gulapasir
1. Ambil 15 ml air
1. Gunakan 20 ml minyak goreng




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Bakar Wong Solo:

1. Terlebih dahulu ungkep ayam dgn bumbu dasar kuning hingga ayam matang. (resep pake andalan masing2 ya)
1. Bumbu Bakaran : haluskan bawang merah + putih dgn margarin. tumis hingga harum. masukkan air + gula merah + garam + lada bubuk. masak hingga air menyusut dan bumbu kental.  - ▫️pindahkan bumbu bakaran ke wadah, tambahkan minyak + kecap manis.
1. Ambil ayam. oles dgn bumbu bakaran beberapa kali. bakar diatas teflon.
1. Sambal Manis : haluskan cabe + duo bawang + terasi. - ▫️tumis bumbu halus hingga harum, tambahkan tomat + gula pasir + garam + air. masak hingga air menyusut. sajikan dgn ayam bakar + lalapan 😋




Wah ternyata cara membuat ayam bakar wong solo yang enak sederhana ini mudah sekali ya! Semua orang bisa menghidangkannya. Cara Membuat ayam bakar wong solo Sesuai sekali untuk anda yang baru belajar memasak ataupun bagi kalian yang telah pandai memasak.

Tertarik untuk mencoba membuat resep ayam bakar wong solo lezat tidak rumit ini? Kalau kalian ingin, yuk kita segera buruan siapkan alat-alat dan bahan-bahannya, kemudian buat deh Resep ayam bakar wong solo yang lezat dan simple ini. Betul-betul mudah kan. 

Oleh karena itu, ketimbang anda berlama-lama, hayo kita langsung saja buat resep ayam bakar wong solo ini. Pasti anda tiidak akan nyesel sudah bikin resep ayam bakar wong solo mantab simple ini! Selamat mencoba dengan resep ayam bakar wong solo lezat simple ini di tempat tinggal masing-masing,oke!.

