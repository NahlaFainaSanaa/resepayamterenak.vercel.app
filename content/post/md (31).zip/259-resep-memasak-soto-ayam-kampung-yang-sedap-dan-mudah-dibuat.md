---
description: "Resep memasak Soto Ayam Kampung yang sedap dan Mudah Dibuat"
title: "Resep memasak Soto Ayam Kampung yang sedap dan Mudah Dibuat"
slug: 259-resep-memasak-soto-ayam-kampung-yang-sedap-dan-mudah-dibuat
date: 2021-02-21T09:29:37.271Z
image: https://img-global.cpcdn.com/recipes/8d6feeac44a846be/680x482cq70/soto-ayam-kampung-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8d6feeac44a846be/680x482cq70/soto-ayam-kampung-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8d6feeac44a846be/680x482cq70/soto-ayam-kampung-foto-resep-utama.jpg
author: Patrick Fowler
ratingvalue: 3.1
reviewcount: 12
recipeingredient:
- "10 potong ayam"
- "5 siung bawang putih"
- "8 siung bawang merah"
- "1 ruas kunir"
- "1/2 ruas laos"
- "1/2 ruas jahe"
- "1 sdt merica"
- "1 sdt ketumbar"
- "3 butir kemiri"
- "1/2 sdt jinten"
- "2 lbr daun jeruk"
- " bawang pre"
- " bawang putih goreng"
- " serai"
- " minyak"
- " garam gula penyedap rasa"
recipeinstructions:
- "Blender semua bumbu (bawang putih, bawang merah, jahe, laos, kunir, ketumbar, jinten, merica, kemiri)"
- "Tumis bumbu yang sudah d blender, lalu masukkan sereh geprek dan 2 lbr daun jeruk dan tunggu sampai layu"
- "Didihkan air dan rebus ayam sampai setengah matang"
- "Setelah ayam mendidih masukkan bumbu yang sudah ditumis kedalam panci"
- "Tambahkan garam, gula penyedap rasa, dan tutup panci tunggu hingga 15 menit"
- "Setelah akan disajikan taburkan bawang putih goreng dan bawang pre"
- "Jangan lupa koreksi rasa sebelum disajikan"
categories:
- Resep
tags:
- soto
- ayam
- kampung

katakunci: soto ayam kampung 
nutrition: 159 calories
recipecuisine: Indonesian
preptime: "PT21M"
cooktime: "PT48M"
recipeyield: "2"
recipecategory: Dessert

---


![Soto Ayam Kampung](https://img-global.cpcdn.com/recipes/8d6feeac44a846be/680x482cq70/soto-ayam-kampung-foto-resep-utama.jpg)

Andai kalian seorang orang tua, menyuguhkan masakan lezat pada keluarga tercinta merupakan suatu hal yang membahagiakan untuk anda sendiri. Peran seorang  wanita Tidak cuma menangani rumah saja, tapi kamu juga wajib memastikan kebutuhan gizi tercukupi dan santapan yang disantap orang tercinta harus sedap.

Di waktu  sekarang, kalian sebenarnya dapat memesan santapan siap saji walaupun tanpa harus ribet mengolahnya terlebih dahulu. Namun ada juga mereka yang selalu ingin memberikan hidangan yang terenak untuk orang tercintanya. Pasalnya, menyajikan masakan yang dibuat sendiri jauh lebih higienis dan bisa menyesuaikan hidangan tersebut berdasarkan selera orang tercinta. 



Mungkinkah kamu salah satu penyuka soto ayam kampung?. Asal kamu tahu, soto ayam kampung merupakan hidangan khas di Indonesia yang sekarang digemari oleh orang-orang di berbagai tempat di Indonesia. Anda bisa membuat soto ayam kampung kreasi sendiri di rumahmu dan pasti jadi makanan kesenanganmu di akhir pekan.

Kalian jangan bingung jika kamu ingin menyantap soto ayam kampung, sebab soto ayam kampung tidak sulit untuk dicari dan juga kamu pun boleh membuatnya sendiri di tempatmu. soto ayam kampung boleh dimasak lewat beragam cara. Kini telah banyak sekali resep kekinian yang membuat soto ayam kampung lebih mantap.

Resep soto ayam kampung pun gampang untuk dibikin, lho. Anda tidak usah ribet-ribet untuk memesan soto ayam kampung, tetapi Anda mampu menyiapkan sendiri di rumah. Untuk Kita yang hendak menyajikannya, inilah resep untuk menyajikan soto ayam kampung yang lezat yang dapat Kita hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Soto Ayam Kampung:

1. Ambil 10 potong ayam
1. Siapkan 5 siung bawang putih
1. Ambil 8 siung bawang merah
1. Siapkan 1 ruas kunir
1. Siapkan 1/2 ruas laos
1. Gunakan 1/2 ruas jahe
1. Sediakan 1 sdt merica
1. Gunakan 1 sdt ketumbar
1. Gunakan 3 butir kemiri
1. Ambil 1/2 sdt jinten
1. Ambil 2 lbr daun jeruk
1. Gunakan  bawang pre
1. Ambil  bawang putih goreng
1. Ambil  serai
1. Ambil  minyak
1. Siapkan  garam, gula penyedap rasa




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Soto Ayam Kampung:

1. Blender semua bumbu (bawang putih, bawang merah, jahe, laos, kunir, ketumbar, jinten, merica, kemiri)
1. Tumis bumbu yang sudah d blender, lalu masukkan sereh geprek dan 2 lbr daun jeruk dan tunggu sampai layu
1. Didihkan air dan rebus ayam sampai setengah matang
1. Setelah ayam mendidih masukkan bumbu yang sudah ditumis kedalam panci
1. Tambahkan garam, gula penyedap rasa, dan tutup panci tunggu hingga 15 menit
1. Setelah akan disajikan taburkan bawang putih goreng dan bawang pre
1. Jangan lupa koreksi rasa sebelum disajikan




Ternyata resep soto ayam kampung yang mantab tidak rumit ini enteng banget ya! Kalian semua bisa menghidangkannya. Resep soto ayam kampung Sangat sesuai sekali buat kamu yang baru belajar memasak ataupun bagi anda yang telah ahli memasak.

Apakah kamu tertarik mencoba bikin resep soto ayam kampung enak simple ini? Kalau kalian mau, ayo kalian segera buruan menyiapkan alat-alat dan bahan-bahannya, setelah itu bikin deh Resep soto ayam kampung yang nikmat dan simple ini. Sangat taidak sulit kan. 

Jadi, daripada kalian berfikir lama-lama, ayo kita langsung saja hidangkan resep soto ayam kampung ini. Pasti anda tak akan nyesel bikin resep soto ayam kampung enak tidak ribet ini! Selamat berkreasi dengan resep soto ayam kampung lezat tidak rumit ini di rumah masing-masing,ya!.

