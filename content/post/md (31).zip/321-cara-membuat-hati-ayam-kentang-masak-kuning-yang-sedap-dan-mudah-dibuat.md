---
description: "Cara membuat Hati Ayam,Kentang Masak Kuning yang sedap dan Mudah Dibuat"
title: "Cara membuat Hati Ayam,Kentang Masak Kuning yang sedap dan Mudah Dibuat"
slug: 321-cara-membuat-hati-ayam-kentang-masak-kuning-yang-sedap-dan-mudah-dibuat
date: 2021-01-29T22:22:07.974Z
image: https://img-global.cpcdn.com/recipes/8b094f0c06ff4e63/680x482cq70/hati-ayamkentang-masak-kuning-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8b094f0c06ff4e63/680x482cq70/hati-ayamkentang-masak-kuning-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8b094f0c06ff4e63/680x482cq70/hati-ayamkentang-masak-kuning-foto-resep-utama.jpg
author: Danny Williamson
ratingvalue: 3.2
reviewcount: 9
recipeingredient:
- "250 gram hati ayamAmpela"
- "1 buah Kentang"
- "2 lembar daun salam"
- "2 lembar daun jeruk"
- "1 buah tomat"
- "4-5 biji Cabe Rawit"
- "1 sdm Bumbu Dasar kuning           lihat resep"
- "1 sdt garam"
- "1 sdt kaldu jamur"
- "1/2 sdt gula"
- "1 ruas Jahe geprek"
- "1 batang serai geprek"
- "Secukupnya Minyak untuk menumis bumbu"
recipeinstructions:
- "Ungkep hati ayam dengan 1sdt bumbu dasar kuning Tambahkan daun jeruk daun salam tambahkan juga 1sdt garam."
- "Jika sudah angkat tiriskan,potong² hati ayam sesuai selera,tomat dan juga kentang."
- "Goreng kentang yang sudah di potong dadu sebentar saja, angkat sisihkan"
- "Tumis bumbu Dasar kuning hingga harum,masukan daun jeruk,daun salam masukan lagi serai dan jahe geprek aduk rata Masukan potongan hati serta kentang,tambahkan kaldu jamur,dan beri sedikit air aduk rata terakhir masukan potongan tomat."
- "Setelah dirasa cukup matikan kompor."
categories:
- Resep
tags:
- hati
- ayamkentang
- masak

katakunci: hati ayamkentang masak 
nutrition: 128 calories
recipecuisine: Indonesian
preptime: "PT18M"
cooktime: "PT35M"
recipeyield: "4"
recipecategory: Dinner

---


![Hati Ayam,Kentang Masak Kuning](https://img-global.cpcdn.com/recipes/8b094f0c06ff4e63/680x482cq70/hati-ayamkentang-masak-kuning-foto-resep-utama.jpg)

Selaku seorang wanita, mempersiapkan masakan sedap kepada keluarga merupakan hal yang membahagiakan untuk kamu sendiri. Tanggung jawab seorang  wanita bukan sekedar menjaga rumah saja, tapi anda pun harus memastikan keperluan gizi tercukupi dan juga santapan yang dimakan anak-anak mesti nikmat.

Di masa  saat ini, anda memang mampu memesan panganan yang sudah jadi meski tanpa harus ribet memasaknya lebih dulu. Tetapi ada juga lho mereka yang selalu ingin menghidangkan yang terenak bagi orang tercintanya. Sebab, menyajikan masakan yang dibuat sendiri akan jauh lebih bersih dan bisa menyesuaikan berdasarkan kesukaan keluarga tercinta. 



Apakah anda salah satu penggemar hati ayam,kentang masak kuning?. Tahukah kamu, hati ayam,kentang masak kuning merupakan makanan khas di Nusantara yang saat ini disenangi oleh kebanyakan orang di berbagai tempat di Nusantara. Kita dapat menghidangkan hati ayam,kentang masak kuning buatan sendiri di rumahmu dan boleh jadi makanan favoritmu di hari libur.

Kalian tidak perlu bingung untuk mendapatkan hati ayam,kentang masak kuning, lantaran hati ayam,kentang masak kuning gampang untuk ditemukan dan kamu pun boleh memasaknya sendiri di tempatmu. hati ayam,kentang masak kuning bisa dimasak lewat beragam cara. Kini pun telah banyak banget resep modern yang membuat hati ayam,kentang masak kuning semakin lebih mantap.

Resep hati ayam,kentang masak kuning juga mudah sekali dihidangkan, lho. Kalian jangan repot-repot untuk membeli hati ayam,kentang masak kuning, lantaran Kita mampu menghidangkan di rumahmu. Untuk Kamu yang mau menyajikannya, dibawah ini merupakan resep untuk menyajikan hati ayam,kentang masak kuning yang mantab yang bisa Anda buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Hati Ayam,Kentang Masak Kuning:

1. Gunakan 250 gram hati ayam+Ampela
1. Siapkan 1 buah Kentang
1. Sediakan 2 lembar daun salam
1. Sediakan 2 lembar daun jeruk
1. Ambil 1 buah tomat
1. Sediakan 4-5 biji Cabe Rawit
1. Siapkan 1 sdm Bumbu Dasar kuning           (lihat resep)
1. Siapkan 1 sdt garam
1. Sediakan 1 sdt kaldu jamur
1. Ambil 1/2 sdt gula
1. Sediakan 1 ruas Jahe (geprek)
1. Ambil 1 batang serai (geprek)
1. Sediakan Secukupnya Minyak untuk menumis bumbu




<!--inarticleads2-->

##### Cara menyiapkan Hati Ayam,Kentang Masak Kuning:

1. Ungkep hati ayam dengan 1sdt bumbu dasar kuning - Tambahkan daun jeruk daun salam tambahkan juga 1sdt garam.
1. Jika sudah angkat tiriskan,potong² hati ayam sesuai selera,tomat dan juga kentang.
1. Goreng kentang yang sudah di potong dadu sebentar saja, angkat sisihkan
1. Tumis bumbu Dasar kuning hingga harum,masukan daun jeruk,daun salam masukan lagi serai dan jahe geprek aduk rata - Masukan potongan hati serta kentang,tambahkan kaldu jamur,dan beri sedikit air aduk rata terakhir masukan potongan tomat.
1. Setelah dirasa cukup matikan kompor.




Ternyata cara buat hati ayam,kentang masak kuning yang lezat tidak ribet ini enteng banget ya! Semua orang dapat memasaknya. Cara Membuat hati ayam,kentang masak kuning Sangat cocok sekali untuk kamu yang baru mau belajar memasak ataupun juga bagi kalian yang telah hebat memasak.

Apakah kamu ingin mulai mencoba bikin resep hati ayam,kentang masak kuning mantab simple ini? Kalau kalian tertarik, yuk kita segera buruan siapkan alat-alat dan bahan-bahannya, maka bikin deh Resep hati ayam,kentang masak kuning yang enak dan tidak rumit ini. Betul-betul taidak sulit kan. 

Maka, ketimbang kamu diam saja, hayo kita langsung saja buat resep hati ayam,kentang masak kuning ini. Dijamin kalian tak akan menyesal sudah membuat resep hati ayam,kentang masak kuning lezat simple ini! Selamat berkreasi dengan resep hati ayam,kentang masak kuning nikmat simple ini di rumah sendiri,ya!.

