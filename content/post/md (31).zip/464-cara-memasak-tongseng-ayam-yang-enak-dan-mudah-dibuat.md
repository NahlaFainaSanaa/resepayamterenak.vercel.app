---
description: "Cara memasak Tongseng Ayam yang enak dan Mudah Dibuat"
title: "Cara memasak Tongseng Ayam yang enak dan Mudah Dibuat"
slug: 464-cara-memasak-tongseng-ayam-yang-enak-dan-mudah-dibuat
date: 2021-05-28T08:22:42.660Z
image: https://img-global.cpcdn.com/recipes/61bd62d98cd7dba1/680x482cq70/tongseng-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/61bd62d98cd7dba1/680x482cq70/tongseng-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/61bd62d98cd7dba1/680x482cq70/tongseng-ayam-foto-resep-utama.jpg
author: Danny Page
ratingvalue: 4.6
reviewcount: 14
recipeingredient:
- "1/2 kg ayam aku campur sama fillet dada"
- "750 ml air matang"
- "200 gr kol"
- "1 buah tomat ukuran sedang"
- "1 batang daun bawang"
- "10 cabai rawit"
- " Bumbu halus"
- "10 butir bawang merah iris 2 butir"
- "4 bawang putih"
- "1 ruas jahe"
- "1 ruas kunyit"
- "3 butir kemiri"
- "1 sdm ketumbar bubuk"
- " Bahan cemplung"
- "4 lembar daun salam"
- "4 lembar daun jeruk"
- "2 batang serai"
- "2 ruas lengkuas"
- "750 ml air"
- "1 1/2 sdt garam"
- "1 sdt penyedap"
- "Secukupnya kecap"
- "1 sdt gula pasir"
- "25 ml santan"
recipeinstructions:
- "Persiapkan semua bahan"
- "Tumis irisan bawang merah hingga harum"
- "Masukan bumbu halus, beserta bumbu cemplung, tumis hingga matang, berwarna kecoklatan. Kemudian masukan ayam aduk hingga rata"
- "Tuangkan air matang, tunggu higga mendidih kemudian masukan kecap, garam, gula, penyedap aduk rata"
- "Masukan santan dan tunggu air hingga menyusut"
- "Apabil air sudah menyusut, masukan cabai rawit, kol, tomat dan daun bawang. Tunggu hingga sayur agak layu. Tes rasa dan siap di santap"
categories:
- Resep
tags:
- tongseng
- ayam

katakunci: tongseng ayam 
nutrition: 165 calories
recipecuisine: Indonesian
preptime: "PT19M"
cooktime: "PT44M"
recipeyield: "1"
recipecategory: Lunch

---


![Tongseng Ayam](https://img-global.cpcdn.com/recipes/61bd62d98cd7dba1/680x482cq70/tongseng-ayam-foto-resep-utama.jpg)

Andai kamu seorang istri, menyajikan santapan sedap buat keluarga tercinta merupakan suatu hal yang mengasyikan untuk anda sendiri. Peran seorang  wanita Tidak cuman mengerjakan pekerjaan rumah saja, tapi anda juga wajib memastikan keperluan gizi terpenuhi dan panganan yang dikonsumsi orang tercinta wajib nikmat.

Di masa  sekarang, anda sebenarnya bisa mengorder olahan praktis tidak harus susah memasaknya dahulu. Tetapi banyak juga mereka yang memang mau memberikan yang terbaik untuk orang tercintanya. Sebab, menyajikan masakan sendiri jauh lebih bersih dan kita pun bisa menyesuaikan masakan tersebut berdasarkan makanan kesukaan orang tercinta. 



Apakah kamu seorang penyuka tongseng ayam?. Tahukah kamu, tongseng ayam adalah hidangan khas di Indonesia yang kini disenangi oleh banyak orang di hampir setiap wilayah di Nusantara. Kalian bisa memasak tongseng ayam olahan sendiri di rumahmu dan dapat dijadikan camilan favorit di akhir pekan.

Kalian jangan bingung untuk mendapatkan tongseng ayam, sebab tongseng ayam gampang untuk dicari dan juga kamu pun boleh memasaknya sendiri di tempatmu. tongseng ayam dapat dibuat memalui bermacam cara. Saat ini telah banyak banget resep modern yang membuat tongseng ayam lebih nikmat.

Resep tongseng ayam juga mudah sekali dibuat, lho. Kamu tidak perlu ribet-ribet untuk memesan tongseng ayam, tetapi Kamu bisa menyajikan sendiri di rumah. Untuk Anda yang ingin mencobanya, di bawah ini adalah resep untuk membuat tongseng ayam yang lezat yang mampu Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Tongseng Ayam:

1. Gunakan 1/2 kg ayam, aku campur sama fillet dada
1. Siapkan 750 ml air matang
1. Sediakan 200 gr kol
1. Ambil 1 buah tomat ukuran sedang
1. Sediakan 1 batang daun bawang
1. Ambil 10 cabai rawit
1. Ambil  Bumbu halus
1. Siapkan 10 butir bawang merah, iris 2 butir
1. Siapkan 4 bawang putih
1. Sediakan 1 ruas jahe
1. Siapkan 1 ruas kunyit
1. Siapkan 3 butir kemiri
1. Ambil 1 sdm ketumbar bubuk
1. Gunakan  Bahan cemplung
1. Siapkan 4 lembar daun salam
1. Sediakan 4 lembar daun jeruk
1. Gunakan 2 batang serai
1. Sediakan 2 ruas lengkuas
1. Ambil 750 ml air
1. Siapkan 1 1/2 sdt garam
1. Ambil 1 sdt penyedap
1. Gunakan Secukupnya kecap
1. Ambil 1 sdt gula pasir
1. Siapkan 25 ml santan




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Tongseng Ayam:

1. Persiapkan semua bahan
1. Tumis irisan bawang merah hingga harum
1. Masukan bumbu halus, beserta bumbu cemplung, tumis hingga matang, berwarna kecoklatan. Kemudian masukan ayam aduk hingga rata
1. Tuangkan air matang, tunggu higga mendidih kemudian masukan kecap, garam, gula, penyedap aduk rata
1. Masukan santan dan tunggu air hingga menyusut
1. Apabil air sudah menyusut, masukan cabai rawit, kol, tomat dan daun bawang. Tunggu hingga sayur agak layu. Tes rasa dan siap di santap




Ternyata cara buat tongseng ayam yang lezat tidak ribet ini gampang sekali ya! Kita semua dapat menghidangkannya. Resep tongseng ayam Cocok sekali untuk kamu yang sedang belajar memasak ataupun bagi anda yang sudah jago dalam memasak.

Tertarik untuk mulai mencoba bikin resep tongseng ayam lezat simple ini? Kalau kalian ingin, ayo kalian segera menyiapkan peralatan dan bahannya, setelah itu bikin deh Resep tongseng ayam yang enak dan tidak ribet ini. Betul-betul taidak sulit kan. 

Oleh karena itu, daripada kamu berlama-lama, ayo kita langsung sajikan resep tongseng ayam ini. Pasti anda gak akan nyesel membuat resep tongseng ayam mantab tidak rumit ini! Selamat berkreasi dengan resep tongseng ayam lezat tidak ribet ini di rumah kalian sendiri,oke!.

