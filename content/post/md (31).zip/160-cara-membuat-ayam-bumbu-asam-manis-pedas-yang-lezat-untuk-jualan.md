---
description: "Cara membuat Ayam bumbu asam manis pedas yang lezat Untuk Jualan"
title: "Cara membuat Ayam bumbu asam manis pedas yang lezat Untuk Jualan"
slug: 160-cara-membuat-ayam-bumbu-asam-manis-pedas-yang-lezat-untuk-jualan
date: 2021-02-24T19:57:49.100Z
image: https://img-global.cpcdn.com/recipes/0d56c3884ca4ec9c/680x482cq70/ayam-bumbu-asam-manis-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0d56c3884ca4ec9c/680x482cq70/ayam-bumbu-asam-manis-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0d56c3884ca4ec9c/680x482cq70/ayam-bumbu-asam-manis-pedas-foto-resep-utama.jpg
author: Scott Murphy
ratingvalue: 3.6
reviewcount: 9
recipeingredient:
- "1/2 Kg Dada Ayam Fillet"
- "1 Bungkus Tepung Bumbu Sasa"
- "1/2 SDT Garam"
- "1/2 Botol Saus Tomat"
- "2 SDM Saus Tiram"
- "5 Butir Cabai Rawit"
- "1 Buah lemon  Sedikit Cuka"
- "1/2 SDT Gula"
- "1 SDT Royco"
- "5-10 SDM Saus Sambal"
- "3 Siung Bawang Putih"
- "1 Buah Bawang Bombay"
- "1 Buah Tomat"
- "1 SDT Tepung Maizena"
recipeinstructions:
- "Cuci ayam menggunakan air bersih"
- "Potong-potong Bawang putih, bawang bombay, tomat dan cabai rawit"
- "Letakkan tepung bumbu sasa pada wadah yang diisi sedikit air"
- "Letakkan tepung bumbu sasa pada wadah yang TIDAK diisi air"
- "Celupkan ayam pada tepung bumbu sasa yang berisikan air lalu celupkan ditepung yang kering (lakukan sebanyak 2x agar tepung terasa tebal)"
- "Tuang minyak kedalam wajan, tunggu hingga panas"
- "Masukkan ayam yang sudah dilumuri tepung kendalam minyak panas"
- "Tunggu hingga ayam berwarna kecoklatan lalu angkat dan tiriskan"
- "Tuangkan sedikit minyak kedalam wajan, tumis bawang bombay, bawang putih dan tomat yang sudah dipotong-potong lalu tunggu hingga layu"
- "Masukkan air kedalam wajan, tunggu hingga mendidik"
- "Masukkan saus tomat, saus sambal, saus tiram lalu aduk hingga merata"
- "Masukkan royco, garam, gula aduk hingga merata. Angkat jika merasa sudah selesai (rasanya pas)"
- "Hidangkan ayam dengan bumbu yang sudah ditumis.."
categories:
- Resep
tags:
- ayam
- bumbu
- asam

katakunci: ayam bumbu asam 
nutrition: 231 calories
recipecuisine: Indonesian
preptime: "PT30M"
cooktime: "PT54M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam bumbu asam manis pedas](https://img-global.cpcdn.com/recipes/0d56c3884ca4ec9c/680x482cq70/ayam-bumbu-asam-manis-pedas-foto-resep-utama.jpg)

Andai kamu seorang wanita, mempersiapkan santapan enak buat keluarga adalah suatu hal yang menggembirakan bagi kita sendiri. Kewajiban seorang ibu Tidak cuman mengatur rumah saja, namun anda pun harus memastikan keperluan nutrisi tercukupi dan juga santapan yang dikonsumsi orang tercinta harus mantab.

Di zaman  saat ini, anda memang mampu mengorder panganan instan tidak harus ribet membuatnya dahulu. Namun ada juga lho orang yang memang mau memberikan makanan yang terlezat bagi keluarganya. Lantaran, menyajikan masakan sendiri jauh lebih higienis dan bisa menyesuaikan makanan tersebut sesuai kesukaan orang tercinta. 

Resep Ayam Bakar Teflon Bumbu Rujak. Masak ini aja bun, ayam saos asam manis pedas dijamin sekeluarga pasti suka semua. Setelah ayam dipotong-potong, sebaiknya cuci terlebih dahulu ayam untuk.

Mungkinkah anda merupakan seorang penggemar ayam bumbu asam manis pedas?. Tahukah kamu, ayam bumbu asam manis pedas adalah sajian khas di Indonesia yang saat ini disukai oleh setiap orang dari hampir setiap tempat di Indonesia. Kamu bisa memasak ayam bumbu asam manis pedas olahan sendiri di rumahmu dan boleh jadi camilan favoritmu di akhir pekanmu.

Kalian tidak usah bingung jika kamu ingin mendapatkan ayam bumbu asam manis pedas, lantaran ayam bumbu asam manis pedas tidak sulit untuk dicari dan juga kita pun boleh memasaknya sendiri di rumah. ayam bumbu asam manis pedas bisa diolah memalui beraneka cara. Sekarang telah banyak resep modern yang membuat ayam bumbu asam manis pedas lebih nikmat.

Resep ayam bumbu asam manis pedas pun sangat mudah untuk dibikin, lho. Kita tidak perlu repot-repot untuk memesan ayam bumbu asam manis pedas, karena Kalian mampu menghidangkan di rumahmu. Untuk Kita yang mau menyajikannya, inilah resep untuk membuat ayam bumbu asam manis pedas yang mantab yang dapat Anda coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Ayam bumbu asam manis pedas:

1. Siapkan 1/2 Kg Dada Ayam Fillet
1. Ambil 1 Bungkus Tepung Bumbu Sasa
1. Gunakan 1/2 SDT Garam
1. Siapkan 1/2 Botol Saus Tomat
1. Ambil 2 SDM Saus Tiram
1. Ambil 5 Butir Cabai Rawit
1. Gunakan 1 Buah lemon / Sedikit Cuka
1. Sediakan 1/2 SDT Gula
1. Gunakan 1 SDT Royco
1. Sediakan 5-10 SDM Saus Sambal
1. Sediakan 3 Siung Bawang Putih
1. Ambil 1 Buah Bawang Bombay
1. Ambil 1 Buah Tomat
1. Sediakan 1 SDT Tepung Maizena


Perlu diketahui bahwa bumbu masakan ayam fillet yakni bawang bombay, bawang putih, saus tomat, dan beberapa bahan bumbu lainnya yangmudah anda beli di pasar maupun supermarket terdekat. Padukan nikmatnya hidangan ayam bumbu kecap dengan rasa manis, gurih, dan pedas. Asam manis pedas lebih kepada saus yang benar-benar menggugah selera. Resep ayam asam pedas merupakan kombinasi unik penghibur lidah yang Baik dari bumbu halus, bahan pilihan hingga cara mengolahnya yang benar-benar dari hati. 

<!--inarticleads2-->

##### Langkah-langkah membuat Ayam bumbu asam manis pedas:

1. Cuci ayam menggunakan air bersih
1. Potong-potong Bawang putih, bawang bombay, tomat dan cabai rawit
1. Letakkan tepung bumbu sasa pada wadah yang diisi sedikit air
1. Letakkan tepung bumbu sasa pada wadah yang TIDAK diisi air
1. Celupkan ayam pada tepung bumbu sasa yang berisikan air lalu celupkan ditepung yang kering (lakukan sebanyak 2x agar tepung terasa tebal)
1. Tuang minyak kedalam wajan, tunggu hingga panas
1. Masukkan ayam yang sudah dilumuri tepung kendalam minyak panas
1. Tunggu hingga ayam berwarna kecoklatan lalu angkat dan tiriskan
1. Tuangkan sedikit minyak kedalam wajan, tumis bawang bombay, bawang putih dan tomat yang sudah dipotong-potong lalu tunggu hingga layu
1. Masukkan air kedalam wajan, tunggu hingga mendidik
1. Masukkan saus tomat, saus sambal, saus tiram lalu aduk hingga merata
1. Masukkan royco, garam, gula aduk hingga merata. Angkat jika merasa sudah selesai (rasanya pas)
1. Hidangkan ayam dengan bumbu yang sudah ditumis..


Resep yang dimasak dari hati akan sampai ke hati. Ayam bakar bumbu rujak merupakan salah satu masakan yang mempunyai cita rasa khas pedas manis. Pengolahan saos asam manis bila ingin terasa lebih pedas bisa ditambahkan cabai rawit atau cabe yang pedas. Saus di Indonesia terkadang juga disebut saos, sedangkan dalam bahasa inggris sauce. Saus asam manis berfungsi serbaguna dan multi fungsi, seperti untuk bahan campuran aneka. 

Ternyata cara buat ayam bumbu asam manis pedas yang nikamt tidak ribet ini enteng sekali ya! Anda Semua bisa mencobanya. Cara Membuat ayam bumbu asam manis pedas Sangat sesuai banget untuk kalian yang sedang belajar memasak maupun bagi kalian yang telah jago memasak.

Tertarik untuk mencoba membikin resep ayam bumbu asam manis pedas enak sederhana ini? Kalau anda tertarik, ayo kamu segera buruan siapin alat-alat dan bahannya, lalu buat deh Resep ayam bumbu asam manis pedas yang mantab dan tidak ribet ini. Betul-betul mudah kan. 

Maka dari itu, ketimbang kita berlama-lama, hayo langsung aja hidangkan resep ayam bumbu asam manis pedas ini. Pasti anda tak akan menyesal sudah bikin resep ayam bumbu asam manis pedas nikmat sederhana ini! Selamat mencoba dengan resep ayam bumbu asam manis pedas mantab sederhana ini di tempat tinggal sendiri,oke!.

