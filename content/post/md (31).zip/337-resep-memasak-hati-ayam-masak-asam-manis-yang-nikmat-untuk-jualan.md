---
description: "Resep memasak Hati Ayam Masak Asam Manis yang nikmat Untuk Jualan"
title: "Resep memasak Hati Ayam Masak Asam Manis yang nikmat Untuk Jualan"
slug: 337-resep-memasak-hati-ayam-masak-asam-manis-yang-nikmat-untuk-jualan
date: 2021-04-25T02:30:19.764Z
image: https://img-global.cpcdn.com/recipes/d65138a4ae7c883d/680x482cq70/hati-ayam-masak-asam-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d65138a4ae7c883d/680x482cq70/hati-ayam-masak-asam-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d65138a4ae7c883d/680x482cq70/hati-ayam-masak-asam-manis-foto-resep-utama.jpg
author: Lela Jacobs
ratingvalue: 3.3
reviewcount: 9
recipeingredient:
- "3 bh Hati Ayam Kampung"
- "5 siung Bawang merah"
- "4 siung Bawang putih"
- "1 bh Bawang merah besar"
- "4 bh Cabe Hijau besar"
- "1 bh Tomat"
- "2 papan petai kupas"
- "1 bks Terasi larutkan dengan air"
- "1 sdm Gula merah serut"
- " Garam"
- " Gula pasir"
- " Penyedap rasa"
recipeinstructions:
- "Bersihkan hati ayam, potong persegi kecil. Beri perasan air jeruk nipis dan garam. Diamkan sebentar. Cuci bersih."
- "Rebus hati ayam sebentar, tiriskan. Sisihkan."
- "Siapkan bahan-bahan lainnya, iris bawang, cabe merah, cabe hijau, tomat, petai."
- "Tumis bumbu iris sampai harum dan layu"
- "Masukkan hati ayam, aduk rata. Tumis sebentar. Masukkan air terasi."
- "Masukkan petai dan Tambahkan sedikit air, beri garam, gula pasir, gula merah, dan penyedap. Aduk rata."
- "Masak sampai kuah menyusut dan hati matang, cek rasa, bila sudah pas, angkat. Sajikan."
categories:
- Resep
tags:
- hati
- ayam
- masak

katakunci: hati ayam masak 
nutrition: 139 calories
recipecuisine: Indonesian
preptime: "PT15M"
cooktime: "PT35M"
recipeyield: "1"
recipecategory: Lunch

---


![Hati Ayam Masak Asam Manis](https://img-global.cpcdn.com/recipes/d65138a4ae7c883d/680x482cq70/hati-ayam-masak-asam-manis-foto-resep-utama.jpg)

Andai kamu seorang ibu, menyajikan hidangan lezat buat famili adalah suatu hal yang menggembirakan untuk anda sendiri. Peran seorang  wanita bukan cuma mengatur rumah saja, namun kamu pun wajib memastikan keperluan nutrisi tercukupi dan juga olahan yang disantap keluarga tercinta harus mantab.

Di masa  sekarang, kita sebenarnya dapat membeli masakan siap saji meski tidak harus capek membuatnya terlebih dahulu. Namun banyak juga mereka yang memang ingin memberikan hidangan yang terenak bagi keluarganya. Karena, menghidangkan masakan yang diolah sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan makanan tersebut berdasarkan masakan kesukaan keluarga tercinta. 



Apakah anda merupakan salah satu penikmat hati ayam masak asam manis?. Asal kamu tahu, hati ayam masak asam manis merupakan makanan khas di Indonesia yang sekarang disukai oleh kebanyakan orang dari berbagai wilayah di Indonesia. Kita dapat memasak hati ayam masak asam manis kreasi sendiri di rumahmu dan boleh dijadikan hidangan kesukaanmu di akhir pekanmu.

Kamu tak perlu bingung untuk menyantap hati ayam masak asam manis, lantaran hati ayam masak asam manis tidak sukar untuk dicari dan anda pun bisa mengolahnya sendiri di tempatmu. hati ayam masak asam manis dapat dibuat lewat berbagai cara. Sekarang ada banyak resep modern yang menjadikan hati ayam masak asam manis lebih enak.

Resep hati ayam masak asam manis juga mudah sekali untuk dibikin, lho. Kamu jangan capek-capek untuk memesan hati ayam masak asam manis, karena Anda dapat menghidangkan ditempatmu. Untuk Kita yang hendak mencobanya, berikut ini cara untuk membuat hati ayam masak asam manis yang enak yang dapat Kalian buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Hati Ayam Masak Asam Manis:

1. Gunakan 3 bh Hati Ayam Kampung
1. Siapkan 5 siung Bawang merah
1. Gunakan 4 siung Bawang putih
1. Ambil 1 bh Bawang merah besar
1. Gunakan 4 bh Cabe Hijau besar
1. Ambil 1 bh Tomat
1. Sediakan 2 papan petai, kupas
1. Sediakan 1 bks Terasi, larutkan dengan air
1. Siapkan 1 sdm Gula merah, serut
1. Ambil  Garam
1. Gunakan  Gula pasir
1. Sediakan  Penyedap rasa




<!--inarticleads2-->

##### Cara menyiapkan Hati Ayam Masak Asam Manis:

1. Bersihkan hati ayam, potong persegi kecil. Beri perasan air jeruk nipis dan garam. Diamkan sebentar. Cuci bersih.
1. Rebus hati ayam sebentar, tiriskan. Sisihkan.
1. Siapkan bahan-bahan lainnya, iris bawang, cabe merah, cabe hijau, tomat, petai.
1. Tumis bumbu iris sampai harum dan layu
1. Masukkan hati ayam, aduk rata. Tumis sebentar. Masukkan air terasi.
1. Masukkan petai dan Tambahkan sedikit air, beri garam, gula pasir, gula merah, dan penyedap. Aduk rata.
1. Masak sampai kuah menyusut dan hati matang, cek rasa, bila sudah pas, angkat. Sajikan.




Ternyata resep hati ayam masak asam manis yang mantab simple ini gampang banget ya! Kamu semua mampu memasaknya. Resep hati ayam masak asam manis Sangat sesuai banget buat kita yang baru mau belajar memasak ataupun untuk kalian yang sudah pandai dalam memasak.

Apakah kamu tertarik mulai mencoba bikin resep hati ayam masak asam manis mantab sederhana ini? Kalau anda ingin, yuk kita segera buruan menyiapkan peralatan dan bahan-bahannya, maka bikin deh Resep hati ayam masak asam manis yang enak dan simple ini. Sangat taidak sulit kan. 

Jadi, daripada kita berlama-lama, hayo langsung aja hidangkan resep hati ayam masak asam manis ini. Dijamin anda tiidak akan nyesel bikin resep hati ayam masak asam manis mantab tidak ribet ini! Selamat mencoba dengan resep hati ayam masak asam manis lezat simple ini di rumah masing-masing,oke!.

