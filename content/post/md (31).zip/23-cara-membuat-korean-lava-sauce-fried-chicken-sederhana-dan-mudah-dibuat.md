---
description: "Cara membuat Korean Lava Sauce Fried Chicken Sederhana dan Mudah Dibuat"
title: "Cara membuat Korean Lava Sauce Fried Chicken Sederhana dan Mudah Dibuat"
slug: 23-cara-membuat-korean-lava-sauce-fried-chicken-sederhana-dan-mudah-dibuat
date: 2021-06-09T02:18:56.364Z
image: https://img-global.cpcdn.com/recipes/d0447388e5a88f2b/680x482cq70/korean-lava-sauce-fried-chicken-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d0447388e5a88f2b/680x482cq70/korean-lava-sauce-fried-chicken-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d0447388e5a88f2b/680x482cq70/korean-lava-sauce-fried-chicken-foto-resep-utama.jpg
author: Harriet Keller
ratingvalue: 4.9
reviewcount: 7
recipeingredient:
- "1 ekor ayam potong 20 bagian"
- " Tepung bumbu"
- " Saus lava bisa dicari ditoko bahan kue  minimarket"
- "5 siung Bawang putih"
recipeinstructions:
- "Ayam yang sudah dipotong menjadi beberapa bagian dicuci bersih dan tiriskan."
- "Siapkan tepung bumbu dan ditambahkan air secukupnya, diaduk rata."
- "Masukkan ayam bersih tadi dalam balutan tepung, pastikan semua meresap lalu dibalur lagi dengan tepung bumbu yang kering di wadah terpisah."
- "Panaskan minyak, goreng ayam tadi hingga matang."
- "Saus lava : cincang halus bawang putih, lalu ditumis hingga harum. Tambahkan garam dan kaldu secukupnya. Masukkan saus lava, masak saus hingga mendidih. Biar tampilan ayam oke, bisa ditambahkan madu 2 sdm atau sesuai selera."
- "Siapkan ayam goreng, tuang saus hingga merata, sajikan."
categories:
- Resep
tags:
- korean
- lava
- sauce

katakunci: korean lava sauce 
nutrition: 233 calories
recipecuisine: Indonesian
preptime: "PT32M"
cooktime: "PT34M"
recipeyield: "3"
recipecategory: Lunch

---


![Korean Lava Sauce Fried Chicken](https://img-global.cpcdn.com/recipes/d0447388e5a88f2b/680x482cq70/korean-lava-sauce-fried-chicken-foto-resep-utama.jpg)

Jika anda seorang ibu, menyajikan santapan enak buat orang tercinta merupakan suatu hal yang memuaskan untuk kamu sendiri. Peran seorang istri bukan sekadar mengatur rumah saja, tetapi kamu juga wajib memastikan keperluan gizi terpenuhi dan olahan yang dikonsumsi orang tercinta mesti nikmat.

Di waktu  sekarang, kita sebenarnya bisa memesan panganan yang sudah jadi tidak harus capek memasaknya lebih dulu. Tapi ada juga mereka yang selalu ingin menyajikan yang terenak untuk orang tercintanya. Pasalnya, menghidangkan masakan yang dibuat sendiri jauh lebih bersih dan kita juga bisa menyesuaikan masakan tersebut sesuai dengan kesukaan orang tercinta. 



Apakah kamu salah satu penyuka korean lava sauce fried chicken?. Asal kamu tahu, korean lava sauce fried chicken adalah hidangan khas di Indonesia yang sekarang disukai oleh kebanyakan orang dari hampir setiap daerah di Nusantara. Kamu bisa membuat korean lava sauce fried chicken sendiri di rumah dan dapat dijadikan santapan kegemaranmu di hari libur.

Anda tidak usah bingung jika kamu ingin mendapatkan korean lava sauce fried chicken, sebab korean lava sauce fried chicken sangat mudah untuk ditemukan dan juga kita pun dapat membuatnya sendiri di tempatmu. korean lava sauce fried chicken bisa dimasak dengan beraneka cara. Sekarang ada banyak banget cara kekinian yang membuat korean lava sauce fried chicken semakin lezat.

Resep korean lava sauce fried chicken juga mudah sekali dihidangkan, lho. Anda jangan capek-capek untuk membeli korean lava sauce fried chicken, tetapi Anda mampu membuatnya di rumah sendiri. Untuk Anda yang ingin menghidangkannya, di bawah ini adalah resep menyajikan korean lava sauce fried chicken yang mantab yang bisa Kita buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Korean Lava Sauce Fried Chicken:

1. Ambil 1 ekor ayam, potong 20 bagian
1. Gunakan  Tepung bumbu
1. Siapkan  Saus lava (bisa dicari ditoko bahan kue / minimarket)
1. Siapkan 5 siung Bawang putih




<!--inarticleads2-->

##### Cara menyiapkan Korean Lava Sauce Fried Chicken:

1. Ayam yang sudah dipotong menjadi beberapa bagian dicuci bersih dan tiriskan.
1. Siapkan tepung bumbu dan ditambahkan air secukupnya, diaduk rata.
1. Masukkan ayam bersih tadi dalam balutan tepung, pastikan semua meresap lalu dibalur lagi dengan tepung bumbu yang kering di wadah terpisah.
1. Panaskan minyak, goreng ayam tadi hingga matang.
1. Saus lava : cincang halus bawang putih, lalu ditumis hingga harum. Tambahkan garam dan kaldu secukupnya. Masukkan saus lava, masak saus hingga mendidih. Biar tampilan ayam oke, bisa ditambahkan madu 2 sdm atau sesuai selera.
1. Siapkan ayam goreng, tuang saus hingga merata, sajikan.




Ternyata cara membuat korean lava sauce fried chicken yang lezat tidak ribet ini gampang sekali ya! Kita semua mampu mencobanya. Cara buat korean lava sauce fried chicken Cocok banget untuk kamu yang baru belajar memasak atau juga bagi anda yang telah hebat memasak.

Tertarik untuk mulai mencoba bikin resep korean lava sauce fried chicken nikmat tidak ribet ini? Kalau kamu ingin, mending kamu segera buruan siapin alat-alat dan bahan-bahannya, kemudian buat deh Resep korean lava sauce fried chicken yang mantab dan tidak rumit ini. Sangat gampang kan. 

Maka, ketimbang kamu diam saja, ayo kita langsung saja bikin resep korean lava sauce fried chicken ini. Pasti anda tak akan menyesal sudah bikin resep korean lava sauce fried chicken enak simple ini! Selamat mencoba dengan resep korean lava sauce fried chicken mantab tidak ribet ini di tempat tinggal masing-masing,ya!.

