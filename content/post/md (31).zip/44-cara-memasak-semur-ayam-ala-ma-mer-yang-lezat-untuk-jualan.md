---
description: "Cara memasak Semur ayam ala Ma Mer yang lezat Untuk Jualan"
title: "Cara memasak Semur ayam ala Ma Mer yang lezat Untuk Jualan"
slug: 44-cara-memasak-semur-ayam-ala-ma-mer-yang-lezat-untuk-jualan
date: 2021-03-18T01:24:19.973Z
image: https://img-global.cpcdn.com/recipes/6674f30c8d9c6e5c/680x482cq70/semur-ayam-ala-ma-mer-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6674f30c8d9c6e5c/680x482cq70/semur-ayam-ala-ma-mer-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6674f30c8d9c6e5c/680x482cq70/semur-ayam-ala-ma-mer-foto-resep-utama.jpg
author: Delia Cunningham
ratingvalue: 3
reviewcount: 12
recipeingredient:
- "1 ekor ayam potong bisa jantan kampung atau broiler"
- "1 buah tomat iris"
- "2 buah kentang"
- "Segenggam soun"
- "3 buah cengkeh"
- "1 btg kayumanis"
- "Sepotong kecil pala"
- "1 buah bawang bombai ukuran kecil"
- "2 siung bawang putih"
- "3 sdm Kecap manis"
- " Garam"
- " Kaldu jamur"
- " Air"
recipeinstructions:
- "Tumis bawang bombay, bawang putih, sampai harum lalu masukan juga cengkeh, kayumanis, pala,tomat, ayam..masak sampai ayam berubah warna."
- "Tbahkan air kira2x 500 ml..tambahkan kecap, garam, kaldu jamur..masak dgn api kecil..sampai ayam empuk dan matang. Bila dirasa blm empuk bisa tambah air lg."
- "Setelah ayam empuk masukan kentang..masak sampai kentang empuk."
- "Terakhir masukan soun..biarkan mendidih..lgs matikan api..siap disajikan."
categories:
- Resep
tags:
- semur
- ayam
- ala

katakunci: semur ayam ala 
nutrition: 233 calories
recipecuisine: Indonesian
preptime: "PT18M"
cooktime: "PT60M"
recipeyield: "3"
recipecategory: Lunch

---


![Semur ayam ala Ma Mer](https://img-global.cpcdn.com/recipes/6674f30c8d9c6e5c/680x482cq70/semur-ayam-ala-ma-mer-foto-resep-utama.jpg)

Selaku seorang wanita, menyuguhkan hidangan menggugah selera bagi orang tercinta merupakan hal yang menyenangkan untuk kamu sendiri. Kewajiban seorang istri bukan hanya mengerjakan pekerjaan rumah saja, tetapi anda juga wajib memastikan keperluan gizi tercukupi dan masakan yang disantap orang tercinta mesti nikmat.

Di waktu  saat ini, kita memang bisa mengorder olahan yang sudah jadi tanpa harus repot mengolahnya lebih dulu. Namun banyak juga lho mereka yang selalu ingin memberikan makanan yang terlezat untuk orang tercintanya. Sebab, menyajikan masakan sendiri jauh lebih bersih dan kita juga bisa menyesuaikan sesuai dengan kesukaan famili. 



Apakah anda merupakan seorang penikmat semur ayam ala ma mer?. Tahukah kamu, semur ayam ala ma mer adalah hidangan khas di Indonesia yang kini disukai oleh kebanyakan orang di hampir setiap tempat di Nusantara. Kamu bisa menghidangkan semur ayam ala ma mer sendiri di rumahmu dan dapat dijadikan makanan favoritmu di hari libur.

Anda tidak perlu bingung untuk mendapatkan semur ayam ala ma mer, sebab semur ayam ala ma mer sangat mudah untuk didapatkan dan kamu pun dapat memasaknya sendiri di rumah. semur ayam ala ma mer dapat dibuat dengan beragam cara. Sekarang telah banyak banget cara modern yang membuat semur ayam ala ma mer semakin lebih mantap.

Resep semur ayam ala ma mer pun sangat gampang dibikin, lho. Kamu jangan capek-capek untuk memesan semur ayam ala ma mer, sebab Kalian mampu menyajikan di rumah sendiri. Untuk Kalian yang hendak membuatnya, di bawah ini adalah resep menyajikan semur ayam ala ma mer yang lezat yang bisa Kalian coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Semur ayam ala Ma Mer:

1. Siapkan 1 ekor ayam potong (bisa jantan, kampung atau broiler)
1. Sediakan 1 buah tomat iris
1. Sediakan 2 buah kentang
1. Ambil Segenggam soun
1. Gunakan 3 buah cengkeh
1. Gunakan 1 btg kayumanis
1. Ambil Sepotong kecil pala
1. Sediakan 1 buah bawang bombai ukuran kecil
1. Sediakan 2 siung bawang putih
1. Sediakan 3 sdm Kecap manis
1. Sediakan  Garam
1. Gunakan  Kaldu jamur
1. Siapkan  Air




<!--inarticleads2-->

##### Langkah-langkah membuat Semur ayam ala Ma Mer:

1. Tumis bawang bombay, bawang putih, sampai harum lalu masukan juga cengkeh, kayumanis, pala,tomat, ayam..masak sampai ayam berubah warna.
1. Tbahkan air kira2x 500 ml..tambahkan kecap, garam, kaldu jamur..masak dgn api kecil..sampai ayam empuk dan matang. Bila dirasa blm empuk bisa tambah air lg.
1. Setelah ayam empuk masukan kentang..masak sampai kentang empuk.
1. Terakhir masukan soun..biarkan mendidih..lgs matikan api..siap disajikan.




Ternyata cara membuat semur ayam ala ma mer yang lezat tidak rumit ini mudah sekali ya! Kita semua dapat memasaknya. Resep semur ayam ala ma mer Sesuai banget untuk kamu yang baru belajar memasak atau juga untuk anda yang telah hebat memasak.

Tertarik untuk mulai mencoba membuat resep semur ayam ala ma mer enak tidak rumit ini? Kalau anda ingin, ayo kalian segera siapkan alat-alat dan bahannya, lantas buat deh Resep semur ayam ala ma mer yang mantab dan tidak ribet ini. Sungguh mudah kan. 

Maka dari itu, ketimbang kita berfikir lama-lama, ayo langsung aja buat resep semur ayam ala ma mer ini. Dijamin kalian tak akan menyesal sudah bikin resep semur ayam ala ma mer mantab simple ini! Selamat berkreasi dengan resep semur ayam ala ma mer nikmat simple ini di rumah kalian sendiri,ya!.

