---
description: "Resep Soto Semarang (non ayam kampung) yang nikmat dan Mudah Dibuat"
title: "Resep Soto Semarang (non ayam kampung) yang nikmat dan Mudah Dibuat"
slug: 260-resep-soto-semarang-non-ayam-kampung-yang-nikmat-dan-mudah-dibuat
date: 2021-04-02T03:26:57.618Z
image: https://img-global.cpcdn.com/recipes/43d1602a320bdfbc/680x482cq70/soto-semarang-non-ayam-kampung-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/43d1602a320bdfbc/680x482cq70/soto-semarang-non-ayam-kampung-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/43d1602a320bdfbc/680x482cq70/soto-semarang-non-ayam-kampung-foto-resep-utama.jpg
author: Billy Henderson
ratingvalue: 4
reviewcount: 15
recipeingredient:
- "250 gr ayam kampung saya pakai ayam broiler"
- "2 liter air"
- "1 lembar daun salam"
- "1 batang daun bawang potong panjang"
- "2 sdm bawang putih goreng"
- " Bumbu halus"
- "4 siung bawang putih"
- "1 ruas kunyit"
- "1 ruas jahe"
- "1 sdm kecap manis"
- " Bumbu Cemplung"
- "1 batang serai memarkan"
- "2 lembar daun salam"
- "4 lembar daun jeruk"
- " Seasoning"
- "1 sdm garam"
- "1 sdm gula merah iris"
- "1/2 sdt merica bubuk"
- "1/2 sdt pala bubuk saya skip"
- "1/2 sdt kaldu jamur"
- "3/4 sdt ketumbar bubuk"
- " Bahan Sambal"
- "5 cabe rawit"
- "1 siung bawang putih"
- " Semua diulek hingga halus"
- " Pelengkap"
- " Nasi putih"
- " Kol iris halus seduh air panas"
- " Toge seduh air panas"
- " Soun seduh air panas"
- "iris Daun bawang"
- " Bawang goreng"
- "Irisan jeruk nipis"
recipeinstructions:
- "Rebus ayam dengan daun salam sampai empuk. Tumis bumbu halus bersama bumbu cemplung hingga harum. Tambahkan kecap manis, lanjut tumis sampai matang."
- "Masukkan tumisan bumbu ke dalam rebusan ayam. Tambahkan seasoning. Koreksi rasa. Jika dirasa sudah pas, angkat ayam untuk disuwir-suwir. Terakhir, masukkan daun bawang potong dan bawang putih goreng. Masak sebentar lalu matikan api."
- "Di mangkok, tata nasi putih, soun, kol, toge, dan suwiran ayam. Siramkan kuah soto. Taburi daun bawang dan bawang goreng. Sajikan dengan sambal dan tempe garit goreng. Jangan lupa kucurkan air jeruk nipis"
categories:
- Resep
tags:
- soto
- semarang
- non

katakunci: soto semarang non 
nutrition: 158 calories
recipecuisine: Indonesian
preptime: "PT13M"
cooktime: "PT35M"
recipeyield: "3"
recipecategory: Dessert

---


![Soto Semarang (non ayam kampung)](https://img-global.cpcdn.com/recipes/43d1602a320bdfbc/680x482cq70/soto-semarang-non-ayam-kampung-foto-resep-utama.jpg)

Sebagai seorang orang tua, menyajikan olahan menggugah selera untuk orang tercinta adalah hal yang menggembirakan untuk kamu sendiri. Tanggung jawab seorang istri Tidak sekadar menjaga rumah saja, tetapi anda juga wajib menyediakan kebutuhan gizi tercukupi dan juga olahan yang dikonsumsi anak-anak harus lezat.

Di masa  sekarang, kita memang mampu mengorder hidangan yang sudah jadi meski tanpa harus susah mengolahnya lebih dulu. Tetapi ada juga lho mereka yang memang ingin memberikan yang terenak untuk keluarganya. Karena, menghidangkan masakan yang dibuat sendiri jauh lebih bersih dan bisa menyesuaikan masakan tersebut sesuai dengan makanan kesukaan keluarga tercinta. 



Mungkinkah anda seorang penyuka soto semarang (non ayam kampung)?. Asal kamu tahu, soto semarang (non ayam kampung) adalah sajian khas di Indonesia yang sekarang disenangi oleh banyak orang di berbagai wilayah di Nusantara. Kamu dapat memasak soto semarang (non ayam kampung) sendiri di rumah dan pasti jadi santapan kesukaanmu di akhir pekan.

Kalian tak perlu bingung jika kamu ingin memakan soto semarang (non ayam kampung), lantaran soto semarang (non ayam kampung) gampang untuk ditemukan dan juga anda pun bisa memasaknya sendiri di tempatmu. soto semarang (non ayam kampung) boleh diolah lewat beraneka cara. Kini pun telah banyak sekali cara kekinian yang menjadikan soto semarang (non ayam kampung) lebih enak.

Resep soto semarang (non ayam kampung) pun sangat mudah untuk dibuat, lho. Kamu tidak usah capek-capek untuk membeli soto semarang (non ayam kampung), sebab Kita mampu menyiapkan di rumahmu. Bagi Anda yang hendak membuatnya, berikut ini cara menyajikan soto semarang (non ayam kampung) yang enak yang mampu Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Soto Semarang (non ayam kampung):

1. Gunakan 250 gr ayam kampung (saya pakai ayam broiler)
1. Ambil 2 liter air
1. Gunakan 1 lembar daun salam
1. Gunakan 1 batang daun bawang, potong panjang
1. Gunakan 2 sdm bawang putih goreng
1. Siapkan  Bumbu halus
1. Ambil 4 siung bawang putih
1. Ambil 1 ruas kunyit
1. Siapkan 1 ruas jahe
1. Sediakan 1 sdm kecap manis
1. Gunakan  Bumbu Cemplung
1. Gunakan 1 batang serai, memarkan
1. Ambil 2 lembar daun salam
1. Ambil 4 lembar daun jeruk
1. Sediakan  Seasoning
1. Ambil 1 sdm garam
1. Sediakan 1 sdm gula merah iris
1. Ambil 1/2 sdt merica bubuk
1. Siapkan 1/2 sdt pala bubuk (saya skip)
1. Gunakan 1/2 sdt kaldu jamur
1. Sediakan 3/4 sdt ketumbar bubuk
1. Ambil  Bahan Sambal
1. Siapkan 5 cabe rawit
1. Sediakan 1 siung bawang putih
1. Gunakan  Semua diulek hingga halus
1. Gunakan  Pelengkap
1. Siapkan  Nasi putih
1. Ambil  Kol iris halus, seduh air panas
1. Ambil  Toge, seduh air panas
1. Siapkan  Soun, seduh air panas
1. Siapkan iris Daun bawang
1. Siapkan  Bawang goreng
1. Sediakan Irisan jeruk nipis




<!--inarticleads2-->

##### Langkah-langkah membuat Soto Semarang (non ayam kampung):

1. Rebus ayam dengan daun salam sampai empuk. Tumis bumbu halus bersama bumbu cemplung hingga harum. Tambahkan kecap manis, lanjut tumis sampai matang.
1. Masukkan tumisan bumbu ke dalam rebusan ayam. Tambahkan seasoning. Koreksi rasa. Jika dirasa sudah pas, angkat ayam untuk disuwir-suwir. Terakhir, masukkan daun bawang potong dan bawang putih goreng. Masak sebentar lalu matikan api.
1. Di mangkok, tata nasi putih, soun, kol, toge, dan suwiran ayam. Siramkan kuah soto. Taburi daun bawang dan bawang goreng. Sajikan dengan sambal dan tempe garit goreng. Jangan lupa kucurkan air jeruk nipis




Ternyata cara buat soto semarang (non ayam kampung) yang nikamt sederhana ini mudah banget ya! Semua orang dapat menghidangkannya. Cara buat soto semarang (non ayam kampung) Cocok banget buat anda yang baru belajar memasak ataupun juga untuk kalian yang telah hebat memasak.

Tertarik untuk mulai mencoba membikin resep soto semarang (non ayam kampung) lezat tidak rumit ini? Kalau ingin, mending kamu segera siapkan alat dan bahannya, lalu bikin deh Resep soto semarang (non ayam kampung) yang mantab dan tidak ribet ini. Sangat taidak sulit kan. 

Jadi, ketimbang kita berlama-lama, maka langsung aja sajikan resep soto semarang (non ayam kampung) ini. Pasti kalian tiidak akan nyesel sudah buat resep soto semarang (non ayam kampung) nikmat tidak rumit ini! Selamat mencoba dengan resep soto semarang (non ayam kampung) lezat tidak rumit ini di tempat tinggal masing-masing,ya!.

