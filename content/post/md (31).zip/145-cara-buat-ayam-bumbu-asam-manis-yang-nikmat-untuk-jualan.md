---
description: "Cara buat Ayam bumbu asam manis yang nikmat Untuk Jualan"
title: "Cara buat Ayam bumbu asam manis yang nikmat Untuk Jualan"
slug: 145-cara-buat-ayam-bumbu-asam-manis-yang-nikmat-untuk-jualan
date: 2021-02-15T08:02:27.136Z
image: https://img-global.cpcdn.com/recipes/bff517ddc7b03a33/680x482cq70/ayam-bumbu-asam-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/bff517ddc7b03a33/680x482cq70/ayam-bumbu-asam-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/bff517ddc7b03a33/680x482cq70/ayam-bumbu-asam-manis-foto-resep-utama.jpg
author: Chase Dean
ratingvalue: 4.9
reviewcount: 4
recipeingredient:
- "500 Gram ayam"
- "1 Buah wortel"
- "2 Buah daun bawang"
- "5 Buah cabe merah"
- "1 Siung bawang bombay"
- "2 Siung bawang putih"
- "1 Buah Tomat"
- "5 Sendok saus tomat"
- "3 Sendok saus sambal"
- "1 Butir telur ayam"
- " Tepung bumbu"
- " merica"
- " garam"
- " gula pasir"
- " Air"
recipeinstructions:
- "Buang tulang ayam, lalu potong kecil - kecil sesuai selera. Campurkan dengan merica dan garam sampai merata. Lalu diamkan selama 10 menit."
- "Setelah 10 Menit, masukkan telur lalu tambahkan tepung bumbu. Ratakan."
- "Goreng ayam yang telah dibaluri tepung bumbu hingga matang. Tiriskan."
- "Tumis bawang putih yang dicincang kasar. Setelah berbau harus, masukkan bawang bombay dan cabe merah."
- "Setelah layu, masukkan wortel yang sudah dipotong korek api. Masukkan saus asam dan saus sambal. Tambahkan air. Masak hingga meletup letup."
- "Setelah air menyusut, masukkan daun bawang. Lalu tambahkan ayam yang telah digoreng tadi."
- "Tambahkan gula pasir, garam dan merica."
- "Koreksi rasa."
- "Matang deh......."
categories:
- Resep
tags:
- ayam
- bumbu
- asam

katakunci: ayam bumbu asam 
nutrition: 271 calories
recipecuisine: Indonesian
preptime: "PT21M"
cooktime: "PT39M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam bumbu asam manis](https://img-global.cpcdn.com/recipes/bff517ddc7b03a33/680x482cq70/ayam-bumbu-asam-manis-foto-resep-utama.jpg)

Selaku seorang ibu, mempersiapkan hidangan menggugah selera bagi orang tercinta adalah hal yang sangat menyenangkan untuk kamu sendiri. Kewajiban seorang ibu bukan cuman menangani rumah saja, tetapi kamu pun wajib memastikan keperluan gizi tercukupi dan juga panganan yang dikonsumsi orang tercinta harus menggugah selera.

Di zaman  saat ini, kamu sebenarnya dapat mengorder santapan instan walaupun tidak harus susah memasaknya dahulu. Namun ada juga lho orang yang memang mau menghidangkan yang terbaik untuk orang tercintanya. Sebab, menyajikan masakan yang diolah sendiri jauh lebih higienis dan kita juga bisa menyesuaikan masakan tersebut sesuai dengan masakan kesukaan keluarga tercinta. 



Apakah anda merupakan seorang penikmat ayam bumbu asam manis?. Tahukah kamu, ayam bumbu asam manis merupakan hidangan khas di Nusantara yang kini digemari oleh banyak orang dari berbagai wilayah di Indonesia. Kita dapat menyajikan ayam bumbu asam manis olahan sendiri di rumah dan dapat dijadikan hidangan kesenanganmu di akhir pekan.

Kita tidak usah bingung untuk memakan ayam bumbu asam manis, karena ayam bumbu asam manis gampang untuk ditemukan dan kamu pun boleh memasaknya sendiri di rumah. ayam bumbu asam manis dapat dibuat dengan beragam cara. Kini pun ada banyak cara kekinian yang membuat ayam bumbu asam manis lebih lezat.

Resep ayam bumbu asam manis pun mudah dibuat, lho. Kalian tidak perlu repot-repot untuk memesan ayam bumbu asam manis, lantaran Anda mampu menghidangkan di rumah sendiri. Untuk Anda yang ingin menghidangkannya, dibawah ini merupakan resep membuat ayam bumbu asam manis yang nikamat yang bisa Kamu buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Ayam bumbu asam manis:

1. Sediakan 500 Gram ayam
1. Siapkan 1 Buah wortel
1. Gunakan 2 Buah daun bawang
1. Sediakan 5 Buah cabe merah
1. Sediakan 1 Siung bawang bombay
1. Sediakan 2 Siung bawang putih
1. Siapkan 1 Buah Tomat
1. Siapkan 5 Sendok saus tomat
1. Ambil 3 Sendok saus sambal
1. Gunakan 1 Butir telur ayam
1. Siapkan  Tepung bumbu
1. Ambil  merica
1. Sediakan  garam
1. Gunakan  gula pasir
1. Gunakan  Air




<!--inarticleads2-->

##### Cara menyiapkan Ayam bumbu asam manis:

1. Buang tulang ayam, lalu potong kecil - kecil sesuai selera. Campurkan dengan merica dan garam sampai merata. Lalu diamkan selama 10 menit.
1. Setelah 10 Menit, masukkan telur lalu tambahkan tepung bumbu. Ratakan.
1. Goreng ayam yang telah dibaluri tepung bumbu hingga matang. Tiriskan.
1. Tumis bawang putih yang dicincang kasar. Setelah berbau harus, masukkan bawang bombay dan cabe merah.
1. Setelah layu, masukkan wortel yang sudah dipotong korek api. Masukkan saus asam dan saus sambal. Tambahkan air. Masak hingga meletup letup.
1. Setelah air menyusut, masukkan daun bawang. Lalu tambahkan ayam yang telah digoreng tadi.
1. Tambahkan gula pasir, garam dan merica.
1. Koreksi rasa.
1. Matang deh.......




Wah ternyata cara buat ayam bumbu asam manis yang mantab simple ini gampang sekali ya! Anda Semua bisa memasaknya. Cara buat ayam bumbu asam manis Sesuai sekali buat kamu yang baru belajar memasak atau juga bagi kamu yang telah lihai dalam memasak.

Tertarik untuk mulai mencoba membuat resep ayam bumbu asam manis lezat simple ini? Kalau kalian ingin, mending kamu segera menyiapkan alat-alat dan bahannya, lantas buat deh Resep ayam bumbu asam manis yang lezat dan simple ini. Benar-benar taidak sulit kan. 

Maka, ketimbang kalian berfikir lama-lama, yuk kita langsung sajikan resep ayam bumbu asam manis ini. Dijamin kamu gak akan nyesel sudah membuat resep ayam bumbu asam manis nikmat tidak ribet ini! Selamat mencoba dengan resep ayam bumbu asam manis mantab tidak ribet ini di rumah kalian sendiri,ya!.

