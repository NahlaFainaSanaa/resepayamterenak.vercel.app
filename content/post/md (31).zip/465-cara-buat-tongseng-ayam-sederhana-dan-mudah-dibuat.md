---
description: "Cara buat Tongseng Ayam Sederhana dan Mudah Dibuat"
title: "Cara buat Tongseng Ayam Sederhana dan Mudah Dibuat"
slug: 465-cara-buat-tongseng-ayam-sederhana-dan-mudah-dibuat
date: 2021-03-11T10:07:55.139Z
image: https://img-global.cpcdn.com/recipes/218b8a346b3cd643/680x482cq70/tongseng-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/218b8a346b3cd643/680x482cq70/tongseng-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/218b8a346b3cd643/680x482cq70/tongseng-ayam-foto-resep-utama.jpg
author: Joe Sanders
ratingvalue: 4.2
reviewcount: 14
recipeingredient:
- "800 gr dada ayam fillet potong kecil"
- "1 buah kentang ukuran besar kupas dan potongpotong saya skip"
- "200 gr kol potongpotong"
- "2 sereh geprek"
- "65 ml santan cair instant"
- "1 ruas lengkuas geprek"
- "3 lembar daun salam"
- "3 lembar daun jeruk buang tulang daun"
- "12 buah cabe rawit utuh sesuaikan selera"
- "1 buat tomat"
- "2 sdm kaldu jamur ayam optional"
- "1 sdt gula pasir"
- "1/2 sdt garam"
- "700 ml air"
- "Secukupnya kecap manis dan minyak sayur untuk menumis"
- " BUMBU HALUS "
- "10 siung bawang merah"
- "6 siung bawang putih"
- "1 sdt ketumbar"
- "1/2 sdt lada bubuk"
- "1 ruas kunyit"
- "1 sdt jintan bubuk tambahan saya"
recipeinstructions:
- "Cuci bersih ayam, kemudian potong-potong dan remas-remas dengan garam dan air perasan jeruk nipis. Bilas sebentar."
- "Siapkan panci, rebus air dan ayam hingga matang selama 20 menit. Kemudian buang airnya &amp; sisihkan"
- "Tumis bumbu halus hingga harum lalu masukkan sereh, lengkuas, daun salam, daun jeruk dan tumis hingga rata"
- "Masukkan ayam lalu tambahkan air aduk hingga rata dan masak hingga mendidih"
- "Masukkan garam, kaldu bubuk, gula dan kecap manis. Tambahkan cabe rawit aduk perlahan dan koreksi rasa"
- "Masukkan santan lalu aduk hingga rata dan masukkan kol sambil terus diaduk rata sebentar lalu matikan kompor"
- "Tongseng ayam dituang ke piring saji lalu taburi bawang goreng dan daun bawang / seledri, hidangkan"
categories:
- Resep
tags:
- tongseng
- ayam

katakunci: tongseng ayam 
nutrition: 144 calories
recipecuisine: Indonesian
preptime: "PT16M"
cooktime: "PT43M"
recipeyield: "1"
recipecategory: Dinner

---


![Tongseng Ayam](https://img-global.cpcdn.com/recipes/218b8a346b3cd643/680x482cq70/tongseng-ayam-foto-resep-utama.jpg)

Selaku seorang yang hobi memasak, menyuguhkan panganan menggugah selera bagi keluarga adalah suatu hal yang mengasyikan bagi anda sendiri. Peran seorang  wanita bukan hanya menangani rumah saja, namun anda pun harus menyediakan kebutuhan nutrisi terpenuhi dan juga panganan yang disantap anak-anak harus menggugah selera.

Di waktu  sekarang, anda memang bisa mengorder hidangan instan tidak harus repot mengolahnya dahulu. Tapi ada juga orang yang memang ingin menghidangkan yang terbaik bagi orang yang dicintainya. Pasalnya, menyajikan masakan yang diolah sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan sesuai makanan kesukaan keluarga. 



Apakah anda adalah salah satu penikmat tongseng ayam?. Asal kamu tahu, tongseng ayam adalah hidangan khas di Nusantara yang sekarang disukai oleh banyak orang dari hampir setiap tempat di Nusantara. Kita dapat menghidangkan tongseng ayam sendiri di rumah dan boleh dijadikan hidangan kegemaranmu di hari libur.

Kita jangan bingung jika kamu ingin menyantap tongseng ayam, karena tongseng ayam tidak sukar untuk dicari dan juga anda pun bisa membuatnya sendiri di rumah. tongseng ayam bisa diolah memalui beraneka cara. Kini telah banyak sekali resep kekinian yang membuat tongseng ayam lebih lezat.

Resep tongseng ayam pun mudah sekali dibikin, lho. Kita tidak usah ribet-ribet untuk memesan tongseng ayam, karena Kita dapat menghidangkan di rumahmu. Untuk Kita yang mau menyajikannya, inilah cara untuk menyajikan tongseng ayam yang lezat yang dapat Kalian buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Tongseng Ayam:

1. Sediakan 800 gr dada ayam fillet, potong kecil
1. Gunakan 1 buah kentang ukuran besar, kupas dan potong-potong (saya skip)
1. Siapkan 200 gr kol, potong-potong
1. Ambil 2 sereh geprek
1. Gunakan 65 ml santan cair instant
1. Gunakan 1 ruas lengkuas geprek
1. Sediakan 3 lembar daun salam
1. Siapkan 3 lembar daun jeruk buang tulang daun
1. Sediakan 12 buah cabe rawit utuh (sesuaikan selera)
1. Sediakan 1 buat tomat
1. Sediakan 2 sdm kaldu jamur /ayam (optional)
1. Siapkan 1 sdt gula pasir
1. Sediakan 1/2 sdt garam
1. Ambil 700 ml air
1. Siapkan Secukupnya kecap manis dan minyak sayur untuk menumis
1. Ambil  BUMBU HALUS :
1. Siapkan 10 siung bawang merah
1. Siapkan 6 siung bawang putih
1. Ambil 1 sdt ketumbar
1. Sediakan 1/2 sdt lada bubuk
1. Gunakan 1 ruas kunyit
1. Ambil 1 sdt jintan bubuk (tambahan saya)




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Tongseng Ayam:

1. Cuci bersih ayam, kemudian potong-potong dan remas-remas dengan garam dan air perasan jeruk nipis. Bilas sebentar.
1. Siapkan panci, rebus air dan ayam hingga matang selama 20 menit. Kemudian buang airnya &amp; sisihkan
1. Tumis bumbu halus hingga harum lalu masukkan sereh, lengkuas, daun salam, daun jeruk dan tumis hingga rata
1. Masukkan ayam lalu tambahkan air aduk hingga rata dan masak hingga mendidih
1. Masukkan garam, kaldu bubuk, gula dan kecap manis. Tambahkan cabe rawit aduk perlahan dan koreksi rasa
1. Masukkan santan lalu aduk hingga rata dan masukkan kol sambil terus diaduk rata sebentar lalu matikan kompor
1. Tongseng ayam dituang ke piring saji lalu taburi bawang goreng dan daun bawang / seledri, hidangkan




Ternyata cara buat tongseng ayam yang nikamt tidak rumit ini mudah banget ya! Kamu semua mampu membuatnya. Cara Membuat tongseng ayam Sesuai banget untuk kita yang sedang belajar memasak ataupun untuk kamu yang sudah ahli dalam memasak.

Tertarik untuk mencoba membikin resep tongseng ayam nikmat simple ini? Kalau kamu ingin, yuk kita segera buruan siapkan alat-alat dan bahannya, setelah itu bikin deh Resep tongseng ayam yang enak dan tidak rumit ini. Benar-benar mudah kan. 

Oleh karena itu, ketimbang kamu diam saja, hayo kita langsung buat resep tongseng ayam ini. Dijamin anda gak akan menyesal sudah buat resep tongseng ayam mantab tidak rumit ini! Selamat mencoba dengan resep tongseng ayam mantab sederhana ini di rumah sendiri,oke!.

