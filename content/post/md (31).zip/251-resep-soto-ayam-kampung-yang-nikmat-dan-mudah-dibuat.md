---
description: "Resep Soto Ayam Kampung yang nikmat dan Mudah Dibuat"
title: "Resep Soto Ayam Kampung yang nikmat dan Mudah Dibuat"
slug: 251-resep-soto-ayam-kampung-yang-nikmat-dan-mudah-dibuat
date: 2021-04-28T23:46:37.931Z
image: https://img-global.cpcdn.com/recipes/200b823360563b58/680x482cq70/soto-ayam-kampung-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/200b823360563b58/680x482cq70/soto-ayam-kampung-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/200b823360563b58/680x482cq70/soto-ayam-kampung-foto-resep-utama.jpg
author: Betty Alexander
ratingvalue: 3.8
reviewcount: 11
recipeingredient:
- "1 ekor ayam kampung klo ta ada boleh ganti ayam pejantan"
- " Bumbu"
- "5 siung bawang putih"
- "8 siung bawang merah"
- "1/4 sdt jinten"
- "1/2 sdt lada"
- "1 sdt ketumbar"
- "2 cm kunyit"
- "2 cm jahe"
- "4 cm laos"
- "2 batang serai"
- "4 lb daun jeruk"
- "5 bt kemiri"
- "1,5-2 sdm garam"
- "1 sdt gula"
- "1 sdt kaldu jamur boleh skip"
- " Pelengkap"
- " Telur rebus"
- " Mie soun"
- " Kubis iris halus"
- "1 cm Daun bawang prei potong2"
- " Seledri iris halus"
- " Koya krupuk udang"
- " Jeruk nipis"
- " Sambal"
recipeinstructions:
- "Potong ayam jadi 4, rebus dg 3L air (sy rebus 30 menit dg api kecil hingga agak empuk)"
- "Siapkan bumbu Bawang putih, bawang merah, jinten, ketumbar, lada, kunyit, kemiri dihaluskan, tambahkan jahe, laos n daun serai geprek serta daun jeruk buang tulang daunnya, tumis dg 2 sdm minyak sayur"
- "Masukkan bumbu yg uda ditumis, garam n gula. Rebus lg 30 menit koreksi rasa. Jika suka asin bs tambah garam. (Cek uda empuk ato blm, tergantung klo ayam tua butuh waktu lbh lama proses rebusnya). Masukkan daun bawang prei n kaldu jamur 5 menit sblm api dimatikan"
- "Sajikan soto ayam dg pelengkap soun, kubis, telor, koyah, daun seledri, jeruk nipis, sambal"
categories:
- Resep
tags:
- soto
- ayam
- kampung

katakunci: soto ayam kampung 
nutrition: 143 calories
recipecuisine: Indonesian
preptime: "PT19M"
cooktime: "PT47M"
recipeyield: "4"
recipecategory: Dinner

---


![Soto Ayam Kampung](https://img-global.cpcdn.com/recipes/200b823360563b58/680x482cq70/soto-ayam-kampung-foto-resep-utama.jpg)

Andai kita seorang wanita, menyuguhkan hidangan enak buat famili adalah suatu hal yang memuaskan bagi kamu sendiri. Peran seorang ibu Tidak hanya mengurus rumah saja, tapi anda juga harus memastikan kebutuhan nutrisi tercukupi dan hidangan yang dimakan anak-anak mesti nikmat.

Di era  sekarang, anda sebenarnya dapat membeli panganan yang sudah jadi tanpa harus repot memasaknya dahulu. Tapi ada juga orang yang memang mau menyajikan yang terbaik bagi orang yang dicintainya. Karena, menghidangkan masakan yang dibuat sendiri jauh lebih higienis dan kita juga bisa menyesuaikan hidangan tersebut berdasarkan selera keluarga. 



Apakah anda seorang penggemar soto ayam kampung?. Tahukah kamu, soto ayam kampung merupakan makanan khas di Nusantara yang kini disenangi oleh orang-orang di hampir setiap wilayah di Indonesia. Kalian bisa membuat soto ayam kampung sendiri di rumahmu dan dapat dijadikan santapan favorit di hari libur.

Kamu tak perlu bingung jika kamu ingin memakan soto ayam kampung, sebab soto ayam kampung sangat mudah untuk ditemukan dan juga kalian pun bisa membuatnya sendiri di tempatmu. soto ayam kampung bisa dimasak memalui beragam cara. Saat ini sudah banyak sekali resep modern yang membuat soto ayam kampung lebih nikmat.

Resep soto ayam kampung juga sangat mudah dihidangkan, lho. Kita tidak perlu repot-repot untuk memesan soto ayam kampung, tetapi Kita bisa menyiapkan ditempatmu. Untuk Kalian yang akan membuatnya, berikut ini cara membuat soto ayam kampung yang nikamat yang dapat Kita coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Soto Ayam Kampung:

1. Gunakan 1 ekor ayam kampung (klo ta ada boleh ganti ayam pejantan)
1. Gunakan  Bumbu:
1. Ambil 5 siung bawang putih
1. Sediakan 8 siung bawang merah
1. Ambil 1/4 sdt jinten
1. Gunakan 1/2 sdt lada
1. Gunakan 1 sdt ketumbar
1. Siapkan 2 cm kunyit
1. Sediakan 2 cm jahe
1. Siapkan 4 cm laos
1. Sediakan 2 batang serai
1. Sediakan 4 lb daun jeruk
1. Sediakan 5 bt kemiri
1. Sediakan 1,5-2 sdm garam
1. Sediakan 1 sdt gula
1. Gunakan 1 sdt kaldu jamur (boleh skip)
1. Sediakan  Pelengkap
1. Sediakan  Telur rebus
1. Siapkan  Mie soun
1. Ambil  Kubis iris halus
1. Gunakan 1 cm Daun bawang prei potong2
1. Ambil  Seledri iris halus
1. Sediakan  Koya krupuk udang
1. Siapkan  Jeruk nipis
1. Siapkan  Sambal




<!--inarticleads2-->

##### Cara membuat Soto Ayam Kampung:

1. Potong ayam jadi 4, rebus dg 3L air (sy rebus 30 menit dg api kecil hingga agak empuk)
1. Siapkan bumbu - Bawang putih, bawang merah, jinten, ketumbar, lada, kunyit, kemiri dihaluskan, tambahkan jahe, laos n daun serai geprek serta daun jeruk buang tulang daunnya, tumis dg 2 sdm minyak sayur
1. Masukkan bumbu yg uda ditumis, garam n gula. Rebus lg 30 menit koreksi rasa. Jika suka asin bs tambah garam. - (Cek uda empuk ato blm, tergantung klo ayam tua butuh waktu lbh lama proses rebusnya). Masukkan daun bawang prei n kaldu jamur 5 menit sblm api dimatikan
1. Sajikan soto ayam dg pelengkap soun, kubis, telor, koyah, daun seledri, jeruk nipis, sambal




Ternyata cara membuat soto ayam kampung yang nikamt simple ini gampang banget ya! Kamu semua dapat menghidangkannya. Cara Membuat soto ayam kampung Sesuai banget buat kamu yang baru mau belajar memasak maupun bagi kamu yang telah ahli dalam memasak.

Tertarik untuk mencoba bikin resep soto ayam kampung mantab sederhana ini? Kalau kamu mau, ayo kamu segera buruan siapkan peralatan dan bahannya, setelah itu bikin deh Resep soto ayam kampung yang mantab dan tidak rumit ini. Sangat mudah kan. 

Maka dari itu, ketimbang kamu berfikir lama-lama, ayo kita langsung hidangkan resep soto ayam kampung ini. Dijamin kamu tiidak akan menyesal bikin resep soto ayam kampung nikmat tidak rumit ini! Selamat berkreasi dengan resep soto ayam kampung enak sederhana ini di rumah kalian sendiri,ya!.

