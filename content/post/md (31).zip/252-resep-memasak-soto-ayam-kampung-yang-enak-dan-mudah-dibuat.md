---
description: "Resep memasak Soto ayam kampung yang enak dan Mudah Dibuat"
title: "Resep memasak Soto ayam kampung yang enak dan Mudah Dibuat"
slug: 252-resep-memasak-soto-ayam-kampung-yang-enak-dan-mudah-dibuat
date: 2021-05-01T04:43:53.306Z
image: https://img-global.cpcdn.com/recipes/44ade79c18fd416b/680x482cq70/soto-ayam-kampung-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/44ade79c18fd416b/680x482cq70/soto-ayam-kampung-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/44ade79c18fd416b/680x482cq70/soto-ayam-kampung-foto-resep-utama.jpg
author: Cory Gardner
ratingvalue: 3.2
reviewcount: 11
recipeingredient:
- "500 gr ayam kampung"
- "1 batang daun seledri"
- "1 batang daun bawang besar"
- "1 buah serai geprek"
- "1 daun jeruk"
- "secukupnya Garam"
- " Kaldu bubuk"
- "5 buah cabe rawit dicemplungkan aja"
- "1/2 buah jeruk nipis"
- " Minyak untuk menumis"
- " Air"
- " Bumbu halus "
- "2 bawang putih besar"
- "6 bawang merah"
- "1/2 kemiri"
- "1 sdt ketumbar"
- "1 ruas jahe"
- "1 ruas lengkuas"
- "1 ruas jari kunyit"
- "1 sdt merica"
recipeinstructions:
- "Haluskan bumbu dengan blender. Tumis bumbu halus dengan serai dan daun jeruk hingga harum. Tiriskan"
- "Didihkan air dan rebus ayam kampung hingga matang (sampai daging empuk)"
- "Setelah ayam matang, masukkan bumbu halus. Aduk hingga bumbu tercampur rata. Didihkan kembali hingga bumbu meresap ke ayam."
- "Tambahkan garam dan kaldu bubuk. Kemudian masukkan irisan daun bawanfg dan seledri. Tunggu hingga meresap. Koreksi rasa."
- "Jika sudah pas. Matikan kompor. Tambahkan perasan jeruk nipis."
- "Lebih nikmat disajikan dengan bihun, kecambah, dan irisan kubis 😊"
categories:
- Resep
tags:
- soto
- ayam
- kampung

katakunci: soto ayam kampung 
nutrition: 283 calories
recipecuisine: Indonesian
preptime: "PT40M"
cooktime: "PT37M"
recipeyield: "4"
recipecategory: Dessert

---


![Soto ayam kampung](https://img-global.cpcdn.com/recipes/44ade79c18fd416b/680x482cq70/soto-ayam-kampung-foto-resep-utama.jpg)

Andai kalian seorang yang hobi masak, menyediakan hidangan sedap pada orang tercinta merupakan hal yang memuaskan bagi kamu sendiri. Peran seorang ibu Tidak cuma mengurus rumah saja, tetapi kamu juga harus memastikan keperluan gizi tercukupi dan panganan yang dikonsumsi keluarga tercinta wajib mantab.

Di era  sekarang, anda memang mampu memesan olahan praktis tidak harus repot mengolahnya terlebih dahulu. Tapi ada juga mereka yang memang mau memberikan makanan yang terenak bagi orang yang dicintainya. Karena, memasak sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan makanan tersebut berdasarkan masakan kesukaan famili. 



Mungkinkah kamu seorang penikmat soto ayam kampung?. Asal kamu tahu, soto ayam kampung adalah sajian khas di Nusantara yang sekarang digemari oleh setiap orang dari hampir setiap tempat di Nusantara. Kalian dapat menghidangkan soto ayam kampung olahan sendiri di rumahmu dan boleh dijadikan camilan kesukaanmu di akhir pekanmu.

Anda tak perlu bingung untuk memakan soto ayam kampung, karena soto ayam kampung mudah untuk didapatkan dan juga kita pun boleh menghidangkannya sendiri di tempatmu. soto ayam kampung boleh diolah dengan beragam cara. Kini telah banyak sekali cara kekinian yang membuat soto ayam kampung semakin lezat.

Resep soto ayam kampung juga sangat mudah dihidangkan, lho. Anda jangan capek-capek untuk membeli soto ayam kampung, karena Anda mampu membuatnya di rumahmu. Bagi Anda yang akan mencobanya, berikut ini cara membuat soto ayam kampung yang lezat yang bisa Kamu coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Soto ayam kampung:

1. Siapkan 500 gr ayam kampung
1. Gunakan 1 batang daun seledri
1. Ambil 1 batang daun bawang besar
1. Siapkan 1 buah serai geprek
1. Ambil 1 daun jeruk
1. Siapkan secukupnya Garam
1. Sediakan  Kaldu bubuk
1. Ambil 5 buah cabe rawit (dicemplungkan aja)
1. Siapkan 1/2 buah jeruk nipis
1. Sediakan  Minyak untuk menumis
1. Siapkan  Air
1. Gunakan  Bumbu halus :
1. Siapkan 2 bawang putih besar
1. Siapkan 6 bawang merah
1. Gunakan 1/2 kemiri
1. Gunakan 1 sdt ketumbar
1. Sediakan 1 ruas jahe
1. Gunakan 1 ruas lengkuas
1. Sediakan 1 ruas jari kunyit
1. Gunakan 1 sdt merica




<!--inarticleads2-->

##### Cara membuat Soto ayam kampung:

1. Haluskan bumbu dengan blender. Tumis bumbu halus dengan serai dan daun jeruk hingga harum. Tiriskan
1. Didihkan air dan rebus ayam kampung hingga matang (sampai daging empuk)
1. Setelah ayam matang, masukkan bumbu halus. Aduk hingga bumbu tercampur rata. Didihkan kembali hingga bumbu meresap ke ayam.
1. Tambahkan garam dan kaldu bubuk. Kemudian masukkan irisan daun bawanfg dan seledri. Tunggu hingga meresap. Koreksi rasa.
1. Jika sudah pas. Matikan kompor. Tambahkan perasan jeruk nipis.
1. Lebih nikmat disajikan dengan bihun, kecambah, dan irisan kubis 😊




Ternyata cara buat soto ayam kampung yang enak sederhana ini mudah banget ya! Anda Semua mampu membuatnya. Cara buat soto ayam kampung Cocok sekali buat kita yang baru mau belajar memasak maupun juga bagi anda yang telah lihai dalam memasak.

Apakah kamu ingin mulai mencoba bikin resep soto ayam kampung enak tidak ribet ini? Kalau kamu mau, yuk kita segera siapkan alat dan bahannya, setelah itu bikin deh Resep soto ayam kampung yang mantab dan sederhana ini. Benar-benar gampang kan. 

Oleh karena itu, daripada kita berfikir lama-lama, yuk kita langsung sajikan resep soto ayam kampung ini. Dijamin kamu gak akan nyesel sudah buat resep soto ayam kampung lezat simple ini! Selamat mencoba dengan resep soto ayam kampung lezat sederhana ini di rumah kalian sendiri,ya!.

