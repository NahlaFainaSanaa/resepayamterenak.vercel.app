---
description: "Cara membuat Soto Ayam Sederhana dan Mudah Dibuat"
title: "Cara membuat Soto Ayam Sederhana dan Mudah Dibuat"
slug: 233-cara-membuat-soto-ayam-sederhana-dan-mudah-dibuat
date: 2021-01-15T16:36:07.582Z
image: https://img-global.cpcdn.com/recipes/a042194080e96ec6/680x482cq70/soto-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a042194080e96ec6/680x482cq70/soto-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a042194080e96ec6/680x482cq70/soto-ayam-foto-resep-utama.jpg
author: Charlie Larson
ratingvalue: 4.6
reviewcount: 3
recipeingredient:
- "1/2 kg ayam dipotong jadi 4"
- "1,5 liter air"
- " Bumbu halus"
- "10 siung bawang merah"
- "6 siung bawang putih"
- "1 ruas kunyit"
- "1 ruas jahe"
- "5 buah kemiri"
- " Bumbu cemplung"
- "1 batang serai"
- "1 ruas lengkuas"
- "5 daun jeruk"
- "3 daun salam"
- "1 sdt ketumbar"
- "1 sdt merica bubuk"
- " Daun bawang"
- " Garamgulakaldu jamur"
- " Pelengkap"
- " Soun rendam air hangat"
- " Telur rebus"
- " Tauge dan kol bisa dikukus jika tidak suka mentah"
recipeinstructions:
- "Rebus air sampai mendidih, kemudian masukkan bumbu cemplung dan ayam (garam, gula, kaldu jamur dan daun bawang dimasukkan terakhir/menjelang matang)"
- "Terakhir masukkan daun bawang,Gula Garam dan kaldu jamur. Koreksi rasa sampai dirasa pas"
- "Setelah matang, sajikan hangat-hangat dengan bahan pelengkapnya. Jika suka bisa ditambahkan kecap manis."
categories:
- Resep
tags:
- soto
- ayam

katakunci: soto ayam 
nutrition: 118 calories
recipecuisine: Indonesian
preptime: "PT32M"
cooktime: "PT40M"
recipeyield: "1"
recipecategory: Lunch

---


![Soto Ayam](https://img-global.cpcdn.com/recipes/a042194080e96ec6/680x482cq70/soto-ayam-foto-resep-utama.jpg)

Selaku seorang wanita, menyediakan panganan enak pada keluarga adalah hal yang menyenangkan untuk kamu sendiri. Kewajiban seorang  wanita Tidak cuma menjaga rumah saja, tapi anda juga wajib memastikan keperluan nutrisi terpenuhi dan juga santapan yang dikonsumsi anak-anak harus nikmat.

Di masa  sekarang, anda memang dapat membeli olahan instan tidak harus ribet memasaknya dahulu. Tetapi ada juga lho mereka yang selalu mau memberikan hidangan yang terbaik untuk orang yang dicintainya. Lantaran, menghidangkan masakan yang dibuat sendiri jauh lebih higienis dan kita juga bisa menyesuaikan sesuai selera famili. 



Mungkinkah kamu salah satu penyuka soto ayam?. Tahukah kamu, soto ayam merupakan makanan khas di Nusantara yang kini digemari oleh orang-orang dari hampir setiap daerah di Nusantara. Kamu bisa membuat soto ayam olahan sendiri di rumahmu dan dapat dijadikan hidangan kesukaanmu di hari liburmu.

Kamu tak perlu bingung untuk menyantap soto ayam, sebab soto ayam gampang untuk didapatkan dan juga kalian pun bisa memasaknya sendiri di tempatmu. soto ayam dapat dibuat dengan bermacam cara. Saat ini sudah banyak resep modern yang menjadikan soto ayam semakin lebih mantap.

Resep soto ayam pun mudah sekali dibikin, lho. Kamu tidak perlu capek-capek untuk memesan soto ayam, tetapi Kalian bisa membuatnya di rumahmu. Untuk Anda yang hendak menyajikannya, berikut cara untuk membuat soto ayam yang enak yang bisa Kamu coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Soto Ayam:

1. Gunakan 1/2 kg ayam dipotong jadi 4
1. Gunakan 1,5 liter air
1. Siapkan  Bumbu halus
1. Siapkan 10 siung bawang merah
1. Ambil 6 siung bawang putih
1. Sediakan 1 ruas kunyit
1. Ambil 1 ruas jahe
1. Sediakan 5 buah kemiri
1. Sediakan  Bumbu cemplung
1. Sediakan 1 batang serai
1. Sediakan 1 ruas lengkuas
1. Gunakan 5 daun jeruk
1. Siapkan 3 daun salam
1. Sediakan 1 sdt ketumbar
1. Gunakan 1 sdt merica bubuk
1. Ambil  Daun bawang
1. Siapkan  Garam+gula+kaldu jamur
1. Sediakan  Pelengkap
1. Gunakan  Soun, rendam air hangat
1. Ambil  Telur rebus
1. Gunakan  Tauge dan kol, bisa dikukus jika tidak suka mentah




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Soto Ayam:

1. Rebus air sampai mendidih, kemudian masukkan bumbu cemplung dan ayam (garam, gula, kaldu jamur dan daun bawang dimasukkan terakhir/menjelang matang)
1. Terakhir masukkan daun bawang,Gula Garam dan kaldu jamur. Koreksi rasa sampai dirasa pas
1. Setelah matang, sajikan hangat-hangat dengan bahan pelengkapnya. Jika suka bisa ditambahkan kecap manis.




Ternyata resep soto ayam yang enak tidak rumit ini mudah banget ya! Kalian semua mampu memasaknya. Cara buat soto ayam Sangat cocok banget buat kita yang sedang belajar memasak atau juga bagi kamu yang sudah hebat memasak.

Tertarik untuk mencoba membikin resep soto ayam mantab tidak rumit ini? Kalau anda mau, ayo kamu segera menyiapkan alat-alat dan bahan-bahannya, lantas buat deh Resep soto ayam yang enak dan simple ini. Betul-betul mudah kan. 

Maka dari itu, ketimbang kita berfikir lama-lama, yuk langsung aja sajikan resep soto ayam ini. Dijamin kamu tiidak akan nyesel sudah bikin resep soto ayam enak sederhana ini! Selamat mencoba dengan resep soto ayam lezat simple ini di rumah sendiri,oke!.

