---
description: "Resep memasak 12. Tongseng Ayam yang nikmat Untuk Jualan"
title: "Resep memasak 12. Tongseng Ayam yang nikmat Untuk Jualan"
slug: 137-resep-memasak-12-tongseng-ayam-yang-nikmat-untuk-jualan
date: 2021-05-25T13:23:29.308Z
image: https://img-global.cpcdn.com/recipes/529c56387a2d6880/680x482cq70/12-tongseng-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/529c56387a2d6880/680x482cq70/12-tongseng-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/529c56387a2d6880/680x482cq70/12-tongseng-ayam-foto-resep-utama.jpg
author: Mittie Martin
ratingvalue: 3.1
reviewcount: 14
recipeingredient:
- "400 gram ayam tanpa tulang dan kulit potong kotak2"
- "2 batang serai"
- "5 lembar daun jeruk"
- "2 kapulaga"
- "3 cengkeh"
- "1 cm lengkuas geprek"
- "700 ml air"
- "200 ml santan kental"
- "2 sdm kecap manis"
- "1 buah tomat"
- "Secukupnya garamgula dan lada putih"
- "3 lembar kubis saya skip"
- "1 batang daun bawang iris2"
- "Secukupnya cabe rawit"
- " Bumbu halus"
- "4-5 siung bawang merah me bawang merah besar setengah"
- "4 siung bawang putih"
- "1/2 sdt ketumbar"
- "1 sdt merica"
- "1 cm kunyit  setengah sdt kunyit bubuk"
- "4 kemiri"
- "3 cabe rawit disesuaikan"
recipeinstructions:
- "Siapkan bahan-bahan"
- "Tumis bumbu halus dengan serai, cengkeh, kapulaga, daun jeruk, lengkuas sampai harum..lalu masukkan cabe rawit dan ayam..masak sampai ayam berubah warna.. tambahkan air dan masak sampai mendidih"
- "Masukkan santan kental, bumbui dengan garam,gula,lada, dan kecap.. Aduk agar santan tidak pecah"
- "Masukkan kubis, lalu tomat dan daun bawang.. masak jangan terlalu lama agar kubis masih garing.. (kali ini saya skip kubis yaa), Tongseng ayam siap dihidangkan dengan taburan bawang goreng🤤"
categories:
- Resep
tags:
- 12
- tongseng
- ayam

katakunci: 12 tongseng ayam 
nutrition: 127 calories
recipecuisine: Indonesian
preptime: "PT39M"
cooktime: "PT37M"
recipeyield: "1"
recipecategory: Lunch

---


![12. Tongseng Ayam](https://img-global.cpcdn.com/recipes/529c56387a2d6880/680x482cq70/12-tongseng-ayam-foto-resep-utama.jpg)

Selaku seorang yang hobi memasak, mempersiapkan olahan lezat pada orang tercinta adalah hal yang memuaskan bagi anda sendiri. Peran seorang ibu Tidak cuman mengurus rumah saja, tapi anda pun harus menyediakan keperluan gizi tercukupi dan juga panganan yang dikonsumsi keluarga tercinta wajib menggugah selera.

Di era  sekarang, anda sebenarnya bisa memesan santapan praktis tidak harus capek mengolahnya dulu. Tapi banyak juga lho mereka yang selalu ingin memberikan hidangan yang terlezat untuk keluarganya. Lantaran, menghidangkan masakan sendiri akan jauh lebih bersih dan bisa menyesuaikan hidangan tersebut berdasarkan masakan kesukaan keluarga. 



Mungkinkah kamu seorang penyuka 12. tongseng ayam?. Tahukah kamu, 12. tongseng ayam merupakan hidangan khas di Indonesia yang saat ini disukai oleh banyak orang di berbagai daerah di Indonesia. Kita bisa memasak 12. tongseng ayam sendiri di rumahmu dan pasti jadi makanan kesukaanmu di akhir pekanmu.

Kalian tidak usah bingung untuk menyantap 12. tongseng ayam, karena 12. tongseng ayam sangat mudah untuk dicari dan juga kamu pun bisa memasaknya sendiri di rumah. 12. tongseng ayam boleh dimasak dengan bermacam cara. Sekarang sudah banyak sekali resep kekinian yang menjadikan 12. tongseng ayam lebih nikmat.

Resep 12. tongseng ayam pun sangat gampang untuk dibuat, lho. Kamu tidak perlu capek-capek untuk membeli 12. tongseng ayam, karena Anda dapat menyajikan di rumahmu. Bagi Kita yang hendak menghidangkannya, inilah cara menyajikan 12. tongseng ayam yang mantab yang dapat Kalian buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan 12. Tongseng Ayam:

1. Ambil 400 gram ayam tanpa tulang dan kulit (potong kotak2)
1. Ambil 2 batang serai
1. Sediakan 5 lembar daun jeruk
1. Gunakan 2 kapulaga
1. Gunakan 3 cengkeh
1. Siapkan 1 cm lengkuas (geprek)
1. Ambil 700 ml air
1. Gunakan 200 ml santan kental
1. Ambil 2 sdm kecap manis
1. Sediakan 1 buah tomat
1. Sediakan Secukupnya garam,gula dan lada putih
1. Sediakan 3 lembar kubis (saya skip)
1. Ambil 1 batang daun bawang (iris2)
1. Siapkan Secukupnya cabe rawit
1. Gunakan  Bumbu halus
1. Gunakan 4-5 siung bawang merah (me: bawang merah besar setengah)
1. Ambil 4 siung bawang putih
1. Ambil 1/2 sdt ketumbar
1. Siapkan 1 sdt merica
1. Ambil 1 cm kunyit / setengah sdt kunyit bubuk
1. Ambil 4 kemiri
1. Siapkan 3 cabe rawit (disesuaikan)




<!--inarticleads2-->

##### Cara menyiapkan 12. Tongseng Ayam:

1. Siapkan bahan-bahan
1. Tumis bumbu halus dengan serai, cengkeh, kapulaga, daun jeruk, lengkuas sampai harum..lalu masukkan cabe rawit dan ayam..masak sampai ayam berubah warna.. tambahkan air dan masak sampai mendidih
1. Masukkan santan kental, bumbui dengan garam,gula,lada, dan kecap.. Aduk agar santan tidak pecah
1. Masukkan kubis, lalu tomat dan daun bawang.. masak jangan terlalu lama agar kubis masih garing.. (kali ini saya skip kubis yaa), Tongseng ayam siap dihidangkan dengan taburan bawang goreng🤤




Wah ternyata resep 12. tongseng ayam yang mantab sederhana ini enteng sekali ya! Kalian semua mampu memasaknya. Cara Membuat 12. tongseng ayam Cocok banget untuk kalian yang sedang belajar memasak ataupun untuk kalian yang telah hebat memasak.

Apakah kamu tertarik mulai mencoba bikin resep 12. tongseng ayam nikmat simple ini? Kalau anda ingin, ayo kalian segera menyiapkan peralatan dan bahannya, lalu buat deh Resep 12. tongseng ayam yang nikmat dan sederhana ini. Benar-benar taidak sulit kan. 

Maka, daripada anda berfikir lama-lama, yuk kita langsung saja sajikan resep 12. tongseng ayam ini. Pasti kamu tiidak akan menyesal sudah bikin resep 12. tongseng ayam lezat simple ini! Selamat berkreasi dengan resep 12. tongseng ayam lezat simple ini di rumah kalian sendiri,oke!.

