---
description: "Bahan-bahan Ayam Asam Manis Bumbu Rempah yang lezat dan Mudah Dibuat"
title: "Bahan-bahan Ayam Asam Manis Bumbu Rempah yang lezat dan Mudah Dibuat"
slug: 159-bahan-bahan-ayam-asam-manis-bumbu-rempah-yang-lezat-dan-mudah-dibuat
date: 2021-02-10T10:17:33.875Z
image: https://img-global.cpcdn.com/recipes/39522eaee6e3c6f3/680x482cq70/ayam-asam-manis-bumbu-rempah-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/39522eaee6e3c6f3/680x482cq70/ayam-asam-manis-bumbu-rempah-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/39522eaee6e3c6f3/680x482cq70/ayam-asam-manis-bumbu-rempah-foto-resep-utama.jpg
author: Vera Cobb
ratingvalue: 4.7
reviewcount: 3
recipeingredient:
- "1 ekor ayam"
- "1 bungkus kecap me bango 3k"
- "1 bungkus kecil asam"
- "secukupnya Ketumbar"
- "3 butir Kemiri"
- "6 siung bawang merah"
- "3 siung bawang putih"
- "4 cm kunyit"
- "2 cm jahe"
- "4 cm lengkuas"
- "1 buah gula merah"
- " Sereh"
- " Daun salam"
- "1 liter Air"
- "3 sendok makan gula pasir"
- "1 sendok teh garam"
- "secukupnya Kaldu bubuk"
recipeinstructions:
- "Cuci bersih ayam yg sudah dipotong potong"
- "Haluskan ketumbar, kemiri, bawang merah, bawang putih, kunyit, asam jawa, gula merah"
- "Tumis bumbu hingga harum kemudian geprek dan masukkan jahe, lengkuas, sereh dan daun salam"
- "Masukan ayam, aduk aduk agar bumbu meresap lalu tambahkan air, diamkan hingga mendidih"
- "Tambahkan kecap, gula pasir, garam, kaldu bubuk. Koreksi rasa lalu masak hingga air menyurut. Koreksi rasa kembali"
- "Setelah matang angkat dan sajikan dengan penuh cinta"
categories:
- Resep
tags:
- ayam
- asam
- manis

katakunci: ayam asam manis 
nutrition: 143 calories
recipecuisine: Indonesian
preptime: "PT11M"
cooktime: "PT55M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam Asam Manis Bumbu Rempah](https://img-global.cpcdn.com/recipes/39522eaee6e3c6f3/680x482cq70/ayam-asam-manis-bumbu-rempah-foto-resep-utama.jpg)

Selaku seorang wanita, mempersiapkan santapan nikmat bagi keluarga tercinta merupakan suatu hal yang memuaskan bagi kita sendiri. Kewajiban seorang ibu bukan sekedar mengerjakan pekerjaan rumah saja, tapi kamu pun harus menyediakan keperluan nutrisi tercukupi dan masakan yang disantap anak-anak wajib sedap.

Di masa  sekarang, kalian sebenarnya bisa membeli panganan yang sudah jadi meski tidak harus susah memasaknya lebih dulu. Tapi banyak juga lho orang yang memang ingin memberikan yang terlezat untuk orang yang dicintainya. Pasalnya, menyajikan masakan sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan makanan tersebut berdasarkan masakan kesukaan famili. 



Mungkinkah kamu seorang penikmat ayam asam manis bumbu rempah?. Tahukah kamu, ayam asam manis bumbu rempah adalah sajian khas di Nusantara yang sekarang digemari oleh banyak orang di hampir setiap tempat di Nusantara. Kamu bisa menyajikan ayam asam manis bumbu rempah buatan sendiri di rumahmu dan dapat dijadikan makanan favorit di akhir pekan.

Kalian tidak perlu bingung jika kamu ingin mendapatkan ayam asam manis bumbu rempah, karena ayam asam manis bumbu rempah tidak sulit untuk dicari dan kamu pun boleh mengolahnya sendiri di rumah. ayam asam manis bumbu rempah dapat diolah lewat beraneka cara. Saat ini telah banyak resep modern yang menjadikan ayam asam manis bumbu rempah semakin lebih enak.

Resep ayam asam manis bumbu rempah pun mudah sekali dibikin, lho. Anda tidak usah capek-capek untuk membeli ayam asam manis bumbu rempah, sebab Kalian mampu membuatnya ditempatmu. Bagi Kalian yang ingin mencobanya, inilah cara membuat ayam asam manis bumbu rempah yang lezat yang dapat Anda hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Ayam Asam Manis Bumbu Rempah:

1. Sediakan 1 ekor ayam
1. Ambil 1 bungkus kecap (me bango 3k)
1. Gunakan 1 bungkus kecil asam
1. Sediakan secukupnya Ketumbar
1. Siapkan 3 butir Kemiri
1. Siapkan 6 siung bawang merah
1. Ambil 3 siung bawang putih
1. Gunakan 4 cm kunyit
1. Ambil 2 cm jahe
1. Siapkan 4 cm lengkuas
1. Siapkan 1 buah gula merah
1. Gunakan  Sereh
1. Ambil  Daun salam
1. Sediakan 1 liter Air
1. Ambil 3 sendok makan gula pasir
1. Gunakan 1 sendok teh garam
1. Siapkan secukupnya Kaldu bubuk




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam Asam Manis Bumbu Rempah:

1. Cuci bersih ayam yg sudah dipotong potong
1. Haluskan ketumbar, kemiri, bawang merah, bawang putih, kunyit, asam jawa, gula merah
1. Tumis bumbu hingga harum kemudian geprek dan masukkan jahe, lengkuas, sereh dan daun salam
1. Masukan ayam, aduk aduk agar bumbu meresap lalu tambahkan air, diamkan hingga mendidih
1. Tambahkan kecap, gula pasir, garam, kaldu bubuk. Koreksi rasa lalu masak hingga air menyurut. Koreksi rasa kembali
1. Setelah matang angkat dan sajikan dengan penuh cinta




Wah ternyata resep ayam asam manis bumbu rempah yang lezat simple ini mudah banget ya! Semua orang dapat menghidangkannya. Cara Membuat ayam asam manis bumbu rempah Sangat sesuai sekali untuk kalian yang sedang belajar memasak ataupun untuk anda yang telah lihai dalam memasak.

Tertarik untuk mencoba bikin resep ayam asam manis bumbu rempah enak sederhana ini? Kalau anda mau, ayo kalian segera siapin alat-alat dan bahan-bahannya, setelah itu buat deh Resep ayam asam manis bumbu rempah yang nikmat dan tidak rumit ini. Sangat gampang kan. 

Maka, daripada kalian berfikir lama-lama, ayo kita langsung saja hidangkan resep ayam asam manis bumbu rempah ini. Pasti kalian gak akan nyesel sudah bikin resep ayam asam manis bumbu rempah mantab tidak rumit ini! Selamat mencoba dengan resep ayam asam manis bumbu rempah nikmat simple ini di tempat tinggal kalian sendiri,ya!.

