---
description: "Cara membuat Ayam goreng Laos/lengkuas pasti enak yang sedap dan Mudah Dibuat"
title: "Cara membuat Ayam goreng Laos/lengkuas pasti enak yang sedap dan Mudah Dibuat"
slug: 279-cara-membuat-ayam-goreng-laos-lengkuas-pasti-enak-yang-sedap-dan-mudah-dibuat
date: 2021-04-28T01:33:16.287Z
image: https://img-global.cpcdn.com/recipes/0ff2c473d1d24128/680x482cq70/ayam-goreng-laoslengkuas-pasti-enak-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0ff2c473d1d24128/680x482cq70/ayam-goreng-laoslengkuas-pasti-enak-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0ff2c473d1d24128/680x482cq70/ayam-goreng-laoslengkuas-pasti-enak-foto-resep-utama.jpg
author: Eugene Joseph
ratingvalue: 3.3
reviewcount: 3
recipeingredient:
- "1 ekor ayam kampungnegri"
- "4 lembar daun salam"
- "1 batan sereh geprek"
- "4 ruas lengkuas diparut lalu sisihkan"
- " Bumbu halus"
- "8 siung bawang merah"
- "7 siung bawang putih"
- "2 sdm ketumbar"
- "7 butir kemiri"
- "2 ruas kunyit"
- "2 ruas jahe"
- " Penyedap secukupnya"
- " Gula"
- " Garam"
- " Kaldu jamurroycomasako"
recipeinstructions:
- "Saya pakai ayam kampung, akhirnya pake slow cooker biar daging empuk karna gak ada presto, hihi.. setrlah empuk jangab buang kuah nya ya karna untuk kaldu campuran"
- "Haluskan dengan blender bumbu sampai halus lalu tumis sampai harum. Masukkan daun salam, sereh dan parutan lengkuas. Aduk hingga daun salam agak layu dan bau tumisan harum"
- "Masukkan ayam, aduk sebentar lalu beri air kaldu. Kalau mau pake ayam negri dimasukkan ke tumisan bumbu dalam keadaan mentah lalu beri air sebanyak 500ml."
- "Rebus ayam hingga bumbu meresap dan agak susut. Setelah matang siapkan minyak goreng panas, goreng ayam beserta kuah (untuk serbuk ayam) hingga kecoklatan."
- "Setelah matang angkat lalu sajikan. Bon apetit 😘😘"
categories:
- Resep
tags:
- ayam
- goreng
- laoslengkuas

katakunci: ayam goreng laoslengkuas 
nutrition: 290 calories
recipecuisine: Indonesian
preptime: "PT12M"
cooktime: "PT35M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam goreng Laos/lengkuas pasti enak](https://img-global.cpcdn.com/recipes/0ff2c473d1d24128/680x482cq70/ayam-goreng-laoslengkuas-pasti-enak-foto-resep-utama.jpg)

Sebagai seorang wanita, menyediakan olahan mantab pada keluarga tercinta merupakan hal yang memuaskan bagi kamu sendiri. Peran seorang istri bukan cuman mengurus rumah saja, tetapi anda pun wajib memastikan keperluan nutrisi terpenuhi dan santapan yang dikonsumsi orang tercinta wajib sedap.

Di era  saat ini, kita sebenarnya mampu mengorder panganan yang sudah jadi tanpa harus ribet memasaknya lebih dulu. Namun ada juga orang yang selalu mau memberikan yang terbaik untuk orang tercintanya. Pasalnya, menyajikan masakan yang dibuat sendiri akan jauh lebih higienis dan bisa menyesuaikan makanan tersebut sesuai dengan masakan kesukaan keluarga tercinta. 

Penggunaan lengkuas atau laos sangat berperan penting terhadap resep ayam goreng lengkuas yang akan dibuat. Jadi pilihlah lengkuas yang masih segar sehingga saat diparut dan diberi bumbu halus menghasilkan remah-remah dengan citarasa yang istimewa. Super kriuk crispy, gurih dan lezat!

Apakah anda seorang penikmat ayam goreng laos/lengkuas pasti enak?. Tahukah kamu, ayam goreng laos/lengkuas pasti enak merupakan sajian khas di Nusantara yang kini disukai oleh setiap orang dari hampir setiap wilayah di Indonesia. Anda dapat memasak ayam goreng laos/lengkuas pasti enak hasil sendiri di rumahmu dan boleh jadi makanan favoritmu di hari libur.

Kamu tidak usah bingung untuk memakan ayam goreng laos/lengkuas pasti enak, sebab ayam goreng laos/lengkuas pasti enak mudah untuk dicari dan juga kamu pun dapat menghidangkannya sendiri di rumah. ayam goreng laos/lengkuas pasti enak dapat diolah memalui beraneka cara. Kini telah banyak banget cara kekinian yang menjadikan ayam goreng laos/lengkuas pasti enak semakin mantap.

Resep ayam goreng laos/lengkuas pasti enak pun sangat mudah untuk dibuat, lho. Anda tidak usah ribet-ribet untuk membeli ayam goreng laos/lengkuas pasti enak, karena Kamu bisa menghidangkan di rumah sendiri. Bagi Kita yang akan menyajikannya, berikut ini resep untuk menyajikan ayam goreng laos/lengkuas pasti enak yang nikamat yang bisa Kalian coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Ayam goreng Laos/lengkuas pasti enak:

1. Sediakan 1 ekor ayam kampung/negri
1. Ambil 4 lembar daun salam
1. Gunakan 1 batan sereh geprek
1. Siapkan 4 ruas lengkuas (diparut lalu sisihkan)
1. Siapkan  Bumbu halus
1. Gunakan 8 siung bawang merah
1. Ambil 7 siung bawang putih
1. Siapkan 2 sdm ketumbar
1. Siapkan 7 butir kemiri
1. Gunakan 2 ruas kunyit
1. Sediakan 2 ruas jahe
1. Gunakan  Penyedap (secukupnya)
1. Ambil  Gula
1. Gunakan  Garam
1. Gunakan  Kaldu jamur/royco/masako


Aromanya wangi dan rasanya gurih meresap. Enak dimakan hangat buat lauk berbuka puasa atau sahur. Coba saja resep ayam goreng lengkuas yang satu ini. Rasanya yang gurih, bercampur kremesan dari parutan bumbu. 

<!--inarticleads2-->

##### Cara menyiapkan Ayam goreng Laos/lengkuas pasti enak:

1. Saya pakai ayam kampung, akhirnya pake slow cooker biar daging empuk karna gak ada presto, hihi.. setrlah empuk jangab buang kuah nya ya karna untuk kaldu campuran
1. Haluskan dengan blender bumbu sampai halus lalu tumis sampai harum. Masukkan daun salam, sereh dan parutan lengkuas. Aduk hingga daun salam agak layu dan bau tumisan harum
1. Masukkan ayam, aduk sebentar lalu beri air kaldu. Kalau mau pake ayam negri dimasukkan ke tumisan bumbu dalam keadaan mentah lalu beri air sebanyak 500ml.
1. Rebus ayam hingga bumbu meresap dan agak susut. Setelah matang siapkan minyak goreng panas, goreng ayam beserta kuah (untuk serbuk ayam) hingga kecoklatan.
1. Setelah matang angkat lalu sajikan. Bon apetit 😘😘


Bukan hal yang mengherankan memang, karena daging ayam yang mempunyai tekstur yang kenyal, empuk dan enak ini bisa disajikan menjadi berbagai macam masakan enak dan. Salah satu Ikon kuliner Indonesia dari kota Bandung: Ayam Goreng Lengkuas. Sekilas mirip Ayam Goreng ditaburi serundeng dan serundeng ini berasal dari lengkuas yang diparut. Ayam goreng memang menjadi salah satu menu hidangan favorit, baik bagi anak-anak maupun orang dewasa. Tidak heran, daging ayam yang kenyal dan nikmat itu memang paling enak disajikan saat masih panas-panas, apalagi kalau. 

Wah ternyata resep ayam goreng laos/lengkuas pasti enak yang mantab tidak ribet ini mudah banget ya! Semua orang mampu memasaknya. Cara buat ayam goreng laos/lengkuas pasti enak Cocok banget untuk kamu yang baru belajar memasak ataupun bagi kalian yang sudah ahli memasak.

Apakah kamu mau mencoba membikin resep ayam goreng laos/lengkuas pasti enak enak tidak rumit ini? Kalau ingin, yuk kita segera siapkan alat-alat dan bahannya, maka bikin deh Resep ayam goreng laos/lengkuas pasti enak yang enak dan tidak ribet ini. Betul-betul mudah kan. 

Jadi, daripada kalian diam saja, maka kita langsung saja sajikan resep ayam goreng laos/lengkuas pasti enak ini. Pasti kamu gak akan menyesal sudah buat resep ayam goreng laos/lengkuas pasti enak lezat sederhana ini! Selamat mencoba dengan resep ayam goreng laos/lengkuas pasti enak mantab sederhana ini di rumah sendiri,oke!.

