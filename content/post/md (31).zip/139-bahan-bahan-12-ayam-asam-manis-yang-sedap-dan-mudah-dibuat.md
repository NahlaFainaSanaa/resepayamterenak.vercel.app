---
description: "Bahan-bahan 12. Ayam asam manis yang sedap dan Mudah Dibuat"
title: "Bahan-bahan 12. Ayam asam manis yang sedap dan Mudah Dibuat"
slug: 139-bahan-bahan-12-ayam-asam-manis-yang-sedap-dan-mudah-dibuat
date: 2021-04-20T16:07:54.538Z
image: https://img-global.cpcdn.com/recipes/885227f325db5f3f/680x482cq70/12-ayam-asam-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/885227f325db5f3f/680x482cq70/12-ayam-asam-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/885227f325db5f3f/680x482cq70/12-ayam-asam-manis-foto-resep-utama.jpg
author: Stanley Reed
ratingvalue: 3.1
reviewcount: 13
recipeingredient:
- "1/2 kg dada ayam potong sesuai selera"
- "2 sdm kecap asin"
- "1 buah jeruk nipis"
- "5 sdm tepung maizena"
- "2 btr putih telur"
- "Secukupnya minyak goreng"
- "1 buah paprika hijau"
- "1 buah nanas"
- "3 buah cabe merah besar"
- "1 buah bawang bombay"
- "3 siung bawang putih"
- "2 batang preidaun bawang"
- "2 sdm gula pasir"
- "3 sdm saos tiram"
- "5 sdm saos tomat"
- "1 sdm minyak wijen"
- "1 sdt lada bubuk"
- "1 sdt garam"
- "1 sdm margarinutk menumis"
recipeinstructions:
- "Potong dada ayam, cuci bersih tambahkan kecap asin dan perasan jeruk nipis, diamkan 10 menit."
- "Tambahkan putih telur dan tepung maizena aduk rata."
- "Goreng ayam sampai berwarna kuning keemasan."
- "Siapkan bahan yg akan ditumis, potong sesuai gambar dan disiapkan juga saos pelengkap utk penunjang rasa."
- "Tumis bawang putih dng sedikit margarin."
- "Berikutnya masukkan paprika dan bawang bombay"
- "Disusul cabe merah besar, ayam goreng, nanas dan semua saos, garam, gula, dan lada bubuk."
- "Terakhir baru masukkan bawang prei."
- "Angkat dan hidangkan dng nasi panas."
categories:
- Resep
tags:
- 12
- ayam
- asam

katakunci: 12 ayam asam 
nutrition: 279 calories
recipecuisine: Indonesian
preptime: "PT32M"
cooktime: "PT30M"
recipeyield: "3"
recipecategory: Lunch

---


![12. Ayam asam manis](https://img-global.cpcdn.com/recipes/885227f325db5f3f/680x482cq70/12-ayam-asam-manis-foto-resep-utama.jpg)

Apabila kalian seorang orang tua, mempersiapkan masakan sedap kepada keluarga tercinta merupakan suatu hal yang sangat menyenangkan bagi anda sendiri. Tanggung jawab seorang  wanita bukan saja menangani rumah saja, tapi anda juga harus menyediakan kebutuhan gizi tercukupi dan olahan yang dikonsumsi anak-anak wajib menggugah selera.

Di waktu  sekarang, kita sebenarnya mampu membeli olahan jadi walaupun tanpa harus repot memasaknya dulu. Tetapi ada juga lho orang yang memang ingin menghidangkan yang terlezat bagi orang yang dicintainya. Pasalnya, menghidangkan masakan sendiri jauh lebih higienis dan bisa menyesuaikan masakan tersebut sesuai dengan makanan kesukaan orang tercinta. 



Apakah kamu seorang penyuka 12. ayam asam manis?. Asal kamu tahu, 12. ayam asam manis merupakan makanan khas di Indonesia yang saat ini disukai oleh setiap orang di hampir setiap wilayah di Indonesia. Kalian bisa membuat 12. ayam asam manis kreasi sendiri di rumah dan dapat dijadikan santapan kesukaanmu di hari libur.

Kalian tak perlu bingung untuk memakan 12. ayam asam manis, sebab 12. ayam asam manis mudah untuk didapatkan dan juga kita pun bisa memasaknya sendiri di tempatmu. 12. ayam asam manis boleh diolah dengan berbagai cara. Kini pun ada banyak banget resep modern yang membuat 12. ayam asam manis semakin lebih enak.

Resep 12. ayam asam manis juga sangat mudah dihidangkan, lho. Kalian jangan repot-repot untuk memesan 12. ayam asam manis, karena Kalian dapat menyajikan di rumahmu. Untuk Kalian yang mau membuatnya, berikut resep untuk menyajikan 12. ayam asam manis yang enak yang dapat Kita coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan 12. Ayam asam manis:

1. Gunakan 1/2 kg dada ayam potong sesuai selera
1. Ambil 2 sdm kecap asin
1. Gunakan 1 buah jeruk nipis
1. Gunakan 5 sdm tepung maizena
1. Sediakan 2 btr putih telur
1. Siapkan Secukupnya minyak goreng
1. Gunakan 1 buah paprika hijau
1. Sediakan 1 buah nanas
1. Ambil 3 buah cabe merah besar
1. Gunakan 1 buah bawang bombay
1. Sediakan 3 siung bawang putih
1. Siapkan 2 batang prei/daun bawang
1. Siapkan 2 sdm gula pasir
1. Siapkan 3 sdm saos tiram
1. Gunakan 5 sdm saos tomat
1. Sediakan 1 sdm minyak wijen
1. Gunakan 1 sdt lada bubuk
1. Gunakan 1 sdt garam
1. Ambil 1 sdm margarin(utk menumis)




<!--inarticleads2-->

##### Langkah-langkah membuat 12. Ayam asam manis:

1. Potong dada ayam, cuci bersih tambahkan kecap asin dan perasan jeruk nipis, diamkan 10 menit.
1. Tambahkan putih telur dan tepung maizena aduk rata.
1. Goreng ayam sampai berwarna kuning keemasan.
1. Siapkan bahan yg akan ditumis, potong sesuai gambar dan disiapkan juga saos pelengkap utk penunjang rasa.
1. Tumis bawang putih dng sedikit margarin.
1. Berikutnya masukkan paprika dan bawang bombay
1. Disusul cabe merah besar, ayam goreng, nanas dan semua saos, garam, gula, dan lada bubuk.
1. Terakhir baru masukkan bawang prei.
1. Angkat dan hidangkan dng nasi panas.




Wah ternyata resep 12. ayam asam manis yang nikamt simple ini gampang banget ya! Kamu semua bisa membuatnya. Cara Membuat 12. ayam asam manis Sangat sesuai banget buat kamu yang baru mau belajar memasak maupun juga bagi kamu yang sudah lihai memasak.

Apakah kamu mau mulai mencoba membikin resep 12. ayam asam manis lezat tidak ribet ini? Kalau kalian ingin, mending kamu segera buruan siapkan alat-alat dan bahannya, lantas buat deh Resep 12. ayam asam manis yang lezat dan tidak ribet ini. Sungguh gampang kan. 

Jadi, ketimbang anda berfikir lama-lama, ayo kita langsung saja sajikan resep 12. ayam asam manis ini. Pasti kalian tiidak akan nyesel sudah bikin resep 12. ayam asam manis mantab sederhana ini! Selamat mencoba dengan resep 12. ayam asam manis mantab simple ini di tempat tinggal kalian masing-masing,oke!.

