---
description: "Cara membuat Ayam Lava yang sedap Untuk Jualan"
title: "Cara membuat Ayam Lava yang sedap Untuk Jualan"
slug: 32-cara-membuat-ayam-lava-yang-sedap-untuk-jualan
date: 2021-04-03T08:17:07.982Z
image: https://img-global.cpcdn.com/recipes/66ab10b5563ef547/680x482cq70/ayam-lava-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/66ab10b5563ef547/680x482cq70/ayam-lava-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/66ab10b5563ef547/680x482cq70/ayam-lava-foto-resep-utama.jpg
author: Milton Roy
ratingvalue: 4.4
reviewcount: 3
recipeingredient:
- "2-3 potong ayam bagian apapun saya pake bagian sayap"
- "1/2 siung bawang bombay"
- "2 siung bawang putih"
- "15-20 buah cabai boleh di kurangi"
- "1 buah tomat"
- "1/2 batang daun bawang"
- "2 sdm mentega"
- "secukupnya garam  penyedap"
- "1/2 sdm saus tiram"
- "2 sdm kecap manis"
- " saos hot lava saya pakai yg merk mama suka"
recipeinstructions:
- "Iris bawang bombay, bawang putih tipis-tipis, untuk tomat dan cabai di iris kasar"
- "Goreng ayam yg sudah di ungkep setengah matang dengan api kecil"
- "Siapkan wajan, lalu masukan mentega dan tuang semua bumbu yg telah diiris. tumis hingga wangi ya moms ☺"
- "Setelah bumbu sudah mulai menguning dan wangi, masukan ayam yg telah di goreng setengah matang lalu aduk perlahan."
- "Setelah tercampur, masukan saus tiram, kecap manis, garam/penyedap secukupnya."
- "Tuang saos lava secukupnya, hingga bewarna merah ya moms. lalu langsung matikan api kompor. di aduk dalam keadaan hangat biar saos lava nya ga kering yaa moms 🤗"
- "Siap di sajikan ke piring dan di taburi irisan daun bawang, selamaat makan 💕"
categories:
- Resep
tags:
- ayam
- lava

katakunci: ayam lava 
nutrition: 158 calories
recipecuisine: Indonesian
preptime: "PT32M"
cooktime: "PT51M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Lava](https://img-global.cpcdn.com/recipes/66ab10b5563ef547/680x482cq70/ayam-lava-foto-resep-utama.jpg)

Selaku seorang orang tua, menyuguhkan santapan mantab bagi keluarga tercinta adalah hal yang memuaskan bagi anda sendiri. Tanggung jawab seorang ibu Tidak cuman mengatur rumah saja, tapi kamu pun wajib memastikan keperluan gizi tercukupi dan santapan yang disantap keluarga tercinta wajib sedap.

Di era  saat ini, kita sebenarnya mampu mengorder hidangan jadi tanpa harus susah memasaknya dulu. Tetapi banyak juga mereka yang memang mau memberikan hidangan yang terlezat bagi orang yang dicintainya. Sebab, menghidangkan masakan yang diolah sendiri jauh lebih higienis dan kita pun bisa menyesuaikan makanan tersebut berdasarkan kesukaan famili. 



Apakah anda merupakan salah satu penggemar ayam lava?. Tahukah kamu, ayam lava adalah hidangan khas di Nusantara yang saat ini digemari oleh setiap orang di berbagai tempat di Nusantara. Anda bisa memasak ayam lava kreasi sendiri di rumahmu dan boleh dijadikan makanan kesenanganmu di akhir pekanmu.

Anda tidak usah bingung jika kamu ingin memakan ayam lava, lantaran ayam lava mudah untuk ditemukan dan kita pun boleh menghidangkannya sendiri di rumah. ayam lava boleh dimasak lewat beragam cara. Saat ini ada banyak banget cara modern yang menjadikan ayam lava semakin lebih mantap.

Resep ayam lava juga gampang untuk dibikin, lho. Kita jangan capek-capek untuk memesan ayam lava, tetapi Kalian bisa membuatnya ditempatmu. Bagi Kita yang ingin menghidangkannya, dibawah ini merupakan resep membuat ayam lava yang lezat yang dapat Kamu hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Ayam Lava:

1. Ambil 2-3 potong ayam bagian apapun (saya pake bagian sayap)
1. Ambil 1/2 siung bawang bombay
1. Sediakan 2 siung bawang putih
1. Sediakan 15-20 buah cabai (boleh di kurangi)
1. Sediakan 1 buah tomat
1. Gunakan 1/2 batang daun bawang
1. Sediakan 2 sdm mentega
1. Siapkan secukupnya garam / penyedap
1. Ambil 1/2 sdm saus tiram
1. Siapkan 2 sdm kecap manis
1. Siapkan  saos hot lava (saya pakai yg merk mama suka)




<!--inarticleads2-->

##### Cara membuat Ayam Lava:

1. Iris bawang bombay, bawang putih tipis-tipis, untuk tomat dan cabai di iris kasar
1. Goreng ayam yg sudah di ungkep setengah matang dengan api kecil
1. Siapkan wajan, lalu masukan mentega dan tuang semua bumbu yg telah diiris. tumis hingga wangi ya moms ☺
1. Setelah bumbu sudah mulai menguning dan wangi, masukan ayam yg telah di goreng setengah matang lalu aduk perlahan.
1. Setelah tercampur, masukan saus tiram, kecap manis, garam/penyedap secukupnya.
1. Tuang saos lava secukupnya, hingga bewarna merah ya moms. lalu langsung matikan api kompor. di aduk dalam keadaan hangat biar saos lava nya ga kering yaa moms 🤗
1. Siap di sajikan ke piring dan di taburi irisan daun bawang, selamaat makan 💕




Wah ternyata cara membuat ayam lava yang enak sederhana ini enteng sekali ya! Kamu semua dapat menghidangkannya. Cara buat ayam lava Sangat cocok banget buat kita yang baru belajar memasak maupun bagi kalian yang sudah pandai memasak.

Tertarik untuk mencoba membuat resep ayam lava lezat tidak ribet ini? Kalau kamu ingin, yuk kita segera buruan siapkan peralatan dan bahannya, lalu bikin deh Resep ayam lava yang nikmat dan tidak rumit ini. Benar-benar taidak sulit kan. 

Maka dari itu, daripada anda berfikir lama-lama, ayo kita langsung saja hidangkan resep ayam lava ini. Pasti anda gak akan nyesel sudah membuat resep ayam lava enak simple ini! Selamat berkreasi dengan resep ayam lava lezat tidak rumit ini di tempat tinggal kalian sendiri,ya!.

