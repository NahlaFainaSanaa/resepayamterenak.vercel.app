---
description: "Bahan-bahan Hati Ayam Masak Laos yang enak dan Mudah Dibuat"
title: "Bahan-bahan Hati Ayam Masak Laos yang enak dan Mudah Dibuat"
slug: 326-bahan-bahan-hati-ayam-masak-laos-yang-enak-dan-mudah-dibuat
date: 2021-05-10T05:10:26.716Z
image: https://img-global.cpcdn.com/recipes/5cf21d73fa2bf12f/680x482cq70/hati-ayam-masak-laos-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5cf21d73fa2bf12f/680x482cq70/hati-ayam-masak-laos-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5cf21d73fa2bf12f/680x482cq70/hati-ayam-masak-laos-foto-resep-utama.jpg
author: Cora Hammond
ratingvalue: 3.7
reviewcount: 7
recipeingredient:
- "300 gr Hati Ayam"
- "1 buah jeruk nipis"
- "2 lembar daun salam"
- "2 batang sereh keprek"
- "Secukupnya garamgulakaldu bubuk"
- "50 g laos  lengkuas diblender"
- "Secukupnya air dan minyak goreng"
- " Bumbu halus"
- "5 bawang merah"
- "3 bawang putih"
- "3 buah kemiri"
- "1 ruas jahe"
- "1 ruas kunyit"
- "Sejumput jinten"
- "1 sdm ketumbar"
recipeinstructions:
- "Cuci bersih hati ayam, beri air jeruk nipis, ratakan dan diamkan 5 menit, kemudian bilas hingga bersih."
- "Blender laos atau diparut. Ukek atau proses bumbu halusnya."
- "Panaskan minyak dan tumis bumbu halus hingga tercium aroma yang harum, lalu masukkan serai dan daun salam, dan laos parut."
- "Masukkan hati ayam, aduk perlahan jingga hati ayam berubah warna dan kaku. Setelah itu beri air, garam, gula dan kaldu bubuk. Cek rasa.. Masak hingga airnya sat."
- "Kemudian goreng hati ayam hingga kecoklatan dan bumbu laosnya mengering. Jadi deh🥰"
categories:
- Resep
tags:
- hati
- ayam
- masak

katakunci: hati ayam masak 
nutrition: 194 calories
recipecuisine: Indonesian
preptime: "PT15M"
cooktime: "PT52M"
recipeyield: "4"
recipecategory: Dessert

---


![Hati Ayam Masak Laos](https://img-global.cpcdn.com/recipes/5cf21d73fa2bf12f/680x482cq70/hati-ayam-masak-laos-foto-resep-utama.jpg)

Selaku seorang wanita, menyediakan hidangan sedap buat keluarga tercinta merupakan suatu hal yang sangat menyenangkan bagi kamu sendiri. Peran seorang  wanita bukan saja menangani rumah saja, tapi anda juga wajib memastikan keperluan gizi tercukupi dan olahan yang dikonsumsi anak-anak harus mantab.

Di era  saat ini, kamu memang bisa membeli hidangan siap saji meski tidak harus ribet memasaknya dahulu. Tetapi ada juga lho mereka yang memang mau memberikan hidangan yang terlezat bagi keluarganya. Pasalnya, menghidangkan masakan yang dibuat sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan berdasarkan selera famili. 



Mungkinkah anda adalah seorang penggemar hati ayam masak laos?. Asal kamu tahu, hati ayam masak laos adalah hidangan khas di Nusantara yang sekarang disukai oleh orang-orang dari hampir setiap tempat di Nusantara. Kalian bisa menghidangkan hati ayam masak laos hasil sendiri di rumah dan boleh dijadikan camilan favorit di akhir pekan.

Kamu tidak perlu bingung jika kamu ingin mendapatkan hati ayam masak laos, lantaran hati ayam masak laos tidak sukar untuk dicari dan anda pun bisa membuatnya sendiri di rumah. hati ayam masak laos bisa diolah dengan berbagai cara. Kini pun telah banyak sekali cara modern yang menjadikan hati ayam masak laos semakin lebih lezat.

Resep hati ayam masak laos pun sangat mudah untuk dibuat, lho. Kamu jangan capek-capek untuk memesan hati ayam masak laos, lantaran Kita bisa menyajikan ditempatmu. Bagi Kita yang hendak membuatnya, berikut resep membuat hati ayam masak laos yang mantab yang bisa Kamu coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Hati Ayam Masak Laos:

1. Gunakan 300 gr Hati Ayam
1. Gunakan 1 buah jeruk nipis
1. Sediakan 2 lembar daun salam
1. Sediakan 2 batang sereh keprek
1. Gunakan Secukupnya garam,gula,kaldu bubuk
1. Ambil 50 g laos / lengkuas diblender
1. Gunakan Secukupnya air dan minyak goreng
1. Ambil  Bumbu halus:
1. Gunakan 5 bawang merah
1. Gunakan 3 bawang putih
1. Siapkan 3 buah kemiri
1. Gunakan 1 ruas jahe
1. Gunakan 1 ruas kunyit
1. Sediakan Sejumput jinten
1. Sediakan 1 sdm ketumbar




<!--inarticleads2-->

##### Cara membuat Hati Ayam Masak Laos:

1. Cuci bersih hati ayam, beri air jeruk nipis, ratakan dan diamkan 5 menit, kemudian bilas hingga bersih.
1. Blender laos atau diparut. Ukek atau proses bumbu halusnya.
1. Panaskan minyak dan tumis bumbu halus hingga tercium aroma yang harum, lalu masukkan serai dan daun salam, dan laos parut.
1. Masukkan hati ayam, aduk perlahan jingga hati ayam berubah warna dan kaku. Setelah itu beri air, garam, gula dan kaldu bubuk. Cek rasa.. Masak hingga airnya sat.
1. Kemudian goreng hati ayam hingga kecoklatan dan bumbu laosnya mengering. Jadi deh🥰




Ternyata cara buat hati ayam masak laos yang lezat tidak rumit ini mudah banget ya! Kita semua dapat mencobanya. Cara Membuat hati ayam masak laos Sangat sesuai sekali buat kalian yang sedang belajar memasak maupun juga bagi anda yang telah pandai memasak.

Tertarik untuk mulai mencoba bikin resep hati ayam masak laos mantab tidak rumit ini? Kalau anda mau, yuk kita segera siapin alat-alat dan bahannya, maka buat deh Resep hati ayam masak laos yang nikmat dan tidak rumit ini. Sangat taidak sulit kan. 

Oleh karena itu, ketimbang kalian berlama-lama, ayo kita langsung hidangkan resep hati ayam masak laos ini. Pasti kalian tak akan menyesal sudah bikin resep hati ayam masak laos lezat sederhana ini! Selamat berkreasi dengan resep hati ayam masak laos enak simple ini di rumah kalian masing-masing,oke!.

