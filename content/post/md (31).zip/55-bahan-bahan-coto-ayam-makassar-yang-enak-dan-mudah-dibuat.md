---
description: "Bahan-bahan Coto ayam makassar yang enak dan Mudah Dibuat"
title: "Bahan-bahan Coto ayam makassar yang enak dan Mudah Dibuat"
slug: 55-bahan-bahan-coto-ayam-makassar-yang-enak-dan-mudah-dibuat
date: 2021-03-15T15:32:00.227Z
image: https://img-global.cpcdn.com/recipes/8893af18e7df99c6/680x482cq70/coto-ayam-makassar-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8893af18e7df99c6/680x482cq70/coto-ayam-makassar-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8893af18e7df99c6/680x482cq70/coto-ayam-makassar-foto-resep-utama.jpg
author: Trevor Berry
ratingvalue: 4.5
reviewcount: 3
recipeingredient:
- "1 ekor ayam recom ayam kampung"
- "1/2 liter kacang tanah goreng kLw mw Lbh kental blh tambah"
- "10 siung bawang putih"
- "14 siung bawang merah"
- "8 batang sereh lbh banyak lbih harum dan enak"
- "2 ruas Lengkuas 1 d geprek 1 nya diiris spya mudah d haluskan"
- "4 biji kemiri"
- "2 sdm ketumbar"
- "1 sdm jintan putih"
- " sdikit jahe"
- " sdikit kencur"
- "1 butir pala"
- " kayu manis"
- " daun salam"
- " garam"
- " gula"
- " penyedap rasa"
- " minyak untuk menumis"
- " air untuk merebus"
- "1 bungkus bihun jagung"
- " bawang goreng"
- " daun seledri"
- " daun sup"
recipeinstructions:
- "Ayam di belah mnjadi 4 kemudian di rebus d dalam 3 Liter air. jngan Lupa kasih daun salam saat merebus, 2 lembar."
- "Setelah matang, angkat lalu tiriskan. air sisa rebusan jngn dibuang, krna itu akan jd kuahnya. masukkan 1 butir pala, lengkuas yg digeprek dan kayu manis ke dalam air rebusan. sisihkan"
- "Setelah ayamx dingin, potong sesuai selera, ambiL dagingnya saja. tuLangnya kembaLikan ke kuah bekas rebusan yg tadi."
- "Ayam yg sudah dipotong, kaLau sy potong dadu (boleh d suir kasar), digoreng tp jngn smPai kering. sisihkan."
- "Haluskan kacang tanah goreng, sisihkan."
- "Sangrai ketumbar, jintan, dan kemiri."
- "Haluskan bawang merah, bawang putih, lengkuas, sereh, ketumbar, jintan, kemiri, jahe, dan kencur."
- "Tumis bumbu halus, masukkan daun salam. setelah harum, tambahkan garam, gula, penyedap rasa."
- "Sementara itu, panaskan kembali air sisa rebusan ayam tadi."
- "Setelah bumbunya matang, masukkan kacang yg sudah dihaluskan td. Aduk hingga rata."
- "Setelah bumbu dan kacang menyatu, matikan api. kaLau airnya sdh mndidih, masukkan bumbu yg sdh di tumis tadi ke dalam kuah rebusan. aduk hingga rata."
- "Setelah mendidih, matikan api. saatnya pLating 😂"
- "Letakkan ayam goreng dan bihun d atas piring. Tuangkan kuah coto. hiasi dngan bawang goreng, daun seledri, dan daun bawang. mmmmmmm selamat makan 😉"
categories:
- Resep
tags:
- coto
- ayam
- makassar

katakunci: coto ayam makassar 
nutrition: 240 calories
recipecuisine: Indonesian
preptime: "PT40M"
cooktime: "PT36M"
recipeyield: "1"
recipecategory: Lunch

---


![Coto ayam makassar](https://img-global.cpcdn.com/recipes/8893af18e7df99c6/680x482cq70/coto-ayam-makassar-foto-resep-utama.jpg)

Selaku seorang ibu, mempersiapkan masakan mantab pada famili merupakan suatu hal yang mengasyikan bagi kita sendiri. Peran seorang istri Tidak cuman mengatur rumah saja, tapi kamu pun wajib memastikan kebutuhan nutrisi tercukupi dan hidangan yang dimakan anak-anak harus mantab.

Di waktu  saat ini, kalian memang mampu memesan panganan praktis meski tidak harus ribet memasaknya dahulu. Namun ada juga orang yang memang ingin memberikan hidangan yang terlezat bagi keluarganya. Sebab, memasak sendiri akan jauh lebih higienis dan bisa menyesuaikan berdasarkan makanan kesukaan orang tercinta. 



Apakah kamu salah satu penggemar coto ayam makassar?. Asal kamu tahu, coto ayam makassar merupakan makanan khas di Nusantara yang sekarang disenangi oleh orang-orang dari berbagai daerah di Nusantara. Kalian bisa menyajikan coto ayam makassar kreasi sendiri di rumahmu dan pasti jadi hidangan favoritmu di akhir pekanmu.

Kita tak perlu bingung untuk memakan coto ayam makassar, lantaran coto ayam makassar mudah untuk didapatkan dan kalian pun bisa menghidangkannya sendiri di rumah. coto ayam makassar dapat dibuat lewat beragam cara. Kini pun ada banyak sekali cara kekinian yang menjadikan coto ayam makassar semakin mantap.

Resep coto ayam makassar juga sangat gampang dihidangkan, lho. Kita tidak perlu ribet-ribet untuk memesan coto ayam makassar, tetapi Kalian dapat membuatnya di rumahmu. Bagi Kalian yang akan membuatnya, berikut ini cara membuat coto ayam makassar yang mantab yang dapat Anda buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Coto ayam makassar:

1. Siapkan 1 ekor ayam (recom ayam kampung)
1. Ambil 1/2 liter kacang tanah goreng (kLw mw Lbh kental, blh tambah)
1. Sediakan 10 siung bawang putih
1. Gunakan 14 siung bawang merah
1. Gunakan 8 batang sereh (lbh banyak lbih harum dan enak)
1. Ambil 2 ruas Lengkuas (1 d geprek, 1 nya diiris spya mudah d haluskan)
1. Siapkan 4 biji kemiri
1. Sediakan 2 sdm ketumbar
1. Ambil 1 sdm jintan putih
1. Gunakan  sdikit jahe
1. Siapkan  sdikit kencur
1. Siapkan 1 butir pala
1. Siapkan  kayu manis
1. Ambil  daun salam
1. Ambil  garam
1. Ambil  gula
1. Sediakan  penyedap rasa
1. Gunakan  minyak untuk menumis
1. Ambil  air untuk merebus
1. Ambil 1 bungkus bihun jagung
1. Gunakan  bawang goreng
1. Sediakan  daun seledri
1. Ambil  daun sup




<!--inarticleads2-->

##### Langkah-langkah membuat Coto ayam makassar:

1. Ayam di belah mnjadi 4 kemudian di rebus d dalam 3 Liter air. jngan Lupa kasih daun salam saat merebus, 2 lembar.
1. Setelah matang, angkat lalu tiriskan. air sisa rebusan jngn dibuang, krna itu akan jd kuahnya. masukkan 1 butir pala, lengkuas yg digeprek dan kayu manis ke dalam air rebusan. sisihkan
1. Setelah ayamx dingin, potong sesuai selera, ambiL dagingnya saja. tuLangnya kembaLikan ke kuah bekas rebusan yg tadi.
1. Ayam yg sudah dipotong, kaLau sy potong dadu (boleh d suir kasar), digoreng tp jngn smPai kering. sisihkan.
1. Haluskan kacang tanah goreng, sisihkan.
1. Sangrai ketumbar, jintan, dan kemiri.
1. Haluskan bawang merah, bawang putih, lengkuas, sereh, ketumbar, jintan, kemiri, jahe, dan kencur.
1. Tumis bumbu halus, masukkan daun salam. setelah harum, tambahkan garam, gula, penyedap rasa.
1. Sementara itu, panaskan kembali air sisa rebusan ayam tadi.
1. Setelah bumbunya matang, masukkan kacang yg sudah dihaluskan td. Aduk hingga rata.
1. Setelah bumbu dan kacang menyatu, matikan api. kaLau airnya sdh mndidih, masukkan bumbu yg sdh di tumis tadi ke dalam kuah rebusan. aduk hingga rata.
1. Setelah mendidih, matikan api. saatnya pLating 😂
1. Letakkan ayam goreng dan bihun d atas piring. Tuangkan kuah coto. hiasi dngan bawang goreng, daun seledri, dan daun bawang. mmmmmmm selamat makan 😉




Wah ternyata cara membuat coto ayam makassar yang lezat tidak ribet ini enteng sekali ya! Anda Semua dapat menghidangkannya. Resep coto ayam makassar Sesuai banget untuk kamu yang baru mau belajar memasak atau juga bagi kamu yang telah ahli memasak.

Tertarik untuk mencoba membuat resep coto ayam makassar lezat simple ini? Kalau anda tertarik, ayo kamu segera buruan menyiapkan alat-alat dan bahannya, lantas bikin deh Resep coto ayam makassar yang enak dan simple ini. Benar-benar gampang kan. 

Maka, daripada anda diam saja, ayo kita langsung saja buat resep coto ayam makassar ini. Pasti anda tak akan menyesal sudah buat resep coto ayam makassar enak sederhana ini! Selamat berkreasi dengan resep coto ayam makassar mantab tidak ribet ini di tempat tinggal kalian masing-masing,ya!.

