---
description: "Cara memasak Coto Ayam Makassar yang lezat Untuk Jualan"
title: "Cara memasak Coto Ayam Makassar yang lezat Untuk Jualan"
slug: 65-cara-memasak-coto-ayam-makassar-yang-lezat-untuk-jualan
date: 2021-01-22T23:55:05.381Z
image: https://img-global.cpcdn.com/recipes/53a4ff5c80d5228e/680x482cq70/coto-ayam-makassar-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/53a4ff5c80d5228e/680x482cq70/coto-ayam-makassar-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/53a4ff5c80d5228e/680x482cq70/coto-ayam-makassar-foto-resep-utama.jpg
author: Georgia Vaughn
ratingvalue: 4.9
reviewcount: 13
recipeingredient:
- "1 ekor ayam 1kg"
- "2 liter air cucian beras yg pertama"
- "1 kaleng susu beruang"
- "2 batang serai"
- "100 gr kacang tanah goreng"
- "secukupnya Garam"
- "secukupnya Kaldu bubuk"
- " Bahan rempah"
- "15 buah cengkeh"
- "1 sdm ketumbar biji"
- "1 sdm merica biji"
- "1/2 sdm jintan"
- "2 ruas jari kayu manis"
- "1 buah pala"
- " Bahan bumbu"
- "100 gr lengkuas"
- "50 gr jahe"
- "50 gr bawang merah"
- "50 gr bawang putih"
recipeinstructions:
- "Siapkan bahan-bahannya. Maafkan karena ga semua terfoto 😁"
- "Goreng bahan rempah hingga harum dan agak kering lalu uleg hingga halus. Setelah itu uleg bahan bumbu bersama bahan rempah. Jika bahan rempah dan bumbunya ingin diuleg, saya sarankan lengkuas dan jahe nya diparut terlebih dahulu biar memudahkan diuleg. Kecuali ingin bahannya diblender hingga halus."
- "Sambil menyiapkan bumbu, didihkan air cucian beras pertama yang telah disaring lalu masukkan daging ayam. Biasanya kalau menggunakan daging sapi, dagingnya direbus dalam ukuran besar. Setelah matang lalu daging diangkat dan ditiriskan. Setelah itulah baru kuah diberi bumbu. Tapi berhubung saya tidak ingin repot jadi daging ayamnya sudah sy potong-potong terlebih dahulu dan langsung sy masak sekaligus dengan bumbu 😁. Oya jangan lupa serai yang digeprek ditambahkan saat merebus dagingnya."
- "Sambil menunggu kuah mendidih, tumis bahan bumbu rempah hingga wangi."
- "Sambil menumis, uleg kacang tanah hingga halus. Lalu tambahkan ke tumisan bumbu rempah. Aduk hingga rata. Nah bumbu rempah yang telah ditambah kacang goreng inilah bumbu coto nya. Dan bumbu ini bisa disimpan di kulkas. Jadi gunakan secukupnya sesuai kebutuhan. Tapi yg jelas takaran bumbu ini untuk 1 ekor ayam 1kg ya hehe."
- "Tambahkan bumbu coto ke dalam kuah rebusan daging. Tambahkan garam dan kaldu ayam secukupnya. Terakhir masukkan susu beruang."
- "Jangan lupa memberi potongan daun bawang dan bawang goreng saat akan menyajikannya. Coto Makassar ini paling cocok disantap bersama ketupat 😍"
categories:
- Resep
tags:
- coto
- ayam
- makassar

katakunci: coto ayam makassar 
nutrition: 108 calories
recipecuisine: Indonesian
preptime: "PT32M"
cooktime: "PT45M"
recipeyield: "4"
recipecategory: Dinner

---


![Coto Ayam Makassar](https://img-global.cpcdn.com/recipes/53a4ff5c80d5228e/680x482cq70/coto-ayam-makassar-foto-resep-utama.jpg)

Selaku seorang istri, menyajikan santapan sedap untuk orang tercinta merupakan suatu hal yang sangat menyenangkan untuk kamu sendiri. Tanggung jawab seorang ibu bukan cuman mengurus rumah saja, namun kamu pun harus memastikan kebutuhan nutrisi terpenuhi dan hidangan yang dikonsumsi keluarga tercinta harus mantab.

Di masa  sekarang, kita sebenarnya bisa membeli olahan jadi walaupun tidak harus repot membuatnya lebih dulu. Tapi banyak juga lho mereka yang memang ingin menyajikan yang terenak bagi keluarganya. Lantaran, menghidangkan masakan yang diolah sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan sesuai dengan makanan kesukaan keluarga. 



Mungkinkah anda seorang penyuka coto ayam makassar?. Asal kamu tahu, coto ayam makassar merupakan sajian khas di Nusantara yang saat ini digemari oleh orang-orang di hampir setiap tempat di Nusantara. Kita dapat membuat coto ayam makassar sendiri di rumah dan boleh dijadikan makanan kesenanganmu di akhir pekan.

Anda tak perlu bingung jika kamu ingin menyantap coto ayam makassar, lantaran coto ayam makassar mudah untuk dicari dan juga kamu pun bisa mengolahnya sendiri di rumah. coto ayam makassar dapat dibuat dengan bermacam cara. Kini telah banyak banget resep modern yang membuat coto ayam makassar semakin lebih mantap.

Resep coto ayam makassar juga gampang sekali untuk dibikin, lho. Kita jangan ribet-ribet untuk memesan coto ayam makassar, sebab Anda dapat membuatnya di rumah sendiri. Untuk Kamu yang ingin menyajikannya, inilah cara membuat coto ayam makassar yang mantab yang bisa Kita coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Coto Ayam Makassar:

1. Ambil 1 ekor ayam 1kg
1. Ambil 2 liter air cucian beras yg pertama
1. Siapkan 1 kaleng susu beruang
1. Siapkan 2 batang serai
1. Ambil 100 gr kacang tanah goreng
1. Sediakan secukupnya Garam
1. Siapkan secukupnya Kaldu bubuk
1. Gunakan  Bahan rempah:
1. Ambil 15 buah cengkeh
1. Siapkan 1 sdm ketumbar biji
1. Siapkan 1 sdm merica biji
1. Ambil 1/2 sdm jintan
1. Gunakan 2 ruas jari kayu manis
1. Siapkan 1 buah pala
1. Gunakan  Bahan bumbu:
1. Gunakan 100 gr lengkuas
1. Ambil 50 gr jahe
1. Sediakan 50 gr bawang merah
1. Ambil 50 gr bawang putih




<!--inarticleads2-->

##### Cara menyiapkan Coto Ayam Makassar:

1. Siapkan bahan-bahannya. Maafkan karena ga semua terfoto 😁
1. Goreng bahan rempah hingga harum dan agak kering lalu uleg hingga halus. Setelah itu uleg bahan bumbu bersama bahan rempah. Jika bahan rempah dan bumbunya ingin diuleg, saya sarankan lengkuas dan jahe nya diparut terlebih dahulu biar memudahkan diuleg. Kecuali ingin bahannya diblender hingga halus.
1. Sambil menyiapkan bumbu, didihkan air cucian beras pertama yang telah disaring lalu masukkan daging ayam. Biasanya kalau menggunakan daging sapi, dagingnya direbus dalam ukuran besar. Setelah matang lalu daging diangkat dan ditiriskan. Setelah itulah baru kuah diberi bumbu. Tapi berhubung saya tidak ingin repot jadi daging ayamnya sudah sy potong-potong terlebih dahulu dan langsung sy masak sekaligus dengan bumbu 😁. Oya jangan lupa serai yang digeprek ditambahkan saat merebus dagingnya.
1. Sambil menunggu kuah mendidih, tumis bahan bumbu rempah hingga wangi.
1. Sambil menumis, uleg kacang tanah hingga halus. Lalu tambahkan ke tumisan bumbu rempah. Aduk hingga rata. Nah bumbu rempah yang telah ditambah kacang goreng inilah bumbu coto nya. Dan bumbu ini bisa disimpan di kulkas. Jadi gunakan secukupnya sesuai kebutuhan. Tapi yg jelas takaran bumbu ini untuk 1 ekor ayam 1kg ya hehe.
1. Tambahkan bumbu coto ke dalam kuah rebusan daging. Tambahkan garam dan kaldu ayam secukupnya. Terakhir masukkan susu beruang.
1. Jangan lupa memberi potongan daun bawang dan bawang goreng saat akan menyajikannya. Coto Makassar ini paling cocok disantap bersama ketupat 😍




Wah ternyata resep coto ayam makassar yang enak tidak rumit ini enteng banget ya! Semua orang bisa menghidangkannya. Cara Membuat coto ayam makassar Sangat cocok banget untuk kamu yang baru belajar memasak maupun juga untuk kalian yang sudah ahli dalam memasak.

Apakah kamu mau mulai mencoba membuat resep coto ayam makassar mantab tidak rumit ini? Kalau ingin, mending kamu segera menyiapkan alat dan bahan-bahannya, lantas bikin deh Resep coto ayam makassar yang lezat dan tidak ribet ini. Sangat taidak sulit kan. 

Maka, ketimbang kita diam saja, hayo kita langsung saja sajikan resep coto ayam makassar ini. Pasti anda tak akan nyesel sudah bikin resep coto ayam makassar enak tidak ribet ini! Selamat berkreasi dengan resep coto ayam makassar lezat sederhana ini di rumah kalian masing-masing,oke!.

