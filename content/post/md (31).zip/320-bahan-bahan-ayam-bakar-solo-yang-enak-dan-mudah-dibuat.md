---
description: "Bahan-bahan Ayam Bakar Solo yang enak dan Mudah Dibuat"
title: "Bahan-bahan Ayam Bakar Solo yang enak dan Mudah Dibuat"
slug: 320-bahan-bahan-ayam-bakar-solo-yang-enak-dan-mudah-dibuat
date: 2021-03-30T16:59:30.279Z
image: https://img-global.cpcdn.com/recipes/711cdcd3f0deb5cf/680x482cq70/ayam-bakar-solo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/711cdcd3f0deb5cf/680x482cq70/ayam-bakar-solo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/711cdcd3f0deb5cf/680x482cq70/ayam-bakar-solo-foto-resep-utama.jpg
author: Ryan Porter
ratingvalue: 4.2
reviewcount: 13
recipeingredient:
- "1 ekor ayam kampung muda"
- "2 sdm kecap manis"
- "1 sdm gula merah sisir"
- " Air kelapa dari 1butir kelapa untuk mengungkap ayam"
- "Secukupnya air untuk ungkap ayam hingga empuk"
- " Bumbu halus "
- "8 siung bawang merah"
- "6 siung bawang putih"
- "2 butir kemiri sangrai"
- "1 ruas kunyit"
- "Secukupnya garam dan kaldu bubuk"
recipeinstructions:
- "Siapkan bahan-bahan. Cuci bersih ayam dan haluskan bumbu. Lumuri ayam dengan bumbu halus, sambil di remas dan diamkan sekitar 20 menit. Setelah 20 menit, pindahkan ayam ke panci. Masak ayam hingga berubah warna menjadi putih."
- "Tambahkan gula merah dan kecap. Aduk rata. Masukan air kelapa. Masak hingga empuk. Tambahkan air sampai ayam empuk. Selalu koreksi rasa ya !"
- "Masak ayam hingga kering dan bumbu meresap."
- "Siapkan teflon anti lengket. Bakar ayam hingga gosong, gunakan sisa bumbu sebagai olesan atau tambahkan kecap sebagai olesan jika ingin. Lakukan hingga ayam habis."
- "Sajikan..           (lihat resep)"
categories:
- Resep
tags:
- ayam
- bakar
- solo

katakunci: ayam bakar solo 
nutrition: 127 calories
recipecuisine: Indonesian
preptime: "PT30M"
cooktime: "PT30M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam Bakar Solo](https://img-global.cpcdn.com/recipes/711cdcd3f0deb5cf/680x482cq70/ayam-bakar-solo-foto-resep-utama.jpg)

Selaku seorang istri, menyediakan olahan sedap bagi orang tercinta merupakan suatu hal yang menggembirakan bagi anda sendiri. Tanggung jawab seorang ibu bukan hanya mengerjakan pekerjaan rumah saja, namun anda juga harus memastikan keperluan nutrisi terpenuhi dan hidangan yang disantap orang tercinta wajib mantab.

Di masa  saat ini, kamu sebenarnya dapat memesan panganan instan tidak harus susah memasaknya terlebih dahulu. Tetapi banyak juga lho orang yang memang ingin menghidangkan yang terenak bagi orang tercintanya. Karena, memasak yang diolah sendiri jauh lebih higienis dan bisa menyesuaikan hidangan tersebut berdasarkan makanan kesukaan orang tercinta. 



Mungkinkah kamu salah satu penyuka ayam bakar solo?. Tahukah kamu, ayam bakar solo adalah makanan khas di Indonesia yang sekarang disukai oleh orang-orang dari hampir setiap tempat di Nusantara. Kamu bisa membuat ayam bakar solo buatan sendiri di rumah dan dapat dijadikan santapan kesenanganmu di hari libur.

Kalian tidak perlu bingung untuk menyantap ayam bakar solo, sebab ayam bakar solo gampang untuk ditemukan dan anda pun bisa menghidangkannya sendiri di tempatmu. ayam bakar solo bisa dimasak memalui bermacam cara. Saat ini sudah banyak sekali cara kekinian yang menjadikan ayam bakar solo semakin lebih lezat.

Resep ayam bakar solo juga gampang untuk dibuat, lho. Kita tidak usah capek-capek untuk membeli ayam bakar solo, tetapi Kita dapat membuatnya di rumah sendiri. Untuk Kalian yang hendak menyajikannya, berikut ini resep untuk menyajikan ayam bakar solo yang nikamat yang mampu Kita hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Ayam Bakar Solo:

1. Gunakan 1 ekor ayam kampung muda
1. Gunakan 2 sdm kecap manis
1. Gunakan 1 sdm gula merah, sisir
1. Gunakan  Air kelapa dari 1butir kelapa untuk mengungkap ayam
1. Sediakan Secukupnya air untuk ungkap ayam hingga empuk
1. Sediakan  Bumbu halus :
1. Gunakan 8 siung bawang merah
1. Gunakan 6 siung bawang putih
1. Sediakan 2 butir kemiri, sangrai
1. Gunakan 1 ruas kunyit
1. Ambil Secukupnya garam dan kaldu bubuk




<!--inarticleads2-->

##### Cara menyiapkan Ayam Bakar Solo:

1. Siapkan bahan-bahan. Cuci bersih ayam dan haluskan bumbu. Lumuri ayam dengan bumbu halus, sambil di remas dan diamkan sekitar 20 menit. Setelah 20 menit, pindahkan ayam ke panci. Masak ayam hingga berubah warna menjadi putih.
1. Tambahkan gula merah dan kecap. Aduk rata. Masukan air kelapa. Masak hingga empuk. Tambahkan air sampai ayam empuk. Selalu koreksi rasa ya !
1. Masak ayam hingga kering dan bumbu meresap.
1. Siapkan teflon anti lengket. Bakar ayam hingga gosong, gunakan sisa bumbu sebagai olesan atau tambahkan kecap sebagai olesan jika ingin. Lakukan hingga ayam habis.
1. Sajikan.. -           (lihat resep)




Ternyata cara buat ayam bakar solo yang nikamt sederhana ini mudah banget ya! Kamu semua mampu membuatnya. Cara Membuat ayam bakar solo Sesuai sekali untuk anda yang baru akan belajar memasak atau juga untuk kalian yang sudah lihai memasak.

Apakah kamu ingin mulai mencoba membikin resep ayam bakar solo nikmat tidak rumit ini? Kalau mau, ayo kalian segera siapkan peralatan dan bahan-bahannya, lalu bikin deh Resep ayam bakar solo yang lezat dan tidak ribet ini. Sungguh taidak sulit kan. 

Jadi, daripada kamu diam saja, ayo langsung aja bikin resep ayam bakar solo ini. Dijamin anda tiidak akan menyesal sudah bikin resep ayam bakar solo mantab tidak ribet ini! Selamat mencoba dengan resep ayam bakar solo lezat tidak rumit ini di rumah kalian sendiri,oke!.

