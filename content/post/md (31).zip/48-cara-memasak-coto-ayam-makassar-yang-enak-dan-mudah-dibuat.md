---
description: "Cara memasak Coto Ayam Makassar yang enak dan Mudah Dibuat"
title: "Cara memasak Coto Ayam Makassar yang enak dan Mudah Dibuat"
slug: 48-cara-memasak-coto-ayam-makassar-yang-enak-dan-mudah-dibuat
date: 2021-05-09T15:44:57.920Z
image: https://img-global.cpcdn.com/recipes/ab97aff97f6a1565/680x482cq70/coto-ayam-makassar-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ab97aff97f6a1565/680x482cq70/coto-ayam-makassar-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ab97aff97f6a1565/680x482cq70/coto-ayam-makassar-foto-resep-utama.jpg
author: Matilda Carr
ratingvalue: 4
reviewcount: 5
recipeingredient:
- "250 gr dada ayam tanpa tulang"
- "100 gr kacang tanah goreng haluskan"
- " Air cucian beras"
- "3 lbr daun jeruk"
- "2 lbr daun salam"
- "1 ruas lengkuas geprek"
- "1 ruas kayu manis"
- "2 batang sereh ambil putihnya geprek"
- "Secukupnya garam kaldu bubukgula"
- " Bumbu Halus "
- "5 butir bawang merah"
- "3 siung bawang putih"
- "1 ruas jahe"
- "1 ruas lengkuas"
- "1 sdt ketumbar sangrai sebentar"
- "1/2 sdt merica"
- "2 butir kemiri sangrai"
- "1/2 sdt pala bubuk"
- " Pelengkap "
- " Bihun Rebus"
- "Irisan Seledri dan daun bawang"
- " Bawang merah goreng"
- " Sambal cabe rawit"
- " Jeruk nipis"
- " Lontong bisa pake nasi jg opsional"
recipeinstructions:
- "Haluskan bumbu halus, lalu tumis bersama sereh, daun salam, daun jeruk, kayu manis dan kacang tanah yg sudah dihaluskan sampai harum dan terlihat mengering kecokelatan. Sisihkan sebentar."
- "Rebus ayam, lalu tiriskan. Goreng sebentar suwir². Sisihkan. Tuang tumisan tadi ke air rebusan ayam. Beri garam, gula, kaldu bubuk. Tes rasa. Masak sampai mendidih. Matikan kompor. Ambil mangkok saji."
- "Penyajian : tata potongan lontong/nasi, lalu bihun, ayam suwir, irisan daun bawang, bawang goreng dan seledri, lalu siram dgn kuah coto. Sajikan bersama sambal cabe rawit dan perasan jeruk nipis."
categories:
- Resep
tags:
- coto
- ayam
- makassar

katakunci: coto ayam makassar 
nutrition: 136 calories
recipecuisine: Indonesian
preptime: "PT12M"
cooktime: "PT38M"
recipeyield: "4"
recipecategory: Dessert

---


![Coto Ayam Makassar](https://img-global.cpcdn.com/recipes/ab97aff97f6a1565/680x482cq70/coto-ayam-makassar-foto-resep-utama.jpg)

Andai kamu seorang istri, menyuguhkan masakan sedap kepada keluarga merupakan suatu hal yang memuaskan untuk kamu sendiri. Kewajiban seorang ibu Tidak sekadar menjaga rumah saja, tetapi kamu juga wajib memastikan kebutuhan nutrisi tercukupi dan panganan yang disantap keluarga tercinta harus mantab.

Di masa  sekarang, kalian sebenarnya dapat memesan olahan jadi walaupun tidak harus capek mengolahnya terlebih dahulu. Tetapi banyak juga mereka yang selalu ingin menyajikan yang terbaik bagi keluarganya. Sebab, menyajikan masakan sendiri jauh lebih bersih dan bisa menyesuaikan makanan tersebut berdasarkan makanan kesukaan famili. 



Apakah anda adalah seorang penyuka coto ayam makassar?. Asal kamu tahu, coto ayam makassar adalah hidangan khas di Nusantara yang saat ini disukai oleh setiap orang di berbagai wilayah di Indonesia. Kamu bisa memasak coto ayam makassar sendiri di rumahmu dan dapat dijadikan camilan kegemaranmu di hari liburmu.

Kamu tidak usah bingung jika kamu ingin mendapatkan coto ayam makassar, karena coto ayam makassar gampang untuk dicari dan kita pun bisa memasaknya sendiri di tempatmu. coto ayam makassar dapat dibuat lewat beragam cara. Kini pun sudah banyak cara modern yang membuat coto ayam makassar lebih mantap.

Resep coto ayam makassar pun sangat gampang untuk dibuat, lho. Kalian tidak perlu repot-repot untuk membeli coto ayam makassar, lantaran Kita dapat menyiapkan di rumahmu. Bagi Kita yang ingin menyajikannya, inilah resep untuk membuat coto ayam makassar yang lezat yang mampu Anda buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Coto Ayam Makassar:

1. Gunakan 250 gr dada ayam tanpa tulang
1. Ambil 100 gr kacang tanah, goreng, haluskan
1. Siapkan  Air cucian beras
1. Ambil 3 lbr daun jeruk
1. Ambil 2 lbr daun salam
1. Ambil 1 ruas lengkuas, geprek
1. Gunakan 1 ruas kayu manis
1. Ambil 2 batang sereh, ambil putihnya, geprek
1. Gunakan Secukupnya garam, kaldu bubuk,gula
1. Gunakan  Bumbu Halus :
1. Siapkan 5 butir bawang merah
1. Ambil 3 siung bawang putih
1. Siapkan 1 ruas jahe
1. Siapkan 1 ruas lengkuas
1. Siapkan 1 sdt ketumbar, sangrai sebentar
1. Gunakan 1/2 sdt merica
1. Sediakan 2 butir kemiri sangrai
1. Ambil 1/2 sdt pala bubuk
1. Siapkan  Pelengkap :
1. Sediakan  Bihun Rebus
1. Sediakan Irisan Seledri dan daun bawang
1. Sediakan  Bawang merah goreng
1. Sediakan  Sambal cabe rawit
1. Gunakan  Jeruk nipis
1. Gunakan  Lontong (bisa pake nasi jg, opsional)




<!--inarticleads2-->

##### Cara menyiapkan Coto Ayam Makassar:

1. Haluskan bumbu halus, lalu tumis bersama sereh, daun salam, daun jeruk, kayu manis dan kacang tanah yg sudah dihaluskan sampai harum dan terlihat mengering kecokelatan. Sisihkan sebentar.
1. Rebus ayam, lalu tiriskan. Goreng sebentar suwir². Sisihkan. Tuang tumisan tadi ke air rebusan ayam. Beri garam, gula, kaldu bubuk. Tes rasa. Masak sampai mendidih. Matikan kompor. Ambil mangkok saji.
1. Penyajian : tata potongan lontong/nasi, lalu bihun, ayam suwir, irisan daun bawang, bawang goreng dan seledri, lalu siram dgn kuah coto. Sajikan bersama sambal cabe rawit dan perasan jeruk nipis.




Wah ternyata cara buat coto ayam makassar yang enak tidak rumit ini mudah banget ya! Kita semua bisa membuatnya. Resep coto ayam makassar Sangat cocok banget untuk kamu yang baru belajar memasak ataupun untuk anda yang telah lihai memasak.

Apakah kamu ingin mencoba bikin resep coto ayam makassar enak tidak ribet ini? Kalau mau, ayo kalian segera buruan menyiapkan peralatan dan bahannya, kemudian buat deh Resep coto ayam makassar yang enak dan tidak ribet ini. Benar-benar mudah kan. 

Maka, ketimbang kita berfikir lama-lama, hayo kita langsung bikin resep coto ayam makassar ini. Pasti kalian tak akan menyesal sudah buat resep coto ayam makassar enak simple ini! Selamat mencoba dengan resep coto ayam makassar nikmat tidak rumit ini di rumah masing-masing,ya!.

