---
description: "Resep memasak Coto Ayam Makassar yang enak Untuk Jualan"
title: "Resep memasak Coto Ayam Makassar yang enak Untuk Jualan"
slug: 59-resep-memasak-coto-ayam-makassar-yang-enak-untuk-jualan
date: 2021-06-26T03:50:39.443Z
image: https://img-global.cpcdn.com/recipes/15bedd810deba4a6/680x482cq70/coto-ayam-makassar-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/15bedd810deba4a6/680x482cq70/coto-ayam-makassar-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/15bedd810deba4a6/680x482cq70/coto-ayam-makassar-foto-resep-utama.jpg
author: Lulu Gilbert
ratingvalue: 3.7
reviewcount: 13
recipeingredient:
- "1/2 ekor ayam"
- "2 batang daun bawang"
- "2-3 buah jeruk nipis"
- "3 lembar daun salam"
- "3 lembar daun jeruk"
- "1 liter air"
- "Secukupnya minyak goreng"
- "Secukupnya gula pasir dan garam"
- "1/2 bulat gula merah"
- " 1 Bumbu halus"
- "10 butir bawang merah"
- "5 siung bawang putih"
- "2 butir kemiri sangrai"
- "1 sdt ketumbar sangrai"
- "2 ruas kunyit bakar"
- " 2 Bumbu halus"
- "5 sdm kacang tanah goreng sy 2 sdm"
- " Bahan tambahan lain"
- " Sambal cabai"
- " Kecap manis"
- " Tomat"
- " Sayur kol iris halus"
- " Kentang goreng"
- " Jeruk nipis"
recipeinstructions:
- "Siapkan bahan, cuci bersih ayam dan semua bahan, baluri ayam dengan jeruk nipis selama 10 menit, bilas sisihkan."
- "Rebus air, tunggu mendidih, masukkan ayam, masak sampai kaldu ayam keluar."
- "Haluskan bumbu, tambahkan sedikit sereh, haluskan, kemudian haluskan juga kacang goreng. Sisihkan."
- "Panaskan secukupnya minyak, tumis bumbu halus, masukkan sereh, lengkuas, daun jeruk, daun salam, masak sampai harum, masukkan kacang, masak sampai mengental. Matikan kompor."
- "Masukkan bumbu yg sudah ditumis ke dalam rebusan air, masak kurang lebih 15 menit agar ayam terasa sedikit berbumbu, lalu tiriskan ayam."
- "Tambahkan irisan daun bawang, gula dan garam, masak smpai air agak menyusut, sambil sesekali diaduk, tes rasa."
- "Goreng ayam sampai kuning kecokelatan. Angakt tiriskan."
- "Penyajian. Suir suir ayam, tambahkan sayur kol, siram kuah coto, tambahkan tomat, irisan daun bawang dan kentang goreng. Siap dinikmati selagi hangat."
categories:
- Resep
tags:
- coto
- ayam
- makassar

katakunci: coto ayam makassar 
nutrition: 165 calories
recipecuisine: Indonesian
preptime: "PT16M"
cooktime: "PT38M"
recipeyield: "3"
recipecategory: Lunch

---


![Coto Ayam Makassar](https://img-global.cpcdn.com/recipes/15bedd810deba4a6/680x482cq70/coto-ayam-makassar-foto-resep-utama.jpg)

Andai kita seorang istri, mempersiapkan masakan sedap kepada keluarga tercinta adalah hal yang menyenangkan bagi kamu sendiri. Tugas seorang istri Tidak cuma mengerjakan pekerjaan rumah saja, namun anda juga wajib menyediakan kebutuhan gizi tercukupi dan juga olahan yang disantap orang tercinta harus enak.

Di masa  sekarang, kita sebenarnya dapat membeli panganan praktis walaupun tanpa harus susah mengolahnya lebih dulu. Tetapi ada juga orang yang selalu mau memberikan hidangan yang terlezat bagi orang tercintanya. Sebab, memasak yang diolah sendiri jauh lebih bersih dan bisa menyesuaikan makanan tersebut sesuai masakan kesukaan famili. 



Mungkinkah anda merupakan seorang penyuka coto ayam makassar?. Tahukah kamu, coto ayam makassar merupakan makanan khas di Nusantara yang sekarang digemari oleh setiap orang dari berbagai wilayah di Nusantara. Kamu bisa menyajikan coto ayam makassar sendiri di rumahmu dan pasti jadi santapan favorit di akhir pekan.

Kamu jangan bingung jika kamu ingin menyantap coto ayam makassar, karena coto ayam makassar tidak sukar untuk dicari dan juga kita pun dapat membuatnya sendiri di rumah. coto ayam makassar bisa dibuat lewat berbagai cara. Sekarang ada banyak sekali resep modern yang membuat coto ayam makassar semakin mantap.

Resep coto ayam makassar pun mudah dibikin, lho. Kita jangan capek-capek untuk membeli coto ayam makassar, sebab Kita dapat menyiapkan ditempatmu. Untuk Kamu yang mau mencobanya, berikut resep menyajikan coto ayam makassar yang lezat yang bisa Anda coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Coto Ayam Makassar:

1. Sediakan 1/2 ekor ayam
1. Sediakan 2 batang daun bawang
1. Siapkan 2-3 buah jeruk nipis
1. Sediakan 3 lembar daun salam
1. Gunakan 3 lembar daun jeruk
1. Gunakan 1 liter air
1. Siapkan Secukupnya minyak goreng
1. Siapkan Secukupnya gula pasir dan garam
1. Siapkan 1/2 bulat gula merah
1. Sediakan  1 Bumbu halus
1. Sediakan 10 butir bawang merah
1. Gunakan 5 siung bawang putih
1. Ambil 2 butir kemiri (sangrai)
1. Ambil 1 sdt ketumbar (sangrai)
1. Gunakan 2 ruas kunyit (bakar)
1. Gunakan  2 Bumbu halus
1. Sediakan 5 sdm kacang tanah (goreng) (sy 2 sdm)
1. Siapkan  Bahan tambahan lain
1. Ambil  Sambal cabai
1. Sediakan  Kecap manis
1. Ambil  Tomat
1. Siapkan  Sayur kol (iris halus)
1. Gunakan  Kentang goreng
1. Gunakan  Jeruk nipis




<!--inarticleads2-->

##### Cara membuat Coto Ayam Makassar:

1. Siapkan bahan, cuci bersih ayam dan semua bahan, baluri ayam dengan jeruk nipis selama 10 menit, bilas sisihkan.
1. Rebus air, tunggu mendidih, masukkan ayam, masak sampai kaldu ayam keluar.
1. Haluskan bumbu, tambahkan sedikit sereh, haluskan, kemudian haluskan juga kacang goreng. Sisihkan.
1. Panaskan secukupnya minyak, tumis bumbu halus, masukkan sereh, lengkuas, daun jeruk, daun salam, masak sampai harum, masukkan kacang, masak sampai mengental. Matikan kompor.
1. Masukkan bumbu yg sudah ditumis ke dalam rebusan air, masak kurang lebih 15 menit agar ayam terasa sedikit berbumbu, lalu tiriskan ayam.
1. Tambahkan irisan daun bawang, gula dan garam, masak smpai air agak menyusut, sambil sesekali diaduk, tes rasa.
1. Goreng ayam sampai kuning kecokelatan. Angakt tiriskan.
1. Penyajian. Suir suir ayam, tambahkan sayur kol, siram kuah coto, tambahkan tomat, irisan daun bawang dan kentang goreng. Siap dinikmati selagi hangat.




Ternyata cara membuat coto ayam makassar yang mantab tidak ribet ini enteng banget ya! Kamu semua mampu memasaknya. Cara Membuat coto ayam makassar Sesuai sekali buat anda yang baru akan belajar memasak ataupun juga untuk kalian yang sudah pandai dalam memasak.

Apakah kamu ingin mencoba bikin resep coto ayam makassar mantab simple ini? Kalau kamu mau, yuk kita segera siapkan alat dan bahannya, lantas buat deh Resep coto ayam makassar yang nikmat dan tidak ribet ini. Betul-betul mudah kan. 

Maka, ketimbang anda berlama-lama, yuk kita langsung buat resep coto ayam makassar ini. Pasti kamu tiidak akan menyesal sudah bikin resep coto ayam makassar enak simple ini! Selamat berkreasi dengan resep coto ayam makassar lezat simple ini di tempat tinggal kalian sendiri,ya!.

