---
description: "Cara membuat Soto ayam kampung favorit Sederhana dan Mudah Dibuat"
title: "Cara membuat Soto ayam kampung favorit Sederhana dan Mudah Dibuat"
slug: 248-cara-membuat-soto-ayam-kampung-favorit-sederhana-dan-mudah-dibuat
date: 2021-01-08T04:35:15.005Z
image: https://img-global.cpcdn.com/recipes/1bd5e438f6ab68eb/680x482cq70/soto-ayam-kampung-favorit-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1bd5e438f6ab68eb/680x482cq70/soto-ayam-kampung-favorit-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1bd5e438f6ab68eb/680x482cq70/soto-ayam-kampung-favorit-foto-resep-utama.jpg
author: Irene Carpenter
ratingvalue: 3.8
reviewcount: 4
recipeingredient:
- "1 ekor ayam kampung"
- "2,5 liter air matang"
- " Bumbu aromatik "
- "3 btg serehgeprak"
- "2 ruas lengkuasgeprak"
- "2 ruas jahegeprak"
- "3 lbr daun jeruk"
- "2 lbr daun salam"
- " Bumbu halus "
- "8 siung bawang merah"
- "4 siung bawang putih"
- "1 sdt merica butiran"
- "1 sdt ketumbar"
- "5 butir kemiri"
- "2 ruas kunir"
- "Sedikit air utk memblender"
- " 1 bgks bumbu instan soto"
recipeinstructions:
- "Didihkan air. Lalu masukkan ayam yg sdh dipotong kecil. Masukkan juga bumbu aromatik nya. Jgn lupa buang buih yg mengapung. Tutup pancinya. Biarkan selama 15 menit."
- "Sambil menunggu rebusan ayam,kita tumis bumbu blenderannya. Jangan diberi tambahan minyak ya selama awal menumis. Biarkan sampai bumbu saat/berkurang airnya,gunakan api kecil&amp;sering dioseng ya spy tdk gosong"
- "Setelah bumbu asat, baru tambahkan 1 sendok sayur minyak. Tumis sampai harum. Masukkan juga bumbu instan soto spy lbh nendang,aduk rata."
- "Masukkan bumbu kedalam rebusan ayam. Aduk rata. Tutup lagi kira2 selama 15 menit atau sampai ayam empuk. Lalu test rasanya. Bila sdh pas,matikan kompornya.. Nikmad bersama kupat/lontong.. Bisa jg disuwir ayamnya yaa..Alhamdulillah.."
categories:
- Resep
tags:
- soto
- ayam
- kampung

katakunci: soto ayam kampung 
nutrition: 210 calories
recipecuisine: Indonesian
preptime: "PT27M"
cooktime: "PT46M"
recipeyield: "3"
recipecategory: Lunch

---


![Soto ayam kampung favorit](https://img-global.cpcdn.com/recipes/1bd5e438f6ab68eb/680x482cq70/soto-ayam-kampung-favorit-foto-resep-utama.jpg)

Apabila kamu seorang yang hobi masak, menyajikan hidangan menggugah selera bagi orang tercinta adalah hal yang menyenangkan bagi kita sendiri. Kewajiban seorang ibu Tidak sekadar mengurus rumah saja, tapi kamu juga wajib memastikan kebutuhan gizi terpenuhi dan hidangan yang dimakan anak-anak wajib menggugah selera.

Di masa  saat ini, kamu sebenarnya bisa membeli masakan siap saji tidak harus susah mengolahnya terlebih dahulu. Tapi banyak juga mereka yang memang mau menghidangkan yang terenak bagi orang tercintanya. Sebab, menyajikan masakan yang dibuat sendiri akan jauh lebih higienis dan bisa menyesuaikan hidangan tersebut berdasarkan selera orang tercinta. 



Mungkinkah anda adalah seorang penikmat soto ayam kampung favorit?. Asal kamu tahu, soto ayam kampung favorit merupakan sajian khas di Indonesia yang sekarang disukai oleh kebanyakan orang di hampir setiap wilayah di Indonesia. Anda bisa memasak soto ayam kampung favorit buatan sendiri di rumah dan boleh jadi hidangan favoritmu di hari libur.

Anda tidak perlu bingung jika kamu ingin memakan soto ayam kampung favorit, sebab soto ayam kampung favorit tidak sukar untuk ditemukan dan juga anda pun bisa mengolahnya sendiri di rumah. soto ayam kampung favorit boleh dibuat memalui beraneka cara. Kini sudah banyak resep kekinian yang membuat soto ayam kampung favorit lebih lezat.

Resep soto ayam kampung favorit pun mudah sekali untuk dibikin, lho. Kalian jangan capek-capek untuk memesan soto ayam kampung favorit, tetapi Kalian mampu membuatnya di rumah sendiri. Bagi Kita yang mau membuatnya, dibawah ini merupakan resep untuk menyajikan soto ayam kampung favorit yang nikamat yang dapat Anda coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Soto ayam kampung favorit:

1. Ambil 1 ekor ayam kampung
1. Gunakan 2,5 liter air matang
1. Sediakan  Bumbu aromatik :
1. Gunakan 3 btg sereh,geprak
1. Ambil 2 ruas lengkuas,geprak
1. Siapkan 2 ruas jahe,geprak
1. Ambil 3 lbr daun jeruk
1. Gunakan 2 lbr daun salam
1. Sediakan  Bumbu halus :
1. Ambil 8 siung bawang merah
1. Siapkan 4 siung bawang putih
1. Gunakan 1 sdt merica butiran
1. Ambil 1 sdt ketumbar
1. Gunakan 5 butir kemiri
1. Gunakan 2 ruas kunir
1. Siapkan Sedikit air utk memblender
1. Siapkan  1 bgks bumbu instan soto




<!--inarticleads2-->

##### Cara membuat Soto ayam kampung favorit:

1. Didihkan air. Lalu masukkan ayam yg sdh dipotong kecil. Masukkan juga bumbu aromatik nya. Jgn lupa buang buih yg mengapung. Tutup pancinya. Biarkan selama 15 menit.
1. Sambil menunggu rebusan ayam,kita tumis bumbu blenderannya. Jangan diberi tambahan minyak ya selama awal menumis. Biarkan sampai bumbu saat/berkurang airnya,gunakan api kecil&amp;sering dioseng ya spy tdk gosong
1. Setelah bumbu asat, baru tambahkan 1 sendok sayur minyak. Tumis sampai harum. Masukkan juga bumbu instan soto spy lbh nendang,aduk rata.
1. Masukkan bumbu kedalam rebusan ayam. Aduk rata. Tutup lagi kira2 selama 15 menit atau sampai ayam empuk. Lalu test rasanya. Bila sdh pas,matikan kompornya.. Nikmad bersama kupat/lontong.. Bisa jg disuwir ayamnya yaa..Alhamdulillah..




Ternyata cara membuat soto ayam kampung favorit yang lezat tidak ribet ini gampang banget ya! Anda Semua bisa membuatnya. Resep soto ayam kampung favorit Sangat sesuai sekali buat kamu yang baru mau belajar memasak maupun bagi anda yang telah ahli memasak.

Tertarik untuk mencoba buat resep soto ayam kampung favorit mantab tidak rumit ini? Kalau kamu ingin, mending kamu segera buruan siapin alat dan bahannya, lalu bikin deh Resep soto ayam kampung favorit yang mantab dan simple ini. Sungguh mudah kan. 

Maka dari itu, ketimbang anda berlama-lama, yuk kita langsung saja hidangkan resep soto ayam kampung favorit ini. Pasti anda tiidak akan nyesel bikin resep soto ayam kampung favorit enak simple ini! Selamat berkreasi dengan resep soto ayam kampung favorit nikmat simple ini di tempat tinggal sendiri,oke!.

