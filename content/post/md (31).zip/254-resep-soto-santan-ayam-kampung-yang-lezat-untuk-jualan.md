---
description: "Resep Soto santan ayam kampung yang lezat Untuk Jualan"
title: "Resep Soto santan ayam kampung yang lezat Untuk Jualan"
slug: 254-resep-soto-santan-ayam-kampung-yang-lezat-untuk-jualan
date: 2021-05-09T15:22:46.421Z
image: https://img-global.cpcdn.com/recipes/021e39922f7ad3fe/680x482cq70/soto-santan-ayam-kampung-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/021e39922f7ad3fe/680x482cq70/soto-santan-ayam-kampung-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/021e39922f7ad3fe/680x482cq70/soto-santan-ayam-kampung-foto-resep-utama.jpg
author: Noah Hardy
ratingvalue: 5
reviewcount: 10
recipeingredient:
- "1/2 kg ayam kampung"
- "1 bks santan cair"
- " Bahan tambahan"
- "1/2 ons soun rebus"
- "1 rb toge rebus sbntr"
- "2 rb kol rebus sebentar"
- "4 btr telor ayam rebus 20 menit"
- "1 batang sledri iris kecil"
- "2 buah jeruk limo"
- "1 buah tomat iris kasar"
- "3 batang daun bawangb iris"
- " Bawang goreng untuk taburan"
- " Bumbu halus"
- "7 siung bawang merah"
- "6 siung bawang putih"
- "4 butir kemiri"
- "1 ruas jahe"
- "1/2 ruas kunyit"
- "1/2 sdt kunyit bubuk"
- "1/2 sdt merica biji"
- "1/2 bks ketumbar biji 500 rupiah"
- "1/2 bks jinten 500 rupiah"
- "1/2 sdt pala biji"
- "3 butir cengkeh"
- "2 butir kapulaga"
- " Bumbu cemplung"
- "1 lmbr daun salam"
- "5 lmbr daun jeruk"
- "1 buah bunga lawang"
- "1/2 potong kayu manis"
- "1/2 ruas lengkuas"
- " Sambal nya"
- "10 biji cabe rawit merah"
- " Gulagaram"
- " Dibikin goang aja"
recipeinstructions:
- "Cuci bersih ayam nya potong2 sesuai keinginan"
- "Didihkan air dan klau sdh bersih ayam ny tinggal masukan ke rebusan air tadi geplek diapi sedang slma 20 menit lalu matikan kompor ny"
- "Haluskan bumbunya boleh pkai blender atau manual aja pke coet biar wanginya nampol klo diulek sendiri mah."
- "Kalo sudah halus semua siapkan minyak di ketel tumis2 hingga harum dan klo dah setengah mateng masukan bumbu cemplung nya dan aduk2 sampe mateng dan kalo sudah mateng kasih air sedikit aja segelas misal ny"
- "Lalu hidup kan lg kompor yg ayam tdi lalu masukan si bumbu ke ayam ny bila kurang air nya boleh tambah lg sesuai selera aja dan koreksi rasa ya bun"
- "Kalo sudah siap siapkan mangkok dan masukan soto nya tata semua bahan tambahan nya.maaf aku juga pke suwiran ayam lgi biar enak aj😁"
- "Siap dihidangkan deh bunda2"
categories:
- Resep
tags:
- soto
- santan
- ayam

katakunci: soto santan ayam 
nutrition: 117 calories
recipecuisine: Indonesian
preptime: "PT18M"
cooktime: "PT46M"
recipeyield: "3"
recipecategory: Dessert

---


![Soto santan ayam kampung](https://img-global.cpcdn.com/recipes/021e39922f7ad3fe/680x482cq70/soto-santan-ayam-kampung-foto-resep-utama.jpg)

Apabila kamu seorang orang tua, menyajikan santapan nikmat bagi keluarga tercinta adalah hal yang memuaskan bagi anda sendiri. Tugas seorang ibu Tidak sekedar mengurus rumah saja, tetapi kamu pun harus menyediakan kebutuhan gizi tercukupi dan juga santapan yang dikonsumsi orang tercinta mesti lezat.

Di era  sekarang, kita memang dapat memesan santapan siap saji tanpa harus susah mengolahnya terlebih dahulu. Namun ada juga orang yang memang mau memberikan hidangan yang terlezat bagi orang tercintanya. Lantaran, menyajikan masakan yang dibuat sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan sesuai dengan masakan kesukaan famili. 



Apakah kamu salah satu penikmat soto santan ayam kampung?. Asal kamu tahu, soto santan ayam kampung merupakan hidangan khas di Nusantara yang saat ini disukai oleh orang-orang di berbagai daerah di Indonesia. Kalian bisa membuat soto santan ayam kampung sendiri di rumahmu dan dapat dijadikan makanan kegemaranmu di akhir pekanmu.

Kalian tak perlu bingung untuk menyantap soto santan ayam kampung, sebab soto santan ayam kampung tidak sulit untuk didapatkan dan kamu pun bisa memasaknya sendiri di rumah. soto santan ayam kampung boleh diolah lewat bermacam cara. Saat ini telah banyak banget cara modern yang menjadikan soto santan ayam kampung semakin lebih mantap.

Resep soto santan ayam kampung pun sangat mudah dibikin, lho. Kalian tidak usah capek-capek untuk membeli soto santan ayam kampung, karena Kita bisa membuatnya di rumahmu. Untuk Kalian yang akan menyajikannya, dibawah ini merupakan resep membuat soto santan ayam kampung yang lezat yang dapat Kalian coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Soto santan ayam kampung:

1. Sediakan 1/2 kg ayam kampung
1. Gunakan 1 bks santan cair
1. Gunakan  Bahan tambahan
1. Ambil 1/2 ons soun rebus
1. Gunakan 1 rb toge rebus sbntr
1. Ambil 2 rb kol rebus sebentar
1. Siapkan 4 btr telor ayam rebus 20 menit
1. Siapkan 1 batang sledri iris kecil
1. Gunakan 2 buah jeruk limo
1. Sediakan 1 buah tomat iris kasar
1. Ambil 3 batang daun bawangb iris
1. Sediakan  Bawang goreng untuk taburan
1. Siapkan  Bumbu halus
1. Siapkan 7 siung bawang merah
1. Gunakan 6 siung bawang putih
1. Siapkan 4 butir kemiri
1. Ambil 1 ruas jahe
1. Siapkan 1/2 ruas kunyit
1. Siapkan 1/2 sdt kunyit bubuk
1. Sediakan 1/2 sdt merica biji
1. Ambil 1/2 bks ketumbar biji 500 rupiah
1. Siapkan 1/2 bks jinten 500 rupiah
1. Siapkan 1/2 sdt pala biji
1. Ambil 3 butir cengkeh
1. Sediakan 2 butir kapulaga
1. Siapkan  Bumbu cemplung
1. Ambil 1 lmbr daun salam
1. Gunakan 5 lmbr daun jeruk
1. Siapkan 1 buah bunga lawang
1. Sediakan 1/2 potong kayu manis
1. Ambil 1/2 ruas lengkuas
1. Gunakan  Sambal nya
1. Sediakan 10 biji cabe rawit merah
1. Sediakan  Gula+garam
1. Sediakan  Dibikin goang aja👍🏻




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Soto santan ayam kampung:

1. Cuci bersih ayam nya potong2 sesuai keinginan
1. Didihkan air dan klau sdh bersih ayam ny tinggal masukan ke rebusan air tadi geplek diapi sedang slma 20 menit lalu matikan kompor ny
1. Haluskan bumbunya boleh pkai blender atau manual aja pke coet biar wanginya nampol klo diulek sendiri mah.
1. Kalo sudah halus semua siapkan minyak di ketel tumis2 hingga harum dan klo dah setengah mateng masukan bumbu cemplung nya dan aduk2 sampe mateng dan kalo sudah mateng kasih air sedikit aja segelas misal ny
1. Lalu hidup kan lg kompor yg ayam tdi lalu masukan si bumbu ke ayam ny bila kurang air nya boleh tambah lg sesuai selera aja dan koreksi rasa ya bun
1. Kalo sudah siap siapkan mangkok dan masukan soto nya tata semua bahan tambahan nya.maaf aku juga pke suwiran ayam lgi biar enak aj😁
1. Siap dihidangkan deh bunda2




Wah ternyata resep soto santan ayam kampung yang mantab sederhana ini enteng banget ya! Kamu semua bisa memasaknya. Resep soto santan ayam kampung Sesuai sekali buat kamu yang baru akan belajar memasak ataupun bagi kalian yang telah ahli memasak.

Apakah kamu ingin mulai mencoba bikin resep soto santan ayam kampung lezat sederhana ini? Kalau anda mau, ayo kalian segera siapin peralatan dan bahan-bahannya, setelah itu bikin deh Resep soto santan ayam kampung yang enak dan tidak ribet ini. Betul-betul taidak sulit kan. 

Maka dari itu, daripada kalian berlama-lama, hayo kita langsung saja hidangkan resep soto santan ayam kampung ini. Pasti anda tak akan nyesel sudah bikin resep soto santan ayam kampung enak simple ini! Selamat mencoba dengan resep soto santan ayam kampung lezat tidak rumit ini di tempat tinggal kalian masing-masing,oke!.

