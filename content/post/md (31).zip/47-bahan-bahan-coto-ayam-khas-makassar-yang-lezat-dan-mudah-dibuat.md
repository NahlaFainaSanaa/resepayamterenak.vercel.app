---
description: "Bahan-bahan Coto ayam khas makassar yang lezat dan Mudah Dibuat"
title: "Bahan-bahan Coto ayam khas makassar yang lezat dan Mudah Dibuat"
slug: 47-bahan-bahan-coto-ayam-khas-makassar-yang-lezat-dan-mudah-dibuat
date: 2021-02-18T23:51:37.829Z
image: https://img-global.cpcdn.com/recipes/7681ce7d9b0eacdb/680x482cq70/coto-ayam-khas-makassar-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7681ce7d9b0eacdb/680x482cq70/coto-ayam-khas-makassar-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7681ce7d9b0eacdb/680x482cq70/coto-ayam-khas-makassar-foto-resep-utama.jpg
author: Seth Fernandez
ratingvalue: 4.6
reviewcount: 6
recipeingredient:
- "1 ekor ayam"
- "mangkok sereh yg sudah diiris"
- "1 mangkok lengkuas yg sdh diiris kurangi sedikit dr porsi sereh"
- "3 bawang putih"
- "1 sendok merica bubuk kurangi bila tdk suka pedasnya"
- "1/2 kg kacang sangrai yg sudah di haluskan"
- " Santan kelapa dr 1 butir kelapa"
- " Bumbu penyedap"
recipeinstructions:
- "Haluskan bumbu lalu tumis  2.Potong potong kecil ayam bersama dgn tulang tulangnya sebesar 1 ruas jari 3.Masak daging ayam yg sudah di potong potong dalam bumbu Coto 4.jika sudah empuk masukkan santan dan kacang sangrai yg sudah dihaluskan 5. Masukkan bumbu penyedap dan bila sudah mendidih Coto siap disajikan bersama dgn ketupat"
- "Potong potong kecil ayam bersama dgn tulang tulangnya sebesar 1 ruas jari"
- "Masak daging ayam yg sudah di potong potong dalam bumbu Coto"
- "Jika sudah empuk masukkan santan dan kacang sangrai yg sudah dihaluskan"
- "Masukkan bumbu penyedap dan bila sudah mendidih Coto siap disajikan bersama dgn ketupat"
- "Jangan lupa taburkan bawang goreng dan daun seledri sebelum di sajikan.selamat mencoba"
categories:
- Resep
tags:
- coto
- ayam
- khas

katakunci: coto ayam khas 
nutrition: 283 calories
recipecuisine: Indonesian
preptime: "PT15M"
cooktime: "PT45M"
recipeyield: "2"
recipecategory: Lunch

---


![Coto ayam khas makassar](https://img-global.cpcdn.com/recipes/7681ce7d9b0eacdb/680x482cq70/coto-ayam-khas-makassar-foto-resep-utama.jpg)

Selaku seorang orang tua, menyuguhkan olahan mantab pada famili merupakan hal yang menyenangkan untuk kita sendiri. Tugas seorang ibu bukan cuma menjaga rumah saja, tapi kamu pun harus memastikan keperluan gizi terpenuhi dan juga olahan yang dimakan orang tercinta harus enak.

Di era  saat ini, kamu sebenarnya bisa mengorder hidangan jadi walaupun tanpa harus ribet membuatnya lebih dulu. Namun ada juga mereka yang selalu mau menyajikan yang terenak untuk orang yang dicintainya. Karena, menyajikan masakan yang diolah sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan sesuai masakan kesukaan keluarga. 



Mungkinkah anda merupakan salah satu penggemar coto ayam khas makassar?. Tahukah kamu, coto ayam khas makassar adalah sajian khas di Indonesia yang saat ini digemari oleh setiap orang di hampir setiap daerah di Nusantara. Anda bisa menghidangkan coto ayam khas makassar sendiri di rumahmu dan boleh jadi hidangan kegemaranmu di akhir pekanmu.

Kalian jangan bingung untuk memakan coto ayam khas makassar, lantaran coto ayam khas makassar tidak sulit untuk dicari dan anda pun dapat mengolahnya sendiri di tempatmu. coto ayam khas makassar boleh diolah memalui berbagai cara. Sekarang ada banyak cara modern yang membuat coto ayam khas makassar semakin lebih lezat.

Resep coto ayam khas makassar juga sangat mudah untuk dibuat, lho. Kamu tidak usah ribet-ribet untuk memesan coto ayam khas makassar, lantaran Kalian mampu menyajikan di rumah sendiri. Untuk Anda yang ingin mencobanya, di bawah ini adalah resep membuat coto ayam khas makassar yang nikamat yang mampu Kalian coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Coto ayam khas makassar:

1. Siapkan 1 ekor ayam
1. Ambil mangkok sereh yg sudah diiris
1. Sediakan 1 mangkok lengkuas yg sdh diiris kurangi sedikit dr porsi sereh
1. Gunakan 3 bawang putih
1. Sediakan 1 sendok merica bubuk, kurangi bila tdk suka pedasnya
1. Siapkan 1/2 kg kacang sangrai yg sudah di haluskan
1. Ambil  Santan kelapa dr 1 butir kelapa
1. Sediakan  Bumbu penyedap




<!--inarticleads2-->

##### Cara menyiapkan Coto ayam khas makassar:

1. Haluskan bumbu lalu tumis  - 2.Potong potong kecil ayam bersama dgn tulang tulangnya sebesar 1 ruas jari - 3.Masak daging ayam yg sudah di potong potong dalam bumbu Coto - 4.jika sudah empuk masukkan santan dan kacang sangrai yg sudah dihaluskan - 5. Masukkan bumbu penyedap dan bila sudah mendidih Coto siap disajikan bersama dgn ketupat
1. Potong potong kecil ayam bersama dgn tulang tulangnya sebesar 1 ruas jari
1. Masak daging ayam yg sudah di potong potong dalam bumbu Coto
1. Jika sudah empuk masukkan santan dan kacang sangrai yg sudah dihaluskan
1. Masukkan bumbu penyedap dan bila sudah mendidih Coto siap disajikan bersama dgn ketupat
1. Jangan lupa taburkan bawang goreng dan daun seledri sebelum di sajikan.selamat mencoba




Wah ternyata cara membuat coto ayam khas makassar yang lezat sederhana ini gampang banget ya! Kalian semua dapat membuatnya. Cara buat coto ayam khas makassar Sangat sesuai sekali buat kamu yang baru akan belajar memasak maupun juga untuk kamu yang telah jago memasak.

Tertarik untuk mulai mencoba buat resep coto ayam khas makassar lezat tidak rumit ini? Kalau mau, yuk kita segera buruan siapin peralatan dan bahan-bahannya, setelah itu bikin deh Resep coto ayam khas makassar yang enak dan tidak rumit ini. Sangat taidak sulit kan. 

Oleh karena itu, daripada kalian berfikir lama-lama, maka kita langsung saja sajikan resep coto ayam khas makassar ini. Dijamin kalian tak akan menyesal sudah bikin resep coto ayam khas makassar mantab sederhana ini! Selamat berkreasi dengan resep coto ayam khas makassar lezat sederhana ini di tempat tinggal kalian sendiri,ya!.

