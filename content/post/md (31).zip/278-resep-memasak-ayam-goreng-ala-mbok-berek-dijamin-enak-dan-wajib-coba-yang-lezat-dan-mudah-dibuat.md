---
description: "Resep memasak Ayam Goreng Ala Mbok Berek (Dijamin Enak dan Wajib Coba) yang lezat dan Mudah Dibuat"
title: "Resep memasak Ayam Goreng Ala Mbok Berek (Dijamin Enak dan Wajib Coba) yang lezat dan Mudah Dibuat"
slug: 278-resep-memasak-ayam-goreng-ala-mbok-berek-dijamin-enak-dan-wajib-coba-yang-lezat-dan-mudah-dibuat
date: 2021-05-22T15:54:02.817Z
image: https://img-global.cpcdn.com/recipes/c171cc18b001a08f/680x482cq70/ayam-goreng-ala-mbok-berek-dijamin-enak-dan-wajib-coba-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c171cc18b001a08f/680x482cq70/ayam-goreng-ala-mbok-berek-dijamin-enak-dan-wajib-coba-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c171cc18b001a08f/680x482cq70/ayam-goreng-ala-mbok-berek-dijamin-enak-dan-wajib-coba-foto-resep-utama.jpg
author: Lloyd Walsh
ratingvalue: 3.1
reviewcount: 12
recipeingredient:
- "1 Ekor Ayam Kampung Saya Pakai Ayam Negri"
- "1 Buah Jeruk Nipis"
- "3 lbr Daun Salam"
- "1 Batang Sereh di Geprek"
- "100 ml Santan Instan dicampur dengan 400 ml Air"
- " Bumbu Halus"
- "9 Siung Bawang Merah"
- "6 Siung Bawang Putih"
- "4 Butir Kemiri"
- "1 sdt Ketumbar"
- "1 cm Kunyit optional"
- "1 sdt Gula"
- "Secukupnya garam me  2 sdt"
- " Adonan Kremesan"
- "300 ml Sisa Air Ungkep Ayam"
- "2 sdm Munjung Tepung Beras"
- "125 gr Tepung Sagu"
- "1/2 sdt Baking Soda"
- "1 Butir Kuning Telur"
recipeinstructions:
- "Siapkan Bahan Bahan"
- "Cuci bersih ayam lalu kucuri dengan perasan air Jeruk Nipis, diamkan selama 15 menit kemudian bilas kembali hingga bersih dan sisihkan."
- "Siapkan wajan, lalu masukkan bumbu halus + sereh + daun salam + garam + gula dan Santan"
- "Aduk agar bumbu tercampur rata, kemudian masukkan ayam yg sudaj dibersihkan hingga ayam terendam. Masak dengan api kecil dan hingga air menyusut dan ayam empuk."
- "Setelah itu angkat ayam dan pisahkan dari airnya. Sisa air ungkep akan digunakan sebagai bahan kremesan."
- "Panaskan minyak, kemudian buat adonan kremesan. Masukkan Telur kedalam sisa air ungkep + tepung beras + tepung sagu, aduk hingga adonan tercampur rata. *NOTE* : Untuk baking Soda dimasukkan saat minyak sdh benar2 panas dan ayam siap di goreng."
- "Setelah minyak panas, masukkan baking soda kedalam adonan kremesan, aduk rata dan celupkan ayam kedalam adonannya."
- "Goreng ayam lalu kucuri dengan teknik melingkar dengan tangan. Nanti akan membuyar sndiri kremesannya. Jika sudah kaku balik ayamnya"
- "Masak hingga kuning kecoklatan angkat dan tiriskan."
- "Ayam Goreng Ala Mbok Berek siap disajikan. Rasanya endesssss cocol sambel dan lalapan oke. Selesai 😊"
categories:
- Resep
tags:
- ayam
- goreng
- ala

katakunci: ayam goreng ala 
nutrition: 267 calories
recipecuisine: Indonesian
preptime: "PT24M"
cooktime: "PT31M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam Goreng Ala Mbok Berek (Dijamin Enak dan Wajib Coba)](https://img-global.cpcdn.com/recipes/c171cc18b001a08f/680x482cq70/ayam-goreng-ala-mbok-berek-dijamin-enak-dan-wajib-coba-foto-resep-utama.jpg)

Sebagai seorang ibu, menyuguhkan hidangan mantab pada famili adalah suatu hal yang menyenangkan bagi kamu sendiri. Tugas seorang istri Tidak cuma mengurus rumah saja, tapi anda juga wajib menyediakan keperluan gizi tercukupi dan masakan yang disantap orang tercinta wajib nikmat.

Di zaman  saat ini, kamu memang dapat membeli panganan jadi meski tanpa harus susah membuatnya terlebih dahulu. Namun banyak juga orang yang memang mau memberikan yang terenak untuk orang yang dicintainya. Sebab, menghidangkan masakan sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan makanan tersebut sesuai dengan kesukaan famili. 



Apakah kamu seorang penyuka ayam goreng ala mbok berek (dijamin enak dan wajib coba)?. Tahukah kamu, ayam goreng ala mbok berek (dijamin enak dan wajib coba) adalah makanan khas di Nusantara yang kini disenangi oleh orang-orang di hampir setiap tempat di Nusantara. Anda dapat menghidangkan ayam goreng ala mbok berek (dijamin enak dan wajib coba) olahan sendiri di rumah dan boleh jadi makanan kegemaranmu di akhir pekanmu.

Kamu tak perlu bingung untuk mendapatkan ayam goreng ala mbok berek (dijamin enak dan wajib coba), karena ayam goreng ala mbok berek (dijamin enak dan wajib coba) tidak sukar untuk dicari dan juga anda pun bisa membuatnya sendiri di rumah. ayam goreng ala mbok berek (dijamin enak dan wajib coba) boleh dimasak lewat bermacam cara. Kini ada banyak resep modern yang menjadikan ayam goreng ala mbok berek (dijamin enak dan wajib coba) lebih mantap.

Resep ayam goreng ala mbok berek (dijamin enak dan wajib coba) juga mudah sekali dihidangkan, lho. Anda tidak usah ribet-ribet untuk membeli ayam goreng ala mbok berek (dijamin enak dan wajib coba), lantaran Kita bisa menghidangkan ditempatmu. Untuk Kamu yang ingin mencobanya, berikut ini resep untuk membuat ayam goreng ala mbok berek (dijamin enak dan wajib coba) yang enak yang dapat Kalian coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Ayam Goreng Ala Mbok Berek (Dijamin Enak dan Wajib Coba):

1. Sediakan 1 Ekor Ayam Kampung (Saya Pakai Ayam Negri)
1. Ambil 1 Buah Jeruk Nipis
1. Ambil 3 lbr Daun Salam
1. Gunakan 1 Batang Sereh di Geprek
1. Ambil 100 ml Santan Instan (dicampur dengan 400 ml Air)
1. Ambil  Bumbu Halus
1. Ambil 9 Siung Bawang Merah
1. Sediakan 6 Siung Bawang Putih
1. Ambil 4 Butir Kemiri
1. Sediakan 1 sdt Ketumbar
1. Gunakan 1 cm Kunyit (optional)
1. Siapkan 1 sdt Gula
1. Sediakan Secukupnya garam (me : 2 sdt)
1. Gunakan  Adonan Kremesan
1. Sediakan 300 ml Sisa Air Ungkep Ayam
1. Sediakan 2 sdm Munjung Tepung Beras
1. Sediakan 125 gr Tepung Sagu
1. Ambil 1/2 sdt Baking Soda
1. Siapkan 1 Butir Kuning Telur




<!--inarticleads2-->

##### Cara menyiapkan Ayam Goreng Ala Mbok Berek (Dijamin Enak dan Wajib Coba):

1. Siapkan Bahan Bahan
1. Cuci bersih ayam lalu kucuri dengan perasan air Jeruk Nipis, diamkan selama 15 menit kemudian bilas kembali hingga bersih dan sisihkan.
1. Siapkan wajan, lalu masukkan bumbu halus + sereh + daun salam + garam + gula dan Santan
1. Aduk agar bumbu tercampur rata, kemudian masukkan ayam yg sudaj dibersihkan hingga ayam terendam. Masak dengan api kecil dan hingga air menyusut dan ayam empuk.
1. Setelah itu angkat ayam dan pisahkan dari airnya. Sisa air ungkep akan digunakan sebagai bahan kremesan.
1. Panaskan minyak, kemudian buat adonan kremesan. Masukkan Telur kedalam sisa air ungkep + tepung beras + tepung sagu, aduk hingga adonan tercampur rata. *NOTE* : Untuk baking Soda dimasukkan saat minyak sdh benar2 panas dan ayam siap di goreng.
1. Setelah minyak panas, masukkan baking soda kedalam adonan kremesan, aduk rata dan celupkan ayam kedalam adonannya.
1. Goreng ayam lalu kucuri dengan teknik melingkar dengan tangan. Nanti akan membuyar sndiri kremesannya. Jika sudah kaku balik ayamnya
1. Masak hingga kuning kecoklatan angkat dan tiriskan.
1. Ayam Goreng Ala Mbok Berek siap disajikan. Rasanya endesssss cocol sambel dan lalapan oke. Selesai 😊




Wah ternyata cara buat ayam goreng ala mbok berek (dijamin enak dan wajib coba) yang lezat sederhana ini gampang sekali ya! Kita semua mampu mencobanya. Cara buat ayam goreng ala mbok berek (dijamin enak dan wajib coba) Sangat sesuai banget untuk kalian yang sedang belajar memasak ataupun juga bagi anda yang telah ahli dalam memasak.

Tertarik untuk mulai mencoba buat resep ayam goreng ala mbok berek (dijamin enak dan wajib coba) nikmat tidak ribet ini? Kalau ingin, ayo kamu segera buruan menyiapkan alat dan bahan-bahannya, kemudian buat deh Resep ayam goreng ala mbok berek (dijamin enak dan wajib coba) yang lezat dan tidak ribet ini. Sungguh mudah kan. 

Oleh karena itu, ketimbang kalian berlama-lama, maka langsung aja sajikan resep ayam goreng ala mbok berek (dijamin enak dan wajib coba) ini. Dijamin anda tak akan menyesal sudah membuat resep ayam goreng ala mbok berek (dijamin enak dan wajib coba) mantab sederhana ini! Selamat mencoba dengan resep ayam goreng ala mbok berek (dijamin enak dan wajib coba) lezat simple ini di tempat tinggal sendiri,oke!.

