---
description: "Cara buat Tongseng Ayam yang lezat dan Mudah Dibuat"
title: "Cara buat Tongseng Ayam yang lezat dan Mudah Dibuat"
slug: 477-cara-buat-tongseng-ayam-yang-lezat-dan-mudah-dibuat
date: 2021-04-01T09:52:31.839Z
image: https://img-global.cpcdn.com/recipes/f1f0fd9a2568b8b7/680x482cq70/tongseng-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f1f0fd9a2568b8b7/680x482cq70/tongseng-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f1f0fd9a2568b8b7/680x482cq70/tongseng-ayam-foto-resep-utama.jpg
author: Christine Ruiz
ratingvalue: 3.8
reviewcount: 13
recipeingredient:
- "potong kecil Dada ayam"
- "3 lembar daun salam"
- "1 batang serai memarkan"
- "1 ruas lengkuas"
- " Cabe rawit merah"
- " Daun bawang"
- "1 buah tomat"
- " Bumbu Halus"
- "3 siung bawang putih"
- "4 siung bawang merah"
- "2 ruas kunyit"
- "1 ruas jahe"
- "2 kemiri sangrai"
- "Secukupnya garam"
- "Secukupnya gula pasir"
- "Secukupnya kaldu jamur"
- "Secukupnya kecap manis"
- " Jeruk lemon"
recipeinstructions:
- "Potong-potong ayam, kemarin dada jadi 12 bagian. Siram dengan perasan jeruk lemon. Diamkan sekitar 15 menit. Setelah itu cuci bersih, rebus setengah matang, angkat dan tiriskan."
- "Tumis salam, sereh, bumbu halus hingga matang. Masukkan ayam yang sudah di rebus. Siram dengan perasan jeruk lemon. Aduk-aduk."
- "Tambahkan kecap, air, garam, gula, kaldu jamur. Tes rasa. Masak dengan api kecil."
- "Iris cabe rawit merah sesuai selera, masukkan. Jika sudah matang matikan kompor. Masukkan irisan daun bawang dan tomat. Aduk sebentar."
- "Angkat dan sajikan."
categories:
- Resep
tags:
- tongseng
- ayam

katakunci: tongseng ayam 
nutrition: 177 calories
recipecuisine: Indonesian
preptime: "PT19M"
cooktime: "PT45M"
recipeyield: "3"
recipecategory: Lunch

---


![Tongseng Ayam](https://img-global.cpcdn.com/recipes/f1f0fd9a2568b8b7/680x482cq70/tongseng-ayam-foto-resep-utama.jpg)

Selaku seorang yang hobi memasak, menyuguhkan olahan mantab untuk famili adalah suatu hal yang menyenangkan bagi kita sendiri. Tugas seorang  wanita Tidak hanya mengerjakan pekerjaan rumah saja, namun anda pun wajib menyediakan keperluan nutrisi terpenuhi dan panganan yang dikonsumsi orang tercinta wajib enak.

Di zaman  sekarang, anda sebenarnya dapat membeli masakan praktis tanpa harus ribet memasaknya dulu. Tapi ada juga lho orang yang selalu mau memberikan makanan yang terbaik bagi keluarganya. Sebab, memasak sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan masakan tersebut berdasarkan kesukaan famili. 



Mungkinkah anda adalah salah satu penyuka tongseng ayam?. Asal kamu tahu, tongseng ayam adalah sajian khas di Indonesia yang sekarang digemari oleh setiap orang dari hampir setiap tempat di Nusantara. Kamu bisa menyajikan tongseng ayam sendiri di rumahmu dan boleh jadi hidangan favorit di akhir pekanmu.

Kalian tidak usah bingung jika kamu ingin memakan tongseng ayam, lantaran tongseng ayam tidak sulit untuk dicari dan kamu pun bisa memasaknya sendiri di rumah. tongseng ayam bisa diolah lewat beragam cara. Kini ada banyak sekali resep modern yang menjadikan tongseng ayam lebih enak.

Resep tongseng ayam juga sangat mudah dihidangkan, lho. Kita tidak perlu ribet-ribet untuk membeli tongseng ayam, lantaran Kamu bisa menghidangkan di rumahmu. Bagi Kalian yang hendak membuatnya, berikut cara untuk menyajikan tongseng ayam yang enak yang dapat Kamu coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Tongseng Ayam:

1. Siapkan potong kecil Dada ayam
1. Ambil 3 lembar daun salam
1. Ambil 1 batang serai, memarkan
1. Gunakan 1 ruas lengkuas
1. Sediakan  Cabe rawit merah
1. Gunakan  Daun bawang
1. Sediakan 1 buah tomat
1. Siapkan  Bumbu Halus
1. Gunakan 3 siung bawang putih
1. Sediakan 4 siung bawang merah
1. Gunakan 2 ruas kunyit
1. Gunakan 1 ruas jahe
1. Siapkan 2 kemiri sangrai
1. Siapkan Secukupnya garam
1. Sediakan Secukupnya gula pasir
1. Sediakan Secukupnya kaldu jamur
1. Ambil Secukupnya kecap manis
1. Sediakan  Jeruk lemon




<!--inarticleads2-->

##### Cara membuat Tongseng Ayam:

1. Potong-potong ayam, kemarin dada jadi 12 bagian. Siram dengan perasan jeruk lemon. Diamkan sekitar 15 menit. Setelah itu cuci bersih, rebus setengah matang, angkat dan tiriskan.
1. Tumis salam, sereh, bumbu halus hingga matang. Masukkan ayam yang sudah di rebus. Siram dengan perasan jeruk lemon. Aduk-aduk.
1. Tambahkan kecap, air, garam, gula, kaldu jamur. Tes rasa. Masak dengan api kecil.
1. Iris cabe rawit merah sesuai selera, masukkan. Jika sudah matang matikan kompor. Masukkan irisan daun bawang dan tomat. Aduk sebentar.
1. Angkat dan sajikan.




Ternyata cara buat tongseng ayam yang lezat tidak rumit ini mudah sekali ya! Kamu semua mampu memasaknya. Cara buat tongseng ayam Cocok banget untuk kamu yang baru mau belajar memasak maupun juga untuk kalian yang telah pandai dalam memasak.

Tertarik untuk mencoba membikin resep tongseng ayam enak tidak ribet ini? Kalau anda ingin, mending kamu segera buruan menyiapkan alat dan bahannya, maka buat deh Resep tongseng ayam yang nikmat dan simple ini. Sungguh mudah kan. 

Oleh karena itu, daripada kamu diam saja, yuk kita langsung saja buat resep tongseng ayam ini. Dijamin kalian tiidak akan menyesal membuat resep tongseng ayam mantab sederhana ini! Selamat berkreasi dengan resep tongseng ayam nikmat simple ini di tempat tinggal kalian masing-masing,oke!.

