---
description: "Cara buat Tahu dan Ati Ayam Masak Sambal yang lezat dan Mudah Dibuat"
title: "Cara buat Tahu dan Ati Ayam Masak Sambal yang lezat dan Mudah Dibuat"
slug: 322-cara-buat-tahu-dan-ati-ayam-masak-sambal-yang-lezat-dan-mudah-dibuat
date: 2021-03-06T15:11:27.690Z
image: https://img-global.cpcdn.com/recipes/7730efe4abe61b5a/680x482cq70/tahu-dan-ati-ayam-masak-sambal-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7730efe4abe61b5a/680x482cq70/tahu-dan-ati-ayam-masak-sambal-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7730efe4abe61b5a/680x482cq70/tahu-dan-ati-ayam-masak-sambal-foto-resep-utama.jpg
author: Max Miles
ratingvalue: 4.1
reviewcount: 12
recipeingredient:
- "4 buah Tahu ukuran sedang goreng"
- "250 gram Hati ayam rebus lalu goreng"
- "2 cm lengkuas geprek"
- "2 lembar daun salam"
- "1 sdt Garam"
- "1 sdt Gula"
- "1/2 sdt Merica"
- "2 sdm Kecap manis jika suka"
- " Kaldu udang 1 sdt bisa juga kaldu jamur atau lainnya           lihat resep"
- " Bumbu halus "
- "6 buah Bawang merah"
- "3 siung Bawang putih"
- "3 buah Cabe merah besar"
- "15 buah cabe rawit sesuai selera"
recipeinstructions:
- "Siapkan bahan : Goreng tahu. Rebus dan goreng hati sapi. Haluskan bumbu."
- "Tumis bumbu dengan sedikit minyak, masukkan Lengkuas dan daun salam. Aduk rata biarkan hingga harum, selagi menunggu, potong² hati sapi. Setelah bumbu harum masukkan kedua bahan utama. Aduk rata."
- "Beri sedikit air, masukkan, gula, garam, merica, kaldu udang, kecap. Aduk rata. Test rasa. Masak hingga air menyusut dan bumbu meresap."
- "Tahu dan Ati Ayam masak sambal, siap di sajikan dengan nasi hangat. Selamat mencoba. Praktis dan enak."
categories:
- Resep
tags:
- tahu
- dan
- ati

katakunci: tahu dan ati 
nutrition: 199 calories
recipecuisine: Indonesian
preptime: "PT17M"
cooktime: "PT51M"
recipeyield: "2"
recipecategory: Dinner

---


![Tahu dan Ati Ayam Masak Sambal](https://img-global.cpcdn.com/recipes/7730efe4abe61b5a/680x482cq70/tahu-dan-ati-ayam-masak-sambal-foto-resep-utama.jpg)

Andai kamu seorang yang hobi masak, menyajikan hidangan mantab untuk famili adalah hal yang membahagiakan bagi anda sendiri. Tanggung jawab seorang  wanita Tidak sekadar menangani rumah saja, tapi anda juga wajib memastikan kebutuhan gizi tercukupi dan juga santapan yang disantap keluarga tercinta mesti sedap.

Di zaman  sekarang, kalian memang bisa membeli hidangan instan tidak harus repot membuatnya terlebih dahulu. Tapi banyak juga mereka yang memang mau memberikan yang terbaik untuk orang yang dicintainya. Pasalnya, menghidangkan masakan yang diolah sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan masakan tersebut berdasarkan makanan kesukaan orang tercinta. 



Apakah anda merupakan seorang penyuka tahu dan ati ayam masak sambal?. Asal kamu tahu, tahu dan ati ayam masak sambal adalah makanan khas di Indonesia yang kini disukai oleh setiap orang di hampir setiap tempat di Nusantara. Anda dapat membuat tahu dan ati ayam masak sambal sendiri di rumahmu dan boleh jadi hidangan favoritmu di akhir pekan.

Kamu jangan bingung untuk memakan tahu dan ati ayam masak sambal, lantaran tahu dan ati ayam masak sambal sangat mudah untuk dicari dan kita pun boleh memasaknya sendiri di tempatmu. tahu dan ati ayam masak sambal bisa dimasak dengan beragam cara. Kini pun sudah banyak banget cara kekinian yang menjadikan tahu dan ati ayam masak sambal semakin lebih enak.

Resep tahu dan ati ayam masak sambal juga sangat gampang dihidangkan, lho. Anda tidak perlu ribet-ribet untuk memesan tahu dan ati ayam masak sambal, sebab Kamu bisa membuatnya di rumahmu. Bagi Kita yang akan menyajikannya, dibawah ini merupakan resep untuk menyajikan tahu dan ati ayam masak sambal yang enak yang dapat Kamu hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Tahu dan Ati Ayam Masak Sambal:

1. Sediakan 4 buah Tahu ukuran sedang (goreng)
1. Siapkan 250 gram Hati ayam (rebus lalu goreng)
1. Gunakan 2 cm lengkuas geprek
1. Ambil 2 lembar daun salam
1. Ambil 1 sdt Garam
1. Ambil 1 sdt Gula
1. Siapkan 1/2 sdt Merica
1. Gunakan 2 sdm Kecap manis (jika suka)
1. Ambil  Kaldu udang 1 sdt (bisa juga kaldu jamur atau lainnya)           (lihat resep)
1. Ambil  Bumbu halus :
1. Gunakan 6 buah Bawang merah
1. Siapkan 3 siung Bawang putih
1. Ambil 3 buah Cabe merah besar
1. Siapkan 15 buah cabe rawit (sesuai selera)




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Tahu dan Ati Ayam Masak Sambal:

1. Siapkan bahan : Goreng tahu. Rebus dan goreng hati sapi. Haluskan bumbu.
<img src="https://img-global.cpcdn.com/steps/8726268525b4a5b5/160x128cq70/tahu-dan-ati-ayam-masak-sambal-langkah-memasak-1-foto.jpg" alt="Tahu dan Ati Ayam Masak Sambal"><img src="https://img-global.cpcdn.com/steps/90448fce54548c1e/160x128cq70/tahu-dan-ati-ayam-masak-sambal-langkah-memasak-1-foto.jpg" alt="Tahu dan Ati Ayam Masak Sambal">1. Tumis bumbu dengan sedikit minyak, masukkan Lengkuas dan daun salam. Aduk rata biarkan hingga harum, selagi menunggu, potong² hati sapi. Setelah bumbu harum masukkan kedua bahan utama. Aduk rata.
1. Beri sedikit air, masukkan, gula, garam, merica, kaldu udang, kecap. Aduk rata. Test rasa. Masak hingga air menyusut dan bumbu meresap.
1. Tahu dan Ati Ayam masak sambal, siap di sajikan dengan nasi hangat. Selamat mencoba. Praktis dan enak.




Ternyata resep tahu dan ati ayam masak sambal yang nikamt tidak ribet ini gampang banget ya! Kita semua dapat menghidangkannya. Cara buat tahu dan ati ayam masak sambal Sangat cocok banget buat anda yang baru mau belajar memasak atau juga bagi kalian yang sudah hebat dalam memasak.

Apakah kamu mau mulai mencoba membikin resep tahu dan ati ayam masak sambal enak tidak ribet ini? Kalau ingin, mending kamu segera siapkan alat-alat dan bahannya, setelah itu buat deh Resep tahu dan ati ayam masak sambal yang lezat dan simple ini. Sangat taidak sulit kan. 

Jadi, daripada kita berfikir lama-lama, hayo kita langsung saja bikin resep tahu dan ati ayam masak sambal ini. Pasti anda gak akan nyesel membuat resep tahu dan ati ayam masak sambal mantab tidak ribet ini! Selamat berkreasi dengan resep tahu dan ati ayam masak sambal nikmat tidak ribet ini di tempat tinggal kalian masing-masing,ya!.

