---
description: "Bahan-bahan Soto ayam Kudus yang sedap dan Mudah Dibuat"
title: "Bahan-bahan Soto ayam Kudus yang sedap dan Mudah Dibuat"
slug: 294-bahan-bahan-soto-ayam-kudus-yang-sedap-dan-mudah-dibuat
date: 2021-03-14T11:44:55.855Z
image: https://img-global.cpcdn.com/recipes/63ad7465fb4bb986/680x482cq70/soto-ayam-kudus-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/63ad7465fb4bb986/680x482cq70/soto-ayam-kudus-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/63ad7465fb4bb986/680x482cq70/soto-ayam-kudus-foto-resep-utama.jpg
author: Brandon Phelps
ratingvalue: 4.5
reviewcount: 11
recipeingredient:
- "1 ekor ayam"
- "1 lt air untuk merebus bisa disesuaikan"
- "1 btg daun bawang iris 1 cm"
- "1 sdm minyak untuk menumis bumbu"
- " Bumbu"
- "5 siung bawang putih "
- "5-10 siung bawang merah "
- "1/4-1/2 siung bawang bombay  pengganti 5 bawang merah opsional"
- "4 btr kemiri "
- " Note  saya pakai 2 sdm bumbu putih"
- "1 sdt ketumbar bubuk"
- "1/2 sdt merica bubuk"
- "1 cm jahe or 12 sdt jahe bubuk"
- "1 cm kunyit or 12 sdt kunyit bubuk bisa ditambah untuk kuah yg lebih kuning"
- "1 sdt garam"
- "1/2 sdt gula"
- "1 cm lengkuas geprek"
- "1 btg sereh geprek"
- "2 lbr daun salam"
- "4 lbr daun jeruk buang tangkainya bisa dikurangi dan ditambahkan sari green lime"
- " Pelengkap"
- " Telur rebus kupas belah tengah"
- " Rice noodles siram air mendidih"
- " Kubis iris tipis siram air mendidih"
- " Taoge bersihkan siram air mendidih di gambar saya ga pake"
- " Bawang goreng"
- " Seledri cuci iris tipis"
- " Kentang iris tipis goreng kering"
recipeinstructions:
- "Rebus ayam, saring lemak pertama."
- "Haluskan semua bumbu kecuali daun2an. Tumis sampai harum. Tambahkan daun salam, daun jeruk dan sereh."
- "Masukkan bumbu yg sudah matang ke dalam kaldu ayam. Tambahkan garam dan gula sesuai selera. Cicipi."
- "Saat ayam telah matang, tiriskan ayam. Tambahkan daun bawang. Rebus sebentar lg sampai harum."
- "Suwir-suwir ayam. Boleh juga digoreng dulu. Sisa tulang biasanya saya kembalikan ke kuah kaldu."
- "Hidangkan dengan pelengkapnya dan selamat menikmati 😋. Semangat sehat 💪💕."
categories:
- Resep
tags:
- soto
- ayam
- kudus

katakunci: soto ayam kudus 
nutrition: 221 calories
recipecuisine: Indonesian
preptime: "PT12M"
cooktime: "PT31M"
recipeyield: "3"
recipecategory: Dessert

---


![Soto ayam Kudus](https://img-global.cpcdn.com/recipes/63ad7465fb4bb986/680x482cq70/soto-ayam-kudus-foto-resep-utama.jpg)

Sebagai seorang ibu, menyuguhkan olahan sedap kepada keluarga tercinta merupakan hal yang sangat menyenangkan bagi kamu sendiri. Kewajiban seorang ibu Tidak saja menangani rumah saja, tetapi anda pun wajib menyediakan keperluan nutrisi tercukupi dan masakan yang dimakan orang tercinta wajib enak.

Di zaman  saat ini, kalian memang bisa memesan panganan yang sudah jadi walaupun tidak harus capek memasaknya dahulu. Namun ada juga lho mereka yang selalu mau memberikan yang terlezat untuk orang tercintanya. Sebab, menghidangkan masakan yang dibuat sendiri akan jauh lebih higienis dan bisa menyesuaikan masakan tersebut berdasarkan kesukaan famili. 



Mungkinkah anda adalah salah satu penyuka soto ayam kudus?. Tahukah kamu, soto ayam kudus merupakan hidangan khas di Nusantara yang kini digemari oleh setiap orang dari berbagai wilayah di Indonesia. Kita bisa membuat soto ayam kudus kreasi sendiri di rumahmu dan boleh dijadikan camilan kesukaanmu di hari libur.

Anda jangan bingung jika kamu ingin menyantap soto ayam kudus, lantaran soto ayam kudus tidak sukar untuk ditemukan dan kalian pun dapat memasaknya sendiri di rumah. soto ayam kudus boleh dibuat lewat beragam cara. Kini pun sudah banyak cara kekinian yang membuat soto ayam kudus semakin lebih nikmat.

Resep soto ayam kudus pun sangat gampang untuk dibuat, lho. Anda tidak usah capek-capek untuk memesan soto ayam kudus, sebab Anda bisa menghidangkan ditempatmu. Bagi Kalian yang hendak menghidangkannya, inilah cara untuk menyajikan soto ayam kudus yang nikamat yang dapat Kita hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Soto ayam Kudus:

1. Gunakan 1 ekor ayam
1. Gunakan 1 lt air untuk merebus, bisa disesuaikan
1. Ambil 1 btg daun bawang, iris 1 cm
1. Ambil 1 sdm minyak untuk menumis bumbu
1. Sediakan  Bumbu
1. Siapkan 5 siung bawang putih *
1. Siapkan 5-10 siung bawang merah *
1. Gunakan 1/4-1/2 siung bawang bombay *, pengganti 5 bawang merah (opsional)
1. Siapkan 4 btr kemiri *
1. Gunakan  Note: * saya pakai 2 sdm bumbu putih
1. Siapkan 1 sdt ketumbar bubuk
1. Ambil 1/2 sdt merica bubuk
1. Siapkan 1 cm jahe, or 1/2 sdt jahe bubuk
1. Gunakan 1 cm kunyit, or 1/2 sdt kunyit bubuk bisa ditambah untuk kuah yg lebih kuning
1. Ambil 1 sdt garam
1. Gunakan 1/2 sdt gula
1. Gunakan 1 cm lengkuas, geprek
1. Ambil 1 btg sereh, geprek
1. Ambil 2 lbr daun salam
1. Ambil 4 lbr daun jeruk, buang tangkainya, bisa dikurangi dan ditambahkan sari green lime
1. Ambil  Pelengkap
1. Sediakan  Telur rebus, kupas, belah tengah
1. Siapkan  Rice noodles, siram air mendidih
1. Siapkan  Kubis, iris tipis, siram air mendidih
1. Ambil  Taoge, bersihkan, siram air mendidih (di gambar saya ga pake)
1. Sediakan  Bawang goreng
1. Siapkan  Seledri, cuci, iris tipis
1. Siapkan  Kentang, iris tipis, goreng kering




<!--inarticleads2-->

##### Cara menyiapkan Soto ayam Kudus:

1. Rebus ayam, saring lemak pertama.
1. Haluskan semua bumbu kecuali daun2an. Tumis sampai harum. Tambahkan daun salam, daun jeruk dan sereh.
1. Masukkan bumbu yg sudah matang ke dalam kaldu ayam. Tambahkan garam dan gula sesuai selera. Cicipi.
1. Saat ayam telah matang, tiriskan ayam. Tambahkan daun bawang. Rebus sebentar lg sampai harum.
1. Suwir-suwir ayam. Boleh juga digoreng dulu. Sisa tulang biasanya saya kembalikan ke kuah kaldu.
1. Hidangkan dengan pelengkapnya dan selamat menikmati 😋. Semangat sehat 💪💕.




Wah ternyata resep soto ayam kudus yang nikamt simple ini gampang sekali ya! Kita semua dapat membuatnya. Resep soto ayam kudus Cocok sekali untuk kita yang sedang belajar memasak ataupun juga bagi anda yang sudah pandai memasak.

Tertarik untuk mulai mencoba membuat resep soto ayam kudus nikmat tidak ribet ini? Kalau tertarik, ayo kamu segera buruan siapkan peralatan dan bahan-bahannya, lantas buat deh Resep soto ayam kudus yang mantab dan tidak ribet ini. Benar-benar gampang kan. 

Maka, daripada anda berlama-lama, maka kita langsung saja bikin resep soto ayam kudus ini. Pasti kamu tak akan nyesel sudah membuat resep soto ayam kudus mantab simple ini! Selamat mencoba dengan resep soto ayam kudus nikmat tidak ribet ini di tempat tinggal kalian masing-masing,oke!.

