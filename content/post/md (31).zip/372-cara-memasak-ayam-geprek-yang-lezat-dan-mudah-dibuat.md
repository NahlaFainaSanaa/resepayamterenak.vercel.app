---
description: "Cara memasak Ayam Geprek yang lezat dan Mudah Dibuat"
title: "Cara memasak Ayam Geprek yang lezat dan Mudah Dibuat"
slug: 372-cara-memasak-ayam-geprek-yang-lezat-dan-mudah-dibuat
date: 2021-06-01T06:12:37.314Z
image: https://img-global.cpcdn.com/recipes/db0f91ee0635e942/680x482cq70/ayam-geprek-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/db0f91ee0635e942/680x482cq70/ayam-geprek-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/db0f91ee0635e942/680x482cq70/ayam-geprek-foto-resep-utama.jpg
author: Mike Little
ratingvalue: 4.1
reviewcount: 15
recipeingredient:
- "1/2 kg Ayam Segar"
- "1 buah Jeruk Nipis"
- "1 sdt ketumbar"
- "1 sdt merica"
- "5 siung bawang putih"
- "10 buah cabai segar"
- "2 sdt kaldu jamur"
- "2 bungkus tepung Bumbu Sajiku"
- "secukupnya Air"
recipeinstructions:
- "Cuci ayam hingga bersih. Lalu masukkan perasan jeruk nipis. Aduk2 hingga bau amisnya hilang, lalu cuci kembali"
- "Haluskan 4 siung bawang putih &amp; ketumbar, lalu lumuri ke ayam yg sdh dibersihkan. Tambahkan merica &amp; kaldu jamur. Diamkan selama 1 jam hingga bumbunya meresap"
- "Siapkan 2 mangkuk untuk tepung bumbu Sajiku. Mangkuk pertama adonan kental, dan mangkuk kedua adonan kering (tanpa air)"
- "Setelah bumbu ayam meresap, celupkan ayam ke dalam adonan kental, lalu angkat dan masukkan ke dalam adonan kering (tepung terigu). Bolak balik hingga semua ayam terselimuti oleh tepung terigu"
- "Masukkan ayam ke dlm minyak yg sudah sedikit panas, masak dengan menggunakan api kecil agar matang sampai dalam"
- "Selanjutnya kita buat sambal geprek andalan"
- "Siapkan cabai dan 1 siung bawang putih, tambahkan Penyedap Rasa (sesuai selera) lalu ulek kasar. Setelah itu siram dengan minyak panas"
- "Angkat ayam, lalu tiriskan. Setelah itu geprek ayam tsb dan langsung baluri dengan sambal diatasnya"
- "Ayam geprek siap dihidangkan"
categories:
- Resep
tags:
- ayam
- geprek

katakunci: ayam geprek 
nutrition: 242 calories
recipecuisine: Indonesian
preptime: "PT20M"
cooktime: "PT47M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam Geprek](https://img-global.cpcdn.com/recipes/db0f91ee0635e942/680x482cq70/ayam-geprek-foto-resep-utama.jpg)

Sebagai seorang orang tua, menyuguhkan hidangan mantab kepada keluarga adalah hal yang membahagiakan untuk kita sendiri. Kewajiban seorang  wanita bukan cuma mengurus rumah saja, tetapi anda juga harus memastikan keperluan gizi terpenuhi dan santapan yang disantap keluarga tercinta wajib nikmat.

Di zaman  sekarang, anda sebenarnya bisa memesan panganan jadi tanpa harus susah mengolahnya dulu. Tapi banyak juga orang yang selalu mau memberikan yang terbaik bagi orang tercintanya. Sebab, menyajikan masakan sendiri jauh lebih higienis dan kita pun bisa menyesuaikan masakan tersebut sesuai dengan makanan kesukaan keluarga. 



Apakah anda adalah seorang penyuka ayam geprek?. Asal kamu tahu, ayam geprek merupakan sajian khas di Nusantara yang kini disenangi oleh banyak orang dari berbagai tempat di Nusantara. Kita bisa memasak ayam geprek hasil sendiri di rumah dan boleh dijadikan santapan favorit di akhir pekan.

Kamu jangan bingung untuk menyantap ayam geprek, sebab ayam geprek sangat mudah untuk ditemukan dan juga kalian pun boleh membuatnya sendiri di rumah. ayam geprek boleh dibuat dengan bermacam cara. Kini pun sudah banyak sekali cara modern yang menjadikan ayam geprek semakin nikmat.

Resep ayam geprek juga mudah dibuat, lho. Anda tidak perlu ribet-ribet untuk membeli ayam geprek, sebab Kamu dapat menghidangkan ditempatmu. Untuk Kamu yang mau mencobanya, di bawah ini adalah cara untuk menyajikan ayam geprek yang nikamat yang mampu Anda hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Ayam Geprek:

1. Siapkan 1/2 kg Ayam Segar
1. Gunakan 1 buah Jeruk Nipis
1. Sediakan 1 sdt ketumbar
1. Gunakan 1 sdt merica
1. Siapkan 5 siung bawang putih
1. Gunakan 10 buah cabai segar
1. Siapkan 2 sdt kaldu jamur
1. Sediakan 2 bungkus tepung Bumbu Sajiku
1. Ambil secukupnya Air




<!--inarticleads2-->

##### Cara menyiapkan Ayam Geprek:

1. Cuci ayam hingga bersih. Lalu masukkan perasan jeruk nipis. Aduk2 hingga bau amisnya hilang, lalu cuci kembali
1. Haluskan 4 siung bawang putih &amp; ketumbar, lalu lumuri ke ayam yg sdh dibersihkan. Tambahkan merica &amp; kaldu jamur. Diamkan selama 1 jam hingga bumbunya meresap
1. Siapkan 2 mangkuk untuk tepung bumbu Sajiku. Mangkuk pertama adonan kental, dan mangkuk kedua adonan kering (tanpa air)
1. Setelah bumbu ayam meresap, celupkan ayam ke dalam adonan kental, lalu angkat dan masukkan ke dalam adonan kering (tepung terigu). Bolak balik hingga semua ayam terselimuti oleh tepung terigu
1. Masukkan ayam ke dlm minyak yg sudah sedikit panas, masak dengan menggunakan api kecil agar matang sampai dalam
1. Selanjutnya kita buat sambal geprek andalan
1. Siapkan cabai dan 1 siung bawang putih, tambahkan Penyedap Rasa (sesuai selera) lalu ulek kasar. Setelah itu siram dengan minyak panas
1. Angkat ayam, lalu tiriskan. Setelah itu geprek ayam tsb dan langsung baluri dengan sambal diatasnya
1. Ayam geprek siap dihidangkan




Wah ternyata resep ayam geprek yang nikamt tidak ribet ini gampang sekali ya! Semua orang bisa membuatnya. Cara Membuat ayam geprek Sangat cocok sekali buat kita yang baru akan belajar memasak maupun untuk kamu yang telah jago memasak.

Apakah kamu mau mulai mencoba bikin resep ayam geprek nikmat tidak rumit ini? Kalau mau, ayo kamu segera buruan siapin peralatan dan bahan-bahannya, maka buat deh Resep ayam geprek yang enak dan simple ini. Sangat mudah kan. 

Maka dari itu, daripada anda diam saja, yuk kita langsung buat resep ayam geprek ini. Pasti kamu tak akan nyesel sudah membuat resep ayam geprek nikmat simple ini! Selamat berkreasi dengan resep ayam geprek mantab tidak ribet ini di tempat tinggal sendiri,oke!.

