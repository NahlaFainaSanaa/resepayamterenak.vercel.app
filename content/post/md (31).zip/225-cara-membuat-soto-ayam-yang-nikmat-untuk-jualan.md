---
description: "Cara membuat Soto Ayam yang nikmat Untuk Jualan"
title: "Cara membuat Soto Ayam yang nikmat Untuk Jualan"
slug: 225-cara-membuat-soto-ayam-yang-nikmat-untuk-jualan
date: 2021-02-21T05:49:41.132Z
image: https://img-global.cpcdn.com/recipes/a17fae7401ff89c3/680x482cq70/soto-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a17fae7401ff89c3/680x482cq70/soto-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a17fae7401ff89c3/680x482cq70/soto-ayam-foto-resep-utama.jpg
author: Samuel Cole
ratingvalue: 3.4
reviewcount: 14
recipeingredient:
- "1 ekor Ayam belah jadi 4"
- "1500 ml Air"
- "2 batang Serai memarkan"
- "4 lembar Daun Jeruk"
- "2 cm Lengkuas memarkan"
- "1/4 sdt Lada bubuk"
- "Secukupnya Gula garam dan kaldu bubuk"
- " Bumbu Halus"
- "10 siung Bawang putih"
- "5 siung Bawang merah"
- "2 cm Jahe"
- "2 cm Kunyit"
- "4 butir Kemiri"
- " Pelengkap"
- "3 butir Telur rebu potong  potong"
- "4 lembar Kol iris halus"
- "100 gr Tauge"
- "2 bh Tomat potongpotong"
- "Beberapa lembar daun seledri rajang halus"
- "Secukupnya Bawang Merah goreng untuk taburan"
- "Secukupnya jeruk nipis untuk kecuran"
- " Sambal rebus cabai rawit haluskan dan beri tambahan gula dan garam secukupnya"
recipeinstructions:
- "Bersihkan ayam lalu rebus ayam sampai keluar kaldu dan ayam agak empuk. Haluskan bumbu dan tumis sampai harum, masukkan serai, daun jeruk, lengkuas dan lada bubuk, aduk-aduk sebentar. Masukkan bumbu tumis ke dalam rebusan ayam. Tambahkan gula, garam dan kaldu bubuk. Kecilkan api masak kira-kira 15 menit sampai bumbu meresap. Cicipi dan koreksi rasa."
- "Setelah ayam empuk, angkat dan goreng sebentar dengan sedikit minyak sampai ayam agak kecoklatan lalu suwir-suwir atau iris tipi sesuai selera. Siapkan pelengkap soto."
- "Hidangkan soto ayam dengan taburan kol rebus, irisan tomat, tauge, bawang goreng, telur rebus dan terakhir beri perasan jeruk nipis."
categories:
- Resep
tags:
- soto
- ayam

katakunci: soto ayam 
nutrition: 256 calories
recipecuisine: Indonesian
preptime: "PT13M"
cooktime: "PT37M"
recipeyield: "4"
recipecategory: Lunch

---


![Soto Ayam](https://img-global.cpcdn.com/recipes/a17fae7401ff89c3/680x482cq70/soto-ayam-foto-resep-utama.jpg)

Apabila anda seorang ibu, mempersiapkan panganan sedap bagi keluarga tercinta adalah suatu hal yang sangat menyenangkan bagi kita sendiri. Tanggung jawab seorang ibu bukan hanya mengurus rumah saja, tetapi kamu juga wajib menyediakan kebutuhan nutrisi tercukupi dan juga olahan yang disantap orang tercinta mesti menggugah selera.

Di waktu  sekarang, kita memang mampu memesan masakan siap saji tanpa harus repot memasaknya lebih dulu. Namun ada juga orang yang memang mau menyajikan yang terbaik untuk orang yang dicintainya. Pasalnya, memasak yang dibuat sendiri jauh lebih bersih dan bisa menyesuaikan masakan tersebut sesuai selera orang tercinta. 



Apakah anda seorang penyuka soto ayam?. Asal kamu tahu, soto ayam adalah hidangan khas di Nusantara yang saat ini digemari oleh orang-orang dari berbagai tempat di Indonesia. Kita bisa membuat soto ayam kreasi sendiri di rumah dan boleh jadi camilan favoritmu di hari liburmu.

Kalian tak perlu bingung untuk menyantap soto ayam, karena soto ayam gampang untuk didapatkan dan anda pun bisa menghidangkannya sendiri di rumah. soto ayam dapat dimasak dengan bermacam cara. Saat ini telah banyak sekali cara modern yang menjadikan soto ayam semakin lebih mantap.

Resep soto ayam juga gampang untuk dibuat, lho. Kita tidak perlu capek-capek untuk membeli soto ayam, sebab Kita dapat menyajikan di rumah sendiri. Untuk Kita yang hendak membuatnya, dibawah ini merupakan cara untuk menyajikan soto ayam yang enak yang mampu Kita hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Soto Ayam:

1. Sediakan 1 ekor Ayam belah jadi 4
1. Ambil 1500 ml Air
1. Gunakan 2 batang Serai, memarkan
1. Gunakan 4 lembar Daun Jeruk
1. Sediakan 2 cm Lengkuas, memarkan
1. Sediakan 1/4 sdt Lada bubuk
1. Ambil Secukupnya Gula, garam dan kaldu bubuk
1. Sediakan  Bumbu Halus:
1. Sediakan 10 siung Bawang putih
1. Sediakan 5 siung Bawang merah
1. Gunakan 2 cm Jahe
1. Ambil 2 cm Kunyit
1. Ambil 4 butir Kemiri
1. Siapkan  Pelengkap:
1. Gunakan 3 butir Telur rebu, potong - potong
1. Gunakan 4 lembar Kol, iris halus
1. Siapkan 100 gr Tauge
1. Ambil 2 bh Tomat, potong-potong
1. Gunakan Beberapa lembar daun seledri, rajang halus
1. Ambil Secukupnya Bawang Merah goreng untuk taburan
1. Gunakan Secukupnya jeruk nipis untuk kecuran
1. Ambil  Sambal: (rebus cabai rawit, haluskan dan beri tambahan gula dan garam secukupnya)




<!--inarticleads2-->

##### Cara menyiapkan Soto Ayam:

1. Bersihkan ayam lalu rebus ayam sampai keluar kaldu dan ayam agak empuk. Haluskan bumbu dan tumis sampai harum, masukkan serai, daun jeruk, lengkuas dan lada bubuk, aduk-aduk sebentar. Masukkan bumbu tumis ke dalam rebusan ayam. Tambahkan gula, garam dan kaldu bubuk. Kecilkan api masak kira-kira 15 menit sampai bumbu meresap. Cicipi dan koreksi rasa.
1. Setelah ayam empuk, angkat dan goreng sebentar dengan sedikit minyak sampai ayam agak kecoklatan lalu suwir-suwir atau iris tipi sesuai selera. Siapkan pelengkap soto.
1. Hidangkan soto ayam dengan taburan kol rebus, irisan tomat, tauge, bawang goreng, telur rebus dan terakhir beri perasan jeruk nipis.




Wah ternyata cara buat soto ayam yang enak tidak rumit ini gampang sekali ya! Anda Semua bisa membuatnya. Resep soto ayam Cocok banget untuk kamu yang baru belajar memasak atau juga bagi kamu yang telah ahli dalam memasak.

Apakah kamu mau mulai mencoba bikin resep soto ayam nikmat tidak ribet ini? Kalau mau, yuk kita segera siapkan alat-alat dan bahan-bahannya, lantas bikin deh Resep soto ayam yang enak dan sederhana ini. Betul-betul mudah kan. 

Jadi, daripada kamu berfikir lama-lama, maka kita langsung saja buat resep soto ayam ini. Dijamin anda tiidak akan nyesel membuat resep soto ayam nikmat simple ini! Selamat berkreasi dengan resep soto ayam enak tidak ribet ini di tempat tinggal kalian sendiri,oke!.

