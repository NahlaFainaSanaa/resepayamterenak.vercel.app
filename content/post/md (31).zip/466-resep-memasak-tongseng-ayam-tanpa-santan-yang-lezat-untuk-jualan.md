---
description: "Resep memasak Tongseng Ayam Tanpa Santan yang lezat Untuk Jualan"
title: "Resep memasak Tongseng Ayam Tanpa Santan yang lezat Untuk Jualan"
slug: 466-resep-memasak-tongseng-ayam-tanpa-santan-yang-lezat-untuk-jualan
date: 2021-02-17T09:41:46.645Z
image: https://img-global.cpcdn.com/recipes/b6d7886a70be2279/680x482cq70/tongseng-ayam-tanpa-santan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b6d7886a70be2279/680x482cq70/tongseng-ayam-tanpa-santan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b6d7886a70be2279/680x482cq70/tongseng-ayam-tanpa-santan-foto-resep-utama.jpg
author: Nancy Cruz
ratingvalue: 4.6
reviewcount: 7
recipeingredient:
- "500 gram ayam negri potong2"
- "150 gram daun kol buang tulang daunnya potong kasar"
- "1 lembar daun salam"
- "1 sdm air asam"
- "1 batang serai memarkan"
- "5 sdm kecap manis"
- "1 buah tomat merah potong2"
- "2 buah tomat ijo potong2"
- "20 buah cabai rawit sy skip"
- "6 buah bawang merah iris tipis"
- " Minyak utk menumis"
- " Bumbu halus "
- "4 siung bawang putih"
- "1 sdt merica bulat"
- "1 sdt ketumbar sangrai"
- "1/2 sdt jintan sangrai"
- "1 sdt jahe"
- "1 cm kunyit bakar"
- "1 1/2 lengkuas cincang"
recipeinstructions:
- "Tumis bawang merah hingga layu dan harum. Masukkan bumbu halus, daun salam, dan serai. Aduk. Tambahkan ayam potong, aduk sampai berubah warna. Sisihkan."
- "Didihkan 500 ml air, masukkan tumisan ayam, kecap manis, dan air asam."
- "Masak sampai ayam lunak. Jika ayam belum empuk, boleh tambahkan air panas secukupnya."
- "Setelah ayam cukup empuk, masukkan tomat, cabai rawit, kol, garam, dan gula sesuai selera. Angkat. Sajikan selagi hangat dan nikmati dengan nasi putih hangat 😋😋"
categories:
- Resep
tags:
- tongseng
- ayam
- tanpa

katakunci: tongseng ayam tanpa 
nutrition: 164 calories
recipecuisine: Indonesian
preptime: "PT24M"
cooktime: "PT31M"
recipeyield: "3"
recipecategory: Dessert

---


![Tongseng Ayam Tanpa Santan](https://img-global.cpcdn.com/recipes/b6d7886a70be2279/680x482cq70/tongseng-ayam-tanpa-santan-foto-resep-utama.jpg)

Selaku seorang wanita, menyediakan olahan lezat bagi orang tercinta merupakan hal yang menggembirakan untuk kita sendiri. Tanggung jawab seorang ibu Tidak cuman mengatur rumah saja, namun anda juga wajib menyediakan kebutuhan nutrisi terpenuhi dan olahan yang dikonsumsi orang tercinta mesti lezat.

Di masa  saat ini, kita sebenarnya mampu mengorder panganan yang sudah jadi tidak harus ribet mengolahnya terlebih dahulu. Namun banyak juga lho orang yang selalu mau memberikan makanan yang terenak bagi orang yang dicintainya. Lantaran, memasak yang dibuat sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan makanan tersebut berdasarkan masakan kesukaan keluarga tercinta. 



Mungkinkah kamu salah satu penggemar tongseng ayam tanpa santan?. Tahukah kamu, tongseng ayam tanpa santan merupakan hidangan khas di Nusantara yang kini disukai oleh kebanyakan orang dari berbagai wilayah di Indonesia. Anda bisa memasak tongseng ayam tanpa santan olahan sendiri di rumahmu dan dapat dijadikan camilan favoritmu di akhir pekanmu.

Kamu tak perlu bingung jika kamu ingin memakan tongseng ayam tanpa santan, karena tongseng ayam tanpa santan tidak sukar untuk dicari dan juga kita pun boleh membuatnya sendiri di tempatmu. tongseng ayam tanpa santan bisa diolah memalui beragam cara. Sekarang telah banyak sekali cara kekinian yang menjadikan tongseng ayam tanpa santan semakin enak.

Resep tongseng ayam tanpa santan juga gampang sekali untuk dibikin, lho. Anda jangan repot-repot untuk memesan tongseng ayam tanpa santan, lantaran Kalian bisa membuatnya sendiri di rumah. Bagi Kita yang ingin menyajikannya, di bawah ini adalah cara membuat tongseng ayam tanpa santan yang mantab yang bisa Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Tongseng Ayam Tanpa Santan:

1. Ambil 500 gram ayam negri, potong2
1. Siapkan 150 gram daun kol, buang tulang daunnya, potong kasar
1. Siapkan 1 lembar daun salam
1. Gunakan 1 sdm air asam
1. Ambil 1 batang serai, memarkan
1. Siapkan 5 sdm kecap manis
1. Siapkan 1 buah tomat merah, potong2
1. Siapkan 2 buah tomat ijo, potong2
1. Sediakan 20 buah cabai rawit (sy skip)
1. Siapkan 6 buah bawang merah, iris tipis
1. Ambil  Minyak utk menumis
1. Gunakan  Bumbu halus :
1. Ambil 4 siung bawang putih
1. Sediakan 1 sdt merica bulat
1. Siapkan 1 sdt ketumbar, sangrai
1. Gunakan 1/2 sdt jintan, sangrai
1. Gunakan 1 sdt jahe
1. Gunakan 1 cm kunyit, bakar
1. Sediakan 1 1/2 lengkuas, cincang




<!--inarticleads2-->

##### Cara membuat Tongseng Ayam Tanpa Santan:

1. Tumis bawang merah hingga layu dan harum. Masukkan bumbu halus, daun salam, dan serai. Aduk. Tambahkan ayam potong, aduk sampai berubah warna. Sisihkan.
1. Didihkan 500 ml air, masukkan tumisan ayam, kecap manis, dan air asam.
1. Masak sampai ayam lunak. Jika ayam belum empuk, boleh tambahkan air panas secukupnya.
1. Setelah ayam cukup empuk, masukkan tomat, cabai rawit, kol, garam, dan gula sesuai selera. Angkat. Sajikan selagi hangat dan nikmati dengan nasi putih hangat 😋😋




Ternyata cara buat tongseng ayam tanpa santan yang nikamt simple ini mudah sekali ya! Kalian semua dapat memasaknya. Cara buat tongseng ayam tanpa santan Sangat sesuai banget buat anda yang sedang belajar memasak atau juga bagi anda yang sudah jago memasak.

Tertarik untuk mulai mencoba membuat resep tongseng ayam tanpa santan enak tidak ribet ini? Kalau kalian ingin, ayo kamu segera buruan siapin alat dan bahannya, kemudian bikin deh Resep tongseng ayam tanpa santan yang nikmat dan sederhana ini. Sungguh taidak sulit kan. 

Maka, daripada kalian diam saja, ayo kita langsung saja sajikan resep tongseng ayam tanpa santan ini. Pasti anda gak akan menyesal sudah membuat resep tongseng ayam tanpa santan mantab tidak rumit ini! Selamat mencoba dengan resep tongseng ayam tanpa santan nikmat tidak ribet ini di tempat tinggal sendiri,oke!.

