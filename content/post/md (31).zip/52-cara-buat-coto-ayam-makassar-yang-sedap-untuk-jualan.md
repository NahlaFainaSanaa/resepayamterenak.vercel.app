---
description: "Cara buat Coto Ayam Makassar yang sedap Untuk Jualan"
title: "Cara buat Coto Ayam Makassar yang sedap Untuk Jualan"
slug: 52-cara-buat-coto-ayam-makassar-yang-sedap-untuk-jualan
date: 2021-05-30T01:47:02.802Z
image: https://img-global.cpcdn.com/recipes/9822600f8ca7213d/680x482cq70/coto-ayam-makassar-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9822600f8ca7213d/680x482cq70/coto-ayam-makassar-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9822600f8ca7213d/680x482cq70/coto-ayam-makassar-foto-resep-utama.jpg
author: Jared Padilla
ratingvalue: 4.8
reviewcount: 3
recipeingredient:
- "500 gram daging ayam"
- "2 helai daun salam"
- "2 helai daun jeruk"
- "Secukupnya garam"
- "Secukupnya Kaldu ayam"
- "1/2 sdt merica bubuk"
- "1 sdt ketumbar bubuk"
- "1/2 sdt pala bubuk"
- "1/2 sdt Jintan bubuk saya skip"
- "2 sdm air asam jawa"
- "2 sdm gula merah bisa pakai gula pasir"
- " Minyak untuk menumis bumbu"
- "2 liter Air bisa pakai air cucian beras"
- " Bumbu halus"
- "150 gr kacang tanah sangrai"
- "6 siung bawang merah"
- "4 siung bawang putih"
- "2 btang serai potong potong"
- "Seruas jahe"
- "Seruas lengkuas"
- "Seruas kunyit boleh di skip"
- " Air"
- " Bumbu pelengkap"
- " Daun bawang potong potong"
- " Bawang goreng"
- " Jeruk nipis"
- " Sambel"
- " Kecap"
recipeinstructions:
- "Siapkan bumbu, Cuci bersih ayam, potong kotak kotak atau sesuai selera, masak sampai dagingnya empuk."
- "Sangrai kacang tanah sampai matang. Kemudian haluskan bersama bumbu halus."
- "Panaskan minyak kemudian tumis bumbu halus, masukkan daun salam, daun jeruk, merica bubuk, ketumbar, pala dan jintan. Tumis sampai minyak tanak."
- "Masukkan bumbu kedalam rebusan ayam, beri garam, gula, kaldu bubuk dan air asam. Aduk rata. Masak sampai kuah mengental. Cek rasa"
- "Sajikan bersama bumbu pelengkap."
categories:
- Resep
tags:
- coto
- ayam
- makassar

katakunci: coto ayam makassar 
nutrition: 272 calories
recipecuisine: Indonesian
preptime: "PT23M"
cooktime: "PT49M"
recipeyield: "2"
recipecategory: Dinner

---


![Coto Ayam Makassar](https://img-global.cpcdn.com/recipes/9822600f8ca7213d/680x482cq70/coto-ayam-makassar-foto-resep-utama.jpg)

Selaku seorang istri, mempersiapkan santapan enak kepada keluarga adalah hal yang menyenangkan bagi anda sendiri. Kewajiban seorang  wanita Tidak sekedar mengerjakan pekerjaan rumah saja, tetapi anda pun wajib memastikan keperluan gizi tercukupi dan juga masakan yang disantap anak-anak mesti lezat.

Di zaman  saat ini, kalian memang dapat membeli panganan instan meski tidak harus ribet membuatnya lebih dulu. Namun ada juga lho orang yang memang mau memberikan yang terenak bagi orang yang dicintainya. Karena, memasak sendiri jauh lebih higienis dan kita pun bisa menyesuaikan hidangan tersebut berdasarkan makanan kesukaan keluarga tercinta. 



Apakah anda merupakan seorang penyuka coto ayam makassar?. Tahukah kamu, coto ayam makassar adalah hidangan khas di Nusantara yang sekarang disukai oleh setiap orang dari berbagai tempat di Nusantara. Anda dapat membuat coto ayam makassar buatan sendiri di rumahmu dan boleh jadi hidangan kegemaranmu di akhir pekanmu.

Kita tidak perlu bingung untuk menyantap coto ayam makassar, sebab coto ayam makassar sangat mudah untuk ditemukan dan kita pun bisa memasaknya sendiri di tempatmu. coto ayam makassar dapat diolah lewat beraneka cara. Saat ini telah banyak resep modern yang menjadikan coto ayam makassar semakin nikmat.

Resep coto ayam makassar juga sangat mudah dihidangkan, lho. Kamu tidak usah ribet-ribet untuk memesan coto ayam makassar, sebab Kita dapat membuatnya di rumahmu. Bagi Kalian yang mau menyajikannya, dibawah ini merupakan cara membuat coto ayam makassar yang lezat yang mampu Anda coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Coto Ayam Makassar:

1. Sediakan 500 gram daging ayam
1. Gunakan 2 helai daun salam
1. Ambil 2 helai daun jeruk
1. Ambil Secukupnya garam
1. Sediakan Secukupnya Kaldu ayam
1. Ambil 1/2 sdt merica bubuk
1. Ambil 1 sdt ketumbar bubuk
1. Siapkan 1/2 sdt pala bubuk
1. Gunakan 1/2 sdt Jintan bubuk, saya skip
1. Gunakan 2 sdm air asam jawa
1. Gunakan 2 sdm gula merah, bisa pakai gula pasir
1. Gunakan  Minyak untuk menumis bumbu
1. Ambil 2 liter Air, bisa pakai air cucian beras
1. Sediakan  Bumbu halus
1. Siapkan 150 gr kacang tanah, sangrai
1. Siapkan 6 siung bawang merah
1. Siapkan 4 siung bawang putih
1. Gunakan 2 btang serai, potong potong
1. Gunakan Seruas jahe
1. Sediakan Seruas lengkuas
1. Siapkan Seruas kunyit, boleh di skip
1. Gunakan  Air
1. Siapkan  Bumbu pelengkap
1. Ambil  Daun bawang, potong potong
1. Ambil  Bawang goreng
1. Siapkan  Jeruk nipis
1. Gunakan  Sambel
1. Ambil  Kecap




<!--inarticleads2-->

##### Langkah-langkah membuat Coto Ayam Makassar:

1. Siapkan bumbu, Cuci bersih ayam, potong kotak kotak atau sesuai selera, masak sampai dagingnya empuk.
1. Sangrai kacang tanah sampai matang. Kemudian haluskan bersama bumbu halus.
1. Panaskan minyak kemudian tumis bumbu halus, masukkan daun salam, daun jeruk, merica bubuk, ketumbar, pala dan jintan. Tumis sampai minyak tanak.
1. Masukkan bumbu kedalam rebusan ayam, beri garam, gula, kaldu bubuk dan air asam. Aduk rata. Masak sampai kuah mengental. Cek rasa
1. Sajikan bersama bumbu pelengkap.




Ternyata resep coto ayam makassar yang mantab tidak rumit ini enteng sekali ya! Kita semua bisa menghidangkannya. Cara Membuat coto ayam makassar Sangat sesuai sekali untuk kalian yang baru akan belajar memasak maupun bagi kalian yang telah jago memasak.

Tertarik untuk mencoba membuat resep coto ayam makassar lezat tidak rumit ini? Kalau anda ingin, yuk kita segera buruan siapkan peralatan dan bahan-bahannya, maka bikin deh Resep coto ayam makassar yang nikmat dan tidak rumit ini. Sangat taidak sulit kan. 

Jadi, ketimbang anda berfikir lama-lama, ayo kita langsung saja sajikan resep coto ayam makassar ini. Pasti kalian gak akan nyesel sudah bikin resep coto ayam makassar enak tidak ribet ini! Selamat mencoba dengan resep coto ayam makassar mantab sederhana ini di rumah kalian sendiri,oke!.

