---
description: "Cara memasak Ayam bakar solo Sederhana Untuk Jualan"
title: "Cara memasak Ayam bakar solo Sederhana Untuk Jualan"
slug: 318-cara-memasak-ayam-bakar-solo-sederhana-untuk-jualan
date: 2021-01-12T09:21:38.414Z
image: https://img-global.cpcdn.com/recipes/f6f8fcca6d5e85d8/680x482cq70/ayam-bakar-solo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f6f8fcca6d5e85d8/680x482cq70/ayam-bakar-solo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f6f8fcca6d5e85d8/680x482cq70/ayam-bakar-solo-foto-resep-utama.jpg
author: Carlos Ryan
ratingvalue: 5
reviewcount: 7
recipeingredient:
- "1/2 ekor ayam"
- "2 lembar Daun salam"
- "1 batang Serai"
- "1 sdt Garam"
- "1 sdt Kaldu bubuk"
- "2 sdm Gula merah"
- "2 sdm Kecap manis"
- " Bumbu yang dihaluskan"
- "7 siung Bawang merah"
- "3 siung Bawang putih"
- "2 buah Cabe merah besar"
- "2 buah Kemiri"
- "1/2 cm Jahe"
- "1/2 cm Kunyit"
- "2 sdm Margarin"
- "secukupnya Air"
recipeinstructions:
- "Siapkan bumbu halus nya kemudian jangan lupa bersihkan terlebih dahulu ayamnya cuci bersih dan peras dengan jeruk nipis"
- "Setelah dihaluskan ditumis dengan sedikit minyak sampai wangi tambahkan gula merah, garam, kaldu bubuk dan juga serai serta daun salam"
- "Setelah bumbu masukkan ayam yang sudah dibersihkan aduk-aduk sampai rata kemudian tambahkan air bisa juga diganti dengan air kelapa agar lebih sedap tapi aku disini menggunakan air matang saja"
- "Setelah itu tambahkan pula kecap manis kemudian masak sambil sesekali diaduk dan ditutup agar bumbu meresap. Masak ayam sampai bumbunya meresap dan airnya menyusut. Bumbunya juga mengental"
- "Siapkan telepon panaskan. Siapkan pula ayam yang sudah di ungkep bumbu tadi tambahkan margarin atau minyak goreng sesuai selera panggang di atas teflon sambil sesekali dibolak-balik agar tidak gosong dan sambil juga diolesi sisa bumbunya tadi yang telah dicampur margarin, panggang sampai matang."
- "Ayam bakar siap dihidangkan ❤️"
categories:
- Resep
tags:
- ayam
- bakar
- solo

katakunci: ayam bakar solo 
nutrition: 283 calories
recipecuisine: Indonesian
preptime: "PT31M"
cooktime: "PT51M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam bakar solo](https://img-global.cpcdn.com/recipes/f6f8fcca6d5e85d8/680x482cq70/ayam-bakar-solo-foto-resep-utama.jpg)

Jika kalian seorang orang tua, menyajikan hidangan mantab kepada orang tercinta merupakan hal yang menggembirakan untuk anda sendiri. Kewajiban seorang ibu bukan hanya mengerjakan pekerjaan rumah saja, namun kamu juga harus menyediakan kebutuhan gizi terpenuhi dan santapan yang dikonsumsi keluarga tercinta mesti sedap.

Di zaman  sekarang, kamu memang dapat mengorder masakan yang sudah jadi tanpa harus capek memasaknya dahulu. Tapi banyak juga lho orang yang memang mau menghidangkan yang terlezat untuk orang yang dicintainya. Karena, memasak yang diolah sendiri jauh lebih bersih dan bisa menyesuaikan hidangan tersebut sesuai makanan kesukaan keluarga. 



Apakah anda adalah salah satu penggemar ayam bakar solo?. Asal kamu tahu, ayam bakar solo adalah hidangan khas di Indonesia yang sekarang digemari oleh kebanyakan orang dari berbagai daerah di Nusantara. Kita dapat menghidangkan ayam bakar solo hasil sendiri di rumah dan boleh jadi hidangan kesenanganmu di akhir pekan.

Kita jangan bingung untuk menyantap ayam bakar solo, lantaran ayam bakar solo tidak sukar untuk dicari dan juga anda pun dapat mengolahnya sendiri di tempatmu. ayam bakar solo boleh dibuat dengan bermacam cara. Kini pun sudah banyak resep kekinian yang menjadikan ayam bakar solo semakin lebih lezat.

Resep ayam bakar solo pun gampang dihidangkan, lho. Kamu tidak perlu repot-repot untuk memesan ayam bakar solo, sebab Anda dapat menghidangkan di rumahmu. Bagi Kalian yang ingin menghidangkannya, di bawah ini adalah resep membuat ayam bakar solo yang enak yang mampu Kalian coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Ayam bakar solo:

1. Sediakan 1/2 ekor ayam
1. Gunakan 2 lembar Daun salam
1. Ambil 1 batang Serai
1. Gunakan 1 sdt Garam
1. Sediakan 1 sdt Kaldu bubuk
1. Gunakan 2 sdm Gula merah
1. Ambil 2 sdm Kecap manis
1. Siapkan  Bumbu yang dihaluskan
1. Ambil 7 siung Bawang merah
1. Gunakan 3 siung Bawang putih
1. Gunakan 2 buah Cabe merah besar
1. Gunakan 2 buah Kemiri
1. Gunakan 1/2 cm Jahe
1. Siapkan 1/2 cm Kunyit
1. Siapkan 2 sdm Margarin
1. Siapkan secukupnya Air




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam bakar solo:

1. Siapkan bumbu halus nya kemudian jangan lupa bersihkan terlebih dahulu ayamnya cuci bersih dan peras dengan jeruk nipis
<img src="https://img-global.cpcdn.com/steps/e404dec5119d39ba/160x128cq70/ayam-bakar-solo-langkah-memasak-1-foto.jpg" alt="Ayam bakar solo">1. Setelah dihaluskan ditumis dengan sedikit minyak sampai wangi tambahkan gula merah, garam, kaldu bubuk dan juga serai serta daun salam
1. Setelah bumbu masukkan ayam yang sudah dibersihkan aduk-aduk sampai rata kemudian tambahkan air bisa juga diganti dengan air kelapa agar lebih sedap tapi aku disini menggunakan air matang saja
1. Setelah itu tambahkan pula kecap manis kemudian masak sambil sesekali diaduk dan ditutup agar bumbu meresap. Masak ayam sampai bumbunya meresap dan airnya menyusut. Bumbunya juga mengental
1. Siapkan telepon panaskan. Siapkan pula ayam yang sudah di ungkep bumbu tadi tambahkan margarin atau minyak goreng sesuai selera panggang di atas teflon sambil sesekali dibolak-balik agar tidak gosong dan sambil juga diolesi sisa bumbunya tadi yang telah dicampur margarin, panggang sampai matang.
1. Ayam bakar siap dihidangkan ❤️




Ternyata resep ayam bakar solo yang mantab tidak ribet ini mudah banget ya! Kita semua bisa memasaknya. Cara buat ayam bakar solo Sangat cocok banget buat kamu yang baru mau belajar memasak ataupun juga bagi kamu yang telah hebat dalam memasak.

Tertarik untuk mencoba membikin resep ayam bakar solo enak tidak rumit ini? Kalau tertarik, mending kamu segera siapkan alat-alat dan bahannya, kemudian bikin deh Resep ayam bakar solo yang mantab dan tidak rumit ini. Betul-betul gampang kan. 

Jadi, ketimbang kamu berfikir lama-lama, ayo kita langsung saja hidangkan resep ayam bakar solo ini. Dijamin anda tak akan menyesal sudah membuat resep ayam bakar solo nikmat tidak ribet ini! Selamat berkreasi dengan resep ayam bakar solo mantab sederhana ini di rumah kalian sendiri,oke!.

