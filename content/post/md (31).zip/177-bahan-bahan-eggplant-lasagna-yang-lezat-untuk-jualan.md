---
description: "Bahan-bahan Eggplant Lasagna yang lezat Untuk Jualan"
title: "Bahan-bahan Eggplant Lasagna yang lezat Untuk Jualan"
slug: 177-bahan-bahan-eggplant-lasagna-yang-lezat-untuk-jualan
date: 2021-05-10T00:53:08.181Z
image: https://img-global.cpcdn.com/recipes/afec631ccd3b08cf/680x482cq70/eggplant-lasagna-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/afec631ccd3b08cf/680x482cq70/eggplant-lasagna-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/afec631ccd3b08cf/680x482cq70/eggplant-lasagna-foto-resep-utama.jpg
author: Lester Gonzales
ratingvalue: 3.9
reviewcount: 6
recipeingredient:
- "7-8 buah terong ungu ukuran sedang cuci bersih iris2 tipis vertikal"
- "6-7 buah jamur champignon segar cuci bersih iris2 tipis vertikal"
- "250 gr mozzarella cheese iris2 tipis vertikal"
- "Secukupnya bubuk Parmesan cheese"
- " Marinara Sauce"
- "15 buah tomat ukuran sedang cuci bersih iris2 kecil blender kasar"
- "1 buah bawang bombay kupas cuci cincang halus"
- "3 buah bawang putih kupas cuci cincang halus"
- "3 buah cabe rawit cuci cincang tipis"
- "Secukupnya Dried thyme"
- "Secukupnya dried basil"
- "Secukupnya Dried parsley"
- "Secukupnya Dried rosemary"
- "Secukupnya pala bubuk"
- "Secukupnya Bubuk black pepper"
- "secukupnya Kaldu sapi bubuk saya pakai pura"
- "Secukupnya garam"
- "secukupnya Gula"
- "Secukupnya minyak untuk menumis"
- " Layer Daging Tumis"
- "450 gr daging cacah"
- "Secukupnya pala bubuk"
- "Secukupnya garam"
- "Secukupnya minyak untuk menumis"
- " White Ricotta Sauce"
- "250 gr Ricotta cheese"
- "1 butir telur ayam"
- "Secukupnya dried thyme"
- "Secukupnya pala bubuk"
recipeinstructions:
- "Tata terong di atas loyang. Taburi dengan sejumput garam secara merata. Diamkan 30 menit untuk masing2 sisinya. Panaskan oven dengan api bawah 180 derajat celcius. Masukkan terong ke dalam oven, panggang kurleb 5-10 menit. Sisihkan."
- "Lanjutkan dengan membuat marinara sauce. Tumis bawang putih sampai harum, masukkan bawang bombay, tumis sampai kecoklatan. Masukkan cabai rawit. Tambahkan tomat hingga mendidih. Tambahkan dried thyme, dried parsley, dried basil, dried rosemary, pala, black pepper, kaldu sapi, garam dan gula. Cicipi, koreksi rasa. Lanjutkan merebus sauce dengan api kecil hingga air berkurang 1/3. Sisihkan."
- "Tumis daging cacah, tambahkan pala dan garam. Tambahkan 4 sendok sayur sauce marinara. Tumis hingga rata dan daging matang, sisihkan."
- "Lanjutkan dengan membuat white ricotta sauce. Campurkan ricotta cheese, telur dan tambahkan dried thyme dan bubuk pala. Aduk hingga merata. Sisihkan."
- "Siapkan pyrex ukuran sedang. Susun terong dengan merata di dasar pyrex. Layer dengan sauce marinara. Kemudian layer dengan daging tumisan. Kemudian susun jamur champignon secara merata diatas tumisan daging. Susun rapi mozarella cheese di atas jamur. Selanjutnya layer dengan white ricotta sauce diatasnya. Taburi parmesan cheese diatas sauce ricotta hingga merata. Ulangi proses layering hingga semua bahan habis. Tutup pyrex dengan aluminium foil."
- "Masukkan pyrex ke dalam oven yang sudah dipanaskan selama 15 menit dengan suhu api atas bawah 180 derajat. Panggang lasagna selama 45 menit, buka aluminium foil dan lanjutkan panggang selama 15 menit atau hingga lapisan ricotta sauce yg paling atas berwarna kecoklatan."
categories:
- Resep
tags:
- eggplant
- lasagna

katakunci: eggplant lasagna 
nutrition: 132 calories
recipecuisine: Indonesian
preptime: "PT16M"
cooktime: "PT45M"
recipeyield: "2"
recipecategory: Dessert

---


![Eggplant Lasagna](https://img-global.cpcdn.com/recipes/afec631ccd3b08cf/680x482cq70/eggplant-lasagna-foto-resep-utama.jpg)

Jika kita seorang orang tua, menyuguhkan hidangan enak bagi famili merupakan hal yang mengasyikan bagi kamu sendiri. Kewajiban seorang  wanita Tidak sekedar mengatur rumah saja, tetapi anda juga harus menyediakan keperluan gizi terpenuhi dan olahan yang disantap keluarga tercinta mesti nikmat.

Di masa  saat ini, kamu sebenarnya dapat memesan santapan praktis meski tidak harus repot mengolahnya lebih dulu. Namun banyak juga lho mereka yang selalu ingin memberikan yang terenak bagi keluarganya. Lantaran, menghidangkan masakan sendiri jauh lebih bersih dan kita pun bisa menyesuaikan masakan tersebut sesuai masakan kesukaan keluarga tercinta. 



Mungkinkah anda salah satu penikmat eggplant lasagna?. Tahukah kamu, eggplant lasagna adalah makanan khas di Nusantara yang saat ini disenangi oleh kebanyakan orang di hampir setiap wilayah di Nusantara. Kita bisa menyajikan eggplant lasagna sendiri di rumahmu dan dapat dijadikan santapan favoritmu di hari liburmu.

Kita jangan bingung jika kamu ingin menyantap eggplant lasagna, karena eggplant lasagna tidak sukar untuk ditemukan dan juga anda pun boleh mengolahnya sendiri di tempatmu. eggplant lasagna dapat dibuat lewat berbagai cara. Kini ada banyak sekali cara kekinian yang membuat eggplant lasagna semakin lezat.

Resep eggplant lasagna pun sangat mudah dibikin, lho. Kita jangan capek-capek untuk membeli eggplant lasagna, tetapi Anda bisa menghidangkan sendiri di rumah. Untuk Kalian yang mau membuatnya, inilah resep untuk menyajikan eggplant lasagna yang mantab yang bisa Kita coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Eggplant Lasagna:

1. Sediakan 7-8 buah terong ungu ukuran sedang, cuci bersih, iris2 tipis vertikal
1. Sediakan 6-7 buah jamur champignon segar, cuci bersih, iris2 tipis vertikal
1. Ambil 250 gr mozzarella cheese, iris2 tipis vertikal
1. Siapkan Secukupnya bubuk Parmesan cheese
1. Ambil  Marinara Sauce
1. Sediakan 15 buah tomat ukuran sedang, cuci bersih, iris2 kecil, blender kasar
1. Gunakan 1 buah bawang bombay, kupas, cuci, cincang halus
1. Sediakan 3 buah bawang putih, kupas, cuci, cincang halus
1. Sediakan 3 buah cabe rawit, cuci, cincang tipis
1. Siapkan Secukupnya Dried thyme
1. Ambil Secukupnya dried basil
1. Sediakan Secukupnya Dried parsley
1. Ambil Secukupnya Dried rosemary
1. Sediakan Secukupnya pala bubuk
1. Gunakan Secukupnya Bubuk black pepper
1. Siapkan secukupnya Kaldu sapi bubuk (saya pakai pura)
1. Sediakan Secukupnya garam
1. Siapkan secukupnya Gula
1. Siapkan Secukupnya minyak untuk menumis
1. Gunakan  Layer Daging Tumis
1. Ambil 450 gr daging cacah
1. Ambil Secukupnya pala bubuk
1. Gunakan Secukupnya garam
1. Sediakan Secukupnya minyak untuk menumis
1. Ambil  White Ricotta Sauce
1. Siapkan 250 gr Ricotta cheese
1. Siapkan 1 butir telur ayam
1. Sediakan Secukupnya dried thyme
1. Siapkan Secukupnya pala bubuk




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Eggplant Lasagna:

1. Tata terong di atas loyang. Taburi dengan sejumput garam secara merata. Diamkan 30 menit untuk masing2 sisinya. Panaskan oven dengan api bawah 180 derajat celcius. Masukkan terong ke dalam oven, panggang kurleb 5-10 menit. Sisihkan.
1. Lanjutkan dengan membuat marinara sauce. Tumis bawang putih sampai harum, masukkan bawang bombay, tumis sampai kecoklatan. Masukkan cabai rawit. Tambahkan tomat hingga mendidih. Tambahkan dried thyme, dried parsley, dried basil, dried rosemary, pala, black pepper, kaldu sapi, garam dan gula. Cicipi, koreksi rasa. Lanjutkan merebus sauce dengan api kecil hingga air berkurang 1/3. Sisihkan.
1. Tumis daging cacah, tambahkan pala dan garam. Tambahkan 4 sendok sayur sauce marinara. Tumis hingga rata dan daging matang, sisihkan.
1. Lanjutkan dengan membuat white ricotta sauce. Campurkan ricotta cheese, telur dan tambahkan dried thyme dan bubuk pala. Aduk hingga merata. Sisihkan.
1. Siapkan pyrex ukuran sedang. Susun terong dengan merata di dasar pyrex. Layer dengan sauce marinara. Kemudian layer dengan daging tumisan. Kemudian susun jamur champignon secara merata diatas tumisan daging. Susun rapi mozarella cheese di atas jamur. Selanjutnya layer dengan white ricotta sauce diatasnya. Taburi parmesan cheese diatas sauce ricotta hingga merata. Ulangi proses layering hingga semua bahan habis. Tutup pyrex dengan aluminium foil.
1. Masukkan pyrex ke dalam oven yang sudah dipanaskan selama 15 menit dengan suhu api atas bawah 180 derajat. Panggang lasagna selama 45 menit, buka aluminium foil dan lanjutkan panggang selama 15 menit atau hingga lapisan ricotta sauce yg paling atas berwarna kecoklatan.




Ternyata resep eggplant lasagna yang nikamt simple ini mudah banget ya! Kalian semua bisa mencobanya. Cara buat eggplant lasagna Sangat cocok banget buat kita yang baru mau belajar memasak maupun untuk anda yang telah lihai memasak.

Tertarik untuk mencoba membikin resep eggplant lasagna enak simple ini? Kalau kalian mau, ayo kamu segera buruan siapin alat dan bahan-bahannya, lantas bikin deh Resep eggplant lasagna yang nikmat dan tidak rumit ini. Sangat gampang kan. 

Oleh karena itu, daripada anda diam saja, maka kita langsung bikin resep eggplant lasagna ini. Pasti anda tiidak akan nyesel sudah buat resep eggplant lasagna lezat simple ini! Selamat mencoba dengan resep eggplant lasagna lezat tidak rumit ini di rumah kalian masing-masing,oke!.

