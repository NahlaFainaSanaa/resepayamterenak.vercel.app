---
description: "Resep memasak Coto Ayam Sederhana Untuk Jualan"
title: "Resep memasak Coto Ayam Sederhana Untuk Jualan"
slug: 46-resep-memasak-coto-ayam-sederhana-untuk-jualan
date: 2021-02-09T10:03:23.998Z
image: https://img-global.cpcdn.com/recipes/716ec121db3577be/680x482cq70/coto-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/716ec121db3577be/680x482cq70/coto-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/716ec121db3577be/680x482cq70/coto-ayam-foto-resep-utama.jpg
author: Cole Tran
ratingvalue: 4.4
reviewcount: 13
recipeingredient:
- "500 gr dada ayam"
- "4 buah ceker ayam"
- "1000 ml air"
- "50 gr kacang tanah sangrai"
- " Bumbu halus "
- "8 siung bawang merah"
- "4 siung bawang putih"
- "2 ruas jahe"
- "3 buah kemiri"
- "1 sdt ketumbar bubuk"
- "1 sdt lada bubuk"
- "2 sdt garam"
- "2 sdt gula pasir"
- "1/2 keping gula merah"
- "secukupnya Minyak goreng"
- " Bahan pelengkap "
- "2 blok kaldu ayam"
- "2 lembar daun salam"
- "3 lembar daun jeruk"
- "2 tangkai sereh"
- "1 tangkai daun bawang"
- "1 tangkai seledri"
- "3 buah kentang rebus"
- "7 buah cabe rawit merahsambal"
- "1 buah tomat"
- "1 buah jeruk nipis"
- "Secukupnya emping"
recipeinstructions:
- "Siapkan semua bahan yang akan digunakan"
- "Sangrai kacang kemudian uleg kasar, buang kulitnya."
- "Rebus kentang bersama cabe rawit hingga empuk. Rebus ayam, setelah empuk sisihkan kuah kaldunya. Goreng ayam kemudian suwir-suwir"
- "Haluskan bumbu, kemudian tumis hingga matang dan harum. Tambahkan kacang yang sudah disangrai. Aduk aduk merata."
- "Masukkan bumbu yang sudah ditumis kedalam kuah kaldu, tambahkan kaldu blok, koreksi rasa"
- "Siapkan mangkuk saji, isi dengan kentang rebus, tomat dan daun bawang serta seledri. Siram kuah, coto siap disajikan"
categories:
- Resep
tags:
- coto
- ayam

katakunci: coto ayam 
nutrition: 193 calories
recipecuisine: Indonesian
preptime: "PT15M"
cooktime: "PT39M"
recipeyield: "4"
recipecategory: Dessert

---


![Coto Ayam](https://img-global.cpcdn.com/recipes/716ec121db3577be/680x482cq70/coto-ayam-foto-resep-utama.jpg)

Selaku seorang ibu, menyediakan olahan enak buat keluarga adalah hal yang memuaskan bagi kamu sendiri. Peran seorang istri Tidak saja mengurus rumah saja, namun kamu pun harus memastikan kebutuhan gizi terpenuhi dan juga hidangan yang disantap keluarga tercinta harus nikmat.

Di waktu  sekarang, kita memang bisa mengorder masakan jadi meski tanpa harus ribet membuatnya lebih dulu. Tapi ada juga orang yang memang ingin memberikan yang terlezat bagi orang tercintanya. Lantaran, menghidangkan masakan yang dibuat sendiri jauh lebih higienis dan kita pun bisa menyesuaikan hidangan tersebut berdasarkan makanan kesukaan keluarga tercinta. 



Apakah anda salah satu penikmat coto ayam?. Tahukah kamu, coto ayam merupakan makanan khas di Indonesia yang saat ini disukai oleh kebanyakan orang dari hampir setiap tempat di Nusantara. Kita bisa memasak coto ayam hasil sendiri di rumah dan dapat dijadikan makanan kegemaranmu di hari libur.

Kamu tidak perlu bingung untuk memakan coto ayam, lantaran coto ayam tidak sukar untuk ditemukan dan kamu pun boleh mengolahnya sendiri di rumah. coto ayam boleh dimasak memalui beragam cara. Kini pun telah banyak cara modern yang menjadikan coto ayam semakin lebih enak.

Resep coto ayam juga gampang sekali dihidangkan, lho. Kamu tidak perlu repot-repot untuk memesan coto ayam, karena Kalian dapat membuatnya sendiri di rumah. Untuk Kalian yang akan membuatnya, berikut resep membuat coto ayam yang lezat yang dapat Kalian coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Coto Ayam:

1. Gunakan 500 gr dada ayam
1. Siapkan 4 buah ceker ayam
1. Ambil 1000 ml air
1. Siapkan 50 gr kacang tanah sangrai
1. Sediakan  Bumbu halus :
1. Siapkan 8 siung bawang merah
1. Sediakan 4 siung bawang putih
1. Gunakan 2 ruas jahe
1. Ambil 3 buah kemiri
1. Ambil 1 sdt ketumbar bubuk
1. Sediakan 1 sdt lada bubuk
1. Siapkan 2 sdt garam
1. Gunakan 2 sdt gula pasir
1. Gunakan 1/2 keping gula merah
1. Siapkan secukupnya Minyak goreng
1. Gunakan  Bahan pelengkap :
1. Sediakan 2 blok kaldu ayam
1. Ambil 2 lembar daun salam
1. Siapkan 3 lembar daun jeruk
1. Ambil 2 tangkai sereh
1. Sediakan 1 tangkai daun bawang
1. Sediakan 1 tangkai seledri
1. Ambil 3 buah kentang rebus
1. Ambil 7 buah cabe rawit merah/sambal
1. Gunakan 1 buah tomat
1. Sediakan 1 buah jeruk nipis
1. Sediakan Secukupnya emping




<!--inarticleads2-->

##### Langkah-langkah membuat Coto Ayam:

1. Siapkan semua bahan yang akan digunakan
1. Sangrai kacang kemudian uleg kasar, buang kulitnya.
1. Rebus kentang bersama cabe rawit hingga empuk. Rebus ayam, setelah empuk sisihkan kuah kaldunya. Goreng ayam kemudian suwir-suwir
1. Haluskan bumbu, kemudian tumis hingga matang dan harum. Tambahkan kacang yang sudah disangrai. Aduk aduk merata.
1. Masukkan bumbu yang sudah ditumis kedalam kuah kaldu, tambahkan kaldu blok, koreksi rasa
1. Siapkan mangkuk saji, isi dengan kentang rebus, tomat dan daun bawang serta seledri. Siram kuah, coto siap disajikan




Wah ternyata cara buat coto ayam yang enak simple ini mudah sekali ya! Kamu semua dapat mencobanya. Cara buat coto ayam Cocok banget untuk kita yang baru mau belajar memasak maupun untuk kalian yang sudah pandai dalam memasak.

Apakah kamu tertarik mencoba bikin resep coto ayam mantab tidak rumit ini? Kalau kalian mau, ayo kalian segera buruan siapin peralatan dan bahannya, maka buat deh Resep coto ayam yang nikmat dan sederhana ini. Sangat mudah kan. 

Maka, daripada kamu berlama-lama, ayo langsung aja buat resep coto ayam ini. Dijamin kamu tiidak akan menyesal bikin resep coto ayam enak tidak rumit ini! Selamat mencoba dengan resep coto ayam lezat simple ini di tempat tinggal kalian masing-masing,ya!.

