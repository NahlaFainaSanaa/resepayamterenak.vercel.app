---
description: "Cara buat Ayam tepung bumbu Asam Manis yang lezat dan Mudah Dibuat"
title: "Cara buat Ayam tepung bumbu Asam Manis yang lezat dan Mudah Dibuat"
slug: 156-cara-buat-ayam-tepung-bumbu-asam-manis-yang-lezat-dan-mudah-dibuat
date: 2021-03-20T01:26:54.172Z
image: https://img-global.cpcdn.com/recipes/9c22cf78a372d9c9/680x482cq70/ayam-tepung-bumbu-asam-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9c22cf78a372d9c9/680x482cq70/ayam-tepung-bumbu-asam-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9c22cf78a372d9c9/680x482cq70/ayam-tepung-bumbu-asam-manis-foto-resep-utama.jpg
author: Lelia Gonzales
ratingvalue: 3.6
reviewcount: 14
recipeingredient:
- " Bahan ayam tepung"
- "1/2 kg dada ayam fillet potong kurleb ukuran 2cm"
- "4 sendok makan tepung terigu"
- "4 sendok makan tepung serba guna"
- "secukupnya Lada bubuk"
- "secukupnya Bawang putih bubuk bisa diganti dengan bawang putih yang dihaluskan uleg"
- "secukupnya Garam"
- " Bahan bumbu asam manis"
- "4 siung bawang merah"
- "1 buah bawang bombang"
- "4 siung bawang putih"
- "10 sachet saos tomat"
- "1 sendok kecap manis"
- "Secukupnya lada"
- "Secukupnya garam"
- "Secukupnya gula"
recipeinstructions:
- "Marinasi Ayam fillet yang sudah dipotong dengan lada bubuk, bawang putih bubuk dan garam. diamkan selama kurang lebih 10-15 menit."
- "Campur tepung terigu dan tepung serbaguna, perbandingan antara tepung terigu dan tepung serbaguna 1:1 (1 sendok tepung terigu : 1 sendok tepung serba guna)"
- "Bagi menjadi 2 mangkok campuran tepung diatas. 1 mangkok tepung dicampur air dan 1 mangkok tepung saja"
- "Masukkan potongan ayam ke adonan tepung cair kemudian ke adonan kering kemudian goreng"
- "Sambil menunggu semua potongan ayam digoreng kita buat saos asam manisnya ya"
- "Tumis bawang merah, bawang bombay dan bawang putih sampai harum"
- "Masukan saos tomat dan kecap"
- "Tambahkan garam, gula dan lada secukupnya"
- "Jika sudah tercampur semua masukan gorengan ayam"
categories:
- Resep
tags:
- ayam
- tepung
- bumbu

katakunci: ayam tepung bumbu 
nutrition: 130 calories
recipecuisine: Indonesian
preptime: "PT23M"
cooktime: "PT41M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam tepung bumbu Asam Manis](https://img-global.cpcdn.com/recipes/9c22cf78a372d9c9/680x482cq70/ayam-tepung-bumbu-asam-manis-foto-resep-utama.jpg)

Sebagai seorang wanita, menyajikan santapan nikmat untuk famili merupakan hal yang memuaskan untuk kita sendiri. Tugas seorang istri bukan sekedar menangani rumah saja, tapi kamu juga harus memastikan kebutuhan gizi tercukupi dan masakan yang disantap anak-anak mesti mantab.

Di waktu  sekarang, kalian memang bisa memesan hidangan jadi walaupun tidak harus susah memasaknya dahulu. Namun ada juga mereka yang memang mau memberikan hidangan yang terbaik bagi orang yang dicintainya. Sebab, menghidangkan masakan sendiri akan jauh lebih bersih dan kita pun bisa menyesuaikan berdasarkan kesukaan keluarga tercinta. 



Apakah anda merupakan seorang penyuka ayam tepung bumbu asam manis?. Asal kamu tahu, ayam tepung bumbu asam manis merupakan sajian khas di Indonesia yang kini disukai oleh banyak orang dari berbagai tempat di Indonesia. Kamu bisa menghidangkan ayam tepung bumbu asam manis kreasi sendiri di rumah dan boleh dijadikan camilan favoritmu di hari libur.

Kita tidak usah bingung jika kamu ingin menyantap ayam tepung bumbu asam manis, karena ayam tepung bumbu asam manis mudah untuk dicari dan kamu pun bisa memasaknya sendiri di tempatmu. ayam tepung bumbu asam manis boleh diolah lewat beragam cara. Sekarang sudah banyak banget resep modern yang menjadikan ayam tepung bumbu asam manis semakin lebih enak.

Resep ayam tepung bumbu asam manis pun sangat gampang untuk dibuat, lho. Kalian tidak usah repot-repot untuk membeli ayam tepung bumbu asam manis, karena Anda mampu menghidangkan di rumahmu. Untuk Kamu yang ingin mencobanya, di bawah ini adalah cara untuk menyajikan ayam tepung bumbu asam manis yang lezat yang mampu Kalian coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Ayam tepung bumbu Asam Manis:

1. Siapkan  Bahan ayam tepung
1. Siapkan 1/2 kg dada ayam fillet potong kurleb ukuran 2cm
1. Sediakan 4 sendok makan tepung terigu
1. Gunakan 4 sendok makan tepung serba guna
1. Siapkan secukupnya Lada bubuk
1. Sediakan secukupnya Bawang putih bubuk bisa diganti dengan bawang putih yang dihaluskan (uleg)
1. Sediakan secukupnya Garam
1. Gunakan  Bahan bumbu asam manis
1. Gunakan 4 siung bawang merah
1. Ambil 1 buah bawang bombang
1. Ambil 4 siung bawang putih
1. Gunakan 10 sachet saos tomat
1. Gunakan 1 sendok kecap manis
1. Ambil Secukupnya lada
1. Ambil Secukupnya garam
1. Sediakan Secukupnya gula




<!--inarticleads2-->

##### Cara menyiapkan Ayam tepung bumbu Asam Manis:

1. Marinasi Ayam fillet yang sudah dipotong dengan lada bubuk, bawang putih bubuk dan garam. diamkan selama kurang lebih 10-15 menit.
1. Campur tepung terigu dan tepung serbaguna, perbandingan antara tepung terigu dan tepung serbaguna 1:1 (1 sendok tepung terigu : 1 sendok tepung serba guna)
1. Bagi menjadi 2 mangkok campuran tepung diatas. 1 mangkok tepung dicampur air dan 1 mangkok tepung saja
1. Masukkan potongan ayam ke adonan tepung cair kemudian ke adonan kering kemudian goreng
1. Sambil menunggu semua potongan ayam digoreng kita buat saos asam manisnya ya
1. Tumis bawang merah, bawang bombay dan bawang putih sampai harum
1. Masukan saos tomat dan kecap
1. Tambahkan garam, gula dan lada secukupnya
1. Jika sudah tercampur semua masukan gorengan ayam




Ternyata cara membuat ayam tepung bumbu asam manis yang mantab tidak ribet ini mudah sekali ya! Kalian semua mampu menghidangkannya. Cara Membuat ayam tepung bumbu asam manis Sangat sesuai banget untuk kita yang sedang belajar memasak ataupun juga bagi anda yang sudah jago dalam memasak.

Apakah kamu mau mencoba bikin resep ayam tepung bumbu asam manis nikmat tidak rumit ini? Kalau kalian mau, mending kamu segera siapkan alat-alat dan bahan-bahannya, setelah itu buat deh Resep ayam tepung bumbu asam manis yang nikmat dan sederhana ini. Benar-benar gampang kan. 

Jadi, daripada anda berfikir lama-lama, hayo kita langsung saja bikin resep ayam tepung bumbu asam manis ini. Pasti kalian tiidak akan nyesel sudah buat resep ayam tepung bumbu asam manis mantab sederhana ini! Selamat mencoba dengan resep ayam tepung bumbu asam manis nikmat tidak rumit ini di rumah masing-masing,ya!.

