---
description: "Resep memasak Soto Ayam Kampung Kuah Santan yang sedap dan Mudah Dibuat"
title: "Resep memasak Soto Ayam Kampung Kuah Santan yang sedap dan Mudah Dibuat"
slug: 258-resep-memasak-soto-ayam-kampung-kuah-santan-yang-sedap-dan-mudah-dibuat
date: 2021-06-28T12:15:45.404Z
image: https://img-global.cpcdn.com/recipes/7bc9114093dd08c4/680x482cq70/soto-ayam-kampung-kuah-santan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7bc9114093dd08c4/680x482cq70/soto-ayam-kampung-kuah-santan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7bc9114093dd08c4/680x482cq70/soto-ayam-kampung-kuah-santan-foto-resep-utama.jpg
author: Dean Gomez
ratingvalue: 3.4
reviewcount: 9
recipeingredient:
- "1/2 ekor ayam kampung"
- "200 gram taoge rendam sebentar dlm air mendidih"
- "100 grm soun aku pake vermicelli rendam sebentar dlm air mendidih"
- "7 lmbr daun salam"
- "4 iris lengkuas"
- "2 btg serai"
- "2 lmbr daun jeruk"
- " bawang goreng dan daun bawang utk taburan"
- "500 ml santan dr 12 butir kelapa"
- "1500 ml air"
- "3/4 sdt garam"
- "1 sdt kaldu jamur bubuk saya  totole"
- "1/4 sdt merica bubuk"
- "1/2 sdt gula pasir"
- "1/2 sdt gula merah"
- " Bumbubumbu yg dihaluskan"
- "4 siung bawang putih"
- "3 siung bawang merah"
- "5 butir kemiri"
- "1 sdt ketumbar butir"
- "1 cm jahe kupas lalu geprek"
- "1 cm kunyit kupas"
- " Pelengkap  Ketupat taoge soun telur kecaptelur pindang bumbu kacang sambel jeruk nipis           lihat resep"
- " Hati  kepala goreng"
recipeinstructions:
- "Rebus air dg panci dan beri 3 lmbr daun salam. Sambil menunggu air mendidih, cuci bersih ayam dg air yg diberi sedikit cuka, bilas dg air lalu tiriskan airnya. Setelah air mendidih, masukkan ayam dan masak hingga kotorannya keluar (+/- 10 menit). Matikan api, buang airnya dan bilas dg air bersih hingga kotorannya hilang."
- "Rebus 1500ml air, sambil menunggu air mendidih, haluskan bumbu (saya diuleg manual/bisa juga diblender). Bila air mendidih masukkan 4 lmbr daun salam dan ayamnya."
- "Tumis bumbu halus dg sedikit minyak hingga harum, masukkan laos, sereh dan jahe. Aduk² agar tidak gosong, tumis bumbu hingga benar² matang lalu matikan api."
- "Masukkan tumisan bumbu kedalam panci yg berisi rebusan ayam. Bumbui garam, kaldu jamur, gula pasir dan merica bubuk, aduk rata. Tuang santan dan tambahkan gula merah, aduk rata. Masak dg api kecil dan sesekali diaduk agar santan tdk pecah. Lakukan test rasa."
- "Bila ayam sudah empuk, angkat, tiriskan airnya. Goreng sebentar lalu suwir² (anak² saya lebih suka yg tdk dogoreng, jadi saya tdk menggorengnya). Siapkan juga soun dan taoge."
- "Sajikan soto: ketupat-soun-tauge- ayam suwir -telur-tuang kuah-bumbu kacang-kecap-kerupuk. Taburi dgn irisan daun bawang dan bawang goreng. Sajikan dg 💕💕 (resep bumbu kacang ada dilampiran)           (lihat resep)"
categories:
- Resep
tags:
- soto
- ayam
- kampung

katakunci: soto ayam kampung 
nutrition: 223 calories
recipecuisine: Indonesian
preptime: "PT26M"
cooktime: "PT47M"
recipeyield: "3"
recipecategory: Lunch

---


![Soto Ayam Kampung Kuah Santan](https://img-global.cpcdn.com/recipes/7bc9114093dd08c4/680x482cq70/soto-ayam-kampung-kuah-santan-foto-resep-utama.jpg)

Sebagai seorang yang hobi masak, menyajikan panganan menggugah selera kepada orang tercinta merupakan suatu hal yang menyenangkan untuk kamu sendiri. Tanggung jawab seorang  wanita bukan sekedar mengurus rumah saja, tapi anda juga wajib menyediakan keperluan gizi tercukupi dan juga olahan yang dikonsumsi anak-anak wajib nikmat.

Di waktu  saat ini, kita sebenarnya bisa memesan hidangan jadi meski tidak harus ribet mengolahnya dulu. Tetapi banyak juga lho mereka yang selalu ingin memberikan makanan yang terbaik bagi orang tercintanya. Lantaran, menyajikan masakan yang dibuat sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan hidangan tersebut sesuai masakan kesukaan famili. 



Apakah anda merupakan salah satu penikmat soto ayam kampung kuah santan?. Tahukah kamu, soto ayam kampung kuah santan merupakan hidangan khas di Indonesia yang saat ini digemari oleh setiap orang di hampir setiap wilayah di Indonesia. Anda dapat menghidangkan soto ayam kampung kuah santan sendiri di rumahmu dan pasti jadi hidangan kesenanganmu di hari liburmu.

Kamu tidak usah bingung untuk menyantap soto ayam kampung kuah santan, sebab soto ayam kampung kuah santan sangat mudah untuk ditemukan dan juga kita pun bisa memasaknya sendiri di tempatmu. soto ayam kampung kuah santan boleh dimasak memalui beraneka cara. Saat ini ada banyak resep kekinian yang menjadikan soto ayam kampung kuah santan semakin lebih nikmat.

Resep soto ayam kampung kuah santan pun gampang untuk dibikin, lho. Anda jangan repot-repot untuk membeli soto ayam kampung kuah santan, karena Kalian mampu menghidangkan ditempatmu. Untuk Kamu yang mau menghidangkannya, di bawah ini adalah resep menyajikan soto ayam kampung kuah santan yang lezat yang dapat Kita coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Soto Ayam Kampung Kuah Santan:

1. Siapkan 1/2 ekor ayam kampung
1. Gunakan 200 gram taoge, rendam sebentar dlm air mendidih
1. Sediakan 100 grm soun (aku pake vermicelli), rendam sebentar dlm air mendidih
1. Siapkan 7 lmbr daun salam
1. Ambil 4 iris lengkuas
1. Gunakan 2 btg serai
1. Ambil 2 lmbr daun jeruk
1. Gunakan  bawang goreng dan daun bawang utk taburan
1. Ambil 500 ml santan dr 1/2 butir kelapa
1. Siapkan 1500 ml air
1. Ambil 3/4 sdt garam
1. Gunakan 1 sdt kaldu jamur bubuk (saya : totole)
1. Siapkan 1/4 sdt merica bubuk
1. Gunakan 1/2 sdt gula pasir
1. Ambil 1/2 sdt gula merah
1. Ambil  Bumbu-bumbu yg dihaluskan
1. Sediakan 4 siung bawang putih
1. Siapkan 3 siung bawang merah
1. Siapkan 5 butir kemiri
1. Gunakan 1 sdt ketumbar butir
1. Siapkan 1 cm jahe, kupas lalu geprek
1. Gunakan 1 cm kunyit, kupas
1. Ambil  Pelengkap : Ketupat, taoge, soun, telur kecap/telur pindang, bumbu kacang, sambel, jeruk nipis           (lihat resep)
1. Gunakan  Hati &amp; kepala goreng




<!--inarticleads2-->

##### Langkah-langkah membuat Soto Ayam Kampung Kuah Santan:

1. Rebus air dg panci dan beri 3 lmbr daun salam. Sambil menunggu air mendidih, cuci bersih ayam dg air yg diberi sedikit cuka, bilas dg air lalu tiriskan airnya. Setelah air mendidih, masukkan ayam dan masak hingga kotorannya keluar (+/- 10 menit). Matikan api, buang airnya dan bilas dg air bersih hingga kotorannya hilang.
1. Rebus 1500ml air, sambil menunggu air mendidih, haluskan bumbu (saya diuleg manual/bisa juga diblender). Bila air mendidih masukkan 4 lmbr daun salam dan ayamnya.
1. Tumis bumbu halus dg sedikit minyak hingga harum, masukkan laos, sereh dan jahe. Aduk² agar tidak gosong, tumis bumbu hingga benar² matang lalu matikan api.
1. Masukkan tumisan bumbu kedalam panci yg berisi rebusan ayam. Bumbui garam, kaldu jamur, gula pasir dan merica bubuk, aduk rata. Tuang santan dan tambahkan gula merah, aduk rata. Masak dg api kecil dan sesekali diaduk agar santan tdk pecah. Lakukan test rasa.
1. Bila ayam sudah empuk, angkat, tiriskan airnya. Goreng sebentar lalu suwir² (anak² saya lebih suka yg tdk dogoreng, jadi saya tdk menggorengnya). Siapkan juga soun dan taoge.
1. Sajikan soto: ketupat-soun-tauge- ayam suwir -telur-tuang kuah-bumbu kacang-kecap-kerupuk. Taburi dgn irisan daun bawang dan bawang goreng. Sajikan dg 💕💕 (resep bumbu kacang ada dilampiran) -           (lihat resep)




Wah ternyata resep soto ayam kampung kuah santan yang enak simple ini mudah sekali ya! Anda Semua mampu membuatnya. Cara Membuat soto ayam kampung kuah santan Sangat sesuai sekali untuk kalian yang baru belajar memasak ataupun juga untuk anda yang telah ahli memasak.

Tertarik untuk mencoba bikin resep soto ayam kampung kuah santan nikmat simple ini? Kalau tertarik, yuk kita segera menyiapkan alat dan bahannya, lalu bikin deh Resep soto ayam kampung kuah santan yang nikmat dan tidak ribet ini. Benar-benar mudah kan. 

Oleh karena itu, ketimbang kita diam saja, yuk kita langsung saja sajikan resep soto ayam kampung kuah santan ini. Dijamin kamu tak akan nyesel membuat resep soto ayam kampung kuah santan mantab sederhana ini! Selamat berkreasi dengan resep soto ayam kampung kuah santan nikmat sederhana ini di rumah masing-masing,oke!.

