---
description: "Cara buat Coto ayam khas makassar Sederhana Untuk Jualan"
title: "Cara buat Coto ayam khas makassar Sederhana Untuk Jualan"
slug: 54-cara-buat-coto-ayam-khas-makassar-sederhana-untuk-jualan
date: 2021-02-01T14:38:38.888Z
image: https://img-global.cpcdn.com/recipes/d9997b3d696832d5/680x482cq70/coto-ayam-khas-makassar-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d9997b3d696832d5/680x482cq70/coto-ayam-khas-makassar-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d9997b3d696832d5/680x482cq70/coto-ayam-khas-makassar-foto-resep-utama.jpg
author: Rosie Conner
ratingvalue: 4.2
reviewcount: 6
recipeingredient:
- "1/2 kilo ayam"
- "2 lembar daun jeruk"
- "2 lembar daun salam"
- "1/2 sendok teh pala bubuk"
- "Secukupnya merica bubuk"
- "Secukupnya kaldu ayam"
- "Secukupnya garam"
- "Secukupnya gula merah"
- "2 sendok makan air asam jawa"
- "Secukupnya Air"
- " Minyak untuk menumis bumbu"
- " Bumbu halus"
- "250 gram kacang tanah"
- "8 siung bawang merah"
- "5 siung bawang putih"
- "2 btang serai"
- "1 ruas lengkuas"
- "1 ruas jahe"
- "2 butir kemiri"
- " Bumbu pelengkap"
- " Daun bawang"
- " Daun seledri"
- " Bawang goreng"
- " Jeruk nipis"
- " Kecap"
- " Sambel"
recipeinstructions:
- "Cuci bersih ayam dan potong kecil kecil"
- "Rebus daging ayam sampai empuk"
- "Haluskan bumbu halus, kemudian masukkan kedalam minyak, masukkan daun salam dan daun jeruk tnggu sampai bumbu kering (sisa bumbu halus dan minyak)"
- "Campurkan bumbu halus kedalam rebusan daging ayam, tambahkan pala bubuk, merica, air asam, gula merah, kaldu dan garam. Cek rasa"
- "Jika sudah tercampur angkat dan coto ayam siap disajikan."
- "Tambahkan bumbu pelengkap supaya lebih nikmat..."
categories:
- Resep
tags:
- coto
- ayam
- khas

katakunci: coto ayam khas 
nutrition: 198 calories
recipecuisine: Indonesian
preptime: "PT26M"
cooktime: "PT58M"
recipeyield: "4"
recipecategory: Dessert

---


![Coto ayam khas makassar](https://img-global.cpcdn.com/recipes/d9997b3d696832d5/680x482cq70/coto-ayam-khas-makassar-foto-resep-utama.jpg)

Andai kalian seorang yang hobi masak, menyuguhkan hidangan sedap kepada famili merupakan suatu hal yang membahagiakan untuk kita sendiri. Kewajiban seorang  wanita bukan saja menjaga rumah saja, tetapi kamu pun harus memastikan kebutuhan nutrisi tercukupi dan santapan yang dikonsumsi orang tercinta harus menggugah selera.

Di era  saat ini, anda memang bisa memesan masakan instan tanpa harus susah membuatnya lebih dulu. Tetapi ada juga lho orang yang selalu ingin menyajikan yang terbaik untuk keluarganya. Lantaran, menyajikan masakan yang dibuat sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan masakan tersebut sesuai kesukaan famili. 



Apakah kamu seorang penyuka coto ayam khas makassar?. Tahukah kamu, coto ayam khas makassar adalah sajian khas di Indonesia yang kini disukai oleh banyak orang dari berbagai wilayah di Nusantara. Kalian dapat membuat coto ayam khas makassar buatan sendiri di rumah dan pasti jadi santapan kesukaanmu di hari libur.

Kita jangan bingung jika kamu ingin mendapatkan coto ayam khas makassar, lantaran coto ayam khas makassar sangat mudah untuk dicari dan juga kalian pun bisa mengolahnya sendiri di tempatmu. coto ayam khas makassar dapat dimasak dengan bermacam cara. Kini pun telah banyak banget resep kekinian yang membuat coto ayam khas makassar lebih enak.

Resep coto ayam khas makassar pun mudah sekali dibikin, lho. Kita jangan ribet-ribet untuk memesan coto ayam khas makassar, karena Anda bisa membuatnya sendiri di rumah. Untuk Kita yang mau menghidangkannya, berikut resep membuat coto ayam khas makassar yang mantab yang dapat Anda coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Coto ayam khas makassar:

1. Ambil 1/2 kilo ayam
1. Ambil 2 lembar daun jeruk
1. Sediakan 2 lembar daun salam
1. Sediakan 1/2 sendok teh pala bubuk
1. Ambil Secukupnya merica bubuk
1. Sediakan Secukupnya kaldu ayam
1. Sediakan Secukupnya garam
1. Gunakan Secukupnya gula merah
1. Ambil 2 sendok makan air asam jawa
1. Ambil Secukupnya Air
1. Gunakan  Minyak untuk menumis bumbu
1. Sediakan  Bumbu halus
1. Ambil 250 gram kacang tanah
1. Sediakan 8 siung bawang merah
1. Siapkan 5 siung bawang putih
1. Ambil 2 btang serai
1. Siapkan 1 ruas lengkuas
1. Ambil 1 ruas jahe
1. Siapkan 2 butir kemiri
1. Ambil  Bumbu pelengkap
1. Ambil  Daun bawang
1. Sediakan  Daun seledri
1. Sediakan  Bawang goreng
1. Gunakan  Jeruk nipis
1. Siapkan  Kecap
1. Gunakan  Sambel




<!--inarticleads2-->

##### Cara menyiapkan Coto ayam khas makassar:

1. Cuci bersih ayam dan potong kecil kecil
1. Rebus daging ayam sampai empuk
1. Haluskan bumbu halus, kemudian masukkan kedalam minyak, masukkan daun salam dan daun jeruk tnggu sampai bumbu kering (sisa bumbu halus dan minyak)
1. Campurkan bumbu halus kedalam rebusan daging ayam, tambahkan pala bubuk, merica, air asam, gula merah, kaldu dan garam. Cek rasa
1. Jika sudah tercampur angkat dan coto ayam siap disajikan.
1. Tambahkan bumbu pelengkap supaya lebih nikmat...




Ternyata cara membuat coto ayam khas makassar yang lezat simple ini gampang sekali ya! Anda Semua mampu menghidangkannya. Cara buat coto ayam khas makassar Sangat sesuai sekali buat kalian yang baru belajar memasak maupun untuk anda yang telah ahli memasak.

Apakah kamu ingin mulai mencoba buat resep coto ayam khas makassar enak simple ini? Kalau ingin, yuk kita segera buruan siapin alat-alat dan bahan-bahannya, lalu buat deh Resep coto ayam khas makassar yang nikmat dan tidak ribet ini. Sungguh mudah kan. 

Maka dari itu, ketimbang anda diam saja, maka kita langsung saja buat resep coto ayam khas makassar ini. Dijamin kalian tiidak akan nyesel sudah buat resep coto ayam khas makassar nikmat simple ini! Selamat berkreasi dengan resep coto ayam khas makassar enak tidak rumit ini di rumah sendiri,oke!.

