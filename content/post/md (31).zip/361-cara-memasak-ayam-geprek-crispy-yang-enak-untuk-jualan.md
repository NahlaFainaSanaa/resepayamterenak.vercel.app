---
description: "Cara memasak Ayam Geprek / Crispy yang enak Untuk Jualan"
title: "Cara memasak Ayam Geprek / Crispy yang enak Untuk Jualan"
slug: 361-cara-memasak-ayam-geprek-crispy-yang-enak-untuk-jualan
date: 2021-03-14T21:11:16.998Z
image: https://img-global.cpcdn.com/recipes/147156d34a533ef0/680x482cq70/ayam-geprek-crispy-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/147156d34a533ef0/680x482cq70/ayam-geprek-crispy-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/147156d34a533ef0/680x482cq70/ayam-geprek-crispy-foto-resep-utama.jpg
author: Jackson McCarthy
ratingvalue: 3
reviewcount: 3
recipeingredient:
- "Secukupnya ayam fillet garam jeniper"
- " Bumbu marinasi "
- "5 Bawang putih yg sudah dihaluskan"
- "1 sdt Lada bubuk"
- "1 sdm Kaldu bubuk"
- "1 sdm Garam"
- "1 sdm Cabe bubuk optional"
- "1 sdm Ketumbar"
- " Bumbu Baluran Tepung "
- " Tepung terigu agak banyakan"
- "1 sdm garam"
- "1 sdm kaldu bubuk"
- "1 sdm lada bubuk"
- "1 sdm ketumbar bubuk"
- "1 sdt baking powder  kalo gk ada boleh pake baking soda"
- " Bahan celupan air "
- " Air dingin  es"
- "1 sdt baking powder  baking soda"
- "1 sdt kaldu bubuk"
- "1 sdt garam"
recipeinstructions:
- "Bersihkan ayam, baluri jeniper dan garam, biarkan sebentar"
- "Siapkan bumbu marinasi, tambahkan ke ayam, aduk rata, biarkan selama semalaman di kulkas."
- "Siapkan bahan tepung balur, aduk rata. Sisihkan."
- "Siapkan bahan celupan air, aduk hingga merata semua."
- "Balurkan ayam yg sudah di marinasi ke dalam tepung, aduk dengan dibalik2 spt di gulung2, jangan di tekan2, lakukan selama 1-2 mnit"
- "Celupkan ke dalam campuran air es, angkat, lalu tiriskan airnya, usahakan air nya benar2 tertiriskan, supaya tepung nya tidak bergumpal2"
- "Lalu baluri lagi dg tepung tadi, guling2kan ayam nya sampai tepung nya terbentuk kriwil2 dn banyak"
- "Jika di rasa tepung kurang tebal, bisa di celupkan lagi ke air es, lalu baluri lg dg tepung"
- "Sambil masih di aduk ayamnya, panas kan minyak, stelah selesai proses baluran tepung, goreng ayam dengan posisi ayam bener2 tenggelam ke dlm minyak, minyak nya harus banyak dan bener2 udah panas pas di celupin ayam nya ke minyak"
- "Kalo sudah keemasan, balik ayamnya. Cukup 1 x balik saja. Stelah matang keemasan, angkat dn tiriskan"
- "Geprek ayam nya sedikit, baluri sambal di atasnya"
- "Siap di nikmati dengan nasi hangat :)"
categories:
- Resep
tags:
- ayam
- geprek
- 

katakunci: ayam geprek  
nutrition: 278 calories
recipecuisine: Indonesian
preptime: "PT12M"
cooktime: "PT49M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam Geprek / Crispy](https://img-global.cpcdn.com/recipes/147156d34a533ef0/680x482cq70/ayam-geprek-crispy-foto-resep-utama.jpg)

Jika anda seorang wanita, mempersiapkan olahan enak pada orang tercinta merupakan suatu hal yang menyenangkan untuk kamu sendiri. Tugas seorang istri bukan sekedar mengurus rumah saja, tetapi kamu pun wajib memastikan kebutuhan nutrisi tercukupi dan juga olahan yang dimakan orang tercinta wajib sedap.

Di era  saat ini, kita sebenarnya bisa memesan masakan instan tanpa harus susah membuatnya lebih dulu. Tapi ada juga mereka yang memang mau memberikan hidangan yang terbaik untuk orang yang dicintainya. Lantaran, menghidangkan masakan yang dibuat sendiri akan jauh lebih bersih dan bisa menyesuaikan hidangan tersebut sesuai makanan kesukaan orang tercinta. 



Mungkinkah kamu seorang penggemar ayam geprek / crispy?. Tahukah kamu, ayam geprek / crispy merupakan makanan khas di Indonesia yang sekarang disukai oleh orang-orang dari hampir setiap wilayah di Nusantara. Anda bisa menghidangkan ayam geprek / crispy sendiri di rumahmu dan dapat dijadikan santapan favoritmu di akhir pekanmu.

Kita tidak perlu bingung jika kamu ingin memakan ayam geprek / crispy, sebab ayam geprek / crispy tidak sulit untuk didapatkan dan juga anda pun bisa memasaknya sendiri di tempatmu. ayam geprek / crispy bisa dimasak lewat beragam cara. Saat ini sudah banyak sekali resep modern yang menjadikan ayam geprek / crispy lebih enak.

Resep ayam geprek / crispy pun gampang sekali untuk dibikin, lho. Kamu tidak perlu repot-repot untuk membeli ayam geprek / crispy, tetapi Kalian mampu membuatnya di rumah sendiri. Untuk Kita yang ingin membuatnya, di bawah ini adalah cara untuk membuat ayam geprek / crispy yang nikamat yang bisa Kamu coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Ayam Geprek / Crispy:

1. Gunakan Secukupnya ayam fillet, garam, jeniper
1. Siapkan  Bumbu marinasi :
1. Gunakan 5 Bawang putih yg sudah dihaluskan
1. Gunakan 1 sdt Lada bubuk
1. Gunakan 1 sdm Kaldu bubuk
1. Sediakan 1 sdm Garam
1. Gunakan 1 sdm Cabe bubuk (optional)
1. Ambil 1 sdm Ketumbar
1. Sediakan  Bumbu Baluran Tepung :
1. Siapkan  Tepung terigu (agak banyakan)
1. Ambil 1 sdm garam
1. Sediakan 1 sdm kaldu bubuk
1. Sediakan 1 sdm lada bubuk
1. Gunakan 1 sdm ketumbar bubuk
1. Siapkan 1 sdt baking powder / kalo gk ada boleh pake baking soda
1. Ambil  Bahan celupan air :
1. Sediakan  Air dingin + es
1. Ambil 1 sdt baking powder / baking soda
1. Ambil 1 sdt kaldu bubuk
1. Ambil 1 sdt garam




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Geprek / Crispy:

1. Bersihkan ayam, baluri jeniper dan garam, biarkan sebentar
1. Siapkan bumbu marinasi, tambahkan ke ayam, aduk rata, biarkan selama semalaman di kulkas.
1. Siapkan bahan tepung balur, aduk rata. Sisihkan.
1. Siapkan bahan celupan air, aduk hingga merata semua.
1. Balurkan ayam yg sudah di marinasi ke dalam tepung, aduk dengan dibalik2 spt di gulung2, jangan di tekan2, lakukan selama 1-2 mnit
1. Celupkan ke dalam campuran air es, angkat, lalu tiriskan airnya, usahakan air nya benar2 tertiriskan, supaya tepung nya tidak bergumpal2
1. Lalu baluri lagi dg tepung tadi, guling2kan ayam nya sampai tepung nya terbentuk kriwil2 dn banyak
1. Jika di rasa tepung kurang tebal, bisa di celupkan lagi ke air es, lalu baluri lg dg tepung
1. Sambil masih di aduk ayamnya, panas kan minyak, stelah selesai proses baluran tepung, goreng ayam dengan posisi ayam bener2 tenggelam ke dlm minyak, minyak nya harus banyak dan bener2 udah panas pas di celupin ayam nya ke minyak
1. Kalo sudah keemasan, balik ayamnya. Cukup 1 x balik saja. - Stelah matang keemasan, angkat dn tiriskan
1. Geprek ayam nya sedikit, baluri sambal di atasnya
1. Siap di nikmati dengan nasi hangat :)




Ternyata cara membuat ayam geprek / crispy yang nikamt simple ini gampang sekali ya! Anda Semua dapat membuatnya. Cara buat ayam geprek / crispy Sangat sesuai sekali buat kamu yang sedang belajar memasak ataupun untuk kalian yang telah jago memasak.

Apakah kamu mau mulai mencoba membikin resep ayam geprek / crispy enak tidak rumit ini? Kalau kamu tertarik, ayo kamu segera menyiapkan peralatan dan bahan-bahannya, lalu bikin deh Resep ayam geprek / crispy yang enak dan simple ini. Sungguh taidak sulit kan. 

Oleh karena itu, daripada kalian berfikir lama-lama, maka langsung aja bikin resep ayam geprek / crispy ini. Pasti kamu gak akan nyesel bikin resep ayam geprek / crispy nikmat tidak ribet ini! Selamat mencoba dengan resep ayam geprek / crispy mantab sederhana ini di tempat tinggal kalian masing-masing,oke!.

