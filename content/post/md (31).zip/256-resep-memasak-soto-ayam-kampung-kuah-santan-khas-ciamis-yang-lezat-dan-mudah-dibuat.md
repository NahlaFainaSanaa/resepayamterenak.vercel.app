---
description: "Resep memasak Soto Ayam Kampung Kuah Santan Khas Ciamis yang lezat dan Mudah Dibuat"
title: "Resep memasak Soto Ayam Kampung Kuah Santan Khas Ciamis yang lezat dan Mudah Dibuat"
slug: 256-resep-memasak-soto-ayam-kampung-kuah-santan-khas-ciamis-yang-lezat-dan-mudah-dibuat
date: 2021-05-12T21:03:22.576Z
image: https://img-global.cpcdn.com/recipes/5c3079f13504354e/680x482cq70/soto-ayam-kampung-kuah-santan-khas-ciamis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5c3079f13504354e/680x482cq70/soto-ayam-kampung-kuah-santan-khas-ciamis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5c3079f13504354e/680x482cq70/soto-ayam-kampung-kuah-santan-khas-ciamis-foto-resep-utama.jpg
author: Mark Reeves
ratingvalue: 4.6
reviewcount: 11
recipeingredient:
- "2 batang bawang daun potongpotong"
- "1 ruas jahe iris tipis"
- "1/2 bagian ayam kampung saya pakai paha"
- "1/2 sdt merica"
- "1 lt air kaldu ayam"
- "2 sdm minyak goreng untuk menumis bumbu"
- "2 batang sereh memarkan"
- "5 cm lengkuas iris tipis"
- "1 sdt gula pasir"
- "500 ml santan"
- "4 lembar daun salam"
- "1 sdt kaldu bubuk"
- " Bumbu Halus "
- "5 siung bawang merah"
- "2 buah kemiri"
- "3 siung bawang putih"
- "1/2 sdt kunyit bubuk"
- "1 sdm gula aren  gula merah yang disisir halus"
- "1 sdt penuh garam"
- "1 buah tomat potongpotong"
- " Bahan Pelengkap "
- "3 keping soun rendam air panas tiriskan"
- "Sesuai selera bawang goreng"
- "Sesuai selera kacang tanah goreng"
- "secukupnya Kerupuk merah"
- "Sesuai selera Sambal"
- "1 buah jeruk nipis potongpotong"
recipeinstructions:
- "Siapkan bumbu, presto ayam kampung, angkat, lalu suir-suir."
- "Didihkan air kaldu dari presto (saring), masukkan ayam suir, bawang daun, jahe dan merica. Aduk rata."
- "Siapkan wajan, panaskan minyak goreng. Tumis bawang merah dan putih hingga harum, tambahkan bumbu halus, sereh, daun salam dan lengkuas. Aduk rata. Tumis hingga bumbu matang. Masukkan bumbu ke dalam kuah ayam. Aduk rata. Biarkan mendidih lagi."
- "Tambahkan santan, aduk rata. Masak hingga mendidih. Cek rasa. Terakhir tambahkan tomat."
- "Siapkan mangkok saji, tata soun, lalu siram kuah panas dan ayam suwirnya, taburi bawang goreng, kacang tanah goreng, jeruk nipis dan kerupuk merah. Sajikan panas-panas 😍"
categories:
- Resep
tags:
- soto
- ayam
- kampung

katakunci: soto ayam kampung 
nutrition: 151 calories
recipecuisine: Indonesian
preptime: "PT20M"
cooktime: "PT38M"
recipeyield: "2"
recipecategory: Dessert

---


![Soto Ayam Kampung Kuah Santan Khas Ciamis](https://img-global.cpcdn.com/recipes/5c3079f13504354e/680x482cq70/soto-ayam-kampung-kuah-santan-khas-ciamis-foto-resep-utama.jpg)

Sebagai seorang istri, mempersiapkan hidangan nikmat pada famili adalah hal yang mengasyikan untuk kita sendiri. Peran seorang  wanita bukan cuman mengurus rumah saja, tapi anda pun harus memastikan kebutuhan gizi tercukupi dan olahan yang dimakan keluarga tercinta wajib nikmat.

Di era  saat ini, anda memang dapat membeli masakan siap saji tanpa harus ribet membuatnya terlebih dahulu. Tapi ada juga mereka yang selalu mau menghidangkan yang terlezat untuk orang yang dicintainya. Karena, menyajikan masakan yang diolah sendiri jauh lebih higienis dan kita juga bisa menyesuaikan masakan tersebut sesuai selera keluarga. 



Apakah kamu salah satu penyuka soto ayam kampung kuah santan khas ciamis?. Asal kamu tahu, soto ayam kampung kuah santan khas ciamis merupakan makanan khas di Nusantara yang saat ini disenangi oleh banyak orang dari berbagai daerah di Nusantara. Kamu dapat menyajikan soto ayam kampung kuah santan khas ciamis sendiri di rumahmu dan boleh jadi santapan favorit di hari liburmu.

Anda tidak usah bingung untuk mendapatkan soto ayam kampung kuah santan khas ciamis, karena soto ayam kampung kuah santan khas ciamis tidak sukar untuk didapatkan dan juga anda pun dapat membuatnya sendiri di tempatmu. soto ayam kampung kuah santan khas ciamis dapat dimasak memalui bermacam cara. Saat ini ada banyak banget cara kekinian yang membuat soto ayam kampung kuah santan khas ciamis semakin lebih mantap.

Resep soto ayam kampung kuah santan khas ciamis juga gampang sekali untuk dibuat, lho. Kalian tidak perlu ribet-ribet untuk memesan soto ayam kampung kuah santan khas ciamis, tetapi Kalian mampu menyajikan ditempatmu. Untuk Anda yang ingin menyajikannya, berikut cara membuat soto ayam kampung kuah santan khas ciamis yang mantab yang bisa Kamu hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Soto Ayam Kampung Kuah Santan Khas Ciamis:

1. Ambil 2 batang bawang daun, potong-potong
1. Siapkan 1 ruas jahe, iris tipis
1. Ambil 1/2 bagian ayam kampung (saya pakai paha)
1. Siapkan 1/2 sdt merica
1. Sediakan 1 lt air kaldu ayam
1. Ambil 2 sdm minyak goreng untuk menumis bumbu
1. Gunakan 2 batang sereh, memarkan
1. Gunakan 5 cm lengkuas, iris tipis
1. Ambil 1 sdt gula pasir
1. Ambil 500 ml santan
1. Siapkan 4 lembar daun salam
1. Sediakan 1 sdt kaldu bubuk
1. Sediakan  Bumbu Halus :
1. Gunakan 5 siung bawang merah
1. Ambil 2 buah kemiri
1. Gunakan 3 siung bawang putih
1. Siapkan 1/2 sdt kunyit bubuk
1. Gunakan 1 sdm gula aren / gula merah yang disisir halus
1. Gunakan 1 sdt penuh garam
1. Sediakan 1 buah tomat, potong-potong
1. Siapkan  Bahan Pelengkap :
1. Ambil 3 keping soun, rendam air panas, tiriskan
1. Gunakan Sesuai selera bawang goreng
1. Sediakan Sesuai selera kacang tanah goreng
1. Gunakan secukupnya Kerupuk merah
1. Sediakan Sesuai selera Sambal
1. Siapkan 1 buah jeruk nipis, potong-potong




<!--inarticleads2-->

##### Cara membuat Soto Ayam Kampung Kuah Santan Khas Ciamis:

1. Siapkan bumbu, presto ayam kampung, angkat, lalu suir-suir.
1. Didihkan air kaldu dari presto (saring), masukkan ayam suir, bawang daun, jahe dan merica. Aduk rata.
1. Siapkan wajan, panaskan minyak goreng. Tumis bawang merah dan putih hingga harum, tambahkan bumbu halus, sereh, daun salam dan lengkuas. Aduk rata. Tumis hingga bumbu matang. Masukkan bumbu ke dalam kuah ayam. Aduk rata. Biarkan mendidih lagi.
1. Tambahkan santan, aduk rata. Masak hingga mendidih. Cek rasa. Terakhir tambahkan tomat.
1. Siapkan mangkok saji, tata soun, lalu siram kuah panas dan ayam suwirnya, taburi bawang goreng, kacang tanah goreng, jeruk nipis dan kerupuk merah. Sajikan panas-panas 😍




Ternyata resep soto ayam kampung kuah santan khas ciamis yang enak tidak ribet ini gampang sekali ya! Kalian semua mampu membuatnya. Cara buat soto ayam kampung kuah santan khas ciamis Sesuai sekali buat kamu yang sedang belajar memasak atau juga bagi kamu yang telah pandai dalam memasak.

Apakah kamu mau mulai mencoba membikin resep soto ayam kampung kuah santan khas ciamis lezat sederhana ini? Kalau ingin, ayo kalian segera menyiapkan peralatan dan bahannya, kemudian bikin deh Resep soto ayam kampung kuah santan khas ciamis yang enak dan tidak ribet ini. Betul-betul mudah kan. 

Maka dari itu, daripada anda berfikir lama-lama, ayo langsung aja sajikan resep soto ayam kampung kuah santan khas ciamis ini. Dijamin anda tiidak akan menyesal sudah bikin resep soto ayam kampung kuah santan khas ciamis mantab sederhana ini! Selamat mencoba dengan resep soto ayam kampung kuah santan khas ciamis enak sederhana ini di tempat tinggal masing-masing,oke!.

