---
description: "Cara memasak Soto Ayam yang enak dan Mudah Dibuat"
title: "Cara memasak Soto Ayam yang enak dan Mudah Dibuat"
slug: 238-cara-memasak-soto-ayam-yang-enak-dan-mudah-dibuat
date: 2021-03-20T04:42:32.137Z
image: https://img-global.cpcdn.com/recipes/c057821a450601b0/680x482cq70/soto-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c057821a450601b0/680x482cq70/soto-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c057821a450601b0/680x482cq70/soto-ayam-foto-resep-utama.jpg
author: Jerome Wade
ratingvalue: 3.1
reviewcount: 14
recipeingredient:
- "1 kg dada ayam"
- "2 liter air"
- "3 sdm minyak goreng untuk tumis"
- "secukupnya garam  lada"
- "sedikit gula"
- "secukupnya kaldu ayam optional"
- " Bumbu A"
- "3 batang serai putihny saja memarkan"
- "6 lembar daun jeruk purut buang tulangnya iris tipis daunnya"
- "1-1,5 sdm kunyit bubuk"
- " Bumbu halus"
- "10 bj bawang merah"
- "5 bj bawang putih"
- "4 bj kemiri Sangrai"
- "3 cm jahe"
- " Pelengkap"
- "1 buah kentang size sedang iris tipis goreng"
- "1/4 buah kembang kol iris tipis"
- "2 genggam mie bihun rendam di air panas hingga lemas"
- "Sedikit irisan bawang merah goreng"
- "Sedikit perasan jeruk nipis"
- "iris Telur rebus"
recipeinstructions:
- "Rebus 5 buah telur hingga matang. Sisihkan."
- "Cuci ayam hingga bersih. Sisihkan."
- "Rebusan ayam: Didihkan air, masukkan ayam. Masak dengan api kecil hingga keluar kaldunya, buang busanya."
- "Tumisan bumbu: Panaskan minyak goreng, tumis bumbu halus + bumbu A hingga harum. Matikan kompor."
- "Masukkan tumisan bumbu ke dalam rebusan ayam, tambahkan sesuai selera garam, lada, gula, kaldu bubuk. Masak hingga ayam empuk."
- "Jika ayam sudah empuk, panaskan minyak goreng, goreng ayam hingga kecoklatan, angkat, lalu suir."
- "Tata soto dalam mangkuk: Bihun + kol + telur rebus + ayam suir + kentang, lalu siram dengan kuah yg panas (hati-hati), beri bawang merah goreng + sedikit perasan jeruk nipis🤤🤤. Sajikan."
- "Photo hanya saran penyajian, ditambah sedikit irisan tomat dan daun bawang (warnanya tambah cakep)🤩"
categories:
- Resep
tags:
- soto
- ayam

katakunci: soto ayam 
nutrition: 270 calories
recipecuisine: Indonesian
preptime: "PT35M"
cooktime: "PT56M"
recipeyield: "1"
recipecategory: Dinner

---


![Soto Ayam](https://img-global.cpcdn.com/recipes/c057821a450601b0/680x482cq70/soto-ayam-foto-resep-utama.jpg)

Jika anda seorang istri, mempersiapkan santapan lezat kepada orang tercinta adalah hal yang memuaskan untuk anda sendiri. Peran seorang ibu Tidak cuma mengatur rumah saja, namun kamu juga harus memastikan kebutuhan nutrisi terpenuhi dan juga hidangan yang dimakan anak-anak wajib nikmat.

Di masa  saat ini, anda memang bisa memesan santapan siap saji tidak harus repot membuatnya dahulu. Tetapi ada juga lho orang yang memang mau memberikan yang terlezat untuk orang tercintanya. Pasalnya, memasak yang dibuat sendiri akan jauh lebih bersih dan bisa menyesuaikan masakan tersebut sesuai selera keluarga. 



Mungkinkah anda salah satu penikmat soto ayam?. Tahukah kamu, soto ayam adalah hidangan khas di Nusantara yang sekarang disenangi oleh setiap orang di berbagai wilayah di Nusantara. Kalian dapat menyajikan soto ayam sendiri di rumahmu dan boleh jadi santapan kesenanganmu di hari libur.

Kalian tidak usah bingung jika kamu ingin menyantap soto ayam, sebab soto ayam tidak sulit untuk ditemukan dan juga kita pun dapat memasaknya sendiri di tempatmu. soto ayam boleh dibuat dengan beragam cara. Sekarang ada banyak banget resep kekinian yang menjadikan soto ayam semakin lebih enak.

Resep soto ayam juga gampang dihidangkan, lho. Kamu jangan capek-capek untuk membeli soto ayam, lantaran Kita bisa menyiapkan sendiri di rumah. Bagi Kalian yang akan menghidangkannya, dibawah ini merupakan resep untuk membuat soto ayam yang enak yang bisa Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Soto Ayam:

1. Gunakan 1 kg dada ayam
1. Ambil 2 liter air
1. Gunakan 3 sdm minyak goreng untuk tumis
1. Ambil secukupnya garam &amp; lada
1. Siapkan sedikit gula
1. Ambil secukupnya kaldu ayam (optional)
1. Siapkan  Bumbu A:
1. Siapkan 3 batang serai, putihny saja, memarkan
1. Siapkan 6 lembar daun jeruk purut, buang tulangnya, iris tipis daunnya
1. Gunakan 1-1,5 sdm kunyit bubuk
1. Ambil  Bumbu halus:
1. Siapkan 10 bj bawang merah
1. Sediakan 5 bj bawang putih
1. Sediakan 4 bj kemiri Sangrai
1. Sediakan 3 cm jahe
1. Gunakan  Pelengkap:
1. Ambil 1 buah kentang size sedang, iris tipis, goreng
1. Siapkan 1/4 buah kembang kol, iris tipis
1. Gunakan 2 genggam mie bihun, rendam di air panas hingga lemas
1. Siapkan Sedikit irisan bawang merah goreng
1. Ambil Sedikit perasan jeruk nipis
1. Siapkan iris Telur rebus,




<!--inarticleads2-->

##### Cara menyiapkan Soto Ayam:

1. Rebus 5 buah telur hingga matang. Sisihkan.
1. Cuci ayam hingga bersih. Sisihkan.
1. Rebusan ayam: - Didihkan air, masukkan ayam. Masak dengan api kecil hingga keluar kaldunya, buang busanya.
1. Tumisan bumbu: - Panaskan minyak goreng, tumis bumbu halus + bumbu A hingga harum. Matikan kompor.
1. Masukkan tumisan bumbu ke dalam rebusan ayam, tambahkan sesuai selera garam, lada, gula, kaldu bubuk. Masak hingga ayam empuk.
1. Jika ayam sudah empuk, panaskan minyak goreng, goreng ayam hingga kecoklatan, angkat, lalu suir.
1. Tata soto dalam mangkuk: - Bihun + kol + telur rebus + ayam suir + kentang, lalu siram dengan kuah yg panas (hati-hati), beri bawang merah goreng + sedikit perasan jeruk nipis🤤🤤. Sajikan.
1. Photo hanya saran penyajian, ditambah sedikit irisan tomat dan daun bawang (warnanya tambah cakep)🤩




Ternyata resep soto ayam yang enak sederhana ini mudah banget ya! Kita semua mampu menghidangkannya. Resep soto ayam Sangat cocok banget buat kamu yang baru akan belajar memasak maupun juga untuk kamu yang sudah lihai dalam memasak.

Tertarik untuk mencoba bikin resep soto ayam mantab tidak rumit ini? Kalau kamu ingin, ayo kamu segera siapin alat dan bahannya, lalu bikin deh Resep soto ayam yang nikmat dan tidak rumit ini. Betul-betul gampang kan. 

Maka, ketimbang kamu berlama-lama, maka kita langsung saja hidangkan resep soto ayam ini. Dijamin kalian tak akan nyesel membuat resep soto ayam lezat tidak rumit ini! Selamat berkreasi dengan resep soto ayam nikmat simple ini di rumah kalian sendiri,ya!.

