---
description: "Cara memasak Coto Ayam yang enak Untuk Jualan"
title: "Cara memasak Coto Ayam yang enak Untuk Jualan"
slug: 49-cara-memasak-coto-ayam-yang-enak-untuk-jualan
date: 2021-07-06T22:04:07.592Z
image: https://img-global.cpcdn.com/recipes/e665170785947757/680x482cq70/coto-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e665170785947757/680x482cq70/coto-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e665170785947757/680x482cq70/coto-ayam-foto-resep-utama.jpg
author: Cecelia Harvey
ratingvalue: 3
reviewcount: 11
recipeingredient:
- "1 ekor ayam"
- "2 L air untuk presto"
- "1 L air cucian beras"
- "100 gr kacang tanah sangrai dihaluskan"
- "1 sdm garam"
- "1/2 sdt gula pasir"
- "1 sdt kaldu bubuk"
- " Bumbu halus"
- "8 siung bawang merah"
- "5 siung bawang putih"
- "4 butir kemiri"
- "1/2 sdm ketumbar bubuk disangrai"
- "1/2 sdm jintan bubuk disangrai"
- "1 sdt lada bubuk"
- "3 batang serai ambil putihnya iris halus"
- "2 sdm minyak sayur"
- " Bumbu daun"
- "5 cm jahe digeprek"
- "5 cm lengkuas digeprek"
- "2 batang serai digeprek"
- "3 lembar daun jeruk"
- "3 lembar daun salam"
recipeinstructions:
- "Masukkan 2 L air dan semua bahan bumbu daun pada panci presto. Kemudian, presto 1 ekor ayam yang telah dipotong menjadi 8 bagian. Setelah dipresto, tiriskan ayam dan biarkan pada suhu ruang. Potong kecil/suir ayam."
- "Blender semua bahan bumbu halus. Panaskan 2 sdm minyak sayur dan tumis bumbu halus hingga wangi."
- "Didihkan kembali air kaldu ayam. Masukkan bumbu yang telah ditumis, aduk rata."
- "Tuang air cucian beras dan aduk kembali hingga rata."
- "Masukkan kacang yang telah dihaluskan, ayam yang telah dipotong kecil/disuir, garam, gula pasir dan kaldu bubuk. Aduk lagi hingga rata."
- "Sajikan coto ayam sesuai selera. Selamat menikmati."
categories:
- Resep
tags:
- coto
- ayam

katakunci: coto ayam 
nutrition: 263 calories
recipecuisine: Indonesian
preptime: "PT18M"
cooktime: "PT38M"
recipeyield: "3"
recipecategory: Lunch

---


![Coto Ayam](https://img-global.cpcdn.com/recipes/e665170785947757/680x482cq70/coto-ayam-foto-resep-utama.jpg)

Sebagai seorang ibu, menyediakan masakan lezat pada keluarga adalah hal yang menggembirakan untuk anda sendiri. Peran seorang istri Tidak cuman mengurus rumah saja, tapi kamu pun harus memastikan kebutuhan gizi terpenuhi dan santapan yang dikonsumsi orang tercinta mesti menggugah selera.

Di waktu  saat ini, kamu sebenarnya dapat mengorder hidangan praktis walaupun tidak harus susah mengolahnya dulu. Tetapi banyak juga mereka yang memang ingin memberikan yang terbaik bagi orang yang dicintainya. Karena, memasak yang dibuat sendiri akan jauh lebih higienis dan bisa menyesuaikan sesuai makanan kesukaan keluarga. 



Apakah anda adalah seorang penikmat coto ayam?. Asal kamu tahu, coto ayam merupakan makanan khas di Nusantara yang sekarang disenangi oleh setiap orang dari hampir setiap daerah di Indonesia. Kita bisa memasak coto ayam olahan sendiri di rumahmu dan pasti jadi makanan favoritmu di akhir pekan.

Anda jangan bingung untuk mendapatkan coto ayam, lantaran coto ayam mudah untuk didapatkan dan juga kita pun dapat memasaknya sendiri di rumah. coto ayam boleh diolah lewat beraneka cara. Saat ini ada banyak sekali cara kekinian yang menjadikan coto ayam semakin enak.

Resep coto ayam juga gampang sekali dihidangkan, lho. Kamu tidak perlu ribet-ribet untuk memesan coto ayam, sebab Kalian mampu menyiapkan sendiri di rumah. Bagi Kalian yang mau menyajikannya, inilah cara membuat coto ayam yang mantab yang bisa Anda coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Coto Ayam:

1. Gunakan 1 ekor ayam
1. Siapkan 2 L air untuk presto
1. Gunakan 1 L air cucian beras
1. Gunakan 100 gr kacang tanah sangrai (dihaluskan)
1. Gunakan 1 sdm garam
1. Gunakan 1/2 sdt gula pasir
1. Siapkan 1 sdt kaldu bubuk
1. Gunakan  Bumbu halus:
1. Gunakan 8 siung bawang merah
1. Sediakan 5 siung bawang putih
1. Ambil 4 butir kemiri
1. Gunakan 1/2 sdm ketumbar bubuk (disangrai)
1. Ambil 1/2 sdm jintan bubuk (disangrai)
1. Ambil 1 sdt lada bubuk
1. Ambil 3 batang serai (ambil putihnya, iris halus)
1. Ambil 2 sdm minyak sayur
1. Gunakan  Bumbu daun:
1. Sediakan 5 cm jahe (digeprek)
1. Ambil 5 cm lengkuas (digeprek)
1. Siapkan 2 batang serai (digeprek)
1. Sediakan 3 lembar daun jeruk
1. Sediakan 3 lembar daun salam




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Coto Ayam:

1. Masukkan 2 L air dan semua bahan bumbu daun pada panci presto. Kemudian, presto 1 ekor ayam yang telah dipotong menjadi 8 bagian. Setelah dipresto, tiriskan ayam dan biarkan pada suhu ruang. Potong kecil/suir ayam.
1. Blender semua bahan bumbu halus. Panaskan 2 sdm minyak sayur dan tumis bumbu halus hingga wangi.
1. Didihkan kembali air kaldu ayam. Masukkan bumbu yang telah ditumis, aduk rata.
1. Tuang air cucian beras dan aduk kembali hingga rata.
1. Masukkan kacang yang telah dihaluskan, ayam yang telah dipotong kecil/disuir, garam, gula pasir dan kaldu bubuk. Aduk lagi hingga rata.
1. Sajikan coto ayam sesuai selera. Selamat menikmati.




Wah ternyata cara membuat coto ayam yang nikamt tidak rumit ini gampang banget ya! Kamu semua mampu membuatnya. Resep coto ayam Sangat cocok banget buat kita yang sedang belajar memasak maupun untuk anda yang telah jago dalam memasak.

Apakah kamu mau mencoba bikin resep coto ayam mantab sederhana ini? Kalau anda ingin, ayo kamu segera buruan siapin alat dan bahannya, kemudian buat deh Resep coto ayam yang enak dan simple ini. Benar-benar mudah kan. 

Jadi, ketimbang anda diam saja, hayo kita langsung hidangkan resep coto ayam ini. Dijamin kamu gak akan menyesal sudah buat resep coto ayam enak tidak ribet ini! Selamat berkreasi dengan resep coto ayam lezat tidak ribet ini di rumah kalian masing-masing,ya!.

