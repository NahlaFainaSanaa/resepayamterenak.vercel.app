---
description: "Cara membuat Soto ayam yang nikmat Untuk Jualan"
title: "Cara membuat Soto ayam yang nikmat Untuk Jualan"
slug: 228-cara-membuat-soto-ayam-yang-nikmat-untuk-jualan
date: 2021-02-25T07:55:40.950Z
image: https://img-global.cpcdn.com/recipes/d7ef7e15648dcbb0/680x482cq70/soto-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d7ef7e15648dcbb0/680x482cq70/soto-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d7ef7e15648dcbb0/680x482cq70/soto-ayam-foto-resep-utama.jpg
author: Victoria Moreno
ratingvalue: 4.6
reviewcount: 3
recipeingredient:
- "1/2 kg ayam"
- " Bumbu halus "
- "5 siung bawang putih"
- "8 siung bawang merah"
- "4 buah kemiri"
- "2 ruas kunyit"
- " Tambahan "
- "2 batang sereh geprek"
- "3 lembar daun salam"
- "6 lembar daun jeruk"
- "1 ruas lengkuas geprek"
- "2 batang daun bawang iris"
- "1 batang seledri iris"
- "1 buah tomat iris sesuai selera"
- "1/2 jeruk nipis"
- "2 sdt Garam"
- "1/2 sdt Gula"
- "1 sdt Lada bubuk"
recipeinstructions:
- "Rebus ayam tidak usah lama2, lalu buang airnya. Rebus kembali."
- "Tumis bumbu halus di atas api sedang, jika sudah harum masukan daun salam, daun jeruk, sereh, lengkuas. Tambahkan 1 gelas belimbing air. Aduk sampai air mendidih. Matikan."
- "Jika rebusan ayam sudah mendidih, masukan bumbu yg sudah di tumis tadi. Aduk."
- "Tambahkan garam, lada, gula. Cek rasa. Matikan kompor."
- "Hidangkan soto di mangkuk, jangan lupa di beri irisan daun bawang, daun seledri, tomat dan perasan jeruk agar tambah segar."
categories:
- Resep
tags:
- soto
- ayam

katakunci: soto ayam 
nutrition: 134 calories
recipecuisine: Indonesian
preptime: "PT10M"
cooktime: "PT57M"
recipeyield: "4"
recipecategory: Lunch

---


![Soto ayam](https://img-global.cpcdn.com/recipes/d7ef7e15648dcbb0/680x482cq70/soto-ayam-foto-resep-utama.jpg)

Selaku seorang wanita, menyajikan hidangan sedap kepada keluarga adalah hal yang sangat menyenangkan bagi kamu sendiri. Peran seorang  wanita Tidak hanya mengatur rumah saja, tetapi anda pun harus menyediakan kebutuhan nutrisi tercukupi dan santapan yang dimakan keluarga tercinta wajib sedap.

Di masa  saat ini, kita sebenarnya bisa memesan masakan instan walaupun tidak harus susah memasaknya dahulu. Tetapi ada juga orang yang memang ingin memberikan yang terlezat untuk orang yang dicintainya. Pasalnya, memasak yang dibuat sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan hidangan tersebut berdasarkan selera keluarga tercinta. 



Mungkinkah anda merupakan seorang penggemar soto ayam?. Tahukah kamu, soto ayam merupakan makanan khas di Nusantara yang saat ini disenangi oleh banyak orang di hampir setiap tempat di Indonesia. Kamu bisa menyajikan soto ayam sendiri di rumahmu dan boleh jadi camilan kegemaranmu di akhir pekanmu.

Kalian jangan bingung untuk menyantap soto ayam, sebab soto ayam gampang untuk ditemukan dan juga kalian pun dapat memasaknya sendiri di rumah. soto ayam dapat dibuat dengan bermacam cara. Kini pun sudah banyak sekali cara kekinian yang membuat soto ayam lebih enak.

Resep soto ayam juga gampang sekali dibuat, lho. Anda tidak usah capek-capek untuk memesan soto ayam, lantaran Kita dapat menghidangkan sendiri di rumah. Bagi Anda yang mau menyajikannya, inilah resep untuk membuat soto ayam yang nikamat yang mampu Anda hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Soto ayam:

1. Ambil 1/2 kg ayam
1. Siapkan  Bumbu halus :
1. Sediakan 5 siung bawang putih
1. Ambil 8 siung bawang merah
1. Ambil 4 buah kemiri
1. Ambil 2 ruas kunyit
1. Siapkan  Tambahan :
1. Siapkan 2 batang sereh (geprek)
1. Ambil 3 lembar daun salam
1. Siapkan 6 lembar daun jeruk
1. Siapkan 1 ruas lengkuas (geprek)
1. Gunakan 2 batang daun bawang (iris)
1. Siapkan 1 batang seledri (iris)
1. Siapkan 1 buah tomat (iris sesuai selera)
1. Ambil 1/2 jeruk nipis
1. Sediakan 2 sdt Garam
1. Sediakan 1/2 sdt Gula
1. Sediakan 1 sdt Lada bubuk




<!--inarticleads2-->

##### Langkah-langkah membuat Soto ayam:

1. Rebus ayam tidak usah lama2, lalu buang airnya. Rebus kembali.
1. Tumis bumbu halus di atas api sedang, jika sudah harum masukan daun salam, daun jeruk, sereh, lengkuas. Tambahkan 1 gelas belimbing air. Aduk sampai air mendidih. Matikan.
1. Jika rebusan ayam sudah mendidih, masukan bumbu yg sudah di tumis tadi. Aduk.
1. Tambahkan garam, lada, gula. Cek rasa. Matikan kompor.
1. Hidangkan soto di mangkuk, jangan lupa di beri irisan daun bawang, daun seledri, tomat dan perasan jeruk agar tambah segar.




Ternyata cara membuat soto ayam yang enak sederhana ini gampang banget ya! Semua orang dapat memasaknya. Cara buat soto ayam Sangat cocok sekali buat kamu yang baru akan belajar memasak maupun untuk kalian yang sudah ahli memasak.

Apakah kamu tertarik mulai mencoba membuat resep soto ayam nikmat tidak rumit ini? Kalau anda ingin, yuk kita segera siapkan alat-alat dan bahannya, lalu bikin deh Resep soto ayam yang mantab dan tidak rumit ini. Sungguh gampang kan. 

Jadi, ketimbang kita berfikir lama-lama, hayo kita langsung saja buat resep soto ayam ini. Pasti kalian gak akan nyesel sudah membuat resep soto ayam nikmat sederhana ini! Selamat berkreasi dengan resep soto ayam nikmat tidak ribet ini di rumah masing-masing,oke!.

