---
description: "Cara memasak Soto Ayam Kampung yang lezat dan Mudah Dibuat"
title: "Cara memasak Soto Ayam Kampung yang lezat dan Mudah Dibuat"
slug: 246-cara-memasak-soto-ayam-kampung-yang-lezat-dan-mudah-dibuat
date: 2021-05-04T20:56:32.588Z
image: https://img-global.cpcdn.com/recipes/b35fd156cd40aaf8/680x482cq70/soto-ayam-kampung-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b35fd156cd40aaf8/680x482cq70/soto-ayam-kampung-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b35fd156cd40aaf8/680x482cq70/soto-ayam-kampung-foto-resep-utama.jpg
author: Richard Sparks
ratingvalue: 4.3
reviewcount: 14
recipeingredient:
- "1 ekor ayam kampung potong cuci dan rebus sebentar utk membuang busanya potong2"
- "2 buah kentang potong dadu"
- "2 liter air matang"
- " Bumbu geprek "
- "2 buah serai"
- "5 cm jahe"
- "3 cm lengkuas"
- "4 lembar daun salam"
- "3 lembar daun jeruk purut"
- " Bumbu halus"
- "10 buah cabe besar"
- "1 ruas kunyit"
- "10 buah bawang merah"
- "8 buah bawang putih"
- "4 buah kemiri sangrai"
- "1 sdm ketumbar sangrai"
- "1/2 sdt merica putih sangrai"
- "secukupnya Minyak goreng"
- " Garam"
- " Gula"
- " Kaldu ayam"
recipeinstructions:
- "Siapkan bahan."
- "Didihkan air dan masukan ayam. Masak. Kemudian tumis bumbu dg api kecil hingga wangi dan agak kekuningan. Masukan ke dalam air dan ayam yg dididihkan."
- "Masak hingga ayam lembut dan beri garam serta bumbu lainnya.  Setelah matang maka bisa lgsg dimakan atau dicampur ke bihun."
categories:
- Resep
tags:
- soto
- ayam
- kampung

katakunci: soto ayam kampung 
nutrition: 251 calories
recipecuisine: Indonesian
preptime: "PT25M"
cooktime: "PT44M"
recipeyield: "2"
recipecategory: Dessert

---


![Soto Ayam Kampung](https://img-global.cpcdn.com/recipes/b35fd156cd40aaf8/680x482cq70/soto-ayam-kampung-foto-resep-utama.jpg)

Selaku seorang istri, mempersiapkan panganan mantab untuk keluarga adalah suatu hal yang menyenangkan bagi anda sendiri. Kewajiban seorang ibu Tidak hanya mengurus rumah saja, tapi kamu pun wajib memastikan kebutuhan gizi tercukupi dan masakan yang dikonsumsi orang tercinta mesti nikmat.

Di zaman  saat ini, kita sebenarnya bisa mengorder masakan jadi meski tidak harus repot memasaknya terlebih dahulu. Tetapi banyak juga orang yang selalu ingin memberikan makanan yang terlezat bagi orang yang dicintainya. Pasalnya, memasak sendiri akan jauh lebih higienis dan bisa menyesuaikan makanan tersebut sesuai selera keluarga tercinta. 



Apakah kamu salah satu penggemar soto ayam kampung?. Asal kamu tahu, soto ayam kampung merupakan makanan khas di Indonesia yang sekarang disenangi oleh orang-orang di hampir setiap daerah di Nusantara. Kamu dapat menghidangkan soto ayam kampung kreasi sendiri di rumahmu dan dapat dijadikan makanan favoritmu di hari libur.

Kamu tidak usah bingung untuk menyantap soto ayam kampung, lantaran soto ayam kampung tidak sulit untuk didapatkan dan kita pun bisa memasaknya sendiri di rumah. soto ayam kampung dapat diolah dengan beragam cara. Kini sudah banyak resep modern yang membuat soto ayam kampung lebih mantap.

Resep soto ayam kampung pun sangat mudah dihidangkan, lho. Kita jangan capek-capek untuk membeli soto ayam kampung, tetapi Kamu mampu menyiapkan ditempatmu. Bagi Kita yang hendak menghidangkannya, di bawah ini adalah cara untuk membuat soto ayam kampung yang enak yang bisa Anda coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Soto Ayam Kampung:

1. Ambil 1 ekor ayam kampung, potong, cuci dan rebus sebentar utk membuang busanya, potong2
1. Sediakan 2 buah kentang, potong dadu
1. Sediakan 2 liter air matang
1. Siapkan  Bumbu geprek :
1. Gunakan 2 buah serai
1. Sediakan 5 cm jahe
1. Ambil 3 cm lengkuas
1. Gunakan 4 lembar daun salam
1. Ambil 3 lembar daun jeruk purut
1. Gunakan  Bumbu halus
1. Gunakan 10 buah cabe besar
1. Sediakan 1 ruas kunyit
1. Ambil 10 buah bawang merah
1. Sediakan 8 buah bawang putih
1. Ambil 4 buah kemiri, sangrai
1. Ambil 1 sdm ketumbar, sangrai
1. Sediakan 1/2 sdt merica putih, sangrai
1. Siapkan secukupnya Minyak goreng
1. Siapkan  Garam
1. Ambil  Gula
1. Sediakan  Kaldu ayam




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Soto Ayam Kampung:

1. Siapkan bahan.
1. Didihkan air dan masukan ayam. Masak. Kemudian tumis bumbu dg api kecil hingga wangi dan agak kekuningan. Masukan ke dalam air dan ayam yg dididihkan.
1. Masak hingga ayam lembut dan beri garam serta bumbu lainnya.  - Setelah matang maka bisa lgsg dimakan atau dicampur ke bihun.




Wah ternyata cara membuat soto ayam kampung yang mantab simple ini gampang banget ya! Semua orang bisa membuatnya. Resep soto ayam kampung Cocok banget buat kamu yang baru belajar memasak atau juga untuk kamu yang sudah pandai dalam memasak.

Apakah kamu ingin mencoba buat resep soto ayam kampung lezat tidak rumit ini? Kalau kamu tertarik, ayo kalian segera buruan menyiapkan peralatan dan bahannya, maka buat deh Resep soto ayam kampung yang lezat dan simple ini. Sangat taidak sulit kan. 

Maka dari itu, ketimbang kita berfikir lama-lama, yuk kita langsung hidangkan resep soto ayam kampung ini. Dijamin kalian tak akan nyesel sudah buat resep soto ayam kampung lezat simple ini! Selamat mencoba dengan resep soto ayam kampung lezat sederhana ini di rumah sendiri,oke!.

