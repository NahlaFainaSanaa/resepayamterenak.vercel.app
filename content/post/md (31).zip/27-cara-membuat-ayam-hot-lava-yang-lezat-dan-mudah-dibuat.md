---
description: "Cara membuat Ayam hot lava yang lezat dan Mudah Dibuat"
title: "Cara membuat Ayam hot lava yang lezat dan Mudah Dibuat"
slug: 27-cara-membuat-ayam-hot-lava-yang-lezat-dan-mudah-dibuat
date: 2021-02-12T06:21:36.228Z
image: https://img-global.cpcdn.com/recipes/19dd22e2258433ed/680x482cq70/ayam-hot-lava-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/19dd22e2258433ed/680x482cq70/ayam-hot-lava-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/19dd22e2258433ed/680x482cq70/ayam-hot-lava-foto-resep-utama.jpg
author: Antonio Harvey
ratingvalue: 4.6
reviewcount: 15
recipeingredient:
- "6 chicken Wings"
- "2 Dau salam"
- " Serai 1 geprek"
- "1/2 Bawang Bombay"
- "1 jeruk nipis"
- "1 batang Dau bawang"
- " Lada bubuk"
- "secukupnya Minyak"
- " Garam"
- " Royco rasa sapi"
- " Gula"
- " Saus hot lava"
- " Bumbu halus"
- "4 siung bawang merah"
- "2 siung bawang putih"
- "2 kemiri"
- "8 cabe keriting"
- "1/3 cahe"
- " Ketumbar"
recipeinstructions:
- "Cuci sayap ayam sampai bersih, rendam ayam dengan jeruk nipis selama 10 menit"
- "Rebus sayap ayam dengan serai yg digeprek,Dau salam 2 lembar,lada bubuk dan dikasih garam secukupnya tunggu selama 15 menit"
- "Haluskan bumbu(bawang merah,bawang putih,jahe dan kemiri) potong daun bawang,cabe,tomat dan bawang bombay"
- "Panaskan minyak,tumis bumbu yg sudah dihaluskan sampai matang,kasih cabe,bawang Bombay dan tomat ketika sudah harum kasih air ½ liter tunggu sampai mendidih kasih garam,Royco,gula, dan saus hot lava"
- "Ketika sudah mendidih dan bumbu sudah tercampur baru masukan sayap ayam tunggu bumbu meresap setelah meresap kasih potongan daun bawang"
- "Setelah dikasih Daun bawang tunggu sebetar lalu angkat"
categories:
- Resep
tags:
- ayam
- hot
- lava

katakunci: ayam hot lava 
nutrition: 249 calories
recipecuisine: Indonesian
preptime: "PT24M"
cooktime: "PT59M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam hot lava](https://img-global.cpcdn.com/recipes/19dd22e2258433ed/680x482cq70/ayam-hot-lava-foto-resep-utama.jpg)

Jika kalian seorang yang hobi memasak, menyediakan olahan menggugah selera bagi keluarga adalah hal yang sangat menyenangkan untuk kita sendiri. Kewajiban seorang ibu Tidak cuman menangani rumah saja, tetapi anda pun wajib memastikan kebutuhan nutrisi tercukupi dan hidangan yang disantap orang tercinta wajib lezat.

Di waktu  saat ini, kamu memang dapat mengorder santapan praktis tanpa harus repot membuatnya dulu. Tapi ada juga mereka yang memang ingin memberikan yang terenak untuk orang tercintanya. Sebab, menyajikan masakan yang dibuat sendiri jauh lebih bersih dan kita pun bisa menyesuaikan hidangan tersebut sesuai dengan selera famili. 



Apakah anda adalah seorang penikmat ayam hot lava?. Tahukah kamu, ayam hot lava adalah makanan khas di Indonesia yang kini digemari oleh banyak orang di berbagai daerah di Indonesia. Anda dapat menyajikan ayam hot lava buatan sendiri di rumah dan boleh jadi santapan favorit di hari liburmu.

Anda tidak usah bingung jika kamu ingin menyantap ayam hot lava, sebab ayam hot lava tidak sukar untuk didapatkan dan kalian pun bisa mengolahnya sendiri di rumah. ayam hot lava dapat dimasak lewat berbagai cara. Saat ini telah banyak sekali cara kekinian yang membuat ayam hot lava semakin lebih lezat.

Resep ayam hot lava pun sangat gampang untuk dibikin, lho. Kalian jangan repot-repot untuk memesan ayam hot lava, tetapi Kamu bisa membuatnya di rumah sendiri. Bagi Anda yang mau menyajikannya, di bawah ini adalah cara membuat ayam hot lava yang mantab yang dapat Anda hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Ayam hot lava:

1. Gunakan 6 chicken Wings
1. Gunakan 2 Dau salam
1. Gunakan  Serai 1 (geprek)
1. Gunakan 1/2 Bawang Bombay
1. Gunakan 1 jeruk nipis
1. Ambil 1 batang Dau bawang
1. Gunakan  Lada bubuk
1. Sediakan secukupnya Minyak
1. Sediakan  Garam
1. Siapkan  Royco rasa sapi
1. Gunakan  Gula
1. Sediakan  Saus hot lava
1. Ambil  Bumbu halus
1. Sediakan 4 siung bawang merah
1. Gunakan 2 siung bawang putih
1. Siapkan 2 kemiri
1. Siapkan 8 cabe keriting
1. Ambil 1/3 cahe
1. Siapkan  Ketumbar




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam hot lava:

1. Cuci sayap ayam sampai bersih, rendam ayam dengan jeruk nipis selama 10 menit
1. Rebus sayap ayam dengan serai yg digeprek,Dau salam 2 lembar,lada bubuk dan dikasih garam secukupnya tunggu selama 15 menit
1. Haluskan bumbu(bawang merah,bawang putih,jahe dan kemiri) potong daun bawang,cabe,tomat dan bawang bombay
1. Panaskan minyak,tumis bumbu yg sudah dihaluskan sampai matang,kasih cabe,bawang Bombay dan tomat ketika sudah harum kasih air ½ liter tunggu sampai mendidih kasih garam,Royco,gula, dan saus hot lava
1. Ketika sudah mendidih dan bumbu sudah tercampur baru masukan sayap ayam tunggu bumbu meresap setelah meresap kasih potongan daun bawang
1. Setelah dikasih Daun bawang tunggu sebetar lalu angkat




Wah ternyata resep ayam hot lava yang lezat simple ini enteng banget ya! Kalian semua bisa memasaknya. Cara Membuat ayam hot lava Sangat sesuai banget untuk kalian yang sedang belajar memasak ataupun untuk kamu yang sudah hebat dalam memasak.

Apakah kamu ingin mencoba bikin resep ayam hot lava enak tidak rumit ini? Kalau mau, yuk kita segera buruan siapin alat-alat dan bahan-bahannya, lantas buat deh Resep ayam hot lava yang lezat dan tidak ribet ini. Sangat mudah kan. 

Oleh karena itu, daripada anda diam saja, yuk kita langsung hidangkan resep ayam hot lava ini. Dijamin kalian tiidak akan nyesel sudah buat resep ayam hot lava mantab sederhana ini! Selamat berkreasi dengan resep ayam hot lava mantab tidak ribet ini di rumah kalian sendiri,ya!.

