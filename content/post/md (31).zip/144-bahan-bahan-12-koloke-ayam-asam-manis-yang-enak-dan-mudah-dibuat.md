---
description: "Bahan-bahan 12. Koloke Ayam Asam Manis yang enak dan Mudah Dibuat"
title: "Bahan-bahan 12. Koloke Ayam Asam Manis yang enak dan Mudah Dibuat"
slug: 144-bahan-bahan-12-koloke-ayam-asam-manis-yang-enak-dan-mudah-dibuat
date: 2021-06-08T12:31:51.868Z
image: https://img-global.cpcdn.com/recipes/d1d1372a20083f37/680x482cq70/12-koloke-ayam-asam-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d1d1372a20083f37/680x482cq70/12-koloke-ayam-asam-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d1d1372a20083f37/680x482cq70/12-koloke-ayam-asam-manis-foto-resep-utama.jpg
author: Michael Walters
ratingvalue: 3.8
reviewcount: 6
recipeingredient:
- " Bahan Utama"
- "500 gr dada ayam potong sesuai selera saya potong kecilkecil"
- "2 siung bawang putih haluskan"
- "1 sdt garam"
- "1/4 sdt merica bubuk"
- " lumuri bumbu ke ayam diamkan sebentar"
- " Bahan pelapis"
- "7 sdm tepung terigu"
- "2 sdm tepung maizena"
- "1 sdt kaldu bubuk"
- "1 sdt garam"
- "1 butir telur kocok lepas"
- " Bahan saus"
- "2 siung bawang putih cincang halus"
- "1 buah bawang bombay potongpotong"
- "7 sdm saus tomat saya 5 sdm  1 buah tomat cincang kasar"
- "2 sdm saus sambal"
- "1 sdm kecap inggris"
- "1/2 gelas air"
- "2 sdm gula pasir"
- "1/2 sdt garam halus"
- "1/2 buah wortel potong korek api"
- "1/2 buah timun buang bijinya lalu potong korek api"
- " Nanas secukupnya potongpotong kecil"
recipeinstructions:
- "Bahan pelapis campur jadi satu, kecuali telur."
- "Masukkan ayam yang telah dilumuri bumbu ke dalam kocokan telur. Lalu masukkan dalam bahan pelapis, sambil cubit-cubit ayam supaya keriting. Pastikan semua ayam tertutup oleh tepung."
- "Goreng ayam dalam minyak panas sampai matang berwarna kuning kecokelatan. Angkat dan tiriskan."
- "Tumis bawang putih dan bombay sampai harum."
- "Masukkan saus tomat, saus sambal, kecap inggris, dan buah tomat yang telah dicincang. Tambahkan air, gula, dan garam."
- "Masukkan wortel, masak sampai agak empuk. Dan saus sedikit mengental."
- "Masukkan timun dan nanas. Masak sebentar. Koreksi rasa."
- "Tuang saus ke ayam yang tadi telah digoreng."
- "Sajikan."
categories:
- Resep
tags:
- 12
- koloke
- ayam

katakunci: 12 koloke ayam 
nutrition: 222 calories
recipecuisine: Indonesian
preptime: "PT13M"
cooktime: "PT45M"
recipeyield: "1"
recipecategory: Dinner

---


![12. Koloke Ayam Asam Manis](https://img-global.cpcdn.com/recipes/d1d1372a20083f37/680x482cq70/12-koloke-ayam-asam-manis-foto-resep-utama.jpg)

Selaku seorang yang hobi memasak, mempersiapkan masakan nikmat buat orang tercinta adalah hal yang menyenangkan untuk kita sendiri. Kewajiban seorang ibu Tidak sekedar menangani rumah saja, namun kamu pun harus memastikan keperluan nutrisi tercukupi dan masakan yang disantap keluarga tercinta mesti mantab.

Di waktu  sekarang, kalian memang mampu memesan santapan instan tidak harus ribet mengolahnya dulu. Namun banyak juga orang yang selalu mau menghidangkan yang terlezat untuk orang yang dicintainya. Karena, memasak sendiri akan jauh lebih higienis dan bisa menyesuaikan hidangan tersebut sesuai dengan masakan kesukaan orang tercinta. 



Mungkinkah kamu seorang penggemar 12. koloke ayam asam manis?. Tahukah kamu, 12. koloke ayam asam manis merupakan sajian khas di Indonesia yang saat ini disukai oleh kebanyakan orang dari hampir setiap daerah di Nusantara. Kalian bisa menyajikan 12. koloke ayam asam manis sendiri di rumahmu dan pasti jadi camilan kegemaranmu di hari libur.

Anda jangan bingung jika kamu ingin mendapatkan 12. koloke ayam asam manis, lantaran 12. koloke ayam asam manis tidak sukar untuk dicari dan juga anda pun bisa memasaknya sendiri di rumah. 12. koloke ayam asam manis dapat diolah lewat berbagai cara. Kini telah banyak banget cara kekinian yang membuat 12. koloke ayam asam manis semakin lebih nikmat.

Resep 12. koloke ayam asam manis pun gampang sekali dibuat, lho. Kamu tidak perlu ribet-ribet untuk memesan 12. koloke ayam asam manis, lantaran Kamu dapat menyajikan ditempatmu. Untuk Kalian yang ingin menghidangkannya, berikut ini cara membuat 12. koloke ayam asam manis yang mantab yang mampu Kita buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan 12. Koloke Ayam Asam Manis:

1. Siapkan  Bahan Utama:
1. Sediakan 500 gr dada ayam, potong sesuai selera (saya potong kecil-kecil)
1. Gunakan 2 siung bawang putih, haluskan
1. Sediakan 1 sdt garam
1. Siapkan 1/4 sdt merica bubuk
1. Gunakan  lumuri bumbu ke ayam, diamkan sebentar
1. Gunakan  Bahan pelapis:
1. Ambil 7 sdm tepung terigu
1. Ambil 2 sdm tepung maizena
1. Ambil 1 sdt kaldu bubuk
1. Siapkan 1 sdt garam
1. Gunakan 1 butir telur kocok lepas
1. Siapkan  Bahan saus:
1. Ambil 2 siung bawang putih, cincang halus
1. Sediakan 1 buah bawang bombay, potong-potong
1. Ambil 7 sdm saus tomat (saya 5 sdm &amp; 1 buah tomat cincang kasar)
1. Ambil 2 sdm saus sambal
1. Siapkan 1 sdm kecap inggris
1. Siapkan 1/2 gelas air
1. Siapkan 2 sdm gula pasir
1. Gunakan 1/2 sdt garam halus
1. Sediakan 1/2 buah wortel, potong korek api
1. Sediakan 1/2 buah timun, buang bijinya lalu potong korek api
1. Sediakan  Nanas secukupnya, potong-potong kecil




<!--inarticleads2-->

##### Cara menyiapkan 12. Koloke Ayam Asam Manis:

1. Bahan pelapis campur jadi satu, kecuali telur.
1. Masukkan ayam yang telah dilumuri bumbu ke dalam kocokan telur. Lalu masukkan dalam bahan pelapis, sambil cubit-cubit ayam supaya keriting. Pastikan semua ayam tertutup oleh tepung.
1. Goreng ayam dalam minyak panas sampai matang berwarna kuning kecokelatan. Angkat dan tiriskan.
1. Tumis bawang putih dan bombay sampai harum.
1. Masukkan saus tomat, saus sambal, kecap inggris, dan buah tomat yang telah dicincang. Tambahkan air, gula, dan garam.
1. Masukkan wortel, masak sampai agak empuk. Dan saus sedikit mengental.
1. Masukkan timun dan nanas. Masak sebentar. Koreksi rasa.
1. Tuang saus ke ayam yang tadi telah digoreng.
1. Sajikan.




Ternyata cara buat 12. koloke ayam asam manis yang lezat sederhana ini mudah sekali ya! Semua orang bisa mencobanya. Cara buat 12. koloke ayam asam manis Sangat sesuai sekali buat kalian yang baru belajar memasak ataupun juga bagi kamu yang sudah pandai memasak.

Apakah kamu ingin mencoba bikin resep 12. koloke ayam asam manis mantab sederhana ini? Kalau kalian tertarik, mending kamu segera menyiapkan alat dan bahannya, lantas bikin deh Resep 12. koloke ayam asam manis yang enak dan tidak rumit ini. Benar-benar mudah kan. 

Oleh karena itu, ketimbang kamu berfikir lama-lama, yuk kita langsung saja hidangkan resep 12. koloke ayam asam manis ini. Pasti kamu tak akan menyesal membuat resep 12. koloke ayam asam manis lezat simple ini! Selamat berkreasi dengan resep 12. koloke ayam asam manis lezat sederhana ini di tempat tinggal kalian masing-masing,ya!.

