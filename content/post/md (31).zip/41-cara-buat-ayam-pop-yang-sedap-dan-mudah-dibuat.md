---
description: "Cara buat Ayam Pop yang sedap dan Mudah Dibuat"
title: "Cara buat Ayam Pop yang sedap dan Mudah Dibuat"
slug: 41-cara-buat-ayam-pop-yang-sedap-dan-mudah-dibuat
date: 2021-01-22T01:22:17.519Z
image: https://img-global.cpcdn.com/recipes/f4c1b51127cb046b/680x482cq70/ayam-pop-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f4c1b51127cb046b/680x482cq70/ayam-pop-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f4c1b51127cb046b/680x482cq70/ayam-pop-foto-resep-utama.jpg
author: Ethel Henry
ratingvalue: 3.2
reviewcount: 10
recipeingredient:
- "1 ekor ayam jantan kampung sy pakai ayam broiler 3 potong"
- "1/2 buah jeruk nipis ambil airnya"
- "5 siung bawang putih"
- "3 cm jahe"
- "2 lembar daun salam"
- "2 iris lengkuas"
- " Air kelapa dari 2 butir kelapa saya pakai Hydro Coco 500ml"
- "100 ml air bila perlu saya skip"
- "1/2 sdm garam"
- "1 sdt merica bubuk"
- "500 ml minyak untuk menggoreng"
recipeinstructions:
- "Haluskan bawang putih dan jahe. (Saya diuleg)"
- "Lumuri ayam dengan jeruk nipis (bebas mau dicuci lagi apa enggak, saya langsung masukin ke dalam panci)"
- "Masukan ke dalam panci : ayam, bumbu halus, daun salam, lengkuas"
- "Masukan ke dalam panci : garam, merica dan air kelapa"
- "Sampai ayam terendam semua. Tambahkan air bila perlu. (saya skip airnya) Ungkep sampai air menyusut."
- "Panaskan minyak, matikan api. Masukan ayam, biarkan beberapa detik."
- "Angkat. Sajikan dengan daun singkong, sambal ayam pop dan gulai sayur."
categories:
- Resep
tags:
- ayam
- pop

katakunci: ayam pop 
nutrition: 282 calories
recipecuisine: Indonesian
preptime: "PT24M"
cooktime: "PT47M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Pop](https://img-global.cpcdn.com/recipes/f4c1b51127cb046b/680x482cq70/ayam-pop-foto-resep-utama.jpg)

Andai kamu seorang yang hobi masak, menyajikan masakan nikmat kepada famili adalah suatu hal yang memuaskan bagi kamu sendiri. Kewajiban seorang  wanita bukan sekadar menangani rumah saja, tetapi kamu pun wajib menyediakan kebutuhan nutrisi terpenuhi dan masakan yang dimakan anak-anak wajib menggugah selera.

Di zaman  saat ini, anda sebenarnya mampu mengorder hidangan siap saji walaupun tidak harus ribet memasaknya dulu. Tapi ada juga lho mereka yang memang ingin menghidangkan yang terbaik bagi orang yang dicintainya. Pasalnya, menghidangkan masakan yang dibuat sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan makanan tersebut sesuai dengan kesukaan keluarga. 



Mungkinkah kamu salah satu penggemar ayam pop?. Asal kamu tahu, ayam pop adalah makanan khas di Nusantara yang saat ini disukai oleh kebanyakan orang di hampir setiap daerah di Nusantara. Anda bisa membuat ayam pop sendiri di rumahmu dan dapat dijadikan makanan kegemaranmu di akhir pekan.

Kita tak perlu bingung jika kamu ingin menyantap ayam pop, lantaran ayam pop sangat mudah untuk didapatkan dan juga kalian pun bisa memasaknya sendiri di rumah. ayam pop boleh diolah lewat bermacam cara. Sekarang telah banyak banget resep modern yang membuat ayam pop semakin enak.

Resep ayam pop juga mudah dibuat, lho. Anda tidak usah capek-capek untuk membeli ayam pop, sebab Kamu mampu menyiapkan ditempatmu. Untuk Kamu yang ingin menghidangkannya, di bawah ini adalah resep menyajikan ayam pop yang nikamat yang bisa Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Ayam Pop:

1. Ambil 1 ekor ayam jantan/ kampung (sy pakai ayam broiler 3 potong)
1. Gunakan 1/2 buah jeruk nipis, ambil airnya
1. Ambil 5 siung bawang putih
1. Siapkan 3 cm jahe
1. Gunakan 2 lembar daun salam
1. Sediakan 2 iris lengkuas
1. Sediakan  Air kelapa dari 2 butir kelapa (saya pakai Hydro Coco 500ml)
1. Siapkan 100 ml air, bila perlu (saya skip)
1. Siapkan 1/2 sdm garam
1. Ambil 1 sdt merica bubuk
1. Sediakan 500 ml minyak untuk menggoreng




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam Pop:

1. Haluskan bawang putih dan jahe. (Saya diuleg)
<img src="https://img-global.cpcdn.com/steps/5371c4609e79477e/160x128cq70/ayam-pop-langkah-memasak-1-foto.jpg" alt="Ayam Pop"><img src="https://img-global.cpcdn.com/steps/519848d9c63a3b1b/160x128cq70/ayam-pop-langkah-memasak-1-foto.jpg" alt="Ayam Pop">1. Lumuri ayam dengan jeruk nipis (bebas mau dicuci lagi apa enggak, saya langsung masukin ke dalam panci)
<img src="https://img-global.cpcdn.com/steps/9c0f763817206c88/160x128cq70/ayam-pop-langkah-memasak-2-foto.jpg" alt="Ayam Pop"><img src="https://img-global.cpcdn.com/steps/330912bc04444e6b/160x128cq70/ayam-pop-langkah-memasak-2-foto.jpg" alt="Ayam Pop">1. Masukan ke dalam panci : ayam, bumbu halus, daun salam, lengkuas
1. Masukan ke dalam panci : garam, merica dan air kelapa
1. Sampai ayam terendam semua. Tambahkan air bila perlu. (saya skip airnya) Ungkep sampai air menyusut.
1. Panaskan minyak, matikan api. Masukan ayam, biarkan beberapa detik.
1. Angkat. Sajikan dengan daun singkong, sambal ayam pop dan gulai sayur.




Ternyata resep ayam pop yang mantab simple ini mudah sekali ya! Kita semua bisa memasaknya. Cara Membuat ayam pop Sesuai sekali untuk kamu yang sedang belajar memasak atau juga bagi kamu yang telah hebat memasak.

Tertarik untuk mencoba membuat resep ayam pop mantab tidak ribet ini? Kalau anda ingin, ayo kamu segera buruan siapkan alat dan bahannya, lalu bikin deh Resep ayam pop yang nikmat dan simple ini. Sungguh gampang kan. 

Jadi, daripada kita berlama-lama, hayo kita langsung sajikan resep ayam pop ini. Pasti anda tak akan nyesel sudah membuat resep ayam pop lezat tidak rumit ini! Selamat mencoba dengan resep ayam pop mantab simple ini di tempat tinggal sendiri,ya!.

