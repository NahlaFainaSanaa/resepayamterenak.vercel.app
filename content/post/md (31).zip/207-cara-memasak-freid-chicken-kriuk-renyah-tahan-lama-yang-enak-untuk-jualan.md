---
description: "Cara memasak Freid chicken kriuk renyah tahan lama yang enak Untuk Jualan"
title: "Cara memasak Freid chicken kriuk renyah tahan lama yang enak Untuk Jualan"
slug: 207-cara-memasak-freid-chicken-kriuk-renyah-tahan-lama-yang-enak-untuk-jualan
date: 2021-01-24T05:02:32.762Z
image: https://img-global.cpcdn.com/recipes/2bcc8372d885cdf6/680x482cq70/freid-chicken-kriuk-renyah-tahan-lama-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2bcc8372d885cdf6/680x482cq70/freid-chicken-kriuk-renyah-tahan-lama-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2bcc8372d885cdf6/680x482cq70/freid-chicken-kriuk-renyah-tahan-lama-foto-resep-utama.jpg
author: Tillie Schmidt
ratingvalue: 4.9
reviewcount: 5
recipeingredient:
- "500 gr ayam potong jadi 8 bagian"
- "250 gr tepung terigu segitiga"
- "Secukupnya Masako rasa apa aja me rasa sapi 12 sdm"
- "1/2 sdt garam  secukupnya"
- "1 sdt soda kue"
- " Air es secukupnya untuk merendam"
- "1 sdm oregano kering opsional"
- "1 sdt ketumbar bubuk"
- "secukupnya Minyak"
- " Bahan Marinasi"
- "1 sachet masako"
- "1 sdt garam"
- "1 sdt ketumbar bubuk"
- "1/4 sdt merica bubuk"
recipeinstructions:
- "Ayam yang sudah dicuci bersih campur dengan bahan marinasi aduk rata. Masukan kulkas min 2 - 3 jam. Klo mau lebih enak semalaman nyimpennya"
- "Campur tepung terigu, masako, merica, oregano, ketumbar, garam. Cek rasa, sisihkan. Siapkan air es yang dicampur soda kue"
- "Ayam yg sudah dimarinasi masukan ke dalam adonan tepung tadi sambil di aduk dengan kedua tangan (jangan ditekan) kurleb 1 menit."
- "Masukan ke dalam air es rendam sebentar lalu angkat dan masukan kembali ke adonan tepung aduk2 lagi (sekitar 2-3 menit) dan pastinya jangan ditekan2 ya nanti keras"
- "Apabila sudah keliatan kriwilnya, siap digoreng dengan api sedang saja ya klo sudah kecoklatan angkat dan siap dihidangkan. (Klo belum mengeras pada saat menggoreng jangan dibolak balik)"
- "Catatan : air es harus dikasih soda kue ya karena ini yg membuat renyahnya tahan lama"
categories:
- Resep
tags:
- freid
- chicken
- kriuk

katakunci: freid chicken kriuk 
nutrition: 261 calories
recipecuisine: Indonesian
preptime: "PT14M"
cooktime: "PT58M"
recipeyield: "4"
recipecategory: Dessert

---


![Freid chicken kriuk renyah tahan lama](https://img-global.cpcdn.com/recipes/2bcc8372d885cdf6/680x482cq70/freid-chicken-kriuk-renyah-tahan-lama-foto-resep-utama.jpg)

Sebagai seorang yang hobi masak, menyajikan masakan mantab buat keluarga tercinta adalah hal yang menggembirakan untuk kamu sendiri. Tanggung jawab seorang istri Tidak sekedar mengatur rumah saja, namun kamu pun harus menyediakan keperluan gizi terpenuhi dan juga masakan yang dimakan anak-anak mesti mantab.

Di zaman  saat ini, kita memang mampu memesan santapan yang sudah jadi tidak harus ribet mengolahnya terlebih dahulu. Tapi banyak juga lho orang yang memang mau menyajikan yang terenak untuk orang tercintanya. Pasalnya, memasak sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan sesuai kesukaan famili. 



Apakah anda merupakan seorang penyuka freid chicken kriuk renyah tahan lama?. Tahukah kamu, freid chicken kriuk renyah tahan lama merupakan sajian khas di Indonesia yang kini disenangi oleh orang-orang dari hampir setiap daerah di Nusantara. Kamu bisa membuat freid chicken kriuk renyah tahan lama sendiri di rumahmu dan boleh dijadikan camilan kesukaanmu di akhir pekan.

Kita tak perlu bingung jika kamu ingin mendapatkan freid chicken kriuk renyah tahan lama, lantaran freid chicken kriuk renyah tahan lama mudah untuk dicari dan juga kita pun boleh menghidangkannya sendiri di tempatmu. freid chicken kriuk renyah tahan lama dapat dibuat lewat beraneka cara. Kini sudah banyak banget resep modern yang menjadikan freid chicken kriuk renyah tahan lama lebih mantap.

Resep freid chicken kriuk renyah tahan lama juga mudah untuk dibuat, lho. Anda jangan capek-capek untuk membeli freid chicken kriuk renyah tahan lama, lantaran Kalian dapat menghidangkan di rumahmu. Untuk Anda yang mau mencobanya, berikut resep untuk membuat freid chicken kriuk renyah tahan lama yang lezat yang bisa Kalian buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Freid chicken kriuk renyah tahan lama:

1. Siapkan 500 gr ayam potong jadi 8 bagian
1. Sediakan 250 gr tepung terigu segitiga
1. Siapkan Secukupnya Masako rasa apa aja (me: rasa sapi 1/2 sdm)
1. Sediakan 1/2 sdt garam / secukupnya
1. Gunakan 1 sdt soda kue
1. Siapkan  Air es secukupnya untuk merendam
1. Ambil 1 sdm oregano kering (opsional)
1. Sediakan 1 sdt ketumbar bubuk
1. Sediakan secukupnya Minyak
1. Sediakan  Bahan Marinasi
1. Ambil 1 sachet masako
1. Sediakan 1 sdt garam
1. Ambil 1 sdt ketumbar bubuk
1. Gunakan 1/4 sdt merica bubuk




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Freid chicken kriuk renyah tahan lama:

1. Ayam yang sudah dicuci bersih campur dengan bahan marinasi aduk rata. Masukan kulkas min 2 - 3 jam. Klo mau lebih enak semalaman nyimpennya
1. Campur tepung terigu, masako, merica, oregano, ketumbar, garam. Cek rasa, sisihkan. Siapkan air es yang dicampur soda kue
1. Ayam yg sudah dimarinasi masukan ke dalam adonan tepung tadi sambil di aduk dengan kedua tangan (jangan ditekan) kurleb 1 menit.
1. Masukan ke dalam air es rendam sebentar lalu angkat dan masukan kembali ke adonan tepung aduk2 lagi (sekitar 2-3 menit) dan pastinya jangan ditekan2 ya nanti keras
1. Apabila sudah keliatan kriwilnya, siap digoreng dengan api sedang saja ya klo sudah kecoklatan angkat dan siap dihidangkan. (Klo belum mengeras pada saat menggoreng jangan dibolak balik)
1. Catatan : air es harus dikasih soda kue ya karena ini yg membuat renyahnya tahan lama




Wah ternyata cara membuat freid chicken kriuk renyah tahan lama yang mantab tidak ribet ini gampang sekali ya! Kamu semua dapat mencobanya. Cara Membuat freid chicken kriuk renyah tahan lama Sesuai banget untuk kita yang baru akan belajar memasak atau juga bagi kalian yang sudah lihai dalam memasak.

Apakah kamu ingin mulai mencoba membikin resep freid chicken kriuk renyah tahan lama mantab tidak rumit ini? Kalau kalian tertarik, ayo kamu segera siapin alat dan bahannya, lantas bikin deh Resep freid chicken kriuk renyah tahan lama yang nikmat dan sederhana ini. Betul-betul taidak sulit kan. 

Oleh karena itu, daripada kamu berlama-lama, hayo kita langsung saja hidangkan resep freid chicken kriuk renyah tahan lama ini. Pasti kalian tiidak akan menyesal sudah membuat resep freid chicken kriuk renyah tahan lama mantab simple ini! Selamat berkreasi dengan resep freid chicken kriuk renyah tahan lama nikmat tidak rumit ini di rumah masing-masing,ya!.

