---
description: "Cara memasak Soto Ayam yang sedap dan Mudah Dibuat"
title: "Cara memasak Soto Ayam yang sedap dan Mudah Dibuat"
slug: 227-cara-memasak-soto-ayam-yang-sedap-dan-mudah-dibuat
date: 2021-05-31T12:09:43.691Z
image: https://img-global.cpcdn.com/recipes/0e103bcecb130943/680x482cq70/soto-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0e103bcecb130943/680x482cq70/soto-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0e103bcecb130943/680x482cq70/soto-ayam-foto-resep-utama.jpg
author: Lydia Rhodes
ratingvalue: 3.9
reviewcount: 6
recipeingredient:
- "1/2 ekor ayam"
- " Kol"
- " Toge Panjang"
- " Bihun Jagung"
- " Daun Bawang"
- "5 siung Bawang Merah"
- "3 siung Bawang Putih"
- "1 ruas Jahe"
- "1 ruas Kunyit"
- "2 lbr Daun Salam"
- "2 lbr Daun Jeruk"
- "1 Serai"
- "1 Lengkuas Geprek"
- "1 sdm Lada Bubuk"
- "secukupnya Gula"
- "secukupnya Garam"
- "secukupnya Penyedap rasa"
recipeinstructions:
- "Sangrai Bawang Merah, Bawang Putih, Jahe, Kunyit Setelah itu Lalu dihaluskan"
- "Tumis Bumbu yg sudah dihaluskan, daun salam, daun jeruk, serai, Lengkuas"
- "Didihkan Air, Lalu Masukkan ayam.. setelah mendidih baru masukkan bumbu yg sudah ditumis"
- "Masukkan gula, garam, lada, dan Penyedap rasa"
- "Setelah semua rasa telah pas, masukkan potongan Daun Bawang"
- "Didihkan Air.. rebus toge panjang, bihun, dan kol"
- "Masukkan bihun, toge panjang, kol, ayam suwir, daun bawang, dan tomat ke dalam mangkok"
- "Soto Ayam siap disajikan"
categories:
- Resep
tags:
- soto
- ayam

katakunci: soto ayam 
nutrition: 201 calories
recipecuisine: Indonesian
preptime: "PT38M"
cooktime: "PT52M"
recipeyield: "3"
recipecategory: Dinner

---


![Soto Ayam](https://img-global.cpcdn.com/recipes/0e103bcecb130943/680x482cq70/soto-ayam-foto-resep-utama.jpg)

Sebagai seorang ibu, mempersiapkan santapan enak bagi orang tercinta merupakan hal yang membahagiakan untuk kamu sendiri. Peran seorang ibu bukan sekedar mengatur rumah saja, namun kamu juga harus menyediakan kebutuhan gizi tercukupi dan masakan yang dimakan anak-anak wajib sedap.

Di era  saat ini, anda sebenarnya mampu mengorder olahan jadi walaupun tanpa harus capek memasaknya terlebih dahulu. Tapi ada juga lho mereka yang selalu ingin memberikan makanan yang terbaik bagi keluarganya. Karena, memasak sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan hidangan tersebut sesuai dengan masakan kesukaan keluarga tercinta. 



Apakah anda salah satu penggemar soto ayam?. Asal kamu tahu, soto ayam adalah makanan khas di Nusantara yang saat ini digemari oleh orang-orang di berbagai daerah di Nusantara. Kalian dapat menghidangkan soto ayam kreasi sendiri di rumahmu dan boleh jadi santapan kesenanganmu di akhir pekan.

Kamu tidak perlu bingung untuk mendapatkan soto ayam, sebab soto ayam sangat mudah untuk didapatkan dan juga anda pun boleh memasaknya sendiri di rumah. soto ayam bisa dimasak lewat bermacam cara. Kini pun telah banyak resep modern yang menjadikan soto ayam lebih enak.

Resep soto ayam pun sangat gampang dibuat, lho. Kamu tidak perlu repot-repot untuk memesan soto ayam, tetapi Kalian bisa membuatnya di rumah sendiri. Untuk Kalian yang hendak menghidangkannya, di bawah ini adalah resep untuk menyajikan soto ayam yang lezat yang mampu Kamu coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Soto Ayam:

1. Sediakan 1/2 ekor ayam
1. Sediakan  Kol
1. Siapkan  Toge Panjang
1. Gunakan  Bihun Jagung
1. Gunakan  Daun Bawang
1. Siapkan 5 siung Bawang Merah
1. Siapkan 3 siung Bawang Putih
1. Siapkan 1 ruas Jahe
1. Ambil 1 ruas Kunyit
1. Gunakan 2 lbr Daun Salam
1. Ambil 2 lbr Daun Jeruk
1. Sediakan 1 Serai
1. Ambil 1 Lengkuas (Geprek)
1. Ambil 1 sdm Lada Bubuk
1. Ambil secukupnya Gula
1. Gunakan secukupnya Garam
1. Gunakan secukupnya Penyedap rasa




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Soto Ayam:

1. Sangrai Bawang Merah, Bawang Putih, Jahe, Kunyit - Setelah itu Lalu dihaluskan
1. Tumis Bumbu yg sudah dihaluskan, daun salam, daun jeruk, serai, Lengkuas
1. Didihkan Air, Lalu Masukkan ayam.. setelah mendidih baru masukkan bumbu yg sudah ditumis
1. Masukkan gula, garam, lada, dan Penyedap rasa
1. Setelah semua rasa telah pas, masukkan potongan Daun Bawang
1. Didihkan Air.. rebus toge panjang, bihun, dan kol
1. Masukkan bihun, toge panjang, kol, ayam suwir, daun bawang, dan tomat ke dalam mangkok
1. Soto Ayam siap disajikan




Wah ternyata cara buat soto ayam yang enak simple ini gampang banget ya! Kamu semua dapat membuatnya. Cara Membuat soto ayam Sangat sesuai banget buat kamu yang baru mau belajar memasak maupun juga untuk kamu yang sudah hebat memasak.

Apakah kamu mau mencoba buat resep soto ayam lezat sederhana ini? Kalau kamu ingin, yuk kita segera buruan siapkan alat-alat dan bahannya, setelah itu bikin deh Resep soto ayam yang nikmat dan tidak rumit ini. Betul-betul gampang kan. 

Oleh karena itu, daripada kalian diam saja, maka kita langsung sajikan resep soto ayam ini. Pasti kamu gak akan nyesel sudah membuat resep soto ayam enak tidak ribet ini! Selamat berkreasi dengan resep soto ayam mantab simple ini di tempat tinggal kalian sendiri,ya!.

