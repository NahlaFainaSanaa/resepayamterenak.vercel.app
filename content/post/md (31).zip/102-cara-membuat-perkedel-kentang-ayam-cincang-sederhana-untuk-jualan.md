---
description: "Cara membuat Perkedel Kentang Ayam Cincang Sederhana Untuk Jualan"
title: "Cara membuat Perkedel Kentang Ayam Cincang Sederhana Untuk Jualan"
slug: 102-cara-membuat-perkedel-kentang-ayam-cincang-sederhana-untuk-jualan
date: 2021-02-08T09:03:16.354Z
image: https://img-global.cpcdn.com/recipes/59f65c91ff0ed55e/680x482cq70/perkedel-kentang-ayam-cincang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/59f65c91ff0ed55e/680x482cq70/perkedel-kentang-ayam-cincang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/59f65c91ff0ed55e/680x482cq70/perkedel-kentang-ayam-cincang-foto-resep-utama.jpg
author: Ernest Jenkins
ratingvalue: 4.6
reviewcount: 14
recipeingredient:
- "210 gram fillet dada ayam"
- "1340 gram kentang mentah"
- "4 batang daun seledri ambil bagian atasnya aja iris2 halus"
- "1 butir telur ocok lepas utk adonan perkedel"
- "1 butir telur dan 2 sdm putih telur kocok lepas utk menggoreng"
- " Bumbu haluskan "
- "1 sdt merica butiran"
- "Sedikit pala"
- "10 siung bawang merah"
- "12 siung bawang putih"
- "1 sdm garam"
- "1 sdt gula pasir"
recipeinstructions:
- "Goreng bawang merah dan bawang putih sampai kekuningan kemudian ulek bersama merica,pala,garam dan gula (lupa fotoin gulanya)"
- "Goreng kentang sampai matang kemudian ulek halus bersama bumbu. Goreng kentang sampai habis dan ulek semua sampai halus"
- "Tumis daging ayam yg udh di chopper (cincang) dgn sedikit minyak sampai matang"
- "Tambahkan daun seledri dan daging ayam yg sdh di tumis,aduk rata"
- "Tambahkan 1 butir telur kocok ke dalam adonan kentang,aduk rata kembali. Lalu bentuk adonan sesuai selera (jadinya 30 perkedel)"
- "Kocok 1 butir telur dan 2 sdm putih telur (sisa bikin kuker) dan tambahkam 1/2 sdt garam,masukkan perkedel ke dalam kocokan telur lalu goreng sampai matang"
- "Sajikan perkedel sbg teman makan soto Banjar atau sebagai lauk atau cemilan"
categories:
- Resep
tags:
- perkedel
- kentang
- ayam

katakunci: perkedel kentang ayam 
nutrition: 184 calories
recipecuisine: Indonesian
preptime: "PT18M"
cooktime: "PT32M"
recipeyield: "3"
recipecategory: Lunch

---


![Perkedel Kentang Ayam Cincang](https://img-global.cpcdn.com/recipes/59f65c91ff0ed55e/680x482cq70/perkedel-kentang-ayam-cincang-foto-resep-utama.jpg)

Andai anda seorang ibu, menyediakan santapan nikmat bagi keluarga tercinta merupakan hal yang sangat menyenangkan bagi kamu sendiri. Tugas seorang ibu Tidak sekadar menjaga rumah saja, tapi kamu pun harus memastikan keperluan gizi tercukupi dan hidangan yang disantap anak-anak wajib mantab.

Di waktu  saat ini, kalian memang bisa membeli santapan instan tidak harus ribet mengolahnya terlebih dahulu. Tapi banyak juga mereka yang memang ingin menyajikan yang terlezat untuk keluarganya. Pasalnya, memasak sendiri akan jauh lebih higienis dan bisa menyesuaikan makanan tersebut berdasarkan makanan kesukaan keluarga tercinta. 



Apakah anda merupakan seorang penyuka perkedel kentang ayam cincang?. Tahukah kamu, perkedel kentang ayam cincang adalah sajian khas di Nusantara yang kini disenangi oleh setiap orang dari berbagai wilayah di Indonesia. Anda bisa membuat perkedel kentang ayam cincang olahan sendiri di rumahmu dan boleh jadi makanan kegemaranmu di akhir pekan.

Kalian tidak perlu bingung untuk memakan perkedel kentang ayam cincang, lantaran perkedel kentang ayam cincang tidak sulit untuk ditemukan dan kamu pun dapat mengolahnya sendiri di rumah. perkedel kentang ayam cincang boleh dibuat dengan bermacam cara. Sekarang ada banyak resep modern yang membuat perkedel kentang ayam cincang lebih mantap.

Resep perkedel kentang ayam cincang juga gampang sekali untuk dibikin, lho. Kamu jangan repot-repot untuk memesan perkedel kentang ayam cincang, karena Kamu bisa membuatnya di rumah sendiri. Untuk Kita yang hendak mencobanya, inilah cara untuk membuat perkedel kentang ayam cincang yang enak yang bisa Kamu coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Perkedel Kentang Ayam Cincang:

1. Siapkan 210 gram fillet dada ayam
1. Siapkan 1340 gram kentang (mentah)
1. Siapkan 4 batang daun seledri ambil bagian atasnya aja iris2 halus
1. Sediakan 1 butir telur ocok lepas utk adonan perkedel
1. Siapkan 1 butir telur dan 2 sdm putih telur kocok lepas utk menggoreng
1. Siapkan  Bumbu haluskan :
1. Ambil 1 sdt merica butiran
1. Gunakan Sedikit pala
1. Sediakan 10 siung bawang merah
1. Sediakan 12 siung bawang putih
1. Ambil 1 sdm garam
1. Sediakan 1 sdt gula pasir




<!--inarticleads2-->

##### Cara membuat Perkedel Kentang Ayam Cincang:

1. Goreng bawang merah dan bawang putih sampai kekuningan kemudian ulek bersama merica,pala,garam dan gula (lupa fotoin gulanya)
1. Goreng kentang sampai matang kemudian ulek halus bersama bumbu. Goreng kentang sampai habis dan ulek semua sampai halus
1. Tumis daging ayam yg udh di chopper (cincang) dgn sedikit minyak sampai matang
1. Tambahkan daun seledri dan daging ayam yg sdh di tumis,aduk rata
1. Tambahkan 1 butir telur kocok ke dalam adonan kentang,aduk rata kembali. Lalu bentuk adonan sesuai selera (jadinya 30 perkedel)
1. Kocok 1 butir telur dan 2 sdm putih telur (sisa bikin kuker) dan tambahkam 1/2 sdt garam,masukkan perkedel ke dalam kocokan telur lalu goreng sampai matang
1. Sajikan perkedel sbg teman makan soto Banjar atau sebagai lauk atau cemilan




Wah ternyata cara membuat perkedel kentang ayam cincang yang enak tidak rumit ini enteng sekali ya! Kalian semua mampu memasaknya. Cara buat perkedel kentang ayam cincang Sesuai banget buat anda yang baru mau belajar memasak atau juga untuk kamu yang sudah jago memasak.

Apakah kamu mau mulai mencoba buat resep perkedel kentang ayam cincang lezat simple ini? Kalau anda mau, mending kamu segera menyiapkan alat dan bahan-bahannya, setelah itu bikin deh Resep perkedel kentang ayam cincang yang lezat dan tidak rumit ini. Sungguh taidak sulit kan. 

Oleh karena itu, ketimbang kita berfikir lama-lama, ayo langsung aja sajikan resep perkedel kentang ayam cincang ini. Dijamin kalian gak akan nyesel sudah bikin resep perkedel kentang ayam cincang enak tidak ribet ini! Selamat mencoba dengan resep perkedel kentang ayam cincang nikmat tidak rumit ini di rumah kalian masing-masing,oke!.

