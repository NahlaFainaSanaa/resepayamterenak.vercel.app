---
description: "Resep memasak Ayam bakar Wong solo yang lezat dan Mudah Dibuat"
title: "Resep memasak Ayam bakar Wong solo yang lezat dan Mudah Dibuat"
slug: 304-resep-memasak-ayam-bakar-wong-solo-yang-lezat-dan-mudah-dibuat
date: 2021-01-19T23:41:48.658Z
image: https://img-global.cpcdn.com/recipes/af7ffaebc08b265f/680x482cq70/ayam-bakar-wong-solo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/af7ffaebc08b265f/680x482cq70/ayam-bakar-wong-solo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/af7ffaebc08b265f/680x482cq70/ayam-bakar-wong-solo-foto-resep-utama.jpg
author: Frank Griffith
ratingvalue: 4.2
reviewcount: 6
recipeingredient:
- " Bumbu Ayam ungkep "
- "8 potong ayam bagian paha"
- "1500 ml air matang"
- "1 batang serai aku skip"
- "4 sdt garam"
- "1 sdt kaldu jamur"
- "3 ruas kunyit haluskan"
- "10 bh bawang putih haluskan"
- "5 bh bawang merah haluskan tambahan"
- "3 ruas jahe haluskan skip"
- " Bumbu olesan"
- "5 bawang merah"
- "5 bawang outih"
- "3 cabe merah besar"
- "5 sdm gula merah sisir"
- "1 sdm margarin untuk numis"
- "2 sdm minyak goreng"
- "1 sdt kaldu jamur dan garam"
- "50 ml Air"
- " Bahan olesan"
- " Kecap air"
recipeinstructions:
- "Cuci bersih ayam, beri jeruk nipis dan garam. Marinasi 30 menit, bilas kembali, blender bumbu ayam ungkep. Kemudian tumis hingga harum,tambahkan daun jeruk"
- "Masukkan ayam,air,tutup wajan dan ungkep hingga matang. Jangan lupa aduk2"
- "Sambil nunggu ungkep ayam, kita bikin bumbu olesan bakarannya. Haluskan bumbu olesnya (kecuali margarin dan air) dg blender, Lalu Lelehkan margarin, tumis bumbu oles hingga wangi, tambahkan air, tumis hingga mengental. Angkat"
- "Pindahkan bumbu oles yg sudah ditumis dlm wadah, tambahkan kecap manis dan 3 sdm air. Aduk rata (maaf ye bun. Gambarnya campur Sama pentol bakar, wkwkwk bakarnya barengan. Biar baranya sekalian🤣🤣)"
- "Siapkan grill pan/alat bakarannya/teflon. Olesi dg sedikit margarin. Panggang/bakar sambil di oles2 sisa bumbunya smp ada gosong2nya"
categories:
- Resep
tags:
- ayam
- bakar
- wong

katakunci: ayam bakar wong 
nutrition: 279 calories
recipecuisine: Indonesian
preptime: "PT25M"
cooktime: "PT31M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam bakar Wong solo](https://img-global.cpcdn.com/recipes/af7ffaebc08b265f/680x482cq70/ayam-bakar-wong-solo-foto-resep-utama.jpg)

Selaku seorang orang tua, menyajikan santapan nikmat pada famili adalah hal yang menyenangkan bagi kita sendiri. Peran seorang  wanita bukan sekedar menjaga rumah saja, namun kamu juga wajib menyediakan keperluan gizi tercukupi dan juga panganan yang dikonsumsi orang tercinta harus mantab.

Di waktu  sekarang, kamu memang dapat memesan santapan praktis walaupun tidak harus repot mengolahnya terlebih dahulu. Namun banyak juga lho orang yang memang ingin memberikan hidangan yang terenak bagi orang yang dicintainya. Sebab, menghidangkan masakan sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan hidangan tersebut sesuai dengan selera famili. 



Apakah kamu salah satu penikmat ayam bakar wong solo?. Asal kamu tahu, ayam bakar wong solo adalah hidangan khas di Indonesia yang saat ini disenangi oleh orang-orang dari berbagai tempat di Indonesia. Kalian dapat memasak ayam bakar wong solo kreasi sendiri di rumah dan pasti jadi camilan kegemaranmu di hari libur.

Kita tak perlu bingung jika kamu ingin memakan ayam bakar wong solo, sebab ayam bakar wong solo tidak sulit untuk dicari dan kita pun bisa memasaknya sendiri di tempatmu. ayam bakar wong solo boleh dibuat dengan berbagai cara. Kini telah banyak resep kekinian yang menjadikan ayam bakar wong solo semakin mantap.

Resep ayam bakar wong solo pun mudah untuk dibuat, lho. Kita tidak perlu capek-capek untuk membeli ayam bakar wong solo, karena Kamu dapat membuatnya di rumah sendiri. Bagi Kamu yang hendak menghidangkannya, di bawah ini adalah cara untuk menyajikan ayam bakar wong solo yang lezat yang bisa Kalian buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Ayam bakar Wong solo:

1. Sediakan  🌻Bumbu Ayam ungkep :
1. Ambil 8 potong ayam bagian paha
1. Gunakan 1500 ml air matang
1. Ambil 1 batang serai (aku skip)
1. Ambil 4 sdt garam
1. Sediakan 1 sdt kaldu jamur
1. Ambil 3 ruas kunyit haluskan
1. Sediakan 10 bh bawang putih haluskan
1. Gunakan 5 bh bawang merah haluskan (tambahan)
1. Gunakan 3 ruas jahe haluskan (skip)
1. Gunakan  🌻Bumbu olesan
1. Ambil 5 bawang merah
1. Gunakan 5 bawang outih
1. Ambil 3 cabe merah besar
1. Gunakan 5 sdm gula merah sisir
1. Sediakan 1 sdm margarin untuk numis
1. Gunakan 2 sdm minyak goreng
1. Ambil 1 sdt kaldu jamur dan garam
1. Sediakan 50 ml Air
1. Ambil  🌻Bahan olesan
1. Sediakan  Kecap, air




<!--inarticleads2-->

##### Cara menyiapkan Ayam bakar Wong solo:

1. Cuci bersih ayam, beri jeruk nipis dan garam. Marinasi 30 menit, bilas kembali, blender bumbu ayam ungkep. Kemudian tumis hingga harum,tambahkan daun jeruk
1. Masukkan ayam,air,tutup wajan dan ungkep hingga matang. Jangan lupa aduk2
1. Sambil nunggu ungkep ayam, kita bikin bumbu olesan bakarannya. Haluskan bumbu olesnya (kecuali margarin dan air) dg blender, Lalu Lelehkan margarin, tumis bumbu oles hingga wangi, tambahkan air, tumis hingga mengental. Angkat
1. Pindahkan bumbu oles yg sudah ditumis dlm wadah, tambahkan kecap manis dan 3 sdm air. Aduk rata (maaf ye bun. Gambarnya campur Sama pentol bakar, wkwkwk bakarnya barengan. Biar baranya sekalian🤣🤣)
1. Siapkan grill pan/alat bakarannya/teflon. Olesi dg sedikit margarin. Panggang/bakar sambil di oles2 sisa bumbunya smp ada gosong2nya




Ternyata cara buat ayam bakar wong solo yang mantab tidak ribet ini gampang sekali ya! Kamu semua dapat memasaknya. Cara buat ayam bakar wong solo Sangat cocok sekali buat anda yang baru akan belajar memasak ataupun untuk kalian yang sudah lihai dalam memasak.

Tertarik untuk mencoba membikin resep ayam bakar wong solo lezat sederhana ini? Kalau anda mau, ayo kalian segera buruan siapin peralatan dan bahan-bahannya, maka bikin deh Resep ayam bakar wong solo yang nikmat dan tidak rumit ini. Sangat mudah kan. 

Maka dari itu, daripada kita berfikir lama-lama, ayo langsung aja bikin resep ayam bakar wong solo ini. Dijamin kamu gak akan menyesal membuat resep ayam bakar wong solo enak sederhana ini! Selamat berkreasi dengan resep ayam bakar wong solo nikmat simple ini di rumah masing-masing,ya!.

