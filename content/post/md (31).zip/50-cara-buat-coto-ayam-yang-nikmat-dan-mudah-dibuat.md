---
description: "Cara buat Coto Ayam yang nikmat dan Mudah Dibuat"
title: "Cara buat Coto Ayam yang nikmat dan Mudah Dibuat"
slug: 50-cara-buat-coto-ayam-yang-nikmat-dan-mudah-dibuat
date: 2021-04-11T15:10:13.398Z
image: https://img-global.cpcdn.com/recipes/a098016465b6be4d/680x482cq70/coto-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a098016465b6be4d/680x482cq70/coto-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a098016465b6be4d/680x482cq70/coto-ayam-foto-resep-utama.jpg
author: Barbara Fields
ratingvalue: 5
reviewcount: 5
recipeingredient:
- "500 gr daging ayam bagian dada dan paha"
- "1,5 L air cucian beras ke 2 dan 3"
- "5 cm kayu manis"
- "4 helai daun salam"
- "4 helai daun jeruk"
- "Secukupnya minyak untuk menumis bumbu"
- "Secukupnya garam dan gula"
- " Bumbu halus "
- "250 gr kacang sangrai"
- "5 siung bawang putih"
- "10 butir bawang merah"
- "3 butir kemiri disangrai"
- "Seruas jahe"
- "Seruas lengkuas"
- "5 batang sereh uk kecil ambil putihnya sajadiiris tipis"
- "1 sdt lada"
- "2 sdt ketumbar bubuk"
- "1 sdt jinten bubuk"
- "1 sdt pala bubuk"
- "200 ml air"
- " Bahan pelengkap "
- " Jeruk nipis"
- " Bawang goreng"
- " Daun bawang iris tipis"
recipeinstructions:
- "Siapkan bahan-bahan yang diperlukan."
- "Potong kotak atau sesuai selera daging ayam, lalu beri jeruk nipis, biarkan selama 10 menit, lalu bilas air bersih. Masukkan kedalam air cucian beras yg sudah dipanaskan. Masak sampai empuk."
- "Haluskan kacang, dan iris bahan bumbu agar lebih mudah menghaluskan, tambahkan air lalu blender semuanya hingga halus."
- "Panaskan minyak, lalu tumis bumbu halus beserta daun salam, daun jeruk, dan kayu manis. Masak hingga matang. Lalu masukkan kedalam rebusan ayam, beri gula dan garam secukupnya."
- "Masak hingga kuah menyusut dan mengental, cek rasa. Matikan api, sajikan dengan bahan pelengkap."
categories:
- Resep
tags:
- coto
- ayam

katakunci: coto ayam 
nutrition: 215 calories
recipecuisine: Indonesian
preptime: "PT29M"
cooktime: "PT52M"
recipeyield: "2"
recipecategory: Dessert

---


![Coto Ayam](https://img-global.cpcdn.com/recipes/a098016465b6be4d/680x482cq70/coto-ayam-foto-resep-utama.jpg)

Sebagai seorang orang tua, mempersiapkan olahan mantab pada keluarga merupakan hal yang memuaskan untuk kamu sendiri. Tugas seorang ibu bukan sekedar menangani rumah saja, tapi kamu pun wajib menyediakan kebutuhan gizi tercukupi dan juga hidangan yang disantap anak-anak harus lezat.

Di zaman  sekarang, kamu memang bisa memesan hidangan jadi walaupun tidak harus capek mengolahnya dulu. Tetapi ada juga orang yang memang mau memberikan yang terlezat untuk keluarganya. Sebab, menyajikan masakan yang dibuat sendiri jauh lebih bersih dan kita pun bisa menyesuaikan sesuai dengan kesukaan keluarga tercinta. 



Mungkinkah anda merupakan seorang penikmat coto ayam?. Tahukah kamu, coto ayam adalah hidangan khas di Nusantara yang saat ini digemari oleh orang-orang dari berbagai wilayah di Indonesia. Kita dapat membuat coto ayam hasil sendiri di rumahmu dan boleh dijadikan makanan kesenanganmu di hari libur.

Kalian tidak usah bingung untuk mendapatkan coto ayam, lantaran coto ayam gampang untuk dicari dan juga anda pun dapat memasaknya sendiri di rumah. coto ayam bisa dimasak dengan berbagai cara. Sekarang sudah banyak cara kekinian yang menjadikan coto ayam semakin lebih lezat.

Resep coto ayam pun gampang untuk dibikin, lho. Anda tidak perlu ribet-ribet untuk membeli coto ayam, lantaran Anda mampu menyiapkan di rumah sendiri. Bagi Kamu yang akan menghidangkannya, inilah resep untuk menyajikan coto ayam yang lezat yang mampu Kalian buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Coto Ayam:

1. Sediakan 500 gr daging ayam bagian dada dan paha
1. Gunakan 1,5 L air cucian beras ke 2 dan 3
1. Gunakan 5 cm kayu manis
1. Ambil 4 helai daun salam
1. Sediakan 4 helai daun jeruk
1. Gunakan Secukupnya minyak untuk menumis bumbu
1. Sediakan Secukupnya garam dan gula
1. Sediakan  Bumbu halus :
1. Sediakan 250 gr kacang sangrai
1. Gunakan 5 siung bawang putih
1. Gunakan 10 butir bawang merah
1. Siapkan 3 butir kemiri, disangrai
1. Ambil Seruas jahe
1. Sediakan Seruas lengkuas
1. Gunakan 5 batang sereh uk kecil, ambil putihnya saja,diiris tipis
1. Gunakan 1 sdt lada
1. Ambil 2 sdt ketumbar bubuk
1. Sediakan 1 sdt jinten bubuk
1. Gunakan 1 sdt pala bubuk
1. Sediakan 200 ml air
1. Ambil  Bahan pelengkap :
1. Sediakan  Jeruk nipis
1. Gunakan  Bawang goreng
1. Siapkan  Daun bawang, iris tipis




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Coto Ayam:

1. Siapkan bahan-bahan yang diperlukan.
1. Potong kotak atau sesuai selera daging ayam, lalu beri jeruk nipis, biarkan selama 10 menit, lalu bilas air bersih. Masukkan kedalam air cucian beras yg sudah dipanaskan. Masak sampai empuk.
1. Haluskan kacang, dan iris bahan bumbu agar lebih mudah menghaluskan, tambahkan air lalu blender semuanya hingga halus.
1. Panaskan minyak, lalu tumis bumbu halus beserta daun salam, daun jeruk, dan kayu manis. Masak hingga matang. Lalu masukkan kedalam rebusan ayam, beri gula dan garam secukupnya.
1. Masak hingga kuah menyusut dan mengental, cek rasa. Matikan api, sajikan dengan bahan pelengkap.




Ternyata cara membuat coto ayam yang enak sederhana ini enteng sekali ya! Kalian semua mampu mencobanya. Resep coto ayam Sangat sesuai sekali untuk kita yang sedang belajar memasak maupun untuk anda yang telah lihai dalam memasak.

Apakah kamu ingin mulai mencoba bikin resep coto ayam nikmat tidak rumit ini? Kalau kamu tertarik, ayo kalian segera buruan menyiapkan alat-alat dan bahan-bahannya, setelah itu bikin deh Resep coto ayam yang enak dan simple ini. Sungguh gampang kan. 

Oleh karena itu, ketimbang kamu berlama-lama, ayo langsung aja buat resep coto ayam ini. Dijamin kalian gak akan nyesel sudah membuat resep coto ayam mantab sederhana ini! Selamat berkreasi dengan resep coto ayam nikmat sederhana ini di rumah masing-masing,oke!.

