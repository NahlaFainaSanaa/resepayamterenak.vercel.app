---
description: "Cara buat Ampela ayam bumbu manis asam pedas Sederhana Untuk Jualan"
title: "Cara buat Ampela ayam bumbu manis asam pedas Sederhana Untuk Jualan"
slug: 158-cara-buat-ampela-ayam-bumbu-manis-asam-pedas-sederhana-untuk-jualan
date: 2021-06-04T17:36:12.456Z
image: https://img-global.cpcdn.com/recipes/2a2fcea6764c12a4/680x482cq70/ampela-ayam-bumbu-manis-asam-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2a2fcea6764c12a4/680x482cq70/ampela-ayam-bumbu-manis-asam-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2a2fcea6764c12a4/680x482cq70/ampela-ayam-bumbu-manis-asam-pedas-foto-resep-utama.jpg
author: Lula Howell
ratingvalue: 3.6
reviewcount: 9
recipeingredient:
- "10 bji ampela ungkep"
- "4 ptong ayam ungkep"
- " Masako"
- " Garam"
- " Merica"
- "2 sdm air asam jawa"
- " Kecap"
- " Gula merah parut"
- " Daun bawang"
- " Bumbu halus"
- "4 bawang merah"
- "3 bawang putih"
- "1/2 ruas jahe"
- "1/2 ruas kunyit"
- "2 cabai keriting"
recipeinstructions:
- "Goreng ampela dan ayam yg sudah di ungkep terlebih dahulu. Setelah matang lalu tiriskan"
- "Buat bumbu. Ulek semua bahan (bumbu halus) sampai halus lalu tumis sampai wangi."
- "Masukkan 2 sdm air asam jawa,kecap dan parutan gula merahnya."
- "Jgn lupa masukkan garam,merica,masako kedalam bumbu lalu masukkan ampela dan ayam yg sdh digoreng tadi lalu aduk sampai tercampur semua bumbunya"
- "Icip rasanya jika sudah pas masukkan irisan daun bawang. Lalu sajikan"
categories:
- Resep
tags:
- ampela
- ayam
- bumbu

katakunci: ampela ayam bumbu 
nutrition: 177 calories
recipecuisine: Indonesian
preptime: "PT37M"
cooktime: "PT54M"
recipeyield: "4"
recipecategory: Dinner

---


![Ampela ayam bumbu manis asam pedas](https://img-global.cpcdn.com/recipes/2a2fcea6764c12a4/680x482cq70/ampela-ayam-bumbu-manis-asam-pedas-foto-resep-utama.jpg)

Sebagai seorang ibu, menyuguhkan olahan mantab buat orang tercinta adalah hal yang membahagiakan untuk kamu sendiri. Tanggung jawab seorang ibu Tidak saja mengurus rumah saja, tapi anda juga wajib memastikan kebutuhan nutrisi tercukupi dan hidangan yang dimakan anak-anak mesti menggugah selera.

Di masa  saat ini, kita memang dapat mengorder hidangan yang sudah jadi meski tidak harus susah memasaknya dahulu. Tapi ada juga lho mereka yang memang ingin memberikan hidangan yang terenak bagi orang tercintanya. Sebab, memasak yang dibuat sendiri akan jauh lebih bersih dan bisa menyesuaikan sesuai makanan kesukaan orang tercinta. 



Apakah kamu salah satu penikmat ampela ayam bumbu manis asam pedas?. Asal kamu tahu, ampela ayam bumbu manis asam pedas merupakan hidangan khas di Indonesia yang kini disukai oleh setiap orang dari berbagai tempat di Indonesia. Kita dapat menyajikan ampela ayam bumbu manis asam pedas sendiri di rumah dan pasti jadi makanan kesukaanmu di hari libur.

Anda tidak perlu bingung jika kamu ingin mendapatkan ampela ayam bumbu manis asam pedas, sebab ampela ayam bumbu manis asam pedas gampang untuk ditemukan dan juga kamu pun boleh menghidangkannya sendiri di tempatmu. ampela ayam bumbu manis asam pedas boleh dimasak dengan berbagai cara. Kini sudah banyak banget resep modern yang menjadikan ampela ayam bumbu manis asam pedas semakin lebih enak.

Resep ampela ayam bumbu manis asam pedas pun mudah sekali untuk dibuat, lho. Anda jangan capek-capek untuk membeli ampela ayam bumbu manis asam pedas, lantaran Anda mampu menghidangkan di rumahmu. Untuk Kita yang akan mencobanya, di bawah ini adalah cara menyajikan ampela ayam bumbu manis asam pedas yang mantab yang bisa Kalian coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Ampela ayam bumbu manis asam pedas:

1. Siapkan 10 bji ampela ungkep
1. Ambil 4 ptong ayam ungkep
1. Gunakan  Masako
1. Gunakan  Garam
1. Ambil  Merica
1. Siapkan 2 sdm air asam jawa
1. Gunakan  Kecap
1. Sediakan  Gula merah parut
1. Siapkan  Daun bawang
1. Siapkan  Bumbu halus
1. Gunakan 4 bawang merah
1. Gunakan 3 bawang putih
1. Ambil 1/2 ruas jahe
1. Gunakan 1/2 ruas kunyit
1. Ambil 2 cabai keriting




<!--inarticleads2-->

##### Cara membuat Ampela ayam bumbu manis asam pedas:

1. Goreng ampela dan ayam yg sudah di ungkep terlebih dahulu. Setelah matang lalu tiriskan
1. Buat bumbu. Ulek semua bahan (bumbu halus) sampai halus lalu tumis sampai wangi.
1. Masukkan 2 sdm air asam jawa,kecap dan parutan gula merahnya.
1. Jgn lupa masukkan garam,merica,masako kedalam bumbu lalu masukkan ampela dan ayam yg sdh digoreng tadi lalu aduk sampai tercampur semua bumbunya
1. Icip rasanya jika sudah pas masukkan irisan daun bawang. Lalu sajikan




Ternyata cara buat ampela ayam bumbu manis asam pedas yang mantab sederhana ini gampang banget ya! Kita semua bisa menghidangkannya. Cara Membuat ampela ayam bumbu manis asam pedas Sangat cocok sekali buat anda yang sedang belajar memasak atau juga bagi kamu yang sudah hebat dalam memasak.

Apakah kamu ingin mencoba buat resep ampela ayam bumbu manis asam pedas mantab tidak rumit ini? Kalau anda mau, ayo kalian segera siapkan alat dan bahan-bahannya, kemudian bikin deh Resep ampela ayam bumbu manis asam pedas yang mantab dan tidak ribet ini. Benar-benar taidak sulit kan. 

Jadi, daripada anda berfikir lama-lama, ayo langsung aja bikin resep ampela ayam bumbu manis asam pedas ini. Pasti kalian tiidak akan menyesal bikin resep ampela ayam bumbu manis asam pedas lezat sederhana ini! Selamat mencoba dengan resep ampela ayam bumbu manis asam pedas mantab sederhana ini di rumah masing-masing,ya!.

