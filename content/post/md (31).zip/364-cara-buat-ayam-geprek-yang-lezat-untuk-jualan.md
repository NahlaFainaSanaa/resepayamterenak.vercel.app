---
description: "Cara buat Ayam Geprek yang lezat Untuk Jualan"
title: "Cara buat Ayam Geprek yang lezat Untuk Jualan"
slug: 364-cara-buat-ayam-geprek-yang-lezat-untuk-jualan
date: 2021-02-05T04:58:32.349Z
image: https://img-global.cpcdn.com/recipes/4030880ddfd8889d/680x482cq70/ayam-geprek-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4030880ddfd8889d/680x482cq70/ayam-geprek-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4030880ddfd8889d/680x482cq70/ayam-geprek-foto-resep-utama.jpg
author: Lena Anderson
ratingvalue: 3.6
reviewcount: 7
recipeingredient:
- "2 buah dada ayam potong melebar"
- "1 sdt bw putih bubuk"
- "secukupnya Garam  lada"
- " Pelapis basah "
- " Tepung bumbu ayam krispi instan secukupnya  sedikit air es"
- " Pelapis kering "
- "secukupnya Tepung bumbu ayam krispi"
- " Sambal Geprek "
- "3 siung bw putih"
- "5 buah cabe rawit setan"
- "2 buah cabe merah keriting"
- "1/2 sdt kaldu jamur"
- "secukupnya Garam  gula"
recipeinstructions:
- "Lumuri dada ayam dgn bw putih bubuk, garam dan lada. Simpan dikulkas selama 30 menit"
- "Buat adonan kental tepung pelapis basah.   Celup dada ayam ke pelapis basah lalu balur ke pelapis kering sambil dicubit&#34;. Goreng ayam hingga matang &amp; kuning keemasan. Angkat &amp; tiriskan"
- "Panaskan minyak sayur secukupnya.  Ulek kasar bahan sambel geprek beri bumbu lainnya. Siram dgn minyak panas. Aduk   Penyajian : ambil ayam, geprek dgn ulekan, beri sambal diatasnya. Sajikan dgn nasi hangat &amp; lalapan"
categories:
- Resep
tags:
- ayam
- geprek

katakunci: ayam geprek 
nutrition: 266 calories
recipecuisine: Indonesian
preptime: "PT40M"
cooktime: "PT46M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam Geprek](https://img-global.cpcdn.com/recipes/4030880ddfd8889d/680x482cq70/ayam-geprek-foto-resep-utama.jpg)

Selaku seorang istri, menyediakan santapan enak kepada orang tercinta merupakan hal yang membahagiakan bagi anda sendiri. Tugas seorang  wanita bukan cuma menjaga rumah saja, namun anda juga harus memastikan kebutuhan nutrisi tercukupi dan juga panganan yang dimakan keluarga tercinta harus enak.

Di era  saat ini, kamu sebenarnya dapat membeli santapan instan walaupun tidak harus ribet mengolahnya lebih dulu. Namun banyak juga lho orang yang selalu mau menghidangkan yang terlezat bagi orang tercintanya. Karena, menghidangkan masakan sendiri jauh lebih higienis dan bisa menyesuaikan sesuai dengan kesukaan orang tercinta. 



Mungkinkah anda merupakan salah satu penyuka ayam geprek?. Tahukah kamu, ayam geprek adalah makanan khas di Nusantara yang sekarang digemari oleh kebanyakan orang di berbagai wilayah di Nusantara. Kamu bisa menyajikan ayam geprek sendiri di rumah dan boleh jadi makanan kesenanganmu di hari liburmu.

Anda tidak usah bingung jika kamu ingin memakan ayam geprek, karena ayam geprek mudah untuk didapatkan dan juga anda pun bisa mengolahnya sendiri di tempatmu. ayam geprek boleh diolah memalui beragam cara. Saat ini telah banyak sekali resep modern yang menjadikan ayam geprek lebih lezat.

Resep ayam geprek juga sangat gampang untuk dibuat, lho. Kamu tidak perlu ribet-ribet untuk membeli ayam geprek, tetapi Kalian dapat menyiapkan sendiri di rumah. Untuk Anda yang hendak menghidangkannya, berikut cara menyajikan ayam geprek yang nikamat yang bisa Kita hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Ayam Geprek:

1. Sediakan 2 buah dada ayam, potong melebar
1. Ambil 1 sdt bw putih bubuk
1. Sediakan secukupnya Garam &amp; lada
1. Ambil  Pelapis basah :
1. Ambil  Tepung bumbu ayam krispi instan secukupnya + sedikit air es
1. Gunakan  Pelapis kering :
1. Ambil secukupnya Tepung bumbu ayam krispi,
1. Ambil  Sambal Geprek :
1. Ambil 3 siung bw putih
1. Ambil 5 buah cabe rawit setan
1. Gunakan 2 buah cabe merah keriting
1. Gunakan 1/2 sdt kaldu jamur
1. Gunakan secukupnya Garam &amp; gula




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam Geprek:

1. Lumuri dada ayam dgn bw putih bubuk, garam dan lada. Simpan dikulkas selama 30 menit
1. Buat adonan kental tepung pelapis basah.  -  - Celup dada ayam ke pelapis basah lalu balur ke pelapis kering sambil dicubit&#34;. Goreng ayam hingga matang &amp; kuning keemasan. Angkat &amp; tiriskan
1. Panaskan minyak sayur secukupnya.  - Ulek kasar bahan sambel geprek beri bumbu lainnya. Siram dgn minyak panas. Aduk  -  - Penyajian : ambil ayam, geprek dgn ulekan, beri sambal diatasnya. Sajikan dgn nasi hangat &amp; lalapan




Wah ternyata cara membuat ayam geprek yang enak tidak rumit ini gampang sekali ya! Kamu semua bisa membuatnya. Resep ayam geprek Sangat sesuai banget buat kita yang baru belajar memasak maupun juga bagi anda yang sudah lihai dalam memasak.

Apakah kamu tertarik mulai mencoba bikin resep ayam geprek nikmat simple ini? Kalau anda tertarik, ayo kamu segera menyiapkan alat dan bahannya, lalu buat deh Resep ayam geprek yang enak dan tidak ribet ini. Benar-benar taidak sulit kan. 

Maka, daripada kamu berfikir lama-lama, yuk kita langsung saja bikin resep ayam geprek ini. Pasti kalian gak akan nyesel membuat resep ayam geprek mantab tidak rumit ini! Selamat mencoba dengan resep ayam geprek enak tidak ribet ini di tempat tinggal kalian masing-masing,ya!.

