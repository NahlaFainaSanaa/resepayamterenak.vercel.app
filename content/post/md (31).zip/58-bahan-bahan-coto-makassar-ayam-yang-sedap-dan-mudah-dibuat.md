---
description: "Bahan-bahan COTO MAKASSAR (AYAM) yang sedap dan Mudah Dibuat"
title: "Bahan-bahan COTO MAKASSAR (AYAM) yang sedap dan Mudah Dibuat"
slug: 58-bahan-bahan-coto-makassar-ayam-yang-sedap-dan-mudah-dibuat
date: 2021-02-10T21:57:47.880Z
image: https://img-global.cpcdn.com/recipes/fbc3b5bdb95a8cb5/680x482cq70/coto-makassar-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/fbc3b5bdb95a8cb5/680x482cq70/coto-makassar-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/fbc3b5bdb95a8cb5/680x482cq70/coto-makassar-ayam-foto-resep-utama.jpg
author: Stephen Barrett
ratingvalue: 4.1
reviewcount: 5
recipeingredient:
- "1 ekor ayam dipotong kecil"
- "200 gr kacang tanah goreng haluskan"
- "2 lbr daun salam"
- "2 lbr daun jeruk"
- "1 btg daun bawang iris2"
- "1 ruas lengkuas geprek"
- "1 ltr air aku pake air dari cucian beras yg ke 2 dan ke 3"
- "1 potong kecil kayu manis"
- "secukupnya Minyak goreng"
- "secukupnya Garam"
- "secukupnya Kaldu ayam bubuk"
- " Bumbu halus"
- "10 siung bawang merah"
- "6 siung bawah putih"
- "1 ruas jahe"
- "1 ruas lengkuas"
- "10 btg sereh putihnya aja"
- "1 sdt merica bubuk"
- "1 sdm ketumbar bubuk"
- " Pelengkap"
- "Irisan jeruk nipis"
- "Potongan daun bawang"
- " Bawang goreng"
recipeinstructions:
- "Rebus air hingga mendidih"
- "Sebelum bumbu2 dihaluskan sebaiknya ditumis dulu setelah semua bumbu diiris2, agar warna coto nanti bs lebih gelap dan bumbu lebih harum (tips)"
- "Setelah bumbu kecoklatan maka blender hingga halus dan tumis hingga harum. Jangan lupa masukkan daun salam, daun jeruk, lengkuas geprek dan kayu manis"
- "Kemudian masukkan ayam, aduk hingga bumbu meresap ke dalam daging ayam"
- "Jangan lupa masukkan daun bawang"
- "Aduk terus hingga ayam berubah warna agak pucat. Lalu tuang ke dalam panci berisi air yg telah mendidih tadi. (Kelupa foto)"
- "Masukkan kacang goreng halus, garam dan kaldu ayam bubuk. Masak hingga ayam matang."
- "Setelah mendidih dan ayam masak, angkat dan sajikan dengan pelengkap irisan jeruk nipis, irisan daun bawang, dan bawang goreng"
categories:
- Resep
tags:
- coto
- makassar
- ayam

katakunci: coto makassar ayam 
nutrition: 149 calories
recipecuisine: Indonesian
preptime: "PT18M"
cooktime: "PT30M"
recipeyield: "3"
recipecategory: Dessert

---


![COTO MAKASSAR (AYAM)](https://img-global.cpcdn.com/recipes/fbc3b5bdb95a8cb5/680x482cq70/coto-makassar-ayam-foto-resep-utama.jpg)

Sebagai seorang orang tua, menyediakan hidangan nikmat untuk orang tercinta adalah hal yang memuaskan untuk kita sendiri. Tugas seorang  wanita bukan cuma mengurus rumah saja, tetapi anda juga wajib menyediakan keperluan nutrisi tercukupi dan juga santapan yang dimakan orang tercinta wajib enak.

Di masa  saat ini, kalian sebenarnya dapat memesan olahan praktis meski tanpa harus repot mengolahnya dahulu. Namun ada juga mereka yang selalu mau menyajikan yang terlezat untuk orang yang dicintainya. Sebab, memasak sendiri jauh lebih higienis dan kita juga bisa menyesuaikan hidangan tersebut sesuai kesukaan orang tercinta. 



Mungkinkah anda merupakan salah satu penyuka coto makassar (ayam)?. Asal kamu tahu, coto makassar (ayam) merupakan hidangan khas di Indonesia yang kini disukai oleh orang-orang di berbagai tempat di Nusantara. Kalian dapat menyajikan coto makassar (ayam) sendiri di rumah dan boleh dijadikan makanan kesukaanmu di hari libur.

Kalian jangan bingung jika kamu ingin memakan coto makassar (ayam), lantaran coto makassar (ayam) tidak sulit untuk dicari dan juga kita pun dapat membuatnya sendiri di rumah. coto makassar (ayam) dapat dimasak lewat berbagai cara. Kini telah banyak cara modern yang menjadikan coto makassar (ayam) lebih lezat.

Resep coto makassar (ayam) pun mudah sekali dihidangkan, lho. Anda jangan capek-capek untuk memesan coto makassar (ayam), karena Kalian bisa menyiapkan di rumahmu. Untuk Anda yang mau mencobanya, inilah resep membuat coto makassar (ayam) yang lezat yang bisa Kamu hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan COTO MAKASSAR (AYAM):

1. Ambil 1 ekor ayam, dipotong kecil²
1. Sediakan 200 gr kacang tanah goreng, haluskan
1. Gunakan 2 lbr daun salam
1. Ambil 2 lbr daun jeruk
1. Ambil 1 btg daun bawang, iris2
1. Siapkan 1 ruas lengkuas, geprek
1. Ambil 1 ltr air (aku pake air dari cucian beras yg ke 2 dan ke 3)
1. Ambil 1 potong kecil kayu manis
1. Siapkan secukupnya Minyak goreng,
1. Ambil secukupnya Garam,
1. Siapkan secukupnya Kaldu ayam bubuk
1. Sediakan  Bumbu halus
1. Gunakan 10 siung bawang merah
1. Gunakan 6 siung bawah putih
1. Sediakan 1 ruas jahe
1. Siapkan 1 ruas lengkuas
1. Gunakan 10 btg sereh (putihnya aja)
1. Ambil 1 sdt merica bubuk
1. Gunakan 1 sdm ketumbar bubuk
1. Ambil  Pelengkap
1. Sediakan Irisan jeruk nipis
1. Ambil Potongan daun bawang
1. Ambil  Bawang goreng




<!--inarticleads2-->

##### Cara membuat COTO MAKASSAR (AYAM):

1. Rebus air hingga mendidih
1. Sebelum bumbu2 dihaluskan sebaiknya ditumis dulu setelah semua bumbu diiris2, agar warna coto nanti bs lebih gelap dan bumbu lebih harum (tips)
1. Setelah bumbu kecoklatan maka blender hingga halus dan tumis hingga harum. Jangan lupa masukkan daun salam, daun jeruk, lengkuas geprek dan kayu manis
1. Kemudian masukkan ayam, aduk hingga bumbu meresap ke dalam daging ayam
1. Jangan lupa masukkan daun bawang
1. Aduk terus hingga ayam berubah warna agak pucat. Lalu tuang ke dalam panci berisi air yg telah mendidih tadi. (Kelupa foto)
1. Masukkan kacang goreng halus, garam dan kaldu ayam bubuk. Masak hingga ayam matang.
1. Setelah mendidih dan ayam masak, angkat dan sajikan dengan pelengkap irisan jeruk nipis, irisan daun bawang, dan bawang goreng




Wah ternyata cara membuat coto makassar (ayam) yang lezat tidak rumit ini enteng banget ya! Kita semua dapat menghidangkannya. Resep coto makassar (ayam) Sangat cocok banget buat anda yang baru mau belajar memasak ataupun juga untuk anda yang sudah pandai memasak.

Apakah kamu tertarik mencoba membuat resep coto makassar (ayam) nikmat tidak rumit ini? Kalau kamu mau, ayo kamu segera buruan menyiapkan alat-alat dan bahan-bahannya, maka bikin deh Resep coto makassar (ayam) yang lezat dan simple ini. Benar-benar taidak sulit kan. 

Maka, ketimbang kamu diam saja, maka kita langsung hidangkan resep coto makassar (ayam) ini. Pasti kamu tiidak akan menyesal sudah bikin resep coto makassar (ayam) nikmat sederhana ini! Selamat berkreasi dengan resep coto makassar (ayam) mantab tidak ribet ini di tempat tinggal kalian masing-masing,ya!.

