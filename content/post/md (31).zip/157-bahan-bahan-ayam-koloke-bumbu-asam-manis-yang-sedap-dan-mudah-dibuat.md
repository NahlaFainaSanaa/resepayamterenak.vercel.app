---
description: "Bahan-bahan Ayam koloke bumbu asam manis yang sedap dan Mudah Dibuat"
title: "Bahan-bahan Ayam koloke bumbu asam manis yang sedap dan Mudah Dibuat"
slug: 157-bahan-bahan-ayam-koloke-bumbu-asam-manis-yang-sedap-dan-mudah-dibuat
date: 2021-04-06T01:38:09.808Z
image: https://img-global.cpcdn.com/recipes/a08c3e9a32522641/680x482cq70/ayam-koloke-bumbu-asam-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a08c3e9a32522641/680x482cq70/ayam-koloke-bumbu-asam-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a08c3e9a32522641/680x482cq70/ayam-koloke-bumbu-asam-manis-foto-resep-utama.jpg
author: Rose Washington
ratingvalue: 3.7
reviewcount: 12
recipeingredient:
- " Bahan lauk"
- "1 kg Ayam"
- " Tepung terigu secukupnya"
- " Merica bubuk"
- "secukupnya Garam"
- " Bahan saus"
- "4 buah cabai merah iris miring"
- "1 buah bawang bombay iris"
- " Tomat 1 buah iris sesuai selera"
- "1 buah wortel iris panjang2"
- "3 siung bawang putih"
- "1/2 cm ruas jahe digeprek"
- "1 batang daun bawang"
- "Secukupnya kaldu ayamjamur"
- "Secukupnya garam"
- "Secukupnya gula pasir"
- " Saus tomat"
- "Secukupnya air"
- "1 sdm gula"
- "1,5 sdm telung maizena"
recipeinstructions:
- "Balur ayam yang telah dipotong dadu (atau sesuai selera) dengan garam dan merica bubuk secukupnya. Diamkan 15-20menit agar bumbu meresap kedalam ayam. Setelah itu balur dengan tepung terigu-celup air- terigu. Kemudian goreng."
- "Siapkan bahan saus. Tumis ke wajan yang telah diberi 3sdm minyak, masukkan bahan saus berurutan. Masukan semua bumbu saus kecuali air dan tepung maizena."
- "Ketika wortel sudah mulai lemas, masukkan air secukupnya,, aduk merata hingga rasa saus telah sesuai dengan selera. (Jika dirasa gula, garam, dan saus kurang, dapat ditambah sesuai selera."
- "Sudah jadi deh, oh iy, kalau bisa saus dan ayamnya dipisah ya, di sajikan bersamaan ketika hendak dimakan, agar ayamnya masih crispy ❤️"
categories:
- Resep
tags:
- ayam
- koloke
- bumbu

katakunci: ayam koloke bumbu 
nutrition: 207 calories
recipecuisine: Indonesian
preptime: "PT23M"
cooktime: "PT39M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam koloke bumbu asam manis](https://img-global.cpcdn.com/recipes/a08c3e9a32522641/680x482cq70/ayam-koloke-bumbu-asam-manis-foto-resep-utama.jpg)

Selaku seorang yang hobi masak, menyediakan masakan menggugah selera untuk orang tercinta adalah suatu hal yang menyenangkan bagi kita sendiri. Tanggung jawab seorang  wanita Tidak hanya mengerjakan pekerjaan rumah saja, tetapi anda juga wajib memastikan kebutuhan gizi tercukupi dan hidangan yang dikonsumsi keluarga tercinta wajib nikmat.

Di era  saat ini, kalian memang mampu mengorder santapan praktis meski tanpa harus ribet membuatnya terlebih dahulu. Tapi ada juga orang yang selalu mau menghidangkan yang terenak untuk orang yang dicintainya. Lantaran, menghidangkan masakan sendiri jauh lebih higienis dan bisa menyesuaikan masakan tersebut berdasarkan kesukaan keluarga. 



Apakah anda adalah seorang penggemar ayam koloke bumbu asam manis?. Asal kamu tahu, ayam koloke bumbu asam manis merupakan makanan khas di Nusantara yang kini digemari oleh setiap orang dari berbagai wilayah di Nusantara. Anda bisa memasak ayam koloke bumbu asam manis hasil sendiri di rumahmu dan boleh dijadikan hidangan favoritmu di hari libur.

Kamu tak perlu bingung untuk memakan ayam koloke bumbu asam manis, karena ayam koloke bumbu asam manis gampang untuk ditemukan dan juga kalian pun bisa memasaknya sendiri di rumah. ayam koloke bumbu asam manis bisa diolah memalui berbagai cara. Kini pun ada banyak banget cara kekinian yang membuat ayam koloke bumbu asam manis semakin enak.

Resep ayam koloke bumbu asam manis juga mudah sekali untuk dibikin, lho. Anda tidak usah repot-repot untuk membeli ayam koloke bumbu asam manis, sebab Anda bisa membuatnya sendiri di rumah. Untuk Kita yang ingin menyajikannya, inilah resep untuk menyajikan ayam koloke bumbu asam manis yang enak yang bisa Kita hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Ayam koloke bumbu asam manis:

1. Gunakan  Bahan lauk
1. Siapkan 1 kg Ayam
1. Ambil  Tepung terigu (secukupnya)
1. Siapkan  Merica bubuk
1. Sediakan secukupnya Garam
1. Ambil  Bahan saus
1. Siapkan 4 buah cabai merah (iris miring)
1. Gunakan 1 buah bawang bombay (iris)
1. Siapkan  Tomat 1 buah (iris sesuai selera)
1. Sediakan 1 buah wortel (iris panjang2)
1. Gunakan 3 siung bawang putih
1. Ambil 1/2 cm ruas jahe (digeprek)
1. Ambil 1 batang daun bawang
1. Ambil Secukupnya kaldu (ayam/jamur)
1. Sediakan Secukupnya garam
1. Siapkan Secukupnya gula pasir
1. Siapkan  Saus tomat
1. Gunakan Secukupnya air
1. Siapkan 1 sdm gula
1. Gunakan 1,5 sdm telung maizena




<!--inarticleads2-->

##### Cara membuat Ayam koloke bumbu asam manis:

1. Balur ayam yang telah dipotong dadu (atau sesuai selera) dengan garam dan merica bubuk secukupnya. Diamkan 15-20menit agar bumbu meresap kedalam ayam. Setelah itu balur dengan tepung terigu-celup air- terigu. Kemudian goreng.
1. Siapkan bahan saus. Tumis ke wajan yang telah diberi 3sdm minyak, masukkan bahan saus berurutan. Masukan semua bumbu saus kecuali air dan tepung maizena.
1. Ketika wortel sudah mulai lemas, masukkan air secukupnya,, aduk merata hingga rasa saus telah sesuai dengan selera. (Jika dirasa gula, garam, dan saus kurang, dapat ditambah sesuai selera.
1. Sudah jadi deh, oh iy, kalau bisa saus dan ayamnya dipisah ya, di sajikan bersamaan ketika hendak dimakan, agar ayamnya masih crispy ❤️




Wah ternyata cara membuat ayam koloke bumbu asam manis yang lezat tidak ribet ini mudah banget ya! Kalian semua bisa memasaknya. Cara Membuat ayam koloke bumbu asam manis Sangat cocok sekali untuk anda yang baru belajar memasak maupun juga untuk kalian yang telah jago dalam memasak.

Tertarik untuk mulai mencoba membikin resep ayam koloke bumbu asam manis nikmat simple ini? Kalau tertarik, yuk kita segera buruan siapkan alat dan bahannya, lantas bikin deh Resep ayam koloke bumbu asam manis yang mantab dan sederhana ini. Sungguh gampang kan. 

Maka dari itu, daripada kita berlama-lama, yuk langsung aja bikin resep ayam koloke bumbu asam manis ini. Dijamin kalian gak akan menyesal sudah bikin resep ayam koloke bumbu asam manis lezat tidak rumit ini! Selamat mencoba dengan resep ayam koloke bumbu asam manis mantab sederhana ini di tempat tinggal masing-masing,ya!.

