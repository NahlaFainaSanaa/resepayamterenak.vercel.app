---
description: "Cara buat Soto ayam Sederhana dan Mudah Dibuat"
title: "Cara buat Soto ayam Sederhana dan Mudah Dibuat"
slug: 224-cara-buat-soto-ayam-sederhana-dan-mudah-dibuat
date: 2021-04-01T17:42:25.567Z
image: https://img-global.cpcdn.com/recipes/d0f80b3ed5e6ef2b/680x482cq70/soto-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d0f80b3ed5e6ef2b/680x482cq70/soto-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d0f80b3ed5e6ef2b/680x482cq70/soto-ayam-foto-resep-utama.jpg
author: John Newman
ratingvalue: 4.6
reviewcount: 14
recipeingredient:
- "500 gr dada ayam"
- " Tauge rebus sebentar"
- " Kol rebus sebentar"
- " Bihun rendam air mendidih 1 mnt tiriskan"
- "2 Daun salam"
- "3 daun jeruk"
- "2 sereh geprek"
- "2 ruas laos geprek"
- "secukupnya Kaldu ayam garam gula"
- " Bumbu halus"
- "5 bawang merah"
- "6 bawang putih"
- "3 cm kunyit bakar"
- "3 butir kemiri sangrai"
- "3 cm jahe"
- " Pelengkap"
- " Sambal"
- " Perkedel"
- " Jeruk nipis"
recipeinstructions:
- "Rebus ayam dengan, daun salam, daun jeruk, laos, sereh sampai ayam setengah matang"
- "Tumis bumbu halus dan masukkan kerebusan ayam, tambah garam, penyedap dan gula secukupnya. Rebus sampai ayam matang. Matikan api"
- "Ambil ayam lalu goreng sampai coklat, tiriskan dan suwir2 ayam"
- "Tata dalam mangkok, tauge, kol, bihun, ayam suwir,siram dengan kuah lalu tambahkan pelengkap. Selesai"
categories:
- Resep
tags:
- soto
- ayam

katakunci: soto ayam 
nutrition: 111 calories
recipecuisine: Indonesian
preptime: "PT10M"
cooktime: "PT56M"
recipeyield: "2"
recipecategory: Lunch

---


![Soto ayam](https://img-global.cpcdn.com/recipes/d0f80b3ed5e6ef2b/680x482cq70/soto-ayam-foto-resep-utama.jpg)

Sebagai seorang istri, mempersiapkan hidangan lezat pada keluarga tercinta merupakan suatu hal yang membahagiakan untuk anda sendiri. Tanggung jawab seorang istri bukan hanya mengerjakan pekerjaan rumah saja, namun kamu pun wajib memastikan kebutuhan nutrisi tercukupi dan masakan yang disantap anak-anak mesti sedap.

Di masa  sekarang, anda memang mampu memesan masakan instan tidak harus susah memasaknya dulu. Namun banyak juga lho mereka yang memang ingin memberikan makanan yang terenak bagi orang yang dicintainya. Lantaran, menghidangkan masakan sendiri jauh lebih bersih dan kita pun bisa menyesuaikan sesuai dengan selera keluarga tercinta. 



Mungkinkah kamu salah satu penggemar soto ayam?. Asal kamu tahu, soto ayam merupakan makanan khas di Indonesia yang saat ini digemari oleh orang-orang dari hampir setiap wilayah di Nusantara. Kamu dapat membuat soto ayam sendiri di rumah dan boleh dijadikan hidangan kesenanganmu di akhir pekan.

Kita tidak usah bingung untuk memakan soto ayam, sebab soto ayam tidak sukar untuk dicari dan anda pun dapat membuatnya sendiri di rumah. soto ayam dapat dimasak memalui berbagai cara. Kini telah banyak resep modern yang membuat soto ayam semakin nikmat.

Resep soto ayam juga mudah untuk dibikin, lho. Kalian tidak usah repot-repot untuk membeli soto ayam, lantaran Anda mampu menyiapkan sendiri di rumah. Untuk Anda yang mau menghidangkannya, berikut ini cara untuk membuat soto ayam yang lezat yang mampu Anda hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Soto ayam:

1. Siapkan 500 gr dada ayam
1. Ambil  Tauge, rebus sebentar
1. Ambil  Kol, rebus sebentar
1. Sediakan  Bihun, rendam air mendidih 1 mnt, tiriskan
1. Sediakan 2 Daun salam
1. Sediakan 3 daun jeruk
1. Ambil 2 sereh, geprek
1. Siapkan 2 ruas laos, geprek
1. Ambil secukupnya Kaldu ayam, garam, gula,
1. Gunakan  Bumbu halus
1. Siapkan 5 bawang merah
1. Sediakan 6 bawang putih
1. Gunakan 3 cm kunyit, bakar
1. Siapkan 3 butir kemiri sangrai
1. Siapkan 3 cm jahe
1. Ambil  Pelengkap
1. Ambil  Sambal
1. Ambil  Perkedel
1. Siapkan  Jeruk nipis




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Soto ayam:

1. Rebus ayam dengan, daun salam, daun jeruk, laos, sereh sampai ayam setengah matang
1. Tumis bumbu halus dan masukkan kerebusan ayam, tambah garam, penyedap dan gula secukupnya. Rebus sampai ayam matang. Matikan api
1. Ambil ayam lalu goreng sampai coklat, tiriskan dan suwir2 ayam
1. Tata dalam mangkok, tauge, kol, bihun, ayam suwir,siram dengan kuah lalu tambahkan pelengkap. Selesai




Ternyata cara buat soto ayam yang mantab tidak ribet ini enteng sekali ya! Anda Semua dapat memasaknya. Cara Membuat soto ayam Sesuai sekali untuk kamu yang baru belajar memasak maupun juga untuk kalian yang telah pandai memasak.

Tertarik untuk mencoba membuat resep soto ayam lezat simple ini? Kalau anda tertarik, ayo kalian segera siapkan peralatan dan bahan-bahannya, lalu bikin deh Resep soto ayam yang nikmat dan simple ini. Benar-benar gampang kan. 

Oleh karena itu, daripada kita berfikir lama-lama, ayo langsung aja sajikan resep soto ayam ini. Dijamin anda tak akan menyesal membuat resep soto ayam mantab tidak ribet ini! Selamat mencoba dengan resep soto ayam mantab simple ini di tempat tinggal masing-masing,oke!.

