---
description: "Resep Coto Ayam yang enak dan Mudah Dibuat"
title: "Resep Coto Ayam yang enak dan Mudah Dibuat"
slug: 63-resep-coto-ayam-yang-enak-dan-mudah-dibuat
date: 2021-06-29T03:01:43.451Z
image: https://img-global.cpcdn.com/recipes/e7af17dd8d68f3ee/680x482cq70/coto-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e7af17dd8d68f3ee/680x482cq70/coto-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e7af17dd8d68f3ee/680x482cq70/coto-ayam-foto-resep-utama.jpg
author: Jerry Gregory
ratingvalue: 3.5
reviewcount: 4
recipeingredient:
- " Ayam"
- " Serei yang sdh digeprek"
- " Lengkuas yg sdh digeprek"
- " Daun salam"
- " Garam"
- " Gula"
- " Penyedap rasa"
- " Bahan yang dihaluskan "
- " Kacang tanah sangrai"
- " Bawang Merah"
- " Bawang Putih"
- " Kemiri"
- " Ketumbar"
- " Merica"
- " Jahe"
recipeinstructions:
- "Cuci ayam dan bahan2 lainnya sebelum diolah."
- "Rebus ayam dengan menambahkan serei dan lengkuas yg sdh digeprek dan daun salam. Tunggu sampai air rebusan mendidih bs sambil menghaluskan kacang tanah yg sdh disangrai. Bs menggunakan ulekan atau blender."
- "Haluskan bumbu2 : Bawang merah, bawang putih, ketumbar, kemiri, merica dan jahe. Setelah halus, tumis menggunakan minyak goreng hingga harum."
- "Setelah rebusan ayam mendidih, masukkan bumbu yg telah ditumis ke dalam rebusan sambil diaduk."
- "Tambahkan kacang tanah yg telah dihaluskan hingga tekstur kuah sedikit mengetal. Aduk agar merata."
- "Tambahkan garam, gula, dan penyedap rasa (optional). Aduk hingga merata dan diamkan hingga ayam matang dan bumbu meresap."
- "Setelah matang, tuang coto ayam ke dalam mangkok lalu tambahkan bawang goreng, daun bawang dan jeruk nipis sebagai pelengkap."
- "Coto ayam siap dihidangkan dgn ketupat atau nasi hangat."
categories:
- Resep
tags:
- coto
- ayam

katakunci: coto ayam 
nutrition: 186 calories
recipecuisine: Indonesian
preptime: "PT34M"
cooktime: "PT55M"
recipeyield: "1"
recipecategory: Lunch

---


![Coto Ayam](https://img-global.cpcdn.com/recipes/e7af17dd8d68f3ee/680x482cq70/coto-ayam-foto-resep-utama.jpg)

Jika kalian seorang yang hobi masak, mempersiapkan masakan mantab pada orang tercinta adalah hal yang menyenangkan bagi kamu sendiri. Tanggung jawab seorang ibu Tidak hanya mengerjakan pekerjaan rumah saja, namun kamu juga wajib memastikan keperluan gizi tercukupi dan juga masakan yang dikonsumsi anak-anak harus mantab.

Di masa  saat ini, anda memang mampu membeli panganan yang sudah jadi walaupun tidak harus susah membuatnya terlebih dahulu. Tapi banyak juga mereka yang memang mau memberikan hidangan yang terbaik untuk orang yang dicintainya. Pasalnya, menyajikan masakan yang diolah sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan makanan tersebut sesuai makanan kesukaan keluarga. 



Apakah anda adalah salah satu penggemar coto ayam?. Asal kamu tahu, coto ayam merupakan hidangan khas di Indonesia yang sekarang disenangi oleh setiap orang di hampir setiap daerah di Indonesia. Kalian dapat menghidangkan coto ayam sendiri di rumahmu dan dapat dijadikan hidangan kegemaranmu di akhir pekanmu.

Kalian jangan bingung jika kamu ingin mendapatkan coto ayam, lantaran coto ayam sangat mudah untuk ditemukan dan kita pun dapat memasaknya sendiri di rumah. coto ayam dapat diolah memalui beraneka cara. Saat ini telah banyak resep kekinian yang membuat coto ayam lebih mantap.

Resep coto ayam juga sangat gampang dihidangkan, lho. Kita jangan capek-capek untuk memesan coto ayam, karena Kita mampu membuatnya di rumah sendiri. Bagi Kalian yang ingin membuatnya, berikut ini cara untuk menyajikan coto ayam yang mantab yang mampu Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Coto Ayam:

1. Gunakan  Ayam
1. Gunakan  Serei yang sdh digeprek
1. Sediakan  Lengkuas yg sdh digeprek
1. Sediakan  Daun salam
1. Gunakan  Garam
1. Ambil  Gula
1. Siapkan  Penyedap rasa
1. Sediakan  Bahan yang dihaluskan :
1. Ambil  Kacang tanah sangrai
1. Siapkan  Bawang Merah
1. Sediakan  Bawang Putih
1. Sediakan  Kemiri
1. Gunakan  Ketumbar
1. Ambil  Merica
1. Ambil  Jahe




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Coto Ayam:

1. Cuci ayam dan bahan2 lainnya sebelum diolah.
1. Rebus ayam dengan menambahkan serei dan lengkuas yg sdh digeprek dan daun salam. Tunggu sampai air rebusan mendidih bs sambil menghaluskan kacang tanah yg sdh disangrai. Bs menggunakan ulekan atau blender.
1. Haluskan bumbu2 : Bawang merah, bawang putih, ketumbar, kemiri, merica dan jahe. Setelah halus, tumis menggunakan minyak goreng hingga harum.
1. Setelah rebusan ayam mendidih, masukkan bumbu yg telah ditumis ke dalam rebusan sambil diaduk.
1. Tambahkan kacang tanah yg telah dihaluskan hingga tekstur kuah sedikit mengetal. Aduk agar merata.
1. Tambahkan garam, gula, dan penyedap rasa (optional). Aduk hingga merata dan diamkan hingga ayam matang dan bumbu meresap.
1. Setelah matang, tuang coto ayam ke dalam mangkok lalu tambahkan bawang goreng, daun bawang dan jeruk nipis sebagai pelengkap.
1. Coto ayam siap dihidangkan dgn ketupat atau nasi hangat.




Wah ternyata cara membuat coto ayam yang lezat tidak ribet ini mudah banget ya! Kita semua mampu membuatnya. Cara buat coto ayam Sangat cocok sekali buat anda yang baru mau belajar memasak maupun untuk kamu yang telah ahli dalam memasak.

Tertarik untuk mulai mencoba bikin resep coto ayam lezat simple ini? Kalau ingin, yuk kita segera buruan siapin peralatan dan bahan-bahannya, lalu buat deh Resep coto ayam yang lezat dan tidak ribet ini. Sangat taidak sulit kan. 

Jadi, ketimbang kita berlama-lama, maka kita langsung saja hidangkan resep coto ayam ini. Pasti kalian tak akan menyesal membuat resep coto ayam mantab tidak ribet ini! Selamat berkreasi dengan resep coto ayam nikmat tidak rumit ini di tempat tinggal kalian masing-masing,oke!.

