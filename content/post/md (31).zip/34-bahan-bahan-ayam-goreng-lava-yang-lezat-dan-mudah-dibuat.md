---
description: "Bahan-bahan Ayam Goreng Lava yang lezat dan Mudah Dibuat"
title: "Bahan-bahan Ayam Goreng Lava yang lezat dan Mudah Dibuat"
slug: 34-bahan-bahan-ayam-goreng-lava-yang-lezat-dan-mudah-dibuat
date: 2021-01-16T17:39:55.143Z
image: https://img-global.cpcdn.com/recipes/36a28b77617f4150/680x482cq70/ayam-goreng-lava-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/36a28b77617f4150/680x482cq70/ayam-goreng-lava-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/36a28b77617f4150/680x482cq70/ayam-goreng-lava-foto-resep-utama.jpg
author: Alta Rice
ratingvalue: 4.7
reviewcount: 12
recipeingredient:
- " Bahan adonan ayam "
- "200 gr daging ayam blender"
- "1 buah wortel parut"
- "2 helai daun bawang iris"
- "2 sdm bawang putih halus"
- "Sejumput garam"
- " Bahan lava "
- "3 sdm mayones"
- "3 sdm saos tomat  saos sambal"
- " Bahan celup "
- "1 sachet tepung bumbu sajiku"
- "2 butir telur"
- "Secukupnya tepung panir  tepung roti"
recipeinstructions:
- "Campurkan semua bahan adonan ayam hingga tercampur rata."
- "Di wadah lain campurkan mayones dan saus tomat, aduk rata"
- "Bagi adonan ayam menjadi 20 gr, lalu bulat&#34;kan kemudian pipihkan, dan beri saos lava, bulat&#34;kan kembali lakukan hingga adonan habis."
- "Siapkan adonan celup, kocok telur dalam mangkok, masukkan tepung bumbu dalam mangkok lain, masukkan juga tepung panir dalam mangkok lain."
- "Lalu masukkan adoan ayam kedalam tepung bumbu hingga semua adonan tertutup tepung, angkat masukkan dalam kocokan telur, angkat masukkan dalam tepung panir, sisihkan, lakukan hingga semua adonan habis"
- "Masukkan semua adonan kedalam freezer kurang lebih selma 15 menit, lalu goreng dalam minyak panas menggunakan api kecil, hingga berwarna kuning keemasan, angkat dan sajikan."
categories:
- Resep
tags:
- ayam
- goreng
- lava

katakunci: ayam goreng lava 
nutrition: 157 calories
recipecuisine: Indonesian
preptime: "PT30M"
cooktime: "PT53M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam Goreng Lava](https://img-global.cpcdn.com/recipes/36a28b77617f4150/680x482cq70/ayam-goreng-lava-foto-resep-utama.jpg)

Sebagai seorang ibu, mempersiapkan masakan lezat untuk keluarga tercinta merupakan hal yang sangat menyenangkan untuk kamu sendiri. Tanggung jawab seorang  wanita bukan hanya mengerjakan pekerjaan rumah saja, namun kamu juga wajib menyediakan kebutuhan nutrisi tercukupi dan santapan yang disantap keluarga tercinta wajib lezat.

Di masa  saat ini, kita memang dapat membeli santapan praktis meski tidak harus repot mengolahnya lebih dulu. Tapi banyak juga orang yang memang ingin memberikan yang terbaik untuk orang tercintanya. Karena, menghidangkan masakan yang dibuat sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan hidangan tersebut berdasarkan kesukaan orang tercinta. 



Apakah anda seorang penggemar ayam goreng lava?. Tahukah kamu, ayam goreng lava adalah sajian khas di Nusantara yang kini digemari oleh setiap orang di hampir setiap tempat di Nusantara. Kalian bisa memasak ayam goreng lava kreasi sendiri di rumahmu dan boleh jadi makanan kesenanganmu di hari libur.

Anda tidak perlu bingung jika kamu ingin menyantap ayam goreng lava, sebab ayam goreng lava gampang untuk ditemukan dan juga anda pun boleh memasaknya sendiri di rumah. ayam goreng lava bisa diolah dengan berbagai cara. Kini pun ada banyak banget resep modern yang menjadikan ayam goreng lava semakin mantap.

Resep ayam goreng lava juga mudah sekali dibikin, lho. Kita tidak perlu ribet-ribet untuk membeli ayam goreng lava, lantaran Kita bisa menghidangkan sendiri di rumah. Untuk Kita yang hendak membuatnya, berikut ini cara untuk membuat ayam goreng lava yang nikamat yang mampu Kalian coba sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Ayam Goreng Lava:

1. Sediakan  Bahan adonan ayam :
1. Sediakan 200 gr daging ayam blender
1. Ambil 1 buah wortel parut
1. Gunakan 2 helai daun bawang iris&#34;
1. Gunakan 2 sdm bawang putih halus
1. Gunakan Sejumput garam
1. Sediakan  Bahan lava :
1. Gunakan 3 sdm mayones
1. Ambil 3 sdm saos tomat / saos sambal
1. Siapkan  Bahan celup :
1. Ambil 1 sachet tepung bumbu sajiku
1. Ambil 2 butir telur
1. Sediakan Secukupnya tepung panir / tepung roti




<!--inarticleads2-->

##### Cara menyiapkan Ayam Goreng Lava:

1. Campurkan semua bahan adonan ayam hingga tercampur rata.
1. Di wadah lain campurkan mayones dan saus tomat, aduk rata
1. Bagi adonan ayam menjadi 20 gr, lalu bulat&#34;kan kemudian pipihkan, dan beri saos lava, bulat&#34;kan kembali lakukan hingga adonan habis.
1. Siapkan adonan celup, kocok telur dalam mangkok, masukkan tepung bumbu dalam mangkok lain, masukkan juga tepung panir dalam mangkok lain.
1. Lalu masukkan adoan ayam kedalam tepung bumbu hingga semua adonan tertutup tepung, angkat masukkan dalam kocokan telur, angkat masukkan dalam tepung panir, sisihkan, lakukan hingga semua adonan habis
1. Masukkan semua adonan kedalam freezer kurang lebih selma 15 menit, lalu goreng dalam minyak panas menggunakan api kecil, hingga berwarna kuning keemasan, angkat dan sajikan.




Wah ternyata cara membuat ayam goreng lava yang enak sederhana ini mudah banget ya! Kalian semua dapat mencobanya. Cara buat ayam goreng lava Sesuai sekali buat kamu yang baru akan belajar memasak maupun juga bagi anda yang telah hebat dalam memasak.

Apakah kamu ingin mulai mencoba bikin resep ayam goreng lava lezat simple ini? Kalau anda mau, yuk kita segera buruan siapkan peralatan dan bahannya, lantas bikin deh Resep ayam goreng lava yang mantab dan tidak ribet ini. Benar-benar taidak sulit kan. 

Oleh karena itu, daripada kita diam saja, hayo kita langsung saja sajikan resep ayam goreng lava ini. Pasti kamu gak akan nyesel sudah membuat resep ayam goreng lava enak tidak ribet ini! Selamat mencoba dengan resep ayam goreng lava mantab sederhana ini di tempat tinggal sendiri,ya!.

