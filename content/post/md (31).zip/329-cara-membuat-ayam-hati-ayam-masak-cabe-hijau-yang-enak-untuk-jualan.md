---
description: "Cara membuat Ayam + hati ayam masak cabe hijau yang enak Untuk Jualan"
title: "Cara membuat Ayam + hati ayam masak cabe hijau yang enak Untuk Jualan"
slug: 329-cara-membuat-ayam-hati-ayam-masak-cabe-hijau-yang-enak-untuk-jualan
date: 2021-02-02T14:46:25.351Z
image: https://img-global.cpcdn.com/recipes/89194f9b425716e4/680x482cq70/ayam-hati-ayam-masak-cabe-hijau-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/89194f9b425716e4/680x482cq70/ayam-hati-ayam-masak-cabe-hijau-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/89194f9b425716e4/680x482cq70/ayam-hati-ayam-masak-cabe-hijau-foto-resep-utama.jpg
author: Mark Larson
ratingvalue: 4
reviewcount: 3
recipeingredient:
- "1/2 ekor ayam"
- "3 hati ayam  ampela"
- "8 siung bawang merah"
- "5 siung bawang putih"
- "8 cabe hijau besar bagusnya sih 15 cabe atau sesuai selera"
- "10 cabe rawit tergantung selera"
- "2 tomat merah ukuran sedang harus tomat hijau 34 buah"
- "2 batang serai geprek"
- "3 lembar daun salam"
- "5 lembar daun jeruk"
- "1 lembar daun kunyit"
- "1 cm kunyit"
- "1 cm jahe"
- "1 cm lengkuas"
- "3 biji kemiri"
- "1/2 sdm ketumbar"
- "1/2 sdm merica"
- "2 asam gandis boleh pake air asam jawa"
- " Penyedap"
- " Gula"
- " Minyak goreng"
- " Air bersih"
recipeinstructions:
- "Bersihkan ayam dan jeroannya, lalu potong sesuai selera, saya rebus jeroannya dulu yah biar gak bau amis, bisa direbus langsung atau ditambah garam dan daun jeruk"
- "Haluskan bawang, jahe, lengkuas, kunyit, kemiri, tomat dan cabe lalu tumis hingga wangi lalu masukan serai, daun jeruk, daun salam tumis hingga mateng"
- "Masukan ayam dan jeroan, dan asam aduk hingga bumbu tercampur rata, lalu tambah air secukupnya, masak hingga air berkurang setengah tambahakn penyedap, garam, gula, ketumbar, merica (atau ini ditambah pas lagi numis bumbu juga gpp)"
- "Koreksi rasa, masak hingga matang dan daging ayam empuk, angkat dan sajikan dengan nasi hangat"
categories:
- Resep
tags:
- ayam
- 
- hati

katakunci: ayam  hati 
nutrition: 145 calories
recipecuisine: Indonesian
preptime: "PT33M"
cooktime: "PT47M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam + hati ayam masak cabe hijau](https://img-global.cpcdn.com/recipes/89194f9b425716e4/680x482cq70/ayam-hati-ayam-masak-cabe-hijau-foto-resep-utama.jpg)

Selaku seorang yang hobi memasak, menyediakan masakan sedap buat famili adalah hal yang menyenangkan bagi kita sendiri. Tugas seorang  wanita bukan saja mengatur rumah saja, tetapi kamu juga harus memastikan keperluan gizi tercukupi dan juga olahan yang dikonsumsi keluarga tercinta harus enak.

Di zaman  sekarang, kalian sebenarnya dapat mengorder santapan instan meski tidak harus repot memasaknya lebih dulu. Tetapi banyak juga lho orang yang selalu mau memberikan hidangan yang terlezat bagi keluarganya. Sebab, menyajikan masakan sendiri akan jauh lebih higienis dan kita pun bisa menyesuaikan hidangan tersebut berdasarkan makanan kesukaan keluarga tercinta. 



Apakah kamu salah satu penikmat ayam + hati ayam masak cabe hijau?. Tahukah kamu, ayam + hati ayam masak cabe hijau adalah hidangan khas di Nusantara yang sekarang digemari oleh orang-orang dari berbagai tempat di Nusantara. Anda dapat menghidangkan ayam + hati ayam masak cabe hijau sendiri di rumah dan boleh jadi camilan kegemaranmu di hari liburmu.

Kalian tidak perlu bingung untuk menyantap ayam + hati ayam masak cabe hijau, lantaran ayam + hati ayam masak cabe hijau mudah untuk didapatkan dan juga kamu pun boleh membuatnya sendiri di rumah. ayam + hati ayam masak cabe hijau bisa dibuat dengan beraneka cara. Saat ini telah banyak sekali resep modern yang menjadikan ayam + hati ayam masak cabe hijau semakin lebih mantap.

Resep ayam + hati ayam masak cabe hijau pun gampang untuk dibuat, lho. Anda tidak usah repot-repot untuk memesan ayam + hati ayam masak cabe hijau, sebab Kalian dapat menyajikan di rumahmu. Untuk Anda yang mau mencobanya, dibawah ini merupakan resep membuat ayam + hati ayam masak cabe hijau yang lezat yang bisa Anda coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Ayam + hati ayam masak cabe hijau:

1. Ambil 1/2 ekor ayam
1. Sediakan 3 hati ayam + ampela
1. Sediakan 8 siung bawang merah
1. Sediakan 5 siung bawang putih
1. Gunakan 8 cabe hijau besar (bagusnya sih 15 cabe atau sesuai selera)
1. Ambil 10 cabe rawit (tergantung selera)
1. Gunakan 2 tomat merah ukuran sedang (harus tomat hijau 3-4 buah)
1. Gunakan 2 batang serai (geprek)
1. Siapkan 3 lembar daun salam
1. Gunakan 5 lembar daun jeruk
1. Gunakan 1 lembar daun kunyit
1. Sediakan 1 cm kunyit
1. Gunakan 1 cm jahe
1. Gunakan 1 cm lengkuas
1. Gunakan 3 biji kemiri
1. Sediakan 1/2 sdm ketumbar
1. Gunakan 1/2 sdm merica
1. Ambil 2 asam gandis (boleh pake air asam jawa)
1. Sediakan  Penyedap
1. Ambil  Gula
1. Sediakan  Minyak goreng
1. Siapkan  Air bersih




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam + hati ayam masak cabe hijau:

1. Bersihkan ayam dan jeroannya, lalu potong sesuai selera, saya rebus jeroannya dulu yah biar gak bau amis, bisa direbus langsung atau ditambah garam dan daun jeruk
1. Haluskan bawang, jahe, lengkuas, kunyit, kemiri, tomat dan cabe lalu tumis hingga wangi lalu masukan serai, daun jeruk, daun salam tumis hingga mateng
1. Masukan ayam dan jeroan, dan asam aduk hingga bumbu tercampur rata, lalu tambah air secukupnya, masak hingga air berkurang setengah tambahakn penyedap, garam, gula, ketumbar, merica (atau ini ditambah pas lagi numis bumbu juga gpp)
1. Koreksi rasa, masak hingga matang dan daging ayam empuk, angkat dan sajikan dengan nasi hangat




Ternyata cara buat ayam + hati ayam masak cabe hijau yang mantab sederhana ini gampang sekali ya! Kalian semua mampu menghidangkannya. Cara buat ayam + hati ayam masak cabe hijau Sangat cocok sekali untuk kamu yang sedang belajar memasak maupun bagi kamu yang telah jago dalam memasak.

Tertarik untuk mulai mencoba membikin resep ayam + hati ayam masak cabe hijau mantab tidak ribet ini? Kalau kamu mau, ayo kalian segera buruan siapkan alat dan bahan-bahannya, lalu buat deh Resep ayam + hati ayam masak cabe hijau yang lezat dan simple ini. Betul-betul mudah kan. 

Maka, ketimbang kita berfikir lama-lama, yuk kita langsung saja bikin resep ayam + hati ayam masak cabe hijau ini. Dijamin anda tak akan nyesel membuat resep ayam + hati ayam masak cabe hijau enak simple ini! Selamat berkreasi dengan resep ayam + hati ayam masak cabe hijau lezat tidak ribet ini di rumah kalian sendiri,ya!.

