---
description: "Bahan-bahan Rice Bowl Ayam Gongso Sederhana dan Mudah Dibuat"
title: "Bahan-bahan Rice Bowl Ayam Gongso Sederhana dan Mudah Dibuat"
slug: 194-bahan-bahan-rice-bowl-ayam-gongso-sederhana-dan-mudah-dibuat
date: 2021-05-16T00:20:23.037Z
image: https://img-global.cpcdn.com/recipes/490db79f45b52317/680x482cq70/rice-bowl-ayam-gongso-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/490db79f45b52317/680x482cq70/rice-bowl-ayam-gongso-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/490db79f45b52317/680x482cq70/rice-bowl-ayam-gongso-foto-resep-utama.jpg
author: Anne Keller
ratingvalue: 4.3
reviewcount: 7
recipeingredient:
- "300 gr dada ayam"
- "50 gr kol potongpotong"
- "2 buah tomat kecil potongpotong"
- "5 buah cabe rawit utuh sesuai selera"
- "2 buah cabe merah iris serong"
- "1 mangkuk Nasi putih"
- "1 butir telur ceplok 12 matang"
- "2 lembar daun salam"
- "1 ruas lengkuas geprek"
- "1 sdt lada bubuk"
- "1/2 sdt garam"
- "1 sdt kaldu jamurpenyedap"
- "3 sdm kecap manis"
- "200 ml air"
- " Minyak goreng"
- " Bumbu halus"
- "4 siung bawang putih"
- "2 siung bawang merah"
- "2 butir kemiri"
- "1 buah cabe rawit"
recipeinstructions:
- "Bersihkan dada ayam, rebus selama 10 menit, angkat dan tiriskan, potong dadu/suwir-suwir, sisihkan."
- "Tumis bumbu halus sampai wangi, tambahkan salam dan lengkuas, masukkan ayam suwir aduk, bumbui kecap, garam, lada dan penyedap."
- "Tuang air, masukkan kol, cabe rawit dan tomat aduk rata, masak sampai bumbu meresap dan kuah menyusut. Koreksi rasa."
- "Sajikan dengan nasi hangat dan telur ceplok 1/2 matang. Selamat menikmati. 😊"
categories:
- Resep
tags:
- rice
- bowl
- ayam

katakunci: rice bowl ayam 
nutrition: 157 calories
recipecuisine: Indonesian
preptime: "PT40M"
cooktime: "PT48M"
recipeyield: "4"
recipecategory: Dinner

---


![Rice Bowl Ayam Gongso](https://img-global.cpcdn.com/recipes/490db79f45b52317/680x482cq70/rice-bowl-ayam-gongso-foto-resep-utama.jpg)

Jika kalian seorang orang tua, mempersiapkan hidangan sedap bagi keluarga tercinta adalah suatu hal yang menggembirakan untuk kita sendiri. Kewajiban seorang ibu bukan cuman menangani rumah saja, namun kamu pun wajib menyediakan keperluan gizi terpenuhi dan santapan yang dikonsumsi keluarga tercinta wajib sedap.

Di masa  sekarang, kita sebenarnya bisa mengorder santapan siap saji tidak harus repot membuatnya terlebih dahulu. Tetapi ada juga lho orang yang selalu ingin memberikan hidangan yang terbaik untuk keluarganya. Pasalnya, memasak yang dibuat sendiri jauh lebih bersih dan kita juga bisa menyesuaikan sesuai selera orang tercinta. 



Apakah anda adalah salah satu penikmat rice bowl ayam gongso?. Tahukah kamu, rice bowl ayam gongso merupakan makanan khas di Nusantara yang saat ini disukai oleh setiap orang dari hampir setiap daerah di Indonesia. Kamu dapat menghidangkan rice bowl ayam gongso sendiri di rumahmu dan pasti jadi makanan favoritmu di akhir pekanmu.

Kamu jangan bingung jika kamu ingin menyantap rice bowl ayam gongso, lantaran rice bowl ayam gongso tidak sulit untuk dicari dan juga kalian pun dapat membuatnya sendiri di tempatmu. rice bowl ayam gongso boleh dimasak dengan berbagai cara. Saat ini sudah banyak sekali cara modern yang membuat rice bowl ayam gongso semakin mantap.

Resep rice bowl ayam gongso pun gampang dibuat, lho. Kalian jangan repot-repot untuk membeli rice bowl ayam gongso, lantaran Anda mampu menyajikan di rumah sendiri. Bagi Kita yang ingin menghidangkannya, inilah cara untuk membuat rice bowl ayam gongso yang lezat yang mampu Kamu buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Rice Bowl Ayam Gongso:

1. Ambil 300 gr dada ayam
1. Siapkan 50 gr kol, potong-potong
1. Siapkan 2 buah tomat kecil, potong-potong
1. Ambil 5 buah cabe rawit utuh (sesuai selera)
1. Ambil 2 buah cabe merah, iris serong
1. Sediakan 1 mangkuk Nasi putih
1. Ambil 1 butir telur ceplok 1/2 matang
1. Sediakan 2 lembar daun salam
1. Ambil 1 ruas lengkuas, geprek
1. Sediakan 1 sdt lada bubuk
1. Ambil 1/2 sdt garam
1. Ambil 1 sdt kaldu jamur/penyedap
1. Sediakan 3 sdm kecap manis
1. Ambil 200 ml air
1. Sediakan  Minyak goreng
1. Siapkan  Bumbu halus
1. Ambil 4 siung bawang putih
1. Siapkan 2 siung bawang merah
1. Sediakan 2 butir kemiri
1. Gunakan 1 buah cabe rawit




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Rice Bowl Ayam Gongso:

1. Bersihkan dada ayam, rebus selama 10 menit, angkat dan tiriskan, potong dadu/suwir-suwir, sisihkan.
1. Tumis bumbu halus sampai wangi, tambahkan salam dan lengkuas, masukkan ayam suwir aduk, bumbui kecap, garam, lada dan penyedap.
1. Tuang air, masukkan kol, cabe rawit dan tomat aduk rata, masak sampai bumbu meresap dan kuah menyusut. Koreksi rasa.
1. Sajikan dengan nasi hangat dan telur ceplok 1/2 matang. Selamat menikmati. 😊




Ternyata cara buat rice bowl ayam gongso yang lezat sederhana ini gampang sekali ya! Kalian semua dapat membuatnya. Cara Membuat rice bowl ayam gongso Sesuai sekali untuk kalian yang baru mau belajar memasak maupun untuk anda yang telah hebat dalam memasak.

Tertarik untuk mulai mencoba membuat resep rice bowl ayam gongso nikmat tidak rumit ini? Kalau kalian ingin, ayo kalian segera buruan siapin alat-alat dan bahan-bahannya, lalu buat deh Resep rice bowl ayam gongso yang enak dan sederhana ini. Sungguh taidak sulit kan. 

Maka dari itu, ketimbang kita berfikir lama-lama, hayo langsung aja hidangkan resep rice bowl ayam gongso ini. Dijamin kamu tak akan menyesal sudah buat resep rice bowl ayam gongso mantab sederhana ini! Selamat berkreasi dengan resep rice bowl ayam gongso lezat simple ini di tempat tinggal masing-masing,oke!.

