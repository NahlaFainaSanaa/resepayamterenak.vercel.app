---
description: "Cara memasak Chicken lava yang enak Untuk Jualan"
title: "Cara memasak Chicken lava yang enak Untuk Jualan"
slug: 25-cara-memasak-chicken-lava-yang-enak-untuk-jualan
date: 2021-02-18T12:01:05.484Z
image: https://img-global.cpcdn.com/recipes/cbd50ea8b9b08b5c/680x482cq70/chicken-lava-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/cbd50ea8b9b08b5c/680x482cq70/chicken-lava-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/cbd50ea8b9b08b5c/680x482cq70/chicken-lava-foto-resep-utama.jpg
author: Ruth Wallace
ratingvalue: 4.8
reviewcount: 6
recipeingredient:
- "300 gr ayam fillet"
- "2 siung bawang putih"
- "1 buah jeruk nipis"
- "1 sdt cabai bubuk"
- "1 bungkus tepung serbaguna ayam krispy"
- " Minyak goreng"
- " Saus lava"
- "1/2 buab bawang bombai"
- "200 gr saos hot lava"
- "30 gr saus tomat"
- "30 gr saus sambal"
- "1 sdm gula pasir"
- "1/2 sdt kaldu"
- "1/2 sdt garam"
- "20 ml air"
- "2 sdm margarin  minyak goreng"
recipeinstructions:
- "Potong dadu ayam fillet, cuci bersoh dan tiriskan."
- "Parut bawang putih campurkan air perasan jeruk nipis dan cabai bubuk aduk rata. Masukkan ayam dan marinasi selama 30 menit"
- "Siapkan 3 sdm tepung dan campurkan air aduk rata, masukkan ayam dan balur dengan tepung kering lalu goreng di minyak panas. Lakukan sampai ayam habis."
- "Membuat saus, cincang bawang bombay tumis hingga wangi. Masukkan semua bahan saus. Aduk rata dan beri sedikit air. Cek rasa."
- "Jika saus sudah meletup-letup masukkan ayam yg sudah di goreng. Aduk hingga rata."
categories:
- Resep
tags:
- chicken
- lava

katakunci: chicken lava 
nutrition: 121 calories
recipecuisine: Indonesian
preptime: "PT17M"
cooktime: "PT57M"
recipeyield: "1"
recipecategory: Lunch

---


![Chicken lava](https://img-global.cpcdn.com/recipes/cbd50ea8b9b08b5c/680x482cq70/chicken-lava-foto-resep-utama.jpg)

Selaku seorang wanita, menyediakan hidangan lezat pada famili merupakan suatu hal yang memuaskan untuk kamu sendiri. Tanggung jawab seorang istri bukan saja mengurus rumah saja, tapi anda juga wajib menyediakan kebutuhan nutrisi tercukupi dan hidangan yang disantap anak-anak harus sedap.

Di zaman  saat ini, kamu sebenarnya mampu mengorder hidangan siap saji walaupun tanpa harus capek membuatnya dahulu. Tapi banyak juga mereka yang memang ingin memberikan hidangan yang terenak bagi orang yang dicintainya. Sebab, memasak yang dibuat sendiri akan jauh lebih bersih dan kita juga bisa menyesuaikan makanan tersebut sesuai dengan masakan kesukaan orang tercinta. 



Mungkinkah kamu seorang penyuka chicken lava?. Tahukah kamu, chicken lava merupakan makanan khas di Indonesia yang kini disukai oleh orang-orang dari berbagai wilayah di Nusantara. Kalian dapat membuat chicken lava hasil sendiri di rumah dan boleh jadi santapan favorit di hari liburmu.

Kita tak perlu bingung untuk menyantap chicken lava, sebab chicken lava tidak sulit untuk ditemukan dan anda pun bisa membuatnya sendiri di tempatmu. chicken lava boleh dimasak memalui berbagai cara. Saat ini ada banyak sekali resep modern yang membuat chicken lava semakin lezat.

Resep chicken lava juga sangat mudah untuk dibikin, lho. Kalian tidak usah repot-repot untuk membeli chicken lava, lantaran Anda bisa menyajikan ditempatmu. Bagi Anda yang akan menyajikannya, dibawah ini merupakan cara membuat chicken lava yang mantab yang mampu Kalian coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Chicken lava:

1. Gunakan 300 gr ayam fillet
1. Sediakan 2 siung bawang putih
1. Sediakan 1 buah jeruk nipis
1. Sediakan 1 sdt cabai bubuk
1. Gunakan 1 bungkus tepung serbaguna ayam krispy
1. Siapkan  Minyak goreng
1. Ambil  Saus lava
1. Siapkan 1/2 buab bawang bombai
1. Ambil 200 gr saos hot lava
1. Ambil 30 gr saus tomat
1. Ambil 30 gr saus sambal
1. Gunakan 1 sdm gula pasir
1. Ambil 1/2 sdt kaldu
1. Gunakan 1/2 sdt garam
1. Ambil 20 ml air
1. Sediakan 2 sdm margarin / minyak goreng




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Chicken lava:

1. Potong dadu ayam fillet, cuci bersoh dan tiriskan.
1. Parut bawang putih campurkan air perasan jeruk nipis dan cabai bubuk aduk rata. Masukkan ayam dan marinasi selama 30 menit
1. Siapkan 3 sdm tepung dan campurkan air aduk rata, masukkan ayam dan balur dengan tepung kering lalu goreng di minyak panas. Lakukan sampai ayam habis.
1. Membuat saus, cincang bawang bombay tumis hingga wangi. Masukkan semua bahan saus. Aduk rata dan beri sedikit air. Cek rasa.
1. Jika saus sudah meletup-letup masukkan ayam yg sudah di goreng. Aduk hingga rata.




Wah ternyata cara membuat chicken lava yang mantab simple ini gampang banget ya! Semua orang dapat menghidangkannya. Cara Membuat chicken lava Sangat cocok banget buat kalian yang baru mau belajar memasak maupun untuk kalian yang telah hebat memasak.

Apakah kamu ingin mencoba bikin resep chicken lava enak tidak rumit ini? Kalau kamu mau, ayo kalian segera siapin peralatan dan bahan-bahannya, setelah itu buat deh Resep chicken lava yang mantab dan tidak ribet ini. Sungguh gampang kan. 

Oleh karena itu, daripada kalian berlama-lama, yuk kita langsung saja hidangkan resep chicken lava ini. Pasti kamu gak akan menyesal membuat resep chicken lava enak tidak ribet ini! Selamat mencoba dengan resep chicken lava nikmat tidak rumit ini di rumah masing-masing,oke!.

