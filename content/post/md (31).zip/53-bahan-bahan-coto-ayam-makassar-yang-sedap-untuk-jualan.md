---
description: "Bahan-bahan Coto ayam makassar yang sedap Untuk Jualan"
title: "Bahan-bahan Coto ayam makassar yang sedap Untuk Jualan"
slug: 53-bahan-bahan-coto-ayam-makassar-yang-sedap-untuk-jualan
date: 2021-02-27T21:17:49.834Z
image: https://img-global.cpcdn.com/recipes/52ce811871121a45/680x482cq70/coto-ayam-makassar-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/52ce811871121a45/680x482cq70/coto-ayam-makassar-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/52ce811871121a45/680x482cq70/coto-ayam-makassar-foto-resep-utama.jpg
author: Chad Casey
ratingvalue: 4
reviewcount: 9
recipeingredient:
- "1 kg daging ayam potong dadu"
- "5 lembar daun jeruk"
- "3 lembar daun Salam"
- "Seruas lengkuasgeprek"
- "250 gr kacang tanah goreng dan haluskan"
- " Secukupnya kayu manis"
- " Secukupnya garam"
- " Secukupnya air"
- " Secukupnya kaldu ayam"
- " Bumbu yang di haluskan"
- " 10 butir bawang merah"
- " 10 butir bawang putih"
- " Seruas jahe"
- " Seruas lengkuas"
- " 1 sdt ketumbar"
- " 1 sdt merica"
- " 1 sdt jintan"
- " 1 buah pala"
- " 5 butir kemiri"
- "7 batang serai"
- " Bahan pelengkap"
- " Bawang goreng"
- " Daun bawang dan seledri"
- " Jeruk nipis"
- " Sambal"
recipeinstructions:
- "Cuci bersih daging ayam,rebus dengan air secukupnya sampai matang,angkat dan sisihkan"
- "Sementara daging ayam di rebus, tumis bumbu halus sampai harum dengan minyak secukupnya, masukkan daun jeruk, daun salam, lengkuas geprek, kayu manis"
- "Masak kembali air rebusan ayam sampai mendidih, masukkan bumbu halus, kacang halus, biarkan sampai bumbu meresap, masukkan garam dan kaldu bubuk, test rasa, angkat"
- "Masukkan daging ayam ke dalam wadah, siram dengan kuah coto, masukkan pelengkap, siap di hidangkan"
categories:
- Resep
tags:
- coto
- ayam
- makassar

katakunci: coto ayam makassar 
nutrition: 124 calories
recipecuisine: Indonesian
preptime: "PT14M"
cooktime: "PT44M"
recipeyield: "2"
recipecategory: Dessert

---


![Coto ayam makassar](https://img-global.cpcdn.com/recipes/52ce811871121a45/680x482cq70/coto-ayam-makassar-foto-resep-utama.jpg)

Selaku seorang wanita, menyajikan masakan lezat buat keluarga merupakan suatu hal yang menyenangkan bagi kamu sendiri. Tanggung jawab seorang ibu bukan sekedar mengatur rumah saja, tapi anda pun wajib menyediakan kebutuhan nutrisi tercukupi dan olahan yang dikonsumsi keluarga tercinta harus enak.

Di masa  saat ini, kalian memang bisa membeli masakan jadi tidak harus capek mengolahnya lebih dulu. Tetapi ada juga mereka yang selalu mau memberikan hidangan yang terlezat bagi orang tercintanya. Karena, menghidangkan masakan yang diolah sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan makanan tersebut berdasarkan masakan kesukaan keluarga tercinta. 



Apakah anda merupakan seorang penyuka coto ayam makassar?. Tahukah kamu, coto ayam makassar adalah hidangan khas di Nusantara yang sekarang disukai oleh setiap orang dari berbagai tempat di Indonesia. Kamu bisa membuat coto ayam makassar buatan sendiri di rumahmu dan pasti jadi santapan kegemaranmu di akhir pekanmu.

Anda tidak usah bingung untuk menyantap coto ayam makassar, sebab coto ayam makassar mudah untuk didapatkan dan juga kamu pun dapat mengolahnya sendiri di rumah. coto ayam makassar boleh dimasak lewat beragam cara. Saat ini telah banyak banget cara kekinian yang menjadikan coto ayam makassar semakin mantap.

Resep coto ayam makassar juga sangat gampang untuk dibikin, lho. Anda tidak perlu capek-capek untuk memesan coto ayam makassar, karena Anda mampu menyiapkan di rumahmu. Bagi Kita yang akan mencobanya, di bawah ini adalah cara untuk membuat coto ayam makassar yang lezat yang dapat Kita coba.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Coto ayam makassar:

1. Gunakan 1 kg daging ayam (potong dadu)
1. Sediakan 5 lembar daun jeruk
1. Gunakan 3 lembar daun Salam
1. Ambil Seruas lengkuas(geprek)
1. Siapkan 250 gr kacang tanah (goreng dan haluskan)
1. Siapkan  Secukupnya kayu manis
1. Ambil  Secukupnya garam
1. Ambil  Secukupnya air
1. Sediakan  Secukupnya kaldu ayam
1. Sediakan  Bumbu yang di haluskan
1. Siapkan  10 butir bawang merah
1. Sediakan  10 butir bawang putih
1. Gunakan  Seruas jahe
1. Ambil  Seruas lengkuas
1. Ambil  1 sdt ketumbar
1. Gunakan  1 sdt merica
1. Sediakan  1 sdt jintan
1. Ambil  1 buah pala
1. Gunakan  5 butir kemiri
1. Ambil 7 batang serai
1. Ambil  Bahan pelengkap
1. Ambil  Bawang goreng
1. Gunakan  Daun bawang dan seledri
1. Ambil  Jeruk nipis
1. Gunakan  Sambal




<!--inarticleads2-->

##### Langkah-langkah membuat Coto ayam makassar:

1. Cuci bersih daging ayam,rebus dengan air secukupnya sampai matang,angkat dan sisihkan
1. Sementara daging ayam di rebus, tumis bumbu halus sampai harum dengan minyak secukupnya, masukkan daun jeruk, daun salam, lengkuas geprek, kayu manis
1. Masak kembali air rebusan ayam sampai mendidih, masukkan bumbu halus, kacang halus, biarkan sampai bumbu meresap, masukkan garam dan kaldu bubuk, test rasa, angkat
1. Masukkan daging ayam ke dalam wadah, siram dengan kuah coto, masukkan pelengkap, siap di hidangkan




Wah ternyata resep coto ayam makassar yang mantab sederhana ini enteng banget ya! Anda Semua dapat memasaknya. Resep coto ayam makassar Sangat cocok sekali buat anda yang baru belajar memasak maupun untuk kamu yang telah lihai dalam memasak.

Tertarik untuk mencoba buat resep coto ayam makassar nikmat tidak ribet ini? Kalau kalian mau, ayo kalian segera buruan siapin alat-alat dan bahan-bahannya, lalu bikin deh Resep coto ayam makassar yang lezat dan sederhana ini. Benar-benar taidak sulit kan. 

Jadi, ketimbang kita diam saja, hayo langsung aja hidangkan resep coto ayam makassar ini. Dijamin anda tiidak akan menyesal sudah buat resep coto ayam makassar nikmat tidak rumit ini! Selamat berkreasi dengan resep coto ayam makassar nikmat tidak ribet ini di rumah kalian sendiri,oke!.

