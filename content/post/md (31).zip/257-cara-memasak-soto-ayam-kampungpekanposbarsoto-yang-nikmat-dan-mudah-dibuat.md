---
description: "Cara memasak Soto Ayam Kampung#PekanPosbarSoto yang nikmat dan Mudah Dibuat"
title: "Cara memasak Soto Ayam Kampung#PekanPosbarSoto yang nikmat dan Mudah Dibuat"
slug: 257-cara-memasak-soto-ayam-kampungpekanposbarsoto-yang-nikmat-dan-mudah-dibuat
date: 2021-02-21T17:03:50.285Z
image: https://img-global.cpcdn.com/recipes/bd48d401b899ff55/680x482cq70/soto-ayam-kampungpekanposbarsoto-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/bd48d401b899ff55/680x482cq70/soto-ayam-kampungpekanposbarsoto-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/bd48d401b899ff55/680x482cq70/soto-ayam-kampungpekanposbarsoto-foto-resep-utama.jpg
author: Winnie Estrada
ratingvalue: 3.6
reviewcount: 13
recipeingredient:
- "1 ekor ayam kampung"
- "1 sendok teh Merica bubuk"
- "2 siung Bawang putih halus"
- "10 butir bawang merah"
- "1 ruas Jahe halus"
- "2-3 lembar Daun jeruk purut"
- "5 buah Kunyit haluskan"
- "5 batang serai digeprek"
- "500 gram kerupuk udang dihaluskan Sebagai bubuk koya"
- " Sabel Cabe"
- "500 gram cabe rawit"
- "2 butir bawang putih"
- "2 butir bawang merah"
- "secukupnya Penyedap rasa"
- "secukupnya Garam"
- "1/2 sendok makan Gula"
- " Tambahan lain"
- "500 gram soun"
- "500 gram Nasi putih"
- "500 gram Tomat Potong sesuai selera"
- "500 kol dipotong halus cuci bersihrebus 3 menit dalam air mendidih angkat tiriskan"
- "500 gram Tauge dibersihkan cuci rebus dalam air mendidih selama 3 menit angkat tiriskan"
- "1-2 Jeruklemonjeruk nipis"
- "500 gram Bawang goreng"
- " Rp 2000 daun bawang cuci bersih iris halus"
- "8 butir Asam kandis"
- "6 butir telur rebus kupas kulitnya belah dua opsional"
recipeinstructions:
- "Bersihkan ayam, cuci bersih bersih, potong 4 bagian, rebus dalam panci besar, air 2000 ml"
- "Masukan semua bumbu halus (jahe, kunyit, bawang merah, bawang putih, merica, daun jeruk 3 lembar, serai geprek 5 batang, asam kandis 8 biji) kedalam panci rebusan isi ayam, masak hingga ayam matang, lembut, dan empuk"
- "Jika air sudah mulai sedikit tambah air lagi secukupnya, kira kira sebanyak yg kita inginkan."
- "Setelah ayam lembut dan empuk, masukan garam dan penyedap rasa secukupnya, sampai terasa pas di lidah ya"
- "Angkat ayam yg sudah empuk dan lembut, teruskan. Supir supir daging nya, sisihkan dalam wadah tupperware atau wadah kaca."
- "Tulang tulang dari sisa ayam yg disuwir dimasukkan ke dalam kuah di panci, agar kaldu soto nya berasa banget, masak kuah soto nya tersebut sampai mendidih. (waktu suwir ayam yg sudah masak menggunakan sarung tangan plastik atau karet ya, biar enak dilihat)"
- "Sekarang kita buat sambil cabe nya, rebus cabe, bawang merah 2 butir, bawang putih 2 butir, setelah direbus mari kita dinginkan, setelah itu blender dengan ditambah garam, penyedap rasa, dan gula 1/2 sendok makan. Tambah cuka 1/2 sendok makan, atau air lemon/jeruk limo peras 1 sendok makan. Tara sambil nya jadi deh"
- "Siapkan soun dengan di rebus dalam air mendidih sampai matang, terus tiriskan, cuci dengan air es atau air galon."
- "Sajikan, soto bisa dinikmati dengan soun atau nasi putih"
- "Siapkan mangkuk, isi dg soun, kol, tauge, tomat, ayam suwir, taburi serbuk koya, bawang goreng, daun bawang, kemudian siram dg kuah soto yg masih mendidih, Taruh 1/2 potong telur rebus, sedap dimakan pas lagi cuaca dingin atau saat hujan. Tambahkan sepiring nasi kalau suka, tambahkan sampel cabe, kecap."
categories:
- Resep
tags:
- soto
- ayam
- kampungpekanposbarsoto

katakunci: soto ayam kampungpekanposbarsoto 
nutrition: 240 calories
recipecuisine: Indonesian
preptime: "PT38M"
cooktime: "PT54M"
recipeyield: "3"
recipecategory: Dinner

---


![Soto Ayam Kampung#PekanPosbarSoto](https://img-global.cpcdn.com/recipes/bd48d401b899ff55/680x482cq70/soto-ayam-kampungpekanposbarsoto-foto-resep-utama.jpg)

Sebagai seorang orang tua, menyediakan hidangan mantab kepada orang tercinta adalah suatu hal yang menyenangkan bagi anda sendiri. Peran seorang ibu Tidak hanya mengerjakan pekerjaan rumah saja, namun kamu juga harus memastikan kebutuhan nutrisi terpenuhi dan juga hidangan yang dikonsumsi anak-anak wajib lezat.

Di waktu  sekarang, kita memang bisa mengorder olahan praktis tanpa harus repot memasaknya dulu. Tapi ada juga lho orang yang selalu mau menghidangkan yang terenak bagi keluarganya. Sebab, menyajikan masakan yang dibuat sendiri jauh lebih bersih dan bisa menyesuaikan hidangan tersebut sesuai makanan kesukaan keluarga. 



Apakah anda adalah seorang penggemar soto ayam kampung#pekanposbarsoto?. Asal kamu tahu, soto ayam kampung#pekanposbarsoto adalah makanan khas di Nusantara yang saat ini digemari oleh setiap orang di hampir setiap tempat di Indonesia. Kalian dapat menghidangkan soto ayam kampung#pekanposbarsoto sendiri di rumah dan boleh jadi hidangan favorit di hari libur.

Kamu tidak usah bingung untuk menyantap soto ayam kampung#pekanposbarsoto, lantaran soto ayam kampung#pekanposbarsoto sangat mudah untuk ditemukan dan kalian pun bisa memasaknya sendiri di rumah. soto ayam kampung#pekanposbarsoto bisa dimasak dengan berbagai cara. Kini ada banyak cara modern yang menjadikan soto ayam kampung#pekanposbarsoto semakin enak.

Resep soto ayam kampung#pekanposbarsoto pun gampang sekali dibuat, lho. Kita tidak perlu capek-capek untuk membeli soto ayam kampung#pekanposbarsoto, sebab Anda mampu menyiapkan di rumah sendiri. Untuk Anda yang hendak menyajikannya, di bawah ini adalah cara membuat soto ayam kampung#pekanposbarsoto yang mantab yang dapat Kita buat sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Soto Ayam Kampung#PekanPosbarSoto:

1. Siapkan 1 ekor ayam kampung
1. Ambil 1 sendok teh Merica bubuk
1. Gunakan 2 siung Bawang putih halus
1. Sediakan 10 butir bawang merah
1. Sediakan 1 ruas Jahe halus
1. Siapkan 2-3 lembar Daun jeruk purut
1. Gunakan 5 buah Kunyit haluskan
1. Sediakan 5 batang serai digeprek
1. Gunakan 500 gram kerupuk udang dihaluskan Sebagai bubuk koya
1. Ambil  Sabel Cabe
1. Ambil 500 gram cabe rawit
1. Gunakan 2 butir bawang putih
1. Gunakan 2 butir bawang merah
1. Siapkan secukupnya Penyedap rasa
1. Sediakan secukupnya Garam
1. Sediakan 1/2 sendok makan Gula
1. Sediakan  Tambahan lain
1. Gunakan 500 gram soun
1. Siapkan 500 gram Nasi putih
1. Siapkan 500 gram Tomat Potong sesuai selera
1. Ambil 500 kol dipotong halus cuci bersih,rebus 3 menit dalam air mendidih angkat, tiriskan
1. Ambil 500 gram Tauge, dibersihkan, cuci, rebus dalam air mendidih selama 3 menit, angkat tiriskan
1. Siapkan 1-2 Jeruk/lemon/jeruk nipis
1. Ambil 500 gram Bawang goreng
1. Siapkan  Rp 2.000 daun bawang, cuci bersih, iris halus
1. Sediakan 8 butir Asam kandis
1. Ambil 6 butir telur rebus, kupas kulitnya, belah dua (opsional)




<!--inarticleads2-->

##### Cara menyiapkan Soto Ayam Kampung#PekanPosbarSoto:

1. Bersihkan ayam, cuci bersih bersih, potong 4 bagian, rebus dalam panci besar, air 2000 ml
1. Masukan semua bumbu halus (jahe, kunyit, bawang merah, bawang putih, merica, daun jeruk 3 lembar, serai geprek 5 batang, asam kandis 8 biji) kedalam panci rebusan isi ayam, masak hingga ayam matang, lembut, dan empuk
1. Jika air sudah mulai sedikit tambah air lagi secukupnya, kira kira sebanyak yg kita inginkan.
1. Setelah ayam lembut dan empuk, masukan garam dan penyedap rasa secukupnya, sampai terasa pas di lidah ya
1. Angkat ayam yg sudah empuk dan lembut, teruskan. Supir supir daging nya, sisihkan dalam wadah tupperware atau wadah kaca.
1. Tulang tulang dari sisa ayam yg disuwir dimasukkan ke dalam kuah di panci, agar kaldu soto nya berasa banget, masak kuah soto nya tersebut sampai mendidih. (waktu suwir ayam yg sudah masak menggunakan sarung tangan plastik atau karet ya, biar enak dilihat)
1. Sekarang kita buat sambil cabe nya, rebus cabe, bawang merah 2 butir, bawang putih 2 butir, setelah direbus mari kita dinginkan, setelah itu blender dengan ditambah garam, penyedap rasa, dan gula 1/2 sendok makan. Tambah cuka 1/2 sendok makan, atau air lemon/jeruk limo peras 1 sendok makan. Tara sambil nya jadi deh
1. Siapkan soun dengan di rebus dalam air mendidih sampai matang, terus tiriskan, cuci dengan air es atau air galon.
1. Sajikan, soto bisa dinikmati dengan soun atau nasi putih
1. Siapkan mangkuk, isi dg soun, kol, tauge, tomat, ayam suwir, taburi serbuk koya, bawang goreng, daun bawang, kemudian siram dg kuah soto yg masih mendidih, Taruh 1/2 potong telur rebus, sedap dimakan pas lagi cuaca dingin atau saat hujan. Tambahkan sepiring nasi kalau suka, tambahkan sampel cabe, kecap.




Wah ternyata cara membuat soto ayam kampung#pekanposbarsoto yang enak tidak rumit ini mudah banget ya! Kita semua dapat mencobanya. Resep soto ayam kampung#pekanposbarsoto Sangat cocok banget untuk kalian yang baru mau belajar memasak atau juga untuk kamu yang telah pandai dalam memasak.

Apakah kamu ingin mulai mencoba membikin resep soto ayam kampung#pekanposbarsoto lezat simple ini? Kalau tertarik, ayo kamu segera buruan menyiapkan alat dan bahan-bahannya, setelah itu bikin deh Resep soto ayam kampung#pekanposbarsoto yang nikmat dan tidak ribet ini. Betul-betul mudah kan. 

Maka dari itu, daripada kalian diam saja, maka langsung aja buat resep soto ayam kampung#pekanposbarsoto ini. Dijamin kalian tak akan nyesel sudah membuat resep soto ayam kampung#pekanposbarsoto mantab sederhana ini! Selamat berkreasi dengan resep soto ayam kampung#pekanposbarsoto enak simple ini di tempat tinggal masing-masing,ya!.

