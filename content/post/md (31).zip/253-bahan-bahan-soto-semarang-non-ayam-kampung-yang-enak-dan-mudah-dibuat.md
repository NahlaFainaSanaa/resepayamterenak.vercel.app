---
description: "Bahan-bahan Soto Semarang (Non Ayam Kampung) yang enak dan Mudah Dibuat"
title: "Bahan-bahan Soto Semarang (Non Ayam Kampung) yang enak dan Mudah Dibuat"
slug: 253-bahan-bahan-soto-semarang-non-ayam-kampung-yang-enak-dan-mudah-dibuat
date: 2021-03-14T19:18:28.572Z
image: https://img-global.cpcdn.com/recipes/7f454489a7648587/680x482cq70/soto-semarang-non-ayam-kampung-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7f454489a7648587/680x482cq70/soto-semarang-non-ayam-kampung-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7f454489a7648587/680x482cq70/soto-semarang-non-ayam-kampung-foto-resep-utama.jpg
author: Gavin Curtis
ratingvalue: 4.6
reviewcount: 15
recipeingredient:
- "1/2 ekor ayam negri rebus hingga empuk"
- "3.5 liter air"
- "2.5 sdm bumbu dasar kuning           lihat resep"
- "5 lembar daun salam"
- "7 lembar daun jeruk"
- "2 batang sereh"
- "2 batang daun bawang potong"
- "2 batang daun seledri potong"
- "3 sdm garam"
- "1/2 keping gula merah"
- "2 sdm lada bubuk"
- "3 sdm kaldu jamur"
- "1 sdm pala bubuk"
- " ISIAN SOTO"
- "1 buah soun naga ukbesar rendam dgn air panas hingga lunak"
- "1/4 kol potong lalu cuci dgn air panas sebentar"
- "1 ons toge cuci  rendam sebentar dgn air panas"
- " PELENGKAP"
- " Sambal soto           lihat resep"
- " Jeruk nipis"
recipeinstructions:
- "Panaskan minyak goreng, masukkan bumbu dasar kuning. Tumis dgn daun salam, daun jeruk &amp; sereh hingga harum."
- "Masukkan tumisan bumbu dasar ke panci yg berisi air mendidih, masukkan ayam yg sdh di rebus sebelumnya. Rebus hingga bumbu meresap ke ayam, masukkan garam, lada bubuk, kaldu jamur, gula merah &amp; pala bubuk. Aduk sebentar, cicipi rasanya jika sdh sesuai selera. Angkat ayam, untuk suiran."
- "Siapkan dlm mangkuk soun, kol, tauge, suiran ayam &amp; rajangan daun bawang jg seledri. Lalu siram dgn kuah soto selagi hangat, makin mantep di sruput 🤤"
categories:
- Resep
tags:
- soto
- semarang
- non

katakunci: soto semarang non 
nutrition: 182 calories
recipecuisine: Indonesian
preptime: "PT23M"
cooktime: "PT35M"
recipeyield: "2"
recipecategory: Dessert

---


![Soto Semarang (Non Ayam Kampung)](https://img-global.cpcdn.com/recipes/7f454489a7648587/680x482cq70/soto-semarang-non-ayam-kampung-foto-resep-utama.jpg)

Sebagai seorang istri, menyediakan masakan enak kepada keluarga merupakan suatu hal yang menggembirakan bagi kamu sendiri. Peran seorang ibu bukan hanya mengatur rumah saja, tapi kamu juga harus menyediakan keperluan gizi tercukupi dan masakan yang disantap orang tercinta mesti lezat.

Di masa  sekarang, kamu sebenarnya bisa mengorder hidangan praktis meski tidak harus ribet mengolahnya terlebih dahulu. Namun banyak juga orang yang memang mau menyajikan yang terlezat bagi keluarganya. Karena, memasak sendiri akan jauh lebih higienis dan kita juga bisa menyesuaikan makanan tersebut sesuai dengan makanan kesukaan famili. 



Apakah kamu salah satu penyuka soto semarang (non ayam kampung)?. Asal kamu tahu, soto semarang (non ayam kampung) adalah makanan khas di Indonesia yang saat ini disenangi oleh kebanyakan orang dari hampir setiap wilayah di Nusantara. Kalian dapat menyajikan soto semarang (non ayam kampung) sendiri di rumahmu dan boleh jadi hidangan kesukaanmu di akhir pekan.

Kalian jangan bingung untuk menyantap soto semarang (non ayam kampung), lantaran soto semarang (non ayam kampung) gampang untuk ditemukan dan kalian pun dapat memasaknya sendiri di rumah. soto semarang (non ayam kampung) dapat dibuat dengan berbagai cara. Saat ini ada banyak banget cara modern yang membuat soto semarang (non ayam kampung) semakin lebih enak.

Resep soto semarang (non ayam kampung) pun mudah untuk dibuat, lho. Kamu tidak usah capek-capek untuk memesan soto semarang (non ayam kampung), karena Kita bisa menyiapkan di rumah sendiri. Bagi Kalian yang mau mencobanya, inilah cara untuk menyajikan soto semarang (non ayam kampung) yang enak yang bisa Kalian hidangkan sendiri.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Soto Semarang (Non Ayam Kampung):

1. Gunakan 1/2 ekor ayam negri, rebus hingga empuk
1. Gunakan 3.5 liter air
1. Gunakan 2.5 sdm bumbu dasar kuning           (lihat resep)
1. Ambil 5 lembar daun salam
1. Siapkan 7 lembar daun jeruk
1. Gunakan 2 batang sereh
1. Ambil 2 batang daun bawang, potong&#34;
1. Siapkan 2 batang daun seledri, potong&#34;
1. Gunakan 3 sdm garam
1. Gunakan 1/2 keping gula merah
1. Siapkan 2 sdm lada bubuk
1. Siapkan 3 sdm kaldu jamur
1. Sediakan 1 sdm pala bubuk
1. Gunakan  ISIAN SOTO:
1. Siapkan 1 buah soun naga uk.besar, rendam dgn air panas hingga lunak
1. Siapkan 1/4 kol, potong&#34; lalu cuci dgn air panas sebentar
1. Siapkan 1 ons toge, cuci &amp; rendam sebentar dgn air panas
1. Siapkan  PELENGKAP:
1. Sediakan  Sambal soto           (lihat resep)
1. Siapkan  Jeruk nipis




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Soto Semarang (Non Ayam Kampung):

1. Panaskan minyak goreng, masukkan bumbu dasar kuning. Tumis dgn daun salam, daun jeruk &amp; sereh hingga harum.
1. Masukkan tumisan bumbu dasar ke panci yg berisi air mendidih, masukkan ayam yg sdh di rebus sebelumnya. Rebus hingga bumbu meresap ke ayam, masukkan garam, lada bubuk, kaldu jamur, gula merah &amp; pala bubuk. Aduk sebentar, cicipi rasanya jika sdh sesuai selera. Angkat ayam, untuk suiran.
1. Siapkan dlm mangkuk soun, kol, tauge, suiran ayam &amp; rajangan daun bawang jg seledri. Lalu siram dgn kuah soto selagi hangat, makin mantep di sruput 🤤




Ternyata resep soto semarang (non ayam kampung) yang nikamt tidak rumit ini enteng sekali ya! Kalian semua mampu mencobanya. Cara Membuat soto semarang (non ayam kampung) Sesuai banget untuk kita yang baru mau belajar memasak maupun juga bagi anda yang sudah jago dalam memasak.

Apakah kamu tertarik mulai mencoba buat resep soto semarang (non ayam kampung) mantab tidak ribet ini? Kalau kalian mau, mending kamu segera buruan menyiapkan alat-alat dan bahan-bahannya, kemudian bikin deh Resep soto semarang (non ayam kampung) yang mantab dan simple ini. Sangat mudah kan. 

Oleh karena itu, daripada kamu diam saja, maka kita langsung saja buat resep soto semarang (non ayam kampung) ini. Dijamin anda gak akan menyesal sudah membuat resep soto semarang (non ayam kampung) lezat simple ini! Selamat mencoba dengan resep soto semarang (non ayam kampung) nikmat tidak rumit ini di tempat tinggal masing-masing,ya!.

